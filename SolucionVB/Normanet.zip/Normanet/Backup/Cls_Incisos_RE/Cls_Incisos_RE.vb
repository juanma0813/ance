Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class Cls_Incisos_RE
    Private _Id_Inciso_Rev As Integer
    Private _Id_tipo_Rev As Integer
    Private _Id_Status_Rev As Integer
    Private _Requisito As String
    Private _Descripcion As String
    Private _Inactivo As Integer

    Private _Bandera As Integer
    Private _Error As String

#Region " Constructor, C�digo generado por Mariano Ascencio "

    ' Conexion 
    Private cn As New SqlConnection
    Private dr As SqlDataReader
    Dim objConexion As New clsConexion.cIsConexion

    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
    End Sub

#End Region

#Region " Propiedades, C�digo generado por Mariano Ascencio "

    Public Property Id_Inciso_Rev() As Integer
        Get
            Return _Id_Inciso_Rev
        End Get
        Set(ByVal Value As Integer)
            _Id_Inciso_Rev = Value
        End Set
    End Property

    Public Property Id_tipo_Rev() As Integer
        Get
            Return _Id_tipo_Rev
        End Get
        Set(ByVal Value As Integer)
            _Id_tipo_Rev = Value
        End Set
    End Property

    Public Property Id_Status_Rev() As Integer
        Get
            Return _Id_Status_Rev
        End Get
        Set(ByVal Value As Integer)
            _Id_Status_Rev = Value
        End Set
    End Property

    Public Property Requisito() As String
        Get
            Return _Requisito
        End Get
        Set(ByVal Value As String)
            _Requisito = Value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As String)
            _Descripcion = Value
        End Set
    End Property

    Public Property Inactivo() As Integer
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Integer)
            _Inactivo = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property

#End Region

    Public Sub ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Inciso_RE_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Inciso_Rev", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Id_Status_Rev", _Id_Status_Rev)
        cmd.Parameters.Add("@Requisito", _Requisito)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@Inactivo", _Inactivo)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_IRE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return
        End Try
    End Sub

    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Inciso_RE_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Inciso_Rev", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Id_Status_Rev", _Id_Status_Rev)
        cmd.Parameters.Add("@Requisito", _Requisito)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@Inactivo", _Inactivo)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_IRE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

    Public Sub Buscar()

        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Inciso_RE_buscar "
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Inciso_Rev", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Id_Status_Rev", _Id_Status_Rev)
        cmd.Parameters.Add("@Requisito", _Requisito)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@Inactivo", _Inactivo)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Inciso_Rev = IIf((IsDBNull(dr("Id_Inciso_Rev"))), 0, dr("Id_Inciso_Rev"))
                _Id_tipo_Rev = IIf((IsDBNull(dr("Id_tipo_Rev"))), 0, dr("Id_tipo_Rev"))
                _Id_Status_Rev = IIf((IsDBNull(dr("Id_Status_Rev"))), 0, dr("Id_Status_Rev"))
                _Descripcion = IIf((IsDBNull(dr("Descripcion"))), "", dr("Descripcion"))
                _Requisito = IIf((IsDBNull(dr("Requisito"))), "", dr("Requisito"))
                _Inactivo = IIf((IsDBNull(dr("Inactivo"))), 0, dr("Inactivo"))
            Else
                _Id_Inciso_Rev = 0
                _Id_tipo_Rev = 0
                _Id_Status_Rev = 0
                _Descripcion = ""
                _Requisito = ""
                _Inactivo = 0
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Sub

    Public Function Insertar() As Boolean
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Inciso_RE"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Inciso_Rev", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Id_Status_Rev", _Id_Status_Rev)
        cmd.Parameters.Add("@Requisito", _Requisito)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            Return True

        Catch ex As Exception

            Return False
        End Try
    End Function

    Public Function Actualizar() As Boolean
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Inciso_RE"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Inciso_Rev", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Id_Status_Rev", _Id_Status_Rev)
        cmd.Parameters.Add("@Requisito", _Requisito)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Function borrar() As Boolean
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "Sp_C_Inciso_RE"
            .Parameters.Add("@Id_Inciso_Rev", _Id_Inciso_Rev)
            .Parameters.Add("@Inactivo", _Inactivo)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            Return True
        Catch ex As Exception
            Return False
        End Try
        '
    End Function
End Class
