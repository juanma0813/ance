
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Prog_Trab Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 07/09/2006 01:12:25 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient


Public Class P_Prog_Trab

     '''''''Declaracion de Variables Privadas

    Private _Id_Plan As String
    Private _Id_Tema As Integer
    Private _Clasificacion As String
    Private _Tipo_Pro As String
    Private _Tipo_Tema As String
    Private _Titulo As String
    Private _Obj As String
    Private _Justificacion As String
    Private _F_Inicio As String
    Private _F_Fin As String
    Private _Revision As String
    Private _ID_Comite As String
    Private _ID_CT As String
    Private _ID_SC As String
    Private _ID_Grupo As String
    Private _ID_etapa As Integer
    Private _Responsable As String
    Private _Bandera As Integer
    Private _Error As String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

    '''''''Declaracion de Propiedades publicas
    Public Property Id_Plan() As String
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value As String)
            _Id_Plan = Value
        End Set
    End Property

    Public Property Id_Tema() As Integer
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value As Integer)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Clasificacion() As String
        Get
            Return _Clasificacion
        End Get
        Set(ByVal Value As String)
            _Clasificacion = Value
        End Set
    End Property

    Public Property Tipo_Pro() As String
        Get
            Return _Tipo_Pro
        End Get
        Set(ByVal Value As String)
            _Tipo_Pro = Value
        End Set
    End Property

    Public Property Tipo_Tema() As String
        Get
            Return _Tipo_Tema
        End Get
        Set(ByVal Value As String)
            _Tipo_Tema = Value
        End Set
    End Property

    Public Property Titulo() As String
        Get
            Return _Titulo
        End Get
        Set(ByVal Value As String)
            _Titulo = Value
        End Set
    End Property

    Public Property Obj() As String
        Get
            Return _Obj
        End Get
        Set(ByVal Value As String)
            _Obj = Value
        End Set
    End Property

    Public Property Justificacion() As String
        Get
            Return _Justificacion
        End Get
        Set(ByVal Value As String)
            _Justificacion = Value
        End Set
    End Property

    Public Property F_Inicio() As String
        Get
            Return _F_Inicio
        End Get
        Set(ByVal Value As String)
            _F_Inicio = Value
        End Set
    End Property

    Public Property F_Fin() As String
        Get
            Return _F_Fin
        End Get
        Set(ByVal Value As String)
            _F_Fin = Value
        End Set
    End Property

    Public Property Revision() As String
        Get
            Return _Revision
        End Get
        Set(ByVal Value As String)
            _Revision = Value
        End Set
    End Property

    Public Property ID_Comite() As String
        Get
            Return _ID_Comite
        End Get
        Set(ByVal Value As String)
            _ID_Comite = Value
        End Set
    End Property

    Public Property ID_CT() As String
        Get
            Return _ID_CT
        End Get
        Set(ByVal Value As String)
            _ID_CT = Value
        End Set
    End Property

    Public Property ID_SC() As String
        Get
            Return _ID_SC
        End Get
        Set(ByVal Value As String)
            _ID_SC = Value
        End Set
    End Property

    Public Property ID_Grupo() As String
        Get
            Return _ID_Grupo
        End Get
        Set(ByVal Value As String)
            _ID_Grupo = Value
        End Set
    End Property

    Public Property ID_etapa() As Integer
        Get
            Return _ID_etapa
        End Get
        Set(ByVal Value As Integer)
            _ID_etapa = Value
        End Set
    End Property

    Public Property Responsable() As String
        Get
            Return _Responsable
        End Get
        Set(ByVal Value As String)
            _Responsable = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        cn.ConnectionString = objconexion.Conexion(Identif, Usuario, Password)


        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la llena de campos de la tabla en un combo
    Public Function ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_Programa_Trabajo_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsSesiones")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Error = "Error " & ex.Source & " - " & ex.Message
        End Try
    End Function

    '''''''''''''''''Genera una la lista de campos
    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_Programa_Trabajo_buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsSesiones")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
   
            Return dt
        Catch ex As Exception
            _Error = "Error " & ex.Source & " - " & ex.Message
            Return Nothing
        End Try
    End Function

    Private Sub llena_parametros(ByVal command As SqlCommand)
        With command
            'llave de c_empleado completo
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Clasificacion", _Clasificacion)
            .Parameters.Add("@Tipo_Pro", _Tipo_Pro)
            .Parameters.Add("@Tipo_Tema", _Tipo_Tema)
            .Parameters.Add("@Titulo", _Titulo)
            .Parameters.Add("@Obj", _Obj)
            .Parameters.Add("@Justificacion", _Justificacion)
            .Parameters.Add("@F_Inicio", _F_Inicio)
            .Parameters.Add("@F_Fin", _F_Fin)
            .Parameters.Add("@Revision", _Revision)
            .Parameters.Add("@ID_Comite", _ID_Comite)
            .Parameters.Add("@ID_CT", _ID_CT)
            .Parameters.Add("@ID_SC", _ID_SC)
            .Parameters.Add("@ID_Grupo", _ID_Grupo)
            .Parameters.Add("@ID_etapa", _ID_etapa)
            .Parameters.Add("@Responsable", _Responsable)
            .Parameters.Add("@Bandera", _Bandera)
        End With
    End Sub

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar(ByVal stema As String, ByVal splan As String)
        Dim cmd As New SqlCommand
        If cn.State = ConnectionState.Open Then cn.Close()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_Programa_Trabajo_buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Plan = IIf((IsDBNull(dr("Id_Plan"))), "", dr("Id_Plan"))
                _Id_Tema = IIf((IsDBNull(dr("Id_Tema"))), 0, dr("Id_Tema"))
                _Clasificacion = IIf((IsDBNull(dr("Clasificacion"))), "", dr("Clasificacion"))
                _Tipo_Pro = IIf((IsDBNull(dr("Tipo_Pro"))), "", dr("Tipo_Pro"))
                _Tipo_Tema = IIf((IsDBNull(dr("Tipo_Tema"))), 0, dr("Tipo_Tema"))
                _Titulo = IIf((IsDBNull(dr("Titulo"))), "", dr("Titulo"))
                _Obj = IIf((IsDBNull(dr("Obj"))), "", dr("Obj"))
                _Justificacion = IIf((IsDBNull(dr("Justificacion"))), "", dr("Justificacion"))
                _F_Inicio = IIf((IsDBNull(dr("F_Inicio"))), Now(), dr("F_Inicio"))
                _F_Fin = IIf((IsDBNull(dr("F_Fin"))), Now(), dr("F_Fin"))
                _Revision = IIf((IsDBNull(dr("Revision"))), "", dr("Revision"))
                _ID_Comite = IIf((IsDBNull(dr("ID_Comite"))), "", dr("ID_Comite"))
                _ID_CT = IIf((IsDBNull(dr("ID_CT"))), "", dr("ID_CT"))
                _ID_SC = IIf((IsDBNull(dr("ID_SC"))), "", dr("ID_SC"))
                _ID_Grupo = IIf((IsDBNull(dr("ID_Grupo"))), "", dr("ID_Grupo"))
                _ID_etapa = IIf((IsDBNull(dr("ID_etapa"))), 0, dr("ID_etapa"))
                _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
            Else
                _Id_Plan = ""
                _Id_Tema = 0
                _Clasificacion = ""
                _Tipo_Pro = ""
                _Tipo_Tema = 0
                _Titulo = ""
                _Obj = ""
                _Justificacion = ""
                _F_Inicio = "01/01/2000"
                _F_Fin = "01/01/2000"
                _Revision = ""
                _ID_Comite = ""
                _ID_CT = ""
                _ID_SC = ""
                _ID_Grupo = ""
                _ID_etapa = 0
                _Responsable = ""
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try

    End Sub

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE P_Prog_Trab SET Id_Plan = @Id_Plan, Id_Tema = @Id_Tema, Clasificacion = @Clasificacion, Tipo_Pro = @Tipo_Pro, Tipo_Tema = @Tipo_Tema, Titulo = @Titulo, Obj = @Obj, Justificacion = @Justificacion, F_Inicio = @F_Inicio, F_Fin = @F_Fin, Revision = @Revision, ID_Comite = @ID_Comite, ID_CT = @ID_CT, ID_SC = @ID_SC, ID_Grupo = @ID_Grupo, ID_etapa = @ID_etapa, Responsable = @Responsable, Where ( = @)"
        cmd.Parameters.Add("@Id_Plan", SqlDbType.NVarChar, 20, "_Id_Plan")
        cmd.Parameters.Add("@Id_Tema", SqlDbType.Int, 0, "_Id_Tema")
        cmd.Parameters.Add("@Clasificacion", SqlDbType.NVarChar, 50, "_Clasificacion")
        cmd.Parameters.Add("@Tipo_Pro", SqlDbType.NVarChar, 20, "_Tipo_Pro")
        cmd.Parameters.Add("@Tipo_Tema", SqlDbType.NVarChar, 20, "_Tipo_Tema")
        cmd.Parameters.Add("@Titulo", SqlDbType.NVarChar, 2147483647, "_Titulo")
        cmd.Parameters.Add("@Obj", SqlDbType.NVarChar, 2147483647, "_Obj")
        cmd.Parameters.Add("@Justificacion", SqlDbType.NVarChar, 2147483647, "_Justificacion")
        cmd.Parameters.Add("@F_Inicio", SqlDbType.NVarChar, 0, "_F_Inicio")
        cmd.Parameters.Add("@F_Fin", SqlDbType.NVarChar, 0, "_F_Fin")
        cmd.Parameters.Add("@Revision", SqlDbType.NVarChar, 15, "_Revision")
        cmd.Parameters.Add("@ID_Comite", SqlDbType.NVarChar, 15, "_ID_Comite")
        cmd.Parameters.Add("@ID_CT", SqlDbType.NVarChar, 15, "_ID_CT")
        cmd.Parameters.Add("@ID_SC", SqlDbType.NVarChar, 15, "_ID_SC")
        cmd.Parameters.Add("@ID_Grupo", SqlDbType.NVarChar, 15, "_ID_Grupo")
        cmd.Parameters.Add("@ID_etapa", SqlDbType.Int, 0, "_ID_etapa")
        cmd.Parameters.Add("@Responsable", SqlDbType.NVarChar, 15, "_Responsable")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal Clasificacion As String, ByVal Tipo_Pro As String, ByVal Tipo_Tema As String, ByVal Titulo As String, ByVal Obj As String, ByVal Justificacion As String, ByVal F_Inicio As String, ByVal F_Fin As String, ByVal Revision As String, ByVal ID_Comite As String, ByVal ID_CT As String, ByVal ID_SC As String, ByVal ID_Grupo As String, ByVal ID_etapa As Integer, ByVal Responsable As String) As String
        Dim cmd As New SqlCommand("sp_Programa_Trabajo", cn)
        cmd.Parameters.Add("@Bandera", 1)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@Clasificacion", Clasificacion)
        cmd.Parameters.Add("@Tipo_Pro", Tipo_Pro)
        cmd.Parameters.Add("@Tipo_Tema", Tipo_Tema)
        cmd.Parameters.Add("@Titulo", Titulo)
        cmd.Parameters.Add("@Obj", Obj)
        cmd.Parameters.Add("@Justificacion", Justificacion)
        cmd.Parameters.Add("@F_Inicio", F_Inicio)
        cmd.Parameters.Add("@F_Fin", F_Fin)
        cmd.Parameters.Add("@Revision", Revision)
        cmd.Parameters.Add("@ID_Comite", ID_Comite)
        cmd.Parameters.Add("@ID_CT", ID_CT)
        cmd.Parameters.Add("@ID_SC", ID_SC)
        cmd.Parameters.Add("@ID_Grupo", ID_Grupo)
        cmd.Parameters.Add("@ID_etapa", ID_etapa)
        cmd.Parameters.Add("@Responsable", Responsable)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
