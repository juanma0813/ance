Imports System.Resources
Imports System.Reflection
Imports System.Threading
Imports System.Globalization


Namespace Maple

    Public Class clsValidarCampos

        Public Function ValidarCampos(ByVal Campos As Array) As String
            Dim CamposInvalidos As String = ""
            Dim CampoValidado As String

            If Not Campos Is Nothing Then
                For Each campo As String In Campos
                    REM busco el campo en el archivo de recursos
                    REM ver si el objeto esta en la lista de recursos y agregarlo al registro 0 del arreglo
                    If campo <> "" Then CampoValidado = ConsutlaRecurso(campo)

                    If CampoValidado <> "" Then
                        CamposInvalidos += CampoValidado + ","
                    End If
                Next
                CamposInvalidos = CamposInvalidos.Substring(0, CamposInvalidos.Length - 1)
            End If

            Return CamposInvalidos
        End Function

        Private Function ConsutlaRecurso(ByVal NombreObj As String) As String
            Dim Nombre As String = ""

            Dim rm As ResourceManager = New System.Resources.ResourceManager("clsValidarCampos.ValidarObjetos", [Assembly].GetExecutingAssembly())
            Nombre = rm.GetString(NombreObj)

            Return Nombre
        End Function

    End Class

End Namespace