Imports System.Data.SqlClient
Imports System.Windows.Forms
Public Class frmP_Resolucion_Comentarios
    Inherits System.Windows.Forms.Form
    Dim objconexion As New clsConexion.cIsConexion
    Dim cn As New SqlConnection
    Dim objComentarios As New clsComentarios.C_Comentarios("Principal", gUsuario, gPasswordSql)
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim iCaso As Integer
    Dim dvPNN As DataView
    Dim objComites As New clsComites.clsComites("Principal", gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim sTipoProceso As String
    Dim ruta As String
    Dim clsCopia As New ClsCopiaArchivos.ClsCopiaArchivos
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Dim nodo1 As New TreeNode
    Dim nodo As New TreeNode
    Dim nodo2 As New TreeNode
    Dim DtCom As DataTable
    Dim Com As DataRow
    Dim array_texto As Array

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tvPNN As System.Windows.Forms.TreeView
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtkFecPublicacionConsulta As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtTitulo As System.Windows.Forms.TextBox
    Friend WithEvents txtFecLimiteAnalisisComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecLimiteComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecPublicacionConsulta As System.Windows.Forms.TextBox
    Friend WithEvents lblFecPublicacionConsulta As System.Windows.Forms.Label
    Friend WithEvents lblFecLimiteComentarios As System.Windows.Forms.Label
    Friend WithEvents lblFecLimiteAnalisisComentarios As System.Windows.Forms.Label
    Friend WithEvents lblTitulo As System.Windows.Forms.Label
    Friend WithEvents dtkFecLimiteComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkFecLimiteAnalisisComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents gpbDatosPersonales As System.Windows.Forms.GroupBox
    Friend WithEvents gbpComentarios As System.Windows.Forms.GroupBox
    Friend WithEvents txtPropuestasCambios As System.Windows.Forms.TextBox
    Friend WithEvents txtComentario As System.Windows.Forms.TextBox
    Friend WithEvents txtParrafo As System.Windows.Forms.TextBox
    Friend WithEvents txtCapituloInciso As System.Windows.Forms.TextBox
    Friend WithEvents cboTipoComentario As System.Windows.Forms.ComboBox
    Friend WithEvents lblTipoComentario As System.Windows.Forms.Label
    Friend WithEvents lblCapituloInciso As System.Windows.Forms.Label
    Friend WithEvents lblParrafo As System.Windows.Forms.Label
    Friend WithEvents lblComentario As System.Windows.Forms.Label
    Friend WithEvents lblPropuestasCambios As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtDomicilio As System.Windows.Forms.TextBox
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents lblNombre As System.Windows.Forms.Label
    Friend WithEvents lblEmpresa As System.Windows.Forms.Label
    Friend WithEvents lblDomicilio As System.Windows.Forms.Label
    Friend WithEvents lblTelefono As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents lblSB As System.Windows.Forms.Label
    Friend WithEvents txtTema As System.Windows.Forms.TextBox
    Friend WithEvents txtPNN As System.Windows.Forms.TextBox
    Friend WithEvents gpbx As System.Windows.Forms.GroupBox
    Friend WithEvents lblFecUno As System.Windows.Forms.Label
    Friend WithEvents txtDocto As System.Windows.Forms.TextBox
    Friend WithEvents txtResolucion As System.Windows.Forms.TextBox
    Friend WithEvents lblResolucion As System.Windows.Forms.Label
    Friend WithEvents lblSubirDocto As System.Windows.Forms.Label
    Friend WithEvents txtFecha As System.Windows.Forms.TextBox
    Friend WithEvents dtkFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents chkSubirDocto As System.Windows.Forms.CheckBox
    Friend WithEvents grdDoctos As System.Windows.Forms.DataGrid
    Friend WithEvents txtID_Comentarios As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmP_Resolucion_Comentarios))
        Me.tvPNN = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dtkFecPublicacionConsulta = New System.Windows.Forms.DateTimePicker
        Me.txtTitulo = New System.Windows.Forms.TextBox
        Me.txtFecLimiteAnalisisComentarios = New System.Windows.Forms.TextBox
        Me.txtFecLimiteComentarios = New System.Windows.Forms.TextBox
        Me.txtFecPublicacionConsulta = New System.Windows.Forms.TextBox
        Me.lblFecPublicacionConsulta = New System.Windows.Forms.Label
        Me.lblFecLimiteComentarios = New System.Windows.Forms.Label
        Me.lblFecLimiteAnalisisComentarios = New System.Windows.Forms.Label
        Me.lblTitulo = New System.Windows.Forms.Label
        Me.dtkFecLimiteComentarios = New System.Windows.Forms.DateTimePicker
        Me.dtkFecLimiteAnalisisComentarios = New System.Windows.Forms.DateTimePicker
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.gpbDatosPersonales = New System.Windows.Forms.GroupBox
        Me.gbpComentarios = New System.Windows.Forms.GroupBox
        Me.txtPropuestasCambios = New System.Windows.Forms.TextBox
        Me.txtComentario = New System.Windows.Forms.TextBox
        Me.txtParrafo = New System.Windows.Forms.TextBox
        Me.txtCapituloInciso = New System.Windows.Forms.TextBox
        Me.cboTipoComentario = New System.Windows.Forms.ComboBox
        Me.lblTipoComentario = New System.Windows.Forms.Label
        Me.lblCapituloInciso = New System.Windows.Forms.Label
        Me.lblParrafo = New System.Windows.Forms.Label
        Me.lblComentario = New System.Windows.Forms.Label
        Me.lblPropuestasCambios = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtTelefono = New System.Windows.Forms.TextBox
        Me.txtDomicilio = New System.Windows.Forms.TextBox
        Me.txtEmpresa = New System.Windows.Forms.TextBox
        Me.txtNombre = New System.Windows.Forms.TextBox
        Me.lblNombre = New System.Windows.Forms.Label
        Me.lblEmpresa = New System.Windows.Forms.Label
        Me.lblDomicilio = New System.Windows.Forms.Label
        Me.lblTelefono = New System.Windows.Forms.Label
        Me.lblFax = New System.Windows.Forms.Label
        Me.lblEmail = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.txtResolucion = New System.Windows.Forms.TextBox
        Me.lblResolucion = New System.Windows.Forms.Label
        Me.gpbx = New System.Windows.Forms.GroupBox
        Me.grdDoctos = New System.Windows.Forms.DataGrid
        Me.chkSubirDocto = New System.Windows.Forms.CheckBox
        Me.txtDocto = New System.Windows.Forms.TextBox
        Me.lblSubirDocto = New System.Windows.Forms.Label
        Me.txtFecha = New System.Windows.Forms.TextBox
        Me.lblFecUno = New System.Windows.Forms.Label
        Me.dtkFecha = New System.Windows.Forms.DateTimePicker
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.lblSB = New System.Windows.Forms.Label
        Me.txtID_Comentarios = New System.Windows.Forms.TextBox
        Me.txtTema = New System.Windows.Forms.TextBox
        Me.txtPNN = New System.Windows.Forms.TextBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gpbDatosPersonales.SuspendLayout()
        Me.gbpComentarios.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.gpbx.SuspendLayout()
        CType(Me.grdDoctos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tvPNN
        '
        Me.tvPNN.ImageList = Me.imgListTreeView
        Me.tvPNN.Location = New System.Drawing.Point(6, 9)
        Me.tvPNN.Name = "tvPNN"
        Me.tvPNN.Size = New System.Drawing.Size(185, 341)
        Me.tvPNN.TabIndex = 54
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(200, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(584, 396)
        Me.TabControl1.TabIndex = 53
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(576, 370)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Proyecto                "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtkFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.txtTitulo)
        Me.GroupBox1.Controls.Add(Me.txtFecLimiteAnalisisComentarios)
        Me.GroupBox1.Controls.Add(Me.txtFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.txtFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.lblFecLimiteAnalisisComentarios)
        Me.GroupBox1.Controls.Add(Me.lblTitulo)
        Me.GroupBox1.Controls.Add(Me.dtkFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.dtkFecLimiteAnalisisComentarios)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(496, 271)
        Me.GroupBox1.TabIndex = 53
        Me.GroupBox1.TabStop = False
        '
        'dtkFecPublicacionConsulta
        '
        Me.dtkFecPublicacionConsulta.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecPublicacionConsulta.Location = New System.Drawing.Point(304, 32)
        Me.dtkFecPublicacionConsulta.Name = "dtkFecPublicacionConsulta"
        Me.dtkFecPublicacionConsulta.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecPublicacionConsulta.TabIndex = 31
        Me.dtkFecPublicacionConsulta.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecPublicacionConsulta.Visible = False
        '
        'txtTitulo
        '
        Me.txtTitulo.Location = New System.Drawing.Point(192, 152)
        Me.txtTitulo.Multiline = True
        Me.txtTitulo.Name = "txtTitulo"
        Me.txtTitulo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTitulo.Size = New System.Drawing.Size(294, 73)
        Me.txtTitulo.TabIndex = 28
        Me.txtTitulo.Text = "txtTitulo"
        '
        'txtFecLimiteAnalisisComentarios
        '
        Me.txtFecLimiteAnalisisComentarios.Location = New System.Drawing.Point(192, 112)
        Me.txtFecLimiteAnalisisComentarios.Name = "txtFecLimiteAnalisisComentarios"
        Me.txtFecLimiteAnalisisComentarios.TabIndex = 27
        Me.txtFecLimiteAnalisisComentarios.Text = "txtFecLimiteAnalisisComentarios"
        '
        'txtFecLimiteComentarios
        '
        Me.txtFecLimiteComentarios.Location = New System.Drawing.Point(192, 72)
        Me.txtFecLimiteComentarios.Name = "txtFecLimiteComentarios"
        Me.txtFecLimiteComentarios.TabIndex = 26
        Me.txtFecLimiteComentarios.Text = "txtFecLimiteComentarios"
        '
        'txtFecPublicacionConsulta
        '
        Me.txtFecPublicacionConsulta.Location = New System.Drawing.Point(192, 32)
        Me.txtFecPublicacionConsulta.Name = "txtFecPublicacionConsulta"
        Me.txtFecPublicacionConsulta.TabIndex = 25
        Me.txtFecPublicacionConsulta.Text = "FecPublicacionConsulta"
        '
        'lblFecPublicacionConsulta
        '
        Me.lblFecPublicacionConsulta.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecPublicacionConsulta.Location = New System.Drawing.Point(8, 24)
        Me.lblFecPublicacionConsulta.Name = "lblFecPublicacionConsulta"
        Me.lblFecPublicacionConsulta.Size = New System.Drawing.Size(174, 28)
        Me.lblFecPublicacionConsulta.TabIndex = 19
        Me.lblFecPublicacionConsulta.Text = "Fecha de Publicaci�n a periodo de Comentario P�blico"
        '
        'lblFecLimiteComentarios
        '
        Me.lblFecLimiteComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecLimiteComentarios.Location = New System.Drawing.Point(8, 72)
        Me.lblFecLimiteComentarios.Name = "lblFecLimiteComentarios"
        Me.lblFecLimiteComentarios.Size = New System.Drawing.Size(176, 19)
        Me.lblFecLimiteComentarios.TabIndex = 21
        Me.lblFecLimiteComentarios.Text = "Fecha L�mite para Comentarios"
        '
        'lblFecLimiteAnalisisComentarios
        '
        Me.lblFecLimiteAnalisisComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecLimiteAnalisisComentarios.Location = New System.Drawing.Point(8, 104)
        Me.lblFecLimiteAnalisisComentarios.Name = "lblFecLimiteAnalisisComentarios"
        Me.lblFecLimiteAnalisisComentarios.Size = New System.Drawing.Size(136, 26)
        Me.lblFecLimiteAnalisisComentarios.TabIndex = 23
        Me.lblFecLimiteAnalisisComentarios.Text = "Fecha L�mite a An�lisis Comentarios"
        '
        'lblTitulo
        '
        Me.lblTitulo.AutoSize = True
        Me.lblTitulo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitulo.Location = New System.Drawing.Point(8, 152)
        Me.lblTitulo.Name = "lblTitulo"
        Me.lblTitulo.Size = New System.Drawing.Size(35, 16)
        Me.lblTitulo.TabIndex = 22
        Me.lblTitulo.Text = "T�tulo"
        '
        'dtkFecLimiteComentarios
        '
        Me.dtkFecLimiteComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecLimiteComentarios.Location = New System.Drawing.Point(304, 72)
        Me.dtkFecLimiteComentarios.Name = "dtkFecLimiteComentarios"
        Me.dtkFecLimiteComentarios.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecLimiteComentarios.TabIndex = 31
        Me.dtkFecLimiteComentarios.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecLimiteComentarios.Visible = False
        '
        'dtkFecLimiteAnalisisComentarios
        '
        Me.dtkFecLimiteAnalisisComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecLimiteAnalisisComentarios.Location = New System.Drawing.Point(304, 112)
        Me.dtkFecLimiteAnalisisComentarios.Name = "dtkFecLimiteAnalisisComentarios"
        Me.dtkFecLimiteAnalisisComentarios.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecLimiteAnalisisComentarios.TabIndex = 31
        Me.dtkFecLimiteAnalisisComentarios.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecLimiteAnalisisComentarios.Visible = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.gpbDatosPersonales)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(576, 370)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos Personales/Comentarios"
        Me.TabPage2.Visible = False
        '
        'gpbDatosPersonales
        '
        Me.gpbDatosPersonales.Controls.Add(Me.gbpComentarios)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmail)
        Me.gpbDatosPersonales.Controls.Add(Me.txtFax)
        Me.gpbDatosPersonales.Controls.Add(Me.txtTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.txtDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.txtNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.lblDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.lblTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.lblFax)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmail)
        Me.gpbDatosPersonales.Location = New System.Drawing.Point(5, 4)
        Me.gpbDatosPersonales.Name = "gpbDatosPersonales"
        Me.gpbDatosPersonales.Size = New System.Drawing.Size(564, 362)
        Me.gpbDatosPersonales.TabIndex = 3
        Me.gpbDatosPersonales.TabStop = False
        '
        'gbpComentarios
        '
        Me.gbpComentarios.Controls.Add(Me.txtPropuestasCambios)
        Me.gbpComentarios.Controls.Add(Me.txtComentario)
        Me.gbpComentarios.Controls.Add(Me.txtParrafo)
        Me.gbpComentarios.Controls.Add(Me.txtCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.cboTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.lblParrafo)
        Me.gbpComentarios.Controls.Add(Me.lblComentario)
        Me.gbpComentarios.Controls.Add(Me.lblPropuestasCambios)
        Me.gbpComentarios.Location = New System.Drawing.Point(8, 144)
        Me.gbpComentarios.Name = "gbpComentarios"
        Me.gbpComentarios.Size = New System.Drawing.Size(440, 212)
        Me.gbpComentarios.TabIndex = 19
        Me.gbpComentarios.TabStop = False
        '
        'txtPropuestasCambios
        '
        Me.txtPropuestasCambios.Location = New System.Drawing.Point(160, 149)
        Me.txtPropuestasCambios.Multiline = True
        Me.txtPropuestasCambios.Name = "txtPropuestasCambios"
        Me.txtPropuestasCambios.Size = New System.Drawing.Size(272, 56)
        Me.txtPropuestasCambios.TabIndex = 60
        Me.txtPropuestasCambios.Text = "txtPropuestasCambios"
        '
        'txtComentario
        '
        Me.txtComentario.Location = New System.Drawing.Point(160, 94)
        Me.txtComentario.Multiline = True
        Me.txtComentario.Name = "txtComentario"
        Me.txtComentario.Size = New System.Drawing.Size(272, 48)
        Me.txtComentario.TabIndex = 59
        Me.txtComentario.Text = "txtComentario"
        '
        'txtParrafo
        '
        Me.txtParrafo.Location = New System.Drawing.Point(160, 66)
        Me.txtParrafo.Name = "txtParrafo"
        Me.txtParrafo.TabIndex = 58
        Me.txtParrafo.Text = "txtParrafo"
        '
        'txtCapituloInciso
        '
        Me.txtCapituloInciso.Location = New System.Drawing.Point(160, 42)
        Me.txtCapituloInciso.Name = "txtCapituloInciso"
        Me.txtCapituloInciso.TabIndex = 57
        Me.txtCapituloInciso.Text = "txtCapituloInciso"
        '
        'cboTipoComentario
        '
        Me.cboTipoComentario.Location = New System.Drawing.Point(160, 16)
        Me.cboTipoComentario.Name = "cboTipoComentario"
        Me.cboTipoComentario.Size = New System.Drawing.Size(260, 21)
        Me.cboTipoComentario.TabIndex = 56
        Me.cboTipoComentario.Text = "cboTipoComentario"
        '
        'lblTipoComentario
        '
        Me.lblTipoComentario.AutoSize = True
        Me.lblTipoComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipoComentario.Location = New System.Drawing.Point(16, 16)
        Me.lblTipoComentario.Name = "lblTipoComentario"
        Me.lblTipoComentario.Size = New System.Drawing.Size(94, 16)
        Me.lblTipoComentario.TabIndex = 52
        Me.lblTipoComentario.Text = "Tipo Comentario"
        '
        'lblCapituloInciso
        '
        Me.lblCapituloInciso.AutoSize = True
        Me.lblCapituloInciso.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCapituloInciso.Location = New System.Drawing.Point(16, 42)
        Me.lblCapituloInciso.Name = "lblCapituloInciso"
        Me.lblCapituloInciso.Size = New System.Drawing.Size(85, 16)
        Me.lblCapituloInciso.TabIndex = 51
        Me.lblCapituloInciso.Text = "Cap�tulo Inciso"
        '
        'lblParrafo
        '
        Me.lblParrafo.AutoSize = True
        Me.lblParrafo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParrafo.Location = New System.Drawing.Point(16, 66)
        Me.lblParrafo.Name = "lblParrafo"
        Me.lblParrafo.Size = New System.Drawing.Size(114, 16)
        Me.lblParrafo.TabIndex = 53
        Me.lblParrafo.Text = "P�rrafo/Tabla/Figura"
        '
        'lblComentario
        '
        Me.lblComentario.AutoSize = True
        Me.lblComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComentario.Location = New System.Drawing.Point(16, 94)
        Me.lblComentario.Name = "lblComentario"
        Me.lblComentario.Size = New System.Drawing.Size(67, 16)
        Me.lblComentario.TabIndex = 55
        Me.lblComentario.Text = "Comentario"
        '
        'lblPropuestasCambios
        '
        Me.lblPropuestasCambios.AutoSize = True
        Me.lblPropuestasCambios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPropuestasCambios.Location = New System.Drawing.Point(16, 149)
        Me.lblPropuestasCambios.Name = "lblPropuestasCambios"
        Me.lblPropuestasCambios.Size = New System.Drawing.Size(133, 16)
        Me.lblPropuestasCambios.TabIndex = 54
        Me.lblPropuestasCambios.Text = "Propuestas de Cambios"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(399, 73)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(160, 20)
        Me.txtEmail.TabIndex = 18
        Me.txtEmail.Text = "txtEmail"
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(399, 41)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(160, 20)
        Me.txtFax.TabIndex = 17
        Me.txtFax.Text = "txtFax"
        '
        'txtTelefono
        '
        Me.txtTelefono.Location = New System.Drawing.Point(399, 9)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(160, 20)
        Me.txtTelefono.TabIndex = 16
        Me.txtTelefono.Text = "txtTelefono"
        '
        'txtDomicilio
        '
        Me.txtDomicilio.Location = New System.Drawing.Point(71, 73)
        Me.txtDomicilio.Multiline = True
        Me.txtDomicilio.Name = "txtDomicilio"
        Me.txtDomicilio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDomicilio.Size = New System.Drawing.Size(264, 70)
        Me.txtDomicilio.TabIndex = 15
        Me.txtDomicilio.Text = "txtDomicilio"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Location = New System.Drawing.Point(71, 41)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(264, 20)
        Me.txtEmpresa.TabIndex = 14
        Me.txtEmpresa.Text = "txtEmpresa"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(71, 9)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(264, 20)
        Me.txtNombre.TabIndex = 13
        Me.txtNombre.Text = "txtNombre"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombre.Location = New System.Drawing.Point(16, 13)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(47, 16)
        Me.lblNombre.TabIndex = 12
        Me.lblNombre.Text = "Nombre"
        '
        'lblEmpresa
        '
        Me.lblEmpresa.AutoSize = True
        Me.lblEmpresa.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpresa.Location = New System.Drawing.Point(11, 42)
        Me.lblEmpresa.Name = "lblEmpresa"
        Me.lblEmpresa.Size = New System.Drawing.Size(52, 16)
        Me.lblEmpresa.TabIndex = 12
        Me.lblEmpresa.Text = "Empresa"
        '
        'lblDomicilio
        '
        Me.lblDomicilio.AutoSize = True
        Me.lblDomicilio.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDomicilio.Location = New System.Drawing.Point(11, 73)
        Me.lblDomicilio.Name = "lblDomicilio"
        Me.lblDomicilio.Size = New System.Drawing.Size(55, 16)
        Me.lblDomicilio.TabIndex = 12
        Me.lblDomicilio.Text = "Domicilio"
        '
        'lblTelefono
        '
        Me.lblTelefono.AutoSize = True
        Me.lblTelefono.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTelefono.Location = New System.Drawing.Point(343, 9)
        Me.lblTelefono.Name = "lblTelefono"
        Me.lblTelefono.Size = New System.Drawing.Size(51, 16)
        Me.lblTelefono.TabIndex = 12
        Me.lblTelefono.Text = "Tel�fono"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFax.Location = New System.Drawing.Point(367, 41)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(24, 16)
        Me.lblFax.TabIndex = 12
        Me.lblFax.Text = "Fax"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(359, 73)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(34, 16)
        Me.lblEmail.TabIndex = 12
        Me.lblEmail.Text = "Email"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.txtResolucion)
        Me.TabPage3.Controls.Add(Me.lblResolucion)
        Me.TabPage3.Controls.Add(Me.gpbx)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(576, 370)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Revisi�n de Comentarios   "
        '
        'txtResolucion
        '
        Me.txtResolucion.Location = New System.Drawing.Point(112, 12)
        Me.txtResolucion.Multiline = True
        Me.txtResolucion.Name = "txtResolucion"
        Me.txtResolucion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtResolucion.Size = New System.Drawing.Size(456, 70)
        Me.txtResolucion.TabIndex = 17
        Me.txtResolucion.Text = "txtResolucion"
        '
        'lblResolucion
        '
        Me.lblResolucion.AutoSize = True
        Me.lblResolucion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResolucion.Location = New System.Drawing.Point(16, 13)
        Me.lblResolucion.Name = "lblResolucion"
        Me.lblResolucion.Size = New System.Drawing.Size(65, 16)
        Me.lblResolucion.TabIndex = 16
        Me.lblResolucion.Text = "Resoluci�n"
        '
        'gpbx
        '
        Me.gpbx.Controls.Add(Me.grdDoctos)
        Me.gpbx.Controls.Add(Me.chkSubirDocto)
        Me.gpbx.Controls.Add(Me.txtDocto)
        Me.gpbx.Controls.Add(Me.lblSubirDocto)
        Me.gpbx.Controls.Add(Me.txtFecha)
        Me.gpbx.Controls.Add(Me.lblFecUno)
        Me.gpbx.Controls.Add(Me.dtkFecha)
        Me.gpbx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gpbx.Location = New System.Drawing.Point(8, 88)
        Me.gpbx.Name = "gpbx"
        Me.gpbx.Size = New System.Drawing.Size(560, 272)
        Me.gpbx.TabIndex = 2
        Me.gpbx.TabStop = False
        Me.gpbx.Text = "Documento"
        '
        'grdDoctos
        '
        Me.grdDoctos.DataMember = ""
        Me.grdDoctos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdDoctos.Location = New System.Drawing.Point(6, 57)
        Me.grdDoctos.Name = "grdDoctos"
        Me.grdDoctos.Size = New System.Drawing.Size(549, 208)
        Me.grdDoctos.TabIndex = 30
        '
        'chkSubirDocto
        '
        Me.chkSubirDocto.Location = New System.Drawing.Point(10, 20)
        Me.chkSubirDocto.Name = "chkSubirDocto"
        Me.chkSubirDocto.Size = New System.Drawing.Size(114, 24)
        Me.chkSubirDocto.TabIndex = 29
        Me.chkSubirDocto.Text = "Subir Documento"
        '
        'txtDocto
        '
        Me.txtDocto.Location = New System.Drawing.Point(488, 22)
        Me.txtDocto.Name = "txtDocto"
        Me.txtDocto.Size = New System.Drawing.Size(65, 20)
        Me.txtDocto.TabIndex = 28
        Me.txtDocto.Text = "txtDocto"
        '
        'lblSubirDocto
        '
        Me.lblSubirDocto.AutoSize = True
        Me.lblSubirDocto.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSubirDocto.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubirDocto.ForeColor = System.Drawing.Color.Blue
        Me.lblSubirDocto.Location = New System.Drawing.Point(344, 23)
        Me.lblSubirDocto.Name = "lblSubirDocto"
        Me.lblSubirDocto.Size = New System.Drawing.Size(127, 18)
        Me.lblSubirDocto.TabIndex = 27
        Me.lblSubirDocto.Text = "Adjuntar Documento"
        '
        'txtFecha
        '
        Me.txtFecha.Location = New System.Drawing.Point(211, 22)
        Me.txtFecha.Name = "txtFecha"
        Me.txtFecha.Size = New System.Drawing.Size(81, 20)
        Me.txtFecha.TabIndex = 23
        Me.txtFecha.Text = "txtFecha"
        '
        'lblFecUno
        '
        Me.lblFecUno.AutoSize = True
        Me.lblFecUno.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecUno.Location = New System.Drawing.Point(163, 24)
        Me.lblFecUno.Name = "lblFecUno"
        Me.lblFecUno.Size = New System.Drawing.Size(41, 16)
        Me.lblFecUno.TabIndex = 22
        Me.lblFecUno.Text = "Fecha:"
        '
        'dtkFecha
        '
        Me.dtkFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecha.Location = New System.Drawing.Point(211, 22)
        Me.dtkFecha.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkFecha.Name = "dtkFecha"
        Me.dtkFecha.Size = New System.Drawing.Size(100, 20)
        Me.dtkFecha.TabIndex = 26
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 408)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(792, 62)
        Me.tlbBotonera.TabIndex = 52
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'lblSB
        '
        Me.lblSB.Location = New System.Drawing.Point(16, 384)
        Me.lblSB.Name = "lblSB"
        Me.lblSB.Size = New System.Drawing.Size(167, 16)
        Me.lblSB.TabIndex = 61
        Me.lblSB.Visible = False
        '
        'txtID_Comentarios
        '
        Me.txtID_Comentarios.Location = New System.Drawing.Point(109, 360)
        Me.txtID_Comentarios.Name = "txtID_Comentarios"
        Me.txtID_Comentarios.Size = New System.Drawing.Size(48, 20)
        Me.txtID_Comentarios.TabIndex = 59
        Me.txtID_Comentarios.Text = ""
        Me.txtID_Comentarios.Visible = False
        '
        'txtTema
        '
        Me.txtTema.Location = New System.Drawing.Point(56, 360)
        Me.txtTema.Name = "txtTema"
        Me.txtTema.Size = New System.Drawing.Size(48, 20)
        Me.txtTema.TabIndex = 58
        Me.txtTema.Text = ""
        Me.txtTema.Visible = False
        '
        'txtPNN
        '
        Me.txtPNN.Location = New System.Drawing.Point(4, 360)
        Me.txtPNN.Name = "txtPNN"
        Me.txtPNN.Size = New System.Drawing.Size(46, 20)
        Me.txtPNN.TabIndex = 57
        Me.txtPNN.Text = ""
        Me.txtPNN.Visible = False
        '
        'frmP_Resolucion_Comentarios
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 470)
        Me.Controls.Add(Me.lblSB)
        Me.Controls.Add(Me.txtID_Comentarios)
        Me.Controls.Add(Me.txtTema)
        Me.Controls.Add(Me.txtPNN)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.tvPNN)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frmP_Resolucion_Comentarios"
        Me.Text = "Revisi�n de Comentarios"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.gpbDatosPersonales.ResumeLayout(False)
        Me.gbpComentarios.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.gpbx.ResumeLayout(False)
        CType(Me.grdDoctos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmP_Resolucion_Comentarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        Call inicializa()

        objComentarios.Bandera = 6 'cboComentario
        Call Carga_Combo(cboTipoComentario)

        Call llena_TreeView()
        Call Formato_Grid(grdDoctos) 'grdDoctos
    End Sub

    Sub Carga_Combo(ByVal cbo As Object)
        objComentarios.ListaCombo(cbo)
        If objComentarios Is Nothing Then
            cboTipoComentario.Items.Add("Lista vacia")
            Exit Sub
        End If
    End Sub

#Region " Inicializa"
    Sub inicializa()
        'Datos Personales
        Limpia_Campos(txtNombre, txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        'Proyecto
        Limpia_Campos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios, txtTitulo)
        'Comentarios
        Limpia_Campos(cboTipoComentario, txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios)
        'Revisi�n de Comentarios
        Limpia_Campos(txtID_Comentarios, txtResolucion, dtkFecha, txtFecha, txtDocto)

        Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
        Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios, txtTitulo)
        Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        cboTipoComentario.Enabled = False

        'Revisi�n de Comentarios
        Inactivos(txtID_Comentarios, txtResolucion, dtkFecha, txtFecha, txtDocto, lblSubirDocto)
        Inactivos(grdDoctos)
        chkSubirDocto.Checked = False
        chkSubirDocto.Enabled = False
    End Sub
#End Region

#Region " Botonera"
    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                tvPNN.Enabled = False
                sTipoProceso = "Agregar"
                Call Agregar()

            Case 2 'EDITAR
                tvPNN.Enabled = False
                sTipoProceso = "Editar"
                ''Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                ''Inactivos(cmdAgregar)
                '''Call Editar()

                If iCaso = 4 Then 'Editar Comentario

                    Activos(cmdDeshacer, cmdGuardar)
                    Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
                    Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                    Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                    Inactivos(cboTipoComentario)

                    'Revisi�n de Comentarios
                    Activos(txtResolucion)
                    'Activos(txtComentarios, txtResolucion, lblSubirDocto)
                    'Activos(grdDoctos)

                    chkSubirDocto.Enabled = True
                End If

            Case 3 'DESHACER
                Activos(tvPNN)
                Call Deshacer()
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                ', cmdAgregar, cmdEditar, cmdBorrar)

            Case 4 'GUARDAR
                '''Inactivos(cmdDeshacer, cmdGuardar, grdCanceladas)
                '''Activos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Call Guardar()

            Case 5 'BORRAR
                Call Borrar()

            Case 7 'SALIR
                Me.Close()
        End Select
    End Sub
#End Region

#Region " Llena TreeView"
    Private Sub llena_TreeView()
        oTablaPNN = x.ListaPNN("")
        tvPNN.BeginUpdate()
        nodo = tvPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = x.Temas_Resolucion_Proy(RegPNN("id_plan"))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                objComentarios.Bandera = 4
                objComentarios.Id_Plan = RegPNN("id_plan")
                objComentarios.Id_Tema = RegDPy("id_tema")
                DtCom = objComentarios.Buscar_PNN
                If DtCom.Rows.Count <> 0 Then
                    For Each Com In DtCom.Rows
                        'nodo2 = nodo1.Nodes.Add(Com("Id_Comentario"))
                        nodo2 = nodo1.Nodes.Add("COM" + Format$(Com("Id_Comentario"), "0000"))
                    Next
                End If
            Next
        Next
        tvPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvPNN.Sorted = True

    End Sub
#End Region

#Region " AfterSelect (Despues de selccionar un nodo)"
    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvPNN.AfterSelect

        lblSB.Text = e.Node.FullPath
        iCaso = 0
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        array_texto = Split(lblSB.Text, "\")
        Select Case array_texto.Length
            Case 1
                Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)


                Limpia_Campos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios)
                Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)

                objComentarios.Id_Tema = Nothing
                objComentarios.Id_Plan = Nothing
                objComentarios.Id_Comentario = Nothing
                objComentarios.Bandera = 7
                Call Llena_GridDocto(grdDoctos)
                grdDoctos.ReadOnly = True

                iCaso = 2
            Case 3
                txtPNN.Text = array_texto(1)
                Inactivos(cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
                Activos(cmdAgregar)
                objComentarios.Bandera = 4
                objComentarios.Id_Plan = array_texto(1)
                'objComentarios.Id_Comentario = CInt(Mid(array_texto(3), 4))
                objComentarios.Id_Tema = array_texto(2)
                objComentarios.Llena_Campos()

                txtFecPublicacionConsulta.Text = objComentarios.Fecha_inicio
                txtFecLimiteComentarios.Text = objComentarios.Fecha_Fin
                txtFecLimiteAnalisisComentarios.Text = objComentarios.Fecha_Fin

                Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                'txtTitulo.Text = objComentarios.

                objComentarios.Id_Tema = Nothing
                objComentarios.Id_Plan = Nothing
                objComentarios.Id_Comentario = Nothing
                objComentarios.Bandera = 7
                Call Llena_GridDocto(grdDoctos)
                grdDoctos.ReadOnly = True

                txtTema.Text = array_texto(2)
                iCaso = 3
            Case 4
                Inactivos(cmdAgregar, cmdDeshacer, cmdGuardar)
                Activos(cmdEditar, cmdBorrar)
                objComentarios.Bandera = 5
                objComentarios.Id_Plan = array_texto(1)
                objComentarios.Id_Tema = array_texto(2)
                objComentarios.Id_Comentario = CInt(Mid(array_texto(3), 4))
                objComentarios.Llena_Campos()

                txtFecPublicacionConsulta.Text = objComentarios.Fecha_inicio
                txtFecLimiteComentarios.Text = objComentarios.Fecha_Fin
                txtFecLimiteAnalisisComentarios.Text = objComentarios.Fecha_Fin

                txtCapituloInciso.Text = objComentarios.Capitulo_inciso
                txtParrafo.Text = objComentarios.Parrafotablafigura
                txtComentario.Text = objComentarios.Comentarios
                txtPropuestasCambios.Text = objComentarios.Propuesta_cambios
                txtNombre.Text = objComentarios.Nombre
                txtEmpresa.Text = objComentarios.Empresa
                txtDomicilio.Text = objComentarios.Domicilio_Empresa
                txtTelefono.Text = objComentarios.Telefono
                txtFax.Text = objComentarios.Fax
                txtEmail.Text = objComentarios.Email
                txtResolucion.Text = objComentarios.Resolucion

                'txtTitulo.Text = objComentarios.
                'txtComent.Text = objComentarios.Id_Comentario

                'txtID_Comentarios.Text = array_texto(3)
                'objComentarios.Bandera = 8 'cboComentario
                'objComentarios.Tipo_comentario = array_texto(3) 'cboComentario
                Call Carga_Combo(cboTipoComentario)
                cboTipoComentario.SelectedValue = objComentarios.Tipo_comentario

                iCaso = 4

                objComentarios.Id_tipo_doc = 5
                objComentarios.Bandera = 7
                Call Llena_GridDocto(grdDoctos)

            Case 4




        End Select

        'If lblSB.Text = "" Or lblSB.Text = "Selecciona un Plan" Then
        '    Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre, txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        '    Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
        '    Limpia_Campos(txtPNN)
        '    objComentarios.Id_Tema = Nothing
        '    objComentarios.Id_Plan = Nothing
        '    objComentarios.Id_Comentario = Nothing
        '    objComentarios.Bandera = 7
        '    Call Llena_GridDocto(grdDoctos)
        '    grdDoctos.ReadOnly = True

        '    iCaso = 1
        '    Exit Sub
        'End If
        'Activos(cmdBorrar)


        If array_texto.Length <= 1 Then 'PNN
            Limpia_Campos(txtPNN)
        Else
            
        End If

        If array_texto.Length <= 2 Then 'Temas
            txtTema.Text = ""
        Else
           
            'cmdBusca2.Dispose()
        End If

        If array_texto.Length <= 3 Then 'Comentarios
            txtID_Comentarios.Text = ""
        Else
           

        End If


        If array_texto.Length > 4 Then
            iCaso = 5
        End If

    End Sub
#End Region

#Region " AGREGAR"
    Private Sub Agregar()
        Inactivos(tvPNN, cmdBorrar)
        Dim sSqlAgregar As String

        If iCaso = 3 Then 'Agregar Comentario
            Activos(cmdDeshacer, cmdGuardar)
            'Activos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
            Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios)

            Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)

            cboTipoComentario.Enabled = True

            Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
            '''Activos(cmdDeshacer, cmdGuardar, txtSC, txtDescripcion, txtObjetivo)
            '''Activos(cboResponsable)
            '''Limpia_Campos(txtSC, txtDescripcion, txtObjetivo)
            '''Exit Sub
        End If

        If iCaso = 4 Then 'Editar Comentario
            Activos(cmdDeshacer, cmdGuardar)
            Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
            cboTipoComentario.Enabled = True
            '''Activos(cmdDeshacer, cmdGuardar, txtGT, txtDescripcion, txtObjetivo)
            '''Activos(cboResponsable)
            '''Limpia_Campos(txtGT, txtDescripcion, txtObjetivo)
            '''Exit Sub
        End If

        If iCaso <> 1 Or iCaso <> 2 Or iCaso <> 3 Or iCaso <> 4 Then
            '''MsgBox("Este es el ultimo nivel, no se pueden agregar m�s nodos")
            '''Activos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            ''''Inactivos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            ''''Activos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            ''''Inactivos(cboResponsable)
            '''Exit Sub
        End If
    End Sub
#End Region

#Region " EDITAR"

#End Region

#Region " DESHACER"
    Public Sub Deshacer()
        tvPNN.Nodes.Clear()
        Call llena_TreeView()
        Call inicializa()

        cboTipoComentario.Enabled = False
    End Sub

#End Region

#Region " GUARDAR"
    Dim iDetalle As Integer
    Private Sub Guardar()
        Dim sSqlAgregar As String

        If sTipoProceso = "Editar" Then '*****************IF*************AGREGAR

      

            If txtResolucion.Text = "" Then
                MsgBox("Falta la Resoluci�n al comentario", MsgBoxStyle.Information, "Resoluci�n de Comentarios")
                Exit Sub
            End If
            With objComentarios
                .Bandera = 3
                .Id_Plan = array_texto(1)
                .Id_Tema = array_texto(2)
                .Id_Comentario = CInt(Mid(array_texto(3), 4))
                .Fecha_Resolucion = txtFecha.Text
                .Resolucion = txtResolucion.Text
                .Actualizar()

                Dim dt As New DataTable
                Dim dr As DataRow
                Dim bInactivo As Boolean
                Dim accion As Boolean
                dt = grdDoctos.DataSource()
                If dt.Rows.Count <> 0 Then
                    Dim archivo As String
                    Dim indice As Integer
                    Dim nombre As String

                    For Each dr In dt.Rows
                        '*****************************************Copia los Doctos a la carpeta
                        .Bandera = 4
                        .Id_tipo_doc = 5
                        .Documento = txtDocto.Text
                        .Actualizar()
                        ruta = dr(3)
                        'clsCopia.CopiaArchivos_Noticias(dr(3), "c:\ance")
                        clsCopia.CopiaArchivos(dr(3), "\\ance-dc\Docs_ONN_WWW")

                        '****************************************Guarda Doctos en la tabla

                        .Id_tipo_doc = 5
                        If dr(4) = 1 Or dr(4) = True Then
                            .Activo = dr(4)
                            'If Mid(OpenFileDialog1.FileName, indice, 1) = "\" Then 
                            If Mid(dr(3), 1) = "\" Then
                                archivo = Mid(OpenFileDialog1.FileName, indice)
                                indice = 1
                            End If
                            ' txtDocto.Text
                            nombre = Mid(archivo, 2, Len(archivo))
                            .Documento = nombre

                            .Actualizar_Documentos()
                        End If
                    Next
                End If



            End With
            tvPNN.Nodes.Clear()
            Call inicializa()
            Call llena_TreeView()
            tvPNN.Enabled = True


            If iCaso = 5 Then
            End If

        End If
    End Sub
#End Region

#Region " BORRAR"
    Public Sub Borrar()
        If MsgBox("�Estas seguro que deseas eliminar este Comentario: " & txtPNN.Text & "/" & txtTema.Text & "/" & txtID_Comentarios.Text & " ", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
            objComentarios.Bandera = 5
            objComentarios.Id_Plan = txtPNN.Text
            objComentarios.Id_Tema = txtTema.Text
            objComentarios.Id_Comentario = txtID_Comentarios.Text
            objComentarios.Borrar()
            tvPNN.Nodes.Clear()
            Call llena_TreeView()
        Else
            Exit Sub
        End If
    End Sub
#End Region

#Region "  Subir documento"
    Private Sub lblSubirDocto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblSubirDocto.Click
        Dim archivo As String
        Dim indice As Integer
        'OpenFileDialog1.Filter = "Archivos PDF (*.pdf)|Archivos Word (*.doc)|Archivos Excel (*.xls)|Archivos Power Point (*.ppt)| Todos los archivos (*.*)|*.*"
        OpenFileDialog1.Filter = "Todos los archivos (*.*)|*.*"
        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.ShowDialog()
        ruta = OpenFileDialog1.FileName
        For indice = Len(OpenFileDialog1.FileName) To 1 Step -1
            If Mid(OpenFileDialog1.FileName, indice, 1) = "\" Then
                archivo = Mid(OpenFileDialog1.FileName, indice)
                indice = 1
            End If
        Next indice
        txtDocto.Text = Mid(archivo, 2, Len(archivo))

        If txtDocto.Text <> "" Then
            Dim dtAgrega As New DataTable
            Dim drAgrega As DataRow
            'Dim dvAgrega As DataView
            dtAgrega = grdDoctos.DataSource
            drAgrega = dtAgrega.NewRow
            drAgrega("id_plan") = txtPNN.Text
            drAgrega("id_tema") = txtTema.Text
            drAgrega("Id_tipo_doc") = 5
            drAgrega("Documento") = ruta   '+ txtDocto.Text
            drAgrega("Activo") = 1
            dtAgrega.Rows.Add(drAgrega)
            grdDoctos.DataSource = dtAgrega
            grdDoctos.Refresh()

            txtFecha.Text = Format(Now, "dd/MM/yyyy") 'este es aparte del grid
        End If
    End Sub
#End Region

#Region " Formato Grid "
    Sub Formato_Grid(ByVal grd As Object)
        Dim dgEstiloGrid As New DataGridTableStyle
        With dgEstiloGrid
            .AlternatingBackColor = Color.GhostWhite
            .BackColor = Color.GhostWhite
            .ForeColor = Color.MidnightBlue
            .GridLineColor = Color.RoyalBlue
            .HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .HeaderForeColor = Color.Lavender
            .SelectionBackColor = Color.Teal
            .SelectionForeColor = Color.PaleGreen
            .RowHeaderWidth = 15 'ajusta el tama�o de la columna de la izquierda que trae el grid
            .RowHeadersVisible = False
            .ColumnHeadersVisible = False
            .MappingName = "P_Prog_Trab_Documentos" 'el nombre que regresa el dataset
            '.ReadOnly = True
        End With

        Dim ColEstilo0 As New DataGridTextBoxColumn '
        Dim ColEstilo1 As New DataGridBoolColumn ' 
        Dim ColEstilo2 As New DataGridTextBoxColumn ' 
        Dim ColEstilo3 As New DataGridTextBoxColumn ' 
        Dim ColEstilo4 As New DataGridBoolColumn ' 
        Dim ColEstilo5 As New DataGridTextBoxColumn ' 

        With ColEstilo0 'PLAN
            .MappingName = "id_Plan"
            .HeaderText = "id_Plan"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEstilo1 'TEMA
            .MappingName = "id_Tema"
            .HeaderText = "id_Tema"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEstilo2 'ID_TIPO_DOC
            .MappingName = "id_tipo_doc"
            .HeaderText = "id_tipo_doc"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEstilo3 'DOCUMENTO
            .MappingName = "Documento"
            .HeaderText = "Documento"
            .Width = 450
            .ReadOnly = True 'este se muestra en el grid
        End With

        With ColEstilo4 'ACTIVO
            .MappingName = "Activo"
            .HeaderText = "Activo"
            .Width = 70
            .FalseValue = False
            .NullValue = False
            .TrueValue = True
            '.ReadOnly = True 'este se muestra en el grid
        End With

        With ColEstilo5 'DOCUMENTO
            .MappingName = "ID_Cometario"
            .HeaderText = "ID_Cometario"
            .Width = 0
            .ReadOnly = True 'este se muestra en el grid
        End With

        dgEstiloGrid.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEstilo0, ColEstilo1, ColEstilo2, ColEstilo3, ColEstilo4, ColEstilo5})
        grd.TableStyles.Add(dgEstiloGrid)
    End Sub
#End Region

#Region "  Llena Grid"
    Sub Llena_GridDocto(ByVal grd As Object)
        If objComentarios.ListaGridDoctos Is Nothing Then
            Exit Sub
        End If
        grd.DataSource = objComentarios.ListaGridDoctos
        grd.readonly = False
    End Sub
#End Region

    Private Sub dtkFecPublicacionConsulta_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecPublicacionConsulta.ValueChanged
        txtFecPublicacionConsulta.Text = dtkFecPublicacionConsulta.Value
    End Sub

    Private Sub dtkFecLimiteComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecLimiteComentarios.ValueChanged
        txtFecLimiteComentarios.Text = dtkFecLimiteComentarios.Value
    End Sub

    Private Sub dtkFecLimiteAnalisisComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecLimiteAnalisisComentarios.ValueChanged
        txtFecLimiteAnalisisComentarios.Text = dtkFecLimiteAnalisisComentarios.Value
    End Sub

    Private Sub tvPNN_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles tvPNN.BeforeExpand
        tvPNN.SelectedImageIndex = 1
    End Sub

#Region "  chk SUBIR DOCUMENTO"""
    Private Sub chkSubirDocto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSubirDocto.CheckedChanged
        If sTipoProceso = "Agregar" Then
            ''If chkAdoptada.Checked = True Then
            ''    Activos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada) ', grdAdoptada)
            ''    grdAdoptada.ReadOnly = False
            ''ElseIf chkAdoptada.Checked = False Then
            ''    Inactivos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada, grdAdoptada)
            ''    grdAdoptada.ReadOnly = True
            ''    Dim dtLimpia As DataTable
            ''    dtLimpia = grdAdoptada.DataSource
            ''    dtLimpia.Rows.Clear()
            ''End If
        ElseIf sTipoProceso = "Editar" Then
            If chkSubirDocto.Checked = True Then
                objComentarios.Id_Tema = Nothing
                objComentarios.Id_Plan = Nothing
                objComentarios.Id_Comentario = Nothing
                objComentarios.Bandera = 7
                'Call Formato_Grid(grdDoctos)
                Call Llena_GridDocto(grdDoctos)
                Inactivos(lblSubirDocto)
                'Inactivos(grdAdoptada)
                grdDoctos.ReadOnly = True
                Activos(lblSubirDocto)
                Activos(grdDoctos)

            ElseIf chkSubirDocto.Checked = False Then
                objComentarios.Id_Tema = txtTema.Text
                objComentarios.Id_Plan = txtPNN.Text
                objComentarios.Id_Comentario = txtID_Comentarios.Text    'CInt(txtComentario.Text)
                objComentarios.Id_tipo_doc = 5
                objComentarios.Bandera = 7
                'Call Formato_Grid(grdDoctos)
                Call Llena_GridDocto(grdDoctos)
                grdDoctos.ReadOnly = False

            End If
        End If
    End Sub
#End Region

End Class
