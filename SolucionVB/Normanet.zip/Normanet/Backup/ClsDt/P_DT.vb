
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_DT Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 20/09/2006 09:46:44 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient



Public Class P_DT

     '''''''Declaracion de Variables Privadas
     Private dsP_DT AS New DataSet
     Private _Id_Plan as System.String
     Private _Id_Tema as System.Int32
     Private _Titulo as System.String
     Private _F_Ini_NMX as System.DateTime
     Private _F_Rev_Cruzada as System.DateTime
     Private _Act_Aprob as System.String
     Private _Clasificacion as System.String
    Private _Responsable As System.String
    Private _Encontrado As Boolean
    Private _Bandera As Boolean
    Private _sReferencia As String

    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _status As Integer
    Private _Tipo As String
    Private _Bandera2 As Integer
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Plan() As System.String
          Get
              Return _Id_Plan
          End Get
          Set(Value as System.String)
              _Id_Plan = Value
          End Set
     End Property

     Public Property Id_Tema() As System.Int32
          Get
              Return _Id_Tema
          End Get
          Set(Value as System.Int32)
              _Id_Tema = Value
          End Set
     End Property

     Public Property Titulo() As System.String
          Get
              Return _Titulo
          End Get
          Set(Value as System.String)
              _Titulo = Value
          End Set
     End Property

     Public Property F_Ini_NMX() As System.DateTime
          Get
              Return _F_Ini_NMX
          End Get
          Set(Value as System.DateTime)
              _F_Ini_NMX = Value
          End Set
     End Property

     Public Property F_Rev_Cruzada() As System.DateTime
          Get
              Return _F_Rev_Cruzada
          End Get
          Set(Value as System.DateTime)
              _F_Rev_Cruzada = Value
          End Set
     End Property

    'Public Property Act_Aprob() As System.String
    '     Get
    '         Return _Act_Aprob
    '     End Get
    '     Set(Value as System.String)
    '         _Act_Aprob = Value
    '     End Set
    'End Property

     Public Property Clasificacion() As System.String
          Get
              Return _Clasificacion
          End Get
          Set(Value as System.String)
              _Clasificacion = Value
          End Set
     End Property

     Public Property Responsable() As System.String
          Get
              Return _Responsable
          End Get
          Set(Value as System.String)
              _Responsable = Value
          End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Bandera() As Boolean
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Boolean)
            _Bandera = Value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Status() As Integer
        Get
            Return _status
        End Get
        Set(ByVal Value As Integer)
            _status = Value
        End Set
    End Property

    Public Property bandera2() As Integer
        Get
            Return _Bandera2
        End Get
        Set(ByVal Value As Integer)
            _Bandera2 = Value
        End Set
    End Property

    Public Property Tipo() As String
        Get
            Return _Tipo
        End Get
        Set(ByVal Value As String)
            _Tipo = Value
        End Set
    End Property

    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_DT")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sTema As String, ByVal sPlan As String, ByVal sRef As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_DT WHERE id_tema='" & sTema & "' and id_plan='" & sPlan & "' and Status <> 10 and Status <> 11 and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & sRef & "'"

        If _Tipo = "abandono" Then sSql = sSql + "Order by ref_regreso desc"
        If _Tipo = "traspaso" Then sSql = sSql + "Order by ref_regreso desc"

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da.Fill(dsP_DT, "C_Encontrado")
        cn.Close()
        If dsP_DT.Tables("C_Encontrado").Rows.Count > 0 Then

            _Ref_A�o = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_A�o"))
            _Ref_Comite = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
            _Ref_Consecutivo = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
            _Ref_Regreso = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
            _Ref_Traspaso = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))
            _status = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Status")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Status"))

            _Id_Plan = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Id_Plan")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Id_Plan"))
            _Id_Tema = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Id_Tema")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Id_Tema"))
            _Titulo = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Titulo")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Titulo"))
            '  _Act_Aprob = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Act_Aprob")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Act_Aprob"))
            _Clasificacion = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Clasificacion")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Clasificacion"))
            _Responsable = IIf(IsDBNull(dsP_DT.Tables("C_Encontrado").Rows(0).Item("Responsable")) = True, "", dsP_DT.Tables("C_Encontrado").Rows(0).Item("Responsable"))
            _Encontrado = True
        Else
            _Id_Plan = ""
            _Id_Tema = 0
            _Titulo = ""
            _Act_Aprob = ""
            _Clasificacion = ""
            _Responsable = ""
            _Encontrado = False
        End If
        dsP_DT.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza(ByVal Id_tema As Integer, ByVal id_plan As String, ByVal titulo As String, ByVal clasificacion As String, ByVal responsable As String, ByVal bandera As Integer, ByVal id_etapa As Integer) As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Dt"

        cmd.Parameters.Add("@Id_Plan", id_plan)
        cmd.Parameters.Add("@Id_Tema", Id_tema)
        cmd.Parameters.Add("@Titulo", titulo)
        'cmd.Parameters.Add("@Act_Aprob", act_aprob)
        cmd.Parameters.Add("@Clasificacion", clasificacion)
        cmd.Parameters.Add("@Responsable", responsable)
        cmd.Parameters.Add("@Bandera", bandera)
        'cmd.Parameters.Add("@ID_etapa", id_etapa)

        cmd.Parameters.Add("@Ref_A�o", _Ref_A�o)
        cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
        cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Status", 1)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function Insertar() As String

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_DT"
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn

        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Clasificacion", _Clasificacion)
        cmd.Parameters.Add("@Titulo", _Titulo)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@Bandera", _Bandera2)
        cmd.Parameters.Add("@Status", _status)
        cmd.Parameters.Add("@sReferencia", _sReferencia)

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Sub ActualizaRefAnterior(ByVal bande As Integer)
        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "Sp_Dt"
            .CommandType = CommandType.StoredProcedure

            .Parameters.Add("@bandera", bande)
            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@sReferencia", _sReferencia)
            If cn.State = 1 Then cn.Close()
            cn.Open()
            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Dim ms
                ms = ex.Message
            End Try
        End With
    End Sub
    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_DT"
        cmd.Parameters.Add("@Bandera", 5)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Sub traspasaDT(ByVal plan As String, ByVal tema As Integer)
        _status = 1
        _Id_Plan = plan
        _Id_Tema = tema
        _Bandera2 = 6
        _Ref_Traspaso = _Ref_Traspaso + 1
        Insertar()
    End Sub
End Class
