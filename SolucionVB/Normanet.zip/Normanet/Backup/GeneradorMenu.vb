Imports System.Configuration
Imports System.Xml
Imports System.IO
Imports System.Text

Public Class GeneradorMenu
    Inherits System.Windows.Forms.Form

    Private _IdItem As Integer

    Private Property IdItem() As Integer
        Get
            Return _IdItem
        End Get
        Set(ByVal Value As Integer)
            _IdItem = Value
        End Set
    End Property

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lstImagenes As System.Windows.Forms.ImageList
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton16 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton25 As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbMenus As System.Windows.Forms.ToolBar
    Friend WithEvents cboLiga As System.Windows.Forms.ComboBox
    Friend WithEvents trvMenu As System.Windows.Forms.TreeView
    Friend WithEvents optTipoExternas As System.Windows.Forms.RadioButton
    Friend WithEvents optTipoCreadas As System.Windows.Forms.RadioButton
    Friend WithEvents grpLigas As System.Windows.Forms.GroupBox
    Friend WithEvents txtNombreMenu As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboTiposMenus As System.Windows.Forms.ComboBox
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents lblLiga As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(GeneradorMenu))
        Me.trvMenu = New System.Windows.Forms.TreeView
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lstImagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbMenus = New System.Windows.Forms.ToolBar
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton16 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton25 = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.txtNombreMenu = New System.Windows.Forms.TextBox
        Me.cboLiga = New System.Windows.Forms.ComboBox
        Me.grpLigas = New System.Windows.Forms.GroupBox
        Me.optTipoExternas = New System.Windows.Forms.RadioButton
        Me.optTipoCreadas = New System.Windows.Forms.RadioButton
        Me.lblLiga = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.cboTiposMenus = New System.Windows.Forms.ComboBox
        Me.grpLigas.SuspendLayout()
        Me.SuspendLayout()
        '
        'trvMenu
        '
        Me.trvMenu.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.trvMenu.ImageIndex = -1
        Me.trvMenu.Location = New System.Drawing.Point(8, 184)
        Me.trvMenu.Name = "trvMenu"
        Me.trvMenu.SelectedImageIndex = -1
        Me.trvMenu.Size = New System.Drawing.Size(672, 256)
        Me.trvMenu.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(32, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Nombre del menu:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(96, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 23)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Liga:"
        '
        'lstImagenes
        '
        Me.lstImagenes.ImageSize = New System.Drawing.Size(20, 20)
        Me.lstImagenes.ImageStream = CType(resources.GetObject("lstImagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.lstImagenes.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbMenus
        '
        Me.tlbMenus.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton16, Me.ToolBarButton25, Me.cmdEditar})
        Me.tlbMenus.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tlbMenus.DropDownArrows = True
        Me.tlbMenus.ImageList = Me.lstImagenes
        Me.tlbMenus.Location = New System.Drawing.Point(0, 0)
        Me.tlbMenus.Name = "tlbMenus"
        Me.tlbMenus.ShowToolTips = True
        Me.tlbMenus.Size = New System.Drawing.Size(688, 32)
        Me.tlbMenus.TabIndex = 7
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 6
        Me.ToolBarButton5.ToolTipText = "Nuevo"
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 3
        Me.ToolBarButton6.ToolTipText = "Guardar"
        '
        'ToolBarButton16
        '
        Me.ToolBarButton16.ImageIndex = 1
        Me.ToolBarButton16.ToolTipText = "Eliminar"
        '
        'ToolBarButton25
        '
        Me.ToolBarButton25.ImageIndex = 10
        Me.ToolBarButton25.ToolTipText = "Deshacer"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 0
        Me.cmdEditar.Text = "Editar"
        Me.cmdEditar.ToolTipText = "Editar"
        '
        'txtNombreMenu
        '
        Me.txtNombreMenu.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNombreMenu.Location = New System.Drawing.Point(128, 64)
        Me.txtNombreMenu.Name = "txtNombreMenu"
        Me.txtNombreMenu.Size = New System.Drawing.Size(552, 20)
        Me.txtNombreMenu.TabIndex = 8
        Me.txtNombreMenu.Text = ""
        '
        'cboLiga
        '
        Me.cboLiga.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboLiga.Location = New System.Drawing.Point(128, 88)
        Me.cboLiga.Name = "cboLiga"
        Me.cboLiga.Size = New System.Drawing.Size(552, 21)
        Me.cboLiga.TabIndex = 9
        '
        'grpLigas
        '
        Me.grpLigas.Controls.Add(Me.optTipoExternas)
        Me.grpLigas.Controls.Add(Me.optTipoCreadas)
        Me.grpLigas.Location = New System.Drawing.Point(128, 112)
        Me.grpLigas.Name = "grpLigas"
        Me.grpLigas.Size = New System.Drawing.Size(256, 48)
        Me.grpLigas.TabIndex = 10
        Me.grpLigas.TabStop = False
        Me.grpLigas.Text = "Tipo de Liga"
        '
        'optTipoExternas
        '
        Me.optTipoExternas.Checked = True
        Me.optTipoExternas.Location = New System.Drawing.Point(136, 16)
        Me.optTipoExternas.Name = "optTipoExternas"
        Me.optTipoExternas.Size = New System.Drawing.Size(112, 24)
        Me.optTipoExternas.TabIndex = 1
        Me.optTipoExternas.TabStop = True
        Me.optTipoExternas.Text = "Paginas Externas"
        '
        'optTipoCreadas
        '
        Me.optTipoCreadas.Location = New System.Drawing.Point(8, 16)
        Me.optTipoCreadas.Name = "optTipoCreadas"
        Me.optTipoCreadas.Size = New System.Drawing.Size(112, 24)
        Me.optTipoCreadas.TabIndex = 0
        Me.optTipoCreadas.Text = "Paginas creadas"
        '
        'lblLiga
        '
        Me.lblLiga.AutoSize = True
        Me.lblLiga.Location = New System.Drawing.Point(32, 160)
        Me.lblLiga.Name = "lblLiga"
        Me.lblLiga.Size = New System.Drawing.Size(38, 16)
        Me.lblLiga.TabIndex = 12
        Me.lblLiga.Text = "Label3"
        Me.lblLiga.Visible = False
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 23)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Seleccion de men�:"
        '
        'cboTiposMenus
        '
        Me.cboTiposMenus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboTiposMenus.Items.AddRange(New Object() {"Acerca de Normalizaci�n", "Normalizaci�n en linea"})
        Me.cboTiposMenus.Location = New System.Drawing.Point(128, 40)
        Me.cboTiposMenus.Name = "cboTiposMenus"
        Me.cboTiposMenus.Size = New System.Drawing.Size(240, 21)
        Me.cboTiposMenus.TabIndex = 14
        '
        'GeneradorMenu
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(688, 450)
        Me.Controls.Add(Me.cboTiposMenus)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblLiga)
        Me.Controls.Add(Me.grpLigas)
        Me.Controls.Add(Me.cboLiga)
        Me.Controls.Add(Me.txtNombreMenu)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.trvMenu)
        Me.Controls.Add(Me.tlbMenus)
        Me.Name = "GeneradorMenu"
        Me.Text = "GeneradorMenu"
        Me.grpLigas.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub GeneradorMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LlenarTiposPaginas()
        BotonesDeInicio()

        CrearXml(cboTiposMenus.SelectedValue)
        LlenarArbol()
    End Sub

    Private Sub LlenarTiposPaginas()
        Dim objTiposPaginas As New clsMenusWeb.Maple.clsTiposMenusWeb
        Try
            objTiposPaginas.Bandera = "s4"
            cboTiposMenus.DataSource = objTiposPaginas.Listar
            cboTiposMenus.DisplayMember = "Descripcion"
            cboTiposMenus.ValueMember = "Id"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objTiposPaginas = Nothing
        End Try
    End Sub

    Private Sub BotonesDeInicio()
        optTipoExternas.Checked = True

        Activar(tlbMenus.Buttons.Item(0), tlbMenus.Buttons.Item(2), trvMenu, tlbMenus.Buttons.Item(4), cboTiposMenus)
        inactivar(tlbMenus.Buttons.Item(1), tlbMenus.Buttons.Item(3))
        inactivar(grpLigas, cboLiga)
        Limpiar(txtNombreMenu, cboLiga)
        Lectura(txtNombreMenu)
        IdItem = 0
    End Sub

    Private Sub ArmarArbol(ByVal xmlNodo As XmlNode, ByVal tvNodo As TreeNode)

        Dim xNode As XmlNode
        Dim tNode As TreeNode
        Dim nodeList As XmlNodeList
        Dim i As Integer

        tvNodo.ImageIndex = 0

        If xmlNodo.HasChildNodes Then
            nodeList = xmlNodo.ChildNodes
            For i = 0 To nodeList.Count - 1
                xNode = xmlNodo.ChildNodes(i)

                Dim nodoAux As New TreeNode
                nodoAux.Text = xNode.Attributes("text").Value
                nodoAux.ImageIndex = 0
                nodoAux.Tag = xNode.Attributes("id").Value

                tvNodo.Nodes.Add(nodoAux)
                tNode = tvNodo.Nodes(i)
                ArmarArbol(xNode, tNode)
            Next
        Else
            tvNodo.Text = xmlNodo.Attributes("text").Value
        End If
    End Sub

    Private Sub BotonesDeNuevo()

            IdItem = trvMenu.SelectedNode.Tag


        inactivar(tlbMenus.Buttons.Item(0), tlbMenus.Buttons.Item(2), tlbMenus.Buttons.Item(4), cboTiposMenus)
        Activar(tlbMenus.Buttons.Item(1), tlbMenus.Buttons.Item(3))
        inactivar(trvMenu)

        Activar(grpLigas)
        Limpiar(txtNombreMenu, cboLiga)
        Escritura(txtNombreMenu)
        Activar(cboLiga)
        cboLiga.DropDownStyle = ComboBoxStyle.Simple
        lblLiga.Text = ""
    End Sub

    Private Sub BotonesEditar()
        IdItem = trvMenu.SelectedNode.Tag

        inactivar(tlbMenus.Buttons.Item(0), tlbMenus.Buttons.Item(2), tlbMenus.Buttons.Item(4), cboTiposMenus)
        Activar(tlbMenus.Buttons.Item(1), tlbMenus.Buttons.Item(3))
        inactivar(trvMenu)

        Activar(grpLigas)
        Escritura(txtNombreMenu)
        Activar(cboLiga)
        cboLiga.DropDownStyle = ComboBoxStyle.Simple
    End Sub

    Private Sub tlbMenus_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbMenus.ButtonClick
        Select Case tlbMenus.Buttons.IndexOf(e.Button)
            Case 0 REM Nuevo
                BotonesDeNuevo()
            Case 1 REM guardar
                If MsgBox("�Estas seguro de guardar los cambios?", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    If lblLiga.Text = "" Then
                        Insertar()
                    Else
                        Actualizar()
                    End If
                    BotonesDeInicio()
                    CrearXml(cboTiposMenus.SelectedValue)
                    LlenarArbol()
                End If
            Case 2 REM eliminar
                If MsgBox("Estas seguro de eliminar la liga", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    Eliminar()
                    BotonesDeInicio()
                    CrearXml(cboTiposMenus.SelectedValue)
                    LlenarArbol()
                End If
            Case 3 REM deshacer
                BotonesDeInicio()
            Case 4 REM editar
                BotonesEditar()
        End Select
    End Sub

    Private Sub trvMenu_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles trvMenu.BeforeSelect
        Dim Id As String
        Dim Nodo As TreeNode = e.Node

        Id = Nodo.Tag

        If Id <> "" Then
            BuscarDatos(Id)
        End If
    End Sub

    Private Sub BuscarDatos(ByVal id As Integer)
        Dim objMenusWeb As New clsMenusWeb.Maple.clsMenusWeb
        Try
            objMenusWeb.Bandera = "s1"
            objMenusWeb.Id = id
            objMenusWeb.LlenarDatos()

            cboTiposMenus.SelectedValue = objMenusWeb.Id_MenuWeb
            txtNombreMenu.Text = objMenusWeb.Titulo


            If objMenusWeb.url Like "Gestor.aspx?IdPagina=*" Then
                cboLiga.Text = buscarPagina(objMenusWeb.url)
                lblLiga.Text = cboLiga.Text
                REM ElseIf objMenusWeb.url Like "*.asp*" Then
            Else
                cboLiga.Text = IIf(objMenusWeb.url = "#", "", objMenusWeb.url)
                lblLiga.Text = " "
            End If


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objMenusWeb = Nothing
        End Try

    End Sub

    Private Function buscarPagina(ByVal Pagina As String) As String
        Dim objPagina As New clsPAginas.Maple.clsPaginas
        Try
            objPagina.Bandera = "s3"
            objPagina.Activo = True
            objPagina.Terminada = True
            objPagina.Id_Pagina = Pagina.Substring(Pagina.Length - 1, 1)
            objPagina.LlenarDatos()
            buscarPagina = objPagina.Nombre
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPagina = Nothing
        End Try
        Return buscarPagina
    End Function

    Private Sub optTipoExternas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTipoExternas.CheckedChanged
        Limpiar(cboLiga)
        cboLiga.DataSource = Nothing
        If optTipoExternas.Checked Then
            cboLiga.DropDownStyle = ComboBoxStyle.Simple
        Else
            cboLiga.DropDownStyle = ComboBoxStyle.DropDownList
        End If
    End Sub

    Private Sub optTipoCreadas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTipoCreadas.CheckedChanged
        Limpiar(cboLiga)
        If optTipoCreadas.Checked Then
            LlenarPaginas()
        End If
    End Sub

    Private Sub LlenarPaginas()
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            objPaginas.Bandera = "s4"
            objPaginas.Terminada = True
            objPaginas.Activo = True

            cboLiga.DataSource = objPaginas.Listar
            cboLiga.ValueMember = "Id_Pagina"
            cboLiga.DisplayMember = "Nombre"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try
    End Sub

    Private Function RutaXML() As String
        Dim sRutaxml As String

        If cboTiposMenus.SelectedValue = 2 Then
            sRutaxml = ConfigurationSettings.AppSettings.Get("MenuAcercaDe")
        Else
            sRutaxml = ConfigurationSettings.AppSettings.Get("MenuOnLine")
        End If

        Return sRutaxml
    End Function

    Private Sub cboTiposMenus_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTiposMenus.SelectionChangeCommitted
        CrearXml(cboTiposMenus.SelectedValue)
        LlenarArbol()

        trvMenu.Focus()
    End Sub

    Private Sub CrearXml(ByVal IdMenu As Integer)
        Dim dt As DataTable
        Dim tabulacion As String = "            "
        Dim xml As New StringBuilder
        Dim archivo As StreamWriter

        REM Listar principales
        Dim objMenus As New clsMenusWeb.Maple.clsMenusWeb
        objMenus.Bandera = "s2"
        objMenus.Id_MenuWeb = IdMenu
        objMenus.Id_Secundario = 0

        xml.Append("<?xml version='1.0'?>" & vbCrLf)
        xml.Append("   <Menu type='horizontal classic pro v 2.0'>" & vbCrLf)
        xml.Append("      <Menu_structure>" & vbCrLf)
        xml.Append("         <Item>" & vbCrLf)

        Try
            dt = objMenus.Listar
            For Each item As DataRow In dt.Rows
                xml.Append(CrearEstructura(item("Id"), tabulacion))
            Next

            xml.Append("         </Item>" & vbCrLf)
            xml.Append("      </Menu_structure>" & vbCrLf)
            xml.Append("   </Menu>")

            archivo = New StreamWriter(RutaXML)
            archivo.WriteLine(xml.ToString)
            archivo.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            archivo = Nothing
            dt = Nothing
            objMenus = Nothing
        End Try

    End Sub

    Private Function CrearEstructura(ByVal Id As Integer, ByVal tabulacion As String) As String
        Dim dt As DataTable
        Dim xmlEstructura As New StringBuilder

        REM sacar los hijos de ID
        Dim objMenusEstructura As New clsMenusWeb.Maple.clsMenusWeb
        objMenusEstructura.Bandera = "s3"
        objMenusEstructura.Pertenece_Al_Id = Id
        Try
            dt = objMenusEstructura.Listar

            REM si filas es mayor a 0 entonces tiene hijos
            If dt.Rows.Count > 0 Then
                REM nodo Padre
                xmlEstructura.Append(tabulacion & ConcatenarDatos(Id, True))
                For Each Items As DataRow In dt.Rows
                    REM Nodos hijos
                    xmlEstructura.Append(CrearEstructura(Items("Id"), tabulacion & "   "))
                Next
                xmlEstructura.Append(tabulacion & "</Item>" & vbCrLf)
            Else
                REM es un item cerrado
                xmlEstructura.Append(tabulacion & ConcatenarDatos(Id, False))
            End If

        Catch ex As Exception

        Finally
            dt = Nothing
            objMenusEstructura = Nothing
        End Try

        Return xmlEstructura.ToString
    End Function

    Private Function ConcatenarDatos(ByVal id As Integer, ByVal asChilds As Boolean) As String
        Dim dt As DataTable
        Dim Item As String = ""
        Dim objMenusEstructura As New clsMenusWeb.Maple.clsMenusWeb
        objMenusEstructura.Bandera = "s1"
        objMenusEstructura.Id = id

        dt = objMenusEstructura.Listar

        If dt.Rows.Count > 0 Then
            If asChilds = True Then
                Item = "<Item Id='" & dt.Rows(0).Item("Id") & "' Text='" & dt.Rows(0).Item("Titulo") & "' Url='" & dt.Rows(0).Item("url") & "' >" & vbCrLf
            Else
                Item = "<Item Id='" & dt.Rows(0).Item("Id") & "' Text='" & dt.Rows(0).Item("Titulo") & "' Url='" & dt.Rows(0).Item("url") & "' />" & vbCrLf
            End If
        End If

        dt = Nothing
        objMenusEstructura = Nothing

        Return Item
    End Function

    Private Sub LlenarArbol()
        Try

            Dim docXML As New XmlDocument
            docXML.Load(RutaXML)

            trvMenu.Nodes.Clear()

            Dim nodoRaiz As New TreeNode
            nodoRaiz.Text = docXML.DocumentElement.Name
            nodoRaiz.Tag = Nothing

            trvMenu.Nodes.Add(nodoRaiz)
            nodoRaiz = Nothing

            Dim tNode As New TreeNode
            tNode = trvMenu.Nodes(0)

            AddNode(docXML.DocumentElement.SelectSingleNode("//Menu_structure/Item"), tNode)
            trvMenu.ExpandAll()

        Catch xmlEx As XmlException
            MessageBox.Show(xmlEx.Message)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub AddNode(ByRef inXmlNode As XmlNode, ByRef inTreeNode As TreeNode)
        Dim xNode As XmlNode
        Dim tNode As TreeNode
        Dim nodeList As XmlNodeList
        Dim i As Integer

        If inXmlNode.HasChildNodes() Then
            nodeList = inXmlNode.ChildNodes
            For i = 0 To nodeList.Count - 1
                xNode = inXmlNode.ChildNodes(i)

                Dim nuevoNodo As New TreeNode
                nuevoNodo.Text = xNode.Attributes("Text").Value
                nuevoNodo.Tag = xNode.Attributes("Id").Value

                inTreeNode.Nodes.Add(nuevoNodo)
                nuevoNodo = Nothing

                tNode = inTreeNode.Nodes(i)
                AddNode(xNode, tNode)
            Next
        Else
            If Not inXmlNode.Attributes("Text") Is Nothing Then inTreeNode.Text = inXmlNode.Attributes("Text").Value
            If Not inXmlNode.Attributes("Id") Is Nothing Then inTreeNode.Tag = inXmlNode.Attributes("Id").Value
        End If
    End Sub

    Private Sub Insertar()
        Dim id As String
        id = trvMenu.SelectedNode.Tag

        Dim objMenusWeb As New clsMenusWeb.Maple.clsMenusWeb
        objMenusWeb.Bandera = "i1"
        REM cambiar por resultado de combo
        objMenusWeb.Id_MenuWeb = cboTiposMenus.SelectedValue
        objMenusWeb.Titulo = txtNombreMenu.Text
        objMenusWeb.Activo = True

        If optTipoCreadas.Checked Then
            REM antes de armar la liga verificar que tipo de liga es

            objMenusWeb.url = ArmarLigaCreada(cboLiga.SelectedValue)
        Else
            objMenusWeb.url = IIf(cboLiga.Text = "", "#", cboLiga.Text)
        End If
        If id = "" Then
            objMenusWeb.Id_Secundario = 0
            objMenusWeb.Pertenece_Al_Id = Nothing
        Else
            objMenusWeb.Id_Secundario = Nothing
            objMenusWeb.Pertenece_Al_Id = id
        End If
        objMenusWeb.Insertar()

        objMenusWeb = Nothing
    End Sub

    Private Function ArmarLigaCreada(ByVal IdPagina As Integer) As String
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Dim url As String = ""
        Try
            objPaginas.Bandera = "s1"
            objPaginas.Id_Pagina = IdPagina
            objPaginas.LlenarDatos()

            If objPaginas.Id_TipoPagina = 3 Then
                url = objPaginas.LigaPreestablecida
            Else
                url = "Gestor.aspx?IdPagina=" & cboLiga.SelectedValue
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try

        Return url
    End Function

    Private Sub Actualizar()
        Dim id As String
        id = trvMenu.SelectedNode.Tag

        Dim objMenusWeb As New clsMenusWeb.Maple.clsMenusWeb
        objMenusWeb.Bandera = "s1"
        objMenusWeb.Id = id
        objMenusWeb.LlenarDatos()

        objMenusWeb.Bandera = "u1"
        objMenusWeb.Titulo = txtNombreMenu.Text

        Dim Band As Boolean = False

        If lblLiga.Text = "" Then
            Band = True
        Else
            REM verifico si cambio, si cambio guardo
            If lblLiga.Text <> cboLiga.Text Then
                Band = True
            End If
        End If

        If Band = True Then
            If optTipoCreadas.Checked Then
                objMenusWeb.url = VerificarLiga(cboLiga.SelectedValue)
            Else
                objMenusWeb.url = IIf(cboLiga.Text = "", "#", cboLiga.Text)
            End If
        End If

        objMenusWeb.Actualizar()
        objMenusWeb = Nothing
    End Sub

    Private Function VerificarLiga(ByVal IdPagina As Integer) As String
        Dim Liga As String

        REM objMenusWeb.url = "Gestor.aspx?IdPagina=" & cboLiga.SelectedValue
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            objPaginas.Bandera = "s1"
            objPaginas.Id_Pagina = IdPagina
            objPaginas.LlenarDatos()

            Liga = IIf(objPaginas.LigaPreestablecida <> "", objPaginas.LigaPreestablecida, "Gestor.aspx?IdPagina=" & IdPagina)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try

        Return Liga
    End Function

    Private Sub Eliminar()
        Dim id As String
        id = trvMenu.SelectedNode.Tag

        Dim objMenusWeb As New clsMenusWeb.Maple.clsMenusWeb
        objMenusWeb.Bandera = "u2"
        objMenusWeb.Id = id
        objMenusWeb.Activo = False

        If id <> "" Then
            objMenusWeb.Actualizar()
        Else
            MsgBox("No se puede eliminar el Elemento seleccionado")
        End If

        objMenusWeb = Nothing
    End Sub
End Class
