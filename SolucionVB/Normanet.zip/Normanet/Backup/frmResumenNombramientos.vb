Imports System.Configuration

Public Class frmResumenNombramientos
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboFolios As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dtpReal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpVencimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdResumen As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmResumenNombramientos))
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboFolios = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.dtpReal = New System.Windows.Forms.DateTimePicker
        Me.dtpVencimiento = New System.Windows.Forms.DateTimePicker
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.cmdResumen = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(96, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 23)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Folio:"
        '
        'cboFolios
        '
        Me.cboFolios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFolios.Location = New System.Drawing.Point(144, 8)
        Me.cboFolios.Name = "cboFolios"
        Me.cboFolios.Size = New System.Drawing.Size(136, 21)
        Me.cboFolios.TabIndex = 60
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(32, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 61
        Me.Label2.Text = "Fecha Real Env�o:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 23)
        Me.Label3.TabIndex = 62
        Me.Label3.Text = "Fecha de Vencimiento:"
        '
        'dtpReal
        '
        Me.dtpReal.Enabled = False
        Me.dtpReal.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpReal.Location = New System.Drawing.Point(144, 40)
        Me.dtpReal.Name = "dtpReal"
        Me.dtpReal.Size = New System.Drawing.Size(136, 20)
        Me.dtpReal.TabIndex = 63
        '
        'dtpVencimiento
        '
        Me.dtpVencimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpVencimiento.Location = New System.Drawing.Point(144, 64)
        Me.dtpVencimiento.Name = "dtpVencimiento"
        Me.dtpVencimiento.Size = New System.Drawing.Size(136, 20)
        Me.dtpVencimiento.TabIndex = 64
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.CmdSalvar, Me.cmdResumen})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 99)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(288, 62)
        Me.tlbBotonera.TabIndex = 65
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'cmdResumen
        '
        Me.cmdResumen.ImageIndex = 15
        Me.cmdResumen.Text = "Resumen"
        Me.cmdResumen.ToolTipText = "Resumen de Nombramientos"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'frmResumenNombramientos
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 161)
        Me.Controls.Add(Me.dtpVencimiento)
        Me.Controls.Add(Me.dtpReal)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cboFolios)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Name = "frmResumenNombramientos"
        Me.Text = "..:: Resumen ::.."
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _IdRemitente As Integer
    Private IdAccion As eAccion
    Private _EmaiRemitente As String

    Private Enum eAccion As Integer
        PrimeraVez = 1
        SegundaVez = 2
    End Enum

    Private Enum eBtnResumen As Integer
        Salvar = 0
        Enviar = 1
    End Enum

    Public Property IdRemitente() As Integer
        Get
            Return _IdRemitente
        End Get
        Set(ByVal Value As Integer)
            _IdRemitente = Value
        End Set
    End Property

    Public Property EmaiRemitente() As String
        Get
            Return _EmaiRemitente
        End Get
        Set(ByVal Value As String)
            _EmaiRemitente = Value
        End Set
    End Property


    Private Sub frmResumenNombramientos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FillFoliosNombramientos(cboFolios)
        FillFechas(cboFolios.SelectedValue)
    End Sub

    Private Sub FillFoliosNombramientos(ByVal cbo As ComboBox)
        Dim dt As DataTable
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "s4"
        objNombramientos.IdRemitente = IdRemitente
        dt = objNombramientos.Listar

        cbo.DisplayMember = "Folio"
        cbo.ValueMember = "IdNombramiento"
        cbo.DataSource = dt
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case eBtnResumen.Enviar
                EnviarResumen(cboFolios.SelectedValue)
            Case eBtnResumen.Salvar
                GuardarFecha(cboFolios.SelectedValue)
        End Select
    End Sub

    Private Sub FillFechas(ByVal IdNombramiento As Integer)
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "s1"
        objNombramientos.IdNombramiento = IdNombramiento
        objNombramientos.LlenarDatos()

        Try
            If objNombramientos.Encontrado = True And Not objNombramientos.FechaRespuestaReal Is Nothing Then
                IdAccion = eAccion.SegundaVez
                Activar(tlbBotonera.Buttons.Item(0))
                dtpReal.Value = objNombramientos.FechaRespuestaReal
                If Not objNombramientos.FechaRespuestaVencimiento Is Nothing Then
                    dtpVencimiento.Value = objNombramientos.FechaRespuestaVencimiento
                Else
                    dtpVencimiento.Text = ""
                End If

            Else
                IdAccion = eAccion.PrimeraVez
                inactivar(tlbBotonera.Buttons.Item(0))
                dtpReal.Value = Now()
                dtpVencimiento.Value = DateAdd(DateInterval.Year, 3, Now())
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub cboFolios_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFolios.SelectionChangeCommitted
        FillFechas(cboFolios.SelectedValue)
    End Sub

    Private Sub EnviarResumen(ByVal IdNombramiento As Integer)
        Dim Parametros As New ArrayList
        Dim paramIdNombramiento As New Maple.entXml
        Dim paramHRef As New Maple.entXml
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos

        If cboFolios.SelectedValue.ToString <> "" Then

            objNombramientos.Bandera = "s1"
            objNombramientos.IdNombramiento = IdNombramiento
            objNombramientos.LlenarDatos()

            paramIdNombramiento.Key = "IdNombramiento"
            paramIdNombramiento.Value = IdNombramiento
            Parametros.Add(paramIdNombramiento)

            paramHRef.Key = "HRef"
            paramHRef.Value = GenerarLiga(IdNombramiento)
            Parametros.Add(paramHRef)

            If objNombramientos.Encontrado = True And objNombramientos.FechaRespuestaReal Is Nothing Then
                objNombramientos.Bandera = "u6"
                objNombramientos.FechaRespuestaReal = dtpReal.Value
                objNombramientos.FechaRespuestaVencimiento = dtpVencimiento.Value
                objNombramientos.ActualizarFechas()
            End If

            Activar(tlbBotonera.Buttons.Item(0))
            Dim objCorreo As New clsCorreo.ClsCorreo
            objCorreo.Subject = "RESUMEN DE CARGOS"
            objCorreo.Bandera = "s5"
            objCorreo.sTo = EmaiRemitente
            objCorreo.XML = Maple.clssufnSQL.CrearXmlParamSql(Parametros)

            objCorreo.CorreoPersonalizado()

            MsgBox("Correo enviado", MsgBoxStyle.Information)
        Else
            MsgBox("Es necesario seleccionar un folio para poder enviar el resumen de nombramientos", MsgBoxStyle.Information)
        End If
    End Sub

    Private Function GenerarLiga(ByVal IdNombramiento As Integer)

        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        Dim sRuta As String
        Dim RutaTemporal As String = objNombramientos.RutaDocumentos()
        Dim LigaDescargaDocumentos As String = ConfigurationSettings.AppSettings("DocumentosWebVirtual").ToString
        Dim Nombramiento As String = ""
        Dim objiniarray As New clsIniarray.ClsIniArray
        Dim RutaNombramientos As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutaNombramientos")))
        Dim RutaFinal As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + RutaNombramientos)

        objNombramientos.Bandera = "s1"
        objNombramientos.IdNombramiento = IdNombramiento
        objNombramientos.LlenarDatos()

        System.IO.File.Copy(RutaFinal & objNombramientos.Nombramiento, RutaTemporal & objNombramientos.Nombramiento, True)
        sRuta = LigaDescargaDocumentos & objNombramientos.Nombramiento

        Return sRuta
    End Function

    Private Function GuardarFecha(ByVal IdNombramiento As Integer)
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "u7"
        objNombramientos.FechaRespuestaReal = dtpReal.Value
        objNombramientos.FechaRespuestaVencimiento = dtpVencimiento.Value
        objNombramientos.IdNombramiento = IdNombramiento
        objNombramientos.ActualizarFechas()
        MsgBox("Fecha Guardada", MsgBoxStyle.Information)
    End Function

End Class
