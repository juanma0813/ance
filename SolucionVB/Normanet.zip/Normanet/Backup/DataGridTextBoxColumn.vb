Imports System.Drawing
Imports System.Drawing.ColorConverter.StandardValuesCollection

Public Class DataGridTextBoxColumn
    Inherits System.Windows.Forms.DataGridTextBoxColumn

    Public Event PaintRow(ByVal args As PaintRowEventArgs)

    Public Sub New()
        MyBase.New()
    End Sub


    Protected Overloads Overrides Sub Paint(ByVal g As Graphics, ByVal bounds As Rectangle, ByVal [source] As CurrencyManager, ByVal rowNum As Integer, ByVal backBrush As Brush, ByVal foreBrush As Brush, ByVal alignToRight As Boolean)
        Dim oArgs As New PaintRowEventArgs

        oArgs.RowNumber = rowNum

        RaiseEvent PaintRow(oArgs)

        If Not oArgs.BackColor Is Nothing Then
            backBrush = (oArgs.BackColor)

        End If

        If Not oArgs.ForeColor Is Nothing Then
            foreBrush = oArgs.ForeColor
        End If

        oArgs = Nothing

        MyBase.Paint(g, bounds, [source], rowNum, backBrush, foreBrush, alignToRight)

    End Sub
End Class

Public Class DGTxtColExpresion
    Inherits DataGridTextBoxColumn
    Private mColumnaExpresion As DataColumn
    Private mColorExpVerdadera As Color
    Private mColorExpFalsa As Color

    ' propiedades para el color de fondo
    ' seg�n se evalue el contenido de la celda
    Public Property ColorExpVerdadera() As Color
        Get
            Return mColorExpVerdadera
        End Get
        Set(ByVal Value As Color)
            mColorExpVerdadera = Value
        End Set
    End Property

    Public Property ColorExpFalsa() As Color
        Get
            Return mColorExpFalsa
        End Get
        Set(ByVal Value As Color)
            mColorExpFalsa = Value
        End Set
    End Property

    Public Sub AgregarColumnaExpresion(ByVal sNombreColumna As String, _
    ByVal sExpresion As String)
        Dim oDataGrid As DataGrid
        Dim oDataView As DataView
        ' obtener el DataGrid en el que esta
        ' columna est� contenida
        oDataGrid = Me.DataGridTableStyle.DataGrid
        ' obtener la fuente de datos asociada al DataGrid
        oDataView = CType(oDataGrid.BindingContext(oDataGrid.DataSource, _
        oDataGrid.DataMember), CurrencyManager).List
        ' crear una columna y asignarle la expresi�n a evaluar
        mColumnaExpresion = New DataColumn(sNombreColumna)
        mColumnaExpresion.Expression = sExpresion
        ' a�adir la columna a la fuente de datos del DataGrid
        oDataView.Table.Columns.Add(mColumnaExpresion)
    End Sub

    Protected Overloads Overrides Sub Paint(ByVal g As System.Drawing.Graphics, _
    ByVal bounds As System.Drawing.Rectangle, _
    ByVal source As System.Windows.Forms.CurrencyManager, _
    ByVal rowNum As Integer, _
    ByVal backBrush As System.Drawing.Brush, _
    ByVal foreBrush As System.Drawing.Brush, _
    ByVal alignToRight As Boolean)
        Dim oDataRowView As DataRowView
        Dim oDataRow As DataRow
        Dim bValorCelda As Boolean
        Dim oBrushFondo As Brush
        ' obtener la fila a pintar de la fuente de datos
        oDataRowView = source.List(rowNum)
        oDataRow = oDataRowView.Row
        ' evaluar el contenido de la expresi�n
        ' asociada a la columna que hemos a�adido
        ' din�micamente a este objeto
        bValorCelda = CType(oDataRow(mColumnaExpresion.ColumnName), Boolean)
        ' dependiendo del valor de la columna
        ' de expresi�n, seleccionar el color
        ' que debemos aplicar
        If bValorCelda Then
            oBrushFondo = New SolidBrush(mColorExpVerdadera)
        Else
            oBrushFondo = New SolidBrush(mColorExpFalsa)
        End If
        ' pintar la celda con el color de fondo apropiado
        MyBase.Paint(g, bounds, source, rowNum, _
        oBrushFondo, foreBrush, alignToRight)
    End Sub

End Class

Public Class PaintRowEventArgs
    Inherits EventArgs

    Private _rowNum As Integer
    Private _backColor As Brush
    Private _foreColor As Brush
    Public Property RowNumber() As Integer
        Get
            Return _rowNum
        End Get
        Set(ByVal Value As Integer)
            _rowNum = Value
        End Set
    End Property

    Public Property BackColor() As Brush
        Get
            Return _backColor
        End Get
        Set(ByVal Value As Brush)
            _backColor = Value
        End Set
    End Property

    Public Property ForeColor() As Brush
        Get
            Return _foreColor
        End Get
        Set(ByVal Value As Brush)
            _foreColor = Value
        End Set
    End Property
End Class


