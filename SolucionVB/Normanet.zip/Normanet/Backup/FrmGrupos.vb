Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections

Public Class FrmGrupos
    Inherits System.Windows.Forms.Form

    Private objMenus As New clsMenus.clsMenus(2, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DGGrupos As System.Windows.Forms.DataGrid
    Friend WithEvents Lblgp As System.Windows.Forms.Label
    Friend WithEvents CBoGrupo As System.Windows.Forms.ComboBox
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmGrupos))
        Me.DGGrupos = New System.Windows.Forms.DataGrid
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.Lblgp = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.CBoGrupo = New System.Windows.Forms.ComboBox
        CType(Me.DGGrupos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DGGrupos
        '
        Me.DGGrupos.CaptionVisible = False
        Me.DGGrupos.DataMember = ""
        Me.DGGrupos.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DGGrupos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DGGrupos.Location = New System.Drawing.Point(16, 64)
        Me.DGGrupos.Name = "DGGrupos"
        Me.DGGrupos.Size = New System.Drawing.Size(368, 440)
        Me.DGGrupos.TabIndex = 0
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdGuardar, Me.CmdBorrar, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 515)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(394, 62)
        Me.tlbBotonera.TabIndex = 118
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdGuardar
        '
        Me.CmdGuardar.ImageIndex = 2
        Me.CmdGuardar.Text = "Guardar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.BlinkRate = 1000
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'Lblgp
        '
        Me.Lblgp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lblgp.Location = New System.Drawing.Point(8, 24)
        Me.Lblgp.Name = "Lblgp"
        Me.Lblgp.TabIndex = 119
        Me.Lblgp.Text = "Grupo:"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(120, 25)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(224, 20)
        Me.TextBox1.TabIndex = 120
        Me.TextBox1.Text = "TextBox1"
        '
        'CBoGrupo
        '
        Me.CBoGrupo.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBoGrupo.Location = New System.Drawing.Point(120, 25)
        Me.CBoGrupo.Name = "CBoGrupo"
        Me.CBoGrupo.Size = New System.Drawing.Size(224, 22)
        Me.CBoGrupo.TabIndex = 121
        Me.CBoGrupo.Text = "ComboBox1"
        '
        'FrmGrupos
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(394, 577)
        Me.Controls.Add(Me.CBoGrupo)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.Lblgp)
        Me.Controls.Add(Me.DGGrupos)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmGrupos"
        Me.Text = "Grupos de Acceso"
        CType(Me.DGGrupos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

#Region " Funciones - Menudt(MainMenu.MenuItemCollection,DataTable) As DataTable, Metodos y Procesos"

    Private Function Menudt(ByVal menus As MainMenu.MenuItemCollection, ByVal dt As DataTable) As DataTable
        Dim i, j As Integer
        Dim bexiste As Boolean
        For i = 0 To menus.Count - 1 Step 1
            bexiste = False
            For j = 0 To dt.Rows.Count - 1 Step 1
                If menus.Item(i).Text = dt.Rows(j).Item("Id_Menu") Then
                    bexiste = True
                    If menus.Item(i).IsParent Then Menudt(menus.Item(i).MenuItems, dt)
                    Exit For
                End If
            Next
            If Not bexiste Then
                objMenus.id_menu = menus.Item(i).Text
                objMenus.nombre_menu = menus.Item(i).Text
                objMenus.Bandera = 1
                objMenus.Inserta_menus(gUsuario, gPasswordSql)
            End If
        Next
        objMenus.Bandera = 3
        Dim dt2 = objMenus.Listar()
        Return dt2
    End Function

#End Region

#End Region

#Region " Forms - FrmGrupos_Load, Metodos y Procesos"

    Private Sub FrmGrupos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim menu As Form = Me.MdiParent
        objMenus.sistema = 16
        objMenus.Bandera = 2
        Dim dt As DataTable = objMenus.Listar
        Dim dtmenus As DataTable = Menudt(menu.Menu.MenuItems, dt)
        DGGrupos.DataSource = dtmenus
        objempleados.Id_Sistema = 16
        objempleados.Bandera = 9
        objempleados.ListaCombo(CBoGrupo)
    End Sub

#End Region

#Region " ComboBox - CBoGrupo_SelectedIndexChanged, Metodos y Procesos"

    Private Sub CBoGrupo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CBoGrupo.SelectedIndexChanged
        objMenus.Bandera = 4
        DGGrupos.DataSource = objMenus.Listar()
    End Sub

#End Region

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick

    End Sub
End Class
