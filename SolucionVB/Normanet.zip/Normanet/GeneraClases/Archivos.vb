Option Strict On
Option Explicit On 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Public Class Archivos
    '''Public ArClase As New System.IO.StreamWriter(RutaPath & ArcClase & ".vb")
    '''Public Shared RutaPath As String
    '''Public Shared ArcClase As String
    '''Public Shared Tabulador As String = "     "
    '''Public Shared Tabulador2 As String = "          "
    '''Public Shared Tabulador3 As String = "              "
    '''Public Shared Tabulador4 As String = "                  "
    '''Public Shared Tabulador5 As String = "                      "
    '''Public Shared CadenaCero As String = Chr(34) & "0" & Chr(34)
    '''Private Shared Programador As String = "Miguel Angel L�pez Ortega"
    ''''********************************************************************************
    '''Public Function Explicativa(ByVal Explica As String) As String
    '''    ArClase.WriteLine(Tabulador & "'*************************************************************************************")
    '''    ArClase.WriteLine(Tabulador & "' " & Tabulador & Explica)
    '''    ArClase.WriteLine(Tabulador & "' " & Tabulador & "Programador: " & Programador & Tabulador2 & Now)
    '''    ArClase.WriteLine(Tabulador & "'*************************************************************************************")
    '''End Function
    ''''********************************************************************************
    '''Public Function FuncAjustar() As String
    '''    ArClase.WriteLine(Tabulador & "Private Function AjustarAncho(Cadena as String, Ancho as Integer) as String")
    '''    ArClase.WriteLine(Tabulador2 & "Dim Sb as New System.Text.StringBuilder(New String(" & Chr(34) & " " & Chr(34) & "c, ancho))")
    '''    ArClase.WriteLine(Tabulador2 & "Return (Cadena & sb.toString()).Substring(0,ancho).Trim()")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function EscribeClase() As String
    '''    Dim wtabla As New Tablas
    '''    Dim I As Integer
    '''    Dim IsLlave As String
    '''    Dim CWhere As String
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        IsLlave = wtabla.Campos(6, I).ToString
    '''        If IsLlave = "True" Then
    '''            CWhere = wtabla.Campos(0, I).ToString()
    '''        End If
    '''    Next
    '''    If CWhere = "" Then
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        SeparaLineas()
    '''        SeparaLineas()
    '''        ArClase.WriteLine(Tabulador & "'" & Tabulador5 & " NO TIENE CAMPO LLAVE CUIDADO")
    '''        ArClase.WriteLine(Tabulador & "'" & Tabulador3 & "Puede Afectar el correcto funcionamiento de las funciones")
    '''        ArClase.WriteLine(Tabulador & "'" & Tabulador2 & "De Actualizacion y de Borrado ya que se hacen sobre un campo llave")
    '''        SeparaLineas()
    '''        SeparaLineas()
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''    Else
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        SeparaLineas()
    '''        SeparaLineas()
    '''        ArClase.WriteLine(Tabulador & "'" & Tabulador5 & " ESTOS SON LOS CAMPOS LLAVE QUE TIENE LA TABLA")
    '''        For I = 0 To wtabla.DimensionCampos - 1
    '''            IsLlave = wtabla.Campos(6, I).ToString
    '''            If IsLlave = "True" Then
    '''                ArClase.WriteLine(Tabulador & "'" & Tabulador3 & wtabla.Campos(0, I).ToString())
    '''            End If
    '''        Next
    '''        SeparaLineas()
    '''        SeparaLineas()
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''        ArClase.WriteLine("")
    '''    End If
    '''    Encabezado()
    '''End Function
    ''''********************************************************************************
    '''Public Function CierraArchivo() As String
    '''    ArClase.WriteLine("End Class")
    '''    ArClase.Close()
    '''End Function
    ''''********************************************************************************
    '''Public Function Encabezado() As String
    '''    Dim xconexion As New Conexion
    '''    ArClase.WriteLine("'*************************************************************************************")
    '''    ArClase.WriteLine("'Clase " & ArcClase & " Generada automaticamente con Clases")
    '''    ArClase.WriteLine("'Programador " & Programador)
    '''    ArClase.WriteLine("'Fecha : " & Now & "")
    '''    ArClase.WriteLine("'Cadena de Conexion : " & xconexion.Cadenaconexion & "")
    '''    ArClase.WriteLine("'*************************************************************************************")
    '''    ArClase.WriteLine("Option Explicit")
    '''    ArClase.WriteLine("Option Strict On")
    '''    Importaciones()
    '''    Lineas()
    '''    ArClase.WriteLine("Public Class " & ArcClase)
    '''    Explicativa("Declaracion de Variables Privadas")
    '''    Variables()
    '''    Explicativa("funcion que me devuelve uan cadena a una determina longuitud")
    '''    FuncAjustar()
    '''    Explicativa("Declaracion de Propiedades Publicas")
    '''    Propiedades()
    '''    Explicativa("Devuelve el Contenido del campo indicado siendo el numero de la columna")
    '''    PropiedadDefault1()
    '''    Explicativa("Devuelve el Contenido del Campo indicado siendo el nombre de la Columna")
    '''    PropiedadDefault2()
    '''    Explicativa("Define la cadena de Conexion a la Base de Datos")
    '''    EstCadCon()
    '''    Explicativa("Define la cadena de Seleccion a la Base de Datos")
    '''    EstCadSel()
    '''    Explicativa("Declara una nueva instancia")
    '''    EstNew()
    '''    Explicativa("Asigan una fila de Tabla a un Objeto " & ArcClase)
    '''    Tab2Obj()
    '''    Explicativa("Asigan un Objeto " & ArcClase & " a una Tabla")
    '''    Obj2Tab()
    '''    Explicativa("Crea una nueva fila y la asigna a un objeto " & ArcClase)
    '''    Fil2Obj()
    '''    Explicativa("Devuelve una Tabla con los datos indicados en la cadena de Seleccion")
    '''    ObtTabla()
    '''    Explicativa("Complemento de la Funcion Anterior")
    '''    ObtTabla1()
    '''    Explicativa("Funcion para buscar datos en la tabla segun parametro")
    '''    Buscar()
    '''    Explicativa("Funcion que nos permite actualizar datos en nuestra base de datos")
    '''    Actualiza()
    '''    Explicativa("Funcion que nos permite actualizar datos en nuestra base de datos")
    '''    Actualiza2()
    '''    Explicativa("Funcion que nos permite ingresar datos nuevos en la tabla")
    '''    Crea()
    '''    Explicativa("Funcion que nos permite Eliminar datos de la tabla")
    '''    Borrado()
    '''    Explicativa("Complemento de la Funcion Anterior")
    '''    Borra2()
    '''End Function
    ''''********************************************************************************
    '''Public Function SeparaLineas() As String
    '''    ArClase.WriteLine(Tabulador & "'*****************************************************************************")
    '''End Function
    ''''********************************************************************************
    '''Public Function Lineas() As String
    '''    ArClase.WriteLine("'")
    '''End Function
    ''''********************************************************************************
    '''Public Function Importaciones() As String
    '''    ArClase.WriteLine("Imports System")
    '''    ArClase.WriteLine("Imports System.Data")
    '''    ArClase.WriteLine("Imports System.Data.SqlClient")
    '''End Function
    ''''********************************************************************************
    '''Public Function Variables() As String
    '''    Dim wtabla As New Tablas
    '''    Dim I As Integer
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        ArClase.WriteLine(Tabulador & "Private _" & wtabla.Campos(0, I).ToString() & " as " & wtabla.Campos(12, I).ToString())
    '''    Next
    '''End Function
    ''''********************************************************************************
    '''Public Function Propiedades() As String
    '''    Dim wtabla As New Tablas
    '''    Dim Campo As String
    '''    Dim Tipo As String
    '''    Dim Variable As String
    '''    Dim I As Integer
    '''    Dim Longitud As String
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Longitud = wtabla.Campos(2, I).ToString
    '''        Variable = "_" & Campo
    '''        'SeparaLineas()
    '''        ArClase.WriteLine(Tabulador & "Public Property " & Campo & "() As " & Tipo)
    '''        ArClase.WriteLine(Tabulador2 & "Get")
    '''        Select Case UCase(Tipo)
    '''            Case Is = "SYSTEM.STRING"
    '''                ArClase.WriteLine(Tabulador3 & "Return AjustarAncho(" & Variable & ", " & Longitud & ")")
    '''            Case Else
    '''                ArClase.WriteLine(Tabulador3 & "Return " & Variable)
    '''        End Select
    '''        ArClase.WriteLine(Tabulador2 & "End Get")
    '''        ArClase.WriteLine(Tabulador2 & "Set(Value as " & Tipo & ")")
    '''        ArClase.WriteLine(Tabulador3 & Variable & " = Value")
    '''        ArClase.WriteLine(Tabulador2 & "End Set")
    '''        ArClase.WriteLine(Tabulador & "End Property")
    '''    Next
    '''End Function
    ''''********************************************************************************
    '''Public Function PropiedadDefault1() As String
    '''    Dim wtabla As New Tablas
    '''    Dim Campo As String
    '''    Dim Tipo As String
    '''    Dim Variable As String
    '''    Dim I As Integer
    '''    ArClase.WriteLine(Tabulador & "Public Default Property Item(Index as Integer) as String")
    '''    ArClase.WriteLine(Tabulador2 & "Get")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Variable = "_" & Campo
    '''        If I = 0 Then
    '''            ArClase.WriteLine(Tabulador3 & "If Index = 0 Then")
    '''        Else
    '''            ArClase.WriteLine(Tabulador3 & "elseif index = " & I & " Then")
    '''        End If
    '''        ArClase.WriteLine(Tabulador4 & "Return Me." & Campo & ".ToString()")
    '''    Next
    '''    ArClase.WriteLine(Tabulador3 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "End Get")
    '''    ArClase.WriteLine(Tabulador2 & "Set(Value as String)")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Variable = "_" & Campo
    '''        If I = 0 Then
    '''            ArClase.WriteLine(Tabulador3 & "If Index = 0 Then")
    '''        Else
    '''            ArClase.WriteLine(Tabulador3 & "ElseIf Index = " & I & " Then")
    '''        End If
    '''        Select Case Tipo
    '''            Case Is = "System.Decimal"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.Int16"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.Int32"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.Int64()"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.DateTime"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.DateTime.Parse(Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Datetime.Now")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Else
    '''                ArClase.WriteLine(Tabulador4 & "Me." & Campo & "= Value")
    '''        End Select
    '''    Next
    '''    ArClase.WriteLine(Tabulador3 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "End Set")
    '''    ArClase.WriteLine(Tabulador & "End Property")
    '''End Function
    ''''********************************************************************************
    '''Public Function PropiedadDefault2() As String
    '''    Dim wtabla As New Tablas
    '''    Dim Campo As String
    '''    Dim Tipo As String
    '''    Dim Variable As String
    '''    Dim Campo_Pre As String
    '''    Dim I As Integer
    '''    ArClase.WriteLine(Tabulador & "Public Default Property Item(Index as String) as String")
    '''    ArClase.WriteLine(Tabulador2 & "Get")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Campo_Pre = Chr(34) & Campo & Chr(34)
    '''        Variable = "_" & Campo
    '''        If I = 0 Then
    '''            ArClase.WriteLine(Tabulador3 & "If Index = " & Campo_Pre & " Then")
    '''        Else
    '''            ArClase.WriteLine(Tabulador3 & "ElseIf Index = " & Campo_Pre & " Then")
    '''        End If
    '''        ArClase.WriteLine(Tabulador4 & "Return Me." & Campo & ".ToString()")
    '''    Next
    '''    ArClase.WriteLine(Tabulador3 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "End Get")
    '''    ArClase.WriteLine(Tabulador2 & "Set(Value as String)")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Variable = "_" & Campo
    '''        Campo_Pre = Chr(34) & Campo & Chr(34)
    '''        If I = 0 Then
    '''            ArClase.WriteLine(Tabulador3 & "If Index = " & Campo_Pre & " Then")
    '''        Else
    '''            ArClase.WriteLine(Tabulador3 & "ElseIf Index = " & Campo_Pre & " Then")
    '''        End If
    '''        Select Case Tipo
    '''            Case Is = "System.Decimal"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.Int16"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.Int32"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.Int64()"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & " & Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & ")")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Is = "System.DateTime"
    '''                ArClase.WriteLine(Tabulador4 & "Try")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.DateTime.Parse(Value)")
    '''                ArClase.WriteLine(Tabulador4 & "Catch")
    '''                ArClase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Datetime.Now")
    '''                ArClase.WriteLine(Tabulador4 & "End Try")
    '''            Case Else
    '''                ArClase.WriteLine(Tabulador4 & "Me." & Campo & " = Value")
    '''        End Select
    '''    Next
    '''    ArClase.WriteLine(Tabulador3 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "End Set")
    '''    ArClase.WriteLine(Tabulador & "End Property")
    '''End Function
    ''''********************************************************************************
    '''Public Function EstCadCon() As String
    '''    Dim xconexion As New Conexion
    '''    ArClase.WriteLine(Tabulador & "Public Shared CadenaConexion as String = " & Chr(34) & xconexion.Cadenaconexion & Chr(34))
    '''End Function
    ''''********************************************************************************
    '''Public Function EstCadSel() As String
    '''    ArClase.WriteLine(Tabulador & "Public Shared CadenaSelect as String = " & Chr(34) & "Select * From " & ArcClase & Chr(34))
    '''End Function
    ''''********************************************************************************
    '''Public Function EstNew() As String
    '''    ArClase.WriteLine(Tabulador & "Public Sub New () ")
    '''    ArClase.WriteLine(Tabulador & "End Sub")
    '''    ArClase.WriteLine(Tabulador & "Public Sub New (conex as String) ")
    '''    ArClase.WriteLine(Tabulador2 & "CadenaConexion =  conex")
    '''    ArClase.WriteLine(Tabulador & "End Sub")
    '''End Function
    ''''********************************************************************************
    '''Public Function Tab2Obj() As String
    '''    Dim I As Integer
    '''    Dim Campo As String
    '''    Dim wtabla As New Tablas
    '''    Dim Variable As String
    '''    Dim Tipo As String
    '''    Dim Campo_Pre As String
    '''    ArClase.WriteLine(Tabulador & "Private Shared function row2" & ArcClase & "(r As DataRow) as " & ArcClase)
    '''    ArClase.WriteLine(Tabulador2 & "Dim o" & ArcClase & " as New " & ArcClase)
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Variable = "_" & Campo
    '''        Campo_Pre = Chr(34) & Campo & Chr(34)
    '''        Select Case Tipo
    '''            Case Is = "System.Decimal"
    '''                ArClase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Decimal.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
    '''            Case Is = "System.Int16"
    '''                ArClase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Int16.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
    '''            Case Is = "System.Int32"
    '''                ArClase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Int32.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
    '''            Case Is = "System.Int64"
    '''                ArClase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Int64.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
    '''            Case Is = "System.DateTime"
    '''                ArClase.WriteLine(Tabulador3 & "Try")
    '''                ArClase.WriteLine(Tabulador4 & "o" & ArcClase & "." & Campo & " = DateTime.Parse(r(" & Campo_Pre & ").ToString())")
    '''                ArClase.WriteLine(Tabulador3 & "Catch")
    '''                ArClase.WriteLine(Tabulador4 & "o" & ArcClase & "." & Campo & " = DateTime.Now")
    '''                ArClase.WriteLine(Tabulador3 & "End Try")
    '''            Case Else
    '''                ArClase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = r(" & Campo_Pre & ").ToString()")
    '''        End Select
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & "Return o" & ArcClase)
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Obj2Tab() As String
    '''    Dim I As Integer
    '''    Dim J As Integer
    '''    Dim Campo As String
    '''    Dim wtabla As New Tablas
    '''    Dim Variable As String
    '''    Dim Tipo As String
    '''    Dim Campo_Pre As String
    '''    Dim CadSel As String
    '''    Dim Primary As String
    '''    Dim Lllave As Boolean = False
    '''    ArClase.WriteLine(Tabulador & "Private Shared Sub " & ArcClase & "2row(o" & ArcClase & " as " & ArcClase & ", r as Datarow)")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(1, I).ToString
    '''        Variable = "_" & Campo
    '''        Campo_Pre = Chr(34) & Campo & Chr(34)
    '''        For J = 1 To 200
    '''            If UCase(RTrim(wtabla.Llaves(1, J))) = UCase(RTrim(ArcClase)) And UCase(RTrim(wtabla.Llaves(0, J))) = UCase(RTrim(Campo)) Then
    '''                Lllave = True
    '''                Exit For
    '''            End If
    '''        Next
    '''        If Lllave Then
    '''            ArClase.WriteLine(Tabulador2 & "'r(" & Campo_Pre & ") = o" & ArcClase & "." & Campo & " Es un campo Llave")
    '''            Lllave = False
    '''        Else
    '''            ArClase.WriteLine(Tabulador2 & "r(" & Campo_Pre & ") = o" & ArcClase & "." & Campo)
    '''        End If
    '''    Next
    '''    ArClase.WriteLine(Tabulador & "End Sub")
    '''End Function
    ''''********************************************************************************
    '''Public Function Fil2Obj() As String
    '''    Dim I As Integer
    '''    Dim Campo As String
    '''    Dim wtabla As New Tablas
    '''    Dim Variable As String
    '''    Dim Tipo As String
    '''    Dim Campo_Pre As String
    '''    Dim Primary As String
    '''    ArClase.WriteLine(Tabulador & "Private Shared Sub nuevo" & ArcClase & "(dt as DataTable, o" & ArcClase & " as " & ArcClase & ")")
    '''    ArClase.WriteLine(Tabulador2 & "Dim Dr as DataRow = dt.NewRow()")
    '''    ArClase.WriteLine(Tabulador2 & "Dim oc as " & ArcClase & " = row2" & ArcClase & "(dr)")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Variable = "_" & Campo
    '''        Campo_Pre = Chr(34) & Campo & Chr(34)
    '''        ArClase.WriteLine(Tabulador2 & "oc." & Campo & " = o" & ArcClase & "." & Campo)
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & ArcClase & "2row(oc,dr)")
    '''    ArClase.WriteLine(Tabulador2 & "dt.rows.add(dr)")
    '''    ArClase.WriteLine(Tabulador & "End Sub")
    '''End Function
    ''''********************************************************************************
    '''Public Function ObtTabla() As String
    '''    ArClase.WriteLine(Tabulador & "Public Shared Function Tabla() as DataTable")
    '''    ArClase.WriteLine(Tabulador2 & "Return Tabla(CadenaSelect)")
    '''    ArClase.WriteLine(Tabulador & "End function")
    '''End Function
    ''''********************************************************************************
    '''Public Function ObtTabla1() As String
    '''    ArClase.WriteLine(Tabulador & "Public Shared Function Tabla(Sel as String) as DataTable")
    '''    ArClase.WriteLine(Tabulador2 & "Dim da as SqldataAdapter")
    '''    ArClase.WriteLine(Tabulador2 & "Dim dt as New DataTable(" & Chr(34) & ArcClase & Chr(34) & ")")
    '''    ArClase.WriteLine(Tabulador2 & "Try")
    '''    ArClase.WriteLine(Tabulador3 & "da = New SqlDataAdapter(Sel, CadenaConexion)")
    '''    ArClase.WriteLine(Tabulador3 & "Da.Fill(dt)")
    '''    ArClase.WriteLine(Tabulador2 & "Catch")
    '''    ArClase.WriteLine(Tabulador3 & "Return Nothing")
    '''    ArClase.WriteLine(Tabulador2 & "End Try")
    '''    ArClase.WriteLine(Tabulador2 & "Return dt")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Buscar() As String
    '''    ArClase.WriteLine(Tabulador & "Public Shared Function Buscar(sWhere as String) as " & ArcClase)
    '''    ArClase.WriteLine(Tabulador2 & "Dim o" & ArcClase & " as " & ArcClase & " = Nothing")
    '''    ArClase.WriteLine(Tabulador2 & "Dim da As SqlDataAdapter")
    '''    ArClase.WriteLine(Tabulador2 & "Dim dt as New DataTable(" & Chr(34) & ArcClase & Chr(34) & ")")
    '''    ArClase.WriteLine(Tabulador2 & "Dim Sel as String = " & Chr(34) & "Select * From " & ArcClase & " Where " & Chr(34) & " & sWhere")
    '''    ArClase.WriteLine(Tabulador2 & "da = New SqlDataAdapter(Sel, CadenaConexion)")
    '''    ArClase.WriteLine(Tabulador2 & "Da.Fill(dt)")
    '''    ArClase.WriteLine(Tabulador2 & "if dt.Rows.count> 0 Then")
    '''    ArClase.WriteLine(Tabulador3 & "o" & ArcClase & " = row2" & ArcClase & "(dt.Rows(0))")
    '''    ArClase.WriteLine(Tabulador2 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "Return o" & ArcClase)
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Actualiza() As String
    '''    Dim wtabla As New Tablas
    '''    Dim I As Integer
    '''    Dim Campo As String
    '''    Dim Llave As String
    '''    Dim isLlave As String
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        isLlave = wtabla.Campos(6, I).ToString
    '''        If isLlave = "True" Then
    '''            Campo = wtabla.Campos(0, I).ToString
    '''            Exit For
    '''        End If
    '''    Next
    '''    ArClase.WriteLine(Tabulador & "Public Function Actualizar() as String")
    '''    ArClase.WriteLine(Tabulador2 & "Dim Sel as string = " & Chr(34) & "Select * From " & ArcClase & " Where " & Campo & " = " & Chr(34) & " & Me." & Campo & ".ToString()")
    '''    ArClase.WriteLine(Tabulador2 & "Return Actualizar(Sel)")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Actualiza2() As String
    '''    Dim wtabla As New Tablas
    '''    Dim I As Integer
    '''    Dim Campo As String
    '''    Dim Cadena As String
    '''    Dim Tipo As String
    '''    Dim IsLlave As String
    '''    Dim Longitud As String
    '''    Dim campollave As String
    '''    Dim Total As Integer
    '''    ArClase.WriteLine(Tabulador & "Public Function Actualizar(Sel as String) as String")
    '''    ArClase.WriteLine(Tabulador2 & "Dim cnn As SqlConnection")
    '''    ArClase.WriteLine(Tabulador2 & "Dim da as SqlDataAdapter")
    '''    ArClase.WriteLine(Tabulador2 & "Dim dt as New Datatable(" & Chr(34) & ArcClase & Chr(34) & ")")
    '''    ArClase.WriteLine(Tabulador2 & "cnn = New SqlConnection(Cadenaconexion)")
    '''    ArClase.WriteLine(Tabulador2 & "da = New SqlDataAdapter(sel,cnn)")
    '''    ArClase.WriteLine(Tabulador2 & "da.MissingSchemaAction=MissingSchemaAction.addWithKey")
    '''    ArClase.WriteLine(Tabulador2 & "Dim sCommand as String")
    '''    Total = wtabla.DimensionCampos - 2
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        IsLlave = wtabla.Campos(6, I).ToString
    '''        If IsLlave = "True" Then
    '''            campollave = Campo
    '''        Else
    '''            If I = Total Then
    '''                Cadena = Cadena & Campo & " = @" & Campo & " "
    '''            Else
    '''                Cadena = Cadena & Campo & " = @" & Campo & ", "
    '''            End If
    '''        End If
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & "sCommand =" & Chr(34) & "UPDATE " & ArcClase & " SET " & Cadena & "Where (" & campollave & " = @" & campollave & ")" & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "da.UpdateCommand = New Sqlcommand(sCommand, Cnn)")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Longitud = wtabla.Campos(2, I).ToString
    '''        Select Case UCase(Tipo)
    '''            Case "SYSTEM.STRING"
    '''                Tipo = "SqlDbType.NvarChar"
    '''            Case "SYSTEM.INT32"
    '''                Tipo = "SqlDbType.Int"
    '''                Longitud = "0"
    '''            Case "SYSTEM.DATETIME"
    '''                Tipo = "SqlDbType.DateTime"
    '''                Longitud = "0"
    '''        End Select

    '''        ArClase.WriteLine(Tabulador2 & "da.UpdateCommand.Parameters.Add(" & Chr(34) & "@" & Campo & Chr(34) & ", " & Tipo & ", " & Longitud & ", " & Chr(34) & Campo & Chr(34) & ")")
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & "Try")
    '''    ArClase.WriteLine(Tabulador3 & "da.Fill(dt)")
    '''    ArClase.WriteLine(Tabulador2 & "Catch ex As Exception")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
    '''    ArClase.WriteLine(Tabulador2 & "End Try")
    '''    ArClase.WriteLine(Tabulador2 & "If dt.Rows.Count=0 Then")
    '''    ArClase.WriteLine(Tabulador3 & "Return Crear()")
    '''    ArClase.WriteLine(Tabulador2 & "Else")
    '''    ArClase.WriteLine(Tabulador3 & ArcClase & "2Row(Me, dt.rows(0))")
    '''    ArClase.WriteLine(Tabulador2 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "Try")
    '''    ArClase.WriteLine(Tabulador3 & "da.Update(dt)")
    '''    ArClase.WriteLine(Tabulador3 & "dt.AcceptChanges()")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & " Actualizado Correctamente" & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "Catch ex As Exception")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
    '''    ArClase.WriteLine(Tabulador2 & "End Try")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Crea() As String
    '''    Dim wtabla As New Tablas
    '''    Dim Campo As String
    '''    Dim Cadena As String
    '''    Dim CadValores As String
    '''    Dim IsLlave As String
    '''    Dim I As Integer
    '''    Dim Tipo As String
    '''    Dim Longitud As String
    '''    Dim total As Integer
    '''    ArClase.WriteLine(Tabulador & "Public Function Crear() as String")
    '''    ArClase.WriteLine(Tabulador2 & "Dim cnn As SqlConnection")
    '''    ArClase.WriteLine(Tabulador2 & "Dim da As SqlDataAdapter")
    '''    ArClase.WriteLine(Tabulador2 & "Dim dt As New Datatable(" & Chr(34) & ArcClase & Chr(34) & ")")
    '''    ArClase.WriteLine(Tabulador2 & "cnn = New SqlConnection(Cadenaconexion)")
    '''    ArClase.WriteLine(Tabulador2 & "da = New SqlDataAdapter(CadenaSelect,cnn)")
    '''    ArClase.WriteLine(Tabulador2 & "da.missingSchemaAction = MissingSchemaAction.AddWithKey")
    '''    ArClase.WriteLine(Tabulador2 & "Dim sCommand As String")
    '''    total = wtabla.DimensionCampos - 2
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        IsLlave = wtabla.Campos(6, I).ToString
    '''        If IsLlave = "True" Then
    '''        Else
    '''            If I = total Then
    '''                Cadena = Cadena & Campo & ")"
    '''                CadValores = CadValores & "@" & Campo & ")"
    '''            Else
    '''                Cadena = Cadena & Campo & ", "
    '''                CadValores = CadValores & "@" & Campo & ", "
    '''            End If
    '''        End If
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & "sCommand =" & Chr(34) & "INSERT INTO " & _
    '''    ArcClase & " (" & Cadena & " VALUES (" & CadValores & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "da.InsertCommand = New Sqlcommand(sCommand, Cnn)")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        Tipo = wtabla.Campos(12, I).ToString
    '''        Longitud = wtabla.Campos(2, I).ToString
    '''        Select Case UCase(Tipo)
    '''            Case "SYSTEM.STRING"
    '''                Tipo = "SqlDbType.NvarChar"
    '''            Case "SYSTEM.INT32"
    '''                Tipo = "SqlDbType.Int"
    '''                Longitud = "0"
    '''            Case "SYSTEM.DATETIME"
    '''                Tipo = "SqlDbType.Datetime"
    '''                Longitud = "0"
    '''        End Select
    '''        ArClase.WriteLine(Tabulador2 & "da.InsertCommand.Parameters.Add(" & Chr(34) & "@" & Campo & Chr(34) & ", " & Tipo & ", " & Longitud & ", " & Chr(34) & Campo & Chr(34) & ")")
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & "Try")
    '''    ArClase.WriteLine(Tabulador3 & "da.Fill(dt)")
    '''    ArClase.WriteLine(Tabulador2 & "Catch ex As Exception")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
    '''    ArClase.WriteLine(Tabulador2 & "End Try")
    '''    ArClase.WriteLine(Tabulador2 & "Nuevo" & ArcClase & "(dt,me)")
    '''    ArClase.WriteLine(Tabulador2 & "Try")
    '''    ArClase.WriteLine(Tabulador3 & "da.Update(dt)")
    '''    ArClase.WriteLine(Tabulador3 & "dt.AcceptChanges()")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & " Se ha Creado un nuevo" & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "Catch ex As Exception")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
    '''    ArClase.WriteLine(Tabulador2 & "End Try")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Borrado() As String
    '''    Dim wtabla As New Tablas
    '''    Dim I As Integer
    '''    Dim Campo As String
    '''    Dim Llave As String
    '''    Dim isLlave As String
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        isLlave = wtabla.Campos(6, I).ToString
    '''        If isLlave = "True" Then
    '''            Campo = wtabla.Campos(0, I).ToString
    '''            Exit For
    '''        End If
    '''    Next
    '''    ArClase.WriteLine(Tabulador & "Public Function Borrar() as String")
    '''    ArClase.WriteLine(Tabulador2 & "Dim Sel as String = " & Chr(34) & "Select * From " & ArcClase & " Where " & Campo & " = " & Chr(34) & " & Me." & Campo & ".ToString()")
    '''    ArClase.WriteLine(Tabulador2 & "Return Borrar(Sel)")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
    ''''********************************************************************************
    '''Public Function Borra2() As String
    '''    Dim wtabla As New Tablas
    '''    Dim I As Integer
    '''    Dim Campo As String
    '''    Dim Cadena As String
    '''    Dim Tipo As String
    '''    Dim IsLlave As String
    '''    Dim Longitud As String
    '''    Dim Cwhere As String
    '''    ArClase.WriteLine(Tabulador & "Public Function Borrar(Sel as String) as String")
    '''    ArClase.WriteLine(Tabulador2 & "Dim cnn As SqlConnection")
    '''    ArClase.WriteLine(Tabulador2 & "Dim da as SqlDataAdapter")
    '''    ArClase.WriteLine(Tabulador2 & "Dim dt as New Datatable(" & Chr(34) & ArcClase & Chr(34) & ")")
    '''    ArClase.WriteLine(Tabulador2 & "cnn = New SqlConnection(Cadenaconexion)")
    '''    ArClase.WriteLine(Tabulador2 & "da = New SqlDataAdapter(sel,cnn)")
    '''    ArClase.WriteLine(Tabulador2 & "cnn = New SqlConnection(Cadenaconexion)")
    '''    ArClase.WriteLine(Tabulador2 & "da = New SqlDataAdapter(Sel,cnn)")
    '''    ArClase.WriteLine(Tabulador2 & "da.missingSchemaAction = MissingSchemaAction.AddWithKey")
    '''    ArClase.WriteLine(Tabulador2 & "Dim sCommand As String")
    '''    For I = 0 To wtabla.DimensionCampos - 1
    '''        Campo = wtabla.Campos(0, I).ToString()
    '''        IsLlave = wtabla.Campos(6, I).ToString
    '''        If IsLlave = "True" Then
    '''            Cwhere = Campo
    '''            Tipo = wtabla.Campos(12, I).ToString
    '''            Longitud = wtabla.Campos(2, I).ToString
    '''            Select Case UCase(Tipo)
    '''                Case "SYSTEM.STRING"
    '''                    Tipo = "SqlDbType.NvarChar"
    '''                Case "SYSTEM.INT32"
    '''                    Tipo = "SqlDbType.Int"
    '''                    Longitud = "0"
    '''            End Select
    '''        Else
    '''            If I = wtabla.DimensionCampos - 1 Then
    '''                Cadena = Cadena & Campo & " = @" & Campo & " "
    '''            Else
    '''                Cadena = Cadena & Campo & " = @" & Campo & ", "
    '''            End If
    '''        End If
    '''    Next
    '''    ArClase.WriteLine(Tabulador2 & "sCommand =" & Chr(34) & "DELETE FROM " & ArcClase & " Where (" & Cwhere & " = @p1)" & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "da.DeleteCommand = New Sqlcommand(sCommand, Cnn)")
    '''    ArClase.WriteLine(Tabulador2 & "da.DeleteCommand.parameters.Add(" & Chr(34) & "@p1" & Chr(34) & "," & Tipo & ", " & Longitud & ", " & Chr(34) & Cwhere & Chr(34) & ")")
    '''    ArClase.WriteLine(Tabulador2 & "da.fill(Dt)")
    '''    ArClase.WriteLine(Tabulador2 & "If dt.rows.count=0 Then")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: No Hay Datos" & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "Else")
    '''    ArClase.WriteLine(Tabulador3 & "dt.Rows(0).Delete()")
    '''    ArClase.WriteLine(Tabulador2 & "End If")
    '''    ArClase.WriteLine(Tabulador2 & "Try")
    '''    ArClase.WriteLine(Tabulador3 & "da.Update(dt)")
    '''    ArClase.WriteLine(Tabulador3 & "dt.AcceptChanges()")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & " Borrado Satisfactoriamente" & Chr(34))
    '''    ArClase.WriteLine(Tabulador2 & "Catch ex As Exception")
    '''    ArClase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
    '''    ArClase.WriteLine(Tabulador2 & "End Try")
    '''    ArClase.WriteLine(Tabulador & "End Function")
    '''End Function
End Class
