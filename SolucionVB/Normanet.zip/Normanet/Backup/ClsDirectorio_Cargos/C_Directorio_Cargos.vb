
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_Directorio_Cargos Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 27/11/2006 09:24:07 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class C_Directorio_Cargos

     '''''''Declaracion de Variables Privadas
     Private dsC_Directorio_Cargos AS New DataSet
    Private _Descripcion As String
     Private _Cve_Directorio as System.String
     Private _Cve_Cargo as System.Int32
     Private _Cve_Comite as System.String
     Private _Cve_ComiteTec as System.String
     Private _Cve_Subcomite as System.String
     Private _Cve_Grupo as System.String
    Private _sector As String
    Private _representacion As String
    Private _Encontrado As Boolean
    Private _Consecutivo As Integer
    Private _Icontador As Integer
    Private _Bandera As Integer
    Private _Id_sector As Integer
    Private _Id_representacion As Integer
    Private _IdNombramiento As Integer
    Private _Vencidos As Boolean
    Private _Pertenece As String
    Private _Filtrar As Boolean

    Private sSql As String

    Private _F_VigenciaInicio As String
    Private _F_VigenciaFinal As String

    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo
    Private Directoriocargos As ClsDirectorio_Cargos.C_Directorio_Cargos


    '''''''Declaracion de Propiedades publicas
    Public Property F_VigenciaInicio() As String
        Get
            Return _F_VigenciaInicio
        End Get
        Set(ByVal Value As String)
            _F_VigenciaInicio = Value
        End Set
    End Property

    Public Property F_VigenciaFinal() As String
        Get
            Return _F_VigenciaFinal
        End Get
        Set(ByVal Value As String)
            _F_VigenciaFinal = Value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As String)
            _Descripcion = Value
        End Set
    End Property

    Public Property Cve_Directorio() As System.String
        Get
            Return _Cve_Directorio
        End Get
        Set(ByVal Value As System.String)
            _Cve_Directorio = Value
        End Set
    End Property

    Public Property Cve_Cargo() As System.Int32
        Get
            Return _Cve_Cargo
        End Get
        Set(ByVal Value As System.Int32)
            _Cve_Cargo = Value
        End Set
    End Property

    Public Property Cve_Comite() As System.String
        Get
            Return _Cve_Comite
        End Get
        Set(ByVal Value As System.String)
            _Cve_Comite = Value
        End Set
    End Property

    Public Property Cve_ComiteTec() As System.String
        Get
            Return _Cve_ComiteTec
        End Get
        Set(ByVal Value As System.String)
            _Cve_ComiteTec = Value
        End Set
    End Property

    Public Property Cve_Subcomite() As System.String
        Get
            Return _Cve_Subcomite
        End Get
        Set(ByVal Value As System.String)
            _Cve_Subcomite = Value
        End Set
    End Property

    Public Property Cve_Grupo() As System.String
        Get
            Return _Cve_Grupo
        End Get
        Set(ByVal Value As System.String)
            _Cve_Grupo = Value
        End Set
    End Property

    Public Property Pertenece() As String
        Get
            Return _Pertenece
        End Get
        Set(ByVal Value As String)
            _Pertenece = Value
        End Set
    End Property

    Public Property Vencidos() As Boolean
        Get
            Return _Vencidos
        End Get
        Set(ByVal Value As Boolean)
            _Vencidos = Value
        End Set
    End Property

    Public Property Filtrar() As Boolean
        Get
            Return _Filtrar
        End Get
        Set(ByVal Value As Boolean)
            _Filtrar = Value
        End Set
    End Property

    Public Property sector() As System.String
        Get
            Return _sector
        End Get
        Set(ByVal Value As System.String)
            _sector = Value
        End Set
    End Property

    Public Property Id_sector() As Integer
        Get
            Return _Id_sector
        End Get
        Set(ByVal Value As Integer)
            _Id_sector = Value
        End Set
    End Property

    Public Property Id_representacion() As Integer
        Get
            Return _Id_representacion
        End Get
        Set(ByVal Value As Integer)
            _Id_representacion = Value
        End Set
    End Property

    Public Property IdNombramiento() As Integer
        Get
            Return _IdNombramiento
        End Get
        Set(ByVal Value As Integer)
            _IdNombramiento = Value
        End Set
    End Property

    Public Property representacion() As System.String
        Get
            Return _representacion
        End Get
        Set(ByVal Value As System.String)
            _representacion = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Consecutivo() As Integer
        Get
            Return _Consecutivo
        End Get
        Set(ByVal Value As Integer)
            _Consecutivo = Value
        End Set
    End Property
    Public Property Contador() As Integer
        Get
            Return _Icontador
        End Get
        Set(ByVal Value As Integer)
            _Icontador = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista() As DataTable
        Dim da As SqlDataAdapter
        Dim sel As String
        sel = "Select consecutivo from C_Directorio_Cargos order by consecutivo desc"
        Dim dt As New DataTable("C_Directorio_Cargos")
        Try
            da = New SqlDataAdapter(sel, cn)
            da.Fill(dt)
            cn.Close()
            If dt.Rows.Count > 0 Then
                _Consecutivo = dt.Rows(0).Item("consecutivo")
            End If
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar() As DataTable
        Dim Dt As New DataTable("C_Encontrado")
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        ''sSql = "SELECT     dbo.C_Cargos.Descripcion, dbo.C_Directorio_Cargos.Cve_Comite, dbo.C_Directorio_Cargos.Cve_ComiteTec, dbo.C_Directorio_Cargos.Cve_Subcomite, "
        ''sSql = sSql + " dbo.C_Directorio_Cargos.Cve_Grupo, dbo.C_Sector.Descripcion AS Sector, dbo.C_Representacion.Descripcion AS Representacion,dbo.C_Directorio_Cargos.Consecutivo"
        ''sSql = sSql + " FROM dbo.C_Cargos INNER JOIN"
        ''sSql = sSql + " dbo.C_Directorio_Cargos ON dbo.C_Cargos.ID_Cargo = dbo.C_Directorio_Cargos.Cve_Cargo INNER JOIN"
        ''sSql = sSql + "  dbo.C_Sector ON dbo.C_Directorio_Cargos.Id_sector = dbo.C_Sector.ID_Sector INNER JOIN"
        ''sSql = sSql + " dbo.C_Representacion ON dbo.C_Directorio_Cargos.Id_representacion = dbo.C_Representacion.ID_Representacion INNER JOIN"
        ''sSql = sSql + "  dbo.C_Directorio ON dbo.C_Directorio_Cargos.Cve_Directorio = dbo.C_Directorio.ID_Directorio"
        ''sSql = sSql + " WHERE cve_directorio ='" & _Cve_Directorio & "' "

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Directorio_Cargos"

        cmd.Parameters.Add("@Cve_Directorio", _Cve_Directorio)
        cmd.Parameters.Add("@Bandera", 7)

        Dim da As New SqlDataAdapter(cmd)
        da.Fill(Dt)

        da.Dispose()
        cmd.Dispose()
        cn.Close()

        ''Dim da As New SqlDataAdapter(sSql, cn)
        ''If cn.State = 1 Then cn.Close()
        ''cn.Open()
        ''da.Fill(Dt)
        ''cn.Close()
        If Dt.Rows.Count > 0 Then
            _Descripcion = Dt.Rows(0).Item("Descripcion")
            ' _Cve_Directorio = Dt.Rows(0).Item("Cve_Directorio")
            _Cve_Comite = Dt.Rows(0).Item("Cve_Comite")
            _Cve_ComiteTec = Dt.Rows(0).Item("Cve_ComiteTec")
            _Cve_Subcomite = Dt.Rows(0).Item("Cve_Subcomite")
            _Cve_Grupo = Dt.Rows(0).Item("Cve_Grupo")
            _sector = Dt.Rows(0).Item("sector")
            _representacion = Dt.Rows(0).Item("representacion")
            _Encontrado = True
            _Consecutivo = Dt.Rows(0).Item("Consecutivo")
            _Icontador = Dt.Rows.Count
        Else
            '_Consecutivo = 0
            _Cve_Directorio = ""
            _Descripcion = ""
            _Cve_Comite = ""
            _Cve_ComiteTec = ""
            _Cve_Subcomite = ""
            _Cve_Grupo = ""
            _sector = 0
            _representacion = 0
            Encontrado = False
            _Consecutivo = 0
            _Icontador = 0
        End If
        'dsC_Directorio_Cargos.Tables("C_Encontrado").Clear()
        Return Dt
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza() As String

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Directorio_Cargos"
        'If _Bandera = 1 Then
        '    _Consecutivo = _Consecutivo + 1
        'End If

        cmd.Parameters.Add("@Consecutivo", _Consecutivo)
        cmd.Parameters.Add("@Cve_Directorio", _Cve_Directorio)
        cmd.Parameters.Add("@Cve_Cargo", _Cve_Cargo)
        cmd.Parameters.Add("@Cve_Comite", _Cve_Comite)
        cmd.Parameters.Add("@Cve_ComiteTec", _Cve_ComiteTec)
        cmd.Parameters.Add("@Cve_Subcomite", _Cve_Subcomite)
        cmd.Parameters.Add("@Cve_Grupo", _Cve_Grupo)
        cmd.Parameters.Add("@id_sector", _sector)
        cmd.Parameters.Add("@ID_representacion", _representacion)

        cmd.Parameters.Add("@F_VigenciaInicio", _F_VigenciaInicio)
        cmd.Parameters.Add("@F_VigenciaFinal", _F_VigenciaFinal)
        cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)

        cmd.Parameters.Add("@Bandera", _Bandera)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Sub LlenarDatos()
        Dim dt As New DataTable("Encontrados")

        Try

            cn.Open()
            Dim cmd As New SqlCommand
            cmd.CommandText = "sp_Directorio_Cargos"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cn
            cmd.Parameters.Add("@Consecutivo", _Consecutivo)
            cmd.Parameters.Add("@Cve_Directorio", _Cve_Directorio)
            cmd.Parameters.Add("@Cve_Cargo", _Cve_Cargo)
            cmd.Parameters.Add("@Cve_Comite", _Cve_Comite)
            cmd.Parameters.Add("@Cve_ComiteTec", _Cve_ComiteTec)
            cmd.Parameters.Add("@Cve_Subcomite", _Cve_Subcomite)
            cmd.Parameters.Add("@Cve_Grupo", _Cve_Grupo)
            cmd.Parameters.Add("@Id_sector", _Id_sector)
            cmd.Parameters.Add("@Id_representacion", _Id_representacion)
            cmd.Parameters.Add("@F_VigenciaInicio", _F_VigenciaInicio)
            cmd.Parameters.Add("@F_VigenciaFinal", _F_VigenciaFinal)
            cmd.Parameters.Add("@Bandera", _Bandera)
            cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)

            da.Dispose()
            cmd.Dispose()

            If dt.Rows.Count > 0 Then
                _Consecutivo = IIf(IsDBNull(dt.Rows(0).Item("Consecutivo")) = True, Nothing, dt.Rows(0).Item("Consecutivo"))
                _Cve_Directorio = IIf(IsDBNull(dt.Rows(0).Item("Cve_Directorio")) = True, Nothing, dt.Rows(0).Item("Cve_Directorio"))
                _Cve_Cargo = IIf(IsDBNull(dt.Rows(0).Item("Cve_Cargo")) = True, Nothing, dt.Rows(0).Item("Cve_Cargo"))
                _Cve_Comite = IIf(IsDBNull(dt.Rows(0).Item("Cve_Comite")) = True, Nothing, dt.Rows(0).Item("Cve_Comite"))
                _Cve_ComiteTec = IIf(IsDBNull(dt.Rows(0).Item("Cve_ComiteTec")) = True, Nothing, dt.Rows(0).Item("Cve_ComiteTec"))
                _Cve_Subcomite = IIf(IsDBNull(dt.Rows(0).Item("Cve_Subcomite")) = True, Nothing, dt.Rows(0).Item("Cve_Subcomite"))
                _Cve_Grupo = IIf(IsDBNull(dt.Rows(0).Item("Cve_Grupo")) = True, Nothing, dt.Rows(0).Item("Cve_Grupo"))
                _Id_sector = IIf(IsDBNull(dt.Rows(0).Item("Id_sector")) = True, Nothing, dt.Rows(0).Item("Id_sector"))
                _Id_representacion = IIf(IsDBNull(dt.Rows(0).Item("Id_representacion")) = True, Nothing, dt.Rows(0).Item("Id_representacion"))
                _F_VigenciaInicio = IIf(IsDBNull(dt.Rows(0).Item("F_VigenciaInicio")) = True, Nothing, dt.Rows(0).Item("F_VigenciaInicio"))
                _F_VigenciaFinal = IIf(IsDBNull(dt.Rows(0).Item("F_VigenciaFinal")) = True, Nothing, dt.Rows(0).Item("F_VigenciaFinal"))
                _IdNombramiento = IIf(IsDBNull(dt.Rows(0).Item("IdNombramiento")) = True, Nothing, dt.Rows(0).Item("IdNombramiento"))
            Else
                _Consecutivo = Nothing
                _Cve_Directorio = Nothing
                _Cve_Cargo = Nothing
                _Cve_Comite = Nothing
                _Cve_ComiteTec = Nothing
                _Cve_Subcomite = Nothing
                _Cve_Grupo = Nothing
                _Id_sector = Nothing
                _Id_representacion = Nothing
                _F_VigenciaInicio = Nothing
                _F_VigenciaFinal = Nothing
            End If

        Finally
            cn.Close()
        End Try
    End Sub

    Public Function ListarDatos() As DataTable
        Dim dt As New DataTable("Encontrados")

        Try
            cn.Open()
            Dim cmd As New SqlCommand
            cmd.CommandText = "sp_Directorio_Cargos"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cn
            cmd.Parameters.Add("@Consecutivo", _Consecutivo)
            cmd.Parameters.Add("@Cve_Directorio", _Cve_Directorio)
            cmd.Parameters.Add("@Cve_Cargo", _Cve_Cargo)
            cmd.Parameters.Add("@Cve_Comite", _Cve_Comite)
            cmd.Parameters.Add("@Cve_ComiteTec", _Cve_ComiteTec)
            cmd.Parameters.Add("@Cve_Subcomite", _Cve_Subcomite)
            cmd.Parameters.Add("@Cve_Grupo", _Cve_Grupo)
            cmd.Parameters.Add("@Id_sector", _Id_sector)
            cmd.Parameters.Add("@Id_representacion", _Id_representacion)
            cmd.Parameters.Add("@F_VigenciaInicio", _F_VigenciaInicio)
            cmd.Parameters.Add("@F_VigenciaFinal", _F_VigenciaFinal)
            cmd.Parameters.Add("@Vencidos", _Vencidos)
            cmd.Parameters.Add("@Pertenece", _Pertenece)
            cmd.Parameters.Add("@Filtrar", _Filtrar)
            cmd.Parameters.Add("@Bandera", _Bandera)
            cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            da.Dispose()
            cmd.Dispose()
        Finally
            cn.Close()
        End Try
        Return dt
    End Function

    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)

        cmd.Parameters.Add("@Consecutivo", SqlDbType.Int, 0, "_Consecutivo")
        cmd.Parameters.Add("@Cve_Directorio", SqlDbType.NVarChar, 8, "_Cve_Directorio")
        cmd.Parameters.Add("@Cve_Cargo", SqlDbType.Int, 0, "_Cve_Cargo")
        cmd.Parameters.Add("@Cve_Comite", SqlDbType.NVarChar, 100, "_Cve_Comite")
        cmd.Parameters.Add("@Cve_ComiteTec", SqlDbType.NVarChar, 100, "_Cve_ComiteTec")
        cmd.Parameters.Add("@Cve_Subcomite", SqlDbType.NVarChar, 100, "_Cve_Subcomite")
        cmd.Parameters.Add("@Cve_Grupo", SqlDbType.NVarChar, 20, "_Cve_Grupo")
        cmd.Parameters.Add("@sector", SqlDbType.NVarChar, 100, "_sector")
        cmd.Parameters.Add("@representacion", SqlDbType.NVarChar, 100, "_representacion")
        cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
