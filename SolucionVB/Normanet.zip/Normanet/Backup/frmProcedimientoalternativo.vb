Public Class frmProcedimientoalternativo
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents cmdActa As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents pnlLectura As System.Windows.Forms.Panel
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker4 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker5 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker6 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker7 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents pnlComentarios As System.Windows.Forms.Panel
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtdomicilio As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtempresa As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents tvTemasDT As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmProcedimientoalternativo))
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.cmdActa = New System.Windows.Forms.ToolBarButton
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.pnlLectura = New System.Windows.Forms.Panel
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.DateTimePicker4 = New System.Windows.Forms.DateTimePicker
        Me.Label17 = New System.Windows.Forms.Label
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.DateTimePicker5 = New System.Windows.Forms.DateTimePicker
        Me.Label18 = New System.Windows.Forms.Label
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.DateTimePicker6 = New System.Windows.Forms.DateTimePicker
        Me.Label19 = New System.Windows.Forms.Label
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.DateTimePicker7 = New System.Windows.Forms.DateTimePicker
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.tvTemasDT = New System.Windows.Forms.TreeView
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.pnlComentarios = New System.Windows.Forms.Panel
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtdomicilio = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtempresa = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtnombre = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.pnlLectura.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.pnlComentarios.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'TVPNN
        '
        Me.TVPNN.ImageIndex = -1
        Me.TVPNN.Location = New System.Drawing.Point(8, 2)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = -1
        Me.TVPNN.Size = New System.Drawing.Size(176, 464)
        Me.TVPNN.TabIndex = 18
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'cmdActa
        '
        Me.cmdActa.ImageIndex = 6
        Me.cmdActa.Text = "Acta Aprobaci�n"
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.CmdSalir, Me.cmdActa})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 560)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(688, 62)
        Me.tlbBotonera.TabIndex = 19
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(192, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(488, 552)
        Me.TabControl1.TabIndex = 21
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.pnlLectura)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(480, 526)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tema"
        '
        'pnlLectura
        '
        Me.pnlLectura.Controls.Add(Me.TextBox7)
        Me.pnlLectura.Controls.Add(Me.Label2)
        Me.pnlLectura.Controls.Add(Me.TextBox13)
        Me.pnlLectura.Controls.Add(Me.DateTimePicker4)
        Me.pnlLectura.Controls.Add(Me.Label17)
        Me.pnlLectura.Controls.Add(Me.TextBox14)
        Me.pnlLectura.Controls.Add(Me.DateTimePicker5)
        Me.pnlLectura.Controls.Add(Me.Label18)
        Me.pnlLectura.Controls.Add(Me.TextBox15)
        Me.pnlLectura.Controls.Add(Me.DateTimePicker6)
        Me.pnlLectura.Controls.Add(Me.Label19)
        Me.pnlLectura.Controls.Add(Me.TextBox16)
        Me.pnlLectura.Controls.Add(Me.DateTimePicker7)
        Me.pnlLectura.Controls.Add(Me.Label20)
        Me.pnlLectura.Controls.Add(Me.Label21)
        Me.pnlLectura.Controls.Add(Me.TextBox17)
        Me.pnlLectura.Controls.Add(Me.ComboBox1)
        Me.pnlLectura.Controls.Add(Me.tvTemasDT)
        Me.pnlLectura.Location = New System.Drawing.Point(8, 16)
        Me.pnlLectura.Name = "pnlLectura"
        Me.pnlLectura.Size = New System.Drawing.Size(440, 496)
        Me.pnlLectura.TabIndex = 22
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(168, 8)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(152, 20)
        Me.TextBox7.TabIndex = 103
        Me.TextBox7.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 16)
        Me.Label2.TabIndex = 102
        Me.Label2.Text = "Clasificaci�n"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(168, 168)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(96, 20)
        Me.TextBox13.TabIndex = 90
        Me.TextBox13.Text = ""
        '
        'DateTimePicker4
        '
        Me.DateTimePicker4.CustomFormat = "dd/mm/yyyy"
        Me.DateTimePicker4.Location = New System.Drawing.Point(168, 168)
        Me.DateTimePicker4.Name = "DateTimePicker4"
        Me.DateTimePicker4.Size = New System.Drawing.Size(112, 20)
        Me.DateTimePicker4.TabIndex = 88
        Me.DateTimePicker4.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(16, 168)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(152, 32)
        Me.Label17.TabIndex = 89
        Me.Label17.Text = "Fecha de Fin De emisi�n de comentarios "
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(168, 128)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(96, 20)
        Me.TextBox14.TabIndex = 87
        Me.TextBox14.Text = ""
        '
        'DateTimePicker5
        '
        Me.DateTimePicker5.CustomFormat = "dd/mm/yyyy"
        Me.DateTimePicker5.Location = New System.Drawing.Point(168, 128)
        Me.DateTimePicker5.Name = "DateTimePicker5"
        Me.DateTimePicker5.Size = New System.Drawing.Size(112, 20)
        Me.DateTimePicker5.TabIndex = 85
        Me.DateTimePicker5.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(16, 128)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(144, 32)
        Me.Label18.TabIndex = 86
        Me.Label18.Text = "Fecha de Inicio De emisi�n de comentarios "
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(168, 96)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(96, 20)
        Me.TextBox15.TabIndex = 84
        Me.TextBox15.Text = ""
        '
        'DateTimePicker6
        '
        Me.DateTimePicker6.CustomFormat = "dd/mm/yyyy"
        Me.DateTimePicker6.Location = New System.Drawing.Point(168, 96)
        Me.DateTimePicker6.Name = "DateTimePicker6"
        Me.DateTimePicker6.Size = New System.Drawing.Size(112, 20)
        Me.DateTimePicker6.TabIndex = 82
        Me.DateTimePicker6.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(16, 96)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(152, 24)
        Me.Label19.TabIndex = 83
        Me.Label19.Text = "Fecha de Fin Responsable"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(168, 64)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(96, 20)
        Me.TextBox16.TabIndex = 81
        Me.TextBox16.Text = ""
        '
        'DateTimePicker7
        '
        Me.DateTimePicker7.CustomFormat = "dd/mm/yyyy"
        Me.DateTimePicker7.Location = New System.Drawing.Point(168, 64)
        Me.DateTimePicker7.Name = "DateTimePicker7"
        Me.DateTimePicker7.Size = New System.Drawing.Size(112, 20)
        Me.DateTimePicker7.TabIndex = 79
        Me.DateTimePicker7.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(16, 64)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(152, 16)
        Me.Label20.TabIndex = 80
        Me.Label20.Text = "Fecha de Inicio Responsable"
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(16, 32)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(112, 24)
        Me.Label21.TabIndex = 76
        Me.Label21.Text = "Responsable Tema:"
        '
        'TextBox17
        '
        Me.TextBox17.Enabled = False
        Me.TextBox17.Location = New System.Drawing.Point(168, 32)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(248, 20)
        Me.TextBox17.TabIndex = 77
        Me.TextBox17.Text = ""
        '
        'ComboBox1
        '
        Me.ComboBox1.ItemHeight = 13
        Me.ComboBox1.Location = New System.Drawing.Point(176, 32)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(256, 21)
        Me.ComboBox1.TabIndex = 78
        '
        'tvTemasDT
        '
        Me.tvTemasDT.ImageIndex = -1
        Me.tvTemasDT.Location = New System.Drawing.Point(16, 216)
        Me.tvTemasDT.Name = "tvTemasDT"
        Me.tvTemasDT.SelectedImageIndex = -1
        Me.tvTemasDT.Size = New System.Drawing.Size(416, 272)
        Me.tvTemasDT.TabIndex = 30
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.pnlComentarios)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(480, 526)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Comentarios"
        '
        'pnlComentarios
        '
        Me.pnlComentarios.Controls.Add(Me.TextBox3)
        Me.pnlComentarios.Controls.Add(Me.Label10)
        Me.pnlComentarios.Controls.Add(Me.TextBox1)
        Me.pnlComentarios.Controls.Add(Me.Label9)
        Me.pnlComentarios.Controls.Add(Me.TextBox2)
        Me.pnlComentarios.Controls.Add(Me.Label8)
        Me.pnlComentarios.Controls.Add(Me.txtdomicilio)
        Me.pnlComentarios.Controls.Add(Me.Label7)
        Me.pnlComentarios.Controls.Add(Me.txtempresa)
        Me.pnlComentarios.Controls.Add(Me.Label6)
        Me.pnlComentarios.Controls.Add(Me.txtnombre)
        Me.pnlComentarios.Controls.Add(Me.Label1)
        Me.pnlComentarios.Controls.Add(Me.TextBox8)
        Me.pnlComentarios.Controls.Add(Me.Label3)
        Me.pnlComentarios.Controls.Add(Me.TextBox9)
        Me.pnlComentarios.Controls.Add(Me.Label4)
        Me.pnlComentarios.Controls.Add(Me.TextBox10)
        Me.pnlComentarios.Controls.Add(Me.Label5)
        Me.pnlComentarios.Controls.Add(Me.TextBox11)
        Me.pnlComentarios.Controls.Add(Me.Label15)
        Me.pnlComentarios.Controls.Add(Me.TextBox12)
        Me.pnlComentarios.Controls.Add(Me.Label16)
        Me.pnlComentarios.Controls.Add(Me.ComboBox2)
        Me.pnlComentarios.Location = New System.Drawing.Point(24, 24)
        Me.pnlComentarios.Name = "pnlComentarios"
        Me.pnlComentarios.Size = New System.Drawing.Size(440, 416)
        Me.pnlComentarios.TabIndex = 0
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(128, 176)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(112, 20)
        Me.TextBox3.TabIndex = 144
        Me.TextBox3.Text = ""
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(8, 176)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(72, 16)
        Me.Label10.TabIndex = 143
        Me.Label10.Text = "Mail"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(128, 144)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(112, 20)
        Me.TextBox1.TabIndex = 142
        Me.TextBox1.Text = ""
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(8, 144)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 16)
        Me.Label9.TabIndex = 141
        Me.Label9.Text = "Fax"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(128, 112)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(112, 20)
        Me.TextBox2.TabIndex = 140
        Me.TextBox2.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(8, 112)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 16)
        Me.Label8.TabIndex = 139
        Me.Label8.Text = "Tel�fono"
        '
        'txtdomicilio
        '
        Me.txtdomicilio.Location = New System.Drawing.Point(128, 80)
        Me.txtdomicilio.Name = "txtdomicilio"
        Me.txtdomicilio.Size = New System.Drawing.Size(304, 20)
        Me.txtdomicilio.TabIndex = 138
        Me.txtdomicilio.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 16)
        Me.Label7.TabIndex = 137
        Me.Label7.Text = "Domicilio"
        '
        'txtempresa
        '
        Me.txtempresa.Location = New System.Drawing.Point(128, 48)
        Me.txtempresa.Name = "txtempresa"
        Me.txtempresa.Size = New System.Drawing.Size(304, 20)
        Me.txtempresa.TabIndex = 136
        Me.txtempresa.Text = ""
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 16)
        Me.Label6.TabIndex = 135
        Me.Label6.Text = "Empresa"
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(128, 16)
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(304, 20)
        Me.txtnombre.TabIndex = 134
        Me.txtnombre.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 16)
        Me.Label1.TabIndex = 133
        Me.Label1.Text = "Nombre"
        '
        'TextBox8
        '
        Me.TextBox8.AutoSize = False
        Me.TextBox8.Location = New System.Drawing.Point(128, 368)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox8.Size = New System.Drawing.Size(272, 40)
        Me.TextBox8.TabIndex = 132
        Me.TextBox8.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 368)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 16)
        Me.Label3.TabIndex = 131
        Me.Label3.Text = "Propuesta de Cambios"
        '
        'TextBox9
        '
        Me.TextBox9.AutoSize = False
        Me.TextBox9.Location = New System.Drawing.Point(128, 320)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox9.Size = New System.Drawing.Size(272, 40)
        Me.TextBox9.TabIndex = 130
        Me.TextBox9.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 320)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 16)
        Me.Label4.TabIndex = 129
        Me.Label4.Text = "Comentarios"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(128, 288)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(112, 20)
        Me.TextBox10.TabIndex = 128
        Me.TextBox10.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 288)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(120, 16)
        Me.Label5.TabIndex = 127
        Me.Label5.Text = "P�rrafo/Tabla/Figura"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(128, 256)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(112, 20)
        Me.TextBox11.TabIndex = 126
        Me.TextBox11.Text = ""
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(8, 256)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 16)
        Me.Label15.TabIndex = 125
        Me.Label15.Text = "Cap�tulo Inciso"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(128, 216)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(256, 20)
        Me.TextBox12.TabIndex = 123
        Me.TextBox12.Text = ""
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(8, 224)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(104, 16)
        Me.Label16.TabIndex = 122
        Me.Label16.Text = "Tipo de Comentario"
        '
        'ComboBox2
        '
        Me.ComboBox2.ItemHeight = 13
        Me.ComboBox2.Location = New System.Drawing.Point(128, 216)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(272, 21)
        Me.ComboBox2.TabIndex = 124
        '
        'frmProcedimientoalternativo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(688, 622)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TVPNN)
        Me.Name = "frmProcedimientoalternativo"
        Me.Text = "frmProcedimientoalternativo"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.pnlLectura.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.pnlComentarios.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim sEtapa As String
    Dim oTablaPNN As DataTable
    Private clsTree As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim RegGT As DataRow
    Dim oTablaDPy As DataTable
    Dim nodo1 As New TreeNode
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private ObjDt As New ClsDt.P_DT(0, gUsuario, gPasswordSql)
    Dim Matriz As Array
    Dim Matriz_Dt As Array
    Dim svariable As String
    Dim sPlan As String
    Dim stema As String
    Dim sraiz As String
    Dim bandera As Integer
    Dim sComite As String
    Dim sCt As String
    Dim sSc As String
    Dim sGt As String

    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVPNN.AfterSelect
        If PnlLectura.Visible = True Then

            svariable = e.Node.FullPath
            Matriz = Split(svariable, "\")
            Select Case Matriz.Length
                Case 1
                    sraiz = Matriz(0)
                    sEtapa = "Inactivo"
                    Call Habilita(sEtapa)

                Case (2)
                    sPlan = Matriz(1)
                    sEtapa = "Plan"
                    Call Habilita(sEtapa)
                Case 3
                    sPlan = Matriz(1)
                    stema = Matriz(2)
                    sEtapa = "Tema"
                    Call Habilita(sEtapa)
            End Select
            If sPlan <> "" And stema <> "" Then
                Call Llena_Temas(sPlan, stema)
            End If
            'llena_tvcomites()
        End If
    End Sub
    Private Sub Llena_Temas(ByVal splan As String, ByVal stema As String)
        Dim sref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(splan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

        ObjDt.Buscar(splan, stema, sref)
    End Sub

    Private Sub frmProcedimientoalternativo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sEtapa = "Inactivo"
        Call Habilita(sEtapa)
        oTablaPNN = clsTree.ListaPNN("")
        TVPNN.BeginUpdate()
        nodo = TVPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = TVPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = clsTree.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
            Next
        Next
        TVPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TVPNN.Sorted = True
        'PnlLectura.Visible = True
        'PnlAgrega.Visible = False
    End Sub


    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PnlLectura_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                sEtapa = "Agregar"
                Call Habilita(sEtapa)
                Llena_TvDt()
                'Call Carga_Combos()
            Case 1 'Editar
                sEtapa = "Editar"
                Call Habilita(sEtapa)
                'llena_tvcomites()

            Case 2 'Deshacer
                sEtapa = "Nulo"
                Call Habilita(sEtapa)
                Call Limpia_Campos()
            Case 3 'Salvar
                If sEtapa = "Editar" Then
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    '   Call Actualizar()
                Else
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    '  Call Insertar()
                End If
            Case 4
                MsgBox("Esta seguro de Borrar este Tema?", MsgBoxStyle.OKCancel, "Atenci�n")
                If MsgBoxResult.OK Then
                    ' Call Borra()
                End If
            Case 5
                Me.Dispose()
        End Select
    End Sub
    Private Sub Llena_TvDt()
        oTablaPNN = clsTree.ListaPNN("")
        tvTemasDT.BeginUpdate()
        nodo = tvTemasDT.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvTemasDT.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = clsTree.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
            Next
        Next
        tvTemasDT.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvTemasDT.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvTemasDT.Sorted = True
        'PnlLectura.Visible = True
        'PnlAgrega.Visible = False
    End Sub
    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"
                Call Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Muestra(pnlLectura)
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
            Case "Agregar"
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Inactivos(TVPNN)
                Call Muestra(pnlLectura)
                'Call Oculta(txttipoTema)
                Call Activos(pnlLectura)
                'Call Limpia_control(TxTescribe1, TxTescribe3, TxTescribe4, TxTescribe5)
                'Call Limpia_Campos(txtf1, txtf2, txtcomite, txttipoTema)
            Case "Editar"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5), tlbBotonera.Buttons.Item(4))
                Call Activos(pnlLectura)
            Case "Inactivo"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4))
            Case "Plan"
                Call Activos(tlbBotonera.Buttons.Item(0))
                Call Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4))
            Case "Tema"
                Call Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(3))

        End Select
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub tvTemasDT_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvTemasDT.AfterSelect

    End Sub
End Class
