Imports System.IO
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class FrmSesiones_pasadas
    Inherits System.Windows.Forms.Form

    Private oVista As DataView
    Dim dvComite As DataView
    Dim dvCT As DataView
    Dim dvC As DataView
    Dim dvGT As DataView
    Dim DTRes As New DataTable ''' datos editables para restaurar
    Dim DTResTem As New DataTable ''' datos editables para restaurar
    Dim DTResArch As New DataTable ''' datos editables para restaurar


    '''''     Otras Variables
    Dim existe, Accion As Boolean
    Dim ValEditar As Integer
    Dim sError, iEditar, sValTreeView, sFechaPk, shoraiPk, shoratPk, sReubica As String
    Dim sesion, i, solicitud, istasol, istasesion As Integer


#Region " Inicializacionde Dll's"

    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objsalas As New Cls_Salas.Cls_Salas("EXTRA", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents DTPkrhoratem As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPkrhoraini As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents Lblht As System.Windows.Forms.Label
    Friend WithEvents TxtNotas As System.Windows.Forms.TextBox
    Friend WithEvents lblNotas As System.Windows.Forms.Label
    Friend WithEvents LblcountArch As System.Windows.Forms.Label
    Friend WithEvents Lblcounttemas As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents LblGridArchivos As System.Windows.Forms.Label
    Friend WithEvents lblGridTemas As System.Windows.Forms.Label
    Friend WithEvents Lblhi As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblSesiones As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents CboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents GridArchivos As System.Windows.Forms.DataGrid
    Friend WithEvents GridTemas As System.Windows.Forms.DataGrid
    Friend WithEvents DTPker As System.Windows.Forms.DateTimePicker
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents Lblchksala As System.Windows.Forms.Label
    Friend WithEvents Lblsal As System.Windows.Forms.Label
    Friend WithEvents LblSol As System.Windows.Forms.Label
    Friend WithEvents TxtLugar As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtAsunto As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtNo_Sol_Sala As System.Windows.Forms.TextBox
    Friend WithEvents CkBxSalasANCE As System.Windows.Forms.CheckBox
    Friend WithEvents CboSalas As System.Windows.Forms.ComboBox
    Friend WithEvents LblStatus As System.Windows.Forms.Label
    Friend WithEvents CBoStatus As System.Windows.Forms.ComboBox
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents CboSesiones As System.Windows.Forms.ComboBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmSesiones_pasadas))
        Me.DTPkrhoratem = New System.Windows.Forms.DateTimePicker
        Me.DTPkrhoraini = New System.Windows.Forms.DateTimePicker
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.Lblht = New System.Windows.Forms.Label
        Me.TxtNotas = New System.Windows.Forms.TextBox
        Me.lblNotas = New System.Windows.Forms.Label
        Me.LblcountArch = New System.Windows.Forms.Label
        Me.Lblcounttemas = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.LblGridArchivos = New System.Windows.Forms.Label
        Me.lblGridTemas = New System.Windows.Forms.Label
        Me.Lblhi = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblSesiones = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.CboResponsable = New System.Windows.Forms.ComboBox
        Me.GridArchivos = New System.Windows.Forms.DataGrid
        Me.GridTemas = New System.Windows.Forms.DataGrid
        Me.DTPker = New System.Windows.Forms.DateTimePicker
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.Lblchksala = New System.Windows.Forms.Label
        Me.Lblsal = New System.Windows.Forms.Label
        Me.LblSol = New System.Windows.Forms.Label
        Me.TxtLugar = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.TxtAsunto = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TxtNo_Sol_Sala = New System.Windows.Forms.TextBox
        Me.CkBxSalasANCE = New System.Windows.Forms.CheckBox
        Me.CboSalas = New System.Windows.Forms.ComboBox
        Me.LblStatus = New System.Windows.Forms.Label
        Me.CBoStatus = New System.Windows.Forms.ComboBox
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.CboSesiones = New System.Windows.Forms.ComboBox
        CType(Me.GridArchivos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridTemas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DTPkrhoratem
        '
        Me.DTPkrhoratem.CustomFormat = "HH:mm "
        Me.DTPkrhoratem.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoratem.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoratem.Location = New System.Drawing.Point(552, 69)
        Me.DTPkrhoratem.Name = "DTPkrhoratem"
        Me.DTPkrhoratem.ShowUpDown = True
        Me.DTPkrhoratem.Size = New System.Drawing.Size(67, 20)
        Me.DTPkrhoratem.TabIndex = 120
        Me.DTPkrhoratem.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'DTPkrhoraini
        '
        Me.DTPkrhoraini.CustomFormat = "HH:mm"
        Me.DTPkrhoraini.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoraini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoraini.Location = New System.Drawing.Point(341, 69)
        Me.DTPkrhoraini.Name = "DTPkrhoraini"
        Me.DTPkrhoraini.ShowUpDown = True
        Me.DTPkrhoraini.Size = New System.Drawing.Size(67, 20)
        Me.DTPkrhoraini.TabIndex = 119
        Me.DTPkrhoraini.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblcomite.Location = New System.Drawing.Point(8, 8)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(126, 16)
        Me.Lblcomite.TabIndex = 118
        Me.Lblcomite.Text = "Comite Seleccionado: "
        '
        'Lblht
        '
        Me.Lblht.AutoSize = True
        Me.Lblht.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblht.Location = New System.Drawing.Point(472, 72)
        Me.Lblht.Name = "Lblht"
        Me.Lblht.Size = New System.Drawing.Size(65, 16)
        Me.Lblht.TabIndex = 116
        Me.Lblht.Text = "Termina a: "
        '
        'TxtNotas
        '
        Me.TxtNotas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNotas.Location = New System.Drawing.Point(341, 424)
        Me.TxtNotas.Multiline = True
        Me.TxtNotas.Name = "TxtNotas"
        Me.TxtNotas.Size = New System.Drawing.Size(395, 40)
        Me.TxtNotas.TabIndex = 96
        Me.TxtNotas.Text = ""
        '
        'lblNotas
        '
        Me.lblNotas.AutoSize = True
        Me.lblNotas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotas.Location = New System.Drawing.Point(261, 424)
        Me.lblNotas.Name = "lblNotas"
        Me.lblNotas.Size = New System.Drawing.Size(39, 16)
        Me.lblNotas.TabIndex = 115
        Me.lblNotas.Text = "Nota:  "
        '
        'LblcountArch
        '
        Me.LblcountArch.AutoSize = True
        Me.LblcountArch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblcountArch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblcountArch.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblcountArch.Location = New System.Drawing.Point(277, 328)
        Me.LblcountArch.Name = "LblcountArch"
        Me.LblcountArch.Size = New System.Drawing.Size(12, 18)
        Me.LblcountArch.TabIndex = 114
        Me.LblcountArch.Text = "0"
        '
        'Lblcounttemas
        '
        Me.Lblcounttemas.AutoSize = True
        Me.Lblcounttemas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblcounttemas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Lblcounttemas.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.Lblcounttemas.Location = New System.Drawing.Point(277, 192)
        Me.Lblcounttemas.Name = "Lblcounttemas"
        Me.Lblcounttemas.Size = New System.Drawing.Size(12, 18)
        Me.Lblcounttemas.TabIndex = 113
        Me.Lblcounttemas.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(261, 480)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 16)
        Me.Label9.TabIndex = 110
        Me.Label9.Text = "Responsable: "
        '
        'LblGridArchivos
        '
        Me.LblGridArchivos.AccessibleName = "+-"
        Me.LblGridArchivos.AutoSize = True
        Me.LblGridArchivos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblGridArchivos.Location = New System.Drawing.Point(261, 296)
        Me.LblGridArchivos.Name = "LblGridArchivos"
        Me.LblGridArchivos.Size = New System.Drawing.Size(60, 16)
        Me.LblGridArchivos.TabIndex = 107
        Me.LblGridArchivos.Text = "Archivos: "
        '
        'lblGridTemas
        '
        Me.lblGridTemas.AutoSize = True
        Me.lblGridTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGridTemas.Location = New System.Drawing.Point(261, 168)
        Me.lblGridTemas.Name = "lblGridTemas"
        Me.lblGridTemas.Size = New System.Drawing.Size(47, 16)
        Me.lblGridTemas.TabIndex = 106
        Me.lblGridTemas.Text = "Temas: "
        '
        'Lblhi
        '
        Me.Lblhi.AutoSize = True
        Me.Lblhi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblhi.Location = New System.Drawing.Point(261, 72)
        Me.Lblhi.Name = "Lblhi"
        Me.Lblhi.Size = New System.Drawing.Size(74, 16)
        Me.Lblhi.TabIndex = 103
        Me.Lblhi.Text = "Comienza a: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(261, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 16)
        Me.Label1.TabIndex = 102
        Me.Label1.Text = "Fecha: "
        '
        'lblSesiones
        '
        Me.lblSesiones.AutoSize = True
        Me.lblSesiones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSesiones.Location = New System.Drawing.Point(261, 11)
        Me.lblSesiones.Name = "lblSesiones"
        Me.lblSesiones.Size = New System.Drawing.Size(82, 16)
        Me.lblSesiones.TabIndex = 101
        Me.lblSesiones.Text = "Clave Sesion: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 24)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 15)
        Me.LblTreeView.TabIndex = 117
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'CboResponsable
        '
        Me.CboResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboResponsable.Location = New System.Drawing.Point(341, 477)
        Me.CboResponsable.Name = "CboResponsable"
        Me.CboResponsable.Size = New System.Drawing.Size(395, 22)
        Me.CboResponsable.TabIndex = 97
        '
        'GridArchivos
        '
        Me.GridArchivos.AllowNavigation = False
        Me.GridArchivos.CaptionVisible = False
        Me.GridArchivos.DataMember = ""
        Me.GridArchivos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridArchivos.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.GridArchivos.HeaderBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GridArchivos.HeaderFont = New System.Drawing.Font("Arial", 9.290323!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridArchivos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GridArchivos.Location = New System.Drawing.Point(341, 296)
        Me.GridArchivos.Name = "GridArchivos"
        Me.GridArchivos.Size = New System.Drawing.Size(395, 120)
        Me.GridArchivos.TabIndex = 95
        '
        'GridTemas
        '
        Me.GridTemas.AllowDrop = True
        Me.GridTemas.AllowNavigation = False
        Me.GridTemas.CaptionVisible = False
        Me.GridTemas.DataMember = ""
        Me.GridTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridTemas.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.GridTemas.HeaderBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GridTemas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GridTemas.Location = New System.Drawing.Point(341, 168)
        Me.GridTemas.Name = "GridTemas"
        Me.GridTemas.Size = New System.Drawing.Size(395, 120)
        Me.GridTemas.TabIndex = 94
        '
        'DTPker
        '
        Me.DTPker.CustomFormat = "dd/MM/yyyy"
        Me.DTPker.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPker.Location = New System.Drawing.Point(341, 38)
        Me.DTPker.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPker.Name = "DTPker"
        Me.DTPker.Size = New System.Drawing.Size(163, 20)
        Me.DTPker.TabIndex = 90
        '
        'tvComites
        '
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 48)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = 1
        Me.tvComites.Size = New System.Drawing.Size(240, 480)
        Me.tvComites.TabIndex = 88
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'Lblchksala
        '
        Me.Lblchksala.AutoSize = True
        Me.Lblchksala.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblchksala.Location = New System.Drawing.Point(573, 136)
        Me.Lblchksala.Name = "Lblchksala"
        Me.Lblchksala.Size = New System.Drawing.Size(127, 16)
        Me.Lblchksala.TabIndex = 112
        Me.Lblchksala.Text = "Solicitar Sala a ANCE: "
        '
        'Lblsal
        '
        Me.Lblsal.AutoSize = True
        Me.Lblsal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsal.Location = New System.Drawing.Point(261, 512)
        Me.Lblsal.Name = "Lblsal"
        Me.Lblsal.Size = New System.Drawing.Size(34, 16)
        Me.Lblsal.TabIndex = 111
        Me.Lblsal.Text = "Sala: "
        '
        'LblSol
        '
        Me.LblSol.AutoSize = True
        Me.LblSol.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSol.Location = New System.Drawing.Point(541, 512)
        Me.LblSol.Name = "LblSol"
        Me.LblSol.Size = New System.Drawing.Size(59, 16)
        Me.LblSol.TabIndex = 109
        Me.LblSol.Text = "Solicitud: "
        '
        'TxtLugar
        '
        Me.TxtLugar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLugar.Location = New System.Drawing.Point(341, 136)
        Me.TxtLugar.Name = "TxtLugar"
        Me.TxtLugar.Size = New System.Drawing.Size(208, 20)
        Me.TxtLugar.TabIndex = 92
        Me.TxtLugar.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(261, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 16)
        Me.Label4.TabIndex = 105
        Me.Label4.Text = "Lugar: "
        '
        'TxtAsunto
        '
        Me.TxtAsunto.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAsunto.Location = New System.Drawing.Point(341, 104)
        Me.TxtAsunto.Multiline = True
        Me.TxtAsunto.Name = "TxtAsunto"
        Me.TxtAsunto.Size = New System.Drawing.Size(395, 19)
        Me.TxtAsunto.TabIndex = 91
        Me.TxtAsunto.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(261, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 16)
        Me.Label3.TabIndex = 104
        Me.Label3.Text = "Asunto: "
        '
        'TxtNo_Sol_Sala
        '
        Me.TxtNo_Sol_Sala.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNo_Sol_Sala.Location = New System.Drawing.Point(597, 511)
        Me.TxtNo_Sol_Sala.Name = "TxtNo_Sol_Sala"
        Me.TxtNo_Sol_Sala.Size = New System.Drawing.Size(139, 20)
        Me.TxtNo_Sol_Sala.TabIndex = 108
        Me.TxtNo_Sol_Sala.Text = ""
        '
        'CkBxSalasANCE
        '
        Me.CkBxSalasANCE.Location = New System.Drawing.Point(717, 136)
        Me.CkBxSalasANCE.Name = "CkBxSalasANCE"
        Me.CkBxSalasANCE.Size = New System.Drawing.Size(16, 16)
        Me.CkBxSalasANCE.TabIndex = 93
        '
        'CboSalas
        '
        Me.CboSalas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboSalas.Location = New System.Drawing.Point(341, 509)
        Me.CboSalas.Name = "CboSalas"
        Me.CboSalas.Size = New System.Drawing.Size(176, 22)
        Me.CboSalas.TabIndex = 98
        '
        'LblStatus
        '
        Me.LblStatus.AutoSize = True
        Me.LblStatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblStatus.Location = New System.Drawing.Point(528, 11)
        Me.LblStatus.Name = "LblStatus"
        Me.LblStatus.Size = New System.Drawing.Size(46, 16)
        Me.LblStatus.TabIndex = 122
        Me.LblStatus.Text = "Estado:"
        '
        'CBoStatus
        '
        Me.CBoStatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBoStatus.Location = New System.Drawing.Point(592, 8)
        Me.CBoStatus.Name = "CBoStatus"
        Me.CBoStatus.Size = New System.Drawing.Size(144, 22)
        Me.CBoStatus.TabIndex = 121
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 538)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(744, 62)
        Me.tlbBotonera.TabIndex = 123
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'CboSesiones
        '
        Me.CboSesiones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.CboSesiones.Enabled = False
        Me.CboSesiones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboSesiones.ItemHeight = 14
        Me.CboSesiones.Location = New System.Drawing.Point(341, 8)
        Me.CboSesiones.Name = "CboSesiones"
        Me.CboSesiones.Size = New System.Drawing.Size(163, 21)
        Me.CboSesiones.TabIndex = 89
        '
        'FrmSesiones_pasadas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(744, 600)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.LblStatus)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.Lblht)
        Me.Controls.Add(Me.TxtNotas)
        Me.Controls.Add(Me.lblNotas)
        Me.Controls.Add(Me.LblcountArch)
        Me.Controls.Add(Me.Lblcounttemas)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.LblGridArchivos)
        Me.Controls.Add(Me.lblGridTemas)
        Me.Controls.Add(Me.Lblhi)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblSesiones)
        Me.Controls.Add(Me.Lblchksala)
        Me.Controls.Add(Me.Lblsal)
        Me.Controls.Add(Me.LblSol)
        Me.Controls.Add(Me.TxtLugar)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtAsunto)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtNo_Sol_Sala)
        Me.Controls.Add(Me.CboSesiones)
        Me.Controls.Add(Me.CBoStatus)
        Me.Controls.Add(Me.DTPkrhoratem)
        Me.Controls.Add(Me.DTPkrhoraini)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.CboResponsable)
        Me.Controls.Add(Me.GridArchivos)
        Me.Controls.Add(Me.GridTemas)
        Me.Controls.Add(Me.DTPker)
        Me.Controls.Add(Me.tvComites)
        Me.Controls.Add(Me.CkBxSalasANCE)
        Me.Controls.Add(Me.CboSalas)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmSesiones_pasadas"
        Me.Text = "Historial de Sesiones"
        CType(Me.GridArchivos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridTemas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos del Modulo"

#Region "Sub  Regresa_path, Metodos y Procesos"

    Public Function Regresa_Path(ByVal lblarray As Array) As String

        Select Case UCase(Mid(lblarray(lblarray.Length - 1), 1, 2))
            Case "CT"
                Return lblarray(0) + " \ " + lblarray(1) + " \ NA \ NA"

            Case "SC"
                Select Case lblarray.Length
                    Case 2
                        Return lblarray(0) + " \ NA \ " + lblarray(1) + " \ NA"
                    Case 3
                        Return lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ NA"
                End Select
            Case "GT"
                Select Case lblarray.Length
                    Case 2
                        Return lblarray(0) + " \ NA \ NA \ " + lblarray(1)
                    Case 3
                        If UCase(Mid(lblarray(1), 1, 2)) = "CT" Then
                            Return lblarray(0) + " \ " + lblarray(1) + " \ NA \ " + lblarray(2)
                        ElseIf UCase(Mid(lblarray(1), 1, 2)) = "SC" Then
                            Return lblarray(0) + " \ NA \ " + lblarray(1) + " \ " + lblarray(2)
                        End If
                    Case 4
                        Return lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ " + lblarray(3)
                End Select
            Case ""
                Return "NA \ NA \ NA \ NA"
            Case Else
                Select Case lblarray.Length
                    Case 0
                        Return "NA \ NA \ NA \ NA"
                    Case 1
                        Return lblarray(0) + " \ NA \ NA \ NA"
                    Case Else
                        Dim regresai As String
                        Dim i As Integer
                        For i = 0 To lblarray.Length - 2
                            If i = 0 Then regresai = lblarray(0) Else regresai = regresai + " \ " + lblarray(i)
                        Next
                        Return Regresa_Path(Split(regresai, " \ "))
                End Select

        End Select
    End Function

#End Region

#Region " Sesiones, Metodos y Procesos"

#Region " Sesiones - Sesiones(comite, CT, SC, grupo, compara) , Metodos y Procesos"

    Private Function sesiones(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String) As DataTable
        Cursor.Current = Cursors.WaitCursor
        Dim combotable As DataTable
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columna As DataColumn
        Dim cm As CurrencyManager

        Try
            With objsesiones
                .Bandera = 9
                .Id_Comite = comite
                .Id_CT = CT
                .Id_SC = SC
                .Id_Grupo = grupo
                combotable = .Listar()
            End With
            If grupo.Trim <> "NA" Then
                comite = grupo.Trim
            ElseIf SC.Trim <> "NA" Then
                comite = SC.Trim
            ElseIf CT.Trim <> "NA" Then
                comite = CT.Trim
            End If
            combotable.Columns.Add("Numero")
            iNumero = 0
            For Each regs In combotable.Rows
                iNumero = iNumero + 1
                combotable.Rows(iNumero - 1).Item("Numero") = iNumero.ToString + "/" + Format$(regs("Fecha"), "yy") + " " + comite.Trim
            Next

            If iNumero = 0 And iEditar <> Nothing Then
                MsgBox("No tiene asignada ninguna Sesion", MsgBoxStyle.Information)
            End If

            cm = CType(BindingContext(combotable), CurrencyManager)
            Dim dv As DataView = CType(cm.List, DataView)
            If compara.Length > 0 Then dv.RowFilter = "Numero = '" & compara & "'"
            Cursor.Current = Cursors.Default
            Return combotable

        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Function

#End Region

#Region " Sesiones - Llenar_sesiones(cbo As ComboBox, comite, CT, SC, grupo, compara), Metodos y Procesos"

    Private Sub Llenar_sesiones(ByVal cbo As ComboBox, ByVal comite As String, _
                                ByVal CT As String, ByVal SC As String, _
                                ByVal grupo As String, ByVal compara As String)

        Cursor.Current = Cursors.WaitCursor
        Try
            Dim combotable As DataTable
            combotable = sesiones(comite, CT, SC, grupo, compara)
            cbo.DisplayMember = combotable.Columns(2).ColumnName
            cbo.ValueMember = combotable.Columns(0).ColumnName
            cbo.DataSource = combotable
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#Region " Sesiones - Limpia, Metodos y Procesos"

    Private Sub limpia()
        DTPker.ResetText()
        sFechaPk = Format$(DTPker.Value, "dd/MM/yyyy")
        TxtAsunto.Text = "" : TxtLugar.Text = "" : LblcountArch.Text = 0 : Lblcounttemas.Text = 0 : TxtNotas.Text = "" : TxtNo_Sol_Sala.Text = ""
        DTPkrhoraini.ResetText()
        DTPkrhoratem.ResetText()
        CboSalas.SelectedValue = 0 : CBoStatus.SelectedValue = 0
        CkBxSalasANCE.CheckState = CheckState.Unchecked
        iarchv = 0
        itemas = 0
        Call Llena_grid(-1)
    End Sub

#End Region

#End Region

#Region "Metodos - Validaciones"

    Private Function valida(ByVal casos As String) As Boolean
        Dim aCasos As Array
        Dim valreturn As Boolean = True
        aCasos = Split(casos, " _#_ ")
        Select Case aCasos(0)
            Case "comites"
                If LblTreeView.Text.Length <= 0 Then
                    ErrorProvider1.SetError(Lblcomite, "Debes seleccionar un Comite")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblcomite, "")
                End If
            Case "dtpker"
                If CStr(DTPker.Value) = "" Then
                    ErrorProvider1.SetError(DTPker, "Debes escribir la fecha de tu sesi�n")
                    valreturn = False
                ElseIf Not (CInt(Format$(DTPker.Value, "dd")) <= CInt(Format$(Now(), "dd")) And CInt(Format$(DTPker.Value, "MM")) <= CInt(Format$(Now(), "MM")) And CInt(Format$(DTPker.Value, "yyyy")) <= CInt(Format$(Now(), "yyyy"))) Then
                    ErrorProvider1.SetError(DTPker, "")
                Else
                    ErrorProvider1.SetError(DTPker, "No se puede programar una  sesi�n para una fecha anterior o del  mismo d�a.")
                    valreturn = False
                End If

            Case "Asunto"
                If TxtAsunto.Text = "" Then
                    ErrorProvider1.SetError(TxtAsunto, "Debes escribir el tema principal de la sesi�n")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(TxtAsunto, "")
                End If

            Case "salas"
                If CboSalas.SelectedValue = 0 Then
                    ErrorProvider1.SetError(CboSalas, "Seleccionaste apartado de sala en ANCE." + Chr(13) + " Debes elegir una sala ahora o deshactivar la casilla de Apartado de sala.")
                    ErrorProvider1.SetError(Lblchksala, "Debes seleccionar la sala en  ANCE." + Chr(13) + " para habilitar las Salas")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(CboSalas, "")
                    ErrorProvider1.SetError(CkBxSalasANCE, "")
                End If

            Case "Horario"
                Dim HoraI As DateTime = DTPkrhoraini.Value
                Dim Horat As DateTime = DTPkrhoratem.Value
                If HoraI >= Horat Then
                    ErrorProvider1.SetError(Lblhi, "Debes escribir un Horario de inicio menor al de Termino de la sesion")
                    ErrorProvider1.SetError(Lblht, "Debes escribir un Horario de Termino mayor al de Inicio de  la sesion")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblhi, "")
                    ErrorProvider1.SetError(Lblht, "")
                End If

            Case "Directorio"
                Dim sPath = aCasos(1)
                Try
                    If Directory.Exists(sPath) = False Then
                        MkDir(sPath)
                    End If
                Catch ex As Exception
                    MsgBox("Error V004 - Al intentar crear una carpeta en el servidor ..." + Chr(13) + sPath + Chr(13) + ex.Message, MsgBoxStyle.Critical) '
                    valreturn = False
                End Try
        End Select
        Return valreturn
    End Function

    Private Function validagrid(ByVal casos As String, ByVal fil As Integer) As Boolean
        Dim acasos As Array = Split(casos, " ")
        Dim i As Integer
        Dim valreturn As Boolean = True
        ErrorProvider1.SetError(lblGridTemas, "")
        ErrorProvider1.SetError(LblGridArchivos, "")
        Select Case acasos(0)
            Case "temas"
                Dim stema = (IIf(IsDBNull(GridTemas.Item(fil, 1)), -1, GridTemas.Item(fil, 1)))
                Dim sPlan = (IIf(IsDBNull(GridTemas.Item(fil, 0)), "", GridTemas.Item(fil, 0)))
                For i = 1 To acasos.Length - 1
                    Select Case acasos(i)
                        Case "1"
                            If stema = -1 Then
                                ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un tema")
                                valreturn = False
                            End If
                        Case "2"
                            If sPlan = "" Then
                                ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un Plan")
                                valreturn = False
                            End If
                        Case "3"
                            Dim sverifica
                            If GridTemas.Item(fil, 3) Is System.DBNull.Value Then sverifica = (-1) Else sverifica = IIf(GridTemas.Item(fil, 3), 1, 0)
                            If sverifica = -1 Then
                                ErrorProvider1.SetError(lblGridTemas, "Debes activar o desactivar la casilla, en la columna de Activar" + Chr(13) + Chr(13) + "En la linea " + CStr(fil + 1) + ".")
                                valreturn = False
                            End If
                    End Select
                Next
            Case "archivos"
                Dim stipo = (IIf(IsDBNull(GridArchivos.Item(fil, 0)), "", GridArchivos.Item(fil, 0)))
                Dim sarchivo = (IIf(IsDBNull(GridArchivos.Item(fil, 1)), "", GridArchivos.Item(fil, 1)))
                For i = 1 To acasos.Length - 1
                    Select Case acasos(i)
                        Case "1"
                            If stipo = "" Then
                                ErrorProvider1.SetError(LblGridArchivos, "Debes seleccionar un tipo de archivos")
                                valreturn = False
                            End If
                        Case "2"
                            If stipo <> "" Then
                                If sarchivo = "" Then
                                    ErrorProvider1.SetError(LblGridArchivos, "Debes Agregar un Archivo")
                                    valreturn = False
                                End If
                            End If
                        Case "3"
                            If sarchivo <> "" Then
                                Dim sverifica
                                If GridArchivos.Item(fil, 3) Is System.DBNull.Value Then sverifica = -1 Else sverifica = IIf(GridArchivos.Item(fil, 3), 1, 0)
                                If sverifica = -1 Then
                                    ErrorProvider1.SetError(LblGridArchivos, "Debes activar o desactivar la casilla, en la columna de Activar." + Chr(13) + Chr(13) + "En la linea " + CStr(fil + 1) + ".")
                                    valreturn = False
                                End If
                            End If

                    End Select
                Next
        End Select
        Return valreturn
    End Function

#End Region

#End Region

#Region " Tree View - ComiteTree, Metodos y Procesos"

#Region "  tvComites - llena_ComiteTreeView , Metodos y Procesos"

    Private Sub llena_ComiteTreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable
        Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"

                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")

                        If GTAnt <> SCAnt And GTAnt <> CTAnt And GTAnt <> ComiteAnt Then
                            oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"), "") '********Sesiones Comite
                            If oTablaSs.Rows.Count > 0 Then
                                For Each RegSes In oTablaSs.Rows
                                    Ses = GT.Nodes.Add(RegSes("numero"))
                                    Ses.ImageIndex = 5
                                    Ses.SelectedImageIndex = 5
                                Next
                            End If
                        End If

                    Next 'GT
                    If SCAnt <> CTAnt And SCAnt <> ComiteAnt Then
                        oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), "NA", "")  '********Sesiones Comite
                        If oTablaSs.Rows.Count > 0 Then
                            For Each RegSes In oTablaSs.Rows
                                Ses = SC.Nodes.Add(RegSes("numero"))
                                Ses.ImageIndex = 5
                                Ses.SelectedImageIndex = 5
                            Next
                        End If
                    End If
sinSC:
                Next 'SC
                If CTAnt <> ComiteAnt Then
                    oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), "NA", "NA", "") '********Sesiones Comite
                    If oTablaSs.Rows.Count > 0 Then
                        For Each RegSes In oTablaSs.Rows
                            Ses = CT.Nodes.Add(RegSes("numero"))
                            Ses.ImageIndex = 5
                            Ses.SelectedImageIndex = 5
                        Next
                    End If
                End If
sinCT:
            Next 'CT
            oTablaSs = sesiones(RegComite("ID_Comite"), "NA", "NA", "NA", "") '********Sesiones Comite
            If oTablaSs.Rows.Count > 0 Then
                For Each RegSes In oTablaSs.Rows
                    Ses = Comite.Nodes.Add(RegSes("numero"))
                    Ses.ImageIndex = 5
                    Ses.SelectedImageIndex = 5
                Next
            End If
sinComite:
        Next 'Comites
        tvComites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvComites.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        ' tvComites.Sorted = True
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  tvComites - tvComites_AfterSelect , Metodos y Procesos"

    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblcomite, "")
        Dim valor_nodo, valor As String
        Dim ivalor As String
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione el comite" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")
        If iEditar = "Espera" Or iEditar = "Agregar" Or iEditar = "" Then
            Call Llena_grid(-1)
            Call Llenar_sesiones(CboSesiones, "NA", "NA", "NA", "NA", "")
        End If
        CboSesiones.Text = ""
        If CboSesiones.Visible = True Then
            Call limpia()
            array_texto = Nothing
            array_texto = Split(Regresa_Path(lblarray), " \ ")
            Inactivos(CboSesiones)
            If ivalor = 5 Then
                Call Llenar_sesiones(CboSesiones, array_texto(0), array_texto(1), array_texto(2), array_texto(3), e.Node.Text)
            Else
                Call Llenar_sesiones(CboSesiones, array_texto(0), array_texto(1), array_texto(2), array_texto(3), "")
            End If
        End If
        Inactivos(tlbBotonera.Buttons(4), tlbBotonera.Buttons(1))
        Cursor.Current = Cursors.Default

    End Sub

#End Region

#End Region

#Region " DataGrid, Metodos y Procesos"

#Region " Datagrid - DGTemas, Metodos y Procesos"

    Private Sub Crea_DGTemas()
        Dim dtcol As DataColumn = Nothing
        Try

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            ts1.MappingName = "clsSesiones"
            Call Tabla_Color(ts1, GridTemas)

            Dim cboPlanes As New DataGridComboBoxColumn(0, GridTemas)
            'Cambia el estilo de la combo ...
            cboPlanes.MappingName = "Plan"
            cboPlanes.HeaderText = "Planes"
            cboPlanes.Width = 100
            cboPlanes.ColumnComboBox.Name = "CboPlanes"
            ts1.GridColumnStyles.Add(cboPlanes)
            cboPlanes.ColumnComboBox.Items.Clear()

            objplanes.Bandera = 1
            Dim dtplanes As New DataTable
            Dim regplan As DataRow
            objplanes.ListaCombo(cboPlanes.ColumnComboBox)
            cboPlanes.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList
            ts1.PreferredRowHeight = (cboPlanes.ColumnComboBox.Height + 4)
            GridTemas.TableStyles.Add(ts1)

            Dim cboTemas As New DataGridComboBoxColumn(1, GridTemas)
            cboTemas.MappingName = "Tema"
            cboTemas.HeaderText = "Temas"
            cboTemas.Width = 80
            ts1.GridColumnStyles.Add(cboTemas)
            cboTemas.ColumnComboBox.Items.Clear()
            cboTemas.ColumnComboBox.Name = "CboTemas"
            objprogtrab.Bandera = 11
            objprogtrab.Id_Plan = ""
            DTC_Temas = objprogtrab.Listar()
            cboTemas.ColumnComboBox.DisplayMember = DTC_Temas.Columns(1).ColumnName
            cboTemas.ColumnComboBox.ValueMember = DTC_Temas.Columns(0).ColumnName
            cboTemas.ColumnComboBox.DataSource = DTC_Temas
            cboTemas.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList
            ts1.PreferredRowHeight = (cboTemas.ColumnComboBox.Height + 4)

            GridTemas.TableStyles.Add(ts1)

            Dim TextCol As DataGridTextBoxColumn
            TextCol = New DataGridTextBoxColumn
            TextCol.MappingName = "Clasificacion"
            TextCol.HeaderText = "Clasificaci�n"
            TextCol.Width = 110
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)
            'GridArchivos.TableStyles.Add(ts1)

            Dim chktemas As New DataGridBoolColumn
            chktemas.MappingName = "Inactivo"
            chktemas.HeaderText = "Activar"
            chktemas.Width = 40
            chktemas.NullValue = False
            chktemas.TrueValue = 0
            chktemas.FalseValue = 1
            'chkcolum.ReadOnly = False
            ts1.GridColumnStyles.Add(chktemas)
            GridTemas.TableStyles.Add(ts1)


        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#Region " Datagrid - Gdarchivos, Metodos y Procesos"

    Private Sub Crea_gdarchivos()

        Try
            Cursor.Current = Cursors.WaitCursor

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, GridArchivos)
            ts1.MappingName = "clsSesiones"


            Dim cboTipos_doctos As New DataGridComboBoxColumn(0, GridArchivos)
            'Cambia el estilo de la combo ...
            cboTipos_doctos.MappingName = "Descripcion"
            cboTipos_doctos.HeaderText = "Tipo"
            cboTipos_doctos.Width = 75
            cboTipos_doctos.ColumnComboBox.Name = "CboTipos_doctos"

            objsesiones.Bandera = 6
            objsesiones.ListaCombo(cboTipos_doctos.ColumnComboBox)
            cboTipos_doctos.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList


            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Docto"
            TextCol1.HeaderText = "Archivo"
            TextCol1.Width = 190
            TextCol1.TextBox.Enabled = False


            Dim chkcolum As New DataGridBoolColumn
            chkcolum.MappingName = "Inactivo"
            chkcolum.HeaderText = "Activar"
            chkcolum.Width = 40
            chkcolum.NullValue = False
            chkcolum.TrueValue = 0
            chkcolum.FalseValue = 1


            Dim ButtonColStyle As New DataGridButtonColumn(2)
            ButtonColStyle.MappingName = "Boton"
            ButtonColStyle.HeaderText = "Examinar"
            AddHandler ButtonColStyle.CellButtonClicked, AddressOf HandleCellButtonClick
            ButtonColStyle.Width = 50
            ts1.PreferredRowHeight = cboTipos_doctos.ColumnComboBox.Height + 4
            ts1.GridColumnStyles.AddRange(New DataGridColumnStyle() {cboTipos_doctos, TextCol1, ButtonColStyle, chkcolum})


            GridArchivos.TableStyles.Add(ts1)

            AddHandler GridArchivos.MouseUp, AddressOf ButtonColStyle.HandleMouseUp
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MessageBox.Show(ex.ToString & " - Sesiones - " & ex.Message)
            Cursor.Current = Cursors.Default
        End Try

    End Sub

    Private Sub HandleCellButtonClick(ByVal sender As Object, ByVal e As DataGridCellButtonClickEventArgs)
        Cursor.Current = Cursors.WaitCursor
        Cursor.Current = Cursors.Default
    End Sub

#End Region

    Public Sub Llena_grid(ByVal num As Integer)
        Dim cm, cm2 As CurrencyManager

        With objsesiones
            .Id_Sesion = num
            .Bandera = 4
            DTTemas = .Listar()
            cm = CType(BindingContext(DTTemas), CurrencyManager)
            'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyManager
            Dim Dv As DataView = CType(cm.List, DataView)
            'Asignamos el valor que deseamos para evitar o permitir nuevos registros
            Dv.AllowNew = False
            GridTemas.DataSource = DTTemas
            .Id_Sesion = num
            .Bandera = 5
            Lblcounttemas.Text = DTTemas.Rows.Count
            itemas = DTTemas.Rows.Count
            DTArchivos = .Listar()
            DTArchivos.Columns.Add("Boton")
            cm2 = CType(BindingContext(DTArchivos), CurrencyManager)
            'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyManager
            Dim Dv2 As DataView = CType(cm2.List, DataView)
            'Asignamos el valor que deseamos para evitar o permitir nuevos registros
            Dv2.AllowNew = False
            GridArchivos.DataSource = DTArchivos
        End With
    End Sub

#End Region

#Region " Forms - FrmSesionesPasadas, Metodos y Procesos"

    Private Sub FrmSesionespasadas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Cursor.Current = Cursors.WaitCursor
        Dim min As DateTime = DateTime.Now
        Dim time As TimeSpan = New TimeSpan(min.TimeOfDay.Days, 7, 0, 0, 0)
        min = DateTime.Today.Add(time)
        DTPkrhoraini.MinDate = min
        DTPkrhoraini.MaxDate = min.AddHours(16)
        DTPkrhoratem.MinDate = DTPkrhoraini.MinDate
        DTPkrhoratem.MaxDate = DTPkrhoraini.MaxDate
        Call Crea_DGTemas()
        Call Crea_gdarchivos()
        Call llena_ComiteTreeView()
        Inactivos(GridTemas, GridArchivos, CboSesiones, CBoStatus, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, CboResponsable, CkBxSalasANCE, CboSalas, tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), TxtNo_Sol_Sala)
        objempleados.Inicializa(Application.StartupPath & "\principal.ini", "comun", gUsuario, gPasswordSql)
        objempleados.Bandera = 6
        objempleados.ListaCombo(CboResponsable)
        objsalas.Bandera = 1
        objsalas.ListaCombo(CboSalas)
        objsesiones.Bandera = 10
        objsesiones.ListaCombo(CBoStatus)
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " ComboBox - CboSesiones, Metodos y Procesos"

    Private Sub CboSesiones_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboSesiones.SelectedIndexChanged
        Dim ahora As Array
        Dim ihora
        ErrorProvider1.SetError(CboSesiones, "")
        Cursor.Current = Cursors.WaitCursor
        Try
            With objsesiones
                .Bandera = 2
                .Id_Sesion = CboSesiones.SelectedValue
                .Buscar()
                DTPker.Value = CDate(.Fecha)
                sFechaPk = Format$(CDate(.Fecha), "dd/MM/yyyy")
                shoraiPk = .HoraI
                DTPkrhoraini.Value = CDate(Format$(Now(), "dd/MM/yyyy ") + .HoraI)
                DTPkrhoratem.Value = CDate(Format$(Now(), "dd/MM/yyyy ") + .HoraT)
                shoratPk = .HoraT
                TxtAsunto.Text = .Asunto
                TxtLugar.Text = .Lugar
                TxtNo_Sol_Sala.Text = ""
                CBoStatus.SelectedValue = .id_status_sesion
                If .Lugar.ToLower = "ance" And .No_Sol_Sala <> "" Then
                    CkBxSalasANCE.CheckState = CheckState.Checked
                    objsalas.No_Solicitud = .No_Sol_Sala
                    objsalas.Bandera = 3
                    objsalas.Buscar()
                    TxtNo_Sol_Sala.Text = .No_Sol_Sala
                    If objsalas.Id_Sala <> 0 Then CboSalas.SelectedValue = objsalas.Id_Sala Else CboSalas.SelectedValue = objsalas.Id_Propuesta
                    Oculta(TxtNo_Sol_Sala, CboSalas, Lblchksala, CkBxSalasANCE, Lblsal, LblSol)
                    Muestra(CboSalas, Lblchksala, CkBxSalasANCE, TxtNo_Sol_Sala, Lblsal, LblSol)
                    Inactivos(CkBxSalasANCE, CboSalas, TxtNo_Sol_Sala)
                Else
                    CkBxSalasANCE.CheckState = CheckState.Unchecked
                    Oculta(TxtNo_Sol_Sala, CboSalas, Lblchksala, CkBxSalasANCE, Lblsal, LblSol)
                    Inactivos(CboSalas, TxtNo_Sol_Sala, CkBxSalasANCE)
                End If
                ''''                     Llena el grid de de Temas y Archivos

                Call Llena_grid(CboSesiones.SelectedValue)
                TxtNotas.Text = .Notas
                CboResponsable.SelectedValue = .Responsable
                LblcountArch.Text = DTArchivos.Rows.Count
                iarchv = DTArchivos.Rows.Count
                GridArchivos.DataSource = DTArchivos

            End With
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - al intentar cargar los datos sobre esta sesion " + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
        Inactivos(tlbBotonera.Buttons(4))
    End Sub

#End Region

#Region " ToolBar - TlbBotonera, Metodos y Procesos"


    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1                   '''----------   Agregar     --------

            Case 2                   '''----------   Edita     --------

            Case 3                   '''----------   Deshacer     --------
                ' Habilita("Nulo")

            Case 4                   '''----------   Guardar     --------

            Case 5                   '''----------   Eliminar     --------

            Case 7                   '''----------   Salir     --------
                iEditar = "Espera"
                Me.Close()
        End Select

        Cursor.Current = Cursors.Default
    End Sub

#End Region


End Class

