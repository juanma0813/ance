Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration


Namespace Maple
   public Class clsPSesionDoctos


#Region"Propiedades de la clase"
      REM Variables de Propiedad
      Private _Id_Sesion as integer
      Private _Id_Docto as integer
      Private _Docto as String
      Private _Id_Tipo as integer
      Private _Inactivo as integer
      Private _NombreDelDocumento as String
      Private _Bandera as String
      Private _respRetorno(1) As String
      Private cn As SqlConnection


      REM Propiedades de la Entidad
      public Property Id_Sesion as integer
         Get
            Return _Id_Sesion
         End Get
         Set(ByVal Value as integer)
            _Id_Sesion = Value
         End Set
      End Property

      public Property Id_Docto as integer
         Get
            Return _Id_Docto
         End Get
         Set(ByVal Value as integer)
            _Id_Docto = Value
         End Set
      End Property

      public Property Docto as String
         Get
            Return _Docto
         End Get
         Set(ByVal Value as String)
            _Docto = Value
         End Set
      End Property

      public Property Id_Tipo as integer
         Get
            Return _Id_Tipo
         End Get
         Set(ByVal Value as integer)
            _Id_Tipo = Value
         End Set
      End Property

      public Property Inactivo as integer
         Get
            Return _Inactivo
         End Get
         Set(ByVal Value as integer)
            _Inactivo = Value
         End Set
      End Property

      public Property NombreDelDocumento as String
         Get
            Return _NombreDelDocumento
         End Get
         Set(ByVal Value as String)
            _NombreDelDocumento = Value
         End Set
      End Property

        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
      public Property Bandera as string
         Get
            Return _Bandera
         End Get
         Set(ByVal Value as String)
            _Bandera = Value
         End Set
      End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 0 contiene el error en caso de fallar :: la posicion 1 Contiene un (1 o 0), '1' indica que el metodo fallo, y '0' indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
      public ReadOnly Property respRetorno as Array
         Get
            Return _respRetorno
         End Get
      End Property


#End Region
#Region"Metodos de la Clase"
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
      public sub New() 
            cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance"))
      End Sub 
      Rem Funcion que Elimina datos
        ''' <summary>
        '''Metodo para eliminar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
      public Sub Eliminar() 

         Try
            _respRetorno(0) = ""
            _respRetorno(1) = cstr(0)

               Cn.Open
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionDoctos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Docto", _Id_Docto)
                cmd.Parameters.Add("@Docto", _Docto)
                cmd.Parameters.Add("@Id_Tipo", _Id_Tipo)
                cmd.Parameters.Add("@Inactivo", _Inactivo)
                cmd.Parameters.Add("@NombreDelDocumento", _NombreDelDocumento)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Actualizar datos
        ''' <summary>
        '''Metodo para Actualizar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Actualizar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionDoctos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Docto", _Id_Docto)
                cmd.Parameters.Add("@Docto", _Docto)
                cmd.Parameters.Add("@Id_Tipo", _Id_Tipo)
                cmd.Parameters.Add("@Inactivo", _Inactivo)
                cmd.Parameters.Add("@NombreDelDocumento", _NombreDelDocumento)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Insertar datos
        ''' <summary>
        ''' Metodo para insertar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Insertar()
            Dim Consecutivo As Integer = 0

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionDoctos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Docto", _Id_Docto)
                cmd.Parameters.Add("@Docto", _Docto)
                cmd.Parameters.Add("@Id_Tipo", _Id_Tipo)
                cmd.Parameters.Add("@Inactivo", _Inactivo)
                cmd.Parameters.Add("@NombreDelDocumento", _NombreDelDocumento)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que LlenarDatos datos
        ''' <summary>
        '''llena todas las propiedades en base a una consulta de sql o Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub LlenarDatos()
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionDoctos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Docto", _Id_Docto)
                cmd.Parameters.Add("@Docto", _Docto)
                cmd.Parameters.Add("@Id_Tipo", _Id_Tipo)
                cmd.Parameters.Add("@Inactivo", _Inactivo)
                cmd.Parameters.Add("@NombreDelDocumento", _NombreDelDocumento)
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                da.Dispose()
                cmd.Dispose()

                If dt.Rows.Count > 0 Then
                    _Id_Sesion = IIf(IsDBNull(dt.Rows(0).Item("Id_Sesion")) = True, Nothing, dt.Rows(0).Item("Id_Sesion"))
                    _Id_Docto = IIf(IsDBNull(dt.Rows(0).Item("Id_Docto")) = True, Nothing, dt.Rows(0).Item("Id_Docto"))
                    _Docto = IIf(IsDBNull(dt.Rows(0).Item("Docto")) = True, Nothing, dt.Rows(0).Item("Docto"))
                    _Id_Tipo = IIf(IsDBNull(dt.Rows(0).Item("Id_Tipo")) = True, Nothing, dt.Rows(0).Item("Id_Tipo"))
                    _Inactivo = IIf(IsDBNull(dt.Rows(0).Item("Inactivo")) = True, Nothing, dt.Rows(0).Item("Inactivo"))
                    _NombreDelDocumento = IIf(IsDBNull(dt.Rows(0).Item("NombreDelDocumento")) = True, Nothing, dt.Rows(0).Item("NombreDelDocumento"))
                Else
                    _Id_Sesion = Nothing
                    _Id_Docto = Nothing
                    _Docto = Nothing
                    _Id_Tipo = Nothing
                    _Inactivo = Nothing
                    _NombreDelDocumento = Nothing
                End If
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = "0"

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionDoctos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Docto", _Id_Docto)
                cmd.Parameters.Add("@Docto", _Docto)
                cmd.Parameters.Add("@Id_Tipo", _Id_Tipo)
                cmd.Parameters.Add("@Inactivo", _Inactivo)
                cmd.Parameters.Add("@NombreDelDocumento", _NombreDelDocumento)
                cmd.Parameters.Add("@Bandera", _Bandera)
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                da.Dispose()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function


#End Region


   End Class

End Namespace
