REM Clase en VB creada automaticamente by Efren David Tello Villalobos ..::zok::.. .Clase creada el: 24/10/2016 Version 3.3
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration


Namespace AnceSystem

    Public Class clssSesionesNotificaciones


#Region "Propiedades de la clase"
        REM Variables de Propiedad
        Private _IdSesionNotificacion As Integer
        Private _IdSesion As Integer
        Private _Titulo As String
        Private _Cuerpo As String
        Private _Encontrado As Boolean
        Private _Bandera As String
        Private _respRetorno(1) As String
        Private cn As SqlConnection


        REM Propiedades de la Entidad
        Public Property IdSesionNotificacion() As Integer
            Get
                Return _IdSesionNotificacion
            End Get
            Set(ByVal Value As Integer)
                _IdSesionNotificacion = Value
            End Set
        End Property

        Public Property IdSesion() As Integer
            Get
                Return _IdSesion
            End Get
            Set(ByVal Value As Integer)
                _IdSesion = Value
            End Set
        End Property

        Public Property Titulo() As String
            Get
                Return _Titulo
            End Get
            Set(ByVal Value As String)
                _Titulo = Value
            End Set
        End Property

        Public Property Cuerpo() As String
            Get
                Return _Cuerpo
            End Get
            Set(ByVal Value As String)
                _Cuerpo = Value
            End Set
        End Property

        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Bandera() As String
            Get
                Return _Bandera
            End Get
            Set(ByVal Value As String)
                _Bandera = Value
            End Set
        End Property

        Public Property Encontrado() As String
            Get
                Return _Encontrado
            End Get
            Set(ByVal Value As String)
                _Encontrado = Value
            End Set
        End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 0 contiene el error en caso de fallar :: la posicion 1 Contiene un (1 o 0), '1' indica que el metodo fallo, y '0' indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property

#End Region
#Region "Metodos de la Clase"
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance").ToString)
        End Sub
        REM Funcion que Elimina datos
        ''' <summary>
        '''Metodo para eliminar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Eliminar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                Cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionesNotificaciones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdSesionNotificacion", _IdSesionNotificacion)
                cmd.Parameters.Add("@IdSesion", _IdSesion)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@Cuerpo", _Cuerpo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Actualizar datos
        ''' <summary>
        '''Metodo para Actualizar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Actualizar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionesNotificaciones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdSesionNotificacion", _IdSesionNotificacion)
                cmd.Parameters.Add("@IdSesion", _IdSesion)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@Cuerpo", _Cuerpo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Insertar datos
        ''' <summary>
        ''' Metodo para insertar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Insertar()
            Dim Consecutivo As Integer = 0

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionesNotificaciones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdSesionNotificacion", _IdSesionNotificacion)
                cmd.Parameters.Add("@IdSesion", _IdSesion)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@Cuerpo", _Cuerpo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que LlenarDatos datos
        ''' <summary>
        '''llena todas las propiedades en base a una consulta de sql o Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub LlenarDatos()
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionesNotificaciones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdSesionNotificacion", _IdSesionNotificacion)
                cmd.Parameters.Add("@IdSesion", _IdSesion)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@Cuerpo", _Cuerpo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)



                If dt.Rows.Count > 0 Then
                    _IdSesionNotificacion = IIf(IsDBNull(dt.Rows(0).Item("IdSesionNotificacion")) = True, Nothing, dt.Rows(0).Item("IdSesionNotificacion"))
                    _IdSesion = IIf(IsDBNull(dt.Rows(0).Item("IdSesion")) = True, Nothing, dt.Rows(0).Item("IdSesion"))
                    _Titulo = IIf(IsDBNull(dt.Rows(0).Item("Titulo")) = True, Nothing, dt.Rows(0).Item("Titulo"))
                    _Cuerpo = IIf(IsDBNull(dt.Rows(0).Item("Cuerpo")) = True, Nothing, dt.Rows(0).Item("Cuerpo"))
                    ''|| TagLlenado
                    ''|| EndTagLlenado
                    _Encontrado = True
                Else
                    _IdSesionNotificacion = Nothing
                    _IdSesion = Nothing
                    _Titulo = Nothing
                    _Cuerpo = Nothing
                    ''|| TagLlenado1
                    ''|| EndTagLlemado1
                    _Encontrado = False
                End If
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = "0"

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspSesionesNotificaciones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdSesionNotificacion", _IdSesionNotificacion)
                cmd.Parameters.Add("@IdSesion", _IdSesion)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@Cuerpo", _Cuerpo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function

#End Region


    End Class

End Namespace
