Imports System.Data.SqlClient
Imports System.Data
Imports System.Configuration

Namespace Maple
    Public Class clsArbolComites

#Region "Variables"
        Private _Inicial As String
        Private _CM As String
        Private _CT As String
        Private _SC As String
        Private _GT As String
        Private _Descripcion
        Private _respRetorno(1) As String
        Private cn As SqlConnection

        Private Property Descripcion()
            Get
                Return _Descripcion
            End Get
            Set(ByVal Value)
                _Descripcion = Value
            End Set
        End Property

        Public Property Inicial() As String
            Get
                Return _Inicial
            End Get
            Set(ByVal Value As String)
                _Inicial = Value
            End Set
        End Property
        Public Property CM() As String
            Get
                Return _CM
            End Get
            Set(ByVal Value As String)
                _CM = Value
            End Set
        End Property
        Public Property CT() As String
            Get
                Return _CT
            End Get
            Set(ByVal Value As String)
                _CT = Value
            End Set
        End Property
        Public Property SC() As String
            Get
                Return _SC
            End Get
            Set(ByVal Value As String)
                _SC = Value
            End Set
        End Property
        Public Property GT() As String
            Get
                Return _GT
            End Get
            Set(ByVal Value As String)
                _GT = Value
            End Set
        End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 1 contiene el error en caso de fallar :: la posicion 0 Contiene un (1 o 0), 1 indica que el metodo fallo, y 0 indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property
#End Region
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance"))
        End Sub

        Function getDatosMenu(ByVal ban As Integer, ByVal var1 As String, ByVal Par1 As String, ByVal var2 As String, ByVal Par2 As String, ByVal var3 As String, ByVal Par3 As String) As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "pawIndex"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Ban", ban)
                If Not Par1 = "" Then
                    cmd.Parameters.Add(var1, Par1)
                End If
                If Not Par2 = "" Then
                    cmd.Parameters.Add(var2, Par2)
                End If
                If Not Par3 = "" Then
                    cmd.Parameters.Add(var3, Par3)
                End If

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                da.Dispose()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt

        End Function

    End Class

End Namespace
