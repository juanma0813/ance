Imports System.Configuration
Imports CrystalDecisions.CrystalReports.Engine

Public Class FrmListaAsistencia
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents crvListasAsistencia As CrystalDecisions.Windows.Forms.CrystalReportViewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.crvListasAsistencia = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.SuspendLayout()
        '
        'crvListasAsistencia
        '
        Me.crvListasAsistencia.ActiveViewIndex = -1
        Me.crvListasAsistencia.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.crvListasAsistencia.Location = New System.Drawing.Point(0, 0)
        Me.crvListasAsistencia.Name = "crvListasAsistencia"
        Me.crvListasAsistencia.ReportSource = Nothing
        Me.crvListasAsistencia.Size = New System.Drawing.Size(848, 488)
        Me.crvListasAsistencia.TabIndex = 0
        '
        'FrmListaAsistencia
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(848, 489)
        Me.Controls.Add(Me.crvListasAsistencia)
        Me.Name = "FrmListaAsistencia"
        Me.Text = "..:: Listas Asistencia ::.."
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _IdSesion As Integer
    Private _Sesion As String
    Private _Comite As String
    Private _ComiteNombre As String
    Private _SesionFecha As String

    Public Property IdSesion() As Integer
        Get
            Return _IdSesion
        End Get
        Set(ByVal Value As Integer)
            _IdSesion = Value
        End Set
    End Property

    Public Property Sesion() As String
        Get
            Return _Sesion
        End Get
        Set(ByVal Value As String)
            _Sesion = Value
        End Set
    End Property

    Public Property Comite() As String
        Get
            Return _Comite
        End Get
        Set(ByVal Value As String)
            _Comite = Value
        End Set
    End Property

    Public Property ComiteNombre() As String
        Get
            Return _ComiteNombre
        End Get
        Set(ByVal Value As String)
            _ComiteNombre = Value
        End Set
    End Property

    Public Property SesionFecha() As String
        Get
            Return _SesionFecha
        End Get
        Set(ByVal Value As String)
            _SesionFecha = Value
        End Set
    End Property

    Public Enum eTipoGrupoBlancos As Integer
        InvitadosOtros = 10
        InvitadosConance = 11
        ANCE = 6
    End Enum
    Public Sub GenerarReporte()
        Dim IsLista As Integer = IIf(Comite = "CONANCE", 1, 2)
        LlenarGrupos(IsLista, IdSesion)
    End Sub

    Private Function LlenarGrupos(ByVal IdGrupoListaAsistencia As Integer, ByVal IdSesion As Integer)
        Dim dt As DataTable
        Dim objGruposListas As New clsGruposListasAsistencia.AnceSystem.clssGruposListasAsistencia
        Dim sRutaReporte As String = Application.StartupPath + "\Reportes\rptListasAsistencia.rpt"

        objGruposListas.Bandera = "s2"
        objGruposListas.IdGrupoListaAsistencia = IdGrupoListaAsistencia
        dt = objGruposListas.Listar
        dt.TableName = "dtGruposListaAsistencia"

        Dim ds As New DataSet
        Dim cryRpt As New ReportDocument

        ds.Tables.Add(dt)
        ds.Tables.Add(FillCargosListas(IdGrupoListaAsistencia, IdSesion))

        cryRpt.Load(sRutaReporte)

        cryRpt.SetParameterValue("txtComite", _Comite)
        cryRpt.SetParameterValue("txtComiteNombre", _ComiteNombre)
        cryRpt.SetParameterValue("txtSesion", _Sesion)
        cryRpt.SetParameterValue("txtFechaSesion", _SesionFecha)

        REM cryRpt.PrintOptions.PaperOrientation = CrystalDecisions.[Shared].PaperOrientation.Landscape
        cryRpt.SetDataSource(ds)

        crvListasAsistencia.ReportSource = cryRpt
        crvListasAsistencia.Refresh()
    End Function

    Public Function FillCargosListas(ByVal IdGrupoListaAsistencia As Integer, ByVal IdSesion As Integer) As DataTable
        Dim dt As DataTable
        Dim Parametros As New ArrayList
        Dim paramIdGrupoListaAsistencia As New Maple.entXml
        Dim paramIdSesion As New Maple.entXml
        Dim paramComite As New Maple.entXml
        Dim objGruposListas As New clsGruposListasAsistencia.AnceSystem.clssGruposListasAsistencia
        objGruposListas.Bandera = "s3"

        paramIdGrupoListaAsistencia.Key = "IdGrupoListaAsistencia"
        paramIdGrupoListaAsistencia.Value = IdGrupoListaAsistencia

        paramIdSesion.Key = "IdSesion"
        paramIdSesion.Value = IdSesion

        paramComite.Value = _Comite
        paramComite.Key = "Comite"

        Parametros.Add(paramIdGrupoListaAsistencia)
        Parametros.Add(paramIdSesion)
        Parametros.Add(paramComite)

        objGruposListas.Xml = Maple.clssufnSQL.CrearXmlParamSql(Parametros)
        dt = objGruposListas.Listar
        dt.TableName = "dtCargos"

        If dt.Rows.Count > 0 Then
            _ComiteNombre = dt.Rows(0).Item("NombreComite")
        End If

        REM Dim TipoGrupoBlancos As eTipoGrupoBlancos = IIf(Comite = "CONANCE", eTipoGrupoBlancos.ANCE, eTipoGrupoBlancos.Invitados)

        REM dt = AgregarEspacios(dt, eTipoGrupoBlancos.ANCE)
        REM solo CONANCE lleva gupo ANCE e invitados, los demas solo invitados
        ''If Comite = "CONANCE" Then
        ''    dt = AgregarEspacios(dt, eTipoGrupoBlancos.ANCE)
        ''    dt = AgregarEspacios(dt, eTipoGrupoBlancos.InvitadosConance)
        ''Else
        ''    dt = AgregarEspacios(dt, eTipoGrupoBlancos.InvitadosOtros)
        ''End If


        Return dt
    End Function

    Public Function AgregarEspacios(ByVal dt As DataTable, ByVal TipoGrupoBlancos As eTipoGrupoBlancos) As DataTable

        For i As Integer = 1 To 7
            Dim newRow As DataRow = dt.NewRow()
            newRow("IdGrupoListaAsistencia") = TipoGrupoBlancos
            newRow("Institucion_Comite") = ""
            newRow("Nombre") = ""
            newRow("Firma") = ""
            newRow("Cargo") = ""
            newRow("Telefono") = ""
            newRow("Mail") = ""
            dt.Rows.Add(newRow)
        Next

        Return dt
    End Function

    Private Sub FrmListaAsistencia_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        _Sesion = Microsoft.VisualBasic.Interaction.InputBox("Favor de ingresar el n�mero de sesi�n", "Numero de sesi�n", _Sesion, 200, 100)
    End Sub
End Class
