'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
'   NOMBRE DE LA CLASE:     CLSMENU
'   DESARROLLADA POR :      EXTI, S.C. PARA ANCE, A.C.
'                           CHRISTIAN C�RDENAS OLIVARES
'   FECHA DE CREACI�N:      12 FEBRERO 2006
'
'   BASES RELACIONADAS:     DBANCE
'
'   TABLAS RELACIONADAS:    C_Grupos_Detalle Y C_Sistema_Menu
'
'   DESCRIPCION:            HABILITA LOS MENUS DE UNA APLICACI�N EN .NET
'                           DE ACUERDO A LA PROPIEDAD TEXTO DEL ITEM DEL MENU. 
'                           EL VALOR DE ESTA PROPIEDAD SE ENCUENTRA EN LAS TABLAS C_Grupos_Detalle Y C_Sistema_Menu
'
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class clsMenus
    Private cn As New SqlClient.SqlConnection
    Private dsMenus As New DataSet
    Private objConexion As New clsConexionArchivo.clsConexionArchivo
    Private sSQL As String
    Private _Grupo As Integer
    Private _Id_Usuario As String
    Private _sistema As Integer
    Private _id_menu As String
    Private _nombre_menu As String
    Private _Bandera As Integer

#Region " Propiedades"

    Public Property Id_Usuario() As String
        Get
            Return _Id_Usuario

        End Get
        Set(ByVal Value As String)
            _Id_Usuario = Value
        End Set
    End Property

    Public Property id_menu() As String
        Get
            Return _id_menu

        End Get
        Set(ByVal Value As String)
            _id_menu = Value
        End Set
    End Property

    Public Property nombre_menu() As String
        Get
            Return _nombre_menu

        End Get
        Set(ByVal Value As String)
            _nombre_menu = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera

        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sistema() As Integer
        Get
            Return _sistema

        End Get
        Set(ByVal Value As Integer)
            _sistema = Value
        End Set
    End Property

    Public Property Id_Grupo() As Integer
        Get
            Return _Grupo

        End Get
        Set(ByVal Value As Integer)
            _Grupo = Value
        End Set
    End Property


#End Region

    ''OBTIENE LAS OPCIONES A LAS QUE TIENE DERECHO EL USUARIO
    Public Function Menus() As DataSet
        Dim cmd As New SqlCommand
        Dim da As New SqlDataAdapter(cmd)
        Try


        If cn.State = ConnectionState.Open Then cn.Close()
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_Grupos"
            cmd.Connection = cn
            cmd.Parameters.Add("@Id_Usuario", _Id_Usuario)
            cmd.Parameters.Add("@Id_Grupo", _Grupo)
            cmd.Parameters.Add("@Id_sistema", _sistema)
            REM cmd.Parameters.Add("@Bandera", 9)
            cmd.Parameters.Add("@Bandera", 5)
            cn.Open()
            da.Fill(dsMenus, "C_Menus")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cn.Close()
        cmd.Dispose()
        Return dsMenus
    End Function


    ''Public Function Habilita_menus(ByVal dsmenu As DataSet, ByVal Forma As Form)

    ''    Dim x As New MainMenu
    ''    Dim sStatus As String
    ''    x = Forma.Menu

    ''    ''PARA DESHABILITAR
    ''    If Not Deshabilita(x.MenuItems) Then
    ''        Exit Function
    ''    End If
    ''    ''''PARA HABILITAR
    ''    sStatus = Habilita(x.MenuItems, dsmenu)
    ''    If sStatus <> "Ok" Then
    ''        MsgBox(sStatus)
    ''        Exit Function
    ''    End If
    ''End Function

    Public Function Habilita_menus(ByVal dsmenu As DataSet, ByVal mnu As MainMenu)
        Dim sStatus As String

        ''PARA DESHABILITAR
        If Not Deshabilita(mnu.MenuItems) Then
            Exit Function
        End If
        ''    ''''PARA HABILITAR
        sStatus = Habilita(mnu.MenuItems, dsmenu)
        If sStatus <> "Ok" Then
            MsgBox(sStatus)
            Exit Function
        End If
    End Function

    Public Function Deshabilita(ByVal Menu As MainMenu.MenuItemCollection) As Boolean
        Try
            Dim i As Integer
            For i = 0 To Menu.Count - 1 Step 1
                Menu.Item(i).Enabled = False
                If Menu.Item(i).IsParent Then Deshabilita(Menu.Item(i).MenuItems)
            Next
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    ''Private Function Habilita(ByVal Menu As MainMenu.MenuItemCollection, ByVal dsmenu As DataSet) As String
    ''    Try
    ''        Dim i, j As Integer
    ''        For i = 0 To Menu.Count - 1 Step 1
    ''            For j = 0 To dsmenu.Tables("C_Menus").Rows.Count - 1 Step 1
    ''                If Menu.Item(i).Text = dsmenu.Tables("C_Menus").Rows(j).Item("nombre_menu") Then
    ''                    Menu.Item(i).Enabled = True
    ''                    If Menu.Item(i).IsParent Then Habilita(Menu.Item(i).MenuItems, dsmenu)
    ''                End If
    ''            Next
    ''        Next
    ''        Return "Ok"
    ''    Catch ex As Exception
    ''        Return "Error " & ex.Message
    ''    End Try
    ''End Function

    Private Function Habilita(ByVal mnu As MainMenu.MenuItemCollection, ByVal dsmenu As DataSet) As String
        Dim Items As DataRow
        Dim dt As DataTable = dsmenu.Tables(0)
        Dim Ciclo As Integer = 0
        Try

            REM se debe de pasar por todos los menus y por cada menu hay que ver si 
            REM se encuentra en el data table
            REM recorre todos los permisos ahora es buscar del menu el nombre 
            While Ciclo < mnu.Count
                If mnu.Item(Ciclo).IsParent Then
                    mnu.Item(Ciclo).Enabled = Consultar(mnu.Item(Ciclo).Text, dt)
                    Habilita(mnu.Item(Ciclo).MenuItems, dsmenu)
                Else
                    mnu.Item(Ciclo).Enabled = Consultar(mnu.Item(Ciclo).Text, dt)
                End If

                Ciclo += 1
            End While

            Return "Ok"
        Catch ex As Exception
            Return "Error " & ex.Message
        Finally
            dt = Nothing
        End Try
    End Function

    Private Function Consultar(ByVal Parametro As String, ByVal dt As DataTable) As Boolean
        Dim Acceso As Boolean
        REM filtrar el datatable

        Dim rows As DataRow()
        Dim dtNew As DataTable

        dtNew = dt.Clone()
        'Donde strSelectgral es un where asunto = ''
        rows = dt.Select("Nombre_Menu='" & Parametro & "'")
        For Each dr As DataRow In rows
            dtNew.ImportRow(dr)
        Next

        If dtNew.Rows.Count > 0 Then
            Acceso = True
        Else
            Acceso = False
        End If

        dtNew = Nothing
        rows = Nothing


        Return Acceso
    End Function


    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSQL = objConexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSQL

        Servidor = objConexion.SserverC
        Base = objConexion.SBaseD
    End Sub

    Public Function Listar() As DataTable
        Dim cmd As New SqlCommand
        If cn.State = ConnectionState.Open Then cn.Close()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Grupo_Detalle_Buscar "
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Grupo", _Grupo)
        cmd.Parameters.Add("@Id_sistema", _sistema)
        cmd.Parameters.Add("@Bandera", _Bandera)
        cn.Open()
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Menus")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception

        End Try

    End Function

    Public Function Inserta_menus(ByVal Gusuario As String, ByVal Gpassword As String)
        Dim cn1 As New SqlClient.SqlConnection
        sSQL = objConexion.Conexion(1, Gusuario, Gpassword)
        cn1.ConnectionString = sSQL
        Dim cmd As New SqlCommand
        If cn.State = ConnectionState.Open Then cn.Close()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Sistemas_Menu "
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_sistema", _sistema)
        cmd.Parameters.Add("@Id_menu", _id_menu)
        cmd.Parameters.Add("@nombre_menu", _nombre_menu)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try

            cn1.Open()
            cmd.ExecuteNonQuery()
            cn1.Close()
        Catch ex As Exception

        End Try

    End Function


End Class
