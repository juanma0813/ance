Imports System.IO
Public Class FrmGestionDoctos
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents txtActaPROYF As System.Windows.Forms.TextBox
    Friend WithEvents txtProy As System.Windows.Forms.TextBox
    Friend WithEvents txtAnteproy As System.Windows.Forms.TextBox
    Friend WithEvents txtAprobacion As System.Windows.Forms.TextBox
    Friend WithEvents TxtActa As System.Windows.Forms.TextBox
    Friend WithEvents txtMinuta As System.Windows.Forms.TextBox
    Friend WithEvents txtTrabajoFinal As System.Windows.Forms.TextBox
    Friend WithEvents TVTemas As System.Windows.Forms.TreeView
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents BtnBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents optMinutaTerminacion As System.Windows.Forms.RadioButton
    Friend WithEvents optTrabajoFinal As System.Windows.Forms.RadioButton
    Friend WithEvents optActaAprobacion As System.Windows.Forms.RadioButton
    Friend WithEvents optMinutaAprobacion As System.Windows.Forms.RadioButton
    Friend WithEvents optAntF As System.Windows.Forms.RadioButton
    Friend WithEvents optProyF As System.Windows.Forms.RadioButton
    Friend WithEvents optApPROYF As System.Windows.Forms.RadioButton
    Friend WithEvents lblStatus2 As System.Windows.Forms.Label
    Friend WithEvents lblStatus1 As System.Windows.Forms.Label
    Friend WithEvents lblStatus3 As System.Windows.Forms.Label
    Friend WithEvents lblStatus4 As System.Windows.Forms.Label
    Friend WithEvents lblStatus5 As System.Windows.Forms.Label
    Friend WithEvents lblStatus6 As System.Windows.Forms.Label
    Friend WithEvents lblStatus7 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TabCDocots As System.Windows.Forms.TabControl
    Friend WithEvents txtDocumentoNorma As System.Windows.Forms.TextBox
    Friend WithEvents txtAclaracion1 As System.Windows.Forms.TextBox
    Friend WithEvents txtAclaracion2 As System.Windows.Forms.TextBox
    Friend WithEvents cboNormas As System.Windows.Forms.ComboBox
    Friend WithEvents optAclaracion1 As System.Windows.Forms.RadioButton
    Friend WithEvents optAclaracion2 As System.Windows.Forms.RadioButton
    Friend WithEvents optDoctoNorma As System.Windows.Forms.RadioButton
    Friend WithEvents txtDoctoNoticia As System.Windows.Forms.TextBox
    Friend WithEvents cboNoticias As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tvActualizacion As System.Windows.Forms.TreeView
    Friend WithEvents txtF_Inicio As System.Windows.Forms.TextBox
    Friend WithEvents cmdAgregar As System.Windows.Forms.Button
    Friend WithEvents txtDocto As System.Windows.Forms.TextBox
    Friend WithEvents txtPertenece As System.Windows.Forms.TextBox
    Friend WithEvents TxtTitulo As System.Windows.Forms.TextBox
    Friend WithEvents txtclasificacion As System.Windows.Forms.TextBox
    Friend WithEvents grdDoctosDT As System.Windows.Forms.DataGrid
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents cboSesiones As System.Windows.Forms.ComboBox
    Friend WithEvents grdSesionesDoctos As System.Windows.Forms.DataGrid
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents lblStatusNorma As System.Windows.Forms.Label
    Friend WithEvents optMatrizAlt As System.Windows.Forms.RadioButton
    Friend WithEvents txtMatrizAlt As System.Windows.Forms.TextBox
    Friend WithEvents txtMatrizProy As System.Windows.Forms.TextBox
    Friend WithEvents optMatrizProy As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmGestionDoctos))
        Me.TabCDocots = New System.Windows.Forms.TabControl
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.txtF_Inicio = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.grdDoctosDT = New System.Windows.Forms.DataGrid
        Me.cmdAgregar = New System.Windows.Forms.Button
        Me.txtDocto = New System.Windows.Forms.TextBox
        Me.txtPertenece = New System.Windows.Forms.TextBox
        Me.TxtTitulo = New System.Windows.Forms.TextBox
        Me.txtclasificacion = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.tvActualizacion = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtMatrizProy = New System.Windows.Forms.TextBox
        Me.optMatrizProy = New System.Windows.Forms.RadioButton
        Me.lblStatus7 = New System.Windows.Forms.Label
        Me.lblStatus6 = New System.Windows.Forms.Label
        Me.optApPROYF = New System.Windows.Forms.RadioButton
        Me.optProyF = New System.Windows.Forms.RadioButton
        Me.txtActaPROYF = New System.Windows.Forms.TextBox
        Me.txtProy = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lblStatus5 = New System.Windows.Forms.Label
        Me.lblStatus4 = New System.Windows.Forms.Label
        Me.lblStatus3 = New System.Windows.Forms.Label
        Me.optAntF = New System.Windows.Forms.RadioButton
        Me.optMinutaAprobacion = New System.Windows.Forms.RadioButton
        Me.txtAnteproy = New System.Windows.Forms.TextBox
        Me.txtAprobacion = New System.Windows.Forms.TextBox
        Me.TxtActa = New System.Windows.Forms.TextBox
        Me.optActaAprobacion = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtMatrizAlt = New System.Windows.Forms.TextBox
        Me.optMatrizAlt = New System.Windows.Forms.RadioButton
        Me.lblStatus1 = New System.Windows.Forms.Label
        Me.lblStatus2 = New System.Windows.Forms.Label
        Me.optTrabajoFinal = New System.Windows.Forms.RadioButton
        Me.optMinutaTerminacion = New System.Windows.Forms.RadioButton
        Me.txtMinuta = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtTrabajoFinal = New System.Windows.Forms.TextBox
        Me.TVTemas = New System.Windows.Forms.TreeView
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.lblStatus = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtDoctoNoticia = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.cboNoticias = New System.Windows.Forms.ComboBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.lblStatusNorma = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtAclaracion1 = New System.Windows.Forms.TextBox
        Me.txtAclaracion2 = New System.Windows.Forms.TextBox
        Me.optAclaracion2 = New System.Windows.Forms.RadioButton
        Me.optAclaracion1 = New System.Windows.Forms.RadioButton
        Me.txtDocumentoNorma = New System.Windows.Forms.TextBox
        Me.optDoctoNorma = New System.Windows.Forms.RadioButton
        Me.Label9 = New System.Windows.Forms.Label
        Me.cboNormas = New System.Windows.Forms.ComboBox
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.cboSesiones = New System.Windows.Forms.ComboBox
        Me.grdSesionesDoctos = New System.Windows.Forms.DataGrid
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.BtnBotonera = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.TabCDocots.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        CType(Me.grdDoctosDT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        CType(Me.grdSesionesDoctos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabCDocots
        '
        Me.TabCDocots.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabCDocots.Controls.Add(Me.TabPage6)
        Me.TabCDocots.Controls.Add(Me.TabPage1)
        Me.TabCDocots.Controls.Add(Me.TabPage4)
        Me.TabCDocots.Controls.Add(Me.TabPage2)
        Me.TabCDocots.Controls.Add(Me.TabPage5)
        Me.TabCDocots.Location = New System.Drawing.Point(16, 8)
        Me.TabCDocots.Name = "TabCDocots"
        Me.TabCDocots.SelectedIndex = 0
        Me.TabCDocots.Size = New System.Drawing.Size(680, 428)
        Me.TabCDocots.TabIndex = 0
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.txtF_Inicio)
        Me.TabPage6.Controls.Add(Me.Label20)
        Me.TabPage6.Controls.Add(Me.grdDoctosDT)
        Me.TabPage6.Controls.Add(Me.cmdAgregar)
        Me.TabPage6.Controls.Add(Me.txtDocto)
        Me.TabPage6.Controls.Add(Me.txtPertenece)
        Me.TabPage6.Controls.Add(Me.TxtTitulo)
        Me.TabPage6.Controls.Add(Me.txtclasificacion)
        Me.TabPage6.Controls.Add(Me.Label19)
        Me.TabPage6.Controls.Add(Me.Label17)
        Me.TabPage6.Controls.Add(Me.Label16)
        Me.TabPage6.Controls.Add(Me.Label15)
        Me.TabPage6.Controls.Add(Me.tvActualizacion)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(672, 402)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Actualizacion de DT"
        '
        'txtF_Inicio
        '
        Me.txtF_Inicio.Enabled = False
        Me.txtF_Inicio.Location = New System.Drawing.Point(544, 128)
        Me.txtF_Inicio.Name = "txtF_Inicio"
        Me.txtF_Inicio.Size = New System.Drawing.Size(120, 20)
        Me.txtF_Inicio.TabIndex = 15
        Me.txtF_Inicio.Text = ""
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(456, 128)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 16)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "Fecha de Inicio:"
        '
        'grdDoctosDT
        '
        Me.grdDoctosDT.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdDoctosDT.BackgroundColor = System.Drawing.Color.White
        Me.grdDoctosDT.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.grdDoctosDT.DataMember = ""
        Me.grdDoctosDT.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdDoctosDT.Location = New System.Drawing.Point(208, 200)
        Me.grdDoctosDT.Name = "grdDoctosDT"
        Me.grdDoctosDT.ReadOnly = True
        Me.grdDoctosDT.Size = New System.Drawing.Size(456, 196)
        Me.grdDoctosDT.TabIndex = 13
        '
        'cmdAgregar
        '
        Me.cmdAgregar.Location = New System.Drawing.Point(608, 168)
        Me.cmdAgregar.Name = "cmdAgregar"
        Me.cmdAgregar.Size = New System.Drawing.Size(56, 20)
        Me.cmdAgregar.TabIndex = 12
        Me.cmdAgregar.Text = "Agregar"
        '
        'txtDocto
        '
        Me.txtDocto.Enabled = False
        Me.txtDocto.Location = New System.Drawing.Point(288, 168)
        Me.txtDocto.Name = "txtDocto"
        Me.txtDocto.Size = New System.Drawing.Size(320, 20)
        Me.txtDocto.TabIndex = 11
        Me.txtDocto.Text = ""
        '
        'txtPertenece
        '
        Me.txtPertenece.Enabled = False
        Me.txtPertenece.Location = New System.Drawing.Point(288, 128)
        Me.txtPertenece.Name = "txtPertenece"
        Me.txtPertenece.Size = New System.Drawing.Size(120, 20)
        Me.txtPertenece.TabIndex = 9
        Me.txtPertenece.Text = ""
        '
        'TxtTitulo
        '
        Me.TxtTitulo.Enabled = False
        Me.TxtTitulo.Location = New System.Drawing.Point(288, 48)
        Me.TxtTitulo.Multiline = True
        Me.TxtTitulo.Name = "TxtTitulo"
        Me.TxtTitulo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TxtTitulo.Size = New System.Drawing.Size(376, 72)
        Me.TxtTitulo.TabIndex = 8
        Me.TxtTitulo.Text = ""
        '
        'txtclasificacion
        '
        Me.txtclasificacion.Enabled = False
        Me.txtclasificacion.Location = New System.Drawing.Point(288, 16)
        Me.txtclasificacion.Name = "txtclasificacion"
        Me.txtclasificacion.Size = New System.Drawing.Size(376, 20)
        Me.txtclasificacion.TabIndex = 7
        Me.txtclasificacion.Text = ""
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(232, 176)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(45, 16)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "Archivo:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(216, 128)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 16)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "Pertenece:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(240, 56)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(35, 16)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "T�tulo:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(208, 16)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(71, 16)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Clasificacion:"
        '
        'tvActualizacion
        '
        Me.tvActualizacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tvActualizacion.ImageIndex = 2
        Me.tvActualizacion.ImageList = Me.imgListTreeView
        Me.tvActualizacion.Location = New System.Drawing.Point(8, 8)
        Me.tvActualizacion.Name = "tvActualizacion"
        Me.tvActualizacion.SelectedImageIndex = 2
        Me.tvActualizacion.Size = New System.Drawing.Size(192, 388)
        Me.tvActualizacion.TabIndex = 1
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.TVTemas)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(624, 358)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Temas"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.txtMatrizProy)
        Me.GroupBox3.Controls.Add(Me.optMatrizProy)
        Me.GroupBox3.Controls.Add(Me.lblStatus7)
        Me.GroupBox3.Controls.Add(Me.lblStatus6)
        Me.GroupBox3.Controls.Add(Me.optApPROYF)
        Me.GroupBox3.Controls.Add(Me.optProyF)
        Me.GroupBox3.Controls.Add(Me.txtActaPROYF)
        Me.GroupBox3.Controls.Add(Me.txtProy)
        Me.GroupBox3.Location = New System.Drawing.Point(160, 240)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(456, 96)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Proyecto"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label3.Location = New System.Drawing.Point(360, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 20)
        Me.Label3.TabIndex = 15
        '
        'txtMatrizProy
        '
        Me.txtMatrizProy.Location = New System.Drawing.Point(184, 64)
        Me.txtMatrizProy.Name = "txtMatrizProy"
        Me.txtMatrizProy.ReadOnly = True
        Me.txtMatrizProy.Size = New System.Drawing.Size(176, 20)
        Me.txtMatrizProy.TabIndex = 15
        Me.txtMatrizProy.Text = ""
        '
        'optMatrizProy
        '
        Me.optMatrizProy.Location = New System.Drawing.Point(24, 64)
        Me.optMatrizProy.Name = "optMatrizProy"
        Me.optMatrizProy.Size = New System.Drawing.Size(152, 24)
        Me.optMatrizProy.TabIndex = 14
        Me.optMatrizProy.Text = "Matriz de Comentarios"
        '
        'lblStatus7
        '
        Me.lblStatus7.AutoSize = True
        Me.lblStatus7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus7.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus7.Location = New System.Drawing.Point(368, 40)
        Me.lblStatus7.Name = "lblStatus7"
        Me.lblStatus7.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus7.TabIndex = 12
        '
        'lblStatus6
        '
        Me.lblStatus6.AutoSize = True
        Me.lblStatus6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus6.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus6.Location = New System.Drawing.Point(368, 16)
        Me.lblStatus6.Name = "lblStatus6"
        Me.lblStatus6.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus6.TabIndex = 11
        '
        'optApPROYF
        '
        Me.optApPROYF.Location = New System.Drawing.Point(24, 40)
        Me.optApPROYF.Name = "optApPROYF"
        Me.optApPROYF.Size = New System.Drawing.Size(152, 24)
        Me.optApPROYF.TabIndex = 7
        Me.optApPROYF.Text = "Acta aprobacion PROYF: "
        '
        'optProyF
        '
        Me.optProyF.Location = New System.Drawing.Point(24, 16)
        Me.optProyF.Name = "optProyF"
        Me.optProyF.TabIndex = 6
        Me.optProyF.Text = "Proyecto Final: "
        '
        'txtActaPROYF
        '
        Me.txtActaPROYF.Location = New System.Drawing.Point(184, 40)
        Me.txtActaPROYF.Name = "txtActaPROYF"
        Me.txtActaPROYF.ReadOnly = True
        Me.txtActaPROYF.Size = New System.Drawing.Size(176, 20)
        Me.txtActaPROYF.TabIndex = 3
        Me.txtActaPROYF.Text = ""
        '
        'txtProy
        '
        Me.txtProy.Location = New System.Drawing.Point(184, 16)
        Me.txtProy.Name = "txtProy"
        Me.txtProy.ReadOnly = True
        Me.txtProy.Size = New System.Drawing.Size(176, 20)
        Me.txtProy.TabIndex = 1
        Me.txtProy.Text = ""
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.lblStatus5)
        Me.GroupBox2.Controls.Add(Me.lblStatus4)
        Me.GroupBox2.Controls.Add(Me.lblStatus3)
        Me.GroupBox2.Controls.Add(Me.optAntF)
        Me.GroupBox2.Controls.Add(Me.optMinutaAprobacion)
        Me.GroupBox2.Controls.Add(Me.txtAnteproy)
        Me.GroupBox2.Controls.Add(Me.txtAprobacion)
        Me.GroupBox2.Controls.Add(Me.TxtActa)
        Me.GroupBox2.Controls.Add(Me.optActaAprobacion)
        Me.GroupBox2.Location = New System.Drawing.Point(160, 136)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(456, 96)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "AnteProyecto"
        '
        'lblStatus5
        '
        Me.lblStatus5.AutoSize = True
        Me.lblStatus5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus5.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus5.Location = New System.Drawing.Point(368, 64)
        Me.lblStatus5.Name = "lblStatus5"
        Me.lblStatus5.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus5.TabIndex = 13
        '
        'lblStatus4
        '
        Me.lblStatus4.AutoSize = True
        Me.lblStatus4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus4.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus4.Location = New System.Drawing.Point(368, 40)
        Me.lblStatus4.Name = "lblStatus4"
        Me.lblStatus4.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus4.TabIndex = 12
        '
        'lblStatus3
        '
        Me.lblStatus3.AutoSize = True
        Me.lblStatus3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus3.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus3.Location = New System.Drawing.Point(368, 16)
        Me.lblStatus3.Name = "lblStatus3"
        Me.lblStatus3.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus3.TabIndex = 11
        '
        'optAntF
        '
        Me.optAntF.Location = New System.Drawing.Point(24, 64)
        Me.optAntF.Name = "optAntF"
        Me.optAntF.Size = New System.Drawing.Size(120, 24)
        Me.optAntF.TabIndex = 10
        Me.optAntF.Text = "Anteproyecto final:"
        '
        'optMinutaAprobacion
        '
        Me.optMinutaAprobacion.Location = New System.Drawing.Point(24, 40)
        Me.optMinutaAprobacion.Name = "optMinutaAprobacion"
        Me.optMinutaAprobacion.Size = New System.Drawing.Size(136, 24)
        Me.optMinutaAprobacion.TabIndex = 9
        Me.optMinutaAprobacion.Text = "Minuta de aprobacion:"
        '
        'txtAnteproy
        '
        Me.txtAnteproy.Location = New System.Drawing.Point(168, 64)
        Me.txtAnteproy.Name = "txtAnteproy"
        Me.txtAnteproy.ReadOnly = True
        Me.txtAnteproy.Size = New System.Drawing.Size(192, 20)
        Me.txtAnteproy.TabIndex = 5
        Me.txtAnteproy.Text = ""
        '
        'txtAprobacion
        '
        Me.txtAprobacion.Location = New System.Drawing.Point(168, 40)
        Me.txtAprobacion.Name = "txtAprobacion"
        Me.txtAprobacion.ReadOnly = True
        Me.txtAprobacion.Size = New System.Drawing.Size(192, 20)
        Me.txtAprobacion.TabIndex = 4
        Me.txtAprobacion.Text = ""
        '
        'TxtActa
        '
        Me.TxtActa.Location = New System.Drawing.Point(168, 16)
        Me.TxtActa.Name = "TxtActa"
        Me.TxtActa.ReadOnly = True
        Me.TxtActa.Size = New System.Drawing.Size(192, 20)
        Me.TxtActa.TabIndex = 3
        Me.TxtActa.Text = ""
        '
        'optActaAprobacion
        '
        Me.optActaAprobacion.Location = New System.Drawing.Point(24, 16)
        Me.optActaAprobacion.Name = "optActaAprobacion"
        Me.optActaAprobacion.Size = New System.Drawing.Size(136, 24)
        Me.optActaAprobacion.TabIndex = 6
        Me.optActaAprobacion.Text = "Acta aprobacion final:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtMatrizAlt)
        Me.GroupBox1.Controls.Add(Me.optMatrizAlt)
        Me.GroupBox1.Controls.Add(Me.lblStatus1)
        Me.GroupBox1.Controls.Add(Me.lblStatus2)
        Me.GroupBox1.Controls.Add(Me.optTrabajoFinal)
        Me.GroupBox1.Controls.Add(Me.optMinutaTerminacion)
        Me.GroupBox1.Controls.Add(Me.txtMinuta)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtTrabajoFinal)
        Me.GroupBox1.Location = New System.Drawing.Point(160, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(456, 120)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "D T"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label1.Location = New System.Drawing.Point(368, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 20)
        Me.Label1.TabIndex = 14
        '
        'txtMatrizAlt
        '
        Me.txtMatrizAlt.Location = New System.Drawing.Point(184, 88)
        Me.txtMatrizAlt.Name = "txtMatrizAlt"
        Me.txtMatrizAlt.ReadOnly = True
        Me.txtMatrizAlt.Size = New System.Drawing.Size(176, 20)
        Me.txtMatrizAlt.TabIndex = 13
        Me.txtMatrizAlt.Text = ""
        '
        'optMatrizAlt
        '
        Me.optMatrizAlt.Location = New System.Drawing.Point(24, 88)
        Me.optMatrizAlt.Name = "optMatrizAlt"
        Me.optMatrizAlt.Size = New System.Drawing.Size(152, 24)
        Me.optMatrizAlt.TabIndex = 12
        Me.optMatrizAlt.Text = "Matriz de Comentarios"
        '
        'lblStatus1
        '
        Me.lblStatus1.AutoSize = True
        Me.lblStatus1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus1.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus1.Location = New System.Drawing.Point(368, 24)
        Me.lblStatus1.Name = "lblStatus1"
        Me.lblStatus1.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus1.TabIndex = 11
        '
        'lblStatus2
        '
        Me.lblStatus2.AutoSize = True
        Me.lblStatus2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus2.ForeColor = System.Drawing.Color.Firebrick
        Me.lblStatus2.Location = New System.Drawing.Point(368, 64)
        Me.lblStatus2.Name = "lblStatus2"
        Me.lblStatus2.Size = New System.Drawing.Size(0, 20)
        Me.lblStatus2.TabIndex = 10
        '
        'optTrabajoFinal
        '
        Me.optTrabajoFinal.Location = New System.Drawing.Point(24, 16)
        Me.optTrabajoFinal.Name = "optTrabajoFinal"
        Me.optTrabajoFinal.Size = New System.Drawing.Size(160, 24)
        Me.optTrabajoFinal.TabIndex = 8
        Me.optTrabajoFinal.Text = "Documento de trabajo final:"
        '
        'optMinutaTerminacion
        '
        Me.optMinutaTerminacion.Location = New System.Drawing.Point(24, 56)
        Me.optMinutaTerminacion.Name = "optMinutaTerminacion"
        Me.optMinutaTerminacion.Size = New System.Drawing.Size(152, 32)
        Me.optMinutaTerminacion.TabIndex = 7
        Me.optMinutaTerminacion.Text = "Minuta de terminacion de procedimiento alternativo:"
        '
        'txtMinuta
        '
        Me.txtMinuta.Location = New System.Drawing.Point(184, 64)
        Me.txtMinuta.Name = "txtMinuta"
        Me.txtMinuta.ReadOnly = True
        Me.txtMinuta.Size = New System.Drawing.Size(176, 20)
        Me.txtMinuta.TabIndex = 5
        Me.txtMinuta.Text = ""
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Procedimiento Alternativo"
        '
        'txtTrabajoFinal
        '
        Me.txtTrabajoFinal.Location = New System.Drawing.Point(184, 16)
        Me.txtTrabajoFinal.Name = "txtTrabajoFinal"
        Me.txtTrabajoFinal.ReadOnly = True
        Me.txtTrabajoFinal.Size = New System.Drawing.Size(176, 20)
        Me.txtTrabajoFinal.TabIndex = 1
        Me.txtTrabajoFinal.Text = ""
        '
        'TVTemas
        '
        Me.TVTemas.ImageIndex = 2
        Me.TVTemas.ImageList = Me.imgListTreeView
        Me.TVTemas.Location = New System.Drawing.Point(8, 8)
        Me.TVTemas.Name = "TVTemas"
        Me.TVTemas.SelectedImageIndex = 2
        Me.TVTemas.Size = New System.Drawing.Size(144, 336)
        Me.TVTemas.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.lblStatus)
        Me.TabPage4.Controls.Add(Me.Label14)
        Me.TabPage4.Controls.Add(Me.txtDoctoNoticia)
        Me.TabPage4.Controls.Add(Me.Label13)
        Me.TabPage4.Controls.Add(Me.cboNoticias)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(624, 358)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Noticias"
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(40, 96)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 31)
        Me.lblStatus.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(48, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(42, 16)
        Me.Label14.TabIndex = 4
        Me.Label14.Text = "Noticia:"
        '
        'txtDoctoNoticia
        '
        Me.txtDoctoNoticia.Location = New System.Drawing.Point(104, 56)
        Me.txtDoctoNoticia.Name = "txtDoctoNoticia"
        Me.txtDoctoNoticia.ReadOnly = True
        Me.txtDoctoNoticia.Size = New System.Drawing.Size(280, 20)
        Me.txtDoctoNoticia.TabIndex = 2
        Me.txtDoctoNoticia.Text = ""
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(32, 56)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 16)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Documento:"
        '
        'cboNoticias
        '
        Me.cboNoticias.Location = New System.Drawing.Point(104, 24)
        Me.cboNoticias.Name = "cboNoticias"
        Me.cboNoticias.Size = New System.Drawing.Size(88, 21)
        Me.cboNoticias.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.lblStatusNorma)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.cboNormas)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(624, 358)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Catalogo de Normas"
        '
        'lblStatusNorma
        '
        Me.lblStatusNorma.AutoSize = True
        Me.lblStatusNorma.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusNorma.Location = New System.Drawing.Point(32, 200)
        Me.lblStatusNorma.Name = "lblStatusNorma"
        Me.lblStatusNorma.Size = New System.Drawing.Size(0, 31)
        Me.lblStatusNorma.TabIndex = 9
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.txtAclaracion1)
        Me.GroupBox4.Controls.Add(Me.txtAclaracion2)
        Me.GroupBox4.Controls.Add(Me.optAclaracion2)
        Me.GroupBox4.Controls.Add(Me.optAclaracion1)
        Me.GroupBox4.Controls.Add(Me.txtDocumentoNorma)
        Me.GroupBox4.Controls.Add(Me.optDoctoNorma)
        Me.GroupBox4.Location = New System.Drawing.Point(24, 56)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(592, 136)
        Me.GroupBox4.TabIndex = 8
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Aclaraciones"
        '
        'txtAclaracion1
        '
        Me.txtAclaracion1.Location = New System.Drawing.Point(120, 24)
        Me.txtAclaracion1.Name = "txtAclaracion1"
        Me.txtAclaracion1.ReadOnly = True
        Me.txtAclaracion1.Size = New System.Drawing.Size(176, 20)
        Me.txtAclaracion1.TabIndex = 4
        Me.txtAclaracion1.Text = ""
        '
        'txtAclaracion2
        '
        Me.txtAclaracion2.Location = New System.Drawing.Point(120, 56)
        Me.txtAclaracion2.Name = "txtAclaracion2"
        Me.txtAclaracion2.ReadOnly = True
        Me.txtAclaracion2.Size = New System.Drawing.Size(176, 20)
        Me.txtAclaracion2.TabIndex = 5
        Me.txtAclaracion2.Text = ""
        '
        'optAclaracion2
        '
        Me.optAclaracion2.Location = New System.Drawing.Point(16, 56)
        Me.optAclaracion2.Name = "optAclaracion2"
        Me.optAclaracion2.TabIndex = 11
        Me.optAclaracion2.Text = "Aclaracion dos:"
        '
        'optAclaracion1
        '
        Me.optAclaracion1.Location = New System.Drawing.Point(16, 24)
        Me.optAclaracion1.Name = "optAclaracion1"
        Me.optAclaracion1.TabIndex = 10
        Me.optAclaracion1.Text = "Aclaracion uno:"
        '
        'txtDocumentoNorma
        '
        Me.txtDocumentoNorma.Location = New System.Drawing.Point(160, 88)
        Me.txtDocumentoNorma.Name = "txtDocumentoNorma"
        Me.txtDocumentoNorma.ReadOnly = True
        Me.txtDocumentoNorma.Size = New System.Drawing.Size(200, 20)
        Me.txtDocumentoNorma.TabIndex = 9
        Me.txtDocumentoNorma.Text = ""
        '
        'optDoctoNorma
        '
        Me.optDoctoNorma.Location = New System.Drawing.Point(16, 88)
        Me.optDoctoNorma.Name = "optDoctoNorma"
        Me.optDoctoNorma.Size = New System.Drawing.Size(152, 24)
        Me.optDoctoNorma.TabIndex = 12
        Me.optDoctoNorma.Text = "Documento de la norma: "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(24, 8)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 16)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Normas:"
        '
        'cboNormas
        '
        Me.cboNormas.Location = New System.Drawing.Point(24, 24)
        Me.cboNormas.Name = "cboNormas"
        Me.cboNormas.Size = New System.Drawing.Size(360, 21)
        Me.cboNormas.TabIndex = 0
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox7)
        Me.TabPage5.Controls.Add(Me.tvComites)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(624, 358)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Sesiones"
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox7.Controls.Add(Me.Label21)
        Me.GroupBox7.Controls.Add(Me.cboSesiones)
        Me.GroupBox7.Controls.Add(Me.grdSesionesDoctos)
        Me.GroupBox7.Location = New System.Drawing.Point(168, 16)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(448, 240)
        Me.GroupBox7.TabIndex = 1
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Archivos de sesiones"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(16, 24)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(104, 16)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Tipo de documento:"
        '
        'cboSesiones
        '
        Me.cboSesiones.Location = New System.Drawing.Point(120, 24)
        Me.cboSesiones.Name = "cboSesiones"
        Me.cboSesiones.Size = New System.Drawing.Size(296, 21)
        Me.cboSesiones.TabIndex = 1
        '
        'grdSesionesDoctos
        '
        Me.grdSesionesDoctos.DataMember = ""
        Me.grdSesionesDoctos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdSesionesDoctos.Location = New System.Drawing.Point(8, 56)
        Me.grdSesionesDoctos.Name = "grdSesionesDoctos"
        Me.grdSesionesDoctos.ReadOnly = True
        Me.grdSesionesDoctos.Size = New System.Drawing.Size(432, 168)
        Me.grdSesionesDoctos.TabIndex = 0
        '
        'tvComites
        '
        Me.tvComites.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 8)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.Size = New System.Drawing.Size(144, 336)
        Me.tvComites.TabIndex = 0
        '
        'BtnBotonera
        '
        Me.BtnBotonera.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BtnBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton3})
        Me.BtnBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BtnBotonera.DropDownArrows = True
        Me.BtnBotonera.ImageList = Me.ImgListBotonera
        Me.BtnBotonera.Location = New System.Drawing.Point(0, 443)
        Me.BtnBotonera.Name = "BtnBotonera"
        Me.BtnBotonera.ShowToolTips = True
        Me.BtnBotonera.Size = New System.Drawing.Size(704, 63)
        Me.BtnBotonera.TabIndex = 5
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 9
        Me.ToolBarButton1.Text = "Ver"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 5
        Me.ToolBarButton2.Text = "Inac/Act"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 1
        Me.ToolBarButton4.Text = "Editar"
        Me.ToolBarButton4.Visible = False
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 2
        Me.ToolBarButton5.Text = "Guardar"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 4
        Me.ToolBarButton3.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'FrmGestionDoctos
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(704, 506)
        Me.Controls.Add(Me.BtnBotonera)
        Me.Controls.Add(Me.TabCDocots)
        Me.Name = "FrmGestionDoctos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Gestion de Documentos"
        Me.TabCDocots.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        CType(Me.grdDoctosDT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.grdSesionesDoctos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private ObjDoctos As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)
    Private objNormas As New clsCatalogoNormas.C_Normas(0, gUsuario, gPasswordSql)
    Private ObjNoticias As New ClsNoticias.P_Noticias(0, gUsuario, gPasswordSql)
    Private ObjComites As New clsComites.clsComites("PRINCIPAL", gUsuario, gPasswordSql)
    Private objComentarios As New clsComentarios.C_Comentarios("Principal", gUsuario, gPasswordSql)
    Private objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Private objDT As New ClsDt.P_DT(0, gUsuario, gPasswordSql)
    Public sPlan As String
    Public sTema As String
    Public optband As Boolean
    Public srefP As String
    Public objiniarray As New clsIniarray.ClsIniArray
    Public rutaOriginal As String
    Private valor As String

    Private sCT As String
    Private sSC As String
    Private sGT As String
    Private Fsesion As Date
    Private ID_sesion As Integer
    Public Matriz As Array
    Public svariable As String
    Public DocumentoReal As String
    Public ID_TipoDocTemas As Integer
    Public dvComite As DataView
    Public iEditar As String

    Sub Llena_Plan(ByVal tv As Object)
        Dim oTablaPNN As DataTable
        Dim oTablaDPy As DataTable
        'Dim oTablaSC As DataTable
        'Dim oTablaGT As DataTable
        Dim RegDPy As DataRow
        Dim RegPNN As DataRow
        Dim nodo As New TreeNode
        Dim nodo1 As New TreeNode
        Dim objTemasPlanes As New clsViewTree.cls(0, gUsuario, gPasswordSql)

        oTablaPNN = objTemasPlanes.ListaPNN("")
        tv.BeginUpdate()
        nodo = tv.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tv.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = objTemasPlanes.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.SelectedImageIndex = 5
                nodo1.ImageIndex = 5
            Next
        Next
        tv.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tv.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tv.Sorted = True
    End Sub

    Private Sub TVTemas_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVTemas.AfterSelect
        Dim Matriz As Array
        Dim svariable As String
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sTema = ""
                sPlan = ""
                ConsultaTemas()
            Case 2
                sPlan = Matriz(1)
                sTema = ""
                ConsultaTemas()
                Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
            Case 3
                sPlan = Matriz(1)
                sTema = Matriz(2)
                ConsultaTemas()
                Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
        End Select
    End Sub
    Private Sub ConsultaTemas()
        ConsultaDT()
        ConsultaProcAlter()
        ConsultaAnteProy()
        ConsultaProyecto()
    End Sub
    Private Sub ConsultaDT()
        Referenciar("Abandono")
        ObjDoctos.BuscarDoctos(sTema, sPlan, 3, srefP)

        If ObjDoctos.Encontrado = True Then
            txtTrabajoFinal.Text = ObjDoctos.Documento
        Else
            txtTrabajoFinal.Text = ""
        End If
        MustraStatus(lblStatus1, ObjDoctos.Status, ObjDoctos.Encontrado)
    End Sub
    Private Sub ConsultaProcAlter()
        Referenciar("Abandono")
        ObjDoctos.BuscarDoctos(sTema, sPlan, 12, srefP)

        If ObjDoctos.Encontrado = True Then
            txtMinuta.Text = ObjDoctos.Documento
        Else
            txtMinuta.Text = ""
        End If
        MustraStatus(lblStatus2, ObjDoctos.Status, ObjDoctos.Encontrado)

        If sTema <> "" Then
            Dim found As Boolean
            Dim estado As Integer
            Dim dtCom As DataTable
            objComentarios.Bandera = 5
            objComentarios.Id_Plan = sPlan
            objComentarios.Id_Tema = Integer.Parse(sTema)
            objComentarios.Id_Etapa = 2
            objComentarios.Llena_Campos_Matriz()
            If objComentarios.RefComite <> "" Then found = True
            If objComentarios.Status = 0 Then estado = 1 Else estado = 0

            txtMatrizAlt.Text = objComentarios.DocMatriz

            MustraStatus(Label1, estado, found)
        End If
    End Sub
    Private Sub ConsultaAnteProy()
        'documento 1
        Referenciar("Abandono")
        ObjDoctos.BuscarDoctos(sTema, sPlan, 4, srefP)

        If ObjDoctos.Encontrado = True Then
            TxtActa.Text = ObjDoctos.Documento
        Else
            TxtActa.Text = ""
        End If
        MustraStatus(lblStatus3, ObjDoctos.Status, ObjDoctos.Encontrado)

        'documento 2
        ObjDoctos.BuscarDoctos(sTema, sPlan, 15, srefP)

        If ObjDoctos.Encontrado = True Then
            txtAprobacion.Text = ObjDoctos.Documento
        Else
            txtAprobacion.Text = ""
        End If
        MustraStatus(lblStatus4, ObjDoctos.Status, ObjDoctos.Encontrado)

        'documento 3
        ObjDoctos.BuscarDoctos(sTema, sPlan, 7, srefP)

        If ObjDoctos.Encontrado = True Then
            txtAnteproy.Text = ObjDoctos.Documento
        Else
            txtAnteproy.Text = ""
        End If
        MustraStatus(lblStatus5, ObjDoctos.Status, ObjDoctos.Encontrado)
    End Sub
    Private Sub ConsultaProyecto()

        Referenciar("Abandono")
        'documento 2
        ObjDoctos.BuscarDoctos(sTema, sPlan, 8, srefP)
        If ObjDoctos.Encontrado = True Then
            txtProy.Text = ObjDoctos.Documento
        Else
            txtProy.Text = ""
        End If
        MustraStatus(lblStatus6, ObjDoctos.Status, ObjDoctos.Encontrado)

        'documento 2
        ObjDoctos.BuscarDoctos(sTema, sPlan, 6, srefP)
        If ObjDoctos.Encontrado = True Then
            txtActaPROYF.Text = ObjDoctos.Documento
        Else
            txtActaPROYF.Text = ""
        End If
        MustraStatus(lblStatus7, ObjDoctos.Status, ObjDoctos.Encontrado)

        If sTema <> "" Then
            Dim found As Boolean
            Dim estado As Integer
            Dim dtCom As DataTable
            objComentarios.Bandera = 5
            objComentarios.Id_Plan = sPlan
            objComentarios.Id_Tema = Integer.Parse(sTema)
            'objComentarios.sReferencia = srefP
            objComentarios.Id_Etapa = 4
            objComentarios.Llena_Campos_Matriz()
            txtMatrizProy.Text = objComentarios.DocMatriz

            If objComentarios.RefComite <> "" Then found = True
            If objComentarios.Status = 0 Then estado = 1 Else estado = 0

            MustraStatus(Label3, estado, found)
        End If
    End Sub
    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(sPlan, sTema)
        srefP = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
    End Sub
    Private Sub BtnBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles BtnBotonera.ButtonClick
        Select Case BtnBotonera.Buttons.IndexOf(e.Button)
            Case 0
                If rutaOriginal <> "" Then
                    Try
                        System.Diagnostics.Process.Start(rutaOriginal)
                    Catch ex As Exception
                        MsgBox("Archivo no encontrado en la ruta : " + rutaOriginal)
                    End Try
                    rutaOriginal = ""
                End If
            Case 1
                Select Case TabCDocots.SelectedIndex
                    Case 0
                        inactivar(19)
                    Case 1
                        inactivar(ID_TipoDocTemas)
                    Case 2 'ya esta bien
                        'Noticias()
                        'ObjNoticias.ListaCombo(cboNoticias)
                        Noticias()
                        cboNoticasllenar()
                    Case 3
                        Dim idDocto As Integer
                        If optAclaracion1.Checked Or optAclaracion2.Checked Or optDoctoNorma.Checked Then
                            If optAclaracion1.Checked Then idDocto = 10
                            If optAclaracion2.Checked Then idDocto = 11
                            If optDoctoNorma.Checked Then idDocto = 13
                            NormasDocIna(idDocto)
                            objNormas.Bandera = 1
                            objNormas.Inactivo = 0
                            objNormas.ListaCombo(cboNormas)
                            lblStatusNorma.Text = ""
                        End If
                    Case 4
                        inactivarSesiones()
                End Select


            Case 2
            Case 3
                guardar()
            Case 4
                Me.Dispose()
        End Select
    End Sub
    Private Sub inactivarSesiones()
        'busco el documento
        objsesiones.Id_Sesion = ID_sesion
        objsesiones.Docto = DocumentoReal
        objsesiones.Bandera = 16
        objsesiones.BuscaDocto()
        Dim inactivo As Integer
        If objsesiones.Inactivo = 0 Then
            inactivo = 10
        Else
            inactivo = 0
        End If

        'necesito id_sesion, documento
        objsesiones.Id_Sesion = ID_sesion
        objsesiones.Docto = DocumentoReal
        objsesiones.Bandera = 15
        objsesiones.Inactivo = inactivo
        objsesiones.ActivaInactiva()
        grdSesionesDoctos.DataSource = Nothing
        tvComites.CollapseAll()
    End Sub
    Private Sub NormasDocIna(ByVal id_tipo_doc As Integer)
        ObjDoctos.buscadocto(cboNormas.SelectedValue, id_tipo_doc, 12)
        Dim activo As Boolean
        If ObjDoctos.Activo = True Then
            activo = False
        Else
            activo = True
        End If
        ObjDoctos.StatusDocto(cboNormas.SelectedValue, 14, activo, id_tipo_doc)

    End Sub
    Private Sub Noticias()
        'busco la noticia 
        Dim inActivo As Boolean
        ObjNoticias.Id_Noticia = cboNoticias.SelectedValue
        ObjNoticias.Buscar()
        'si esta inactiva la activo
        With ObjNoticias
            If .Inactivo = True Then
                inActivo = False
            Else
                inActivo = True
            End If
            .Actualizar(3, .Id_Noticia, .Fecha, .Titulo, .Fuente, .Noticia, .Id_Categoria, .Documento, inActivo)
        End With
        'cerrar()
    End Sub

    Private Sub inactivar(ByVal Id_tipo_doc As Integer)
        If Id_tipo_doc = 100 Or Id_tipo_doc = 101 Then
            With objComentarios
                .Bandera = 5
                .Id_Plan = sPlan
                .Id_Tema = sTema

                If Id_tipo_doc = 100 Then .Id_Etapa = 2
                If Id_tipo_doc = 101 Then .Id_Etapa = 4

                .Llena_Campos_Matriz()

                If .Status = 0 Then .Status = 1 Else .Status = 0
                .Bandera = 4
                .BorrarComMatriz()
            End With
        ElseIf Id_tipo_doc > 0 Then
            ObjDoctos.Id_tipo_doc = Id_tipo_doc
            ObjDoctos.Documento = DocumentoReal

            ObjDoctos.buarcarDocumento()
            If ObjDoctos.Activo = False Then 'busco el status del documento y si es inactivo then 
                ObjDoctos.Status = 1
                ObjDoctos.Activo = True
            Else
                'si es activo then
                ObjDoctos.Status = 10
                ObjDoctos.Activo = False
            End If

            ObjDoctos.Id_tipo_doc = Id_tipo_doc
            ObjDoctos.Documento = DocumentoReal
            ObjDoctos.InactivarDocto()
        End If
        cerrar()
    End Sub
    Private Sub cerrar()
        Dim gestion As New FrmGestionDoctos
        gestion.MdiParent = Me.MdiParent
        gestion.Show()
        Me.Dispose()
    End Sub
    Private Sub guardar()
        Referenciar("abandono")
        Dim dt As New DataTable
        Dim dr As DataRow
        Dim bInactivo As Boolean
        Dim ruta As String
        Dim accion As Boolean
        dt = grdDoctosDT.DataSource()
        Try
            With objComentarios
                If dt.Rows.Count <> 0 Then
                    Dim archivo As String
                    Dim indice As Integer
                    Dim nombre As String
                    Dim comitepath As String
                    For Each dr In dt.Rows
                        '*****************************************Copia los Doctos a la carpeta
                        .Bandera = 4
                        .Id_tipo_doc = 5
                        .Documento = dr.Item(13)

                        .RefA�o = ObjPrograma.RefA�o
                        .RefComite = ObjPrograma.RefComite
                        .RefConsecutivo = ObjPrograma.RefConsecutivo
                        .RefRegreso = ObjPrograma.RefRegreso
                        .RefTraspaso = ObjPrograma.RefTraspaso
                        .Id_tipo_doc = 19
                        .Activo = True
                        .Status = 1
                        .Id_Plan = sPlan
                        .Id_Tema = sTema


                        ObjPrograma.Buscar(sPlan, sTema)
                        comitepath = ObjPrograma.ID_Comite
                        'If ObjPrograma.ID_CT <> "NA" Or ObjPrograma.ID_CT <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_CT
                        'If ObjPrograma.ID_SC <> "NA" Or ObjPrograma.ID_SC <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_SC
                        'If ObjPrograma.ID_Grupo <> "NA" Or ObjPrograma.ID_Grupo <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_Grupo
                        ObjPrograma.Buscar(sPlan, sTema)
                        If ObjPrograma.ID_Grupo <> "NA" Then
                            comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
                        End If
                        'SI ES SUBCOMITE
                        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
                            comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
                        End If
                        'SI ES COMITE TECNICO
                        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                            comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
                        End If
                        'SI ES DIRECTO DE COMITE
                        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                            comitepath = ObjPrograma.ID_Comite
                        End If

                        ruta = dr.Item(8)
                        'clsCopia.CopiaArchivos_Noticias(dr.Item(3), "c:\ance")
                        'clsCopia.CopiaArchivos(dr.Item(3), "\\ance-dc\Docs_ONN_WWW")
                        Dim rutaInicial As String
                        rutaInicial = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")))
                        If ruta <> dr.Item(13) Then
                            .Bandera = 9
                            .Actualizar()
                            REM If File.Exists(rutaInicial & "\" & comitepath & "\" + dr.Item(13)) Then
                            If File.Exists(rutaInicial & comitepath & "\" + dr.Item(13)) Then
                                If MsgBox("El archivo ya existe en el Servidor..." + Chr(13) + Chr(13) + " �Desea sobrescribir el archivo?", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                                    File.Delete(rutaInicial & comitepath & "\" + dr.Item(13))
                                    File.Copy(dr.Item(8), rutaInicial & comitepath & "\" + dr.Item(13))
                                End If
                            Else
                                If Not Directory.Exists(rutaInicial & comitepath & "\") Then
                                    Directory.CreateDirectory(rutaInicial & comitepath & "\")
                                End If
                                File.Copy(dr.Item(8), rutaInicial & comitepath & "\" + dr.Item(13))
                            End If
                        End If
                        '****************************************Guarda Doctos en la tabla
                    Next
                End If
            End With
        Catch ex As Exception
            MsgBox("No se encuentra la ruta, verifica que existan las carpetas pertinentes dentro de normanet :" & ex.Message)
        End Try

        Dim Gestion As New FrmGestionDoctos
        Gestion.MdiParent = Me.MdiParent
        Gestion.Show()
        Me.Dispose()

    End Sub
    Private Sub Limpiar(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Checked = False
        Next objeto
    End Sub
    Private Sub MustraStatus(ByVal Status As Object, ByVal activo As Integer, ByVal Encontrado As Boolean)
        'If opt.Checked = False Then
        'Imagen.ImageIndex = ""
        'Status.text = ""
        'Else
        If Encontrado = False Then
            Status.text = ""
        Else
            If activo = 1 Then
                Status.text = "Activo"
                Status.ForeColor = SystemColors.ControlText.RoyalBlue
                'Imagen.ImageIndex = 1
            Else
                Status.text = "Inactivo"
                Status.ForeColor = SystemColors.ControlText.Firebrick
                'Imagen.ImageIndex = 0
            End If
        End If
    End Sub

    Private Sub optTrabajoFinal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTrabajoFinal.CheckedChanged
        If optTrabajoFinal.Checked = True Then
            Limpiar(optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
            Direccion(txtTrabajoFinal.Text)
            ID_TipoDocTemas = 3
            'statusTemas(3, lblStatusTemas)
        End If
        'Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF)
    End Sub

    Private Sub optMatrizAlt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optMatrizAlt.CheckedChanged
        If optMatrizAlt.Checked = True Then
            Limpiar(optMinutaTerminacion, optTrabajoFinal, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizProy)
            PathDocMatriz(txtMatrizAlt.Text)
            ID_TipoDocTemas = 100
            'Direccion(txtMinuta.Text)
        End If
    End Sub

    Private Sub optMatrizProy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optMatrizProy.CheckedChanged
        If optMatrizProy.Checked = True Then
            Limpiar(optMinutaTerminacion, optTrabajoFinal, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt)
            PathDocMatriz(txtMatrizProy.Text)
            ID_TipoDocTemas = 101
            'Direccion(txtMinuta.Text)
        End If
    End Sub

    Private Sub optMinutaTerminacion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optMinutaTerminacion.CheckedChanged
        If optMinutaTerminacion.Checked = True Then
            Limpiar(optTrabajoFinal, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
            Direccion(txtMinuta.Text)
            ID_TipoDocTemas = 12
            'statusTemas(12, lblStatusTemas)
        End If
    End Sub

    Private Sub optActaAprobacion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optActaAprobacion.CheckedChanged
        If optActaAprobacion.Checked = True Then
            Limpiar(optTrabajoFinal, optMinutaTerminacion, optMinutaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
            Direccion(TxtActa.Text)
            ID_TipoDocTemas = 4
            'statusTemas(4, lblStatusTemas)
        End If
    End Sub

    Private Sub optMinutaAprobacion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optMinutaAprobacion.CheckedChanged
        If optMinutaAprobacion.Checked = True Then
            Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optAntF, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
            Direccion(txtAprobacion.Text)
            ID_TipoDocTemas = 15
            'statusTemas(15, lblStatusTemas)
        End If
    End Sub

    Private Sub optAntF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optAntF.CheckedChanged
        If optAntF.Checked = True Then
            Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optProyF, optApPROYF, optMatrizAlt, optMatrizProy)
            Direccion(txtAnteproy.Text)
            ID_TipoDocTemas = 7
            'statusTemas(7, lblStatusTemas)
        End If
    End Sub

    Private Sub optProyF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optProyF.CheckedChanged
        If optProyF.Checked = True Then
            Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optAntF, optApPROYF, optMatrizAlt, optMatrizProy)
            rutaOriginal = ""
            Direccion(txtProy.Text)
            ID_TipoDocTemas = 8
            'statusTemas(8, lblStatusTemas)
        End If
    End Sub

    Private Sub optApPROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optApPROYF.CheckedChanged
        If optApPROYF.Checked = True Then
            Limpiar(optTrabajoFinal, optMinutaTerminacion, optActaAprobacion, optMinutaAprobacion, optAntF, optProyF, optMatrizAlt, optMatrizProy)
            Direccion(txtActaPROYF.Text)
            ID_TipoDocTemas = 6
            'statusTemas(6, lblStatusTemas)
        End If
    End Sub
    Private Sub Direccion(ByVal Complemento As String)
        '****Para traer la ruta donde se insertan los documentos
        Dim RutaDoctoFinal As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutasDoctosFinales")))
        Dim ruta As String = "NA"

        ObjPrograma.Buscar(sPlan, sTema)
        If ObjPrograma.ID_Grupo <> "NA" Then
            ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
        End If
        'SI ES SUBCOMITE
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
            ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
        End If
        'SI ES COMITE TECNICO
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
        End If
        'SI ES DIRECTO DE COMITE
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            ruta = ObjPrograma.ID_Comite
        End If

        If sPlan = "" And sTema = "" Then
            ruta = RutaDoctoFinal
        End If

        If Complemento = "" Then
            rutaOriginal = ""
        Else
            rutaOriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + ruta + "\" + Complemento)
        End If
        DocumentoReal = Complemento
    End Sub

    Private Sub TabCDocots_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabCDocots.SelectedIndexChanged
        Select Case TabCDocots.SelectedIndex
            Case 0
                sTema = ""
                sPlan = ""
                cmdAgregar.Enabled = False
                LimpiaCampos(txtclasificacion, TxtTitulo, txtPertenece, txtF_Inicio, txtDocto)
                grdDoctosDT.DataSource = Nothing
            Case 1
                sTema = ""
                sPlan = ""
            Case 2
                sTema = ""
                sPlan = ""
                ObjNoticias.ListaCombo(cboNoticias)
            Case 3
                sTema = ""
                sPlan = ""
                Llena_catalogo()
            Case 4
                ObjDoctos.ListaCombo(cboSesiones)
                sTema = ""
                sPlan = ""

            Case 5
                sTema = ""
                sPlan = ""
        End Select
    End Sub

    Private Sub RutaNoticias(ByVal Complemento As String)
        rutaOriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")))
        rutaOriginal = rutaOriginal + ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Noticias")))
        rutaOriginal = rutaOriginal + Complemento
        If Complemento = "" Then
            rutaOriginal = ""
        End If
    End Sub
    Private Sub Llena_catalogo()
        objNormas.Bandera = 1
        objNormas.Inactivo = 0
        objNormas.ListaCombo(cboNormas)
    End Sub

    Private Sub cboNormas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboNormas.SelectedIndexChanged
        Limpiar(optAclaracion1, optAclaracion2, optDoctoNorma)
        Dim clsDoctosTemas As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)
        txtAclaracion1.Text = clsDoctosTemas.buscadocto(cboNormas.SelectedValue, 10, 12)
        txtAclaracion2.Text = clsDoctosTemas.buscadocto(cboNormas.SelectedValue, 11, 12)
        txtDocumentoNorma.Text = clsDoctosTemas.buscadocto(cboNormas.SelectedValue, 13, 12)
    End Sub
    Private Sub statusnNorma(ByVal Clasificacion As String, ByVal id_Docto As Integer, ByVal lbl As Object)
        ObjDoctos.buscadocto(Clasificacion, id_Docto, 12)
        Dim activo As Boolean
        If ObjDoctos.Activo = True Then
            lbl.Text = "Activo"
        Else
            lbl.Text = "Inactivo"
        End If
    End Sub

    Private Sub statusTemas(ByVal id_Docto As Integer, ByVal lbl As Object)
        ObjDoctos.Id_tipo_doc = id_Docto
        ObjDoctos.Documento = DocumentoReal
        ObjDoctos.buarcarDocumento()
        Dim activo As Boolean
        If ObjDoctos.Status = 1 Then
            lbl.Text = "Activo"
        Else
            lbl.Text = "Inactivo"
        End If
    End Sub

    Private Sub optAclaracion1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optAclaracion1.CheckedChanged
        antecedentes(cboNormas.SelectedValue)
        Direccion(txtAclaracion1.Text)
        statusnNorma(cboNormas.SelectedValue, 10, lblStatusNorma)
    End Sub

    Private Sub optAclaracion2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optAclaracion2.CheckedChanged
        antecedentes(cboNormas.SelectedValue)
        Direccion(txtAclaracion2.Text)
        statusnNorma(cboNormas.SelectedValue, 11, lblStatusNorma)
    End Sub

    Private Sub optDoctoNorma_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optDoctoNorma.CheckedChanged
        antecedentes(cboNormas.SelectedValue)
        Direccion(txtDocumentoNorma.Text)
        statusnNorma(cboNormas.SelectedValue, 13, lblStatusNorma)
    End Sub
    Private Sub antecedentes(ByVal clasificacion As String)
        objNormas.Bandera = 12
        objNormas.Clasificacion = clasificacion
        objNormas.BuscaCaracteristicas()
        sPlan = objNormas.Id_Plan
        sTema = objNormas.Id_Tema
    End Sub

    Private Sub FrmGestionDoctos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Llena_Plan(TVTemas)
        Llena_Plan(tvActualizacion)
        Llena_Sesiones(tvComites)
        'llena_ComiteTreeView()
    End Sub
    Private Sub Llena_Sesiones(ByVal tv As Object)
        Cursor.Current = Cursors.WaitCursor
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode
        Dim dvComite As DataView
        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tv.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tv.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tv.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tv.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO

                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        '********Sesiones Comite
                        If GTAnt <> SCAnt And GTAnt <> CTAnt And GTAnt <> ComiteAnt Then
                            oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"), "")
                            If oTablaSs.Rows.Count > 0 Then
                                For Each RegSes In oTablaSs.Rows
                                    Ses = GT.Nodes.Add(RegSes("numero"))
                                    Ses.ImageIndex = 5
                                    Ses.SelectedImageIndex = 5
                                Next
                            End If
                        End If
                    Next 'GT
                    oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), "NA", "")  '********Sesiones Comite
                    If SCAnt <> CTAnt And SCAnt <> ComiteAnt Then
                        If oTablaSs.Rows.Count > 0 Then
                            For Each RegSes In oTablaSs.Rows
                                Ses = SC.Nodes.Add(RegSes("numero"))
                                Ses.ImageIndex = 5
                                Ses.SelectedImageIndex = 5
                            Next
                        End If
                    End If
sinSC:
                Next 'SC
                oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), "NA", "NA", "") '********Sesiones Comite
                If CTAnt <> ComiteAnt Then
                    If oTablaSs.Rows.Count > 0 Then
                        For Each RegSes In oTablaSs.Rows
                            Ses = CT.Nodes.Add(RegSes("numero"))
                            Ses.ImageIndex = 5
                            Ses.SelectedImageIndex = 5
                        Next
                    End If
                End If
sinCT:
            Next 'CT

            oTablaSs = sesiones(RegComite("ID_Comite"), "NA", "NA", "NA", "") '********Sesiones Comite
            If oTablaSs.Rows.Count > 0 Then
                For Each RegSes In oTablaSs.Rows
                    Ses = Comite.Nodes.Add(RegSes("numero"))
                    Ses.ImageIndex = 5
                    Ses.SelectedImageIndex = 5
                Next
            End If
sinComite:
        Next 'Comites
        tv.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tv.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tv.ResetText()

        Cursor.Current = Cursors.Default
    End Sub

    Private Sub DGReStyle(ByVal grd As DataGrid)
        Dim dtcol As DataColumn = Nothing
        Try
            grd.TableStyles.Clear()
            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grd)

            ts1.MappingName = "P_Prog_Trab_Documentos"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Documento"
            TextCol.HeaderText = "Documento"
            TextCol.Width = 215
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Activo"
            TextCol1.HeaderText = "Activo"
            TextCol1.Width = 115
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            ts1.PreferredRowHeight = TextCol1.TextBox.Height ' para dar el alto a la fila
            grd.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

    Private Sub cboNoticias_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboNoticias.SelectedIndexChanged

        cboNoticasllenar()
    End Sub
    Private Sub cboNoticasllenar()
        ObjNoticias.Id_Noticia = cboNoticias.SelectedValue
        ObjNoticias.Buscar()
        txtDoctoNoticia.Text = ObjNoticias.Documento
        If ObjNoticias.Inactivo = True Then
            lblStatus.Text = "Inactivo"
        Else
            lblStatus.Text = "Activo"
        End If
        RutaNoticias(txtDoctoNoticia.Text)
    End Sub

    Private Sub tvActualizacion_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvActualizacion.AfterSelect
        Dim Matriz As Array
        Dim svariable As String
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")
        Select Case Matriz.Length
            Case 1
                sTema = ""
                sPlan = ""
            Case 2
                sPlan = Matriz(1)
                sTema = ""
                LimpiaCampos(txtclasificacion, TxtTitulo, txtPertenece, txtF_Inicio, txtDocto)
                cmdAgregar.Enabled = False
                grdDoctosDT.DataSource = Nothing
            Case 3
                sPlan = Matriz(1)
                sTema = Matriz(2)
                ObjPrograma.Buscar(sPlan, sTema)
                If ObjPrograma.ID_etapa <> 2 Then
                    MsgBox("El tema no se encuentra en la etapa de Documento de Trabajo")
                    'limpiar todo y desabilitar botones
                    LimpiaCampos(txtclasificacion, TxtTitulo, txtPertenece, txtF_Inicio, txtDocto)
                    cmdAgregar.Enabled = False
                    grdDoctosDT.DataSource = Nothing
                Else
                    Llena_GridDocto(grdDoctosDT)
                    llenaActualizacion()
                    DGReStyle()
                End If
        End Select
    End Sub
    Private Sub DGReStyle()
        Dim dtcol As DataColumn = Nothing
        Try
            grdDoctosDT.TableStyles.Clear()
            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdDoctosDT)

            ts1.MappingName = "C_Encontrado"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "id_Plan"
            TextCol.HeaderText = "id_Plan"
            TextCol.Width = 0
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "id_Tema"
            TextCol2.HeaderText = "id_Tema"
            TextCol2.Width = 0
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "id_tipo_doc"
            TextCol3.HeaderText = "id_tipo_doc"
            TextCol3.Width = 0
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "namedoc"
            TextCol4.HeaderText = "Documento"
            TextCol4.Width = 150
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "Activo"
            TextCol5.HeaderText = "Activo"
            TextCol5.Width = 100
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "ID_Cometario"
            TextCol6.HeaderText = "ID_Cometario"
            TextCol6.Width = 0
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            ts1.PreferredRowHeight = TextCol2.TextBox.Height ' para dar el alto a la fila
            grdDoctosDT.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub
    Private Sub llenaActualizacion()
        cmdAgregar.Enabled = True
        'ObjPrograma.Buscar(sPlan, sTema)
        Referenciar("abandono")
        objDT.Buscar(sTema, sPlan, srefP)
        'txtclasificacion.Text = ObjPrograma.Clasificacion
        'TxtTitulo.Text = ObjPrograma.Titulo
        txtclasificacion.Text = objDT.Clasificacion
        TxtTitulo.Text = objDT.Titulo
        Pertenece()
        txtF_Inicio.Text = ObjPrograma.F_Inicio
    End Sub
    Sub Llena_GridDocto(ByVal grd As Object)
        Referenciar("abandono")
        grd.DataSource = ObjDoctos.BuscarDoctos(sTema, sPlan, 19, srefP)
    End Sub
    Private Sub Pertenece()
        ObjPrograma.Buscar(sPlan, sTema)
        If ObjPrograma.ID_Grupo <> "NA" Then
            txtPertenece.Text = ObjPrograma.ID_Grupo
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Bandera = 4
            ObjComites.Busca_cuatro()
        End If
        'SI ES SUBCOMITE
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txtPertenece.Text = ObjPrograma.ID_SC
            ObjComites.Bandera = 3
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Busca_tres()
        End If
        'SI ES COMITE TECNICO
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txtPertenece.Text = ObjPrograma.ID_CT
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Bandera = 2
            ObjComites.Busca_dos()
        End If
        'SI ES DIRECTO DE COMITE
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txtPertenece.Text = ObjPrograma.ID_Comite
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Bandera = 1
            ObjComites.Busca_uno()
        End If
        'Busca Responsable de Ct Gt O comite por default
    End Sub
    Private Sub LimpiaCampos(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.text = ""
        Next objeto
    End Sub

    Private Sub cmdAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAgregar.Click
        Dim archivo As String
        Dim indice As Integer
        Dim dtAgrega As New DataTable
        Dim drAgrega As DataRow
        Dim dt As New DataTable
        Dim iIndice As Integer = 0
        Dim sext As String
        Dim sext2 As String
        Dim ruta As String
        Dim numTemp As Integer
        Dim tempDT As DataTable
        Try
            'OpenFileDialog1.Filter = "Archivos PDF (*.pdf)|Archivos Word (*.doc)|Archivos Excel (*.xls)|Archivos Power Point (*.ppt)"
            OpenFileDialog1.Filter = "Todos los archivos (*.*)|*.*"
            OpenFileDialog1.FilterIndex = 1
            OpenFileDialog1.FileName = ""
            OpenFileDialog1.ShowDialog()
            ruta = OpenFileDialog1.FileName
            'archivo = Split(ruta, "\")
            dtAgrega = grdDoctosDT.DataSource
            indice = dtAgrega.Rows.Count
            If OpenFileDialog1.FileName = "" Then Exit Sub
            'objComentarios.Bandera = 42
            'objComentarios.Id_Plan = sPlan
            'objComentarios.Id_Tema = sTema
            'dt = objComentarios.ListaGridDoctos
            'namearch = Split(archivo(Len(archivo) - 1), ".")

            For iIndice = Len(ruta) To 1 Step -1
                If Mid(ruta, iIndice, 1) = "\" Then
                    archivo = Mid(ruta, iIndice + 1)
                    iIndice = 1
                End If
            Next iIndice
            sext = Len(archivo)
            'txtDocto.Text = archivo
            Dim Part As String
            Dim partAnt As String

            'Esta parte tenia problemas con las extenciones ".docx"
            'Part = Mid(archivo, CInt(sext - 3), 4)
            Part = archivo.Substring(archivo.LastIndexOf("."))
            Dim pnn As New TextBox
            pnn.Text = sPlan
            Dim longCampo As Integer
            Dim Consecutivo As Integer
            Dim textTemp As String
            'consecutivo = 
            Dim temporal As String
            If txtDocto.Text <> "" Then
                sext2 = Len(txtDocto.Text)
                partAnt = Mid(txtDocto.Text, CInt(sext2 - 3), 4)
                temporal = Replace(Mid(txtDocto.Text, 13, sext2), partAnt, "")
                Consecutivo = CInt(temporal) + 1
                txtDocto.Text = "TEACDT" & sTema & "_" + Mid(sPlan, pnn.TextLength - 4) + Format(Consecutivo, "0000") + Part
            Else
                tempDT = grdDoctosDT.DataSource
                numTemp = tempDT.Rows.Count + 1
                txtDocto.Text = "TEACDT" & sTema & "_" + Mid(sPlan, pnn.TextLength - 4) + Format(numTemp, "0000") + Part
            End If

            If txtDocto.Text <> "" Then
                'Dim dvAgrega As DataView
                drAgrega = dtAgrega.NewRow
                drAgrega("id_plan") = sPlan
                drAgrega("id_tema") = sTema
                drAgrega("Id_tipo_doc") = 5
                drAgrega("Documento") = ruta
                drAgrega("namedoc") = txtDocto.Text
                drAgrega("Activo") = 1
                dtAgrega.Rows.Add(drAgrega)
                grdDoctosDT.DataSource = dtAgrega
                grdDoctosDT.Refresh()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub grdDoctosDT_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdDoctosDT.Click
        'clic saco el nombre del docto
        Dim nombreDocto As String
        Dim grdIndex As Integer
        If Not grdDoctosDT.DataSource Is Nothing Then
            grdIndex = grdDoctosDT.CurrentCell.RowNumber
            Try
                nombreDocto = grdDoctosDT.Item(grdIndex, 3)
            Catch ex As Exception
            End Try
            Direccion(nombreDocto)
        End If
    End Sub

    Private Function sesiones(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String) As DataTable
        Cursor.Current = Cursors.WaitCursor
        Dim combotable As DataTable
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columna As DataColumn
        Dim cm As CurrencyManager
        Dim Fecha As Date

        Try
            With objsesiones
                '.Bandera = 9
                .Bandera = 28
                .Id_Comite = comite
                .Id_CT = CT
                .Id_SC = SC
                .Id_Grupo = grupo
                combotable = .Listar()
            End With
            If CT.Trim <> "NA" Then
                comite = CT.Trim
            ElseIf SC.Trim <> "NA" Then
                comite = SC.Trim
            ElseIf grupo.Trim <> "NA" Then
                comite = grupo.Trim
            End If
            combotable.Columns.Add("Numero")
            iNumero = 0
            For Each regs In combotable.Rows
                Fecha = combotable.Rows.Item(iNumero).ItemArray(1)
                iNumero = iNumero + 1
                'combotable.Rows(iNumero - 1).Item("Numero") = iNumero.ToString + "/" + Format$(regs("Fecha"), "yy") + " " + comite.Trim
                combotable.Rows(iNumero - 1).Item("Numero") = Format$(Fecha, "dd-MM-yyyy") + " " + comite.Trim + " " + Format(regs("ID_Sesion"), "0000")
            Next

            If iNumero = 0 And iEditar <> Nothing Then
                MsgBox("No tiene asignada ninguna Sesion", MsgBoxStyle.Information)
            End If

            cm = CType(BindingContext(combotable), CurrencyManager)
            Dim dv As DataView = CType(cm.List, DataView)
            If compara.Length > 0 Then dv.RowFilter = "Numero = '" & compara & "'"
            Cursor.Current = Cursors.Default
            Return combotable

        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Function

    Public Sub DocumentoSesiones()
        objsesiones.Id_Sesion = ID_sesion
        objsesiones.Bandera = 14
        grdSesionesDoctos.DataSource = objsesiones.sesionDocumentos
        DGReStyleSesiones()
    End Sub
    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect

        Dim pasa As Boolean
        Dim fTemp As Date
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")
        Select Case Matriz.Length
            Case 1
                'nada
            Case 2
                sPlan = Matriz(1)
                sCT = "NA"
                sSC = "NA"
                sGT = "NA"
                grdSesionesDoctos.DataSource = Nothing
            Case 3 'CT
                grdSesionesDoctos.DataSource = Nothing
                sPlan = Matriz(1)
                Try
                    fTemp = CDate(Mid(Matriz(2), 1, 10))
                    pasa = False
                Catch ex As Exception
                    pasa = True
                End Try
                If pasa = False Then
                    'es sesion colgando de un plan
                    sCT = "NA"
                    sSC = "NA"
                    sGT = "NA"
                    Fsesion = fTemp
                    ID_sesion = Len(Matriz(2)) - 3
                    ID_sesion = Mid(Matriz(2), ID_sesion, 4)
                    DocumentoSesiones()
                Else
                    Fsesion = Nothing
                    If Matriz(2) Like "*GT*" Then
                        sCT = "NA"
                        sSC = "NA"
                        sGT = Matriz(2)
                    Else
                        sCT = Matriz(2)
                        sSC = "NA"
                        sGT = "NA"
                    End If
                End If
            Case 4 'SC
                grdSesionesDoctos.DataSource = Nothing
                sPlan = Matriz(1)
                sCT = Matriz(2)

                Try
                    fTemp = CDate(Mid(Matriz(3), 1, 10))
                    pasa = False
                Catch ex As Exception
                    pasa = True
                End Try
                If pasa = False Then
                    'sesion colgada de un CT
                    sSC = "NA"
                    sGT = "NA"
                    Fsesion = fTemp
                    ID_sesion = Len(Matriz(3)) - 3
                    ID_sesion = Mid(Matriz(3), ID_sesion, 4)
                    Try
                        DocumentoSesiones()
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                Else
                    Fsesion = Nothing
                    If Matriz(3) Like "*GT*" Then
                        sSC = "NA"
                        sGT = Matriz(3)
                    Else
                        sSC = Matriz(3)
                        sGT = "NA"
                    End If
                End If
            Case 5 'grupo trabajo
                grdSesionesDoctos.DataSource = Nothing
                sPlan = Matriz(1)
                sCT = Matriz(2)
                sSC = Matriz(3)
                Try
                    fTemp = CDate(Mid(Matriz(4), 1, 10))
                    pasa = False
                Catch ex As Exception
                    pasa = True
                End Try
                If pasa = False Then
                    Fsesion = fTemp
                    sGT = "NA"
                    ID_sesion = Len(Matriz(4)) - 3
                    ID_sesion = Mid(Matriz(4), ID_sesion, 4)
                    DocumentoSesiones()
                Else
                    sGT = Matriz(4)
                    Fsesion = Nothing
                End If
            Case 6
                grdSesionesDoctos.DataSource = Nothing
                sPlan = Matriz(1)
                sCT = Matriz(2)
                sSC = Matriz(3)
                sGT = Matriz(4)
                Fsesion = CDate(Mid(Matriz(5), 1, 10))
                ID_sesion = Len(Matriz(5)) - 3
                ID_sesion = Mid(Matriz(5), ID_sesion, 4)
                DocumentoSesiones()
        End Select
    End Sub
    Private Sub DGReStyleSesiones()
        Dim dtcol As DataColumn = Nothing
        Try
            grdSesionesDoctos.TableStyles.Clear()
            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdSesionesDoctos)

            ts1.MappingName = "DocumentosSesiones"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "id_sesion"
            TextCol.HeaderText = "id_sesion"
            TextCol.Width = 0
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "id_docto"
            TextCol2.HeaderText = "id_docto"
            TextCol2.Width = 0
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "docto"
            TextCol3.HeaderText = "docto"
            TextCol3.Width = 150
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "ID_Tipo"
            TextCol4.HeaderText = "ID_Tipo"
            TextCol4.Width = 0
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "Inactivo"
            TextCol5.HeaderText = "Inactivo"
            TextCol5.Width = 60
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "Descripcion"
            TextCol6.HeaderText = "Descripcion"
            TextCol6.Width = 100
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            ts1.PreferredRowHeight = TextCol2.TextBox.Height ' para dar el alto a la fila
            grdSesionesDoctos.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

    Private Sub grdSesionesDoctos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdSesionesDoctos.Click
        Dim docto As String
        Dim index As Integer
        If Not grdSesionesDoctos.DataSource Is Nothing Then
            index = grdSesionesDoctos.CurrentCell.RowNumber
            Try
                docto = grdSesionesDoctos.Item(index, 2)
            Catch ex As Exception
            End Try
            DireccionSesiones(docto)
        End If
    End Sub
    Private Sub DireccionSesiones(ByVal Complemento As String)
        Dim ruta As String
        Dim comitepath
        Dim fecha As String = "*" + Format$(Fsesion, "dd-MM-yyyy") + "*"
        Select Case Matriz.Length()
            Case 1
            Case 2
                If Matriz(1) <> "NA" Then
                    If Matriz(1) Like fecha Then
                    Else
                        comitepath = Matriz(1)
                    End If
                End If
            Case 3
                If Matriz(1) <> "NA" Then
                    If Matriz(1) Like fecha Then
                    Else
                        comitepath = Matriz(1)
                    End If
                End If

                If Matriz(2) <> "NA" Then
                    If Matriz(2) Like fecha Then
                    Else
                        comitepath = comitepath + "\" + Matriz(2)
                    End If
                End If
            Case 4
                If Matriz(1) <> "NA" Then
                    If Matriz(1) Like fecha Then
                    Else
                        comitepath = Matriz(1)
                    End If
                End If

                If Matriz(2) <> "NA" Then
                    If Matriz(2) Like fecha Then
                    Else
                        comitepath = comitepath + "\" + Matriz(2)
                    End If
                End If
                If Matriz(3) <> "NA" Then
                    If Matriz(3) Like fecha Then
                    Else
                        comitepath = comitepath + "\" + Matriz(3)
                    End If
                End If

            Case 5
                If Matriz(1) <> "NA" Then
                    If Matriz(1) Like fecha Then
                    Else
                        comitepath = Matriz(1)
                    End If
                End If

                If Matriz(2) <> "NA" Then
                    If Matriz(2) Like fecha Then
                    Else
                        comitepath = comitepath + "\" + Matriz(2)
                    End If
                End If
                If Matriz(3) <> "NA" Then
                    If Matriz(3) Like fecha Then
                    Else
                        comitepath = comitepath + "\" + Matriz(3)
                    End If
                End If

                If Matriz(4) <> "NA" Then
                    If Matriz(4) Like fecha Then
                    Else
                        comitepath = comitepath + "\" + Matriz(4)
                    End If
                End If
        End Select

        rutaOriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + comitepath + "\" + Complemento)
        DocumentoReal = Complemento
        If Complemento = "" Then
            rutaOriginal = ""
        End If
    End Sub

    Private Sub cboSesiones_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSesiones.SelectedIndexChanged
        Dim dt As DataTable
        Dim rows As DataRow()
        Dim dtNew As DataTable
        Dim dtRespaldo As DataTable
        If Not grdSesionesDoctos.DataSource Is Nothing Then
            dt = grdSesionesDoctos.DataSource
            ' copy table structure  
            dtNew = dt.Clone()
            ' sort and filter data  
            rows = dt.Select("ID_Tipo = '" & cboSesiones.SelectedValue & "'")
            ' fill dtNew with selected rows
            For Each dr As DataRow In rows
                dtNew.ImportRow(dr)
            Next
            grdSesionesDoctos.DataSource = Nothing
            grdSesionesDoctos.DataSource = dtNew
        End If
    End Sub


    Private Sub PathDocMatriz(ByVal txt As String)
        Dim ruta As String

        'sPlan = array_texto(1)
        'sTema = array_texto(2)

        Referenciar("abandono")

        If ObjPrograma.ID_Grupo <> "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite

        Dim server = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")
        Dim carpeta = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Comentarios")
        Dim rutaCarpetas = server + carpeta + "\" + ruta + "\"
        Dim sPath = rutaCarpetas + txt

        rutaOriginal = sPath
        DocumentoReal = txt
    End Sub


End Class
