Public Class FrmNombramientos
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEliminar As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtFolio As System.Windows.Forms.TextBox
    Friend WithEvents grdNombramientos As System.Windows.Forms.DataGrid
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtRutaNombramiento As System.Windows.Forms.TextBox
    Friend WithEvents dtpIngreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents cboRemitentes As System.Windows.Forms.ComboBox
    Friend WithEvents btnAdjuntar As System.Windows.Forms.Button
    Friend WithEvents dtpMaxima As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpVencimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkRequiereRespuesta As System.Windows.Forms.CheckBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtIdNombramiento As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmNombramientos))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtIdNombramiento = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnAdjuntar = New System.Windows.Forms.Button
        Me.cboRemitentes = New System.Windows.Forms.ComboBox
        Me.dtpIngreso = New System.Windows.Forms.DateTimePicker
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtRutaNombramiento = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtFolio = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.grdNombramientos = New System.Windows.Forms.DataGrid
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.cmdEliminar = New System.Windows.Forms.ToolBarButton
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.chkRequiereRespuesta = New System.Windows.Forms.CheckBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.dtpVencimiento = New System.Windows.Forms.DateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.dtpMaxima = New System.Windows.Forms.DateTimePicker
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdNombramientos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.txtIdNombramiento)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.btnAdjuntar)
        Me.GroupBox1.Controls.Add(Me.cboRemitentes)
        Me.GroupBox1.Controls.Add(Me.dtpIngreso)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtRutaNombramiento)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtFolio)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(704, 96)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'txtIdNombramiento
        '
        Me.txtIdNombramiento.Location = New System.Drawing.Point(472, 64)
        Me.txtIdNombramiento.Name = "txtIdNombramiento"
        Me.txtIdNombramiento.TabIndex = 27
        Me.txtIdNombramiento.Text = ""
        Me.txtIdNombramiento.Visible = False
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(472, 32)
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "IdNombramiento"
        Me.Label6.Visible = False
        '
        'btnAdjuntar
        '
        Me.btnAdjuntar.Location = New System.Drawing.Point(392, 64)
        Me.btnAdjuntar.Name = "btnAdjuntar"
        Me.btnAdjuntar.Size = New System.Drawing.Size(56, 23)
        Me.btnAdjuntar.TabIndex = 25
        Me.btnAdjuntar.Text = "...."
        '
        'cboRemitentes
        '
        Me.cboRemitentes.Location = New System.Drawing.Point(104, 40)
        Me.cboRemitentes.Name = "cboRemitentes"
        Me.cboRemitentes.Size = New System.Drawing.Size(344, 21)
        Me.cboRemitentes.TabIndex = 24
        '
        'dtpIngreso
        '
        Me.dtpIngreso.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpIngreso.Location = New System.Drawing.Point(320, 16)
        Me.dtpIngreso.Name = "dtpIngreso"
        Me.dtpIngreso.Size = New System.Drawing.Size(128, 20)
        Me.dtpIngreso.TabIndex = 23
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(272, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 16)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Ingreso:"
        '
        'txtRutaNombramiento
        '
        Me.txtRutaNombramiento.Location = New System.Drawing.Point(104, 64)
        Me.txtRutaNombramiento.Name = "txtRutaNombramiento"
        Me.txtRutaNombramiento.Size = New System.Drawing.Size(280, 20)
        Me.txtRutaNombramiento.TabIndex = 7
        Me.txtRutaNombramiento.Text = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 16)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Nombramiento:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Remitente:"
        '
        'txtFolio
        '
        Me.txtFolio.Location = New System.Drawing.Point(104, 16)
        Me.txtFolio.Name = "txtFolio"
        Me.txtFolio.Size = New System.Drawing.Size(144, 20)
        Me.txtFolio.TabIndex = 1
        Me.txtFolio.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Folio:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.grdNombramientos)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 168)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(704, 184)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'grdNombramientos
        '
        Me.grdNombramientos.AllowNavigation = False
        Me.grdNombramientos.AlternatingBackColor = System.Drawing.Color.Silver
        Me.grdNombramientos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdNombramientos.BackColor = System.Drawing.Color.White
        Me.grdNombramientos.CaptionBackColor = System.Drawing.Color.YellowGreen
        Me.grdNombramientos.CaptionFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdNombramientos.CaptionForeColor = System.Drawing.Color.White
        Me.grdNombramientos.CaptionText = "Remitentes"
        Me.grdNombramientos.DataMember = ""
        Me.grdNombramientos.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdNombramientos.ForeColor = System.Drawing.Color.Black
        Me.grdNombramientos.GridLineColor = System.Drawing.Color.Silver
        Me.grdNombramientos.HeaderBackColor = System.Drawing.Color.Silver
        Me.grdNombramientos.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdNombramientos.HeaderForeColor = System.Drawing.Color.Black
        Me.grdNombramientos.LinkColor = System.Drawing.Color.Maroon
        Me.grdNombramientos.Location = New System.Drawing.Point(8, 16)
        Me.grdNombramientos.Name = "grdNombramientos"
        Me.grdNombramientos.ParentRowsBackColor = System.Drawing.Color.Silver
        Me.grdNombramientos.ParentRowsForeColor = System.Drawing.Color.Black
        Me.grdNombramientos.ReadOnly = True
        Me.grdNombramientos.SelectionBackColor = System.Drawing.Color.Maroon
        Me.grdNombramientos.SelectionForeColor = System.Drawing.Color.White
        Me.grdNombramientos.Size = New System.Drawing.Size(688, 160)
        Me.grdNombramientos.TabIndex = 37
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.cmdEliminar})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 363)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(720, 62)
        Me.tlbBotonera.TabIndex = 37
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'cmdEliminar
        '
        Me.cmdEliminar.ImageIndex = 11
        Me.cmdEliminar.Text = "Eliminar"
        Me.cmdEliminar.ToolTipText = "Eliminar Participante"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.chkRequiereRespuesta)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.dtpVencimiento)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.dtpMaxima)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 112)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(704, 56)
        Me.GroupBox3.TabIndex = 38
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Fecha de respuesta"
        '
        'chkRequiereRespuesta
        '
        Me.chkRequiereRespuesta.Checked = True
        Me.chkRequiereRespuesta.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkRequiereRespuesta.Enabled = False
        Me.chkRequiereRespuesta.Location = New System.Drawing.Point(16, 24)
        Me.chkRequiereRespuesta.Name = "chkRequiereRespuesta"
        Me.chkRequiereRespuesta.Size = New System.Drawing.Size(128, 24)
        Me.chkRequiereRespuesta.TabIndex = 30
        Me.chkRequiereRespuesta.Text = "Requiere respuesta"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(352, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 16)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Vencimiento:"
        '
        'dtpVencimiento
        '
        Me.dtpVencimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpVencimiento.Location = New System.Drawing.Point(424, 24)
        Me.dtpVencimiento.Name = "dtpVencimiento"
        Me.dtpVencimiento.Size = New System.Drawing.Size(128, 20)
        Me.dtpVencimiento.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(160, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 16)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Maxima:"
        '
        'dtpMaxima
        '
        Me.dtpMaxima.Enabled = False
        Me.dtpMaxima.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpMaxima.Location = New System.Drawing.Point(208, 24)
        Me.dtpMaxima.Name = "dtpMaxima"
        Me.dtpMaxima.Size = New System.Drawing.Size(128, 20)
        Me.dtpMaxima.TabIndex = 27
        '
        'FrmNombramientos
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(720, 425)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FrmNombramientos"
        Me.Text = "..:: Nombramientos ::.."
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdNombramientos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Inicializacion de variables"
    Dim Tabla As String = "Encontrados"
    Dim dgEstiloColumna As New DataGridTableStyle
    Dim ColEStilo0 As New DataGridTextBoxColumn
    Dim ColEStilo1 As New DataGridTextBoxColumn
    Dim ColEStilo2 As New DataGridTextBoxColumn
    Dim ColEStilo3 As New DataGridTextBoxColumn
    Dim ColEStilo4 As New DataGridTextBoxColumn
    Dim ColEStilo5 As New DataGridTextBoxColumn
    Dim ColEStilo6 As New DataGridBoolColumn
    Dim ColEStilo7 As New DataGridButtonColumn(6)
    Dim ColEStilo8 As New DataGridTextBoxColumn

#End Region

    Private _IdAccion As eAccionGuardado

    Private Property IdAccion() As eAccionGuardado
        Get
            Return _IdAccion
        End Get
        Set(ByVal Value As eAccionGuardado)
            _IdAccion = Value
        End Set
    End Property

    Private Enum eBtnRemitentes As Integer
        Agregar = 0
        Editar = 1
        Deshacer = 2
        Salvar = 3
        Eliminar = 4
    End Enum

    Private Enum eAccionGuardado As Integer
        Ninguna = 0
        Nuevo = 1
        Edicion = 2
    End Enum

    Private Sub FrmRemitentes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        BotonesInicio()
        FillRemitentes(cboRemitentes)
        CargarDatos()
        FormaGrid(grdNombramientos)

    End Sub

    Private Sub BotonesInicio()
        IdAccion = eAccionGuardado.Ninguna
        inactivar(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
        Activar(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
        Limpiar(txtFolio, txtRutaNombramiento, txtIdNombramiento)
        inactivar(txtFolio, txtRutaNombramiento, dtpIngreso, cboRemitentes, btnAdjuntar, dtpVencimiento, chkRequiereRespuesta)
        Activar(grdNombramientos)
    End Sub

    Private Sub BotonesNuevo()
        IdAccion = eAccionGuardado.Nuevo
        Activar(txtFolio, dtpIngreso, cboRemitentes, btnAdjuntar)
        inactivar(dtpVencimiento)
        Limpiar(txtFolio, txtRutaNombramiento, txtIdNombramiento)

        Activar(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
        inactivar(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
        inactivar(grdNombramientos)
    End Sub

    Private Sub BotonesEdicion()
        IdAccion = eAccionGuardado.Edicion
        Activar(dtpIngreso, cboRemitentes, btnAdjuntar, dtpVencimiento)

        Activar(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
        inactivar(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
        inactivar(grdNombramientos)
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case eBtnRemitentes.Agregar
                BotonesNuevo()
                dtpMaxima.Value = CalcularFechaMaxima()
            Case eBtnRemitentes.Editar
                If txtIdNombramiento.Text <> "" Then
                    BotonesEdicion()
                Else
                    MsgBox("Es necesario seleccionar un registro", MsgBoxStyle.Critical)
                End If
            Case eBtnRemitentes.Deshacer
                BotonesInicio()
            Case eBtnRemitentes.Salvar
                If ValidarDatos() = False Then
                    Select Case IdAccion
                        Case eAccionGuardado.Nuevo
                            GuardarNuevo()
                        Case eAccionGuardado.Edicion
                            GuardarEdicion()
                    End Select
                End If
            Case eBtnRemitentes.Eliminar
                If txtIdNombramiento.Text <> "" Then
                    If MsgBox("�Estas seguro de eliminar el registro?", MsgBoxStyle.Information Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        Eliminar(txtIdNombramiento.Text)
                    End If
                Else
                    MsgBox("Es necesario seleccionar un registro", MsgBoxStyle.Critical)
                End If
        End Select
    End Sub

    Private Sub CargarDatos()
        Dim dt As DataTable
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "s2"
        dt = objNombramientos.Listar
        grdNombramientos.DataSource = dt
    End Sub


    Sub FormaGrid(ByVal grd As DataGrid)
        With grd
            .CaptionText = "NOMBRAMIENTOS"
            .CaptionBackColor = Color.RoyalBlue
            .CaptionFont = New Font("Tahoma", 10.0!, FontStyle.Bold)
            .BorderStyle = BorderStyle.None
            .Font = New Font("Tahoma", 8.0!)
            .AllowSorting = False
        End With
        Call Tabla_Color(dgEstiloColumna, grd)

        With dgEstiloColumna
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .MappingName = Tabla
            .PreferredColumnWidth = 125
            .PreferredRowHeight = 15
            .AllowSorting = False
        End With

        With ColEStilo8
            .HeaderText = "IdNombramiento"
            .MappingName = "IdNombramiento"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEStilo0
            .HeaderText = "Folio"
            .MappingName = "Folio"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo1
            .HeaderText = "Ingreso"
            .MappingName = "FechaIngreso"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo2
            .HeaderText = "Remitente"
            .MappingName = "Remitente"
            .Width = 120
            .ReadOnly = True
        End With

        With ColEStilo3
            .HeaderText = "Maxima"
            .MappingName = "FechaRespuestaMaxima"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo4
            .HeaderText = "Real"
            .MappingName = "FechaRespuestaReal"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo5
            .HeaderText = "Vencimiento"
            .MappingName = "FechaRespuestaVencimiento"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo6
            .HeaderText = "Requiere Resp."
            .MappingName = "RequiereRespuesta"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo7
            .HeaderText = "Nombramiento"
            .MappingName = "Nombramiento"
            .Width = 80
            .ReadOnly = False
        End With


        dgEstiloColumna.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEStilo8, ColEStilo0, ColEStilo1, ColEStilo2, ColEStilo3, ColEStilo4, ColEStilo5, ColEStilo6, ColEStilo7})
        grd.TableStyles.Add(dgEstiloColumna)

    End Sub

    Private Sub GuardarNuevo()
        Dim bExiste As Boolean = False


        bExiste = ValidarExistencia(txtFolio.Text)
        If bExiste = True Then
            MsgBox("El Folio que intenta registrar ya existe. intentalo con uno distinto", MsgBoxStyle.Critical)
        Else
            Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
            objNombramientos.Bandera = "i2"
            objNombramientos.Folio = txtFolio.Text
            objNombramientos.FechaIngreso = dtpIngreso.Value

            objNombramientos.Nombramiento = AdjuntarNombramiento(txtRutaNombramiento.Text)
            objNombramientos.FechaRespuestaMaxima = dtpMaxima.Value
            objNombramientos.FechaRespuestaVencimiento = Nothing
            objNombramientos.RequiereRespuesta = chkRequiereRespuesta.Checked
            objNombramientos.FechaRespuestaReal = Nothing
            objNombramientos.Activo = True
            objNombramientos.IdRemitente = cboRemitentes.SelectedValue
            objNombramientos.InsertarInicio()

            CargarDatos()
            BotonesInicio()

            If objNombramientos.respRetorno(1) = 1 Then
                MsgBox(objNombramientos.respRetorno(0), MsgBoxStyle.Critical)
            Else
                MsgBox("Registro Ingresado correctamente", MsgBoxStyle.Information)
            End If


        End If
    End Sub

    Private Sub GuardarEdicion()
        Dim bExiste As Boolean = False
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos

        objNombramientos.Bandera = "s1"
        objNombramientos.IdNombramiento = txtIdNombramiento.Text
        objNombramientos.LlenarDatos()
        REM -------------------

        objNombramientos.Bandera = "u5"
        objNombramientos.Folio = txtFolio.Text
        objNombramientos.FechaIngreso = dtpIngreso.Value
        objNombramientos.IdRemitente = cboRemitentes.SelectedValue
        objNombramientos.FechaRespuestaMaxima = dtpMaxima.Value

        If txtRutaNombramiento.Text <> "" Then
            objNombramientos.Nombramiento = AdjuntarNombramiento(txtRutaNombramiento.Text)
        End If

        If Not objNombramientos.FechaRespuestaVencimiento Is Nothing Then
            objNombramientos.FechaRespuestaVencimiento = dtpVencimiento.Value
        End If
        objNombramientos.Actualizar()

        If objNombramientos.respRetorno(1) = 1 Then
            MsgBox(objNombramientos.respRetorno(0), MsgBoxStyle.Critical)
        Else
            CargarDatos()
            BotonesInicio()
            MsgBox("Registro Actualizado correctamente", MsgBoxStyle.Information)
        End If

  
    End Sub

    Private Function ValidarExistencia(ByVal Folio As String) As Boolean
        Dim bExiste As Boolean = False
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "s3"
        objNombramientos.Folio = Trim(Folio)

        If objNombramientos.Listar().Rows.Count > 0 Then
            bExiste = True
        Else
            bExiste = False
        End If

        Return bExiste
    End Function

    Private Function ValidarDatos() As Boolean
        Dim bError As Boolean = False
        Dim msg As String = ""

        If Trim(txtFolio.Text) = "" Then msg += "--Folio" & vbCrLf
        If Trim(cboRemitentes.Text) = "" Then msg += "--Remitente" & vbCrLf

        If IdAccion <> eAccionGuardado.Edicion Then
            If Trim(txtRutaNombramiento.Text) = "" Then msg += "--Nombramiento" & vbCrLf
        End If

        If msg <> "" Then
            bError = True
            msg = "El o los siguientes campos son obligatorios:" & vbCrLf & msg
            MsgBox(msg, MsgBoxStyle.Critical)
        End If
        Return bError
    End Function

    Private Sub grdNombramientos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdNombramientos.Click
        Dim index As Integer
        Dim IdNombramiento As Integer
        Dim dgc As DataGridCell
        dgc.ColumnNumber = 0

        If grdNombramientos.CurrentRowIndex < 0 Then
        Else

            If grdNombramientos.CurrentCell.ColumnNumber = 8 Then
                IdNombramiento = grdNombramientos.Item(grdNombramientos.CurrentCell.RowNumber, 0)
                AbrirArchivo(IdNombramiento)
                grdNombramientos.CurrentCell = dgc
            Else
                If Not grdNombramientos.DataSource Is Nothing Then
                    bandgrd = True
                    index = grdNombramientos.CurrentRowIndex
                    IdNombramiento = grdNombramientos.Item(index, 0)

                    LlenarCampos(IdNombramiento)
                End If
            End If
        End If
    End Sub

    Private Sub LlenarCampos(ByVal IdNombramiento)
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "s1"
        objNombramientos.IdNombramiento = IdNombramiento
        objNombramientos.LlenarDatos()

        txtIdNombramiento.Text = objNombramientos.IdNombramiento
        txtFolio.Text = objNombramientos.Folio
        dtpIngreso.Value = objNombramientos.FechaIngreso
        cboRemitentes.SelectedValue = objNombramientos.IdRemitente
        txtRutaNombramiento.Text = ""
        chkRequiereRespuesta.Checked = objNombramientos.RequiereRespuesta
        dtpMaxima.Value = objNombramientos.FechaRespuestaMaxima
        If objNombramientos.FechaRespuestaVencimiento <> "" Then
            dtpVencimiento.Value = objNombramientos.FechaRespuestaVencimiento
        End If

    End Sub

    Private Sub Eliminar(ByVal IdNombramiento As Integer)
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "u4"
        objNombramientos.IdNombramiento = IdNombramiento
        objNombramientos.Activo = False
        objNombramientos.FechaIngreso = Now
        objNombramientos.FechaRespuestaMaxima = Now
        objNombramientos.Actualizar()

        If objNombramientos.respRetorno(1) = 1 Then
            MsgBox(objNombramientos.respRetorno(0), MsgBoxStyle.Information)
        Else
            CargarDatos()
            BotonesInicio()
            MsgBox("Registro Eliminado correctamente", MsgBoxStyle.Information)
        End If

    End Sub

    Private Function CalcularFechaMaxima(Optional ByVal NoDias As Integer = 3, Optional ByRef Maxima As Object = Nothing) As Date

        Maxima = DateAdd(DateInterval.Day, NoDias, dtpIngreso.Value)
        If Weekday(Maxima) = 7 Then CalcularFechaMaxima(NoDias + 2, Maxima) REM Sabado
        If Weekday(Maxima) = 1 Then CalcularFechaMaxima(NoDias + 1, Maxima) REM Domingo

        Return Maxima
    End Function

    Private Sub dtpIngreso_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpIngreso.ValueChanged
        dtpMaxima.Value = CalcularFechaMaxima()
    End Sub

    Private Sub FillRemitentes(ByVal cbo As ComboBox)
        Dim dt As DataTable
        Dim clsRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
        clsRemitentes.Bandera = "s4"
        dt = clsRemitentes.Listar

        cbo.DisplayMember = "Nombre"
        cbo.ValueMember = "IdRemitente"
        cbo.DataSource = dt
    End Sub

    Private Sub btnAdjuntar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdjuntar.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            txtRutaNombramiento.Text = openFileDialog1.FileName
        End If

    End Sub

    Private Function AdjuntarNombramiento(ByVal RutaNombramiento) As String
        Dim NombreArchivo As String = Guid.NewGuid.ToString
        Dim NombreArchivoFinal As String
        Try

            Dim info As New System.IO.FileInfo(RutaNombramiento)
            Dim objiniarray As New clsIniarray.ClsIniArray
            Dim RutaNombramientos As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutaNombramientos")))
            Dim RutaFinal As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + RutaNombramientos)
            NombreArchivoFinal = NombreArchivo & info.Extension
            If Not System.IO.Directory.Exists(RutaFinal) Then System.IO.Directory.CreateDirectory(RutaFinal)
            System.IO.File.Copy(RutaNombramiento, RutaFinal & NombreArchivoFinal)

            CopiaTemporal(NombreArchivoFinal)

        Catch ex As Exception
            NombreArchivoFinal = ""
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
        Return NombreArchivoFinal
    End Function

    Private Sub CopiaTemporal(ByVal sArchivo As String)
        Try
            Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
            Dim RutaTemporal As String = objNombramientos.RutaDocumentos()

            Dim Nombramiento As String = ""
            Dim objiniarray As New clsIniarray.ClsIniArray
            Dim RutaNombramientos As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutaNombramientos")))
            Dim RutaFinal As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + RutaNombramientos)
            If System.IO.Directory.Exists(RutaFinal) Then System.IO.Directory.CreateDirectory(RutaFinal)
            System.IO.File.Copy(RutaFinal & sArchivo, RutaTemporal & sArchivo, True)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub AbrirArchivo(ByVal IdNombramiento)
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        Dim Nombramiento As String = ""
        Dim objiniarray As New clsIniarray.ClsIniArray
        Dim RutaNombramientos As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutaNombramientos")))
        Dim RutaFinal As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + RutaNombramientos)

        objNombramientos.Bandera = "s1"
        objNombramientos.IdNombramiento = IdNombramiento
        objNombramientos.LlenarDatos()

        If System.IO.File.Exists(RutaFinal & objNombramientos.Nombramiento) Then
            System.Diagnostics.Process.Start(RutaFinal & objNombramientos.Nombramiento, True)
        Else
            MsgBox("Archivo no encontrado", MsgBoxStyle.Critical)
        End If
    End Sub

End Class
