Imports System.Data.SqlClient
Imports System.IO
Public Class frmP_Comite
    Inherits System.Windows.Forms.Form
    Private oVista As DataView
    Dim dvComite As DataView
    Dim dvCT As DataView
    Dim dvC As DataView
    Dim dvGT As DataView
    Dim iCaso As Integer
    Dim sTipoProceso As String
    Dim status As String

    Dim cn As New SqlConnection
    'Dim objConexion As New clsConexionArchivo.clsConexionArchivo
    Dim objConexion As New clsConexion.cIsConexion

    'Dim objComites As New clsComites.clsComites 'fmr
    Dim objComites As New clsComites.clsComites("Principal", gUsuario, gPasswordSql)

    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim sRutaComite As String
    Dim bandError As Boolean




#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()
        objempleados.Inicializa(Application.StartupPath & "\Principal.ini", "COMUN", gUsuario, gPasswordSql)
        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()
        '''objConexion1.Conexion(0, "admsis", "amynsys")
        ''''con.Conexion("PRINCIPAL", "admsis", "admynys")
        ''''cn.ConnectionString = ("Data source='" + objConexion1.SserverC + "';initial catalog='" + objConexion1.SBaseD + "'; user id = admsis; pwd=admynsys")
        '''cn.ConnectionString = ("Data source='" + objConexion1.SserverC + "';initial catalog='" + objConexion1.SBaseD + "'; user id = admsis; pwd=admynsys")
        ''''Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents lblObjetivo As System.Windows.Forms.Label
    Friend WithEvents lblDescripcion As System.Windows.Forms.Label
    Friend WithEvents SB As System.Windows.Forms.StatusBar
    Friend WithEvents SB2 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents SB1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents txtGT As System.Windows.Forms.TextBox
    Friend WithEvents txtSC As System.Windows.Forms.TextBox
    Friend WithEvents txtCT As System.Windows.Forms.TextBox
    Friend WithEvents txtComite As System.Windows.Forms.TextBox
    Friend WithEvents lblGT As System.Windows.Forms.Label
    Friend WithEvents lblSC As System.Windows.Forms.Label
    Friend WithEvents lblCT As System.Windows.Forms.Label
    Friend WithEvents lblComite As System.Windows.Forms.Label
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents txtDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents txtSGT As System.Windows.Forms.TextBox
    Friend WithEvents lblSGT As System.Windows.Forms.Label
    Friend WithEvents txtObjetivo As System.Windows.Forms.TextBox
    Friend WithEvents lblResponsable As System.Windows.Forms.Label
    Friend WithEvents txtResponsable As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents lblactivo As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmP_Comite))
        Me.lblObjetivo = New System.Windows.Forms.Label
        Me.lblDescripcion = New System.Windows.Forms.Label
        Me.txtDescripcion = New System.Windows.Forms.TextBox
        Me.txtSGT = New System.Windows.Forms.TextBox
        Me.SB = New System.Windows.Forms.StatusBar
        Me.SB2 = New System.Windows.Forms.StatusBarPanel
        Me.SB1 = New System.Windows.Forms.StatusBarPanel
        Me.txtGT = New System.Windows.Forms.TextBox
        Me.txtSC = New System.Windows.Forms.TextBox
        Me.txtCT = New System.Windows.Forms.TextBox
        Me.txtComite = New System.Windows.Forms.TextBox
        Me.lblGT = New System.Windows.Forms.Label
        Me.lblSC = New System.Windows.Forms.Label
        Me.lblCT = New System.Windows.Forms.Label
        Me.lblComite = New System.Windows.Forms.Label
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.lblSGT = New System.Windows.Forms.Label
        Me.txtObjetivo = New System.Windows.Forms.TextBox
        Me.lblResponsable = New System.Windows.Forms.Label
        Me.txtResponsable = New System.Windows.Forms.TextBox
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.lblactivo = New System.Windows.Forms.Label
        CType(Me.SB2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SB1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblObjetivo
        '
        Me.lblObjetivo.AutoSize = True
        Me.lblObjetivo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblObjetivo.Location = New System.Drawing.Point(240, 292)
        Me.lblObjetivo.Name = "lblObjetivo"
        Me.lblObjetivo.Size = New System.Drawing.Size(56, 16)
        Me.lblObjetivo.TabIndex = 44
        Me.lblObjetivo.Text = "Objetivo: "
        '
        'lblDescripcion
        '
        Me.lblDescripcion.AutoSize = True
        Me.lblDescripcion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescripcion.Location = New System.Drawing.Point(240, 248)
        Me.lblDescripcion.Name = "lblDescripcion"
        Me.lblDescripcion.Size = New System.Drawing.Size(76, 16)
        Me.lblDescripcion.TabIndex = 43
        Me.lblDescripcion.Text = "Descripci�n: "
        '
        'txtDescripcion
        '
        Me.txtDescripcion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescripcion.Location = New System.Drawing.Point(352, 232)
        Me.txtDescripcion.MaxLength = 100000
        Me.txtDescripcion.Multiline = True
        Me.txtDescripcion.Name = "txtDescripcion"
        Me.txtDescripcion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescripcion.Size = New System.Drawing.Size(256, 48)
        Me.txtDescripcion.TabIndex = 42
        Me.txtDescripcion.Text = "Descripcion"
        '
        'txtSGT
        '
        Me.txtSGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSGT.Location = New System.Drawing.Point(352, 200)
        Me.txtSGT.Name = "txtSGT"
        Me.txtSGT.Size = New System.Drawing.Size(256, 20)
        Me.txtSGT.TabIndex = 41
        Me.txtSGT.Text = "Sub Grupo de Trabajo"
        Me.txtSGT.Visible = False
        '
        'SB
        '
        Me.SB.Location = New System.Drawing.Point(0, 462)
        Me.SB.Name = "SB"
        Me.SB.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.SB2, Me.SB1})
        Me.SB.ShowPanels = True
        Me.SB.Size = New System.Drawing.Size(616, 24)
        Me.SB.TabIndex = 35
        '
        'SB2
        '
        Me.SB2.Text = "PATH :"
        Me.SB2.Width = 38
        '
        'SB1
        '
        Me.SB1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.SB1.Text = "StatusBarPanel1"
        Me.SB1.Width = 562
        '
        'txtGT
        '
        Me.txtGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGT.Location = New System.Drawing.Point(352, 168)
        Me.txtGT.Name = "txtGT"
        Me.txtGT.Size = New System.Drawing.Size(128, 20)
        Me.txtGT.TabIndex = 34
        Me.txtGT.Text = "Grupo de Trabajo"
        '
        'txtSC
        '
        Me.txtSC.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSC.Location = New System.Drawing.Point(352, 120)
        Me.txtSC.Name = "txtSC"
        Me.txtSC.Size = New System.Drawing.Size(128, 20)
        Me.txtSC.TabIndex = 33
        Me.txtSC.Text = "Sub Comit�"
        '
        'txtCT
        '
        Me.txtCT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCT.Location = New System.Drawing.Point(352, 72)
        Me.txtCT.Name = "txtCT"
        Me.txtCT.Size = New System.Drawing.Size(128, 20)
        Me.txtCT.TabIndex = 32
        Me.txtCT.Text = "Comite T�cnico"
        '
        'txtComite
        '
        Me.txtComite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComite.Location = New System.Drawing.Point(352, 24)
        Me.txtComite.Name = "txtComite"
        Me.txtComite.Size = New System.Drawing.Size(128, 20)
        Me.txtComite.TabIndex = 31
        Me.txtComite.Text = "Comit�"
        '
        'lblGT
        '
        Me.lblGT.AutoSize = True
        Me.lblGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGT.Location = New System.Drawing.Point(240, 171)
        Me.lblGT.Name = "lblGT"
        Me.lblGT.Size = New System.Drawing.Size(106, 16)
        Me.lblGT.TabIndex = 30
        Me.lblGT.Text = "Grupo de Trabajo: "
        '
        'lblSC
        '
        Me.lblSC.AutoSize = True
        Me.lblSC.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSC.Location = New System.Drawing.Point(240, 125)
        Me.lblSC.Name = "lblSC"
        Me.lblSC.Size = New System.Drawing.Size(74, 16)
        Me.lblSC.TabIndex = 29
        Me.lblSC.Text = "Sub Comit�: "
        '
        'lblCT
        '
        Me.lblCT.AutoSize = True
        Me.lblCT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCT.Location = New System.Drawing.Point(240, 75)
        Me.lblCT.Name = "lblCT"
        Me.lblCT.Size = New System.Drawing.Size(95, 16)
        Me.lblCT.TabIndex = 28
        Me.lblCT.Text = "Comite T�cnico: "
        '
        'lblComite
        '
        Me.lblComite.AutoSize = True
        Me.lblComite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComite.Location = New System.Drawing.Point(240, 24)
        Me.lblComite.Name = "lblComite"
        Me.lblComite.Size = New System.Drawing.Size(49, 16)
        Me.lblComite.TabIndex = 27
        Me.lblComite.Text = "Comite: "
        '
        'tvComites
        '
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 8)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = 1
        Me.tvComites.Size = New System.Drawing.Size(224, 352)
        Me.tvComites.TabIndex = 26
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 400)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(616, 62)
        Me.tlbBotonera.TabIndex = 47
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Inactivar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'lblSGT
        '
        Me.lblSGT.AutoSize = True
        Me.lblSGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSGT.Location = New System.Drawing.Point(241, 200)
        Me.lblSGT.Name = "lblSGT"
        Me.lblSGT.Size = New System.Drawing.Size(51, 16)
        Me.lblSGT.TabIndex = 48
        Me.lblSGT.Text = "Sub GT: "
        Me.lblSGT.Visible = False
        '
        'txtObjetivo
        '
        Me.txtObjetivo.Location = New System.Drawing.Point(351, 288)
        Me.txtObjetivo.Name = "txtObjetivo"
        Me.txtObjetivo.Size = New System.Drawing.Size(257, 20)
        Me.txtObjetivo.TabIndex = 49
        Me.txtObjetivo.Text = "Objetivo"
        '
        'lblResponsable
        '
        Me.lblResponsable.AutoSize = True
        Me.lblResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResponsable.Location = New System.Drawing.Point(241, 329)
        Me.lblResponsable.Name = "lblResponsable"
        Me.lblResponsable.Size = New System.Drawing.Size(82, 16)
        Me.lblResponsable.TabIndex = 50
        Me.lblResponsable.Text = "Responsable: "
        '
        'txtResponsable
        '
        Me.txtResponsable.Location = New System.Drawing.Point(352, 320)
        Me.txtResponsable.Name = "txtResponsable"
        Me.txtResponsable.Size = New System.Drawing.Size(256, 20)
        Me.txtResponsable.TabIndex = 51
        Me.txtResponsable.Text = "Responsable"
        '
        'cboResponsable
        '
        Me.cboResponsable.Location = New System.Drawing.Point(352, 320)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(256, 21)
        Me.cboResponsable.TabIndex = 52
        Me.cboResponsable.Text = "cboResponsable"
        '
        'lblactivo
        '
        Me.lblactivo.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblactivo.Location = New System.Drawing.Point(248, 352)
        Me.lblactivo.Name = "lblactivo"
        Me.lblactivo.Size = New System.Drawing.Size(304, 40)
        Me.lblactivo.TabIndex = 53
        '
        'frmP_Comite
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(616, 486)
        Me.Controls.Add(Me.lblactivo)
        Me.Controls.Add(Me.cboResponsable)
        Me.Controls.Add(Me.txtResponsable)
        Me.Controls.Add(Me.lblResponsable)
        Me.Controls.Add(Me.txtObjetivo)
        Me.Controls.Add(Me.lblSGT)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.lblObjetivo)
        Me.Controls.Add(Me.lblDescripcion)
        Me.Controls.Add(Me.txtDescripcion)
        Me.Controls.Add(Me.txtSGT)
        Me.Controls.Add(Me.txtGT)
        Me.Controls.Add(Me.txtSC)
        Me.Controls.Add(Me.txtCT)
        Me.Controls.Add(Me.txtComite)
        Me.Controls.Add(Me.lblGT)
        Me.Controls.Add(Me.lblSC)
        Me.Controls.Add(Me.lblCT)
        Me.Controls.Add(Me.lblComite)
        Me.Controls.Add(Me.SB)
        Me.Controls.Add(Me.tvComites)
        Me.Name = "frmP_Comite"
        Me.Text = "COMITES"
        CType(Me.SB2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SB1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load 'fmr 27/10/06
    Private Sub frmP_Comite_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        'cn.ConnectionString = ("Data source= ance02; initial catalog= dbNormaNet; user id = admsis; pwd=admynsys")

        'objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", "admsis", "admynsys")
        'cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", "admsis", "admynsys")

        Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
        Inactivos(txtSGT, cboResponsable)
        Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
        Limpia_Campos(txtSGT, cboResponsable)
        Call llena_TreeView()
    End Sub

#Region "  Llena TreView"
    Private Sub llena_TreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione un Comit�")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione un Comit�")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        tvComites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        'tvComites.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvComites.ResetText()

        Cursor.Current = Cursors.Default





    End Sub
#End Region

#Region "llenatreview de franK"
    '        Dim Comite As TreeNode
    '        Dim CT As TreeNode
    '        Dim SC As TreeNode
    '        Dim GT As TreeNode
    '        Dim SGT As TreeNode

    '        Dim oTablaComite As DataTable
    '        Dim oTablaCT As DataTable
    '        Dim oTablaSC As DataTable
    '        Dim oTablaGT As DataTable
    '        Dim oTablaSGT As DataTable 'fmr octubre
    '        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)

    '        oTablaComite = objNodos.ListaComite
    '        If objNodos.ListaComite Is Nothing Then
    '            Comite = tvComites.Nodes.Add("Ra�z")
    '            Exit Sub
    '        End If

    '        ' deshabilita la actualizaci�n en pantalla del control TreeView 
    '        tvComites.BeginUpdate()

    '        ' defino variable del tipo DataRow
    '        Dim RegComite As DataRow
    '        Dim RegCT As DataRow
    '        Dim RegSC As DataRow
    '        Dim RegGT As DataRow
    '        Dim RegSGT As DataRow

    '        dvComite = oTablaComite.DefaultView
    '        Comite = tvComites.Nodes.Add("Seleccione un Comit�")

    '        For Each RegComite In oTablaComite.Rows '******COMITES

    '            If RegComite("ID_Comite") = "NA" Then 'Valida si es NA
    '                GoTo ComiteNA
    '            End If

    '            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))

    'ComiteNA:

    '            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
    '                GoTo sinComite
    '            End If

    '            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

    '            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS

    '                If RegComite("ID_comite") = "NA" Or RegCT("ID_CT") = "NA" Then 'Valida si no existen NA
    '                    GoTo CTNA
    '                End If

    '                CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))

    'CTNA:

    '                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
    '                    GoTo sinCT
    '                End If

    '                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

    '                For Each RegSC In oTablaSC.Rows '******SUB COMITE

    '                    If RegComite("ID_Comite") = "NA" Or RegCT("ID_CT") = "NA" Or RegSC("ID_SC") = "NA" Then 'Valida si no existen nodos hijos
    '                        GoTo SCNA
    '                    End If

    '                    SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))

    'SCNA:

    '                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
    '                        GoTo sinSC
    '                    End If
    '                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

    '                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO

    '                        If RegCT("ID_CT") = "NA" And RegSC("ID_SC") = "NA" Then 'cuando es de un comite el GT
    '                            'Comite = Comite.Nodes.Add(Trim(RegGT("ID_Grupo")))
    '                            Comite.Nodes.Add(Trim(RegGT("ID_Grupo")))
    '                            'Exit For
    '                        End If

    '                        If Not (RegCT("ID_CT") = "NA") And (RegSC("ID_SC") = "NA") Then 'cuando es de un CT el GT
    '                            'CT = CT.Nodes.Add(Trim(RegGT("ID_Grupo")))
    '                            CT.Nodes.Add(Trim(RegGT("ID_Grupo")))
    '                            'Exit For
    '                        End If


    '                        If Not (RegCT("ID_CT") = "NA") And Not (RegSC("ID_SC") = "NA") And Not (RegGT("ID_Grupo") = "") Then 'cuando es de un comite el GT
    '                            'GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
    '                            SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
    '                        End If



    '                        '''If objNodos.ListaSGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo")) Is Nothing Then  'Valida si no existen nodos hijos
    '                        '''    GoTo sinGT
    '                        '''End If
    '                        '''oTablaSGT = objNodos.ListaSGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"))  '***OK

    '                        '''For Each RegSGT In oTablaSGT.Rows '******SUB GRUPOS DE TRABAJO
    '                        '''    SGT = GT.Nodes.Add(Trim(RegSGT("ID_SGT")))

    '                        '''Next 'SGT
    '                        '''sinGT:


    '                    Next 'GT
    'sinSC:
    '                Next 'SC
    'sinCT:
    '            Next 'CT
    'sinComite:
    '        Next 'Comites
    '        tvComites.EndUpdate()
    '        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
    '        tvComites.AllowDrop = True
    '        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
    '''        tvComites.Sorted = True
#End Region

#Region "  AfterSelect"
    Private Sub tvComites_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect

        ' recupero el Path donde est� la selecci�n y lo pongo en la barra de estado
        SB1.Text = e.Node.FullPath
        iCaso = 0

        objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)  'fmr 07/12/06
        Dim array_texto As Array
        Dim cmdBusca As New SqlCommand
        Dim cmdBusca2 As New SqlCommand
        Dim cmdBusca3 As New SqlCommand
        Dim cmdBusca4 As New SqlCommand

        Dim da As New SqlDataAdapter(cmdBusca)
        Dim da2 As New SqlDataAdapter(cmdBusca2)
        Dim da3 As New SqlDataAdapter(cmdBusca3)
        Dim da4 As New SqlDataAdapter(cmdBusca4)

        Dim dsP_Normalizacion As New DataSet
        Dim dsP_Normalizacion2 As New DataSet
        Dim dsP_Normalizacion3 As New DataSet
        Dim dsP_Normalizacion4 As New DataSet

        If SB1.Text = "" Or SB1.Text = "Seleccione un Comit�" Then
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
            Inactivos(cmdBorrar)
            txtResponsable.Text = ""
            iCaso = 1
            lblactivo.Text = ""
            objComites.Inactivo = Nothing
            Exit Sub

        End If

        lblactivo.Text = ""
        Activos(cmdBorrar)
        array_texto = Split(SB1.Text, "\")

        If array_texto.Length <= 1 Then
            Limpia_Campos(txtComite)
        Else
            objComites.Bandera = 1

            objComites.ID_Comite = array_texto(1)
            objComites.Busca_uno()
            '''aqui

            txtDescripcion.Text = objComites.Descripcion
            txtObjetivo.Text = ""
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT
            txtObjetivo.Text = objComites.Objetivo
            'Inactivo/Activo
            Select Case objComites.Inactivo
                Case True
                    lblactivo.Text = "Inactivo"
                    tlbBotonera.Buttons.Item(5).Text = "Activar"
                Case False
                    lblactivo.Text = "Activo"
                    tlbBotonera.Buttons.Item(5).Text = "Inactivar"
            End Select




            objempleados.Bandera = 3
            Call llena_responsable(objComites.Responsable)
            txtResponsable.Text = objComites.Responsable
            iCaso = 2
        End If

        If array_texto.Length <= 2 Then
            txtCT.Text = ""
        Else
            objComites.Bandera = 2
            objComites.ID_Comite = array_texto(1)

            If Microsoft.VisualBasic.Left(array_texto(2), 2) = "GT" Then
                objComites.Bandera = 4
                objComites.ID_CT = "NA"
                objComites.ID_SC = "NA"
                objComites.ID_GT = array_texto(2)
                GoTo GT
            End If

            objComites.ID_CT = array_texto(2)
            objComites.Busca_dos()
            txtDescripcion.Text = objComites.Descripcion
            txtObjetivo.Text = objComites.Objetivo
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            'Inactivo/Activo
            Select Case objComites.Inactivo
                Case True
                    lblactivo.Text = "Inactivo"
                    tlbBotonera.Buttons.Item(5).Text = "Activar"
                Case False
                    lblactivo.Text = "Activo"
                    tlbBotonera.Buttons.Item(5).Text = "Inactivar"
            End Select

            objempleados.Bandera = 3
            Call llena_responsable(objComites.Responsable)
            txtResponsable.Text = objComites.Responsable


            iCaso = 3

        End If

        '''''''''''''''''''''''''CT


        If array_texto.Length <= 3 Then

            txtSC.Text = ""
        Else
            objComites.Bandera = 3
            objComites.ID_Comite = array_texto(1)
            objComites.ID_CT = array_texto(2)

            If Microsoft.VisualBasic.Left(array_texto(3), 2) = "GT" Then
                objComites.Bandera = 4
                objComites.ID_SC = "NA"
                objComites.ID_GT = array_texto(3)
                GoTo GT
            End If

            objComites.ID_SC = array_texto(3)
            objComites.Busca_tres()
            txtDescripcion.Text = objComites.Descripcion
            txtObjetivo.Text = objComites.Objetivo
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            'Inactivo/Activo
            Select Case objComites.Inactivo
                Case True
                    lblactivo.Text = "Inactivo"
                    tlbBotonera.Buttons.Item(5).Text = "Activar"
                Case False
                    lblactivo.Text = "Activo"
                    tlbBotonera.Buttons.Item(5).Text = "Inactivar"
            End Select

            objempleados.Bandera = 3
            Call llena_responsable(objComites.Responsable)
            txtResponsable.Text = objComites.Responsable

            iCaso = 4
        End If

        '''''''''''''''''''''''''''''' sc

        If array_texto.Length <= 4 Then
            txtGT.Text = ""
        Else
            objComites.Bandera = 4
            objComites.ID_Comite = array_texto(1)
            objComites.ID_CT = array_texto(2)
            objComites.ID_SC = array_texto(3)
            objComites.ID_GT = array_texto(4)

GT:         'esta salto de l�nea es para cuando un Comite o CT tiene un GT directo

            objComites.Busca_cuatro()
            txtDescripcion.Text = objComites.Descripcion
            txtObjetivo.Text = objComites.Objetivo
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            'Inactivo/Activo
            Select Case objComites.Inactivo
                Case True
                    lblactivo.Text = "Inactivo"
                    tlbBotonera.Buttons.Item(5).Text = "Activar"
                Case False
                    lblactivo.Text = "Activo"
                    tlbBotonera.Buttons.Item(5).Text = "Inactivar"
            End Select

            objempleados.Bandera = 3
            Call llena_responsable(objComites.Responsable)
            txtResponsable.Text = objComites.Responsable


            iCaso = 5
            'cmdBusca4.Dispose()
        End If

        If array_texto.Length > 5 Then
            iCaso = 6
        End If


    End Sub
#End Region

    Sub llena_responsable(ByVal responsable As String)
        Try

            'objempleados.Bandera = 6  'funfiona cuando se llena el treeview
            objempleados.ID_Area = "12"
            objempleados.Id_usuario = responsable
            'cboResponsable.DataSource = 
            objempleados.ListaCombo(cboResponsable)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub


    Private Sub tvComites_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles tvComites.BeforeExpand
        ' le asigno la imagen con la carpeta abierta
        tvComites.SelectedImageIndex = 1
    End Sub

    Private Sub Agregar()
        If objComites.Inactivo = True Then
            MsgBox("No es posible agregar a un elemento inactivo")
            Exit Sub
        End If

        Inactivos(cmdAgregar, cmdEditar)
        Inactivos(tvComites, cmdBorrar)
        Dim sSqlAgregar As String
        objempleados.Bandera = 6
        Call llena_responsable("")
        If iCaso = 1 Then
            Activos(cmdDeshacer, cmdGuardar, txtComite, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Limpia_Campos(txtComite, txtDescripcion, txtObjetivo)
            Exit Sub
        End If

        If iCaso = 2 Then
            Activos(cmdDeshacer, cmdGuardar, txtCT, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Limpia_Campos(txtCT, txtDescripcion, txtObjetivo)

            Activos(txtGT)
            Limpia_Campos(txtGT)
            Exit Sub
        End If

        If iCaso = 3 Then
            Activos(cmdDeshacer, cmdGuardar, txtSC, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Limpia_Campos(txtSC, txtDescripcion, txtObjetivo)

            Activos(txtGT)
            Limpia_Campos(txtGT)
            Exit Sub
        End If

        If iCaso = 4 Then
            Activos(cmdDeshacer, cmdGuardar, txtGT, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Limpia_Campos(txtGT, txtDescripcion, txtObjetivo)
            Exit Sub
        End If

        If iCaso <> 1 Or iCaso <> 2 Or iCaso <> 3 Or iCaso <> 4 Then
            MsgBox("Este es el ultimo nivel, no se pueden agregar m�s nodos")
            Activos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            'Inactivos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            'Activos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            'Inactivos(cboResponsable)
            Exit Sub
        End If

    End Sub

    Private Sub Editar()

        Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
        Dim sSqlAgregar As String
        Dim variable As String



        'txtResponsable.Visible = True
        'txtResponsable.Text = cboResponsable.Text

        '  txtResponsable.Text = objComites.Responsable


        If iCaso = 1 Then
            MsgBox("Este nodo no se puede editar", MsgBoxStyle.Exclamation, "Comites")
            Activos(cmdAgregar, cmdEditar)
            bandError = True
            'Activos(cboResponsable)
            Exit Sub
        End If

        objempleados.Bandera = 6
        Call llena_responsable(objComites.Responsable)
        cboResponsable.SelectedValue = objComites.Responsable


        If iCaso = 2 Then
            'tvComites.Enabled = False
            Inactivos(tvComites)
            Activos(cmdDeshacer, cmdGuardar, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Exit Sub
        End If

        If iCaso = 3 Then
            Inactivos(tvComites)
            Activos(cmdDeshacer, cmdGuardar, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Exit Sub
        End If

        If iCaso = 4 Then
            Inactivos(tvComites)
            Activos(cmdDeshacer, cmdGuardar, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Exit Sub
        End If

        If iCaso = 5 Then
            Inactivos(tvComites)
            Activos(cmdDeshacer, cmdGuardar, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Exit Sub
        End If

        If iCaso = 6 Then
            Inactivos(tvComites)
            Activos(cmdDeshacer, cmdGuardar, txtDescripcion, txtObjetivo)
            Activos(cboResponsable)
            Exit Sub
        End If

    End Sub


    Private Sub Guardar()
        Dim sSqlAgregar As String

        If sTipoProceso = "Agregar" Then '*****************IF*************AGREGAR
            If iCaso = 1 Then
                With objComites
                    .Bandera = 1
                    .ID_Comite = UCase(txtComite.Text)
                    .Descripcion = txtDescripcion.Text
                    .Responsable = cboResponsable.SelectedValue
                    .Objetivo = txtObjetivo.Text
                    .Inactivo = False

                    sRutaComite = objComites.ID_Comite
                    .Busca_uno()
                    If .Encontrado <> True Then
                        .Bandera = 1
                        .ID_Comite = UCase(txtComite.Text)
                        .Descripcion = txtDescripcion.Text
                        .Responsable = cboResponsable.SelectedValue
                        .Objetivo = txtObjetivo.Text
                        .Inactivo = False
                        .Agregar_uno()
                    Else
                        MsgBox("El Registro ya existe.")
                        'deshacer()
                        Exit Sub
                    End If
                    If .statusProceso = False Then
                        'deshacer()
                        Exit Sub
                    End If

                    Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + sRutaComite)
                    If Directory.Exists(sPath) = False Then
                        MkDir(sPath)
                    End If
                End With
                If status = "Fallo" Then
                    Exit Sub
                End If
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Inactivos(txtSGT, cboResponsable, txtObjetivo)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Limpia_Campos(txtSGT, cboResponsable)
            End If
            '***************************************************************************************
            If iCaso = 2 Then
                If Trim(txtCT.Text) <> "" And Trim(txtGT.Text) <> "" Then
                    MsgBox("No puedes agregar un CT y un GT al mismo tiempo", MsgBoxStyle.Exclamation, "Catalogo de Comites")
                    Exit Sub
                End If

                With objComites
                    .Bandera = 2
                    .ID_Comite = UCase(txtComite.Text)
                    .ID_CT = UCase(txtCT.Text)
                    .Descripcion = txtDescripcion.Text
                    .Objetivo = txtObjetivo.Text
                    .Responsable = cboResponsable.SelectedValue

                    If objComites.ID_CT = "NA" Or objComites.ID_CT = "" Then
                        sRutaComite = objComites.ID_Comite
                    Else
                        sRutaComite = objComites.ID_Comite + "\" + objComites.ID_CT
                    End If


                    If txtGT.Text <> "" Then
                        If Not (Microsoft.VisualBasic.Left(txtGT.Text, 2) = "GT") Then
                            MsgBox("El Grupo de Trabajo debe empezar con GT", MsgBoxStyle.Information, "Catalogo de Comites")
                            txtGT.Text = ""
                            Exit Sub
                        End If
                        .ID_CT = "NA"
                        .ID_SC = "NA"

                        .Bandera = 2
                        .Agregar_dos()

                        .Bandera = 3
                        .Agregar_tres()

                        .Bandera = 4
                        .ID_GT = UCase(txtGT.Text)
                        .Agregar_cuatro()
                        sRutaComite += "\" + .ID_GT
                    Else
                        If Not (Microsoft.VisualBasic.Left(txtCT.Text, 2) = "CT") Then
                            MsgBox("El Comite T�cnico debe empezar con CT", MsgBoxStyle.Information, "Catalogo de Comites")
                            txtCT.Text = ""
                            Exit Sub
                        End If
                        .Agregar_dos()
                    End If

                    If .statusProceso = False Then
                        Exit Sub
                    End If

                    Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + sRutaComite)
                    'Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + SB1.Text)

                    If Directory.Exists(sPath) = False Then
                        MkDir(sPath)
                    End If


                End With
                If status = "Fallo" Then
                    Exit Sub
                End If
                cn.Close()
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Inactivos(txtSGT, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Limpia_Campos(txtSGT)
            End If

            If iCaso = 3 Then
                If Trim(txtSC.Text) <> "" And Trim(txtGT.Text) <> "" Then
                    MsgBox("No puedes agregar un SC y un GT al mismo tiempo", MsgBoxStyle.Exclamation, "Catalogo de Comites")
                    Exit Sub
                End If

                With objComites
                    .Bandera = 3
                    .ID_Comite = UCase(txtComite.Text)
                    .ID_CT = UCase(txtCT.Text)
                    .ID_SC = UCase(txtSC.Text)
                    .Descripcion = txtDescripcion.Text
                    .Objetivo = txtObjetivo.Text
                    .Responsable = cboResponsable.SelectedValue


                    If objComites.ID_CT = "NA" Or objComites.ID_CT = "" Then
                        sRutaComite = objComites.ID_Comite
                    Else
                        sRutaComite = objComites.ID_Comite + "\" + objComites.ID_CT
                    End If

                    If objComites.ID_SC = "NA" Or objComites.ID_SC = "" Then
                    Else
                        sRutaComite += "\" + objComites.ID_SC
                    End If


                    If txtGT.Text <> "" Then
                        If Not (Microsoft.VisualBasic.Left(txtGT.Text, 2) = "GT") Then
                            MsgBox("El Grupo de Trabajo debe empezar con GT", MsgBoxStyle.Information, "Catalogo de Comites")
                            txtGT.Text = ""
                            Exit Sub
                        End If
                        .ID_SC = "NA"

                        .Bandera = 3
                        .Agregar_tres()

                        .Bandera = 4
                        .ID_GT = UCase(txtGT.Text)
                        .Agregar_cuatro()
                        sRutaComite += "\" + .ID_GT
                    Else
                        If Not (Microsoft.VisualBasic.Left(txtSC.Text, 2) = "SC") Then
                            MsgBox("El Sub Comit� debe empezar con SC", MsgBoxStyle.Information, "Catalogo de Comites")
                            txtSC.Text = ""
                            Exit Sub
                        End If
                        .Agregar_tres()
                    End If

                    If .statusProceso = False Then
                        Exit Sub
                    End If

                    Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + sRutaComite)
                    If Directory.Exists(sPath) = False Then
                        MkDir(sPath)
                    End If

                End With
                If status = "Fallo" Then
                    Exit Sub
                End If
                cn.Close()
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Inactivos(txtSGT, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Limpia_Campos(txtSGT)
            End If

            If iCaso = 4 Then
                '''If txtSC.Text <> "" And txtGT.Text <> "" Then
                '''    MsgBox("No puedes agregar un CT y un GT al mismo tiempo", MsgBoxStyle.Exclamation, "Catalogo de Comites")
                '''    Exit Sub
                '''End If

                With objComites
                    .Bandera = 4
                    .ID_Comite = UCase(txtComite.Text)
                    .ID_CT = UCase(txtCT.Text)
                    .ID_SC = UCase(txtSC.Text)
                    .ID_GT = UCase(txtGT.Text)
                    .Descripcion = txtDescripcion.Text
                    .Objetivo = txtObjetivo.Text
                    .Responsable = cboResponsable.SelectedValue

                    If objComites.ID_CT = "NA" Then
                        sRutaComite = objComites.ID_Comite
                    Else
                        sRutaComite = objComites.ID_Comite + "\" + objComites.ID_CT
                    End If


                    If objComites.ID_SC <> "NA" Then
                        sRutaComite += "\" + objComites.ID_SC
                    End If

                    If objComites.ID_GT <> "NA" Then
                        sRutaComite += "\" + objComites.ID_GT
                    End If

                    .Agregar_cuatro()

                    If .statusProceso = False Then
                        Exit Sub
                    End If

                    Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + sRutaComite)
                    If Directory.Exists(sPath) = False Then
                        MkDir(sPath)
                    End If

                End With
                If status = "Fallo" Then
                    Exit Sub
                End If
                cn.Close()
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Inactivos(txtSGT, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Limpia_Campos(txtSGT)
            End If

        ElseIf sTipoProceso = "Editar" Then '****************ELSE**************EDITAR
            If iCaso = 2 Then
                objComites.Bandera = 1 'COMITE
                objComites.ID_Comite = UCase(txtComite.Text)
                objComites.Descripcion = txtDescripcion.Text
                objComites.Responsable = cboResponsable.SelectedValue
                objComites.Objetivo = txtObjetivo.Text
                objComites.Actualizar_uno()
                '''If status = "Fallo" Then
                '''    MsgBox("Verifica que no esxita ya este nombre", MsgBoxStyle.Exclamation, "Campo Existente")
                '''    Exit Sub
                '''End If
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
            End If

            If iCaso = 3 Then
                objComites.Bandera = 2 'CT
                objComites.ID_Comite = UCase(txtComite.Text)
                objComites.ID_CT = UCase(txtCT.Text)
                objComites.Descripcion = txtDescripcion.Text
                objComites.Objetivo = txtObjetivo.Text
                objComites.Responsable = cboResponsable.SelectedValue
                objComites.Actualizar_dos()
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
            End If

            If iCaso = 4 Then
                objComites.Bandera = 3 'SC
                objComites.ID_Comite = UCase(txtComite.Text)
                objComites.ID_CT = UCase(txtCT.Text)
                objComites.ID_SC = UCase(txtSC.Text)
                objComites.Descripcion = txtDescripcion.Text
                objComites.Objetivo = txtObjetivo.Text
                objComites.Responsable = cboResponsable.SelectedValue
                objComites.Actualizar_tres()
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
            End If

            If iCaso = 5 Then
                Dim descripcion As String = txtDescripcion.Text
                Dim objetivo As String = txtObjetivo.Text
                objComites.Bandera = 4 'GT
                objComites.ID_Comite = UCase(txtComite.Text)
                objComites.ID_CT = UCase(txtCT.Text)
                objComites.ID_SC = UCase(txtSC.Text)
                objComites.ID_GT = UCase(txtGT.Text)
                objComites.Descripcion = txtDescripcion.Text
                objComites.Objetivo = txtObjetivo.Text
                objComites.Responsable = cboResponsable.SelectedValue
                objComites.Actualizar_cuatro()
                '''If status = "Fallo" Then
                '''    MsgBox("Verifica que no esxita ya este nombre", MsgBoxStyle.Exclamation, "Campo Existente")
                '''    Exit Sub
                '''End If
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
                Activos(tvComites, cmdAgregar, cmdEditar)
                Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
            End If

            '''If iCaso = 6 Then
            '''    Dim descripcion As String = txtDescripcion.Text
            '''    Dim objetivo As String = txtObjetivo.Text
            '''    objComites.Bandera = 5 'SGT
            '''    objComites.ID_Comite = UCASE(txtComite.Text)
            '''    objComites.ID_CT = Ucase(txtCT.Text)
            '''    objComites.ID_SC = Ucase(txtSC.Text)
            '''    objComites.ID_GT = Ucase(txtGT.Text)
            '''    objComites.ID_SGT = txtSGT.Text
            '''    objComites.Descripcion = txtDescripcion.Text
            '''    objComites.Objetivo = txtObjetivo.Text
            '''    objComites.Actualizar_cinco()
            '''    '''If status = "Fallo" Then
            '''    '''    MsgBox("Verifica que no esxita ya este nombre", MsgBoxStyle.Exclamation, "Campo Existente")
            '''    '''    Exit Sub
            '''    '''End If
            '''    tvComites.Nodes.Clear()
            '''    Call llena_TreeView()
            '''    Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, txtSGT, cboResponsable)
            '''    Activos(tvComites, cmdAgregar, cmdEditar)
            '''    Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, txtSGT)
            '''End If
        End If
    End Sub



    Private Sub Borrar()
        Dim bandActivo As Boolean = False
        If iCaso = 2 Then
            If lblactivo.Text = "Activo" Then
                If MsgBox("�Estas seguro que deseas Inactivar este Comit�: " & txtComite.Text, MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    bandActivo = True
                Else
                    Exit Sub
                End If
            Else
                If MsgBox("�Estas seguro que deseas Activarlo", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    bandActivo = False
                Else
                    Exit Sub
                End If
            End If
            objComites.Bandera = 1
            objComites.ID_Comite = UCase(txtComite.Text)
            objComites.Inactivo = bandActivo
            objComites.Borrar_uno()

            If objComites.statusProceso = False Then
                Exit Sub
            End If

            '''Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + sRutaComite)
            '''If Directory.Exists(sPath) = False Then
            '''    MkDir(sPath)
            '''End If

            tvComites.Nodes.Clear()
            Call llena_TreeView()
            Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
            Activos(tvComites, cmdAgregar, cmdEditar)
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
        End If

        If iCaso = 3 Then
            If lblactivo.Text = "Activo" Then
                If MsgBox("�Estas seguro que deseas Inactivar este Comit�: " & txtComite.Text, MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    bandActivo = True
                Else
                    Exit Sub
                End If
            Else
                If MsgBox("�Estas seguro que deseas Activarlo", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    bandActivo = False
                Else
                    Exit Sub
                End If
            End If

            objComites.Bandera = 2
            objComites.ID_Comite = UCase(txtComite.Text)
            objComites.ID_CT = UCase(txtCT.Text)
            objComites.Inactivo = bandActivo
            objComites.Borrar_dos()

            If objComites.statusProceso = False Then
                Exit Sub
            End If

            tvComites.Nodes.Clear()
            Call llena_TreeView()
            Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
            Activos(tvComites, cmdAgregar, cmdEditar)
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
        End If

        If iCaso = 4 Then
            If lblactivo.Text = "Activo" Then
                If MsgBox("�Estas seguro que deseas Inactivar este Comit�: " & txtComite.Text, MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    bandActivo = True
                Else
                    Exit Sub
                End If
            Else
                If MsgBox("�Estas seguro que deseas Activarlo", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    bandActivo = False
                Else
                    Exit Sub
                End If
            End If

            objComites.Bandera = 3
            objComites.ID_Comite = UCase(txtComite.Text)
            objComites.ID_CT = UCase(txtCT.Text)
            objComites.ID_SC = UCase(txtSC.Text)
            objComites.Inactivo = bandActivo
            objComites.Borrar_tres()

            If objComites.statusProceso = False Then
                Exit Sub
            End If

            tvComites.Nodes.Clear()
            Call llena_TreeView()
            Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
            Activos(tvComites, cmdAgregar, cmdEditar)
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
        End If

        If iCaso = 5 Then
            If lblactivo.Text = "Activo" Then
                If MsgBox("�Estas seguro que deseas Inactivar este Comit�: " & txtComite.Text, MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    bandActivo = True
                Else
                    Exit Sub
                End If
            Else
                If MsgBox("�Estas seguro que deseas Activarlo", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    bandActivo = False
                Else
                    Exit Sub
                End If
            End If
            objComites.Bandera = 4
            objComites.ID_Comite = UCase(txtComite.Text)
            objComites.ID_CT = UCase(txtCT.Text)
            objComites.ID_SC = UCase(txtSC.Text)
            objComites.ID_GT = UCase(txtGT.Text)
            objComites.Inactivo = bandActivo
            objComites.Borrar_cuatro()

            If objComites.statusProceso = False Then
                Exit Sub
            End If

            tvComites.Nodes.Clear()
            Call llena_TreeView()
            Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
            Activos(tvComites, cmdAgregar, cmdEditar)
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
        End If

    End Sub
    Private Sub Limpiar(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.text = ""
        Next objeto
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                sTipoProceso = "Agregar"
                Call Agregar()

            Case 2 'EDITAR
                sTipoProceso = "Editar"
                Call Editar()
                If bandError <> True Then
                    Activos(cmdDeshacer, cmdGuardar)
                End If
                bandError = False

            Case 3 'DESHACER
                deshacer()
            Case 4 'GUARDAR
                    Call Guardar()

            Case 5 'BORRAR
                    Call Borrar()

            Case 7 'SALIR
                    Me.Close()
        End Select
    End Sub
    Private Sub deshacer()
        Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, txtSGT, cboResponsable)

        objempleados.Bandera = 3
        Call llena_responsable(txtResponsable.Text)
        'Call llena_responsable("")
        cboResponsable.DataSource = Nothing
        Activos(tvComites, cmdAgregar, cmdEditar, cmdBorrar)
        Limpiar(txtComite, txtCT, txtSC, txtGT, txtSGT, txtDescripcion, txtObjetivo)
        tvComites.CollapseAll()
    End Sub
End Class
