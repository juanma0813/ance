Public Class frmPNN
    Inherits System.Windows.Forms.Form


#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents PnlCaptura As System.Windows.Forms.Panel
    Friend WithEvents PnlOpn1 As System.Windows.Forms.Panel
    Friend WithEvents RadAlterno As System.Windows.Forms.RadioButton
    Friend WithEvents RadPubDOF As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtclave As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents cboclave As System.Windows.Forms.ComboBox
    Friend WithEvents txtdescripcion As System.Windows.Forms.TextBox
    Friend WithEvents txtfcnn As System.Windows.Forms.TextBox
    Friend WithEvents txtf_fin As System.Windows.Forms.TextBox
    Friend WithEvents txtf_inicio As System.Windows.Forms.TextBox
    Friend WithEvents txtdof As System.Windows.Forms.TextBox
    Friend WithEvents dtcnn As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtdof As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtInicial As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtfprimpub As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtfprimpub As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPNN))
        Me.PnlCaptura = New System.Windows.Forms.Panel
        Me.txtfcnn = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.dtcnn = New System.Windows.Forms.DateTimePicker
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtdescripcion = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtclave = New System.Windows.Forms.TextBox
        Me.txtf_fin = New System.Windows.Forms.TextBox
        Me.txtf_inicio = New System.Windows.Forms.TextBox
        Me.txtdof = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.dtdof = New System.Windows.Forms.DateTimePicker
        Me.dtFin = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.dtInicial = New System.Windows.Forms.DateTimePicker
        Me.PnlOpn1 = New System.Windows.Forms.Panel
        Me.RadAlterno = New System.Windows.Forms.RadioButton
        Me.RadPubDOF = New System.Windows.Forms.RadioButton
        Me.cboclave = New System.Windows.Forms.ComboBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.txtfprimpub = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.dtfprimpub = New System.Windows.Forms.DateTimePicker
        Me.PnlCaptura.SuspendLayout()
        Me.PnlOpn1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PnlCaptura
        '
        Me.PnlCaptura.Controls.Add(Me.txtfprimpub)
        Me.PnlCaptura.Controls.Add(Me.Label4)
        Me.PnlCaptura.Controls.Add(Me.dtfprimpub)
        Me.PnlCaptura.Controls.Add(Me.txtfcnn)
        Me.PnlCaptura.Controls.Add(Me.Label14)
        Me.PnlCaptura.Controls.Add(Me.dtcnn)
        Me.PnlCaptura.Controls.Add(Me.Label12)
        Me.PnlCaptura.Controls.Add(Me.txtdescripcion)
        Me.PnlCaptura.Controls.Add(Me.Label11)
        Me.PnlCaptura.Controls.Add(Me.Label10)
        Me.PnlCaptura.Controls.Add(Me.txtclave)
        Me.PnlCaptura.Controls.Add(Me.txtf_fin)
        Me.PnlCaptura.Controls.Add(Me.txtf_inicio)
        Me.PnlCaptura.Controls.Add(Me.txtdof)
        Me.PnlCaptura.Controls.Add(Me.Label3)
        Me.PnlCaptura.Controls.Add(Me.dtdof)
        Me.PnlCaptura.Controls.Add(Me.dtFin)
        Me.PnlCaptura.Controls.Add(Me.Label2)
        Me.PnlCaptura.Controls.Add(Me.Label1)
        Me.PnlCaptura.Controls.Add(Me.dtInicial)
        Me.PnlCaptura.Controls.Add(Me.PnlOpn1)
        Me.PnlCaptura.Controls.Add(Me.cboclave)
        Me.PnlCaptura.Location = New System.Drawing.Point(12, 8)
        Me.PnlCaptura.Name = "PnlCaptura"
        Me.PnlCaptura.Size = New System.Drawing.Size(508, 344)
        Me.PnlCaptura.TabIndex = 1
        '
        'txtfcnn
        '
        Me.txtfcnn.Location = New System.Drawing.Point(128, 216)
        Me.txtfcnn.Name = "txtfcnn"
        Me.txtfcnn.Size = New System.Drawing.Size(112, 20)
        Me.txtfcnn.TabIndex = 42
        Me.txtfcnn.Text = ""
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(24, 216)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 24)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "Fecha de Envio a CNN"
        '
        'dtcnn
        '
        Me.dtcnn.Location = New System.Drawing.Point(128, 216)
        Me.dtcnn.Name = "dtcnn"
        Me.dtcnn.Size = New System.Drawing.Size(128, 20)
        Me.dtcnn.TabIndex = 43
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(24, 80)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 16)
        Me.Label12.TabIndex = 36
        Me.Label12.Text = "Tipo Plan"
        '
        'txtdescripcion
        '
        Me.txtdescripcion.Location = New System.Drawing.Point(128, 48)
        Me.txtdescripcion.Name = "txtdescripcion"
        Me.txtdescripcion.Size = New System.Drawing.Size(264, 20)
        Me.txtdescripcion.TabIndex = 31
        Me.txtdescripcion.Text = ""
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(24, 48)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(64, 23)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Descripcion"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(24, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(64, 16)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "Clave"
        '
        'txtclave
        '
        Me.txtclave.Location = New System.Drawing.Point(128, 16)
        Me.txtclave.Name = "txtclave"
        Me.txtclave.Size = New System.Drawing.Size(256, 20)
        Me.txtclave.TabIndex = 28
        Me.txtclave.Text = ""
        '
        'txtf_fin
        '
        Me.txtf_fin.Location = New System.Drawing.Point(128, 184)
        Me.txtf_fin.Name = "txtf_fin"
        Me.txtf_fin.Size = New System.Drawing.Size(112, 20)
        Me.txtf_fin.TabIndex = 27
        Me.txtf_fin.Text = ""
        '
        'txtf_inicio
        '
        Me.txtf_inicio.Location = New System.Drawing.Point(128, 152)
        Me.txtf_inicio.Name = "txtf_inicio"
        Me.txtf_inicio.Size = New System.Drawing.Size(112, 20)
        Me.txtf_inicio.TabIndex = 26
        Me.txtf_inicio.Text = ""
        '
        'txtdof
        '
        Me.txtdof.Location = New System.Drawing.Point(128, 264)
        Me.txtdof.Name = "txtdof"
        Me.txtdof.Size = New System.Drawing.Size(112, 20)
        Me.txtdof.TabIndex = 25
        Me.txtdof.Text = ""
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(24, 256)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 26)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Fecha de Publicaci�n DOF:"
        '
        'dtdof
        '
        Me.dtdof.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtdof.Location = New System.Drawing.Point(128, 264)
        Me.dtdof.Name = "dtdof"
        Me.dtdof.Size = New System.Drawing.Size(128, 20)
        Me.dtdof.TabIndex = 2
        '
        'dtFin
        '
        Me.dtFin.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtFin.Location = New System.Drawing.Point(128, 184)
        Me.dtFin.Name = "dtFin"
        Me.dtFin.Size = New System.Drawing.Size(128, 20)
        Me.dtFin.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 184)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 16)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Fecha Final:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 152)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Fecha Inicial:"
        '
        'dtInicial
        '
        Me.dtInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtInicial.Location = New System.Drawing.Point(128, 152)
        Me.dtInicial.Name = "dtInicial"
        Me.dtInicial.Size = New System.Drawing.Size(128, 20)
        Me.dtInicial.TabIndex = 3
        '
        'PnlOpn1
        '
        Me.PnlOpn1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PnlOpn1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PnlOpn1.Controls.Add(Me.RadAlterno)
        Me.PnlOpn1.Controls.Add(Me.RadPubDOF)
        Me.PnlOpn1.Location = New System.Drawing.Point(128, 80)
        Me.PnlOpn1.Name = "PnlOpn1"
        Me.PnlOpn1.Size = New System.Drawing.Size(200, 56)
        Me.PnlOpn1.TabIndex = 1
        '
        'RadAlterno
        '
        Me.RadAlterno.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadAlterno.Location = New System.Drawing.Point(15, 27)
        Me.RadAlterno.Name = "RadAlterno"
        Me.RadAlterno.Size = New System.Drawing.Size(176, 24)
        Me.RadAlterno.TabIndex = 1
        Me.RadAlterno.Text = "Suplemento"
        '
        'RadPubDOF
        '
        Me.RadPubDOF.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadPubDOF.Location = New System.Drawing.Point(15, 3)
        Me.RadPubDOF.Name = "RadPubDOF"
        Me.RadPubDOF.Size = New System.Drawing.Size(176, 24)
        Me.RadPubDOF.TabIndex = 0
        Me.RadPubDOF.Text = "Publicado en DOF"
        '
        'cboclave
        '
        Me.cboclave.Location = New System.Drawing.Point(128, 16)
        Me.cboclave.Name = "cboclave"
        Me.cboclave.Size = New System.Drawing.Size(272, 21)
        Me.cboclave.TabIndex = 44
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 370)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(418, 62)
        Me.tlbBotonera.TabIndex = 10
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'txtfprimpub
        '
        Me.txtfprimpub.Location = New System.Drawing.Point(128, 304)
        Me.txtfprimpub.Name = "txtfprimpub"
        Me.txtfprimpub.Size = New System.Drawing.Size(112, 20)
        Me.txtfprimpub.TabIndex = 47
        Me.txtfprimpub.Text = ""
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(24, 296)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 26)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Fecha de Primera Publicaci�n:"
        '
        'dtfprimpub
        '
        Me.dtfprimpub.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtfprimpub.Location = New System.Drawing.Point(128, 304)
        Me.dtfprimpub.Name = "dtfprimpub"
        Me.dtfprimpub.Size = New System.Drawing.Size(128, 20)
        Me.dtfprimpub.TabIndex = 45
        '
        'frmPNN
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(418, 432)
        Me.Controls.Add(Me.PnlCaptura)
        Me.Controls.Add(Me.tlbBotonera)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmPNN"
        Me.Text = "Plan Nacional de Normalizaci�n"
        Me.PnlCaptura.ResumeLayout(False)
        Me.PnlOpn1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim sEtapa As String
    Private objConexion As New clsConexionArchivo.clsConexionArchivo
    Private objUsuario As New clsUsuarios.clsUsuarios(0, "", "")
    Private ObjPlan As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Private dtPlan As DataTable
    Dim Bandera As Boolean
    Dim sDof As String
    Dim sCnn As String
    Private Sub BtnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        End
    End Sub
    Private Sub BtnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub BtnEditar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub BtnDeshacer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub BtnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub frmPNN_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sEtapa = "Nulo"
        Call Habilita(sEtapa)
        Bandera = False
        ObjPlan.Bandera = 1
        ObjPlan.ListaCombo(cboClave)
        'cboClave.DisplayMember = dtPlan.Columns(0).ColumnName
        'cboClave.ValueMember = dtPlan.Columns(0).ColumnName
        Bandera = True
    End Sub

    Private Sub Llena_Campos()

        ObjPlan.Id_Plan = cboClave.SelectedValue
        ObjPlan.Buscar(cboClave.SelectedValue)
        txtdescripcion.Text = ObjPlan.Descripcion
        txtclave.Text = cboclave.Text
        Select Case ObjPlan.Tipo
            Case 1
                RadPubDOF.Checked = True
                RadAlterno.Checked = False
            Case 2
                RadAlterno.Checked = True
                RadPubDOF.Checked = False
        End Select
        txtdof.Text = ObjPlan.Publicado_DOF
        txtf_inicio.Text = ObjPlan.F_inicio
        txtf_fin.Text = ObjPlan.F_Fin
        txtfcnn.Text = ObjPlan.F_Envio_CNN
        txtfprimpub.Text = ObjPlan.Prim_Pub


    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                sEtapa = "Agregar"
                Call Habilita(sEtapa)

            Case 1 'Editar
                sEtapa = "Editar"
                Call Habilita(sEtapa)

            Case 2 'Deshacer
                sEtapa = "Nulo"
                Call Habilita(sEtapa)
                cboclave.Visible = True
                Call Limpia_Campos(txtdof, txtf_inicio, txtf_fin, txtdescripcion, cboclave, txtclave, txtfprimpub, txtfcnn)

            Case 3 'Salvar
                If sEtapa = "Editar" Then
                    Call Actualizar()
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                Else
                    If txtf_inicio.Text = "" Or txtf_fin.Text = "" Or txtfcnn.Text = "" Or txtdof.Text = "" Or txtfprimpub.Text = "" Then
                        MsgBox("Faltan fechas por capturar")
                        Exit Sub
                    Else
                        Call Insertar()
                        sEtapa = "Nulo"
                        Call Habilita(sEtapa)
                    End If
                End If
                cboclave.Visible = True
            Case 4
                'MsgBox("Esta seguro de Borrar este Plan?", MsgBoxStyle.OKCancel, "Atenci�n")
                'If MsgBoxResult.OK Then
                MsgBox("Imposible borrar un plan")
                'End If
            Case 5
                    Me.Dispose()
        End Select
    End Sub
    Private Sub Insertar()
        If sEtapa = "Agregar" Then
            Dim ms As String
            Dim Stipo As String
            If RadPubDOF.Checked = True Then
                Stipo = "1"
            Else
                Stipo = "2"
            End If
            ObjPlan.Buscar(txtclave.Text)
            If ObjPlan.Encontrado = True Then
                MsgBox("El plan ya existe")
                Exit Sub
            Else
                ObjPlan.Insertar("1", UCase(txtclave.Text), txtdescripcion.Text, Stipo, txtdof.Text, txtf_inicio.Text, txtf_fin.Text, 0, txtfcnn.Text, txtdof.Text, txtfprimpub.Text)
            End If
        End If
    End Sub
    Private Sub Actualizar()
        Dim sTipo As String
        If sEtapa = "Editar" Then
            If RadPubDOF.Checked = True Then
                sTipo = "1"
            Else
                sTipo = "2"
            End If
            ObjPlan.Actualizar("2", cboclave.SelectedValue, txtdescripcion.Text, sTipo, txtdof.Text, txtf_inicio.Text, txtf_fin.Text, 0, txtfcnn.Text, txtdof.Text, txtfprimpub.Text)
        End If
    End Sub
    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"
                Call Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(5))
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4))
                Call Inactivos(txtdescripcion, txtdof, txtf_inicio, txtf_fin, txtfcnn, txtclave, txtfprimpub)
                Call Activos(cboclave)
                Call Oculta(dtdof, dtInicial, dtFin, dtcnn, dtfprimpub)
                Call Inactivos(RadPubDOF, RadAlterno)

            Case "Agregar"
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(txtdescripcion)
                Call Muestra(PnlCaptura)
                Call Muestra(dtdof, dtInicial, dtFin, dtcnn, dtfprimpub)
                Call Oculta(cboclave)
                Call Limpia_Campos(txtdescripcion, txtdof, txtf_inicio, txtf_fin, txtfcnn, txtfprimpub, txtclave)
                Call Activos(txtclave)
                Call Activos(RadPubDOF, RadAlterno)

            Case "Editar"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))
                Call Activos(txtdescripcion)
                Call Inactivos(cboclave, txtdof, txtf_inicio, txtf_fin, txtfcnn)
                Call Muestra(dtdof, dtInicial, dtFin, dtcnn, dtfprimpub)
                Call Activos(RadPubDOF, RadAlterno)

        End Select
    End Sub

   

    Private Sub dtdof_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If sEtapa = "Editar" Or sEtapa = "Agregar" Then
            txtdof.Text = Format(dtdof.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtinicial_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If sEtapa = "Editar" Then
            txtf_inicio.Text = Format(dtinicial.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtdof_Agregar_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtdof.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtdof.Text = Format(dtdof.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtInicial_Agregar_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtInicial.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtf_inicio.Text = Format(dtInicial.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtFin_Agregar_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtFin.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtf_fin.Text = Format(dtFin.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub radalt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxTclave_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PnlCaptura_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PnlCaptura.Paint

    End Sub

    Private Sub txtdescripcion_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ChkDof_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        sDof = "1"
    End Sub

    Private Sub chkCnn_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        sCnn = "1"
    End Sub

    


    Private Sub cboclave_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboclave.SelectedIndexChanged
        If Bandera = True Then
            Call Llena_Campos()
        End If
    End Sub

    Private Sub dtcnn_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtcnn.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtfcnn.Text = Format(dtcnn.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtfprimpub_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfprimpub.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtfprimpub.Text = Format(dtfprimpub.Value, "dd/MM/yyyy")
        End If
    End Sub
End Class
