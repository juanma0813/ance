
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_Tipos_Tema Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 12/09/2006 12:00:02 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class C_Tipos_Tema

     '''''''Declaracion de Variables Privadas
     Private dsC_Tipos_Tema AS New DataSet
    Private _Id_Tipo_Tema As Integer
     Private _Descripcion as System.String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
    Public Property Id_Tipo_Tema() As Integer
        Get
            Return _Id_Tipo_Tema
        End Get
        Set(ByVal Value As Integer)
            _Id_Tipo_Tema = Value
        End Set
    End Property

    Public Property Descripcion() As System.String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As System.String)
            _Descripcion = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD

    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Tipos_Tema")
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            da = New SqlDataAdapter("SELECT * FROM c_Tipos_Tema", cn)
            da.Fill(dt)
            cn.Close()
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As Integer) As C_Tipos_Tema
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM c_Tipos_Tema WHERE id_tipo_tema = '" & sClave & "'"
        Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da.Fill(dsC_Tipos_Tema, "C_Encontrado")
        cn.Close()
        If dsC_Tipos_Tema.Tables("C_Encontrado").Rows.Count > 0 Then
            _Id_Tipo_Tema = dsC_Tipos_Tema.Tables("C_Encontrado").Rows(0).Item("Id_Tipo_Tema")
            _Descripcion = dsC_Tipos_Tema.Tables("C_Encontrado").Rows(0).Item("Descripcion")
        Else
            _Id_Tipo_Tema = 0
            _Descripcion = ""
        End If
        dsC_Tipos_Tema.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE C_Tipos_Tema SET Id_Tipo_Tema = @Id_Tipo_Tema, Descripcion = @Descripcion, Where ( = @)"
        cmd.Parameters.Add("@Id_Tipo_Tema", SqlDbType.Int, 0, "_Id_Tipo_Tema")
        cmd.Parameters.Add("@Descripcion", SqlDbType.NVarChar, 50, "_Descripcion")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "INSERT INTO C_Tipos_Tema (Id_Tipo_Tema)Descripcion,  VALUES (@Id_Tipo_Tema)@Descripcion, "
        cmd.Parameters.Add("@Id_Tipo_Tema", SqlDbType.Int, 0, "_Id_Tipo_Tema")
        cmd.Parameters.Add("@Descripcion", SqlDbType.NVarChar, 50, "_Descripcion")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
