Public Class frmAdministracion
    Inherits System.Windows.Forms.Form
    Public objGruposAdmin As New ClsGruposAdmin.ClsGruposAdmin(2, gUsuario, gPasswordSql)
    Public dtTemp2 As DataTable
    Public id_MenuAlt As String
    Public id_menuBaja As String
    Public tarea As String
    Public id_grupoTemp As Integer = Nothing

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents cboGruposAdmin As System.Windows.Forms.ComboBox
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents grdActivos As System.Windows.Forms.DataGrid
    Friend WithEvents grdinactivos As System.Windows.Forms.DataGrid
    Friend WithEvents cmdBaja As System.Windows.Forms.Button
    Friend WithEvents cmdAlta As System.Windows.Forms.Button
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAdministracion))
        Me.cboGruposAdmin = New System.Windows.Forms.ComboBox
        Me.grdinactivos = New System.Windows.Forms.DataGrid
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.grdActivos = New System.Windows.Forms.DataGrid
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmdBaja = New System.Windows.Forms.Button
        Me.cmdAlta = New System.Windows.Forms.Button
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton
        CType(Me.grdinactivos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdActivos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cboGruposAdmin
        '
        Me.cboGruposAdmin.Location = New System.Drawing.Point(80, 16)
        Me.cboGruposAdmin.Name = "cboGruposAdmin"
        Me.cboGruposAdmin.Size = New System.Drawing.Size(296, 21)
        Me.cboGruposAdmin.TabIndex = 0
        '
        'grdinactivos
        '
        Me.grdinactivos.DataMember = ""
        Me.grdinactivos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdinactivos.Location = New System.Drawing.Point(16, 72)
        Me.grdinactivos.Name = "grdinactivos"
        Me.grdinactivos.ReadOnly = True
        Me.grdinactivos.Size = New System.Drawing.Size(200, 152)
        Me.grdinactivos.TabIndex = 2
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton6})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 232)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(496, 62)
        Me.tlbBotonera.TabIndex = 3
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.Text = "Agregar"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 2
        Me.ToolBarButton2.Text = "Guardar"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 5
        Me.ToolBarButton3.Text = "Eliminar"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 3
        Me.ToolBarButton4.Text = "Deshacer"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 1
        Me.ToolBarButton5.Text = "Editar"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 16)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Grupos:"
        '
        'grdActivos
        '
        Me.grdActivos.DataMember = ""
        Me.grdActivos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdActivos.Location = New System.Drawing.Point(280, 72)
        Me.grdActivos.Name = "grdActivos"
        Me.grdActivos.ReadOnly = True
        Me.grdActivos.Size = New System.Drawing.Size(200, 152)
        Me.grdActivos.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Menus Inactivos"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(280, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Menus Activos"
        '
        'cmdBaja
        '
        Me.cmdBaja.Image = CType(resources.GetObject("cmdBaja.Image"), System.Drawing.Image)
        Me.cmdBaja.Location = New System.Drawing.Point(224, 96)
        Me.cmdBaja.Name = "cmdBaja"
        Me.cmdBaja.Size = New System.Drawing.Size(48, 40)
        Me.cmdBaja.TabIndex = 8
        '
        'cmdAlta
        '
        Me.cmdAlta.Image = CType(resources.GetObject("cmdAlta.Image"), System.Drawing.Image)
        Me.cmdAlta.Location = New System.Drawing.Point(224, 144)
        Me.cmdAlta.Name = "cmdAlta"
        Me.cmdAlta.Size = New System.Drawing.Size(48, 40)
        Me.cmdAlta.TabIndex = 9
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 4
        Me.ToolBarButton6.Text = "Salir"
        '
        'frmAdministracion
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(496, 294)
        Me.Controls.Add(Me.cmdAlta)
        Me.Controls.Add(Me.cmdBaja)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.grdActivos)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.grdinactivos)
        Me.Controls.Add(Me.cboGruposAdmin)
        Me.Name = "frmAdministracion"
        Me.Text = "Administracion"
        CType(Me.grdinactivos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdActivos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub GuardaGrupo()
        If tarea = "agregar" Then
            objGruposAdmin.Nombre_Grupo = cboGruposAdmin.Text
            objGruposAdmin.Bandera = 1
            objGruposAdmin.Insertar()
            tarea = ""
        End If
        If tarea = "editar" Then
            objGruposAdmin.Nombre_Grupo = cboGruposAdmin.Text
            objGruposAdmin.Bandera = 11
            objGruposAdmin.Id_Grupo = id_grupoTemp
            If id_grupoTemp <> Nothing Then
                objGruposAdmin.Actualizar()
            End If
            tarea = ""
        End If
    End Sub

    Private Sub frmAdministracion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        llenaCombo()
        Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
    End Sub
    Private Sub llenaCombo()
        objGruposAdmin.Id_Sistema = 16
        objGruposAdmin.Bandera = 4
        objGruposAdmin.LlenaCombo(cboGruposAdmin)
    End Sub

    Private Sub cmdEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'nuevo
                cboGruposAdmin.Text = ""
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(4))
                Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
                tarea = "agregar"
            Case 1 'guardar
                GuardaGrupo()
                llenaCombo()
                Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(4))
                Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
            Case 2 'eliminar
                If MsgBox("�Estas seguro de eliminar este registro?", MsgBoxStyle.OKCancel, "Eliminar") = MsgBoxResult.OK Then
                    objGruposAdmin.Id_Grupo = cboGruposAdmin.SelectedValue
                    objGruposAdmin.Bandera = 3
                    objGruposAdmin.Eliminar()
                    llenaCombo()
                    Activos(tlbBotonera.Buttons.Item(0))
                    Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
                End If
            Case 3 'deshacer
                Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(4))
                Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
                llenaCombo()
                tarea = ""
            Case 4 'editar
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(4))
                Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
                id_grupoTemp = cboGruposAdmin.SelectedValue
                tarea = "editar"
            Case 5 'salir
                Me.Dispose()
        End Select

    End Sub

    Private Sub cboGruposAdmin_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboGruposAdmin.SelectedIndexChanged
        'listar en el grid
        llenagridActivos()
        compara()
        If cboGruposAdmin.Text = "Administrador" Then
            Inactivos(tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(2), cmdBaja)
        Else
            Activos(tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(2), cmdBaja)
        End If
    End Sub
    Private Sub llenagridActivos()
        dtTemp2 = Nothing
        DGReStyle(grdActivos)
        objGruposAdmin.Id_Grupo = cboGruposAdmin.SelectedValue
        objGruposAdmin.Bandera = 5
        grdActivos.DataSource = objGruposAdmin.Lista
        dtTemp2 = grdActivos.DataSource
        If dtTemp2.Rows.Count > 0 Then
            cmdBaja.Enabled = True
        Else
            cmdBaja.Enabled = False
            grdActivos.DataSource = Nothing
        End If
    End Sub

    Private Sub DGReStyle(ByVal grd As DataGrid)
        Dim dtcol As DataColumn = Nothing
        Try
            grd.TableStyles.Clear()
            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grd)

            ts1.MappingName = "ClsGruposAdmin"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Nombre_menu"
            TextCol.HeaderText = "Menu"
            TextCol.Width = 300
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "id_menu"
            TextCol1.HeaderText = "ID_Menu"
            TextCol1.Width = 0
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            ts1.PreferredRowHeight = TextCol1.TextBox.Height ' para dar el alto a la fila
            grd.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub
    Private Sub compara()
        Dim dt As New DataTable("temporal")
        Dim drow As DataRow
        Dim drow2 As DataRow
        Dim Dato1
        Dim Dato2
        Dim band As Boolean = False
        DGReStyle(grdActivos)
        objGruposAdmin.Id_Grupo = cboGruposAdmin.SelectedValue
        objGruposAdmin.Bandera = 6
        dt = objGruposAdmin.Lista
        dt.Columns.Add("Compara")
        For Each drow In dt.Rows
            Dato1 = drow.Item(1)
            For Each drow2 In dtTemp2.Rows
                Dato2 = drow2.Item(1)
                If Dato1 = Dato2 Then
                    drow.Item(3) = True
                    band = True
                    Exit For
                Else
                    drow.Item(3) = False
                    band = True
                End If
            Next
            If band = False Then
                drow.Item(3) = False
            End If
        Next
        'filtrar el dt que solo muestre los que estan en false

        Dim rows3 As DataRow()
        Dim dtNew As DataTable
        dtNew = dt.Clone()
        rows3 = dt.Select(" Compara = false")
        For Each dr As DataRow In rows3
            dtNew.ImportRow(dr)
        Next
        If dtNew.Rows.Count > 0 Then
            grdinactivos.DataSource = dtNew
        Else
            grdinactivos.DataSource = Nothing
        End If
        DGReStyle(grdinactivos)
        dt.Dispose()
        drow = Nothing
        drow2 = Nothing
        rows3 = Nothing

        If dtNew.Rows.Count > 0 Then
            cmdAlta.Enabled = True
        Else
            cmdAlta.Enabled = False
        End If
    End Sub

    Private Sub cmdAlta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAlta.Click
        objGruposAdmin.Bandera = 8
        objGruposAdmin.Id_Grupo = cboGruposAdmin.SelectedValue
        objGruposAdmin.ID_Menu = id_MenuAlt
        If id_MenuAlt <> "" Then
            objGruposAdmin.Insertar()
            llenagridActivos()
            compara()
        Else
            MsgBox("No se ha seleccionado ningun elemento para su Alta")
        End If
        id_MenuAlt = ""
    End Sub

    Private Sub grdinactivos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdinactivos.Click
        Dim index As Integer
        index = grdinactivos.CurrentRowIndex
        If Not grdinactivos.DataSource Is Nothing Then
            id_MenuAlt = grdinactivos.Item(index, 1)
        End If
    End Sub

    Private Sub grdActivos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdActivos.Click
        Dim index As Integer
        index = grdActivos.CurrentRowIndex
        If Not grdActivos.DataSource Is Nothing Then
            id_menuBaja = grdActivos.Item(index, 1)
        End If
    End Sub

    Private Sub cmdBaja_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBaja.Click
        objGruposAdmin.Bandera = 7
        objGruposAdmin.Id_Grupo = cboGruposAdmin.SelectedValue
        objGruposAdmin.ID_Menu = id_menuBaja

        If id_menuBaja <> "" Then
            objGruposAdmin.Eliminar()
            llenagridActivos()
            compara()
        Else
            MsgBox("No se ha seleccionado ningun elemento para su baja")
        End If
        id_menuBaja = ""
    End Sub
End Class
