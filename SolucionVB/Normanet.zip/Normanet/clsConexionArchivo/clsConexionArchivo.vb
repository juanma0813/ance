'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
'   NOMBRE DE LA CLASE: CLASE DE CONEXION ARCHIVO DE CONTABILIDAD
'   DESARROLLADA POR : EXTI, S.C. PARA ANCE, A.C.
'                      EMMANUEL ESPINOSA JUAREZ 
'   FECHA: 30 SEPTIEMBRE 2005
'
'   BASES RELACIONADAS: DEPENDIENDO DEL ARCHIVO .INI
'
'   TIPO: SOLO LECTURA
'
'   DESCRIPCION: REQUIERO OBLIGATORIAMENTE:
'                Identif = 0 PARA IDNETIFICAR QUE SE CONCECTA A LA BASE PRINCIPAL (NORMALIZACION)
'                Identif = 1 PARA IDENTIFICAR QUE SE CONECTA A LA BASE COMUN (dbANCE)
'                Usuario = id_Usuario QUE CREA LA CONEXION
'                Password = CLAVE DE ACCESO

'
'   FECHA MODIFICACION: 
'   MODIFICACION REALIZADA:
'
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Imports System.IO
Imports System.Windows.Forms

Public Class clsConexionArchivo
    Private cn As New SqlClient.SqlConnection
    Private sSql As String
    Private Sbase As String
    Private sUsuario As String
    Private sServer As String
    Private _Sistema As Integer

    Public Property SBaseD() As System.String
        Get
            Return Sbase
        End Get
        Set(ByVal Value As System.String)
            Sbase = Value
        End Set
    End Property
    Public Property sUsuarioC() As System.String
        Get
            Return sUsuario
        End Get
        Set(ByVal Value As System.String)
            sUsuario = Value
        End Set
    End Property
    Public Property SserverC()
        Get
            SserverC = sServer
        End Get
        Set(ByVal Value)
            sServer = Value
        End Set
    End Property
    Public Property Id_Sistema()
        Get
            Id_Sistema = _Sistema
        End Get
        Set(ByVal Value)
            _Sistema = Value
        End Set
    End Property

    Public Function Conexion(ByVal Identificador As Integer, ByVal Usuario As String, ByVal Password As String) As String

        Dim Archivo As New System.IO.StreamReader(Application.StartupPath + "\Principal.ini")
        'Dim sServer As String
        'Dim sBase As String
        Dim sUsuario As String
        Dim sPsw As String
        Dim sOpcion As String
        Dim iLinea As Integer


        If Identificador = 0 Then

            sOpcion = Archivo.ReadLine
            If sOpcion = "[PRINCIPAL]" Then
                sServer = Mid(Archivo.ReadLine, 10)
                sBase = Mid(Archivo.ReadLine, 6)
                If Usuario = "" Then
                    sUsuario = "sa"
                    'sUsuario = "admsis"
                    sSql = "Data Source =  " & sServer & " ; Initial Catalog = " & Sbase & "; User Id =sa; Password =0000;"
                Else
                    'Archivo.Close()
                    sUsuario = Usuario
                    sPsw = Password
                    sSql = "Data Source =  " & sServer & " ; Initial Catalog = " & Sbase & "; User Id =sa; Password =0000;"
                End If
            End If
        Else
            '''EEJ: 22/Sep/05
            '''Cuando el identificador = 1 genera la conexion a dbANCE
            Do While iLinea < 100
                sOpcion = Archivo.ReadLine
                If sOpcion = "[COMUN]" Then
                    sServer = Mid(Archivo.ReadLine, 10)
                    Sbase = Mid(Archivo.ReadLine, 6)
                    If Usuario = "" Then
                        sUsuario = "sa"
                        'sUsuario = "admsis"
                        sSql = "Data Source =  " & sServer & " ; Initial Catalog = " & Sbase & "; User Id =sa; Password =0000;"
                        Exit Do
                    Else
                        '   Archivo.Close()
                        sUsuario = Usuario
                        sPsw = Password
                        sSql = "Data Source =  " & sServer & " ; Initial Catalog = " & Sbase & "; User Id =sa; Password =0000:"
                        Exit Do
                    End If
                End If
                iLinea = iLinea + 1
            Loop
        End If

        ''EEJ: 08/02/06
        ''Estas lineas fueron agregadas para recuperar el id del sitema tambien por medio del archivo de texto Principal.ini
        Do While iLinea < 100
            sOpcion = Archivo.ReadLine
            If sOpcion = "[SISTEMA]" Then
                _Sistema = Mid(Archivo.ReadLine, 10)
                Exit Do
            End If
            iLinea = iLinea + 1
        Loop
        Archivo.Close()

        Return sSql
    End Function

End Class
