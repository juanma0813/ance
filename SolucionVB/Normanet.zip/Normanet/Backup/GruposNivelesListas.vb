Public Class frmGruposNivelesListas
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents cboLista As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmdAbajo As System.Windows.Forms.Button
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents CmdArriba As System.Windows.Forms.Button
    Friend WithEvents lstvGrupos As System.Windows.Forms.ListView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmGruposNivelesListas))
        Me.cboLista = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.CmdAbajo = New System.Windows.Forms.Button
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.CmdArriba = New System.Windows.Forms.Button
        Me.lstvGrupos = New System.Windows.Forms.ListView
        Me.SuspendLayout()
        '
        'cboLista
        '
        Me.cboLista.Location = New System.Drawing.Point(64, 16)
        Me.cboLista.Name = "cboLista"
        Me.cboLista.Size = New System.Drawing.Size(224, 21)
        Me.cboLista.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 16)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Lista:"
        '
        'CmdAbajo
        '
        Me.CmdAbajo.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CmdAbajo.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdAbajo.ImageIndex = 6
        Me.CmdAbajo.ImageList = Me.imgListBotonera
        Me.CmdAbajo.Location = New System.Drawing.Point(240, 144)
        Me.CmdAbajo.Name = "CmdAbajo"
        Me.CmdAbajo.Size = New System.Drawing.Size(48, 48)
        Me.CmdAbajo.TabIndex = 11
        Me.CmdAbajo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'CmdArriba
        '
        Me.CmdArriba.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CmdArriba.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdArriba.ImageIndex = 7
        Me.CmdArriba.ImageList = Me.imgListBotonera
        Me.CmdArriba.Location = New System.Drawing.Point(240, 88)
        Me.CmdArriba.Name = "CmdArriba"
        Me.CmdArriba.Size = New System.Drawing.Size(48, 48)
        Me.CmdArriba.TabIndex = 10
        Me.CmdArriba.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'lstvGrupos
        '
        Me.lstvGrupos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstvGrupos.FullRowSelect = True
        Me.lstvGrupos.GridLines = True
        Me.lstvGrupos.HideSelection = False
        Me.lstvGrupos.Location = New System.Drawing.Point(16, 48)
        Me.lstvGrupos.Name = "lstvGrupos"
        Me.lstvGrupos.Size = New System.Drawing.Size(216, 200)
        Me.lstvGrupos.TabIndex = 12
        '
        'frmGruposNivelesListas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 261)
        Me.Controls.Add(Me.lstvGrupos)
        Me.Controls.Add(Me.CmdArriba)
        Me.Controls.Add(Me.cboLista)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CmdAbajo)
        Me.Name = "frmGruposNivelesListas"
        Me.Text = "..:: Nivel de grupos ::.."
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmGruposNivelesListas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FillListas(cboLista)
        FillGruposLista(FillGrupos(cboLista.SelectedValue))
    End Sub

    Private Sub FillListas(ByVal cbo As ComboBox)
        Dim objListas As New clsListasAsistencia.AnceSystem.clssListasAsistencia
        Dim dt As DataTable
        objListas.Bandera = "s2"
        dt = objListas.Listar()

        cbo.DataSource = dt

        cbo.DisplayMember = "Descripcion"
        cbo.ValueMember = "IdListaAsistencia"
    End Sub

    Private Function FillGrupos(ByVal IdGrupoListaAsistencia As Integer) As DataTable
        Dim dt As DataTable
        Dim objGruposListas As New clsGruposListasAsistencia.AnceSystem.clssGruposListasAsistencia

        objGruposListas.IdGrupoListaAsistencia = IdGrupoListaAsistencia
        objGruposListas.Bandera = "s2"
        dt = objGruposListas.Listar
        Return dt
    End Function

    Private Sub FillGruposLista(ByVal dt As DataTable)
        Dim Item As DataRow
        Dim ItemGrupo As New ItemGrupo

        lstvGrupos.Items.Clear()

        lstvGrupos.View = View.Details
        lstvGrupos.GridLines = True
        lstvGrupos.Columns.Add("IdGrupoListaAsistencia", 0, HorizontalAlignment.Center)
        lstvGrupos.Columns.Add("Orden", 0, HorizontalAlignment.Center)
        lstvGrupos.Columns.Add("Grupos", 210, HorizontalAlignment.Left)


        For Each Item In dt.Rows
            lstvGrupos.Items.Add(New ListViewItem(New String() {Item("IdGrupoListaAsistencia"), Item("Orden"), Item("GrupoListaAsistencia")}))
        Next
    End Sub

    Private Sub cboLista_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboLista.SelectionChangeCommitted
        FillGruposLista(FillGrupos(cboLista.SelectedValue))
    End Sub


    Private Sub CmdArriba_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdArriba.Click
        If lstvGrupos.SelectedItems.Count > 0 Then
            MoverOrden(1, lstvGrupos.SelectedItems(0).Text)
        End If

    End Sub

    Private Sub CmdAbajo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdAbajo.Click
        If lstvGrupos.SelectedItems.Count > 0 Then
            MoverOrden(2, lstvGrupos.SelectedItems(0).Text)
        End If

    End Sub

    Private Sub MoverOrden(ByVal Accion, ByVal IdGrupoListaAsistencia)
        Dim objGrupoListaAsistencia As New clsGruposListasAsistencia.AnceSystem.clssGruposListasAsistencia
        objGrupoListaAsistencia.IdGrupoListaAsistencia = IdGrupoListaAsistencia
        objGrupoListaAsistencia.Bandera = IIf(Accion = 1, "u2", "u3")
        objGrupoListaAsistencia.Actualizar()

        FillGruposLista(FillGrupos(cboLista.SelectedValue))
    End Sub

End Class

Public Class ItemGrupo
    Private _IdGrupoListaAsistencia As Integer
    Private _Orden As Integer
    Private _GrupoListaAsistencia As String

    Public Property IdGrupoListaAsistencia() As Integer
        Get
            Return _IdGrupoListaAsistencia
        End Get
        Set(ByVal Value As Integer)
            _IdGrupoListaAsistencia = Value
        End Set
    End Property

    Public Property Orden() As Integer
        Get
            Return _Orden
        End Get
        Set(ByVal Value As Integer)
            _Orden = Value
        End Set
    End Property

    Public Property GrupoListaAsistencia() As String
        Get
            Return _GrupoListaAsistencia
        End Get
        Set(ByVal Value As String)
            _GrupoListaAsistencia = Value
        End Set
    End Property
End Class
