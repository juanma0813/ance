Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Web
Imports CrystalDecisions.Windows.Forms


Public Class FrmIndicadores
    Inherits System.Windows.Forms.Form

#Region " Variables"

    Dim existe, Accion As Boolean
    Dim ValEditar As Integer
    Dim sError, iEditar, sValTreeView, sFechaPk, shoraiPk, shoratPk, sReubica As String
    Dim sesion, i, solicitud, istasol, istasesion As Integer
    Dim crprin As New crprinindicadores

#End Region

#Region " Inicializaci�n de   Dll's y componentes"

    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objsalas As New Cls_Salas.Cls_Salas("EXTRA", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DTPMes As System.Windows.Forms.DateTimePicker
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdBuscar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdImprimir As System.Windows.Forms.ToolBarButton
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents CRView As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmIndicadores))
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.Label4 = New System.Windows.Forms.Label
        Me.DTPMes = New System.Windows.Forms.DateTimePicker
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdBuscar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdImprimir = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.CRView = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.SuspendLayout()
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lblcomite.Location = New System.Drawing.Point(8, 9)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(126, 16)
        Me.Lblcomite.TabIndex = 91
        Me.Lblcomite.Text = "Comite Seleccionado: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 26)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 16)
        Me.LblTreeView.TabIndex = 90
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'tvComites
        '
        Me.tvComites.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.tvComites.ImageIndex = -1
        Me.tvComites.Location = New System.Drawing.Point(8, 52)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = -1
        Me.tvComites.Size = New System.Drawing.Size(216, 508)
        Me.tvComites.TabIndex = 89
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(8, 633)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 16)
        Me.Label4.TabIndex = 137
        Me.Label4.Text = "Mes: "
        '
        'DTPMes
        '
        Me.DTPMes.CustomFormat = "MMMM"
        Me.DTPMes.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPMes.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPMes.Location = New System.Drawing.Point(72, 631)
        Me.DTPMes.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPMes.Name = "DTPMes"
        Me.DTPMes.Size = New System.Drawing.Size(152, 20)
        Me.DTPMes.TabIndex = 136
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdBuscar, Me.CmdDeshacer, Me.CmdImprimir, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 674)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(1018, 62)
        Me.tlbBotonera.TabIndex = 193
        '
        'cmdBuscar
        '
        Me.cmdBuscar.ImageIndex = 6
        Me.cmdBuscar.Text = "Buscar"
        Me.cmdBuscar.ToolTipText = "Realiza Busquedas"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 2
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.ImageIndex = 7
        Me.CmdImprimir.Text = "Imprimir"
        Me.CmdImprimir.ToolTipText = "Imprimir Consulta"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 5
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'CRView
        '
        Me.CRView.ActiveViewIndex = -1
        Me.CRView.DisplayGroupTree = False
        Me.CRView.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CRView.Location = New System.Drawing.Point(248, 17)
        Me.CRView.Name = "CRView"
        Me.CRView.ReportSource = Nothing
        Me.CRView.Size = New System.Drawing.Size(688, 644)
        Me.CRView.TabIndex = 194
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'FrmIndicadores
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1018, 736)
        Me.Controls.Add(Me.CRView)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DTPMes)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.tvComites)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmIndicadores"
        Me.Text = "Consulta de Indicadores"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

#Region " Function - Totales, Metodos y Procesos"

    Private Function Totales(ByVal ds As Indicadores, ByVal table As Integer, ByVal dr As DataRow, ByVal Proceso As String) As DataRow
        Dim tot1, tot2, tot3, tot4 As Integer
        Dim tot5, tot6 As Decimal
        Dim dr2 = dr
        Dim dr1 As DataRow
        tot1 = 0 : tot2 = 0 : tot3 = 0 : tot4 = 0 : tot5 = 0 : tot6 = 0
        Select Case table
            Case 3
                For Each dr1 In ds.Tables(3).Rows
                    tot1 = tot1 + dr1("temas")
                    tot2 = tot2 + dr1("proceso")
                    tot3 = tot3 + dr1("sin_atender")
                    tot5 = tot5 + dr1("Grado_Atencion")

                Next
                dr2("Responsable") = "Totales"
                dr2("temas") = tot1
                dr2("proceso") = tot2
                dr2("sin_atender") = tot3
                dr2("Grado_Atencion") = tot5


            Case 2
                For Each dr1 In ds.Tables(2).Rows
                    If dr1("Grupo") = Proceso Then
                        tot1 = tot1 + dr1("val1")
                        tot2 = tot2 + dr1("val2")
                        tot5 = tot5 + IIf(IsDBNull(dr1("dif")), 0, dr1("dif"))
                    End If
                Next
                dr2("Grupo") = Proceso
                dr2("Etiqueta") = "Totales"
                dr2("val1") = tot1
                dr2("val2") = tot2
                dr2("dif") = tot5
            Case 1
                For Each dr1 In ds.Tables(1).Rows
                    If dr1("Grupo") = Proceso Then
                        tot1 = tot1 + dr1("val1")
                        tot2 = tot2 + dr1("val2")
                        tot5 = tot5 + dr1("dif")
                    End If
                Next
                dr2("Grupo") = Proceso
                dr2("Etiqueta") = "Totales"
                dr2("val1") = tot1
                dr2("val2") = tot2
                dr2("dif") = tot5
            Case 0
                For Each dr1 In ds.Tables(0).Rows
                    If dr1("Grupo") = Proceso Then
                        tot1 = tot1 + dr1("Pub_ini")
                        tot2 = tot2 + dr1("Pub_fin")
                        tot3 = tot3 + dr1("Pag_ini")
                        tot4 = tot4 + dr1("Pag_fin")

                    End If
                Next
                dr2("Grupo") = Proceso
                dr2("Etiqueta") = "Totales"
                dr2("Pub_ini") = tot1
                dr2("Pub_fin") = tot2
                dr2("AvgPubFinVSIni") = tot2 - tot1 / tot1
                dr2("Pag_ini") = tot3
                dr2("Pag_fin") = tot4
                dr2("AvgPag_FinvsIni") = tot4 - tot3 / tot3

        End Select
        Return dr2
    End Function

#End Region

#Region " Sub - Indicadores, Metodos y Procesos"

    Private Sub Indicadores()
        Cursor.Current = Cursors.WaitCursor
        Try
            Dim dtind As New Indicadores
            Dim dtemp As New Indicadores.TempIndicadoresDataTable
            Dim dtemp1 As New Indicadores.indicadores2DataTable
            Dim tb1, tb2 As DataTable
            Dim aComites As Array
            Dim dr1, dr2, dravg As DataRow
            Dim idr1, idr2, ipaso, tot1, tot2, tot3, tot4 As Integer
            Dim tot5, tot6 As Decimal
            aComites = Split(sReubica, "\")
            Select Case aComites.Length
                Case 1
                    objprogtrab.ID_Comite = aComites(0)
                    objprogtrab.ID_CT = Nothing
                    objprogtrab.ID_SC = Nothing
                    objprogtrab.ID_Grupo = Nothing
                Case 2
                    objprogtrab.ID_Comite = aComites(0)
                    objprogtrab.ID_CT = aComites(1)
                    objprogtrab.ID_SC = Nothing
                    objprogtrab.ID_Grupo = Nothing
                Case 3
                    objprogtrab.ID_Comite = aComites(0)
                    objprogtrab.ID_CT = aComites(1)
                    objprogtrab.ID_SC = aComites(2)
                    objprogtrab.ID_Grupo = Nothing
                Case 4
                    objprogtrab.ID_Comite = aComites(0)
                    objprogtrab.ID_CT = aComites(1)
                    objprogtrab.ID_SC = aComites(2)
                    objprogtrab.ID_Grupo = aComites(3)
            End Select
            ''''''''''''''  ---- Proyectos ----  ''''''''''''''
            objprogtrab.Bandera = 30
            objprogtrab.F_Inicio = CStr(Now())
            objprogtrab.F_Fin = CStr(DTPMes.Value)
            objprogtrab.ID_etapa = 4
            tb1 = objprogtrab.Listar
            objprogtrab.F_Inicio = CStr(CDate(Now()).AddYears(-1))
            tb2 = objprogtrab.Listar
            dtind.Tables(0).Rows.Clear()
            dr2 = tb2.Rows(0)
            dr1 = tb1.Rows(0)
            dravg = dtind.Tables(0).NewRow()
            dravg("Grupo") = "General"
            dravg("Etiqueta") = "Proy-" & LblTreeView.Text.Replace(" - ", "-")
            dravg("Pub_ini") = dr2("proys")
            dravg("Pub_fin") = dr1("proys")
            dravg("AvgPubFinVSIni") = ((CInt(dr1("proys")) - CInt(dr2("proys"))) / IIf(CInt(dr2("proys")) = 0, 1, CInt(dr2("proys"))))
            dravg("Pag_ini") = dr2("pagis")
            dravg("Pag_fin") = dr1("pagis")
            dravg("AvgPag_FinvsIni") = ((CInt(dr1("pagis")) - CInt(dr2("pagis"))) / IIf(CInt(dr2("pagis")) = 0, 1, CInt(dr2("pagis"))))
            dtind.Tables(0).Rows.Add(dravg)

            ''''''''''''''  ---- Nomas ----  ''''''''''''''
            objprogtrab.Bandera = 31
            objprogtrab.F_Inicio = CStr(Now())
            objprogtrab.F_Fin = CStr(DTPMes.Value)
            objprogtrab.ID_etapa = 4
            tb1 = objprogtrab.Listar
            objprogtrab.F_Inicio = CStr(CDate(Now()).AddYears(-1))
            tb2 = objprogtrab.Listar
            dr2 = tb2.Rows(0)
            dr1 = tb1.Rows(0)
            dravg = dtind.Tables(0).NewRow()
            dravg("Grupo") = "General"
            dravg("Etiqueta") = "NMX-" & LblTreeView.Text.Replace(" - ", "-")
            dravg("Pub_ini") = dr2("proys")
            dravg("Pub_fin") = dr1("proys")
            dravg("AvgPubFinVSIni") = ((CInt(dr1("proys")) - CInt(dr2("proys"))) / IIf(CInt(dr2("proys")) = 0, 1, CInt(dr2("proys"))))
            dravg("Pag_ini") = dr2("pagis")
            dravg("Pag_fin") = dr1("pagis")
            dravg("AvgPag_FinvsIni") = ((CInt(dr1("pagis")) - CInt(dr2("pagis"))) / IIf(CInt(dr2("pagis")) = 0, 1, CInt(dr2("pagis"))))
            dtind.Tables(0).Rows.Add(dravg)

            dravg = dtind.Tables(0).NewRow()
            dravg = Totales(dtind, 0, dravg, "General")
            dtind.Tables(0).Rows.Add(dravg)


            ''''''''''''''  ---- Nomas x Usuario ----  ''''''''''''''
            objprogtrab.Bandera = 32
            objprogtrab.F_Inicio = CStr(Now())
            objprogtrab.F_Fin = CStr(DTPMes.Value)
            objprogtrab.ID_etapa = 5
            tb1 = objprogtrab.Listar
            objprogtrab.F_Inicio = CStr(CDate(Now()).AddYears(-1))
            tb2 = objprogtrab.Listar
            idr1 = 0 : idr2 = 0
            For Each dr2 In tb2.Rows
                ipaso = 0
                For Each dr1 In tb1.Rows
                    If dr2("Resp") = dr1("Resp") Then
                        dravg = dtind.Tables(0).NewRow()
                        dravg("Grupo") = "Normas Mexicanas"
                        dravg("Etiqueta") = dr2("Resp")
                        dravg("Pub_ini") = dr2("proys")
                        dravg("Pub_fin") = dr1("proys")
                        dravg("AvgPubFinVSIni") = ((CInt(dr1("proys")) - CInt(dr2("proys"))) / IIf(CInt(dr2("proys")) = 0, 1, CInt(dr2("proys"))))
                        dravg("Pag_ini") = dr2("pagis")
                        dravg("Pag_fin") = dr1("pagis")
                        dravg("AvgPag_FinvsIni") = ((CInt(dr1("pagis")) - CInt(dr2("pagis"))) / IIf(CInt(dr2("pagis")) = 0, 1, CInt(dr2("pagis"))))
                        dtind.Tables(0).Rows.Add(dravg)
                        ipaso = 1
                        idr1 = idr1 + 1
                        tot1 = 1
                        Exit For
                    End If
                Next
                If ipaso = 0 Then
                    dravg = dtind.Tables(0).NewRow()
                    dravg("Grupo") = "Normas Mexicanas"
                    dravg("Etiqueta") = dr2("Resp")
                    dravg("Pub_ini") = dr2("proys")
                    dravg("Pub_fin") = 0
                    dravg("AvgPubFinVSIni") = ((CInt(dr2("proys")) * -1))
                    dravg("Pag_ini") = dr2("pagis")
                    dravg("Pag_fin") = 0
                    dravg("AvgPag_FinvsIni") = ((CInt(dr2("pagis")) * -1))
                    dtind.Tables(0).Rows.Add(dravg)
                    ipaso = 1
                    idr2 = idr2 + 1
                    tot1 = 1
                End If
            Next
            dtemp.Rows.Clear()
            For Each dr1 In tb1.Rows
                ipaso = 0
                For Each dr2 In dtind.Tables(0).Rows
                    If dr2("Grupo") = "Normas Mexicanas" Then
                        If dr2("Etiqueta") <> dr1("Resp") Then
                            dravg = dtemp.NewRow()
                            dravg("Grupo") = "Normas Mexicanas"
                            dravg("Etiqueta") = dr1("Resp")
                            dravg("Pub_ini") = 0
                            dravg("Pub_fin") = dr1("proys")
                            dravg("AvgPubFinVSIni") = ((CInt(dr1("proys")) * 1))
                            dravg("Pag_ini") = 0
                            dravg("Pag_fin") = dr1("pagis")
                            dravg("AvgPag_FinvsIni") = ((CInt(dr1("pagis")) * 1))
                            dtemp.AddTempIndicadoresRow(dravg)
                            ipaso = 1
                            idr2 = idr2 + 1
                            Exit For
                        End If
                    End If
                Next
            Next
            tb1 = dtind.Tables(0)
            For Each dr2 In dtemp
                ipaso = 0
                For Each dr1 In tb1.Rows
                    If dr1("Grupo") = dr2("Grupo") And dr1("Etiqueta") = dr2("Etiqueta") Then
                        ipaso = 1
                        Exit For
                    End If
                Next
                If ipaso = 0 Then
                    dravg = dtind.Tables(0).NewRow()
                    dravg("Grupo") = dr2("Grupo")
                    dravg("Etiqueta") = dr2("Etiqueta")
                    dravg("Pub_ini") = dr2("Pub_ini")
                    dravg("Pub_fin") = dr2("Pub_fin")
                    dravg("AvgPubFinVSIni") = dr2("AvgPubFinVSIni")
                    dravg("Pag_ini") = dr2("Pag_ini")
                    dravg("Pag_fin") = dr2("Pag_fin")
                    dravg("AvgPag_FinvsIni") = dr2("AvgPag_FinvsIni")
                    dtind.Tables(0).Rows.Add(dravg)
                    tot1 = 1
                End If
            Next

            If tot1 = 1 Then
                dravg = dtind.Tables(0).NewRow()
                dravg = Totales(dtind, 0, dravg, "Normas Mexicanas")
                dtind.Tables(0).Rows.Add(dravg)
            End If

            ''''''''''''''  ---- Proyectos x Usuario ----  ''''''''''''''
            objprogtrab.Bandera = 33
            objprogtrab.F_Inicio = CStr(Now())
            objprogtrab.F_Fin = CStr(DTPMes.Value)
            objprogtrab.ID_etapa = 4
            tb1 = objprogtrab.Listar
            objprogtrab.F_Inicio = CStr(CDate(Now()).AddYears(-1))
            tb2 = objprogtrab.Listar
            idr1 = 0 : idr2 = 0
            For Each dr2 In tb2.Rows
                ipaso = 0
                For Each dr1 In tb1.Rows
                    If dr2("Resp") = dr1("Resp") Then
                        dravg = dtind.Tables(0).NewRow()
                        dravg("Grupo") = "Proyectos de Normas Mexicanas"
                        dravg("Etiqueta") = dr2("Resp")
                        dravg("Pub_ini") = dr2("proys")
                        dravg("Pub_fin") = dr1("proys")
                        dravg("AvgPubFinVSIni") = (CInt(dr1("proys")) - CInt(dr2("proys"))) / IIf(CInt(dr2("proys")) = 0, 1, CInt(dr2("proys")))
                        dravg("Pag_ini") = dr2("pagis")
                        dravg("Pag_fin") = dr1("pagis")
                        dravg("AvgPag_FinvsIni") = (CInt(dr1("pagis") - CInt(dr2("pagis"))) / IIf(CInt(dr2("pagis")) = 0, 1, CInt(dr2("pagis"))))
                        dtind.Tables(0).Rows.Add(dravg)
                        ipaso = 1
                        idr1 = idr1 + 1
                        tot2 = 1
                        Exit For
                    End If
                Next
                If ipaso = 0 Then
                    dravg = dtind.Tables(0).NewRow()
                    dravg("Grupo") = "Proyectos de Normas Mexicanas"
                    dravg("Etiqueta") = dr2("Resp")
                    dravg("Pub_ini") = dr2("proys")
                    dravg("Pub_fin") = 0
                    dravg("AvgPubFinVSIni") = ((CInt(dr2("proys")) * -1))
                    dravg("Pag_ini") = dr2("pagis")
                    dravg("Pag_fin") = 0
                    dravg("AvgPag_FinvsIni") = ((CInt(dr2("pagis")) * -1))
                    dtind.Tables(0).Rows.Add(dravg)
                    ipaso = 1
                    idr2 = idr2 + 1
                    tot2 = 1
                End If
            Next
            dtemp.Rows.Clear()
            idr1 = 1
            For Each dr1 In tb1.Rows
                ipaso = 0
                istasesion = 0
                For Each dr2 In dtind.Tables(0).Rows
                    If dr2("Grupo") = "Proyectos de Normas Mexicanas" Then
                        If dr2("Etiqueta") <> dr1("Resp") Then
                            dravg = dtemp.NewRow()
                            dravg("Grupo") = "Proyectos de Normas Mexicanas"
                            dravg("Etiqueta") = dr1("Resp")
                            dravg("Pub_ini") = 0
                            dravg("Pub_fin") = dr1("proys")
                            dravg("AvgPubFinVSIni") = ((CInt(dr1("proys")) * 1))
                            dravg("Pag_ini") = 0
                            dravg("Pag_fin") = dr1("pagis")
                            dravg("AvgPag_FinvsIni") = ((CInt(dr1("pagis")) * 1))
                            dtemp.AddTempIndicadoresRow(dravg)
                            ipaso = 1
                            istasesion = 1
                            idr1 = idr1 + 1
                            Exit For
                        End If
                    End If
                Next
                If istasesion = 0 Then
                    dravg = dtemp.NewRow()
                    dravg("Grupo") = "Proyectos de Normas Mexicanas"
                    dravg("Etiqueta") = dr1("Resp")
                    dravg("Pub_ini") = 0
                    dravg("Pub_fin") = dr1("proys")
                    dravg("AvgPubFinVSIni") = ((CInt(dr1("proys")) * 1))
                    dravg("Pag_ini") = 0
                    dravg("Pag_fin") = dr1("pagis")
                    dravg("AvgPag_FinvsIni") = ((CInt(dr1("pagis")) * 1))
                    dtemp.AddTempIndicadoresRow(dravg)
                End If
            Next
            tb1 = dtind.Tables(0)
            For Each dr2 In dtemp
                ipaso = 0
                For Each dr1 In tb1.Rows
                    If dr1("Grupo") = dr2("Grupo") And dr1("Etiqueta") <> dr2("Etiqueta") Then
                        ipaso = 1
                        Exit For
                    End If
                Next
                If ipaso = 0 Then
                    dravg = dtind.Tables(0).NewRow()
                    dravg("Grupo") = dr2("Grupo")
                    dravg("Etiqueta") = dr2("Etiqueta")
                    dravg("Pub_ini") = dr2("Pub_ini")
                    dravg("Pub_fin") = dr2("Pub_fin")
                    dravg("AvgPubFinVSIni") = dr2("AvgPubFinVSIni")
                    dravg("Pag_ini") = dr2("Pag_ini")
                    dravg("Pag_fin") = dr2("Pag_fin")
                    dravg("AvgPag_FinvsIni") = dr2("AvgPag_FinvsIni")
                    dtind.Tables(0).Rows.Add(dravg)
                    tot2 = 1
                End If
            Next

            If tot2 = 1 Then
                dravg = dtind.Tables(0).NewRow()
                dravg = Totales(dtind, 0, dravg, "Proyectos de Normas Mexicanas")
                dtind.Tables(0).Rows.Add(dravg)
            End If

            ''''''''''''''  ----  Normas ANCE  ----  ''''''''''''''

            objprogtrab.Bandera = 34
            objprogtrab.F_Inicio = CStr(Now())
            objprogtrab.F_Fin = CStr(DTPMes.Value)
            tb1 = objprogtrab.Listar
            objprogtrab.F_Inicio = CStr(CDate(Now()).AddYears(-1))
            tb2 = objprogtrab.Listar
            idr1 = 0 : idr2 = 0

            For Each dr2 In tb2.Rows
                ipaso = 0
                For Each dr1 In tb1.Rows
                    If dr2("Etiqueta") = dr1("Etiqueta") Then
                        dravg = dtind.Tables(1).NewRow()
                        dravg("Grupo") = "Normas-ANCE"
                        dravg("Etiqueta") = dr2("Etiqueta")
                        dravg("val1") = dr2("proys")
                        dravg("val2") = dr1("proys")
                        dravg("dif") = (CInt(dr1("proys")) - CInt(dr2("proys"))) / IIf(CInt(dr2("proys")) = 0, 1, CInt(dr2("proys")))
                        dtind.Tables(1).Rows.Add(dravg)
                        ipaso = 1
                        idr1 = idr1 + 1
                        tot3 = 1
                        Exit For
                    End If
                Next
                If ipaso = 0 Then
                    dravg = dtind.Tables(1).NewRow()
                    dravg("Grupo") = "Normas-ANCE"
                    dravg("Etiqueta") = dr2("Etiqueta")
                    dravg("val1") = dr2("proys")
                    dravg("val2") = 0
                    dravg("dif") = ((CInt(dr2("proys")) * -1))
                    dtind.Tables(1).Rows.Add(dravg)
                    ipaso = 1
                    idr2 = idr2 + 1
                    tot3 = 1
                End If
            Next
            dtemp1.Rows.Clear()
            idr1 = 1
            For Each dr1 In tb1.Rows
                ipaso = 0
                istasesion = 0
                For Each dr2 In dtind.Tables(0).Rows
                    If dr2("Grupo") = "Normas-ANCE" Then
                        If dr2("Etiqueta") <> dr1("Etiqueta") Then
                            dravg = dtemp1.NewRow()
                            dravg("Grupo") = "Normas-ANCE"
                            dravg("Etiqueta") = dr1("Etiqueta")
                            dravg("val1") = 0
                            dravg("val2") = dr1("proys")
                            dravg("dif") = ((CInt(dr1("proys")) * 1))
                            dtemp1.Addindicadores2Row(dravg)
                            ipaso = 1
                            istasesion = 1
                            idr1 = idr1 + 1
                            Exit For
                        End If
                    End If
                Next
                If istasesion = 0 Then
                    dravg = dtemp1.NewRow()
                    dravg("Grupo") = "Normas-ANCE"
                    dravg("Etiqueta") = dr1("Etiqueta")
                    dravg("val1") = 0
                    dravg("val2") = dr1("proys")
                    dravg("dif") = ((CInt(dr1("proys")) * 1))
                    dtemp1.Addindicadores2Row(dravg)
                End If
            Next
            tb1 = dtind.Tables(1)
            For Each dr2 In dtemp
                ipaso = 0
                For Each dr1 In tb1.Rows
                    If dr1("Grupo") = dr2("Grupo") And dr1("Etiqueta") <> dr2("Etiqueta") Then
                        ipaso = 1
                        Exit For
                    End If
                Next
                If ipaso = 1 Then
                    dravg = dtind.Tables(1).NewRow()
                    dravg("Grupo") = dr2("Grupo")
                    dravg("Etiqueta") = dr2("Etiqueta")
                    dravg("val1") = dr2("val1")
                    dravg("val2") = dr2("val2")
                    dravg("dif") = dr2("dif")
                    dtind.Tables(1).Rows.Add(dravg)
                    tot3 = 1
                End If
            Next

            If tot3 = 1 Then
                dravg = dtind.Tables(1).NewRow()
                dravg = Totales(dtind, 1, dravg, "Normas-ANCE")
                dtind.Tables(1).Rows.Add(dravg)
            End If

            ''''''''''''''  ----  Sesiones   ----  ''''''''''''''


            objprogtrab.Bandera = 35
            objprogtrab.F_Inicio = CStr(Now())
            objprogtrab.F_Fin = CStr(DTPMes.Value)
            tb1 = objprogtrab.Listar
            tb2 = dtind.Tables(0)
            Dim dr3, dr4, drind As DataRow
            For Each dr2 In tb2.Rows
                If dr2(0) = "Normas Mexicanas" And dr2(1) <> "Totales" Then
                    drind = dtind.Tables(2).NewRow
                    drind(0) = "Sesiones"
                    drind(1) = dr2(1)
                    drind(2) = 0
                    drind(3) = dr2(6)
                    dtind.Tables(2).Rows.Add(drind)
                    tot4 = 1
                End If
            Next
            For Each dr2 In tb2.Rows
                ipaso = 0
                If dr2(0) = "Proyectos de Normas Mexicanas" And dr2(1) <> "Totales" Then
                    For Each dr1 In dtind.Tables(2).Rows
                        If dr1(1) = dr2(1) Then
                            dr1(3) = dr2(6) + dr1(3)
                            ipaso = 1
                            Exit For
                        End If
                    Next
                    If ipaso = 0 Then
                        drind = dtind.Tables(2).NewRow
                        drind(0) = "Sesiones"
                        drind(1) = dr2(1)
                        dtind.Tables(2).Rows.Add(drind)
                        tot4 = 1
                    End If
                End If
            Next
            For Each dr1 In dtind.Tables(2).Rows
                For Each dr3 In tb1.Rows
                    If dr3(0) = dr1(1) Then
                        dr1(2) = dr3(1)
                        Exit For
                    End If
                Next
                If dr1(2) = 0 Then
                    dr1(4) = 0
                Else
                    dr1(4) = dr1(3) / dr1(2)
                End If
            Next
            If tot4 = 1 Then
                dravg = dtind.Tables(2).NewRow()
                dravg = Totales(dtind, 2, dravg, "Sesiones")
                dtind.Tables(2).Rows.Add(dravg)
            End If

            ''''''''''''''  ----  Programas   ----  ''''''''''''''

            objprogtrab.Bandera = 36
            objprogtrab.F_Inicio = CStr(Now())
            tb1 = objprogtrab.Listar
            For Each dr1 In tb1.Rows
                dravg = dtind.Tables(3).NewRow()
                dravg(0) = dr1(0)
                dravg(1) = dr1(1)
                dravg(2) = dr1(2)
                dravg(3) = dr1(3)
                dravg(4) = dr1(4)
                dtind.Tables(3).Rows.Add(dravg)
                tot5 = 1
            Next

            If tot5 = 1 Then
                dravg = dtind.Tables(3).NewRow()
                dravg = Totales(dtind, 3, dravg, "")
                dtind.Tables(3).Rows.Add(dravg)
            End If

            crprin.SetDataSource(dtind)
            crprin.OpenSubreport("CRIndicadores").SetDataSource(dtind.Tables(0))
            crprin.OpenSubreport("CrIndicadores2").SetDataSource(dtind.Tables(1))
            crprin.OpenSubreport("CrIndicadores3").SetDataSource(dtind.Tables(2))
            crprin.OpenSubreport("CrIndicadores4").SetDataSource(dtind.Tables(3))
            crprin.OpenSubreport("CRIndicadores").DataDefinition.FormulaFields("etiqanoant").Text = "'" + CStr(Format(CDate(Now()).AddYears(-1), "yyyy")) + "'"
            crprin.OpenSubreport("CrIndicadores2").DataDefinition.FormulaFields("etiqanoant").Text = "'" + CStr(Format(CDate(Now()).AddYears(-1), "yyyy")) + "'"
            crprin.OpenSubreport("CRIndicadores").DataDefinition.FormulaFields("etiqano").Text = "'" + CStr(Format(CDate(Now()), "yyyy")) + "'"
            crprin.OpenSubreport("CRIndicadores").DataDefinition.FormulaFields("etiqmes").Text = "'" + DTPMes.Text + "'"
            crprin.OpenSubreport("CrIndicadores2").DataDefinition.FormulaFields("etiqano").Text = "'" + CStr(Format(CDate(Now()), "yyyy")) + "'"
            crprin.OpenSubreport("CrIndicadores4").DataDefinition.FormulaFields("@etiqano").Text = "'" + CStr(Format(CDate(Now()), "yyyy")) + "'"
            crprin.OpenSubreport("CrIndicadores2").DataDefinition.FormulaFields("etiqmes").Text = "'" + DTPMes.Text + "'"
            crprin.OpenSubreport("CrIndicadores3").DataDefinition.FormulaFields("etiqmes").Text = "'" + DTPMes.Text + "'"
            crprin.DataDefinition.FormulaFields("etiqano").Text = "'" + CStr(Format(CDate(Now()), "yyyy")) + "'"
            crprin.DataDefinition.FormulaFields("etiqmes").Text = "'" + DTPMes.Text + "'"
            crprin.Refresh()
            CRView.ReportSource = crprin

            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar crear consulta" + Chr(13) + Chr(13) + ex.Message + Chr(13) + Chr(13) + ex.StackTrace, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#End Region

#Region " Forms - FrmIndicadores_Load, Metodos y Procesos"

    Private Sub FrmIndicadores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CRView.Width = Me.Width - (tvComites.Width + 50)
        CRView.Height = Me.Height - (115)
        DTPMes.CustomFormat = "MMMM"
        DTPMes.Format = DateTimePickerFormat.Custom
        DTPMes.ShowUpDown = True
        DTPMes.MaxDate = "01/12/2000"
        DTPMes.MinDate = "01/01/2000"
        Call lleNA_ComiteTreeView()
    End Sub

#End Region

#Region " Tree View - ComiteTreeView, Metodos y Procesos"

#Region "  ComiteTreeView - lleNA_ComiteTreeView, Metodos y Procesos"

    Private Sub lleNA_ComiteTreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        Comite = tvComites.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        tvComites.EndUpdate()

        tvComites.ResetText()

        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  ComiteTreeView -  tvComites_AfterSelect(Object,TreeViewEventArgs) , Control TreeView"

    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect

        Cursor.Current = Cursors.WaitCursor
        Dim valor_nodo, valor As String
        Dim ivalor As Integer
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione el comite" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")
        With tlbBotonera
            Inactivos(.Buttons(0), .Buttons(1), .Buttons(2))
            Select Case UCase(Mid(lblarray(lblarray.Length - 1), 1, 2))
                Case "CT"
                    sReubica = lblarray(0) + " \ " + lblarray(1)
                    Activos(.Buttons(0))
                Case "SC"
                    Select Case lblarray.Length
                        Case 2
                            sReubica = lblarray(0) + "\NA\" + lblarray(1)
                        Case 3
                            sReubica = lblarray(0) + "\" + lblarray(1) + "\" + lblarray(2)
                    End Select
                    Activos(.Buttons(0))
                Case "GT"
                    Select Case lblarray.Length
                        Case 2
                            sReubica = lblarray(0) + "\NA\NA\" + lblarray(1)
                        Case 3
                            If UCase(Mid(lblarray(1), 1, 2)) = "CT" Then
                                sReubica = lblarray(0) + "\" + lblarray(1) + "\NA\" + lblarray(2)
                            ElseIf UCase(Mid(lblarray(1), 1, 2)) = "SC" Then
                                sReubica = lblarray(0) + "\NA\" + lblarray(1) + "\" + lblarray(2)
                            End If
                        Case 4
                            sReubica = lblarray(0) + "\" + lblarray(1) + "\" + lblarray(2) + "\" + lblarray(3)
                    End Select
                    Activos(.Buttons(0))
                Case Else
                    If lblarray.Length = 1 Then
                        sReubica = lblarray(0)
                        Activos(.Buttons(0))
                    End If
            End Select
            '  End If
        End With
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

#Region " ToolBar  - tlbBotonera_ButtonClick, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Buscar
                Call Indicadores()
            Case 4
                Me.Dispose()
        End Select
    End Sub

#End Region

End Class
