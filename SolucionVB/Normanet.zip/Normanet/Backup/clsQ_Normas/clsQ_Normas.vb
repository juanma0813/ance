Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class clsQ_Normas

    '''''''Declaracion de Variables Privadas
    Private dsC_Normas As New DataSet
    Private cn As New SqlConnection

    Private _Clasificacion As String
    Private _Cancelada As String

    Private _ID_Comite As String '
    Private _ID_CT As String
    Private _ID_SC As String
    Private _ID_Grupo As String
    Private _F_Decla_Vigencia As String
    Private _Norma_Cancela As String
    Private _TIE As String
    Private _TII As String
    Private _No_Paginas As Integer  'Int32
    Private _Objetivo As String
    Private _Campo_Aplicacion As String
    Private _Concor_Norm_Intern As String
    Private _Bilbiografia As String

    Private _Resp_Publicacion As String

    Private _F_Ent_Vigor As String
    Private _F_Ini_Desarrollo As String 'Date
    Private _F_Apro_CT_GT As String 'Date
    Private _F_Apro_CONANCE As String 'Date
    Private _F_Resol_Comentarios As String 'Date
    Private _F_Env_DGN As String

    '_F_Ini_Desarrollo   _F_Apro_CONANCE _F_Apro_CT_GT _F_Apro_Coment_Pub = IIf(IsDBNull(dr("F_Publicacion_ComentarioPublico")) = True, Nothing, dr("F_Publicacion_ComentarioPublico"))


    Private _F_Apro_Coment_Pub As String 'Date
    Private _F_Revi_Quinquenal As String 'Date
    Private _F_Avi_Cancelacion As String 'Date
    Private _F_Decl_Vige_Can As String 'Date
    Private _F_Noti_Ratificacion As String 'Date

    Private _F_Publi_Cancelacion As String 'Date
    Private _F_Limite As String 'Date
    Private _F_Noti_Modificacion As String 'Date

    'Tabla C_Normas_Detalle
    Private _ID_Detalle As Integer 'int32
    Private _ID_Tipo_Norma As Integer

    Private _Clasificacion_Norma As String
    Private _Titulo_Norma As String


    Private sSql As String

    'Private objConexion As New clsConexionArchivo.clsConexionArchivo
    Private objConexion As New clsConexionArchivo.clsConexionArchivo
    Private _Bandera As Integer
    'Private _Inactivo As Boolean
    Private _Inactivo As Integer
    Private _Tipo_Norma As Integer
    Private _Tipo_Norma_Dos As Integer
    Dim cmd As New SqlCommand

    Private _sStatus As String

    Private _Id_Plan As String
    Private _Id_Tema As String
    Private _Id_tipo_doc As Integer
    Private _Documento As String
    Private _Activo As Boolean
    Private _Id_comentario As Integer
    Private _Encontrado As Boolean

    Private _Observaciones As String
    Private _sqlNormas As String
    Private _sqlNormasAdoptadas As String
    Private _sqlProyecto As String
    Private _sqlAnteproyecto As String
    Private _sqlDT As String



    '''''''Declaracion de Propiedades publicas
    '''Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
    '''    cn.ConnectionString = objConexion.Conexion(Identificador, Usuario, Password)
    '''    'cn.ConnectionString = objConexion.Conexion(0, "admsis", "admynys")
    ''Public Sub New(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
    ''    objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
    ''    cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
    ''End Sub

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property Inactivo() As Integer
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Integer)
            _Inactivo = Value
        End Set
    End Property

    Public Property Tipo_Norma() As Integer
        Get
            Return _Tipo_Norma
        End Get
        Set(ByVal Value As Integer)
            _Tipo_Norma = Value
        End Set
    End Property


    Public Property Clasificacion() As String
        Get
            Return _Clasificacion
        End Get
        Set(ByVal Value As String)
            _Clasificacion = Value
        End Set
    End Property

    Public Property Cancelada() As String
        Get
            Return _Cancelada
        End Get
        Set(ByVal Value As String)
            _Cancelada = Value
        End Set
    End Property



    Public Property ID_Comite() As String
        Get
            Return _ID_Comite
        End Get
        Set(ByVal Value As String)
            _ID_Comite = Value
        End Set
    End Property

    Public Property ID_CT() As String
        Get
            Return _ID_CT
        End Get
        Set(ByVal Value As String)
            _ID_CT = Value
        End Set
    End Property

    Public Property ID_SC() As String
        Get
            Return _ID_SC
        End Get
        Set(ByVal Value As String)
            _ID_SC = Value
        End Set
    End Property

    Public Property ID_Grupo() As String
        Get
            Return _ID_Grupo
        End Get
        Set(ByVal Value As String)
            _ID_Grupo = Value
        End Set
    End Property

    Public Property F_Decla_Vigencia() As String
        Get
            Return _F_Decla_Vigencia
        End Get
        Set(ByVal Value As String)
            _F_Decla_Vigencia = Value
        End Set
    End Property

    Public Property Norma_Cancela() As String
        Get
            Return _Norma_Cancela
        End Get
        Set(ByVal Value As String)
            _Norma_Cancela = Value
        End Set
    End Property

    Public Property TIE() As String
        Get
            Return _TIE
        End Get
        Set(ByVal Value As String)
            _TIE = Value
        End Set
    End Property

    Public Property TII() As String
        Get
            Return _TII
        End Get
        Set(ByVal Value As String)
            _TII = Value
        End Set
    End Property

    Public Property No_Paginas() As String
        Get
            Return _No_Paginas
        End Get
        Set(ByVal Value As String)
            _No_Paginas = Value
        End Set
    End Property

    Public Property Objetivo() As String
        Get
            Return _Objetivo
        End Get
        Set(ByVal Value As String)
            _Objetivo = Value
        End Set
    End Property

    Public Property Campo_Aplicacion() As String
        Get
            Return _Campo_Aplicacion
        End Get
        Set(ByVal Value As String)
            _Campo_Aplicacion = Value
        End Set
    End Property

    Public Property Concor_Norm_Intern() As String
        Get
            Return _Concor_Norm_Intern
        End Get
        Set(ByVal Value As String)
            _Concor_Norm_Intern = Value
        End Set
    End Property

    Public Property Bilbiografia() As String
        Get
            Return _Bilbiografia
        End Get
        Set(ByVal Value As String)
            _Bilbiografia = Value
        End Set
    End Property

    Public Property Resp_Publicacion() As String
        Get
            Return _Resp_Publicacion
        End Get
        Set(ByVal Value As String)
            _Resp_Publicacion = Value
        End Set
    End Property

    Public Property F_Ent_Vigor() As String
        Get
            Return _F_Ent_Vigor
        End Get
        Set(ByVal Value As String)
            _F_Ent_Vigor = Value
        End Set
    End Property

    Public Property F_Ini_Desarrollo() As String
        Get
            Return _F_Ini_Desarrollo
        End Get
        Set(ByVal Value As String)
            _F_Ini_Desarrollo = Value
        End Set
    End Property

    Public Property F_Apro_CT_GT() As String
        Get
            Return _F_Apro_CT_GT
        End Get
        Set(ByVal Value As String)
            _F_Apro_CT_GT = Value
        End Set
    End Property

    Public Property F_Apro_CONANCE() As String
        Get
            Return _F_Apro_CONANCE
        End Get
        Set(ByVal Value As String)
            _F_Apro_CONANCE = Value
        End Set
    End Property


    Public Property F_Resol_Comentarios() As String
        Get
            Return _F_Resol_Comentarios
        End Get
        Set(ByVal Value As String)
            _F_Resol_Comentarios = Value
        End Set
    End Property

    Public Property F_Env_DGN() As String
        Get
            Return _F_Env_DGN
        End Get
        Set(ByVal Value As String)
            _F_Env_DGN = Value
        End Set
    End Property



    Public Property F_Apro_Coment_Pub() As String
        Get
            Return _F_Apro_Coment_Pub
        End Get
        Set(ByVal Value As String)
            _F_Apro_Coment_Pub = Value
        End Set
    End Property

    Public Property F_Revi_Quinquenal() As String
        Get
            Return _F_Revi_Quinquenal
        End Get
        Set(ByVal Value As String)
            _F_Revi_Quinquenal = Value
        End Set
    End Property

    Public Property F_Avi_Cancelacion() As String
        Get
            Return _F_Avi_Cancelacion
        End Get
        Set(ByVal Value As String)
            _F_Avi_Cancelacion = Value
        End Set
    End Property

    Public Property F_Decl_Vige_Can() As String
        Get
            Return _F_Decl_Vige_Can
        End Get
        Set(ByVal Value As String)
            _F_Decl_Vige_Can = Value
        End Set
    End Property

    Public Property F_Noti_Ratificacion() As String
        Get
            Return _F_Noti_Ratificacion
        End Get
        Set(ByVal Value As String)
            _F_Noti_Ratificacion = Value
        End Set
    End Property


    Public Property F_Publi_Cancelacion() As String
        Get
            Return _F_Publi_Cancelacion
        End Get
        Set(ByVal Value As String)
            _F_Publi_Cancelacion = Value
        End Set
    End Property

    Public Property F_Limite() As String
        Get
            Return _F_Limite
        End Get
        Set(ByVal Value As String)
            _F_Limite = Value
        End Set
    End Property

    Public Property F_Noti_Modificacion() As String
        Get
            Return _F_Noti_Modificacion
        End Get
        Set(ByVal Value As String)
            _F_Noti_Modificacion = Value
        End Set
    End Property


    Public Property ID_Detalle() As Integer
        Get
            Return _ID_Detalle
        End Get
        Set(ByVal Value As Integer)
            _ID_Detalle = Value
        End Set
    End Property

    Public Property ID_Tipo_Norma() As Integer
        Get
            Return _ID_Tipo_Norma
        End Get
        Set(ByVal Value As Integer)
            _ID_Tipo_Norma = Value
        End Set
    End Property

    Public Property Tipo_Norma_Dos() As Integer
        Get
            Return _Tipo_Norma_Dos
        End Get
        Set(ByVal Value As Integer)
            _Tipo_Norma_Dos = Value
        End Set
    End Property


    Public Property Clasificacion_Norma() As String
        Get
            Return _Clasificacion_Norma
        End Get
        Set(ByVal Value As String)
            _Clasificacion_Norma = Value
        End Set
    End Property


    Public Property Titulo_Norma() As String
        Get
            Return _Titulo_Norma
        End Get
        Set(ByVal Value As String)
            _Titulo_Norma = Value
        End Set
    End Property

    Public Property sStatus()
        Get
            Return _sStatus
        End Get
        Set(ByVal Value)
            _Sstatus = Value
        End Set
    End Property


    Public Property Id_Plan()
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value)
            _Id_Plan = Value
        End Set
    End Property

    Public Property Id_Tema()
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Id_tipo_doc()
        Get
            Return _Id_tipo_doc
        End Get
        Set(ByVal Value)
            _Id_tipo_doc = Value
        End Set
    End Property

    Public Property Documento()
        Get
            Return _Documento
        End Get
        Set(ByVal Value)
            _Documento = Value
        End Set
    End Property

    Public Property Activo()
        Get
            Return _Activo
        End Get
        Set(ByVal Value)
            _Activo = Value
        End Set
    End Property

    Public Property Id_Comentario()
        Get
            Return _Id_Comentario
        End Get
        Set(ByVal Value)
            _Id_Comentario = Value
        End Set
    End Property

    Public Property Observaciones() As String
        Get
            Return _Observaciones
        End Get
        Set(ByVal Value As String)
            _Observaciones = Value
        End Set
    End Property

    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property

    Public Property sqlNormas() As String
        Get
            Return _sqlNormas
        End Get
        Set(ByVal Value As String)
            _sqlNormas = Value
        End Set
    End Property

    Public Property sqlNormasAdoptadas() As String
        Get
            Return _sqlNormasAdoptadas
        End Get
        Set(ByVal Value As String)
            _sqlNormasAdoptadas = Value
        End Set
    End Property

    Public Property sqlProyecto() As String
        Get
            Return _sqlProyecto
        End Get
        Set(ByVal Value As String)
            _sqlProyecto = Value
        End Set
    End Property

    Public Property sqlAnteproyecto() As String
        Get
            Return _sqlAnteproyecto
        End Get
        Set(ByVal Value As String)
            _sqlAnteproyecto = Value
        End Set
    End Property

    Public Property sqlDT() As String
        Get
            Return _sqlDT
        End Get
        Set(ByVal Value As String)
            _sqlDT = Value
        End Set
    End Property



    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objConexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objConexion.SserverC
        Base = objConexion.SBaseD
    End Sub
    '''''''''''''''''Genera una la lista de campos

    Public Function Consulta_Normas()
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "Sp_Q_Normas"
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@sqlNormas", _sqlNormas)
            .Parameters.Add("@sqlNormasAdoptadas", _sqlNormasAdoptadas)
            .Parameters.Add("@sqlProyecto", _sqlProyecto)
            .Parameters.Add("@sqlAnteproyecto", _sqlAnteproyecto)
            .Parameters.Add("@sqlDT", _sqlDT)
        End With
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
            Dim da As SqlDataAdapter
            Dim dt As New DataTable("clsQTNormas")
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function












    Public Sub ListaCombo(ByVal cbo As Object) 'este sustituye a los dos de abajo
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Norma_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Clasificacion", _Clasificacion)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Norma")
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            da.Fill(dt)
            If _Bandera = 1 Then
                cbo.DisplayMember = dt.Columns(0).ColumnName
                'cbo.ValueMember = dt.Columns(0).ColumnName
            ElseIf _Bandera = 2 Then
                cbo.DisplayMember = dt.Columns(1).ColumnName
                'cbo.ValueMember = dt.Columns(1).ColumnName
            End If
            'cbo.DisplayMember = dt.Columns(0).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Objetivo = ex.Message
            Return
        End Try
    End Sub


    ''''''''''''''''''''Genera una la lista de campos
    Function ListaGrid() As DataTable  'este sustituye a los dos de abajo
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        Dim dtGrig As SqlDataReader
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Norma_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
        End With
        Dim dsGrid As New DataSet
        Try

            cn.Open()
            cmd.ExecuteNonQuery()
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dsGrid, "C_Normas")
            cmd.Dispose()
        Catch ex As Exception
            _Objetivo = ex.Message
            Return Nothing
            'Return 
        End Try
        Return dsGrid.Tables("C_Normas")
    End Function


    Function ListaGridDetalle() As DataTable  'para cargar los grid del cat�logo de normas (clasifiaci�n y t�tulos)
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        Dim dtGrig As SqlDataReader
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Norma_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Tipo_Norma", _Tipo_Norma)
            .Parameters.Add("@Tipo_Norma_Dos", _Tipo_Norma_Dos)
            .Parameters.Add("@Clasificacion", _Clasificacion)
        End With
        Dim dsGrid As New DataSet
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dsGrid, "C_Normas")
            cmd.Dispose()
        Catch ex As Exception
            _Objetivo = ex.Message
            Return Nothing
            'Return 
        End Try
        Return dsGrid.Tables("C_Normas")
    End Function
    Public Sub Temas_Normas()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Norma_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmd.ExecuteReader()
            If dr.Read Then
                'FECHA DE INICIO NMX
                _F_Ini_Desarrollo = IIf(IsDBNull(dr("F_Inic_Desarrollo_Nmx")) = True, "00/00/0000", dr("F_Inic_Desarrollo_Nmx"))
                'FECHA APROB COMITE
                _F_Apro_CONANCE = IIf(IsDBNull(dr("F_Aprobacion_Comite_PROY")) = True, "00/00/0000", dr("F_Aprobacion_Comite_PROY"))
                'fecha de aprob ct gt ant
                _F_Apro_CT_GT = IIf(IsDBNull(dr("F_Aprobacion_CTGT_ANT")) = True, "00/00/0000", dr("F_Aprobacion_CTGT_ANT"))
                'F_iNICIO_COM_PUBS
                _F_Apro_Coment_Pub = IIf(IsDBNull(dr("F_Publicacion_ComentarioPublico")) = True, "00/00/0000", dr("F_Publicacion_ComentarioPublico"))
                'F_LIMITE-COMPUBS
                _F_Limite = IIf(IsDBNull(dr("F_Limite_ComentarioPublico")) = True, "00/00/0000", dr("F_Limite_ComentarioPublico"))
                'f_ENVIO dgn
                _F_Env_DGN = IIf(IsDBNull(dr("F_ACUSE_DGN_PROYF")) = True, "00/00/0000", dr("F_ACUSE_DGN_PROYF"))
                'f_RESOLUCION cOMpUBS
                _F_Resol_Comentarios = IIf(IsDBNull(dr("F_Resolucion_ComentarioPublico")) = True, "00/00/0000", dr("F_Resolucion_ComentarioPublico"))
                _Id_Plan = IIf(IsDBNull(dr("Id_Plan")) = True, "", dr("Id_Plan"))
                _Id_Tema = IIf(IsDBNull(dr("Id_Tema")) = True, "", dr("Id_Tema"))
            Else
                'FECHA DE INICIO NMX
                _F_Ini_Desarrollo = Nothing

                'FECHA APROB COMITE
                _F_Apro_CONANCE = Nothing

                'fecha de aprob ct gt ant
                _F_Apro_CT_GT = Nothing

                'F_iNICIO_COM_PUBS
                _F_Apro_Coment_Pub = Nothing

                'F_LIMITE-cOMPUBS
                _F_Limite = Nothing

                'f_ENVIO dgn
                _F_Env_DGN = Nothing

                'f_RESOLUCION cOMpUBS
                _F_Resol_Comentarios = Nothing

                _Id_Plan = ""
                _Id_Tema = ""

            End If


        Catch ex As Exception

        End Try


    End Sub

    Public Sub Llena_Campos()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Norma_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmd.ExecuteReader()
            If dr.Read Then
                _Clasificacion = IIf((IsDBNull(dr("Clasificacion"))), "NA", dr("Clasificacion"))
                _ID_Comite = IIf((IsDBNull(dr("ID_Comite"))), "NA", dr("ID_Comite"))
                _ID_CT = IIf((IsDBNull(dr("ID_CT"))), "NA", dr("ID_CT"))
                _ID_SC = IIf((IsDBNull(dr("ID_SC"))), "NA", dr("ID_SC"))
                _ID_Grupo = IIf((IsDBNull(dr("ID_Grupo"))), "NA", dr("ID_Grupo"))

                If dr("F_Decla_Vigencia") Is Nothing Or IsDBNull(dr("F_Decla_Vigencia")) Then
                    _F_Decla_Vigencia = ""
                Else
                    _F_Decla_Vigencia = dr("F_Decla_Vigencia")
                End If
                '''' _F_Decla_Vigencia = IIf((IsDBNull(dr("F_Decla_Vigencia"))), "", CStr(dr("F_Decla_Vigencia")))
                _TIE = IIf((IsDBNull(dr("TIE"))), "", dr("TIE"))
                _TII = IIf((IsDBNull(dr("TII"))), "", dr("TII"))
                _No_Paginas = IIf((IsDBNull(dr("No_Paginas"))), "", dr("No_Paginas"))
                _Objetivo = IIf((IsDBNull(dr("Objetivo"))), "", dr("Objetivo"))

                _Bilbiografia = IIf((IsDBNull(dr("Bilbiografia"))), "", dr("Bilbiografia"))
                _Resp_Publicacion = IIf(IsDBNull(dr("Resp_Publicacion")) = True, "", dr("Resp_Publicacion"))
                _F_Ent_Vigor = IIf(IsDBNull(dr("F_Ent_Vigor")) = True, "", dr("F_Ent_Vigor"))

                If dr("F_Revi_Quinquenal") Is Nothing Or IsDBNull(dr("F_Revi_Quinquenal")) Then
                    _F_Revi_Quinquenal = ""
                Else
                    _F_Revi_Quinquenal = dr("F_Revi_Quinquenal")
                End If

                If dr("F_Avi_Cancelacion") Is Nothing Or IsDBNull(dr("F_Avi_Cancelacion")) Then
                    _F_Avi_Cancelacion = ""
                Else
                    _F_Avi_Cancelacion = dr("F_Avi_Cancelacion")
                End If

                If dr("F_Decl_Vige_Can") Is Nothing Or IsDBNull(dr("F_Decl_Vige_Can")) Then
                    _F_Decl_Vige_Can = ""
                Else
                    _F_Decl_Vige_Can = dr("F_Decl_Vige_Can")
                End If

                If dr("F_Noti_Ratificacion") Is Nothing Or IsDBNull(dr("F_Noti_Ratificacion")) Then
                    _F_Noti_Ratificacion = ""
                Else
                    _F_Noti_Ratificacion = dr("F_Noti_Ratificacion")
                End If

                If dr("F_Noti_Modificacion") Is Nothing Or IsDBNull(dr("F_Noti_Modificacion")) Then
                    _F_Noti_Modificacion = ""
                Else
                    _F_Noti_Modificacion = dr("F_Noti_Modificacion")
                End If

                _Observaciones = IIf((IsDBNull(dr("Observaciones"))), Nothing, dr("Observaciones"))
                _Encontrado = True
                _F_Publi_Cancelacion = IIf(IsDBNull(dr("F_Pub_Canc")) = True, "", dr("F_Pub_Canc"))
                _F_Limite = IIf(IsDBNull(dr("F_Lim_Canc")) = True, "", dr("F_Lim_Canc"))


            Else
                _Clasificacion = ""
                _ID_Comite = ""
                _ID_CT = ""
                _ID_SC = ""
                _ID_Grupo = ""
                _F_Decla_Vigencia = ""
                '_Norma_Cancela = ""
                _TIE = ""
                _TII = ""
                _No_Paginas = ""
                _Objetivo = ""
                '_Campo_Aplicacion = ""
                _Concor_Norm_Intern = ""
                _Bilbiografia = ""
                _Resp_Publicacion = ""
                _F_Ent_Vigor = ""
                _F_Revi_Quinquenal = ""
                _F_Avi_Cancelacion = ""
                _F_Decl_Vige_Can = ""
                _F_Noti_Ratificacion = ""
                _F_Noti_Modificacion = ""
                _Observaciones = Nothing
                _Encontrado = False
                _F_Publi_Cancelacion = ""
                _F_Limite = ""
            End If
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
        Catch ex As Exception
            Return
        End Try
    End Sub

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Normas_Modificar"
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
            .Parameters.Add("@Cancelada", _Cancelada)
            .Parameters.Add("@Inactivo", _Inactivo)

            .Parameters.Add("@ID_Comite", _ID_Comite)
            .Parameters.Add("@ID_CT", _ID_CT)
            .Parameters.Add("@ID_SC", _ID_SC)
            .Parameters.Add("@ID_Grupo", _ID_Grupo)
            ' .Parameters.Add("@F_Decla_Vigencia", _F_Decla_Vigencia)
            '.Parameters.Add("@F_Decla_Vigencia", Date.Now)

            .Parameters.Add("@F_Decla_Vigencia", _F_Decla_Vigencia)

            .Parameters.Add("@TIE", _TIE)
            .Parameters.Add("@TII", _TII)
            .Parameters.Add("@No_Paginas", _No_Paginas)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Concor_Norm_Intern", _Concor_Norm_Intern)
            .Parameters.Add("@Bilbiografia", _Bilbiografia)
            .Parameters.Add("@Resp_Publicacion", _Resp_Publicacion)

            .Parameters.Add("@F_Ent_Vigor", _F_Ent_Vigor)
            .Parameters.Add("@F_Revi_Quinquenal", _F_Revi_Quinquenal)
            .Parameters.Add("@F_Avi_Cancelacion", _F_Avi_Cancelacion)
            .Parameters.Add("@F_Decl_Vige_Can", _F_Decl_Vige_Can)
            .Parameters.Add("@F_Noti_Ratificacion", _F_Noti_Ratificacion)
            .Parameters.Add("@F_Noti_Modificacion", _F_Noti_Modificacion)
            .Parameters.Add("@F_Pub_Canc", _F_Publi_Cancelacion)
            .Parameters.Add("@F_Lim_Canc", _F_Limite)

        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
            Return True
            Exit Function
        Catch ex As Exception
            MsgBox("Error al tratar de guardar los datos de la norma - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            'Return "ERROR: " & ex.Message
            Return False
        End Try

    End Function


    Public Function Actualizar_Detalle() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Normas_Modificar"
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
            .Parameters.Add("@ID_Detalle", _ID_Detalle)
            .Parameters.Add("@ID_Tipo_Norma", _ID_Tipo_Norma)
            .Parameters.Add("@Clasificacion_Norma", _Clasificacion_Norma)
            .Parameters.Add("@Titulo_Norma", _Titulo_Norma)
            .Parameters.Add("@Inactivo", _Inactivo)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
            Return True
            Exit Function
        Catch ex As Exception
            MsgBox("Verifica que no exista ya esa norma - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            'Return "ERROR: " & ex.Message
            Return False
        End Try
    End Function

    Public Function Actualizar_Tema_Norma() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Normas_Modificar"
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
            .Parameters.Add("@Cancelada", _Cancelada)
            .Parameters.Add("@Inactivo", _Inactivo)

            .Parameters.Add("@ID_Comite", _ID_Comite)
            .Parameters.Add("@ID_CT", _ID_CT)
            .Parameters.Add("@ID_SC", _ID_SC)
            .Parameters.Add("@ID_Grupo", _ID_Grupo)
            ' .Parameters.Add("@F_Decla_Vigencia", _F_Decla_Vigencia)
            '.Parameters.Add("@F_Decla_Vigencia", Date.Now)

            .Parameters.Add("@F_Decla_Vigencia", _F_Decla_Vigencia)

            .Parameters.Add("@TIE", _TIE)
            .Parameters.Add("@TII", _TII)
            .Parameters.Add("@No_Paginas", _No_Paginas)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Concor_Norm_Intern", _Concor_Norm_Intern)
            .Parameters.Add("@Bilbiografia", _Bilbiografia)
            .Parameters.Add("@Resp_Publicacion", _Resp_Publicacion)

            .Parameters.Add("@F_Ent_Vigor", _F_Ent_Vigor)
            .Parameters.Add("@F_Ini_Desarrollo", _F_Ini_Desarrollo)
            .Parameters.Add("@F_Apro_CONANCE", _F_Apro_CONANCE)
            .Parameters.Add("@F_Apro_Coment_Pub", _F_Apro_Coment_Pub)
            .Parameters.Add("@F_Revi_Quinquenal", _F_Revi_Quinquenal)
            .Parameters.Add("@F_Avi_Cancelacion", _F_Avi_Cancelacion)
            .Parameters.Add("@F_Decl_Vige_Can", _F_Decl_Vige_Can)
            .Parameters.Add("@F_Noti_Ratificacion", _F_Noti_Ratificacion)
            .Parameters.Add("@F_Noti_Modificacion", _F_Noti_Modificacion)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
            Return True
            Exit Function
        Catch ex As Exception
            MsgBox("Error al tratar de guardar los datos de la norma - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            'Return "ERROR: " & ex.Message
            Return False
        End Try

    End Function

    Public Function Agregar() As String
        Dim cmdAgregar As SqlCommand
        If _Clasificacion = "" Then
            MsgBox("Error al tratar de guardar los datos", MsgBoxStyle.Exclamation, "Comites")
            Exit Function
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Normas_Modificar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
            '.Parameters.Add("@Cancelada", _Cancelada)
            .Parameters.Add("@Inactivo", _Inactivo)

            .Parameters.Add("@ID_Comite", _ID_Comite)
            .Parameters.Add("@ID_CT", _ID_CT)
            .Parameters.Add("@ID_SC", _ID_SC)
            .Parameters.Add("@ID_Grupo", _ID_Grupo)
            .Parameters.Add("@F_Decla_Vigencia", _F_Decla_Vigencia)
            .Parameters.Add("@TIE", _TIE)
            .Parameters.Add("@TII", _TII)
            .Parameters.Add("@No_Paginas", _No_Paginas)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Bilbiografia", _Bilbiografia)
            .Parameters.Add("@Resp_Publicacion", _Resp_Publicacion)
            .Parameters.Add("@F_Ent_Vigor", _F_Ent_Vigor)
            .Parameters.Add("@F_Revi_Quinquenal", _F_Revi_Quinquenal)
            .Parameters.Add("@F_Avi_Cancelacion", _F_Avi_Cancelacion)
            .Parameters.Add("@F_Decl_Vige_Can", _F_Decl_Vige_Can)
            .Parameters.Add("@F_Noti_Ratificacion", _F_Noti_Ratificacion)
            .Parameters.Add("@F_Noti_Modificacion", _F_Noti_Modificacion)
            .Parameters.Add("@Observaciones", _Observaciones)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
            Return True
        Catch ex As Exception
            MsgBox("Verifica que no exista ya esa norma - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            Return False
        End Try
        Exit Function
    End Function

    Public Function Borrar_Norma() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        On Error GoTo er
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Normas_Borrar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Clasificacion", _Clasificacion)
        End With
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        cmd.Parameters.Clear()
        cmd.Dispose()
        Return sStatus
er:
        MsgBox("Verifica que no existan nodos hijos - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Campo Existente")
        sStatus = "Fallo"
    End Function

    Public Sub Buscar_ID_Detalle()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand

        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Norma_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            'cmd.ExecuteNonQuery()
            dr = cmd.ExecuteReader
            If dr.Read Then
                _ID_Detalle = dr("Id_Detalle")
            Else
                _ID_Detalle = ""
            End If
            cmd.Dispose()
        Catch ex As Exception
            _Objetivo = ex.Message
            'Return Nothing
            'Return False
            'Return 
        End Try
        'Return True
        cn.Close()
    End Sub

    Public Function Actualizar_Documentos() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Normas_Modificar"
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Id_Tipo_doc", _Id_tipo_doc)
            .Parameters.Add("@Documento", _Documento)
            .Parameters.Add("@Activo", _Activo)
            .Parameters.Add("@Id_Comentario", _Id_comentario)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
            Return True
            Exit Function
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este documento - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Documento Existente")
            'Return "ERROR: " & ex.Message
            Return False
        End Try

    End Function

End Class
