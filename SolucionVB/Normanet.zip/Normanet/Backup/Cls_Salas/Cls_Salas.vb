
'*************************************************************************************
'Clase P_Solicitud Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 18/09/2006 09:56:59 a.m.
'*************************************************************************************

Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class Cls_Salas
    '''''''Declaracion de Variables Privadas

    Private cn As New SqlConnection
    Private _Descripcion_sala As String
    Private _No_Solicitud As Integer
    Private _F_Solicitada As String
    Private _F_Apartado As String
    Private _Id_Area As Integer
    Private _Id_Responsable As String
    Private _Reunion As String
    Private _H_Entrada As String
    Private _H_Salida As String
    Private _No_Personas As String
    Private _Servicio As String
    Private _Equipo As String
    Private _Id_Sala As Integer
    Private _Status As String
    Private _Observacion As String
    Private _Comentarios As String
    Private _Id_Propuesta As Integer
    Private _Acomodo As String
    Private _Id_Coordinador As String

    Private sSql As String
    Private _Bandera As String
    Private _Error As String
    Private dr As SqlDataReader
    Dim objConexion As New clsConexion.cIsConexion
    '''''''Declaracion de Propiedades publicas
    Public Property Descripcion() As String
        Get
            Return _Descripcion_sala
        End Get
        Set(ByVal Value As String)
            _Descripcion_sala = Value
        End Set
    End Property

    Public Property No_Solicitud() As Integer
        Get
            Return _No_Solicitud
        End Get
        Set(ByVal Value As Integer)
            _No_Solicitud = Value
        End Set
    End Property

    Public Property F_Solicitada() As String
        Get
            Return _F_Solicitada
        End Get
        Set(ByVal Value As String)
            _F_Solicitada = Value
        End Set
    End Property

    Public Property F_Apartado() As String
        Get
            Return _F_Apartado
        End Get
        Set(ByVal Value As String)
            _F_Apartado = Value
        End Set
    End Property

    Public Property Id_Area() As Integer
        Get
            Return _Id_Area
        End Get
        Set(ByVal Value As Integer)
            _Id_Area = Value
        End Set
    End Property

    Public Property Id_Responsable() As String
        Get
            Return _Id_Responsable
        End Get
        Set(ByVal Value As String)
            _Id_Responsable = Value
        End Set
    End Property

    Public Property Reunion() As String
        Get
            Return _Reunion
        End Get
        Set(ByVal Value As String)
            _Reunion = Value
        End Set
    End Property

    Public Property H_Entrada() As String
        Get
            Return _H_Entrada
        End Get
        Set(ByVal Value As String)
            _H_Entrada = Value
        End Set
    End Property

    Public Property H_Salida() As String
        Get
            Return _H_Salida
        End Get
        Set(ByVal Value As String)
            _H_Salida = Value
        End Set
    End Property

    Public Property No_Personas() As String
        Get
            Return _No_Personas
        End Get
        Set(ByVal Value As String)
            _No_Personas = Value
        End Set
    End Property

    Public Property Servicio() As String
        Get
            Return _Servicio
        End Get
        Set(ByVal Value As String)
            _Servicio = Value
        End Set
    End Property

    Public Property Equipo() As String
        Get
            Return _Equipo
        End Get
        Set(ByVal Value As String)
            _Equipo = Value
        End Set
    End Property

    Public Property Id_Sala() As Integer
        Get
            Return _Id_Sala
        End Get
        Set(ByVal Value As Integer)
            _Id_Sala = Value
        End Set
    End Property

    Public Property Status() As String
        Get
            Return _Status
        End Get
        Set(ByVal Value As String)
            _Status = Value
        End Set
    End Property

    Public Property Observacion() As String
        Get
            Return _Observacion
        End Get
        Set(ByVal Value As String)
            _Observacion = Value
        End Set
    End Property

    Public Property Comentarios() As String
        Get
            Return _Comentarios
        End Get
        Set(ByVal Value As String)
            _Comentarios = Value
        End Set
    End Property

    Public Property Id_Propuesta() As Integer
        Get
            Return _Id_Propuesta
        End Get
        Set(ByVal Value As Integer)
            _Id_Propuesta = Value
        End Set
    End Property

    Public Property Acomodo() As String
        Get
            Return _Acomodo
        End Get
        Set(ByVal Value As String)
            _Acomodo = Value
        End Set
    End Property

    Public Property Id_Coordinador() As String
        Get
            Return _Id_Coordinador
        End Get
        Set(ByVal Value As String)
            _Id_Coordinador = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property


    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
        cn.ConnectionString = "Data source = " + objConexion.Server + "; Initial Catalog = " + objConexion.Base + "; User Id = " + Usuario + "; Pwd =  " + Password
    End Sub

    Public Sub ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Salas_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_Salas")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return
        End Try
    End Sub
    '''''''''''''''''Genera una la lista de campos
    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Salas_Buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_Salas")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)

            Return dt
        Catch ex As Exception
            _Error = "Error " & ex.Source & " - " & ex.Message
            Return Nothing
        End Try
    End Function

    Private Sub llena_parametros(ByVal command As SqlCommand)

        With command
            'llave de c_empleado completo
            .Parameters.Add("@No_Solicitud", _No_Solicitud)
            If _Bandera = 1 Then
                .Parameters.Add("@No_Solicitud2", SqlDbType.Int)
                .Parameters("@No_Solicitud2").Direction = ParameterDirection.InputOutput
            End If
            .Parameters.Add("@F_Solicitada", _F_Solicitada)
            .Parameters.Add("@F_Apartado", _F_Apartado)
            .Parameters.Add("@Id_Area", _Id_Area)
            .Parameters.Add("@Id_Responsable", _Id_Responsable)
            .Parameters.Add("@Reunion", _Reunion)
            .Parameters.Add("@H_Entrada", _H_Entrada)
            .Parameters.Add("@H_Salida", _H_Salida)
            .Parameters.Add("@No_Personas", _No_Personas)
            .Parameters.Add("@Servicio", _Servicio)
            .Parameters.Add("@Equipo", _Equipo)
            .Parameters.Add("@Id_Sala", _Id_Sala)
            .Parameters.Add("@Status", _Status)
            .Parameters.Add("@Observacion", _Observacion)
            .Parameters.Add("@Comentarios", _Comentarios)
            .Parameters.Add("@Id_Propuesta", _Id_Propuesta)
            .Parameters.Add("@Acomodo", _Acomodo)
            .Parameters.Add("@Id_Coordinador", _Id_Coordinador)
            .Parameters.Add("@Descripcion_sala", _Descripcion_sala)
            .Parameters.Add("@Bandera", _Bandera)
        End With
    End Sub

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar()
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Salas_Buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader

            If dr.Read Then
                _No_Solicitud = IIf((IsDBNull(dr("No_Solicitud"))), 0, dr("No_Solicitud"))
                _F_Solicitada = IIf((IsDBNull(dr("F_Solicitada"))), "", dr("F_Solicitada"))
                _F_Apartado = IIf((IsDBNull(dr("F_Apartado"))), "", dr("F_Apartado"))
                _Id_Area = IIf((IsDBNull(dr("Id_Area"))), 0, dr("Id_Area"))
                _Id_Responsable = IIf((IsDBNull(dr("Id_Responsable"))), "", dr("Id_Responsable"))
                _Reunion = IIf((IsDBNull(dr("Reunion"))), "", dr("Reunion"))
                _H_Entrada = IIf((IsDBNull(dr("H_Entrada"))), "", dr("H_Entrada"))
                _H_Salida = IIf((IsDBNull(dr("H_Salida"))), "", dr("H_Salida"))
                _No_Personas = IIf((IsDBNull(dr("No_Personas"))), "", dr("No_Personas"))
                _Servicio = IIf((IsDBNull(dr("Servicio"))), "", dr("Servicio"))
                _Equipo = IIf((IsDBNull(dr("Equipo"))), "", dr("Equipo"))
                _Id_Sala = IIf((IsDBNull(dr("Id_Sala"))), 0, dr("Id_Sala"))
                _Status = IIf((IsDBNull(dr("Status"))), "", dr("Status"))
                _Observacion = IIf((IsDBNull(dr("Observacion"))), "", dr("Observacion"))
                _Comentarios = IIf((IsDBNull(dr("Comentarios"))), "", dr("Comentarios"))
                _Id_Propuesta = IIf((IsDBNull(dr("Id_Propuesta"))), "", dr("Id_Propuesta"))
                _Acomodo = IIf((IsDBNull(dr("Acomodo"))), "", dr("Acomodo"))
                _Id_Coordinador = IIf((IsDBNull(dr("Id_Coordinador"))), "", dr("Id_Coordinador"))
                _Descripcion_sala = IIf((IsDBNull(dr("Descripcion_Sala"))), "", dr("Descripcion_Sala"))
            Else
                _No_Solicitud = ""
                _F_Solicitada = ""
                _F_Apartado = ""
                _Id_Area = ""
                _Id_Responsable = ""
                _Reunion = ""
                _H_Entrada = ""
                _H_Salida = ""
                _No_Personas = ""
                _Servicio = ""
                _Equipo = ""
                _Id_Sala = ""
                _Status = ""
                _Observacion = ""
                _Comentarios = ""
                _Id_Propuesta = ""
                _Acomodo = ""
                _Id_Coordinador = ""
                _Descripcion_sala = ""
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Sub

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Salas"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cmd.ExecuteNonQuery()
            If _Bandera = 1 Then
                _No_Solicitud = IIf(IsDBNull(cmd.Parameters("@Id_Sesion2").Value), -1, cmd.Parameters("@Id_Sesion2").Value)
            End If
            Return True
        Catch ex As Exception When _No_Solicitud = -1 And Bandera = 1
            _Error = ""
            If _No_Solicitud = -1 Then _Error = Chr(13) + "El valor devuelto por el Procedimiento de Sql es un DBNULL"
            _Error = "ERROR - Bandera " + _Bandera + " " + _Error + ex.Message
            Return False
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Salas"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cmd.ExecuteNonQuery()
            If _Bandera = 1 Then
                _No_Solicitud = IIf(IsDBNull(cmd.Parameters("@No_Solicitud2").Value), -1, cmd.Parameters("@No_Solicitud2").Value)
            End If
            Return True
        Catch ex As Exception When _No_Solicitud = -1 And Bandera = 1
            _Error = ""
            If _No_Solicitud = -1 Then _Error = Chr(13) + "El valor devuelto por el Procedimiento de Sql es un DBNULL"
            _Error = "ERROR - Bandera " + _Bandera + " " + _Error + ex.Message
            Return False
        End Try
    End Function



End Class
