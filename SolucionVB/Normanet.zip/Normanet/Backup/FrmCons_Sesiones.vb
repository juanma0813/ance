Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections

Public Class frmCons_sesiones
    Inherits System.Windows.Forms.Form

#Region " Inicializaci�n de   Dll's y componentes"

    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objsalas As New Cls_Salas.Cls_Salas("EXTRA", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)
    Public stema As Integer
    Public splan As String

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

#Region " Inicializaci�n de componentes"
    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
        objplanes.Inicializa(0, gUsuario, gPasswordSql)
        objempleados.Inicializa(Application.StartupPath & "\principal.ini","comun",gUsuario, gPasswordSql)
    End Sub

#End Region

    'Form reemplaza a Dispose para limpiar la lista de componentes.

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region " Components, C�digo generado por el Dise�ador de Windows Forms "
    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents CmdBuscar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAsistencia As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdCalendario As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdImprimir As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separator2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents DGridResultados As System.Windows.Forms.DataGrid
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TbPSesiones As System.Windows.Forms.TabPage
    Friend WithEvents TbPTemas As System.Windows.Forms.TabPage
    Friend WithEvents Lbletapas As System.Windows.Forms.Label
    Friend WithEvents CBoEtapa As System.Windows.Forms.ComboBox
    Friend WithEvents ChkEtapas As System.Windows.Forms.CheckBox
    Friend WithEvents Lblstatus As System.Windows.Forms.Label
    Friend WithEvents cbostatus As System.Windows.Forms.ComboBox
    Friend WithEvents ChKStatus As System.Windows.Forms.CheckBox
    Friend WithEvents TxtLugar As System.Windows.Forms.TextBox
    Friend WithEvents Lbllugar As System.Windows.Forms.Label
    Friend WithEvents Chklugar As System.Windows.Forms.CheckBox
    Friend WithEvents LblResp As System.Windows.Forms.Label
    Friend WithEvents CboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents ChkResponsable As System.Windows.Forms.CheckBox
    Friend WithEvents DTPh_tem As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPh_ini As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lblht As System.Windows.Forms.Label
    Friend WithEvents Lblhi As System.Windows.Forms.Label
    Friend WithEvents ChkHora As System.Windows.Forms.CheckBox
    Friend WithEvents DTPF_Fin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lblft As System.Windows.Forms.Label
    Friend WithEvents Lblfi As System.Windows.Forms.Label
    Friend WithEvents DTPF_Ini As System.Windows.Forms.DateTimePicker
    Friend WithEvents ChkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents TbCCriterios As System.Windows.Forms.TabControl
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ChkF_DGN As System.Windows.Forms.CheckBox
    Friend WithEvents ChkTemas As System.Windows.Forms.CheckBox
    Friend WithEvents ChkF_Public As System.Windows.Forms.CheckBox
    Friend WithEvents DTP_DGNFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTP_DGNini As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTP_Pubfin As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTP_Pubini As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbldgn As System.Windows.Forms.Label
    Friend WithEvents Lblpub As System.Windows.Forms.Label
    Friend WithEvents Lbltemas As System.Windows.Forms.Label
    Friend WithEvents LbltvTemas As System.Windows.Forms.Label
    Friend WithEvents TbPCalendario As System.Windows.Forms.TabPage
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ChkAnual As System.Windows.Forms.CheckBox
    Friend WithEvents DTPPerini As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ChkMes As System.Windows.Forms.CheckBox
    Friend WithEvents DTPMes As System.Windows.Forms.DateTimePicker
    Friend WithEvents TVTemas As System.Windows.Forms.TreeView
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents imgListTreeView2 As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmCons_sesiones))
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.DGridResultados = New System.Windows.Forms.DataGrid
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.CmdBuscar = New System.Windows.Forms.ToolBarButton
        Me.cmdAsistencia = New System.Windows.Forms.ToolBarButton
        Me.CmdCalendario = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdImprimir = New System.Windows.Forms.ToolBarButton
        Me.Separator2 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.TxtTotal = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TbCCriterios = New System.Windows.Forms.TabControl
        Me.TbPCalendario = New System.Windows.Forms.TabPage
        Me.Label4 = New System.Windows.Forms.Label
        Me.DTPMes = New System.Windows.Forms.DateTimePicker
        Me.ChkMes = New System.Windows.Forms.CheckBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.DTPPerini = New System.Windows.Forms.DateTimePicker
        Me.ChkAnual = New System.Windows.Forms.CheckBox
        Me.TbPSesiones = New System.Windows.Forms.TabPage
        Me.Lblstatus = New System.Windows.Forms.Label
        Me.cbostatus = New System.Windows.Forms.ComboBox
        Me.ChKStatus = New System.Windows.Forms.CheckBox
        Me.TxtLugar = New System.Windows.Forms.TextBox
        Me.Lbllugar = New System.Windows.Forms.Label
        Me.Chklugar = New System.Windows.Forms.CheckBox
        Me.LblResp = New System.Windows.Forms.Label
        Me.CboResponsable = New System.Windows.Forms.ComboBox
        Me.ChkResponsable = New System.Windows.Forms.CheckBox
        Me.DTPh_tem = New System.Windows.Forms.DateTimePicker
        Me.DTPh_ini = New System.Windows.Forms.DateTimePicker
        Me.Lblht = New System.Windows.Forms.Label
        Me.Lblhi = New System.Windows.Forms.Label
        Me.ChkHora = New System.Windows.Forms.CheckBox
        Me.DTPF_Fin = New System.Windows.Forms.DateTimePicker
        Me.Lblft = New System.Windows.Forms.Label
        Me.Lblfi = New System.Windows.Forms.Label
        Me.DTPF_Ini = New System.Windows.Forms.DateTimePicker
        Me.ChkFechas = New System.Windows.Forms.CheckBox
        Me.TbPTemas = New System.Windows.Forms.TabPage
        Me.LbltvTemas = New System.Windows.Forms.Label
        Me.DTP_DGNFin = New System.Windows.Forms.DateTimePicker
        Me.Label5 = New System.Windows.Forms.Label
        Me.Lbldgn = New System.Windows.Forms.Label
        Me.DTP_DGNini = New System.Windows.Forms.DateTimePicker
        Me.ChkF_DGN = New System.Windows.Forms.CheckBox
        Me.DTP_Pubfin = New System.Windows.Forms.DateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.Lblpub = New System.Windows.Forms.Label
        Me.DTP_Pubini = New System.Windows.Forms.DateTimePicker
        Me.ChkF_Public = New System.Windows.Forms.CheckBox
        Me.TVTemas = New System.Windows.Forms.TreeView
        Me.imgListTreeView2 = New System.Windows.Forms.ImageList(Me.components)
        Me.Lbltemas = New System.Windows.Forms.Label
        Me.ChkTemas = New System.Windows.Forms.CheckBox
        Me.Lbletapas = New System.Windows.Forms.Label
        Me.CBoEtapa = New System.Windows.Forms.ComboBox
        Me.ChkEtapas = New System.Windows.Forms.CheckBox
        CType(Me.DGridResultados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TbCCriterios.SuspendLayout()
        Me.TbPCalendario.SuspendLayout()
        Me.TbPSesiones.SuspendLayout()
        Me.TbPTemas.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lblcomite.Location = New System.Drawing.Point(8, 8)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(126, 16)
        Me.Lblcomite.TabIndex = 88
        Me.Lblcomite.Text = "Comite Seleccionado: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 24)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 16)
        Me.LblTreeView.TabIndex = 87
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'tvComites
        '
        Me.tvComites.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 47)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = 1
        Me.tvComites.Size = New System.Drawing.Size(216, 273)
        Me.tvComites.TabIndex = 1
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'DGridResultados
        '
        Me.DGridResultados.CaptionBackColor = System.Drawing.Color.FromArgb(CType(95, Byte), CType(126, Byte), CType(60, Byte))
        Me.DGridResultados.CaptionVisible = False
        Me.DGridResultados.DataMember = ""
        Me.DGridResultados.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.DGridResultados.HeaderBackColor = System.Drawing.Color.FromArgb(CType(95, Byte), CType(126, Byte), CType(60, Byte))
        Me.DGridResultados.HeaderForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.DGridResultados.Location = New System.Drawing.Point(8, 328)
        Me.DGridResultados.Name = "DGridResultados"
        Me.DGridResultados.Size = New System.Drawing.Size(792, 216)
        Me.DGridResultados.TabIndex = 90
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.CmdBuscar, Me.cmdAsistencia, Me.CmdCalendario, Me.CmdDeshacer, Me.CmdImprimir, Me.Separator2, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 576)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(806, 62)
        Me.tlbBotonera.TabIndex = 92
        '
        'CmdBuscar
        '
        Me.CmdBuscar.ImageIndex = 8
        Me.CmdBuscar.Text = "Buscar"
        '
        'cmdAsistencia
        '
        Me.cmdAsistencia.ImageIndex = 9
        Me.cmdAsistencia.Text = "Lista Asistencia"
        '
        'CmdCalendario
        '
        Me.CmdCalendario.ImageIndex = 10
        Me.CmdCalendario.Text = "Calendario"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.ImageIndex = 11
        Me.CmdImprimir.Text = "Imprimir"
        '
        'Separator2
        '
        Me.Separator2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'TxtTotal
        '
        Me.TxtTotal.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTotal.Location = New System.Drawing.Point(680, 550)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(120, 20)
        Me.TxtTotal.TabIndex = 115
        Me.TxtTotal.Text = ""
        Me.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(624, 552)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 16)
        Me.Label1.TabIndex = 114
        Me.Label1.Text = "Total:"
        '
        'TbCCriterios
        '
        Me.TbCCriterios.Controls.Add(Me.TbPCalendario)
        Me.TbCCriterios.Controls.Add(Me.TbPSesiones)
        Me.TbCCriterios.Controls.Add(Me.TbPTemas)
        Me.TbCCriterios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TbCCriterios.Location = New System.Drawing.Point(232, 8)
        Me.TbCCriterios.Name = "TbCCriterios"
        Me.TbCCriterios.SelectedIndex = 0
        Me.TbCCriterios.Size = New System.Drawing.Size(568, 312)
        Me.TbCCriterios.TabIndex = 122
        '
        'TbPCalendario
        '
        Me.TbPCalendario.Controls.Add(Me.Label4)
        Me.TbPCalendario.Controls.Add(Me.DTPMes)
        Me.TbPCalendario.Controls.Add(Me.ChkMes)
        Me.TbPCalendario.Controls.Add(Me.Label2)
        Me.TbPCalendario.Controls.Add(Me.DTPPerini)
        Me.TbPCalendario.Controls.Add(Me.ChkAnual)
        Me.TbPCalendario.Location = New System.Drawing.Point(4, 23)
        Me.TbPCalendario.Name = "TbPCalendario"
        Me.TbPCalendario.Size = New System.Drawing.Size(560, 245)
        Me.TbPCalendario.TabIndex = 2
        Me.TbPCalendario.Text = "Calendario"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(168, 141)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 16)
        Me.Label4.TabIndex = 135
        Me.Label4.Text = "Mes: "
        '
        'DTPMes
        '
        Me.DTPMes.CustomFormat = "dd/MM/yyyy"
        Me.DTPMes.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPMes.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPMes.Location = New System.Drawing.Point(232, 139)
        Me.DTPMes.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPMes.Name = "DTPMes"
        Me.DTPMes.Size = New System.Drawing.Size(95, 20)
        Me.DTPMes.TabIndex = 134
        '
        'ChkMes
        '
        Me.ChkMes.Checked = True
        Me.ChkMes.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkMes.Location = New System.Drawing.Point(24, 136)
        Me.ChkMes.Name = "ChkMes"
        Me.ChkMes.Size = New System.Drawing.Size(112, 24)
        Me.ChkMes.TabIndex = 133
        Me.ChkMes.Text = "Mensual"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(168, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 16)
        Me.Label2.TabIndex = 132
        Me.Label2.Text = "A�o: "
        '
        'DTPPerini
        '
        Me.DTPPerini.CustomFormat = "dd/MM/yyyy"
        Me.DTPPerini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPPerini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPPerini.Location = New System.Drawing.Point(232, 91)
        Me.DTPPerini.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPPerini.Name = "DTPPerini"
        Me.DTPPerini.Size = New System.Drawing.Size(95, 20)
        Me.DTPPerini.TabIndex = 131
        '
        'ChkAnual
        '
        Me.ChkAnual.Checked = True
        Me.ChkAnual.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkAnual.Location = New System.Drawing.Point(24, 88)
        Me.ChkAnual.Name = "ChkAnual"
        Me.ChkAnual.Size = New System.Drawing.Size(112, 24)
        Me.ChkAnual.TabIndex = 130
        Me.ChkAnual.Text = "Anual"
        '
        'TbPSesiones
        '
        Me.TbPSesiones.Controls.Add(Me.Lblstatus)
        Me.TbPSesiones.Controls.Add(Me.cbostatus)
        Me.TbPSesiones.Controls.Add(Me.ChKStatus)
        Me.TbPSesiones.Controls.Add(Me.TxtLugar)
        Me.TbPSesiones.Controls.Add(Me.Lbllugar)
        Me.TbPSesiones.Controls.Add(Me.Chklugar)
        Me.TbPSesiones.Controls.Add(Me.LblResp)
        Me.TbPSesiones.Controls.Add(Me.CboResponsable)
        Me.TbPSesiones.Controls.Add(Me.ChkResponsable)
        Me.TbPSesiones.Controls.Add(Me.DTPh_tem)
        Me.TbPSesiones.Controls.Add(Me.DTPh_ini)
        Me.TbPSesiones.Controls.Add(Me.Lblht)
        Me.TbPSesiones.Controls.Add(Me.Lblhi)
        Me.TbPSesiones.Controls.Add(Me.ChkHora)
        Me.TbPSesiones.Controls.Add(Me.DTPF_Fin)
        Me.TbPSesiones.Controls.Add(Me.Lblft)
        Me.TbPSesiones.Controls.Add(Me.Lblfi)
        Me.TbPSesiones.Controls.Add(Me.DTPF_Ini)
        Me.TbPSesiones.Controls.Add(Me.ChkFechas)
        Me.TbPSesiones.Location = New System.Drawing.Point(4, 23)
        Me.TbPSesiones.Name = "TbPSesiones"
        Me.TbPSesiones.Size = New System.Drawing.Size(560, 245)
        Me.TbPSesiones.TabIndex = 0
        Me.TbPSesiones.Text = "Sesiones"
        '
        'Lblstatus
        '
        Me.Lblstatus.AutoSize = True
        Me.Lblstatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblstatus.Location = New System.Drawing.Point(140, 197)
        Me.Lblstatus.Name = "Lblstatus"
        Me.Lblstatus.Size = New System.Drawing.Size(46, 16)
        Me.Lblstatus.TabIndex = 137
        Me.Lblstatus.Text = "Status: "
        '
        'cbostatus
        '
        Me.cbostatus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbostatus.Location = New System.Drawing.Point(244, 194)
        Me.cbostatus.Name = "cbostatus"
        Me.cbostatus.Size = New System.Drawing.Size(296, 21)
        Me.cbostatus.TabIndex = 136
        '
        'ChKStatus
        '
        Me.ChKStatus.Checked = True
        Me.ChKStatus.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChKStatus.Location = New System.Drawing.Point(20, 192)
        Me.ChKStatus.Name = "ChKStatus"
        Me.ChKStatus.Size = New System.Drawing.Size(112, 24)
        Me.ChKStatus.TabIndex = 135
        Me.ChKStatus.Text = "Por Status:"
        '
        'TxtLugar
        '
        Me.TxtLugar.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.TxtLugar.Location = New System.Drawing.Point(244, 154)
        Me.TxtLugar.Name = "TxtLugar"
        Me.TxtLugar.Size = New System.Drawing.Size(296, 20)
        Me.TxtLugar.TabIndex = 134
        Me.TxtLugar.Text = ""
        '
        'Lbllugar
        '
        Me.Lbllugar.AutoSize = True
        Me.Lbllugar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbllugar.Location = New System.Drawing.Point(140, 157)
        Me.Lbllugar.Name = "Lbllugar"
        Me.Lbllugar.Size = New System.Drawing.Size(38, 16)
        Me.Lbllugar.TabIndex = 133
        Me.Lbllugar.Text = "Sede: "
        '
        'Chklugar
        '
        Me.Chklugar.Checked = True
        Me.Chklugar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Chklugar.Location = New System.Drawing.Point(20, 152)
        Me.Chklugar.Name = "Chklugar"
        Me.Chklugar.Size = New System.Drawing.Size(112, 24)
        Me.Chklugar.TabIndex = 132
        Me.Chklugar.Text = "Por Sede:"
        '
        'LblResp
        '
        Me.LblResp.AutoSize = True
        Me.LblResp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblResp.Location = New System.Drawing.Point(140, 116)
        Me.LblResp.Name = "LblResp"
        Me.LblResp.Size = New System.Drawing.Size(82, 16)
        Me.LblResp.TabIndex = 131
        Me.LblResp.Text = "Responsable: "
        '
        'CboResponsable
        '
        Me.CboResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboResponsable.Location = New System.Drawing.Point(244, 113)
        Me.CboResponsable.Name = "CboResponsable"
        Me.CboResponsable.Size = New System.Drawing.Size(296, 21)
        Me.CboResponsable.TabIndex = 130
        '
        'ChkResponsable
        '
        Me.ChkResponsable.Checked = True
        Me.ChkResponsable.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkResponsable.Location = New System.Drawing.Point(20, 111)
        Me.ChkResponsable.Name = "ChkResponsable"
        Me.ChkResponsable.Size = New System.Drawing.Size(112, 24)
        Me.ChkResponsable.TabIndex = 129
        Me.ChkResponsable.Text = "Por Responsable:"
        '
        'DTPh_tem
        '
        Me.DTPh_tem.CustomFormat = "HH:mm "
        Me.DTPh_tem.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPh_tem.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPh_tem.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPh_tem.Location = New System.Drawing.Point(444, 74)
        Me.DTPh_tem.Name = "DTPh_tem"
        Me.DTPh_tem.ShowUpDown = True
        Me.DTPh_tem.Size = New System.Drawing.Size(96, 20)
        Me.DTPh_tem.TabIndex = 128
        Me.DTPh_tem.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'DTPh_ini
        '
        Me.DTPh_ini.CustomFormat = "HH:mm"
        Me.DTPh_ini.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPh_ini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPh_ini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPh_ini.Location = New System.Drawing.Point(244, 74)
        Me.DTPh_ini.Name = "DTPh_ini"
        Me.DTPh_ini.ShowUpDown = True
        Me.DTPh_ini.Size = New System.Drawing.Size(96, 20)
        Me.DTPh_ini.TabIndex = 127
        Me.DTPh_ini.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'Lblht
        '
        Me.Lblht.AutoSize = True
        Me.Lblht.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblht.Location = New System.Drawing.Point(364, 77)
        Me.Lblht.Name = "Lblht"
        Me.Lblht.Size = New System.Drawing.Size(65, 16)
        Me.Lblht.TabIndex = 126
        Me.Lblht.Text = "Termina a: "
        '
        'Lblhi
        '
        Me.Lblhi.AutoSize = True
        Me.Lblhi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblhi.Location = New System.Drawing.Point(140, 77)
        Me.Lblhi.Name = "Lblhi"
        Me.Lblhi.Size = New System.Drawing.Size(74, 16)
        Me.Lblhi.TabIndex = 125
        Me.Lblhi.Text = "Comienza a: "
        '
        'ChkHora
        '
        Me.ChkHora.Checked = True
        Me.ChkHora.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkHora.Location = New System.Drawing.Point(20, 72)
        Me.ChkHora.Name = "ChkHora"
        Me.ChkHora.Size = New System.Drawing.Size(112, 24)
        Me.ChkHora.TabIndex = 124
        Me.ChkHora.Text = "Por Horas:"
        '
        'DTPF_Fin
        '
        Me.DTPF_Fin.CustomFormat = "dd/MM/yyyy"
        Me.DTPF_Fin.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPF_Fin.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPF_Fin.Location = New System.Drawing.Point(444, 35)
        Me.DTPF_Fin.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPF_Fin.Name = "DTPF_Fin"
        Me.DTPF_Fin.Size = New System.Drawing.Size(95, 20)
        Me.DTPF_Fin.TabIndex = 123
        '
        'Lblft
        '
        Me.Lblft.AutoSize = True
        Me.Lblft.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblft.Location = New System.Drawing.Point(364, 37)
        Me.Lblft.Name = "Lblft"
        Me.Lblft.Size = New System.Drawing.Size(65, 16)
        Me.Lblft.TabIndex = 122
        Me.Lblft.Text = "Termina a: "
        '
        'Lblfi
        '
        Me.Lblfi.AutoSize = True
        Me.Lblfi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblfi.Location = New System.Drawing.Point(140, 37)
        Me.Lblfi.Name = "Lblfi"
        Me.Lblfi.Size = New System.Drawing.Size(74, 16)
        Me.Lblfi.TabIndex = 121
        Me.Lblfi.Text = "Comienza a: "
        '
        'DTPF_Ini
        '
        Me.DTPF_Ini.CustomFormat = "dd/MM/yyyy"
        Me.DTPF_Ini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPF_Ini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPF_Ini.Location = New System.Drawing.Point(244, 35)
        Me.DTPF_Ini.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPF_Ini.Name = "DTPF_Ini"
        Me.DTPF_Ini.Size = New System.Drawing.Size(95, 20)
        Me.DTPF_Ini.TabIndex = 120
        '
        'ChkFechas
        '
        Me.ChkFechas.Checked = True
        Me.ChkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkFechas.Location = New System.Drawing.Point(20, 32)
        Me.ChkFechas.Name = "ChkFechas"
        Me.ChkFechas.Size = New System.Drawing.Size(112, 24)
        Me.ChkFechas.TabIndex = 119
        Me.ChkFechas.Text = "Por Fechas:"
        '
        'TbPTemas
        '
        Me.TbPTemas.Controls.Add(Me.LbltvTemas)
        Me.TbPTemas.Controls.Add(Me.DTP_DGNFin)
        Me.TbPTemas.Controls.Add(Me.Label5)
        Me.TbPTemas.Controls.Add(Me.Lbldgn)
        Me.TbPTemas.Controls.Add(Me.DTP_DGNini)
        Me.TbPTemas.Controls.Add(Me.ChkF_DGN)
        Me.TbPTemas.Controls.Add(Me.DTP_Pubfin)
        Me.TbPTemas.Controls.Add(Me.Label3)
        Me.TbPTemas.Controls.Add(Me.Lblpub)
        Me.TbPTemas.Controls.Add(Me.DTP_Pubini)
        Me.TbPTemas.Controls.Add(Me.ChkF_Public)
        Me.TbPTemas.Controls.Add(Me.TVTemas)
        Me.TbPTemas.Controls.Add(Me.Lbltemas)
        Me.TbPTemas.Controls.Add(Me.ChkTemas)
        Me.TbPTemas.Controls.Add(Me.Lbletapas)
        Me.TbPTemas.Controls.Add(Me.CBoEtapa)
        Me.TbPTemas.Controls.Add(Me.ChkEtapas)
        Me.TbPTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TbPTemas.Location = New System.Drawing.Point(4, 23)
        Me.TbPTemas.Name = "TbPTemas"
        Me.TbPTemas.Size = New System.Drawing.Size(560, 285)
        Me.TbPTemas.TabIndex = 1
        Me.TbPTemas.Text = "Temas"
        '
        'LbltvTemas
        '
        Me.LbltvTemas.AutoSize = True
        Me.LbltvTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.LbltvTemas.Location = New System.Drawing.Point(56, 192)
        Me.LbltvTemas.Name = "LbltvTemas"
        Me.LbltvTemas.Size = New System.Drawing.Size(0, 16)
        Me.LbltvTemas.TabIndex = 138
        Me.LbltvTemas.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.LbltvTemas.Visible = False
        '
        'DTP_DGNFin
        '
        Me.DTP_DGNFin.CustomFormat = "dd/MM/yyyy"
        Me.DTP_DGNFin.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTP_DGNFin.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_DGNFin.Location = New System.Drawing.Point(449, 115)
        Me.DTP_DGNFin.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTP_DGNFin.Name = "DTP_DGNFin"
        Me.DTP_DGNFin.Size = New System.Drawing.Size(95, 20)
        Me.DTP_DGNFin.TabIndex = 137
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label5.Location = New System.Drawing.Point(384, 117)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 16)
        Me.Label5.TabIndex = 136
        Me.Label5.Text = "Termina a: "
        '
        'Lbldgn
        '
        Me.Lbldgn.AutoSize = True
        Me.Lbldgn.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lbldgn.Location = New System.Drawing.Point(160, 117)
        Me.Lbldgn.Name = "Lbldgn"
        Me.Lbldgn.Size = New System.Drawing.Size(74, 16)
        Me.Lbldgn.TabIndex = 135
        Me.Lbldgn.Text = "Comienza a: "
        '
        'DTP_DGNini
        '
        Me.DTP_DGNini.CustomFormat = "dd/MM/yyyy"
        Me.DTP_DGNini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTP_DGNini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_DGNini.Location = New System.Drawing.Point(256, 115)
        Me.DTP_DGNini.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTP_DGNini.Name = "DTP_DGNini"
        Me.DTP_DGNini.Size = New System.Drawing.Size(95, 20)
        Me.DTP_DGNini.TabIndex = 134
        '
        'ChkF_DGN
        '
        Me.ChkF_DGN.Checked = True
        Me.ChkF_DGN.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkF_DGN.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.ChkF_DGN.Location = New System.Drawing.Point(16, 112)
        Me.ChkF_DGN.Name = "ChkF_DGN"
        Me.ChkF_DGN.Size = New System.Drawing.Size(136, 24)
        Me.ChkF_DGN.TabIndex = 133
        Me.ChkF_DGN.Text = "Por Fecha de Envi� a DGN:"
        '
        'DTP_Pubfin
        '
        Me.DTP_Pubfin.CustomFormat = "dd/MM/yyyy"
        Me.DTP_Pubfin.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTP_Pubfin.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_Pubfin.Location = New System.Drawing.Point(449, 75)
        Me.DTP_Pubfin.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTP_Pubfin.Name = "DTP_Pubfin"
        Me.DTP_Pubfin.Size = New System.Drawing.Size(95, 20)
        Me.DTP_Pubfin.TabIndex = 132
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label3.Location = New System.Drawing.Point(384, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 16)
        Me.Label3.TabIndex = 131
        Me.Label3.Text = "Termina a: "
        '
        'Lblpub
        '
        Me.Lblpub.AutoSize = True
        Me.Lblpub.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lblpub.Location = New System.Drawing.Point(160, 77)
        Me.Lblpub.Name = "Lblpub"
        Me.Lblpub.Size = New System.Drawing.Size(74, 16)
        Me.Lblpub.TabIndex = 130
        Me.Lblpub.Text = "Comienza a: "
        '
        'DTP_Pubini
        '
        Me.DTP_Pubini.CustomFormat = "dd/MM/yyyy"
        Me.DTP_Pubini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTP_Pubini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_Pubini.Location = New System.Drawing.Point(256, 75)
        Me.DTP_Pubini.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTP_Pubini.Name = "DTP_Pubini"
        Me.DTP_Pubini.Size = New System.Drawing.Size(95, 20)
        Me.DTP_Pubini.TabIndex = 129
        '
        'ChkF_Public
        '
        Me.ChkF_Public.Checked = True
        Me.ChkF_Public.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkF_Public.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.ChkF_Public.Location = New System.Drawing.Point(16, 72)
        Me.ChkF_Public.Name = "ChkF_Public"
        Me.ChkF_Public.Size = New System.Drawing.Size(136, 24)
        Me.ChkF_Public.TabIndex = 128
        Me.ChkF_Public.Text = "Por Fechas de Publicaci�n:"
        '
        'TVTemas
        '
        Me.TVTemas.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.TVTemas.ImageList = Me.imgListTreeView2
        Me.TVTemas.Location = New System.Drawing.Point(256, 156)
        Me.TVTemas.Name = "TVTemas"
        Me.TVTemas.Size = New System.Drawing.Size(288, 124)
        Me.TVTemas.TabIndex = 127
        '
        'imgListTreeView2
        '
        Me.imgListTreeView2.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView2.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView2.ImageStream = CType(resources.GetObject("imgListTreeView2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView2.TransparentColor = System.Drawing.Color.Transparent
        '
        'Lbltemas
        '
        Me.Lbltemas.AutoSize = True
        Me.Lbltemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lbltemas.Location = New System.Drawing.Point(160, 165)
        Me.Lbltemas.Name = "Lbltemas"
        Me.Lbltemas.Size = New System.Drawing.Size(47, 16)
        Me.Lbltemas.TabIndex = 126
        Me.Lbltemas.Text = "Temas: "
        '
        'ChkTemas
        '
        Me.ChkTemas.Checked = True
        Me.ChkTemas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.ChkTemas.Location = New System.Drawing.Point(16, 160)
        Me.ChkTemas.Name = "ChkTemas"
        Me.ChkTemas.Size = New System.Drawing.Size(136, 24)
        Me.ChkTemas.TabIndex = 125
        Me.ChkTemas.Text = "Por Temas:"
        '
        'Lbletapas
        '
        Me.Lbletapas.AutoSize = True
        Me.Lbletapas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lbletapas.Location = New System.Drawing.Point(160, 32)
        Me.Lbletapas.Name = "Lbletapas"
        Me.Lbletapas.Size = New System.Drawing.Size(104, 16)
        Me.Lbletapas.TabIndex = 124
        Me.Lbletapas.Text = "Etapas de Temas: "
        '
        'CBoEtapa
        '
        Me.CBoEtapa.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CBoEtapa.Location = New System.Drawing.Point(256, 29)
        Me.CBoEtapa.Name = "CBoEtapa"
        Me.CBoEtapa.Size = New System.Drawing.Size(288, 22)
        Me.CBoEtapa.TabIndex = 123
        '
        'ChkEtapas
        '
        Me.ChkEtapas.Checked = True
        Me.ChkEtapas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkEtapas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.ChkEtapas.Location = New System.Drawing.Point(16, 27)
        Me.ChkEtapas.Name = "ChkEtapas"
        Me.ChkEtapas.Size = New System.Drawing.Size(136, 24)
        Me.ChkEtapas.TabIndex = 122
        Me.ChkEtapas.Text = "Por Etapas:"
        '
        'frmCons_sesiones
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(806, 638)
        Me.Controls.Add(Me.TxtTotal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.DGridResultados)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.tvComites)
        Me.Controls.Add(Me.TbCCriterios)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCons_sesiones"
        Me.Text = "Consultas - Sesiones"
        Me.TransparencyKey = System.Drawing.SystemColors.AppWorkspace
        CType(Me.DGridResultados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TbCCriterios.ResumeLayout(False)
        Me.TbPCalendario.ResumeLayout(False)
        Me.TbPSesiones.ResumeLayout(False)
        Me.TbPTemas.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#End Region

#Region "  Otras Variables"

    Private oVista As DataView
    Dim dvComite As DataView
    Dim dvCT As DataView
    Dim dvC As DataView
    Dim dvGT As DataView
    Dim DTRes As New DataTable ''' datos editables para restaurar
    Dim DTResTem As New DataTable ''' datos editables para restaurar
    Dim DTResArch As New DataTable ''' datos editables para restaurar
    Dim dTimpresion As New DataTable
    Dim existe, Accion As Boolean
    Dim ValEditar As Integer
    Dim sError, iEditar, sValTreeView, sFechaPk, shoraiPk, shoratPk, sReubica As String
    Dim sesion, i, solicitud, istasol, istasesion As Integer

#End Region

#Region " Metodos y Procesos"

#Region "Funciones - Sesiones(comite, CT, SC, grupo, compara) As DataTable, Metodos y Procesos"

    Private Function sesiones(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String, ByVal bandera As Integer) As DataTable
        Cursor.Current = Cursors.WaitCursor
        Dim combotable As DataTable
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columNA As DataColumn
        Try
            With objsesiones
                .Bandera = bandera
                .Id_Comite = comite
                .Id_CT = CT
                .Id_SC = SC
                .Id_Grupo = grupo
                combotable = .Listar()
            End With
            If bandera = 16 Then
                If CT <> "NA" Then
                    comite = CT
                ElseIf SC <> "NA" Then
                    comite = SC
                ElseIf grupo <> "NA" Then
                    comite = grupo
                End If
                combotable.Columns.Add("Numero")
                iNumero = 0
                For Each regs In combotable.Rows
                    iNumero = iNumero + 1
                    combotable.Rows(iNumero - 1).Item("Numero") = Format$(iNumero, "000") + "/" + Format$(CDate(regs("Fecha")), "yy") + " " + comite
                Next


            End If
            Dim cm As CurrencyManager
            cm = CType(BindingContext(combotable), CurrencyManager)
            'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyMaNAger
            Dim Dv As DataView = CType(cm.List, DataView)
            'AsigNAmos el valor que deseamos para evitar o permitir nuevos registros
            If compara.Length > 0 Then Dv.RowFilter = compara
            Dv.AllowNew = False
            Dv.AllowEdit = False
            Dv.AllowDelete = False
            TxtTotal.Text = Dv.Count()
            dTimpresion = Dv.Table.Clone
            Dim drv As DataRowView
            For Each drv In Dv
                dTimpresion.ImportRow(drv.Row)
            Next
            Return combotable
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Function

#End Region

#Region "Funcion - Valida(casos), Metodos y Procesos"

    Private Function Valida(ByVal casos As String) As Boolean
        Dim aCasos As Array
        Dim valreturn As Boolean = True
        aCasos = Split(casos, " _#_ ")
        Select Case aCasos(0)
            Case "comites"
                If LblTreeView.Text.Length <= 0 Then
                    ErrorProvider1.SetError(Lblcomite, "Debes seleccioNAr un Comite")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblcomite, "")
                End If
            Case "temas"
                If TVTemas.Parent.Name <> "SeleccioNA un Tema" Then
                    ErrorProvider1.SetError(Lbltemas, "Debes seleccioNAr un Tema")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lbltemas, "")
                End If
            Case "Fechas"
                If CStr(DTPF_Ini.Value) = "" And CStr(DTPF_Fin.Value) = "" Then
                    ErrorProvider1.SetError(Lblfi, "Debes seleccioNAr la fecha de tu periodo de busqueda")
                    valreturn = False
                ElseIf Not DTPF_Ini.Value > DTPF_Fin.Value Then
                    ErrorProvider1.SetError(Lblfi, "")
                Else
                    ErrorProvider1.SetError(Lblfi, "No se puede realizar uNA consulta de" & Chr(13) & "sesi�n con un periodo incorrecto.")
                    valreturn = False
                End If
            Case "Fecha_pub"
                If CStr(DTP_Pubini.Value) = "" And CStr(DTP_Pubfin.Value) = "" Then
                    ErrorProvider1.SetError(Lblpub, "Debes seleccioNAr la fecha de tu periodo de busqueda")
                    valreturn = False
                ElseIf Not DTP_Pubini.Value > DTP_Pubfin.Value Then
                    ErrorProvider1.SetError(Lblpub, "")
                Else
                    ErrorProvider1.SetError(Lblpub, "No se puede realizar uNA consulta de" & Chr(13) & "sesi�n con un periodo incorrecto.")
                    valreturn = False
                End If
            Case "Fecha_DGN"
                If CStr(DTP_DGNini.Value) = "" And CStr(DTP_DGNFin.Value) = "" Then
                    ErrorProvider1.SetError(Lbldgn, "Debes seleccioNAr la fecha de tu periodo de busqueda")
                    valreturn = False
                ElseIf Not DTP_DGNini.Value > DTP_DGNFin.Value Then
                    ErrorProvider1.SetError(Lbldgn, "")
                Else
                    ErrorProvider1.SetError(Lbldgn, "No se puede realizar uNA consulta de" & Chr(13) & "sesi�n con un periodo incorrecto.")
                    valreturn = False
                End If
            Case "Horas"
                If CStr(DTPh_ini.Value) = "" And CStr(DTPh_tem.Value) = "" Then
                    ErrorProvider1.SetError(Lblhi, "Debes seleccioNAr la fecha de tu periodo de busqueda")
                    valreturn = False
                ElseIf Not DTPh_ini.Value > DTPh_tem.Value Then
                    ErrorProvider1.SetError(Lblhi, "")
                Else
                    ErrorProvider1.SetError(Lblhi, "No se puede realizar uNA consulta de" & Chr(13) & "sesi�n con un periodo incorrecto.")
                    valreturn = False
                End If
            Case "Responsable"
                If CboResponsable.ValueMember = "" Then
                    ErrorProvider1.SetError(LblResp, "Debes seleccioNAr el nombre del responsable" & Chr(13) & "para la busqueda")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(LblResp, "")
                End If
            Case "Lugar"
                If TxtLugar.Text.Trim = "" Then
                    ErrorProvider1.SetError(Lbllugar, "Debes escribir el lugar de la sesion que deseas buscar")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lbllugar, "")
                End If
            Case "status"
                If cbostatus.ValueMember = "" Then
                    ErrorProvider1.SetError(Lblstatus, "Debes seleccioNAr el estado que quieres  buscar")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblstatus, "")
                End If
        End Select
        Return valreturn
    End Function

#End Region

#Region " Funci�n - NewLinea(dr, com, OptioNAl ct, OptioNAl  sc , OptioNAl  gp ) As DataRow"

    Private Function NewLinea(ByVal dr As DataRow, ByVal com As String, Optional ByVal ct As String = "NA", Optional ByVal sc As String = "NA", Optional ByVal gp As String = "NA") As DataRow
        Dim RegCon As DataRow
        Dim dt1 As DataTable
        If gp = "NA" Then
            If sc = "NA" Then
                If ct = "NA" Then
                    dr("Comite") = com
                Else
                    dr("Comite") = ct
                End If
            Else
                dr("Comite") = sc
            End If
        Else
            dr("Comite") = gp
        End If

        For i = 1 To 12
            With objsesiones
                .Bandera = 20
                .Id_Comite = com
                .Id_CT = ct
                .Id_SC = sc
                .Id_Grupo = gp
                .HoraI = i
                .Fecha = DTPPerini.Value
                dt1 = .Listar()
                If dt1.Rows.Count > 0 Then
                    Dim contador = 0
                    For Each RegCon In dt1.Rows
                        contador = 1 + contador
                        dr(i) = dr(i) + ", " + Format(CDate(RegCon("fecha")), "dd")
                        If contador = 3 Then dr(i) = dr(i) + vbCrLf : contador = 0
                    Next
                    If Mid(dr(i).Trim, 1, 2) = ", " Then dr(i) = Mid(dr(i).Trim, 3, dr(i).Length)
                    dr("Horario") = IIf(IsDBNull(RegCon("horario")), " ", RegCon("horario"))
                    dr("Lugar") = IIf(IsDBNull(RegCon("Lugar")), " ", RegCon("Lugar"))
                Else
                    dr(i) = " "
                End If
            End With
        Next

        Return dr
    End Function

#End Region

#Region " Funci�n - NewLineames(dr, com, OptioNAl ct, OptioNAl  sc , OptioNAl  gp ) As DataRow"

    Private Function NewLineames(ByVal dt As DataTable, ByVal com As String, Optional ByVal ct As String = "NA", Optional ByVal sc As String = "NA", Optional ByVal gp As String = "NA")
        Dim RegCon As DataRow
        Dim dt1 As DataTable
        Dim i As Integer = 1
        Dim da, ds As DateTime
        Dim days As Integer
        Dim fecha As Date
        Dim bandera As Integer = 0
        With objsesiones
            .Bandera = 20
            .Id_Comite = com
            .Id_CT = ct
            .Id_SC = sc
            .Id_Grupo = gp
            .HoraI = CInt(Format(DTPMes.Value, "MM"))
            .Fecha = DTPPerini.Value
            dt1 = .Listar()
            For days = 1 To da.DaysInMonth(CInt(Format(DTPPerini.Value, "yyyy")), CInt(Format(DTPMes.Value, "MM")))
                Dim dr As DataRow
                fecha = CDate(CStr(days) + "/" + Format(DTPMes.Value, "MM") + "/" + Format(DTPPerini.Value, "yyyy"))
                If bandera = 0 And (days = 1 Or Format(fecha, "dddd") = "Lunes") Then
                    dr = dt.NewRow
                    bandera = 1
                End If
                For Each RegCon In dt1.Rows
                    If gp = "NA" Then
                        If sc = "NA" Then
                            If ct = "NA" Then
                                dr("Comite") = com
                            Else
                                dr("Comite") = ct
                            End If
                        Else
                            dr("Comite") = sc
                        End If
                    Else
                        dr("Comite") = gp
                    End If
                    If Format(fecha, "dddd") <> "S�bado" And Format(fecha, "dddd") <> "Domingo" Then
                        If Format(fecha, "dd/MM/yyyy") = Format(RegCon("fecha"), "dd/MM/yyyy") Then
                            dr(Format(RegCon("fecha"), "dddd")) = Format(RegCon("fecha"), "dd") + vbCrLf + RegCon("horario") + vbCrLf + RegCon("lugar")
                            Exit For
                        Else
                            dr(Format(fecha, "dddd")) = CStr(days)
                        End If
                    End If
                Next
                If bandera = 1 And ((Format(fecha, "dddd")) = "Viernes" Or da.DaysInMonth(CInt(Format(DTPPerini.Value, "yyyy")), CInt(Format(DTPMes.Value, "MM"))) = days) Then
                    dt.Rows.Add(dr)
                    bandera = 0
                End If
            Next
        End With

    End Function

#End Region

#Region "Sub - Buscar, Metodos y Procesos"

    Private Sub buscar()
        Dim lblarray, lblarray2 As Array
        Dim compara As String = ""
        lblarray = Split(sReubica, " \ ")
        lblarray2 = Split(LbltvTemas.Text, " - ")
        Dim bandera = 29 '16
        If Valida("comites") Then
            Select Case TbCCriterios.SelectedTab.Name
                Case "TbPSesiones"
                    Call DGStySesiones16()
                    If Valida("Fechas") And ChkFechas.Checked Then compara = compara + " and fecha>='" + DTPF_Ini.Text.Trim + "' and fecha<='" + DTPF_Fin.Text.Trim + "'"
                    If Valida("Horas") And ChkHora.Checked Then compara = compara + " and horai >= '" + DTPh_ini.Text.Trim + "' and horai<='" + DTPh_tem.Text.Trim + "' and horat >= '" + DTPh_ini.Text.Trim + "' and horat<='" + DTPh_tem.Text.Trim + "'"
                    If ChkResponsable.Checked Then If Valida("Responsable") Then compara = compara + " and Responsable='" + CboResponsable.Text + "'"
                    If Chklugar.Checked Then If Valida("Lugar") Then compara = compara + " and Lugar like '%" + TxtLugar.Text + "%'"
                    If ChKStatus.Checked Then If Valida("status") Then compara = compara + " and Descripcion='" + cbostatus.Text + "'"
                Case "TbPTemas"
                    DGStySesiones1708()
                    bandera = 30 '18
                    If ChkEtapas.Checked Then If Valida("etapas") Then compara = compara + " and id_etapa=" + CStr(CBoEtapa.SelectedValue)
                    'If Valida("Fecha_pub") And ChkF_Public.Checked And (ChkEtapas.Checked And Valida("etapas") And CBoEtapa.SelectedValue = 4) Then compara = compara + " and Desde>='" + DTP_Pubini.Text.Trim + "' and desde<='" + DTP_Pubfin.Text.Trim + "'"
                    'If Valida("Fecha_DGN") And ChkF_DGN.Checked And (ChkEtapas.Checked And Valida("etapas") And CBoEtapa.SelectedValue = 5) Then compara = compara + " and Desde>='" + DTP_DGNini.Text.Trim + "' and desde<='" + DTP_DGNFin.Text.Trim + "'"
                    If Valida("Fecha_pub") And ChkF_Public.Checked Then compara = compara + " and F_primpub >= '" & DTP_Pubini.Value & "' and F_primpub <= '" & DTP_Pubfin.Value & "'"
                    If Valida("Fecha_DGN") And ChkF_DGN.Checked Then compara = compara + " and F_ACUSE_DGN_PROYF >= '" & DTP_DGNini.Value & "' and F_ACUSE_DGN_PROYF <= '" & DTP_DGNFin.Value & "'"
                    If ChkTemas.Checked Then compara = " ID_tema = '" & stema & "' and id_plan = '" & splan & "'"
                    If ChkTemas.Checked Then
                        Select Case lblarray2.Length
                            Case 1
                                compara = compara + " and id_plan>='" + lblarray2(0) + "'"
                            Case 2
                                compara = compara + " and id_plan>='" + lblarray2(0) + "' and id_tema=" + lblarray2(1)
                        End Select
                    End If
            End Select
            If Mid(compara.Trim, 1, 3) = "and" Then compara = Mid(compara.Trim, 4, compara.Length)
            Select Case lblarray.Length
                Case 1
                    DGridResultados.DataSource = sesiones(lblarray(0), "NA", "NA", "NA", compara, bandera)
                Case 2
                    DGridResultados.DataSource = sesiones(lblarray(0), lblarray(1), "NA", "NA", compara, bandera)
                Case 3
                    DGridResultados.DataSource = sesiones(lblarray(0), lblarray(1), lblarray(2), "NA", compara, bandera)
                Case 4
                    DGridResultados.DataSource = sesiones(lblarray(0), lblarray(1), lblarray(2), lblarray(3), compara, bandera)
            End Select
        End If
        DGridResultados.Refresh()


    End Sub

#End Region

#Region "Sub - Calendario, Metodos y Procesos"

    Private Sub Calendario()
        Dim ComiteAnt, CTAnt, SCAnt , GTAnt As String
        Dim RegComite, RegCT, RegSC, RegGT, RegCon As DataRow
        Dim DtCalen As DataTable = New DataTable("clsSesiones")
        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable
        Dim lblarray As Array = Split(sReubica, " \ ")
        If ChkAnual.Checked And ChkMes.Checked Then
            Dim dt1 As DataTable
            Call Calendario2()
            If DtCalen.Columns.Count > 0 Then DtCalen.Clear()
            DtCalen.Columns.Add("Comite")
            DtCalen.Columns.Add("Lunes")
            DtCalen.Columns.Add("Martes")
            DtCalen.Columns.Add("Mi�rcoles")
            DtCalen.Columns.Add("Jueves")
            DtCalen.Columns.Add("Viernes")
            oTablaComite = objNodos.ListaComite
            For Each RegComite In oTablaComite.Rows
                NewLineames(DtCalen, RegComite("ID_Comite"))
                ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
                oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))
                For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS                   
                    CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                    If CTAnt <> ComiteAnt Then NewLineames(DtCalen, RegComite("ID_Comite"), RegCT("ID_CT"))
                    oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))
                    For Each RegSC In oTablaSC.Rows '******SUB COMITE
                        SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                        If SCAnt <> CTAnt And SCAnt <> ComiteAnt Then NewLineames(DtCalen, RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"))
                        oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"))
                        For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                            GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                            If GTAnt <> SCAnt And GTAnt <> CTAnt And GTAnt <> ComiteAnt Then NewLineames(DtCalen, RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"))
                        Next
                    Next
                Next
            Next

        ElseIf ChkAnual.Checked Then
            Dim dr As DataRow
            Call Calendario1()
            If DtCalen.Columns.Count > 0 Then DtCalen.Clear()
            DtCalen.Columns.Add("Comite")

            DtCalen.Columns.Add("Ene")
            DtCalen.Columns.Add("Feb")
            DtCalen.Columns.Add("Mar")
            DtCalen.Columns.Add("Abr")
            DtCalen.Columns.Add("May")
            DtCalen.Columns.Add("Jun")
            DtCalen.Columns.Add("Jul")
            DtCalen.Columns.Add("Ago")
            DtCalen.Columns.Add("Sep")
            DtCalen.Columns.Add("Oct")
            DtCalen.Columns.Add("Nov")
            DtCalen.Columns.Add("Dic")
            DtCalen.Columns.Add("Horario")
            DtCalen.Columns.Add("Lugar")
            oTablaComite = objNodos.ListaComite
            For Each RegComite In oTablaComite.Rows
                dr = DtCalen.NewRow
                DtCalen.Rows.Add(NewLinea(dr, RegComite("ID_Comite")))
                oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))
                ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
                For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                    dr = DtCalen.NewRow
                    CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                    If CTAnt <> ComiteAnt Then DtCalen.Rows.Add(NewLinea(dr, RegComite("ID_Comite"), RegCT("ID_CT")))
                    oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))
                    For Each RegSC In oTablaSC.Rows '******SUB COMITE
                        dr = DtCalen.NewRow
                        SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                        If SCAnt <> CTAnt And SCAnt <> ComiteAnt Then DtCalen.Rows.Add(NewLinea(dr, RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")))
                        oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"))
                        For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                            dr = DtCalen.NewRow
                            GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                            If GTAnt <> SCAnt And GTAnt <> CTAnt And GTAnt <> ComiteAnt Then DtCalen.Rows.Add(NewLinea(dr, RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo")))
                        Next
                    Next
                Next
            Next
            DGridResultados.DataSource = DtCalen
            dTimpresion = DtCalen
            DGridResultados.Refresh()
        End If
        If DtCalen.Rows.Count > 0 Then
            Dim cm As CurrencyManager
            cm = CType(BindingContext(DtCalen), CurrencyManager)
            'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyMaNAger
            Dim Dv As DataView = CType(cm.List, DataView)
            'AsigNAmos el valor que deseamos para evitar o permitir nuevos registros
            If LblTreeView.Text.Trim <> "" Then
                If lblarray.Length > 0 Then
                    Dim com As String
                    com = lblarray(0)
                    If lblarray(1) <> "NA" Then com = lblarray(1)
                    If lblarray(2) <> "NA" Then com = lblarray(2)
                    If lblarray(3) <> "NA" Then com = lblarray(3)
                    Dv.RowFilter = "isnull(Comite,'null')<>'null' and  Comite='" + com + "'"
                End If
            Else
                Dv.RowFilter = "isnull(comite,'null')<>'null'"
            End If
            Dv.AllowNew = False
            Dv.AllowEdit = False
            Dv.AllowDelete = False
            DGridResultados.DataSource = DtCalen
            dTimpresion = Dv.Table.Clone
            Dim drv As DataRowView
            For Each drv In Dv
                dTimpresion.ImportRow(drv.Row)
            Next
            DGridResultados.Refresh()
            TxtTotal.Text = Dv.Count
        End If
    End Sub

#End Region

#Region "Sub - CreAsistencia, Metodos y Procesos"

    Private Sub CreAsistencia()
        Cursor.Current = Cursors.WaitCursor
        Dim combotable As DataTable
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim lblarray As Array
        Dim compara As String = ""
        Dim columNA As DataColumn
        Dim comite, com, ct, sc, gp As String
        Try
            Call Asistencia()
            If Valida("comites") Then
                lblarray = Split(sReubica, " \ ")
                com = lblarray(0)
                If lblarray(1) = "" Then ct = "NA" Else ct = lblarray(1)
                If lblarray(2) = "" Then sc = "NA" Else sc = lblarray(2)
                If lblarray(3) = "" Then gp = "NA" Else gp = lblarray(3)
                compara = "si"
            End If
            With objsesiones
                .Bandera = 21
                combotable = .Listar()
            End With
            combotable.Columns.Add("Comite")
            For Each regs In combotable.Rows
                iNumero = iNumero + 1
                comite = regs(0)
                If regs(1) <> "NA" Then
                    comite = regs(1)
                ElseIf regs(2) <> "NA" Then
                    comite = regs(2)
                ElseIf regs(3) <> "NA" Then
                    comite = regs(3)
                End If
                combotable.Rows(iNumero - 1).Item("Comite") = comite
            Next

            Dim cm As CurrencyManager
            cm = CType(BindingContext(combotable), CurrencyManager)
            Dim Dv As DataView = CType(cm.List, DataView)
            If compara.Length > 0 Then Dv.RowFilter = " Cve_Comite='" & com & "' and Cve_ComiteTec='" & ct & "' and  Cve_Subcomite='" & sc & "' and Cve_Grupo='" & gp & "'"
            Dv.AllowNew = False
            Dv.AllowEdit = False
            Dv.AllowDelete = False
            dTimpresion = Dv.Table.Clone
            Dim drv As DataRowView
            For Each drv In Dv
                dTimpresion.ImportRow(drv.Row)
            Next
            DGridResultados.DataSource = combotable
            DGridResultados.Refresh()
            TxtTotal.Text = Dv.Count()
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region


#End Region

#Region " CheckBox, Metodos y Procesos"

#Region " CheckBox - ChkAnual, Metodos y Procesos"

#Region " ChkAnual -  ChkAnual_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkAnual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkAnual.CheckedChanged
        If ChkAnual.Checked Then
            Activos(DTPPerini)
        Else
            Inactivos(DTPPerini)
        End If
        DTPPerini.ResetText()
    End Sub

#End Region

#Region " ChkAnual -  ChkAnual_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkAnual_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkAnual.EnabledChanged
        ChkAnual.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkEtapas, Metodos y Procesos"

#Region " Chketapas -  Chketapas_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chketapas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkEtapas.CheckedChanged
        If ChkEtapas.Checked Then
            Activos(CBoEtapa)
        Else
            Inactivos(CBoEtapa)
        End If
        CBoEtapa.ResetText()
    End Sub

#End Region

#Region " Chketapas -  Chketapas_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chketapas_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkEtapas.EnabledChanged
        ChkEtapas.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkFechas, Metodos y Procesos"

#Region " ChkFechas -  ChkFechas_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkFechas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkFechas.CheckedChanged
        If ChkFechas.Checked Then
            Activos(DTPF_Ini, DTPF_Fin)
        Else
            Inactivos(DTPF_Ini, DTPF_Fin)
        End If
        DTPF_Ini.ResetText() : DTPF_Fin.ResetText()
    End Sub

#End Region

#Region " ChkFechas -  ChkFechas_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkFechas_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkFechas.EnabledChanged
        ChkFechas.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkF_pub, Metodos y Procesos"

#Region " ChkF_public -  ChkF_public_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkF_public_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkF_Public.CheckedChanged
        If ChkF_Public.Checked Then
            Activos(DTP_Pubini, DTP_Pubfin)
        Else
            Inactivos(DTP_Pubini, DTP_Pubfin)
        End If
        DTP_Pubini.ResetText() : DTP_Pubfin.ResetText()
    End Sub

#End Region

#Region " ChkF_public -  ChkF_public_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkF_public_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkF_Public.EnabledChanged
        ChkF_Public.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkF_DGN, Metodos y Procesos"

#Region " ChkF_DGN -  ChkF_DGN_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkF_DGN_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkF_DGN.CheckedChanged
        If ChkF_DGN.Checked Then
            Activos(DTP_DGNini, DTP_DGNFin)
        Else
            Inactivos(DTP_DGNini, DTP_DGNFin)
        End If
        DTP_DGNini.ResetText() : DTP_DGNFin.ResetText()
    End Sub

#End Region

#Region " ChkF_DGN -  ChkF_DGN_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkF_DGN_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkF_DGN.EnabledChanged
        ChkF_DGN.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkHora, Metodos y Procesos"

#Region " ChkHora -  ChkHora_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkHora_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkHora.CheckedChanged
        If ChkHora.Checked Then
            Activos(DTPh_tem, DTPh_ini)
        Else
            Inactivos(DTPh_tem, DTPh_ini)
        End If
        DTPh_ini.ResetText() : DTPh_tem.ResetText()
    End Sub

#End Region

#Region " ChkHora -  ChkHora_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkHora_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkHora.EnabledChanged
        ChkHora.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - Chklugar, Metodos y Procesos"

#Region " Chklugar -  Chklugar_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chklugar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chklugar.CheckedChanged
        If Chklugar.Checked Then
            Activos(TxtLugar)
        Else
            Inactivos(TxtLugar)
        End If
        TxtLugar.ResetText()
    End Sub

#End Region

#Region " Chklugar -  Chklugar_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chklugar_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chklugar.EnabledChanged
        Chklugar.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkMes, Metodos y Procesos"

#Region " ChkMes -  ChkMes_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkMes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkMes.CheckedChanged
        If ChkMes.Checked Then
            Activos(DTPMes, ChkAnual)
        Else
            Inactivos(DTPMes)
        End If
        DTPPerini.ResetText() : DTPMes.ResetText()
    End Sub

#End Region

#Region " ChkMes -  ChkMes_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkMes_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkMes.EnabledChanged
        ChkMes.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChkResponsable, Metodos y Procesos"

#Region " ChkResponsable -  ChkResponsable_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkResponsable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkResponsable.CheckedChanged
        If ChkResponsable.Checked Then
            Activos(CboResponsable)
        Else
            Inactivos(CboResponsable)
        End If
        CboResponsable.Refresh()
    End Sub

#End Region

#Region " ChkResponsable -  ChkResponsable_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub ChkResponsable_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkResponsable.EnabledChanged
        If Not ChkResponsable.Enabled Then ChkResponsable.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - Chkstatus, Metodos y Procesos"

#Region " Chkstatus -  Chkstatus_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chkstatus_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChKStatus.CheckedChanged
        If ChKStatus.Checked Then
            Activos(cbostatus)
        Else
            Inactivos(cbostatus)
        End If
        cbostatus.ResetText()
    End Sub

#End Region

#Region " Chkstatus -  Chkstatus_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chkstatus_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChKStatus.EnabledChanged
        ChKStatus.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - Chktemas, Metodos y Procesos"

#Region " Chktemas -  Chktemas_CheckedChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chktemas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkTemas.CheckedChanged
        If ChkTemas.Checked Then
            Activos(TVTemas)
        Else
            Inactivos(TVTemas)
        End If
        cbostatus.ResetText()
    End Sub

#End Region

#Region " Chktemas -  Chktemas_ENAbledChanged( Object, EventArgs), Metodos y Procesos"

    Private Sub Chktemas_ENAbledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkTemas.EnabledChanged
        ChkTemas.Checked = False
    End Sub

#End Region

#End Region

#End Region

#Region " ComboBox - Cboetapa, Metodos y Procesos"

    Private Sub CBoEtapa_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CBoEtapa.SelectedIndexChanged
        'Inactivos(ChkF_Public, ChkF_DGN)
        Select Case CBoEtapa.SelectedValue
            Case 4
                Activos(ChkF_Public)
            Case 5
                Activos(ChkF_DGN)
        End Select
    End Sub

#End Region

#Region " DataGrid - DGridResultados, Metodos y Procesos"

#Region " DGridResultados - DGStySesiones16, Metodos y Procesos"

    Private Sub DGStySesiones16()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)
            ts1.MappingName = "clsSesiones"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Numero"
            TextCol.HeaderText = "Sesion"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol0 As New DataGridTextBoxColumn
            TextCol0.MappingName = "fecha"
            TextCol0.HeaderText = "Fecha"
            TextCol0.Width = 90
            TextCol0.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol0)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "horario"
            TextCol1.HeaderText = "Horario"
            TextCol1.Width = 110
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "asunto"
            TextCol2.HeaderText = "Asunto"
            TextCol2.Width = 210
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Responsable"
            TextCol3.HeaderText = "Responsable de Sesion"
            TextCol3.Width = 180
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "lugar"
            TextCol4.HeaderText = "Lugar"
            TextCol4.Width = 170
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

    Private Sub DGStySesiones1708()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)
            ts1.MappingName = "clsSesiones"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "ID_Tema"
            TextCol.HeaderText = "Tema"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol0 As New DataGridTextBoxColumn
            TextCol0.MappingName = "Titulo"
            TextCol0.HeaderText = "Titulo del tema"
            TextCol0.Width = 150
            TextCol0.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol0)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Fecha"
            TextCol1.HeaderText = "Fecha de la sesion"
            TextCol1.Width = 170
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Responsable"
            TextCol2.HeaderText = "Responsable"
            TextCol2.Width = 310
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "ID_Etapa"
            TextCol3.HeaderText = "ID_Etapa"
            TextCol3.Width = 0
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "f_primpub"
            TextCol4.HeaderText = "Fecha primera publicacion en el dof"
            TextCol4.Width = 0
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "F_ACUSE_DGN_PROYF"
            TextCol5.HeaderText = "Fecha acuse DGN"
            TextCol5.Width = 0
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "Id_Plan"
            TextCol6.HeaderText = "Id_Plan"
            TextCol6.Width = 0
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#Region " DGridResultados - DGStySesiones18, Metodos y Procesos"

    Private Sub DGStySesiones18()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)
            ts1.MappingName = "clsSesiones"


            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "sesiones"
            TextCol.HeaderText = "Total Sesiones"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "id_plan"
            TextCol1.HeaderText = "Plan"
            TextCol1.Width = 80
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Id_tema"
            TextCol2.HeaderText = "Tema"
            TextCol2.Width = 80
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Clasificacion"
            TextCol3.HeaderText = "Clasificaci�n"
            TextCol3.Width = 180
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Desde"
            TextCol4.HeaderText = "Inicio Periodo"
            TextCol4.Width = 90
            TextCol4.Format = "dd/MM/yyyy"
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "hasta"
            TextCol5.HeaderText = "Fin Periodo"
            TextCol5.Width = 90
            TextCol5.Format = "dd/MM/yyyy"
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "totHrsSesioNAdas"
            TextCol6.HeaderText = "Horas SesioNAdas"
            TextCol6.Width = 90
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#Region " DGridResultados - Calendario1, Metodos y Procesos"

    Private Sub Calendario1()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)

            ts1.MappingName = "clsSesiones"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Comite"
            TextCol.HeaderText = "Comite"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Ene"
            TextCol1.HeaderText = "Enero"
            TextCol1.Width = 55
            TextCol1.TextBox.WordWrap = True
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Feb"
            TextCol2.HeaderText = "Febrero"
            TextCol2.Width = 55
            TextCol2.TextBox.WordWrap = True
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Mar"
            TextCol3.HeaderText = "Marzo"
            TextCol3.Width = 50
            TextCol3.TextBox.WordWrap = True
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Abr"
            TextCol4.HeaderText = "Abril"
            TextCol4.Width = 55
            TextCol4.TextBox.WordWrap = True
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "May"
            TextCol5.HeaderText = "Mayo"
            TextCol5.Width = 55
            TextCol5.TextBox.WordWrap = True
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "Jun"
            TextCol6.HeaderText = "Junio"
            TextCol6.Width = 55
            TextCol6.TextBox.WordWrap = True
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "Jul"
            TextCol7.HeaderText = "Julio"
            TextCol7.Width = 55
            TextCol7.TextBox.WordWrap = True
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "Ago"
            TextCol8.HeaderText = "Agosto"
            TextCol8.Width = 55
            TextCol8.TextBox.WordWrap = True
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)

            Dim TextCol9 As New DataGridTextBoxColumn
            TextCol9.MappingName = "Sep"
            TextCol9.HeaderText = "Septiembre"
            TextCol9.Width = 50
            TextCol9.TextBox.WordWrap = True
            TextCol9.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol9)

            Dim TextCol10 As New DataGridTextBoxColumn
            TextCol10.MappingName = "Oct"
            TextCol10.HeaderText = "Octubre"
            TextCol10.Width = 55
            TextCol10.TextBox.WordWrap = True
            TextCol10.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol10)

            Dim TextCol11 As New DataGridTextBoxColumn
            TextCol11.MappingName = "Nov"
            TextCol11.HeaderText = "Noviembre"
            TextCol11.Width = 55
            TextCol11.TextBox.WordWrap = True
            TextCol11.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol11)

            Dim TextCol12 As New DataGridTextBoxColumn
            TextCol12.MappingName = "Dic"
            TextCol12.HeaderText = "Diciembre"
            TextCol12.Width = 55
            TextCol12.TextBox.WordWrap = True
            TextCol12.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol12)

            Dim TextCol13 As New DataGridTextBoxColumn
            TextCol13.MappingName = "Horario"
            TextCol13.HeaderText = "Horario"
            TextCol13.Width = 120
            TextCol13.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol13)

            Dim TextCol14 As New DataGridTextBoxColumn
            TextCol14.MappingName = "Lugar"
            TextCol14.HeaderText = "Sede"
            TextCol14.Width = 180
            TextCol14.TextBox.Enabled = False
            ts1.PreferredRowHeight = TextCol4.TextBox.Height * 2
            ts1.GridColumnStyles.Add(TextCol14)

            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#Region " DGridResultados - Calendario2, Metodos y Procesos"

    Private Sub Calendario2()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)

            ts1.MappingName = "clsSesiones"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Comite"
            TextCol.HeaderText = "Comite"
            TextCol.Width = 100
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol0 As New DataGridTextBoxColumn
            TextCol0.MappingName = "Lunes"
            TextCol0.HeaderText = "Lunes"
            TextCol0.Width = 100
            TextCol0.TextBox.WordWrap = True
            TextCol0.TextBox.Multiline = True
            TextCol0.TextBox.Enabled = False
            TextCol0.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol0)


            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Martes"
            TextCol1.HeaderText = "Martes"
            TextCol1.Width = 100
            TextCol1.TextBox.WordWrap = True
            TextCol1.TextBox.Multiline = True
            TextCol1.TextBox.Enabled = False
            TextCol1.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Mi�rcoles"
            TextCol2.HeaderText = "Mi�rcoles"
            TextCol2.Width = 100
            TextCol2.TextBox.WordWrap = True
            TextCol2.TextBox.Enabled = False
            TextCol2.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Jueves"
            TextCol3.HeaderText = "Jueves"
            TextCol3.Width = 100
            TextCol3.TextBox.WordWrap = True
            TextCol3.TextBox.Enabled = False
            TextCol3.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Viernes"
            TextCol4.HeaderText = "Viernes"
            TextCol4.Width = 100
            TextCol4.TextBox.WordWrap = True
            TextCol4.TextBox.Multiline = True
            TextCol4.TextBox.Enabled = False
            TextCol4.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol4)
            ts1.PreferredRowHeight = TextCol4.TextBox.Height * 2.5
            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#Region " DGridResultados - Asistencia, Metodos y Procesos"

    Private Sub Asistencia()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)

            ts1.MappingName = "clsSesiones"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Comite"
            TextCol.HeaderText = "Comite"
            TextCol.Width = 100
            TextCol.Alignment = HorizontalAlignment.Center
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol0 As New DataGridTextBoxColumn
            TextCol0.MappingName = "Nombre"
            TextCol0.HeaderText = "Nombre"
            TextCol0.Width = 150
            TextCol0.TextBox.WordWrap = True
            TextCol0.TextBox.Multiline = True
            TextCol0.TextBox.Enabled = False
            TextCol0.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol0)


            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Descripcion"
            TextCol1.HeaderText = "Cargo"
            TextCol1.Width = 120
            TextCol1.TextBox.WordWrap = True
            TextCol1.TextBox.Multiline = True
            TextCol1.TextBox.Enabled = False
            TextCol1.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Telefono"
            TextCol2.HeaderText = "T�lefono"
            TextCol2.Width = 100
            TextCol2.TextBox.WordWrap = True
            TextCol2.TextBox.Enabled = False
            TextCol2.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Fax"
            TextCol3.HeaderText = "Fax"
            TextCol3.Width = 100
            TextCol3.TextBox.WordWrap = True
            TextCol3.TextBox.Enabled = False
            TextCol3.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Mail"
            TextCol4.HeaderText = "Mail"
            TextCol4.Width = 140
            TextCol4.TextBox.WordWrap = True
            TextCol4.TextBox.Multiline = True
            TextCol4.TextBox.Enabled = False
            TextCol4.Alignment = HorizontalAlignment.Center
            ts1.GridColumnStyles.Add(TextCol4)

            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#End Region

#Region " Forms - frmCons_sesiones, Metodos y Procesos"

    Private Sub frmCons_sesiones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Llena_Plan(TVTemas)
        Cursor.Current = Cursors.WaitCursor
        Call llena_ComiteTreeView()
        objempleados.Inicializa(Application.StartupPath & "\principal.ini", "comun", gUsuario, gPasswordSql)
        objempleados.Bandera = 6
        objempleados.ListaCombo(CboResponsable)
        objsesiones.Bandera = 17
        objsesiones.ListaCombo(cbostatus)
        objprogtrab.Bandera = 16
        Dim dt As DataTable = objprogtrab.Listar()
        CBoEtapa.DisplayMember = dt.Columns(1).ColumnName
        CBoEtapa.ValueMember = dt.Columns(0).ColumnName
        CBoEtapa.DataSource = dt
        Dim min As DateTime = DateTime.Now
        Dim time As TimeSpan = New TimeSpan(min.TimeOfDay.Days, 7, 0, 0, 0)
        min = DateTime.Today.Add(time)
        DTPh_ini.MinDate = min
        DTPh_ini.MaxDate = min.AddHours(16)
        DTPh_tem.MinDate = DTPh_ini.MinDate
        DTPh_tem.MaxDate = DTPh_ini.MaxDate
        DTPMes.CustomFormat = "MMMM"
        DTPMes.Format = DateTimePickerFormat.Custom
        DTPMes.ShowUpDown = True
        DTPMes.MaxDate = "01/12/2000"
        DTPMes.MinDate = "01/01/2000"
        DTPPerini.CustomFormat = "yyyy"
        DTPPerini.Format = DateTimePickerFormat.Custom
        DTPPerini.ShowUpDown = True
        With tlbBotonera
            Inactivos(.Buttons(3), .Buttons(4), .Buttons(0), .Buttons(1), .Buttons(2), TbCCriterios)
            Checador(Chklugar, ChkResponsable, ChKStatus, ChkFechas, ChkHora, ChkEtapas, ChkTemas, ChkF_DGN, ChkF_Public, ChkAnual, ChkMes)
        End With
        Cursor.Current = Cursors.Default
    End Sub
    Sub Llena_Plan(ByVal tvplanes As Object)
        Dim oTablaPNN As DataTable
        Dim oTablaDPy As DataTable
        Dim x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
        Dim nodo1 As New TreeNode
        Dim nodo As New TreeNode

        ' defino variable del tipo DataRow
        Dim RegPNN As DataRow
        Dim RegDPy As DataRow
        oTablaPNN = x.ListaPNN("")
        tvplanes.BeginUpdate()
        nodo = tvplanes.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvplanes.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = x.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.SelectedImageIndex = 5
                nodo1.ImageIndex = 5
            Next
        Next
        tvplanes.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvplanes.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvplanes.Sorted = True
    End Sub
#End Region

#Region " TabControl - TbCCriterios, Metodos y Procesos "

#Region " TbCCriterios - TbCCriterios_SelectedIndexChanged, Metodos y Procesos "

    Private Sub TbCCriterios_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TbCCriterios.SelectedIndexChanged
        Checador(Chklugar, ChkResponsable, ChKStatus, ChkFechas, ChkHora, ChkEtapas, ChkTemas, ChkF_DGN, ChkF_Public, ChkAnual, ChkMes)
        Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(0))
        Select Case TbCCriterios.SelectedTab.Name
            Case "TbPSesiones"
                Activos(tlbBotonera.Buttons(0), tlbBotonera.Buttons(1))
            Case "TbPTemas"
                Activos(tlbBotonera.Buttons(0), tlbBotonera.Buttons(1))
            Case "TbPCalendario"
                Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(1))
        End Select
    End Sub

#End Region

#Region " TbCCriterios - TbCCriterios_ENAbledChanged, Metodos y Procesos "

    Private Sub TbCCriterios_ENAbledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TbCCriterios.EnabledChanged
        If TbCCriterios.Enabled = False Then
            Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(0))
        End If
    End Sub

#End Region

#End Region

#Region " ToolBar - tlbBotonera, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        With tlbBotonera
            Select Case tlbBotonera.Buttons.IndexOf(e.Button)
                Case 0
                    Call buscar()
                    ' INActivos(.Buttons(3), .Buttons(4), .Buttons(0), .Buttons(1), .Buttons(2))
                    Activos(.Buttons(3), .Buttons(4))
                Case 1
                    Call CreAsistencia()
                    Activos(.Buttons(3), .Buttons(4))
                Case 2
                    Call Calendario()
                    Activos(.Buttons(3), .Buttons(4))
                Case 3
                    Inactivos(.Buttons(3), .Buttons(4), .Buttons(0), .Buttons(1), .Buttons(2), TbCCriterios)
                    Checador(Chklugar, ChkResponsable, ChKStatus, ChkFechas, ChkHora, ChkEtapas, ChkTemas, ChkF_DGN, ChkF_Public, ChkAnual, ChkMes)
                Case 4
                    DataTableToExcel(CType(dTimpresion, DataTable))
                Case 6                   '''----------   Salir     --------
                    iEditar = "Espera"
                    Me.Close()
            End Select
        End With
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Tree View, Metodos y Procesos"

#Region " Tree View - ComiteTreeView, Metodos y Procesos"

#Region "  ComiteTreeView - lleNA_ComiteTreeView, Metodos y Procesos"

    Private Sub lleNA_ComiteTreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        tvComites.EndUpdate()

        tvComites.ResetText()

        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  ComiteTreeView -  tvComites_AfterSelect(Object,TreeViewEventArgs) , Control TreeView"

    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect

        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblcomite, "")
        Dim valor_nodo, valor As String
        Dim ivalor As Integer
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione el comite" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")
        With tlbBotonera
            Inactivos(.Buttons(0), .Buttons(1), .Buttons(2), TbCCriterios)
            Select Case UCase(Mid(lblarray(lblarray.Length - 1), 1, 2))
                Case "CT"
                    sReubica = lblarray(0) + " \ " + lblarray(1) + " \ NA \ NA"
                    Activos(TbCCriterios)
                Case "SC"
                    Select Case lblarray.Length
                        Case 2
                            sReubica = lblarray(0) + " \ NA \ " + lblarray(1) + " \ NA"
                        Case 3
                            sReubica = lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ NA"
                    End Select
                    Activos(TbCCriterios)
                Case "GT"
                    Select Case lblarray.Length
                        Case 2
                            sReubica = lblarray(0) + " \ NA \ NA \ " + lblarray(1)
                        Case 3
                            If UCase(Mid(lblarray(1), 1, 2)) = "CT" Then
                                sReubica = lblarray(0) + " \ " + lblarray(1) + " \ NA \ " + lblarray(2)
                            ElseIf UCase(Mid(lblarray(1), 1, 2)) = "SC" Then
                                sReubica = lblarray(0) + " \ NA \ " + lblarray(1) + " \ " + lblarray(2)
                            End If
                        Case 4
                            sReubica = lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ " + lblarray(3)
                    End Select
                    Activos(TbCCriterios)
                Case Else
                    If lblarray.Length = 1 Then
                        sReubica = lblarray(0) + " \ NA \ NA \ NA"
                    End If
                    Activos(TbCCriterios)
            End Select
            '  End If
            Call TbCCriterios_SelectedIndexChanged(TbCCriterios, e)

            'TVTemas.Nodes.Clear()
            'zok
            'Call Llena_Plan(TVTemas)


        End With
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

#Region " Tree View- TVTemas, Metodos y Procesos"

#Region "  TVTemas - LleNA_Plantreeview, Metodos y Procesos"

    Sub LleNA_Plantreeview()
        Cursor.Current = Cursors.WaitCursor
        Dim Planes As TreeNode
        Dim Plan As TreeNode
        Dim Temas As TreeNode
        Dim lblarray As Array

        lblarray = Split(LblTreeView.Text, " - ")


        Dim oTablaPlan As DataTable
        Dim oTablaTemas As DataTable

        Dim RegPlan As DataRow
        Dim RegTemas As DataRow
        objplanes.Bandera = 1
        oTablaPlan = objplanes.Listar
        TVTemas.BeginUpdate()
        Planes = TVTemas.Nodes.Add("SeleccioNA un Tema")
        Planes.ImageIndex = 3
        Planes.SelectedImageIndex = 3

        If oTablaPlan.Rows Is Nothing Then
            TVTemas.EndUpdate()
            TVTemas.AllowDrop = True
            TVTemas.Sorted = True
            Cursor.Current = Cursors.Default
            Exit Sub
        End If

        For Each RegPlan In oTablaPlan.Rows '******Planes
            Plan = Planes.Nodes.Add(Trim(RegPlan("id_plan")))
            With objprogtrab
                .ID_Comite = "NA"
                .ID_CT = "NA"
                .ID_SC = "NA"
                .ID_Grupo = "NA"
                Select Case lblarray.Length
                    Case 1
                        .ID_Comite = lblarray(0)
                    Case 2
                        .ID_Comite = lblarray(0) : .ID_CT = lblarray(1)
                    Case 3
                        .ID_Comite = lblarray(0) : .ID_CT = lblarray(1) : .ID_SC = lblarray(2)
                    Case 4
                        .ID_Comite = lblarray(0) : .ID_CT = lblarray(1) : .ID_SC = lblarray(2) : .ID_Grupo = lblarray(3)
                End Select
                .Bandera = 17
                .Id_Plan = Trim(RegPlan("id_plan"))
                oTablaTemas = .Listar
            End With
            If oTablaTemas.Rows Is Nothing Then 'Valida si no existen nodos hijos
                GoTo temas
            End If
            For Each RegTemas In oTablaTemas.Rows '******Temas de PNN
                Temas = Plan.Nodes.Add(Trim(RegTemas("id_tema")))
                Temas.ImageIndex = 6
                Temas.SelectedImageIndex = 6
            Next
temas:
        Next
        TVTemas.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVTemas.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordeNAdos
        ' TVTemas.Sorted = True
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  TVTemas - TVTemas_AfterSelect, Metodos y Procesos"

    Private Sub TVTemas_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVTemas.AfterSelect

        Dim Matriz As Array
        Dim svariable As String

            svariable = e.Node.FullPath
            Matriz = Split(svariable, "\")

            Select Case Matriz.Length
            Case 3
                splan = Matriz(1)
                stema = Matriz(2)
        End Select


            Cursor.Current = Cursors.WaitCursor
            ErrorProvider1.SetError(Lbltemas, "")
            Dim valor_nodo, valor As String
            Dim ivalor As Integer
            Dim array_texto, lblarray As Array
            Dim Nodo As TreeNode
            valor_nodo = e.Node.FullPath
            ivalor = e.Node.ImageIndex
            array_texto = Split(valor_nodo, "\")
            LbltvTemas.Text = ""
            For Each valor In array_texto
                If valor <> "SeleccioNA un Tema" Then
                    If LbltvTemas.Text = "" Then
                        LbltvTemas.Text = valor
                    Else
                        LbltvTemas.Text = LbltvTemas.Text + " - " + valor
                    End If
                End If
        Next
    End Sub

#End Region

#End Region

#End Region

#Region " DatePiker - DTPF_Fin, Metodos y Procesos"

    Private Sub DTPF_Fin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPF_Fin.ValueChanged
        Valida("Fechas")
    End Sub

#End Region

End Class
