Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections

Public Class FrmIncisos
    Inherits System.Windows.Forms.Form

#Region " Variables"

    Dim ValEditar, iEditar As Integer
    Dim selearray As Array
    Dim objclscategoria As New Cls_Tipos_RevEdit.Cls_tipos_RE("principal", gUsuario, gPasswordSql)
    Dim objincisos As New Cls_Incisos_RE.Cls_Incisos_RE("principal", gUsuario, gPasswordSql)
    Dim objstatus_revedit As New Cls_Status_Rev_Edit.Cls_Status_Rev_Edit("principal", gUsuario, gPasswordSql)

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents LblRequisito As System.Windows.Forms.Label
    Friend WithEvents LblTipoEval As System.Windows.Forms.Label
    Friend WithEvents TVRevEdt As System.Windows.Forms.TreeView
    Friend WithEvents TxtRequisito As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents CBoEvalua As System.Windows.Forms.ComboBox
    Friend WithEvents TxtDesc As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmIncisos))
        Me.TVRevEdt = New System.Windows.Forms.TreeView
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.LblRequisito = New System.Windows.Forms.Label
        Me.LblTipoEval = New System.Windows.Forms.Label
        Me.TxtRequisito = New System.Windows.Forms.TextBox
        Me.CBoEvalua = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TxtDesc = New System.Windows.Forms.TextBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.SuspendLayout()
        '
        'TVRevEdt
        '
        Me.TVRevEdt.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.TVRevEdt.ImageIndex = 2
        Me.TVRevEdt.ImageList = Me.imgListTreeView
        Me.TVRevEdt.Location = New System.Drawing.Point(8, 8)
        Me.TVRevEdt.Name = "TVRevEdt"
        Me.TVRevEdt.SelectedImageIndex = 2
        Me.TVRevEdt.Size = New System.Drawing.Size(192, 248)
        Me.TVRevEdt.TabIndex = 0
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.BlinkRate = 1000
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblcomite.Location = New System.Drawing.Point(208, 11)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(57, 15)
        Me.Lblcomite.TabIndex = 87
        Me.Lblcomite.Text = "Selecci�n: "
        '
        'LblTreeView
        '
        Me.LblTreeView.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.LblTreeView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.LblTreeView.Location = New System.Drawing.Point(280, 8)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(248, 21)
        Me.LblTreeView.TabIndex = 86
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblRequisito
        '
        Me.LblRequisito.AutoSize = True
        Me.LblRequisito.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRequisito.Location = New System.Drawing.Point(208, 47)
        Me.LblRequisito.Name = "LblRequisito"
        Me.LblRequisito.Size = New System.Drawing.Size(56, 15)
        Me.LblRequisito.TabIndex = 88
        Me.LblRequisito.Text = "Requisito: "
        '
        'LblTipoEval
        '
        Me.LblTipoEval.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTipoEval.Location = New System.Drawing.Point(208, 78)
        Me.LblTipoEval.Name = "LblTipoEval"
        Me.LblTipoEval.Size = New System.Drawing.Size(64, 24)
        Me.LblTipoEval.TabIndex = 89
        Me.LblTipoEval.Text = "Tipo de Evaluaci�n: "
        '
        'TxtRequisito
        '
        Me.TxtRequisito.Location = New System.Drawing.Point(280, 40)
        Me.TxtRequisito.Name = "TxtRequisito"
        Me.TxtRequisito.Size = New System.Drawing.Size(176, 19)
        Me.TxtRequisito.TabIndex = 90
        Me.TxtRequisito.Text = ""
        '
        'CBoEvalua
        '
        Me.CBoEvalua.Location = New System.Drawing.Point(280, 80)
        Me.CBoEvalua.Name = "CBoEvalua"
        Me.CBoEvalua.Size = New System.Drawing.Size(168, 21)
        Me.CBoEvalua.TabIndex = 91
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(208, 120)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 15)
        Me.Label1.TabIndex = 92
        Me.Label1.Text = "Descripci�n: "
        '
        'TxtDesc
        '
        Me.TxtDesc.Location = New System.Drawing.Point(280, 120)
        Me.TxtDesc.Multiline = True
        Me.TxtDesc.Name = "TxtDesc"
        Me.TxtDesc.Size = New System.Drawing.Size(248, 128)
        Me.TxtDesc.TabIndex = 93
        Me.TxtDesc.Text = ""
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdGuardar, Me.CmdBorrar, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 261)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(546, 62)
        Me.tlbBotonera.TabIndex = 117
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdGuardar
        '
        Me.CmdGuardar.ImageIndex = 2
        Me.CmdGuardar.Text = "Guardar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'FrmIncisos
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 12)
        Me.ClientSize = New System.Drawing.Size(546, 323)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TxtDesc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CBoEvalua)
        Me.Controls.Add(Me.TxtRequisito)
        Me.Controls.Add(Me.LblTipoEval)
        Me.Controls.Add(Me.LblRequisito)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.TVRevEdt)
        Me.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmIncisos"
        Me.Text = "Incisos de Revisi�n Editorial"
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Forms - FrmIncisos_Load, Metodos y procesos"

    Private Sub FrmIncisos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Cursor.Current = Cursors.WaitCursor
        Call Llena_TVRE()
        objstatus_revedit.Bandera = 1
        objstatus_revedit.ListaCombo(CBoEvalua)
        Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), CBoEvalua, TxtRequisito, TxtDesc)
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Metodos y procesos"

#Region " Funci�n - Eliminar, Metodos y Procesos"

    Private Function Eliminar() As Boolean
        Dim iregistros As Integer()
        Try
            If Len(ValEditar) > 0 Then
                objincisos.Bandera = 5
                objincisos.Id_Inciso_Rev = CInt(Mid(selearray(2), 1, 3))
                objincisos.Inactivo = 1
                objincisos.borrar()
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

#Region " Funci�n - Guarda() = Boolean, Metodos y procesos"

    Private Function Guarda() As Boolean

        If Valida("TxtDesc") Then
            With objincisos
                If iEditar = 1 Then
                    objclscategoria.Nombre_Revision = LblTreeView.Text
                    objclscategoria.Bandera = 2
                    objclscategoria.Buscar()
                    .Id_Status_Rev = CBoEvalua.SelectedValue
                    .Id_tipo_Rev = objclscategoria.Id_tipo_Rev
                    .Requisito = TxtRequisito.Text
                    .Descripcion = TxtDesc.Text
                    .Bandera = 1
                    Try
                        .Insertar()
                        Return True
                    Catch ex As Exception
                        MsgBox("Error G001 - Al intentar guardar o leer el  Registro ..." + Chr(13), MsgBoxStyle.Critical)
                        Return False
                    End Try
                ElseIf iEditar = 2 Then
                    objclscategoria.Nombre_Revision = LblTreeView.Text
                    objclscategoria.Bandera = 2
                    objclscategoria.Buscar()
                    .Id_Inciso_Rev = CInt(Mid(selearray(2), 1, 3))
                    .Id_Status_Rev = CBoEvalua.SelectedValue
                    .Id_tipo_Rev = objclscategoria.Id_tipo_Rev
                    .Requisito = TxtRequisito.Text
                    .Descripcion = TxtDesc.Text
                    .Bandera = 3
                    Try
                        .Actualizar()
                        Return True
                    Catch ex As Exception
                        MsgBox("Error G002 - Al intentar guardar o leer el  Registro ..." + Chr(13), MsgBoxStyle.Critical)
                        Return False
                    End Try
                End If
            End With
        End If
    End Function

#End Region

#Region " Funci�n - Valida(desc - String) = Boolean, Metodos y procesos"

    Private Function Valida(ByVal desc As String) As Boolean
        If desc = "TxtDesc" Then
            If TxtDesc.Text <> "" Then Return True
        End If
    End Function

#End Region

#Region " Sub - Buscar(desc - String), Metodos y procesos"

    Private Sub buscar(ByVal desc As String)
        With objincisos
            .Bandera = 3
            .Id_Inciso_Rev = CInt(desc)
            .Buscar()
            TxtRequisito.Text = .Requisito
            CBoEvalua.SelectedValue = .Id_Status_Rev
            TxtDesc.Text = .Descripcion
        End With
    End Sub

#End Region

#End Region

#Region " ToolBar  - tlbBotonera_ButtonClick, Metodos y procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0
                If selearray.Length > 0 Then
                    Call buscar(0)
                    iEditar = 1
                    Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(0), TVRevEdt)
                    Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), CBoEvalua, TxtRequisito, TxtDesc)
                End If
            Case 1
                If selearray.Length = 3 Then
                    ValEditar = objincisos.Id_Inciso_Rev
                    iEditar = 2
                    Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(0), TVRevEdt)
                    Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), CBoEvalua, TxtRequisito, TxtDesc)
                End If
            Case 2
                TVRevEdt.Nodes.Clear()
                Call Llena_TVRE()
                Call buscar(0)
                Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), CBoEvalua, TxtRequisito, TxtDesc)
                Activos(tlbBotonera.Buttons(0), TVRevEdt)
                iEditar = Nothing
            Case 3
                Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera, CBoEvalua, TxtRequisito, TxtDesc)
                If Guarda() Then
                    TVRevEdt.Nodes.Clear()
                    Call Llena_TVRE()
                    Call buscar(0)
                    Activos(tlbBotonera, tlbBotonera.Buttons(0), TVRevEdt)
                    iEditar = Nothing
                Else
                    Activos(tlbBotonera, tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), CBoEvalua, TxtRequisito, TxtDesc)
                End If
            Case 4
                If selearray.Length = 3 Then
                    Inactivos(tlbBotonera, CBoEvalua, TxtRequisito, TxtDesc)
                    If MsgBox("�Estas seguro que deseas eliminar este punto?", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                        Call Eliminar()
                        iEditar = Nothing
                        TVRevEdt.Nodes.Clear()
                        Call Llena_TVRE()
                        Call buscar(0)
                        Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
                        Activos(tlbBotonera, tlbBotonera.Buttons(0), TVRevEdt)
                    End If
                End If
            Case 6
                    Me.Dispose()
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " TreeView - TVRevEdt, Metodos y Procesos"

#Region " TVRevEdt - Llena_TVRE, Metodos y Procesos"

    Private Sub Llena_TVRE()
        Cursor.Current = Cursors.WaitCursor
        Dim Categorias As TreeNode
        Dim Categoria As TreeNode
        Dim Inciso As TreeNode
        Dim oTablaCat As DataTable
        Dim oTablaInc As DataTable
        Dim RegCat As DataRow
        Dim RegInc As DataRow
        TVRevEdt.BeginUpdate()
        Categorias = TVRevEdt.Nodes.Add("Selecciona una Categor�a")
        objclscategoria.Bandera = 1
        oTablaCat = objclscategoria.Listar
        If oTablaCat.Rows Is Nothing Then
            TVRevEdt.EndUpdate()
            TVRevEdt.AllowDrop = True
            Cursor.Current = Cursors.Default
            Exit Sub
        End If
        For Each RegCat In oTablaCat.Rows '******Categorias
            Categoria = Categorias.Nodes.Add(Trim(RegCat(1)))
            Categoria.ImageIndex = 3
            Categoria.SelectedImageIndex = 4
            objincisos.Bandera = 2
            objincisos.Id_tipo_Rev = (RegCat(0))
            oTablaInc = objincisos.Listar
            For Each RegInc In oTablaInc.Rows
                Inciso = Categoria.Nodes.Add(Format(RegInc(0), "000") + " " + Replace(Replace(RegInc(4), Chr(13), "... "), Chr(10), " "))
                objstatus_revedit.Id_Status_Rev = CInt(RegInc(2))
                objstatus_revedit.Bandera = 2
                objstatus_revedit.Buscar()
                Inciso.BackColor = System.Drawing.Color.FromName(objstatus_revedit.Color)
                Inciso.ImageIndex = 5
                Inciso.SelectedImageIndex = 5
            Next

        Next
        TVRevEdt.ShowPlusMinus = True
        TVRevEdt.EndUpdate()
        TVRevEdt.AllowDrop = True
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " TVRevEdt - TVRevEdt_AfterSelect, Metodos y Procesos"

    Private Sub TVRevEdt_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVRevEdt.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        Dim seleccion As String
        selearray = Split(e.Node.FullPath, "\")
        LblTreeView.Text = ""
        Inactivos(tlbBotonera.Buttons(0), tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
        Select Case selearray.Length
            Case 2
                LblTreeView.Text = selearray(1)
                Activos(tlbBotonera.Buttons(0), tlbBotonera.Buttons(4))
            Case 3
                LblTreeView.Text = selearray(1)
                Call buscar(Mid(selearray(2), 1, 3))
                Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(0), tlbBotonera.Buttons(4))
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

End Class
