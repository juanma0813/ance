Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms


Public Class Cls_tipos_RE

#Region " Variables"

    Private _Id_tipo_Rev As Integer
    Private _Nombre_Revision As String
    Private _Contenido As String
    Private _Inactivo As Integer

    Private _Bandera As Integer
    Private _Error As String
    ' Conexion 

    Private cn As New SqlConnection
    Private dr As SqlDataReader
    Dim objConexion As New clsConexion.cIsConexion

#End Region

#Region " Propiedades"

    Public Property Id_tipo_Rev() As Integer
        Get
            Return _Id_tipo_Rev
        End Get
        Set(ByVal Value As Integer)
            _Id_tipo_Rev = Value
        End Set
    End Property

    Public Property Inactivo() As Integer
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Integer)
            _Inactivo = Value
        End Set
    End Property

    Public Property Nombre_Revision() As String
        Get
            Return _Nombre_Revision
        End Get
        Set(ByVal Value As String)
            _Nombre_Revision = Value
        End Set
    End Property

    Public Property Contenido() As String
        Get
            Return _Contenido
        End Get
        Set(ByVal Value As String)
            _Contenido = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property

#End Region

    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
    End Sub

    Public Sub ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Tipos_Rev_Edit_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Nombre_Revision", _Nombre_Revision)
        cmd.Parameters.Add("@Contenido", _Contenido)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_TRE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return
        End Try
    End Sub

    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Tipos_Rev_Edit_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Nombre_Revision", _Nombre_Revision)
        cmd.Parameters.Add("@Contenido", _Contenido)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_TRE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

    Public Sub Buscar()
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_C_Tipos_Rev_Edit_Buscar "
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
        cmd.Parameters.Add("@Nombre_Revision", _Nombre_Revision)
        cmd.Parameters.Add("@Contenido", _Contenido)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_tipo_Rev = IIf((IsDBNull(dr("Id_tipo_Rev"))), 0, dr("Id_tipo_Rev"))
                _Nombre_Revision = IIf((IsDBNull(dr("Nombre_Revision"))), "", dr("Nombre_Revision"))
                _Contenido = IIf((IsDBNull(dr("Contenido"))), "", dr("Contenido"))
            Else
                _Id_tipo_Rev = 0
                _Contenido = ""
                _Nombre_Revision = ""
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Sub

    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "Sp_C_Tipos_Rev_Edit"
            .Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
            .Parameters.Add("@Nombre_Revision", _Nombre_Revision)
            .Parameters.Add("@Bandera", _Bandera)
        End With

        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close() 'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try


    End Function


    Public Function Insertar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "Sp_C_Tipos_Rev_Edit"
            .Parameters.Add("@Nombre_Revision", _Nombre_Revision)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function borrar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "Sp_C_Tipos_Rev_Edit"
            .Parameters.Add("@Id_tipo_Rev", _Id_tipo_Rev)
            .Parameters.Add("@Inactivo", _Inactivo)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        '
    End Function
End Class
