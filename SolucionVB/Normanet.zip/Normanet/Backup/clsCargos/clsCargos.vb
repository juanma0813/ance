Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class C_Cargos

    '''''''Declaracion de Variables Privadas
    Private dsC_Cargos As New DataSet
    Private cn As New SQLConnection
    Private _ID_Cargo As Int32
    Private _Comite As Boolean
    Private _CT As Boolean
    Private _SC As Boolean
    Private _GT As Boolean
    Private _Descripcion As String
    Private _Dependencia As Integer
    Private sSql As String
    Private _sXml As String
    Private dr As SqlDataReader
    'Private objConexion As New clsConexionArchivo.clsConexionArchivo
    Private objConexion As New clsConexion.cIsConexion

    Private _Bandera As Integer
    Private _Inactivo As Boolean


    '''''''Declaracion de Propiedades publicas
    '''Public Sub New(ByVal Identificador As Integer, ByVal Usuario As String, ByVal Password As String)
    '''    cn.ConnectionString = objConexion.Conexion(Identificador, Usuario, Password)
    '''    'cn.ConnectionString = objConexion.Conexion(0, "admsis", "admynys")

    Public Sub New(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
    End Sub


    Public Property Bandera()
        Get
            Return _Bandera
        End Get
        Set(ByVal Value)
            _Bandera = Value
        End Set
    End Property

    Public Property sXml()
        Get
            Return _sXml
        End Get
        Set(ByVal Value)
            _sXml = Value
        End Set
    End Property

    Public Property ID_Cargo()
        Get
            Return _ID_Cargo
        End Get
        Set(ByVal Value)
            _ID_Cargo = Value
        End Set
    End Property

    Public Property Comite()
        Get
            Return _Comite
        End Get
        Set(ByVal Value)
            _Comite = Value
        End Set
    End Property

    Public Property CT()
        Get
            Return _CT
        End Get
        Set(ByVal Value)
            _CT = Value
        End Set
    End Property

    Public Property SC()
        Get
            Return _SC
        End Get
        Set(ByVal Value)
            _SC = Value
        End Set
    End Property

    Public Property GT()
        Get
            Return _GT
        End Get
        Set(ByVal Value)
            _GT = Value
        End Set
    End Property

    Public Property Descripcion()
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value)
            _Descripcion = Value
        End Set
    End Property

    Public Property Dependencia()
        Get
            Return _Dependencia
        End Get
        Set(ByVal Value)
            _Dependencia = Value
        End Set
    End Property

    Public Property Inactivo() As Boolean
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Boolean)
            _Inactivo = Value
        End Set
    End Property

    '''''''''''''''''Genera una la lista de campos
    Public Sub ListaCombo(ByVal cbo As Object)
        'Public Function ListaCombo() As DataTable
        If cn.State = ConnectionState.Open Then 'funciona, pero necesito los demas valores de las columnas
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Cargo_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@xml", _sXml)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Cargo")
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(5).ColumnName ' 5 -> descripcion
            cbo.ValueMember = dt.Columns(0).ColumnName ' 0 -> ID_Cargo
            cbo.DataSource = dt
        Catch ex As Exception
            _Descripcion = ex.Message
            Return
        End Try
    End Sub

    Public Function Listar() As DataTable
        'Public Function ListaCombo() As DataTable
        If cn.State = ConnectionState.Open Then 'funciona, pero necesito los demas valores de las columnas
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Cargo_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@xml", _sXml)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Cargo")
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Descripcion = ex.Message
            Return Nothing
        End Try
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar()
        If cn.State = ConnectionState.Open Then 'funciona, pero necesito los demas valores de las columnas
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Cargo_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@xml", _sXml)
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmd.ExecuteReader()
            If dr.Read Then
                _ID_Cargo = dr("ID_Cargo")
                _Descripcion = dr("Descripcion")
                _Comite = dr("Comite")
                _CT = dr("CT")
                _SC = dr("SC")
                _GT = dr("GT") 'dr("SC")
                _Inactivo = dr("Inactivo")
            Else
                _ID_Cargo = ""
                _Descripcion = ""
                _Comite = ""
                _CT = ""
                _SC = ""
                _GT = ""
                _Inactivo = ""
            End If
            cn.Close()
        Catch ex As Exception
            '_Descripcion = ex.Message
            Return
        End Try
    End Sub

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Cargos"
            '      .Parameters.Add("@ID_Representacion", _ID_Representacion)
            .Parameters.Add("@ID_Cargo", _ID_Cargo)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Comite", _Comite)
            .Parameters.Add("@CT", _CT)
            .Parameters.Add("@SC", _SC)
            .Parameters.Add("@GT", _GT) '
            .Parameters.Add("@Dependencia", _Dependencia)
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@xml", _sXml)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function

    Public Function Insertar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Cargos"
            '      .Parameters.Add("@ID_Representacion", _ID_Representacion)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Comite", _Comite)
            .Parameters.Add("@CT", _CT)
            .Parameters.Add("@SC", _CT)
            .Parameters.Add("@GT", _GT)
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@xml", _sXml)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Terminar este, si inserta tambien envia el mensaje -12/12/06
            '''If IsNothing(cmd.Container) Then
            '''    Return MsgBox("Descripci�n repetida", MsgBoxStyle.Exclamation, "Cat�logo de Cargos")
            '''End If
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function

    Public Function Eliminar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            'cn.ConnectionString = ("Data source=ance02;initial catalog= NormaNet; user id = admsis; pwd=admynsys")
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Cargos"
            .Parameters.Add("@ID_Cargo", _ID_Cargo)
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Inactivo", _Inactivo)
            .Parameters.Add("@xml", _sXml)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            _Descripcion = ex.Message
            Return "ERROR: " & ex.Message
        End Try
    End Function

End Class

