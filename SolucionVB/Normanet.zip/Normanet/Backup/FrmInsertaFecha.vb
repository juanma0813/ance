Public Class FrmInsertaFecha
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpDeclaratoria As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.dtpDeclaratoria = New System.Windows.Forms.DateTimePicker
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(296, 48)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Inserta la fecha Declaratoria de Cancelaci�n:"
        '
        'dtpDeclaratoria
        '
        Me.dtpDeclaratoria.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpDeclaratoria.Location = New System.Drawing.Point(24, 64)
        Me.dtpDeclaratoria.Name = "dtpDeclaratoria"
        Me.dtpDeclaratoria.Size = New System.Drawing.Size(104, 20)
        Me.dtpDeclaratoria.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(136, 64)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Aceptar"
        '
        'FrmInsertaFecha
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 102)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.dtpDeclaratoria)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmInsertaFecha"
        Me.Text = "Declaratoria de Cancelaci�n:"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FrmInsertaFecha_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dtpDeclaratoria.Value = Now
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        FechaDeclaratoria = dtpDeclaratoria.Value
        Me.Dispose()
    End Sub
End Class
