Public Class FrmPrincipal
    Inherits System.Windows.Forms.Form
    Private objMenus As New clsMenus.clsMenus(2, gUsuario, gPasswordSql)
    Private objiniarray As New clsIniarray.ClsIniArray
#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents mnuCatalogos As System.Windows.Forms.MenuItem
    Friend WithEvents mnuComites As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCargos As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCategorias As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCategoriasRev As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPuntoRev As System.Windows.Forms.MenuItem
    Friend WithEvents mnuRepresentacion As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSectores As System.Windows.Forms.MenuItem
    Friend WithEvents mnuDirectorio As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProcesos As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAdmonTemas As System.Windows.Forms.MenuItem
    Friend WithEvents mnupnn As System.Windows.Forms.MenuItem
    Friend WithEvents mnupnnTemas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTraspasoTemas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAvanceTemas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAsignacionRevision As System.Windows.Forms.MenuItem
    Friend WithEvents mnnuRevisionEd As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAutorizarR As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInspPru As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCatalogoNormas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuComentarios As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProcNormal As System.Windows.Forms.MenuItem
    Friend WithEvents mnuResolCom As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProcAlter As System.Windows.Forms.MenuItem
    Friend WithEvents mnuResolucionprocAlter As System.Windows.Forms.MenuItem
    Friend WithEvents mnuNoticias As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSesiones As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCerrarSes As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHistorialSes As System.Windows.Forms.MenuItem
    Friend WithEvents mnnuSesionesPeriodicas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuConsultas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuConComentarios As System.Windows.Forms.MenuItem
    Friend WithEvents mnuconsFechas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuConsNormas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuConsSesiones As System.Windows.Forms.MenuItem
    Friend WithEvents mnuConsTemas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAdministracion As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProxsesiones As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGruposAdmin As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGestionDoctos As System.Windows.Forms.MenuItem
    Friend WithEvents Servidor As System.Windows.Forms.StatusBarPanel
    Friend WithEvents BaseDatos As System.Windows.Forms.StatusBarPanel
    Friend WithEvents Usuario As System.Windows.Forms.StatusBarPanel
    Friend WithEvents mnuPaginaWeb As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSalir As System.Windows.Forms.MenuItem
    Friend WithEvents mnuIndex As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGeneradorMenu As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGestorPaginas As System.Windows.Forms.MenuItem
    Friend WithEvents mnuRemitentes As System.Windows.Forms.MenuItem
    Friend WithEvents mnuNombramientos As System.Windows.Forms.MenuItem
    Friend WithEvents mnuReporteAsistencia As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmPrincipal))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.mnuCatalogos = New System.Windows.Forms.MenuItem
        Me.mnuComites = New System.Windows.Forms.MenuItem
        Me.mnuCargos = New System.Windows.Forms.MenuItem
        Me.mnuCategorias = New System.Windows.Forms.MenuItem
        Me.mnuCategoriasRev = New System.Windows.Forms.MenuItem
        Me.mnuPuntoRev = New System.Windows.Forms.MenuItem
        Me.mnuRepresentacion = New System.Windows.Forms.MenuItem
        Me.mnuSectores = New System.Windows.Forms.MenuItem
        Me.mnuDirectorio = New System.Windows.Forms.MenuItem
        Me.mnuRemitentes = New System.Windows.Forms.MenuItem
        Me.mnuNombramientos = New System.Windows.Forms.MenuItem
        Me.mnuProcesos = New System.Windows.Forms.MenuItem
        Me.mnuAdmonTemas = New System.Windows.Forms.MenuItem
        Me.mnupnn = New System.Windows.Forms.MenuItem
        Me.mnupnnTemas = New System.Windows.Forms.MenuItem
        Me.mnuTraspasoTemas = New System.Windows.Forms.MenuItem
        Me.mnuAvanceTemas = New System.Windows.Forms.MenuItem
        Me.mnuAsignacionRevision = New System.Windows.Forms.MenuItem
        Me.mnnuRevisionEd = New System.Windows.Forms.MenuItem
        Me.mnuAutorizarR = New System.Windows.Forms.MenuItem
        Me.mnuInspPru = New System.Windows.Forms.MenuItem
        Me.mnuCatalogoNormas = New System.Windows.Forms.MenuItem
        Me.mnuComentarios = New System.Windows.Forms.MenuItem
        Me.mnuProcNormal = New System.Windows.Forms.MenuItem
        Me.mnuResolCom = New System.Windows.Forms.MenuItem
        Me.mnuProcAlter = New System.Windows.Forms.MenuItem
        Me.mnuResolucionprocAlter = New System.Windows.Forms.MenuItem
        Me.mnuNoticias = New System.Windows.Forms.MenuItem
        Me.mnuSesiones = New System.Windows.Forms.MenuItem
        Me.mnuCerrarSes = New System.Windows.Forms.MenuItem
        Me.mnuHistorialSes = New System.Windows.Forms.MenuItem
        Me.mnnuSesionesPeriodicas = New System.Windows.Forms.MenuItem
        Me.mnuProxsesiones = New System.Windows.Forms.MenuItem
        Me.mnuGestionDoctos = New System.Windows.Forms.MenuItem
        Me.mnuConsultas = New System.Windows.Forms.MenuItem
        Me.mnuConComentarios = New System.Windows.Forms.MenuItem
        Me.mnuconsFechas = New System.Windows.Forms.MenuItem
        Me.mnuConsNormas = New System.Windows.Forms.MenuItem
        Me.mnuConsSesiones = New System.Windows.Forms.MenuItem
        Me.mnuConsTemas = New System.Windows.Forms.MenuItem
        Me.mnuPaginaWeb = New System.Windows.Forms.MenuItem
        Me.mnuIndex = New System.Windows.Forms.MenuItem
        Me.mnuGeneradorMenu = New System.Windows.Forms.MenuItem
        Me.mnuGestorPaginas = New System.Windows.Forms.MenuItem
        Me.mnuAdministracion = New System.Windows.Forms.MenuItem
        Me.mnuGruposAdmin = New System.Windows.Forms.MenuItem
        Me.mnuSalir = New System.Windows.Forms.MenuItem
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.Servidor = New System.Windows.Forms.StatusBarPanel
        Me.BaseDatos = New System.Windows.Forms.StatusBarPanel
        Me.Usuario = New System.Windows.Forms.StatusBarPanel
        Me.mnuReporteAsistencia = New System.Windows.Forms.MenuItem
        CType(Me.Servidor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Usuario, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuCatalogos, Me.mnuProcesos, Me.mnuConsultas, Me.mnuPaginaWeb, Me.mnuAdministracion, Me.mnuSalir})
        '
        'mnuCatalogos
        '
        Me.mnuCatalogos.Index = 0
        Me.mnuCatalogos.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuComites, Me.mnuCargos, Me.mnuCategorias, Me.mnuCategoriasRev, Me.mnuPuntoRev, Me.mnuRepresentacion, Me.mnuSectores, Me.mnuDirectorio, Me.mnuRemitentes, Me.mnuNombramientos, Me.mnuReporteAsistencia})
        Me.mnuCatalogos.Text = "Cat�logos"
        '
        'mnuComites
        '
        Me.mnuComites.Index = 0
        Me.mnuComites.Text = "Comit�s"
        '
        'mnuCargos
        '
        Me.mnuCargos.Index = 1
        Me.mnuCargos.Text = "Cargos"
        '
        'mnuCategorias
        '
        Me.mnuCategorias.Index = 2
        Me.mnuCategorias.Text = "Categor�as"
        '
        'mnuCategoriasRev
        '
        Me.mnuCategoriasRev.Index = 3
        Me.mnuCategoriasRev.Text = "Categor�as de Revisi�n Editorial"
        '
        'mnuPuntoRev
        '
        Me.mnuPuntoRev.Index = 4
        Me.mnuPuntoRev.Text = "Puntos de Revisi�n Editorial"
        '
        'mnuRepresentacion
        '
        Me.mnuRepresentacion.Index = 5
        Me.mnuRepresentacion.Text = "Representaci�n"
        '
        'mnuSectores
        '
        Me.mnuSectores.Index = 6
        Me.mnuSectores.Text = "Sectores"
        '
        'mnuDirectorio
        '
        Me.mnuDirectorio.Index = 7
        Me.mnuDirectorio.Text = "Directorio"
        '
        'mnuRemitentes
        '
        Me.mnuRemitentes.Index = 8
        Me.mnuRemitentes.Text = "Remitentes"
        '
        'mnuNombramientos
        '
        Me.mnuNombramientos.Index = 9
        Me.mnuNombramientos.Text = "Nombramientos"
        '
        'mnuProcesos
        '
        Me.mnuProcesos.Index = 1
        Me.mnuProcesos.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdmonTemas, Me.mnuAvanceTemas, Me.mnuCatalogoNormas, Me.mnuComentarios, Me.mnuNoticias, Me.mnuSesiones, Me.mnuGestionDoctos})
        Me.mnuProcesos.Text = "Procesos"
        '
        'mnuAdmonTemas
        '
        Me.mnuAdmonTemas.Index = 0
        Me.mnuAdmonTemas.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnupnn, Me.mnupnnTemas, Me.mnuTraspasoTemas})
        Me.mnuAdmonTemas.Text = "Admon PNN"
        '
        'mnupnn
        '
        Me.mnupnn.Index = 0
        Me.mnupnn.Text = "PNN"
        '
        'mnupnnTemas
        '
        Me.mnupnnTemas.Index = 1
        Me.mnupnnTemas.Text = "PNN TEMAS"
        '
        'mnuTraspasoTemas
        '
        Me.mnuTraspasoTemas.Index = 2
        Me.mnuTraspasoTemas.Text = "Traspaso Temas Planes"
        '
        'mnuAvanceTemas
        '
        Me.mnuAvanceTemas.Index = 1
        Me.mnuAvanceTemas.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAsignacionRevision, Me.mnnuRevisionEd, Me.mnuAutorizarR, Me.mnuInspPru})
        Me.mnuAvanceTemas.Text = "Avance Temas"
        '
        'mnuAsignacionRevision
        '
        Me.mnuAsignacionRevision.Index = 0
        Me.mnuAsignacionRevision.Text = "Asignaci�n Revisi�n Editorial"
        '
        'mnnuRevisionEd
        '
        Me.mnnuRevisionEd.Index = 1
        Me.mnnuRevisionEd.Text = "Revision Editorial"
        '
        'mnuAutorizarR
        '
        Me.mnuAutorizarR.Index = 2
        Me.mnuAutorizarR.Text = "Autorizar Revisi�n Editorial"
        '
        'mnuInspPru
        '
        Me.mnuInspPru.Index = 3
        Me.mnuInspPru.Text = "Inspeci�n y Pruebas"
        '
        'mnuCatalogoNormas
        '
        Me.mnuCatalogoNormas.Index = 2
        Me.mnuCatalogoNormas.Text = "Cat�logo de Normas"
        '
        'mnuComentarios
        '
        Me.mnuComentarios.Index = 3
        Me.mnuComentarios.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuProcNormal, Me.mnuResolCom, Me.mnuProcAlter, Me.mnuResolucionprocAlter})
        Me.mnuComentarios.Text = "Comentarios"
        '
        'mnuProcNormal
        '
        Me.mnuProcNormal.Index = 0
        Me.mnuProcNormal.Text = "Procedimiento Normal"
        '
        'mnuResolCom
        '
        Me.mnuResolCom.Index = 1
        Me.mnuResolCom.Text = "Resoluci�n de Comentarios"
        '
        'mnuProcAlter
        '
        Me.mnuProcAlter.Index = 2
        Me.mnuProcAlter.Text = "Procedimiento Alternativo"
        '
        'mnuResolucionprocAlter
        '
        Me.mnuResolucionprocAlter.Index = 3
        Me.mnuResolucionprocAlter.Text = "Resoluci�n De Comentarios Proc  Alternativo"
        '
        'mnuNoticias
        '
        Me.mnuNoticias.Index = 4
        Me.mnuNoticias.Text = "Noticias"
        '
        'mnuSesiones
        '
        Me.mnuSesiones.Index = 5
        Me.mnuSesiones.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuCerrarSes, Me.mnuHistorialSes, Me.mnnuSesionesPeriodicas, Me.mnuProxsesiones})
        Me.mnuSesiones.Text = "Sesiones"
        '
        'mnuCerrarSes
        '
        Me.mnuCerrarSes.Index = 0
        Me.mnuCerrarSes.Text = "Cerrar Sesiones Realizadas"
        '
        'mnuHistorialSes
        '
        Me.mnuHistorialSes.Index = 1
        Me.mnuHistorialSes.Text = "Historial de Sesiones"
        '
        'mnnuSesionesPeriodicas
        '
        Me.mnnuSesionesPeriodicas.Index = 2
        Me.mnnuSesionesPeriodicas.Text = "Programar Sesiones Peri�dicas"
        '
        'mnuProxsesiones
        '
        Me.mnuProxsesiones.Index = 3
        Me.mnuProxsesiones.Text = "Programar Pr�ximas Sesiones"
        '
        'mnuGestionDoctos
        '
        Me.mnuGestionDoctos.Index = 6
        Me.mnuGestionDoctos.Text = "Gestion de Documentos"
        '
        'mnuConsultas
        '
        Me.mnuConsultas.Index = 2
        Me.mnuConsultas.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuConComentarios, Me.mnuconsFechas, Me.mnuConsNormas, Me.mnuConsSesiones, Me.mnuConsTemas})
        Me.mnuConsultas.Text = "Consultas"
        '
        'mnuConComentarios
        '
        Me.mnuConComentarios.Index = 0
        Me.mnuConComentarios.Text = "Consulta Comentarios"
        '
        'mnuconsFechas
        '
        Me.mnuconsFechas.Index = 1
        Me.mnuconsFechas.Text = "Consulta Fechas"
        '
        'mnuConsNormas
        '
        Me.mnuConsNormas.Index = 2
        Me.mnuConsNormas.Text = "Consulta Normas"
        '
        'mnuConsSesiones
        '
        Me.mnuConsSesiones.Index = 3
        Me.mnuConsSesiones.Text = "Consulta Sesiones"
        '
        'mnuConsTemas
        '
        Me.mnuConsTemas.Index = 4
        Me.mnuConsTemas.Text = "Consulta Temas"
        '
        'mnuPaginaWeb
        '
        Me.mnuPaginaWeb.Index = 3
        Me.mnuPaginaWeb.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuIndex, Me.mnuGeneradorMenu, Me.mnuGestorPaginas})
        Me.mnuPaginaWeb.Shortcut = System.Windows.Forms.Shortcut.F1
        Me.mnuPaginaWeb.Text = "Pagina Web"
        '
        'mnuIndex
        '
        Me.mnuIndex.Index = 0
        Me.mnuIndex.Text = "Index"
        '
        'mnuGeneradorMenu
        '
        Me.mnuGeneradorMenu.Index = 1
        Me.mnuGeneradorMenu.Text = "Generador de menus"
        '
        'mnuGestorPaginas
        '
        Me.mnuGestorPaginas.Index = 2
        Me.mnuGestorPaginas.Text = "Gestor de paginas"
        '
        'mnuAdministracion
        '
        Me.mnuAdministracion.Index = 4
        Me.mnuAdministracion.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuGruposAdmin})
        Me.mnuAdministracion.Text = "Administracion"
        '
        'mnuGruposAdmin
        '
        Me.mnuGruposAdmin.Index = 0
        Me.mnuGruposAdmin.Text = "Grupos"
        '
        'mnuSalir
        '
        Me.mnuSalir.Index = 5
        Me.mnuSalir.Text = "Salir"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 691)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.Servidor, Me.BaseDatos, Me.Usuario})
        Me.StatusBar1.ShowPanels = True
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 22)
        Me.StatusBar1.TabIndex = 0
        '
        'Servidor
        '
        Me.Servidor.Icon = CType(resources.GetObject("Servidor.Icon"), System.Drawing.Icon)
        Me.Servidor.Text = "StatusBarPanel1"
        Me.Servidor.Width = 99
        '
        'BaseDatos
        '
        Me.BaseDatos.Icon = CType(resources.GetObject("BaseDatos.Icon"), System.Drawing.Icon)
        Me.BaseDatos.Text = "StatusBarPanel2"
        '
        'Usuario
        '
        Me.Usuario.Icon = CType(resources.GetObject("Usuario.Icon"), System.Drawing.Icon)
        Me.Usuario.Text = "StatusBarPanel3"
        '
        'mnuReporteAsistencia
        '
        Me.mnuReporteAsistencia.Index = 10
        Me.mnuReporteAsistencia.Text = "Reporte Asistencia"
        '
        'FrmPrincipal
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1016, 713)
        Me.Controls.Add(Me.StatusBar1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "FrmPrincipal"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Men� Principal"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.Servidor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseDatos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Usuario, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNoticias.Click
        Dim FrmNoticias As New FrmP_Noticias
        FrmNoticias.MdiParent = Me
        FrmNoticias.Show()
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPaginaWeb.Click

    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnupnn.Click
        Dim frmPlan As New frmPNN
        frmPlan.MdiParent = Me
        frmPlan.Show()
    End Sub

    Private Sub MenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnupnnTemas.Click
        Dim FrmTemas As New frmPNN_temas
        FrmTemas.MdiParent = Me
        FrmTemas.Show()
    End Sub


    Private Sub MenuItem16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAsignacionRevision.Click
        Dim Asignacion As New FrmAsig_Rev_Edit
        Asignacion.MdiParent = Me
        Asignacion.Show()
    End Sub

    Private Sub MenuItem18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProcNormal.Click
        Dim compronormal As New frmP_Comentarios
        compronormal.MdiParent = Me
        compronormal.Show()
    End Sub

    Private Sub MenuItem21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCerrarSes.Click
        'Dim CierraSesiones As New FrmSesionesCerrar
        'CierraSesiones.MdiParent = Me.MdiParent
        'CierraSesiones.Show()
        Dim cierrasess As New FrmSesionesCerrar
        cierrasess.MdiParent = Me
        cierrasess.Show()
    End Sub

    Private Sub MenuItem20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnnuSesionesPeriodicas.Click
        Dim ProgramaSesiones As New FrmProgramaSesiones
        ProgramaSesiones.MdiParent = Me
        ProgramaSesiones.Show()
    End Sub

    Private Sub MenuItem22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHistorialSes.Click
        Dim AnterioresSesiones As New FrmSesiones_pasadas
        AnterioresSesiones.MdiParent = Me
        AnterioresSesiones.Show()
    End Sub

    Private Sub MenuItem23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProxsesiones.Click
        Dim prox As New frmProgramarSesiones
        prox.MdiParent = Me
        prox.Show()
    End Sub

    Private Sub MenuItem24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCatalogoNormas.Click
        Dim normas As New frmC_Normas
        normas.MdiParent = Me
        normas.Show()
    End Sub

    Private Sub MenuItem25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTraspasoTemas.Click
        Dim Traspaso As New FrmTraspaso
        Traspaso.MdiParent = Me
        Traspaso.Show()
    End Sub

    Private Sub MenuItem15_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnnuRevisionEd.Click
        Dim Revision As New FrmRev_Editorial(1)
        Revision.MdiParent = Me
        Revision.Show()
    End Sub

    Private Sub MenuItem27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuResolCom.Click
        Dim P_Resolucion As New Resolucion
        P_Resolucion.MdiParent = Me
        P_Resolucion.Show()
    End Sub

    Private Sub MenuItem14_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuComentarios.Click
        Dim Cons_Sesiones As New frmCons_sesiones
        Cons_Sesiones.MdiParent = Me
        Cons_Sesiones.Show()
    End Sub

    Private Sub MenuItem28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAutorizarR.Click
        Dim Revision As New FrmRev_Editorial(3)
        Revision.MdiParent = Me
        Revision.Show()
    End Sub

    Private Sub MenuItem17_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProcAlter.Click
        Dim Proc As New FrmAlternativo
        Proc.MdiParent = Me
        Proc.Show()
    End Sub

    Private Sub MenuItem31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuResolucionprocAlter.Click
        Dim res As New frmP_Resolucion_Comentarios
        res.MdiParent = Me
        res.Show()
    End Sub

    Private Sub MenuItem30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuConsSesiones.Click
        Dim qsesiones As New frmCons_sesiones
        qsesiones.MdiParent = Me
        qsesiones.Show()
    End Sub

    Private Sub MenuItem33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuConsTemas.Click
        Dim Qtemas As New FrmQTemas
        Qtemas.MdiParent = Me
        Qtemas.Show()
    End Sub

#Region " Menus - Cat�logos, Procesos"

    ''''''''''''''''''''' Comites '''''''''''''''''''''
    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuComites.Click
        Dim Comites As New frmP_Comite
        Me.Parent = Comites.Parent
        Comites.Show()


    End Sub

    ''''''''''''''''''''' Cargos '''''''''''''''''''''
    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCargos.Click
        Dim Cargos As New frmC_Cargos
        Cargos.MdiParent = Me
        Cargos.Show()
    End Sub

    ''''''''''''''''''''' Categor�as '''''''''''''''''''''
    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCategorias.Click
        Dim FrmCatego As New FrmCategorias
        FrmCatego.MdiParent = Me
        FrmCatego.Show()
    End Sub

    ''''''''''''''''''''' Categor�as de Revisi�n editorial '''''''''''''''''''''
    Private Sub MenuItem36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCategoriasRev.Click
        Dim Cat_Rev_Edt As New FrmCateRevEdt
        Cat_Rev_Edt.MdiParent = Me
        Cat_Rev_Edt.Show()
    End Sub

    ''''''''''''''''''''' Puntos de Revisi�n editorial '''''''''''''''''''''
    Private Sub MenuItem37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPuntoRev.Click
        Dim Frm_Incisos As New FrmIncisos
        Frm_Incisos.MdiParent = Me
        Frm_Incisos.Show()
    End Sub

    ''''''''''''''''''''' Representaci�n '''''''''''''''''''''
    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRepresentacion.Click
        Dim FrmRepresentacion As New FrmRepresentacion
        FrmRepresentacion.MdiParent = Me
        FrmRepresentacion.Show()
    End Sub

    ''''''''''''''''''''' Sectores '''''''''''''''''''''
    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSectores.Click
        Dim Frmsectores As New FrmSectores
        Frmsectores.MdiParent = Me
        Frmsectores.Show()
    End Sub

    ''''''''''''''''''''' Directorio '''''''''''''''''''''
    Private Sub MenuItem26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDirectorio.Click
        Dim Directorio As New FrmCatalogoDirectorio
        Directorio.MdiParent = Me
        Directorio.Show()
    End Sub

#End Region

#Region " Menus - Consultas, Procesos"

    Private Sub MenuItem35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuConComentarios.Click
        Dim Qcomentarios As New FrmConsComentarios
        Qcomentarios.MdiParent = Me
        Qcomentarios.Show()
    End Sub

    Private Sub MenuItem34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuconsFechas.Click
        Dim QFechas As New FrmConsxFechas
        QFechas.MdiParent = Me
        QFechas.Show()
    End Sub

    Private Sub MenuItem32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuConsNormas.Click
        Dim QNormas As New frmQ_Normas
        QNormas.MdiParent = Me
        QNormas.Show()

    End Sub

    Private Sub MenuItem38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim QIndicadores As New FrmIndicadores
        QIndicadores.MdiParent = Me
        QIndicadores.Show()
    End Sub

#End Region

    Private Sub FrmPrincipal_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If MsgBox("** �Deseas Salir de NormaNet? **", MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Application.Exit()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub MenuItem42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInspPru.Click
        Dim Pruebas As New Frm_inspeccion_Pruebas
        Pruebas.MdiParent = Me
        Pruebas.Show()
    End Sub

    Private Sub MenuItem43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGestionDoctos.Click
        Dim GDoctos As New FrmGestionDoctos
        GDoctos.MdiParent = Me
        GDoctos.Show()
    End Sub

    Private Sub FrmPrincipal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.StatusBar1.Panels(0).Text = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Principal", "Servidor")
        Me.StatusBar1.Panels(1).Text = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Principal", "Base")
        Me.StatusBar1.Panels(2).Text = gUsuario

        Dim dsmenu As DataSet
        objMenus.sistema = 16
        objMenus.Id_Grupo = iGrupo
        objMenus.Id_Usuario = gUsuario
        dsmenu = objMenus.Menus

        REM objMenus.Habilita_menus(dsmenu, Me)
        objMenus.Habilita_menus(dsmenu, MainMenu1)
    End Sub

    Private Sub MenuItem40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGruposAdmin.Click
        Dim gruposAdmon As New frmAdministracion
        gruposAdmon.MdiParent = Me
        gruposAdmon.Show()
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSalir.Click
        If MsgBox("Deseas Salir del Sistema", MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then End
    End Sub

    Private Sub mnuIndex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuIndex.Click
        Dim frmIndex As New CrearIndex
        frmIndex.MdiParent = Me
        frmIndex.Show()
    End Sub

    Private Sub mnuGeneradorMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGeneradorMenu.Click
        Dim frmMenu As New GeneradorMenu
        frmMenu.MdiParent = Me
        frmMenu.Show()
    End Sub

    Private Sub mnuGestorPaginas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGestorPaginas.Click
        Dim frmGestorDeLigas As New frmGestor
        frmGestorDeLigas.MdiParent = Me
        frmGestorDeLigas.Show()
    End Sub

    Private Sub mnuRemitentes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRemitentes.Click
        Dim Remitentes As New FrmRemitentes
        Remitentes.MdiParent = Me
        Remitentes.Show()
    End Sub

    Private Sub mnuNombramientos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNombramientos.Click
        Dim Nombramientos As New FrmNombramientos
        Nombramientos.MdiParent = Me
        Nombramientos.Show()
    End Sub

    Private Sub mnuReporteAsistencia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuReporteAsistencia.Click
        Dim ReporteAsistencia As New FrmReporteAsistencia
        ReporteAsistencia.MdiParent = Me
        ReporteAsistencia.Show()
    End Sub
End Class
