Public Class FrmQTemas
    Inherits System.Windows.Forms.Form
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Dim dvComite As DataView
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Private ObjTiposTema As New ClsTipos_tema.C_Tipos_Tema(0, gUsuario, gPasswordSql) 'Esta clase habilita el tipo de tema de los catalagos
    Private ObjTiposProceso As New ClsTiposProceso.C_Tipo_Proceso(0, gUsuario, gPasswordSql)
    Private ObjEmpleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private objRevision As New ClsRevision_Normas.C_Revision_Normas(0, gUsuario, gPasswordSql)
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private objEtapas As New ClsEtapas.C_Etapas(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    Private dtTiposTema As DataTable
    Private dtEtapas As DataTable
    Private dtTiposProceso As DataTable
    ' defino variable del tipo DataRow
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim RegGT As DataRow
    Dim nodo1 As New TreeNode
    Dim sEtapa As String
    Dim Matriz As Array
    Dim svariable As String
    Dim stema As String
    Dim sraiz As String
    Dim bandera As Integer
    Dim sComite As String
    Dim sCt As String
    Dim sSc As String
    Dim sGt As String
    Dim sPlan As String
    Dim sSentencia As String
    Private dtRevision As DataTable


#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents TBpt As System.Windows.Forms.TabControl
    Friend WithEvents TbPgProgramaTrabajo As System.Windows.Forms.TabPage
    Friend WithEvents TbDt As System.Windows.Forms.TabPage
    Friend WithEvents tbAnt As System.Windows.Forms.TabPage
    Friend WithEvents tbProy As System.Windows.Forms.TabPage
    Friend WithEvents txtf2 As System.Windows.Forms.TextBox
    Friend WithEvents txtf1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents f1 As System.Windows.Forms.Label
    Friend WithEvents DT1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DT2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkPeriodoPT As System.Windows.Forms.CheckBox
    Friend WithEvents lblpertenece As System.Windows.Forms.Label
    Friend WithEvents txttipoTema As System.Windows.Forms.TextBox
    Friend WithEvents CboTipoTema As System.Windows.Forms.ComboBox
    Friend WithEvents chkTipoTema As System.Windows.Forms.CheckBox
    Friend WithEvents txtresponsable As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents chkResponsable As System.Windows.Forms.CheckBox
    Friend WithEvents txtrevision As System.Windows.Forms.TextBox
    Friend WithEvents cboRevision As System.Windows.Forms.ComboBox
    Friend WithEvents chkrevision As System.Windows.Forms.CheckBox
    Friend WithEvents txtcomite As System.Windows.Forms.TextBox
    Friend WithEvents TVcomites As System.Windows.Forms.TreeView
    Friend WithEvents chkcomite As System.Windows.Forms.CheckBox
    Friend WithEvents grdResultadosPT As System.Windows.Forms.DataGrid
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chknmx As System.Windows.Forms.CheckBox
    Friend WithEvents txtnmx2 As System.Windows.Forms.TextBox
    Friend WithEvents txtnmx1 As System.Windows.Forms.TextBox
    Friend WithEvents dtnmx1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtnmx2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkRevedit As System.Windows.Forms.CheckBox
    Friend WithEvents txtrev2 As System.Windows.Forms.TextBox
    Friend WithEvents txtrev1 As System.Windows.Forms.TextBox
    Friend WithEvents dtrev1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtrev2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtresponsableDt As System.Windows.Forms.TextBox
    Friend WithEvents CboResponsableDt As System.Windows.Forms.ComboBox
    Friend WithEvents chkresponsable_dt As System.Windows.Forms.CheckBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents txttipo As System.Windows.Forms.TextBox
    Friend WithEvents cbotipo As System.Windows.Forms.ComboBox
    Friend WithEvents chktipo As System.Windows.Forms.CheckBox
    Friend WithEvents chktipoproceso As System.Windows.Forms.CheckBox
    Friend WithEvents txttipoproceso As System.Windows.Forms.TextBox
    Friend WithEvents cbotipoproceso As System.Windows.Forms.ComboBox
    Friend WithEvents pnlalternativo As System.Windows.Forms.Panel
    Friend WithEvents chkInicioResponsable As System.Windows.Forms.CheckBox
    Friend WithEvents chkResponsableAlternativo As System.Windows.Forms.CheckBox
    Friend WithEvents txtresponsablealternativo As System.Windows.Forms.TextBox
    Friend WithEvents cboresponsablealternativo As System.Windows.Forms.ComboBox
    Friend WithEvents txtfinicioalter2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfinicioalter As System.Windows.Forms.TextBox
    Friend WithEvents dtfinicioalter As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfinicioalter2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkfinResponsable As System.Windows.Forms.CheckBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtfcom2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfcom1 As System.Windows.Forms.TextBox
    Friend WithEvents dtfcom1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfcom2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtadj2 As System.Windows.Forms.TextBox
    Friend WithEvents txtadj As System.Windows.Forms.TextBox
    Friend WithEvents dtadj As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtadj2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkadj As System.Windows.Forms.CheckBox
    Friend WithEvents grdresultados_dt As System.Windows.Forms.DataGrid
    Friend WithEvents chkclasificacion As System.Windows.Forms.CheckBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkresponsableant As System.Windows.Forms.CheckBox
    Friend WithEvents txtresponsableant As System.Windows.Forms.TextBox
    Friend WithEvents cboresponsableant As System.Windows.Forms.ComboBox
    Friend WithEvents txtetapas As System.Windows.Forms.TextBox
    Friend WithEvents cboetapas As System.Windows.Forms.ComboBox
    Friend WithEvents chketapas As System.Windows.Forms.CheckBox
    Friend WithEvents chkfechaAprob As System.Windows.Forms.CheckBox
    Friend WithEvents txtfaprob2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfaprob1 As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionant As System.Windows.Forms.TextBox
    Friend WithEvents dtfaprob1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfaprob2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents grdresultadosant As System.Windows.Forms.DataGrid
    Friend WithEvents grdresultadosproy As System.Windows.Forms.DataGrid
    Friend WithEvents chkDgn As System.Windows.Forms.CheckBox
    Friend WithEvents txtdgn2 As System.Windows.Forms.TextBox
    Friend WithEvents txtDgn As System.Windows.Forms.TextBox
    Friend WithEvents dtDgn As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtdgn2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkfedproyf As System.Windows.Forms.CheckBox
    Friend WithEvents txtfedproyf2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfedproyf As System.Windows.Forms.TextBox
    Friend WithEvents dtfedproyf As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfedproyf2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkfrevproyf As System.Windows.Forms.CheckBox
    Friend WithEvents txtfrevproyf2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfrevproyf As System.Windows.Forms.TextBox
    Friend WithEvents dtfrevproyf As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfrevproyf2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkvobo As System.Windows.Forms.CheckBox
    Friend WithEvents txtvobo2 As System.Windows.Forms.TextBox
    Friend WithEvents txtvobo As System.Windows.Forms.TextBox
    Friend WithEvents dtvobo As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtvobo2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkaprobres As System.Windows.Forms.CheckBox
    Friend WithEvents txtaprobres2 As System.Windows.Forms.TextBox
    Friend WithEvents txtaprobres As System.Windows.Forms.TextBox
    Friend WithEvents dtaprobres As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtaprobres2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkres As System.Windows.Forms.CheckBox
    Friend WithEvents txtres2 As System.Windows.Forms.TextBox
    Friend WithEvents txtres As System.Windows.Forms.TextBox
    Friend WithEvents dtres As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtres2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkpubcom As System.Windows.Forms.CheckBox
    Friend WithEvents txtfpubcom2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfpubcom As System.Windows.Forms.TextBox
    Friend WithEvents dtpubcom As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpubcom2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkapCom As System.Windows.Forms.CheckBox
    Friend WithEvents txtfaprcom2 As System.Windows.Forms.TextBox
    Friend WithEvents txtfaprcom1 As System.Windows.Forms.TextBox
    Friend WithEvents dtfaprocom1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfaprocom2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkresponsable_proy As System.Windows.Forms.CheckBox
    Friend WithEvents txtresponsable_proy As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsable_proy As System.Windows.Forms.ComboBox
    Friend WithEvents chkclasificacionproy As System.Windows.Forms.CheckBox
    Friend WithEvents txtclasificacion_proy As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Textproy As System.Windows.Forms.TextBox
    Friend WithEvents Textant As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextDT As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextPT As System.Windows.Forms.TextBox
    Friend WithEvents CmdImprimir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmQTemas))
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdImprimir = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.TBpt = New System.Windows.Forms.TabControl
        Me.TbPgProgramaTrabajo = New System.Windows.Forms.TabPage
        Me.TextPT = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.grdResultadosPT = New System.Windows.Forms.DataGrid
        Me.chkrevision = New System.Windows.Forms.CheckBox
        Me.txtrevision = New System.Windows.Forms.TextBox
        Me.cboRevision = New System.Windows.Forms.ComboBox
        Me.chkResponsable = New System.Windows.Forms.CheckBox
        Me.txtresponsable = New System.Windows.Forms.TextBox
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.chkTipoTema = New System.Windows.Forms.CheckBox
        Me.txttipoTema = New System.Windows.Forms.TextBox
        Me.CboTipoTema = New System.Windows.Forms.ComboBox
        Me.chkPeriodoPT = New System.Windows.Forms.CheckBox
        Me.txtf2 = New System.Windows.Forms.TextBox
        Me.txtf1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.f1 = New System.Windows.Forms.Label
        Me.DT1 = New System.Windows.Forms.DateTimePicker
        Me.DT2 = New System.Windows.Forms.DateTimePicker
        Me.TbDt = New System.Windows.Forms.TabPage
        Me.TextDT = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.grdresultados_dt = New System.Windows.Forms.DataGrid
        Me.pnlalternativo = New System.Windows.Forms.Panel
        Me.chkadj = New System.Windows.Forms.CheckBox
        Me.txtadj2 = New System.Windows.Forms.TextBox
        Me.txtadj = New System.Windows.Forms.TextBox
        Me.dtadj = New System.Windows.Forms.DateTimePicker
        Me.dtadj2 = New System.Windows.Forms.DateTimePicker
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.chkfinResponsable = New System.Windows.Forms.CheckBox
        Me.txtfcom2 = New System.Windows.Forms.TextBox
        Me.txtfcom1 = New System.Windows.Forms.TextBox
        Me.dtfcom1 = New System.Windows.Forms.DateTimePicker
        Me.dtfcom2 = New System.Windows.Forms.DateTimePicker
        Me.chkResponsableAlternativo = New System.Windows.Forms.CheckBox
        Me.txtresponsablealternativo = New System.Windows.Forms.TextBox
        Me.cboresponsablealternativo = New System.Windows.Forms.ComboBox
        Me.chkInicioResponsable = New System.Windows.Forms.CheckBox
        Me.txtfinicioalter2 = New System.Windows.Forms.TextBox
        Me.txtfinicioalter = New System.Windows.Forms.TextBox
        Me.dtfinicioalter = New System.Windows.Forms.DateTimePicker
        Me.dtfinicioalter2 = New System.Windows.Forms.DateTimePicker
        Me.chktipoproceso = New System.Windows.Forms.CheckBox
        Me.txttipoproceso = New System.Windows.Forms.TextBox
        Me.cbotipoproceso = New System.Windows.Forms.ComboBox
        Me.chktipo = New System.Windows.Forms.CheckBox
        Me.txttipo = New System.Windows.Forms.TextBox
        Me.cbotipo = New System.Windows.Forms.ComboBox
        Me.chkresponsable_dt = New System.Windows.Forms.CheckBox
        Me.txtresponsableDt = New System.Windows.Forms.TextBox
        Me.CboResponsableDt = New System.Windows.Forms.ComboBox
        Me.chkRevedit = New System.Windows.Forms.CheckBox
        Me.txtrev2 = New System.Windows.Forms.TextBox
        Me.txtrev1 = New System.Windows.Forms.TextBox
        Me.dtrev1 = New System.Windows.Forms.DateTimePicker
        Me.dtrev2 = New System.Windows.Forms.DateTimePicker
        Me.chknmx = New System.Windows.Forms.CheckBox
        Me.txtnmx2 = New System.Windows.Forms.TextBox
        Me.txtnmx1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.dtnmx1 = New System.Windows.Forms.DateTimePicker
        Me.dtnmx2 = New System.Windows.Forms.DateTimePicker
        Me.tbAnt = New System.Windows.Forms.TabPage
        Me.Textant = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.grdresultadosant = New System.Windows.Forms.DataGrid
        Me.chkresponsableant = New System.Windows.Forms.CheckBox
        Me.txtresponsableant = New System.Windows.Forms.TextBox
        Me.cboresponsableant = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.chkfechaAprob = New System.Windows.Forms.CheckBox
        Me.txtfaprob2 = New System.Windows.Forms.TextBox
        Me.txtfaprob1 = New System.Windows.Forms.TextBox
        Me.dtfaprob1 = New System.Windows.Forms.DateTimePicker
        Me.dtfaprob2 = New System.Windows.Forms.DateTimePicker
        Me.chkclasificacion = New System.Windows.Forms.CheckBox
        Me.txtClasificacionant = New System.Windows.Forms.TextBox
        Me.tbProy = New System.Windows.Forms.TabPage
        Me.Textproy = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.chkDgn = New System.Windows.Forms.CheckBox
        Me.txtdgn2 = New System.Windows.Forms.TextBox
        Me.txtDgn = New System.Windows.Forms.TextBox
        Me.dtDgn = New System.Windows.Forms.DateTimePicker
        Me.dtdgn2 = New System.Windows.Forms.DateTimePicker
        Me.chkfedproyf = New System.Windows.Forms.CheckBox
        Me.txtfedproyf2 = New System.Windows.Forms.TextBox
        Me.txtfedproyf = New System.Windows.Forms.TextBox
        Me.dtfedproyf = New System.Windows.Forms.DateTimePicker
        Me.dtfedproyf2 = New System.Windows.Forms.DateTimePicker
        Me.chkfrevproyf = New System.Windows.Forms.CheckBox
        Me.txtfrevproyf2 = New System.Windows.Forms.TextBox
        Me.txtfrevproyf = New System.Windows.Forms.TextBox
        Me.dtfrevproyf = New System.Windows.Forms.DateTimePicker
        Me.dtfrevproyf2 = New System.Windows.Forms.DateTimePicker
        Me.chkvobo = New System.Windows.Forms.CheckBox
        Me.txtvobo2 = New System.Windows.Forms.TextBox
        Me.txtvobo = New System.Windows.Forms.TextBox
        Me.dtvobo = New System.Windows.Forms.DateTimePicker
        Me.dtvobo2 = New System.Windows.Forms.DateTimePicker
        Me.chkaprobres = New System.Windows.Forms.CheckBox
        Me.txtaprobres2 = New System.Windows.Forms.TextBox
        Me.txtaprobres = New System.Windows.Forms.TextBox
        Me.dtaprobres = New System.Windows.Forms.DateTimePicker
        Me.dtaprobres2 = New System.Windows.Forms.DateTimePicker
        Me.chkres = New System.Windows.Forms.CheckBox
        Me.txtres2 = New System.Windows.Forms.TextBox
        Me.txtres = New System.Windows.Forms.TextBox
        Me.dtres = New System.Windows.Forms.DateTimePicker
        Me.dtres2 = New System.Windows.Forms.DateTimePicker
        Me.chkpubcom = New System.Windows.Forms.CheckBox
        Me.txtfpubcom2 = New System.Windows.Forms.TextBox
        Me.txtfpubcom = New System.Windows.Forms.TextBox
        Me.dtpubcom = New System.Windows.Forms.DateTimePicker
        Me.dtpubcom2 = New System.Windows.Forms.DateTimePicker
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.chkapCom = New System.Windows.Forms.CheckBox
        Me.txtfaprcom2 = New System.Windows.Forms.TextBox
        Me.txtfaprcom1 = New System.Windows.Forms.TextBox
        Me.dtfaprocom1 = New System.Windows.Forms.DateTimePicker
        Me.dtfaprocom2 = New System.Windows.Forms.DateTimePicker
        Me.chkresponsable_proy = New System.Windows.Forms.CheckBox
        Me.txtresponsable_proy = New System.Windows.Forms.TextBox
        Me.cboResponsable_proy = New System.Windows.Forms.ComboBox
        Me.chkclasificacionproy = New System.Windows.Forms.CheckBox
        Me.txtclasificacion_proy = New System.Windows.Forms.TextBox
        Me.grdresultadosproy = New System.Windows.Forms.DataGrid
        Me.chkcomite = New System.Windows.Forms.CheckBox
        Me.txtcomite = New System.Windows.Forms.TextBox
        Me.TVcomites = New System.Windows.Forms.TreeView
        Me.lblpertenece = New System.Windows.Forms.Label
        Me.chketapas = New System.Windows.Forms.CheckBox
        Me.txtetapas = New System.Windows.Forms.TextBox
        Me.cboetapas = New System.Windows.Forms.ComboBox
        Me.TBpt.SuspendLayout()
        Me.TbPgProgramaTrabajo.SuspendLayout()
        CType(Me.grdResultadosPT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TbDt.SuspendLayout()
        CType(Me.grdresultados_dt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlalternativo.SuspendLayout()
        Me.tbAnt.SuspendLayout()
        CType(Me.grdresultadosant, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbProy.SuspendLayout()
        CType(Me.grdresultadosproy, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TVPNN
        '
        Me.TVPNN.ImageIndex = 2
        Me.TVPNN.ImageList = Me.imgListTreeView
        Me.TVPNN.Location = New System.Drawing.Point(8, 8)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = 2
        Me.TVPNN.Size = New System.Drawing.Size(192, 200)
        Me.TVPNN.TabIndex = 14
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.CmdDeshacer, Me.CmdImprimir, Me.ToolBarButton2, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 672)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(1000, 62)
        Me.tlbBotonera.TabIndex = 16
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 8
        Me.cmdAgregar.Text = "Buscar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.ImageIndex = 7
        Me.CmdImprimir.Text = "Imprimir"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'TBpt
        '
        Me.TBpt.Controls.Add(Me.TbPgProgramaTrabajo)
        Me.TBpt.Controls.Add(Me.TbDt)
        Me.TBpt.Controls.Add(Me.tbAnt)
        Me.TBpt.Controls.Add(Me.tbProy)
        Me.TBpt.ItemSize = New System.Drawing.Size(111, 18)
        Me.TBpt.Location = New System.Drawing.Point(248, 16)
        Me.TBpt.Name = "TBpt"
        Me.TBpt.SelectedIndex = 0
        Me.TBpt.Size = New System.Drawing.Size(744, 648)
        Me.TBpt.TabIndex = 17
        '
        'TbPgProgramaTrabajo
        '
        Me.TbPgProgramaTrabajo.Controls.Add(Me.TextPT)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.Label13)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.grdResultadosPT)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.chkrevision)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.txtrevision)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.cboRevision)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.chkResponsable)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.txtresponsable)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.cboResponsable)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.chkTipoTema)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.txttipoTema)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.CboTipoTema)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.chkPeriodoPT)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.txtf2)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.txtf1)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.Label1)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.f1)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.DT1)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.DT2)
        Me.TbPgProgramaTrabajo.Location = New System.Drawing.Point(4, 22)
        Me.TbPgProgramaTrabajo.Name = "TbPgProgramaTrabajo"
        Me.TbPgProgramaTrabajo.Size = New System.Drawing.Size(736, 622)
        Me.TbPgProgramaTrabajo.TabIndex = 0
        Me.TbPgProgramaTrabajo.Text = "Propuesta de Trabajo"
        '
        'TextPT
        '
        Me.TextPT.Enabled = False
        Me.TextPT.Location = New System.Drawing.Point(616, 584)
        Me.TextPT.Name = "TextPT"
        Me.TextPT.TabIndex = 232
        Me.TextPT.Text = ""
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(544, 584)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(33, 16)
        Me.Label13.TabIndex = 231
        Me.Label13.Text = "Total:"
        '
        'grdResultadosPT
        '
        Me.grdResultadosPT.DataMember = ""
        Me.grdResultadosPT.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdResultadosPT.Location = New System.Drawing.Point(8, 192)
        Me.grdResultadosPT.Name = "grdResultadosPT"
        Me.grdResultadosPT.Size = New System.Drawing.Size(712, 384)
        Me.grdResultadosPT.TabIndex = 88
        '
        'chkrevision
        '
        Me.chkrevision.Location = New System.Drawing.Point(32, 144)
        Me.chkrevision.Name = "chkrevision"
        Me.chkrevision.Size = New System.Drawing.Size(128, 24)
        Me.chkrevision.TabIndex = 82
        Me.chkrevision.Text = "Revisi�n"
        '
        'txtrevision
        '
        Me.txtrevision.Enabled = False
        Me.txtrevision.Location = New System.Drawing.Point(160, 144)
        Me.txtrevision.Multiline = True
        Me.txtrevision.Name = "txtrevision"
        Me.txtrevision.Size = New System.Drawing.Size(240, 20)
        Me.txtrevision.TabIndex = 81
        Me.txtrevision.Text = ""
        '
        'cboRevision
        '
        Me.cboRevision.Enabled = False
        Me.cboRevision.Location = New System.Drawing.Point(160, 144)
        Me.cboRevision.Name = "cboRevision"
        Me.cboRevision.Size = New System.Drawing.Size(256, 21)
        Me.cboRevision.TabIndex = 79
        '
        'chkResponsable
        '
        Me.chkResponsable.Location = New System.Drawing.Point(32, 104)
        Me.chkResponsable.Name = "chkResponsable"
        Me.chkResponsable.Size = New System.Drawing.Size(128, 24)
        Me.chkResponsable.TabIndex = 78
        Me.chkResponsable.Text = "Responsable Tema"
        '
        'txtresponsable
        '
        Me.txtresponsable.Enabled = False
        Me.txtresponsable.Location = New System.Drawing.Point(160, 104)
        Me.txtresponsable.Name = "txtresponsable"
        Me.txtresponsable.Size = New System.Drawing.Size(240, 20)
        Me.txtresponsable.TabIndex = 77
        Me.txtresponsable.Text = ""
        '
        'cboResponsable
        '
        Me.cboResponsable.Enabled = False
        Me.cboResponsable.ItemHeight = 13
        Me.cboResponsable.Location = New System.Drawing.Point(160, 104)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(256, 21)
        Me.cboResponsable.TabIndex = 75
        '
        'chkTipoTema
        '
        Me.chkTipoTema.Location = New System.Drawing.Point(32, 64)
        Me.chkTipoTema.Name = "chkTipoTema"
        Me.chkTipoTema.Size = New System.Drawing.Size(120, 24)
        Me.chkTipoTema.TabIndex = 74
        Me.chkTipoTema.Text = "Por Tipo de Tema"
        '
        'txttipoTema
        '
        Me.txttipoTema.Enabled = False
        Me.txttipoTema.Location = New System.Drawing.Point(160, 64)
        Me.txttipoTema.Name = "txttipoTema"
        Me.txttipoTema.Size = New System.Drawing.Size(240, 20)
        Me.txttipoTema.TabIndex = 73
        Me.txttipoTema.Text = ""
        '
        'CboTipoTema
        '
        Me.CboTipoTema.Enabled = False
        Me.CboTipoTema.ItemHeight = 13
        Me.CboTipoTema.Location = New System.Drawing.Point(160, 64)
        Me.CboTipoTema.Name = "CboTipoTema"
        Me.CboTipoTema.Size = New System.Drawing.Size(256, 21)
        Me.CboTipoTema.TabIndex = 71
        '
        'chkPeriodoPT
        '
        Me.chkPeriodoPT.Location = New System.Drawing.Point(32, 32)
        Me.chkPeriodoPT.Name = "chkPeriodoPT"
        Me.chkPeriodoPT.Size = New System.Drawing.Size(96, 24)
        Me.chkPeriodoPT.TabIndex = 70
        Me.chkPeriodoPT.Text = "Por Periodo"
        '
        'txtf2
        '
        Me.txtf2.Enabled = False
        Me.txtf2.Location = New System.Drawing.Point(304, 32)
        Me.txtf2.Name = "txtf2"
        Me.txtf2.Size = New System.Drawing.Size(96, 20)
        Me.txtf2.TabIndex = 67
        Me.txtf2.Text = ""
        '
        'txtf1
        '
        Me.txtf1.Enabled = False
        Me.txtf1.Location = New System.Drawing.Point(160, 32)
        Me.txtf1.Name = "txtf1"
        Me.txtf1.Size = New System.Drawing.Size(104, 20)
        Me.txtf1.TabIndex = 66
        Me.txtf1.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(320, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 65
        Me.Label1.Text = "Fecha de Fin"
        '
        'f1
        '
        Me.f1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f1.Location = New System.Drawing.Point(168, 8)
        Me.f1.Name = "f1"
        Me.f1.Size = New System.Drawing.Size(88, 16)
        Me.f1.TabIndex = 64
        Me.f1.Text = "Fecha de Inicio"
        '
        'DT1
        '
        Me.DT1.Enabled = False
        Me.DT1.Location = New System.Drawing.Point(160, 32)
        Me.DT1.Name = "DT1"
        Me.DT1.Size = New System.Drawing.Size(120, 20)
        Me.DT1.TabIndex = 68
        '
        'DT2
        '
        Me.DT2.Enabled = False
        Me.DT2.Location = New System.Drawing.Point(304, 32)
        Me.DT2.Name = "DT2"
        Me.DT2.Size = New System.Drawing.Size(112, 20)
        Me.DT2.TabIndex = 69
        '
        'TbDt
        '
        Me.TbDt.Controls.Add(Me.TextDT)
        Me.TbDt.Controls.Add(Me.Label12)
        Me.TbDt.Controls.Add(Me.grdresultados_dt)
        Me.TbDt.Controls.Add(Me.pnlalternativo)
        Me.TbDt.Controls.Add(Me.chktipoproceso)
        Me.TbDt.Controls.Add(Me.txttipoproceso)
        Me.TbDt.Controls.Add(Me.cbotipoproceso)
        Me.TbDt.Controls.Add(Me.chktipo)
        Me.TbDt.Controls.Add(Me.txttipo)
        Me.TbDt.Controls.Add(Me.cbotipo)
        Me.TbDt.Controls.Add(Me.chkresponsable_dt)
        Me.TbDt.Controls.Add(Me.txtresponsableDt)
        Me.TbDt.Controls.Add(Me.CboResponsableDt)
        Me.TbDt.Controls.Add(Me.chkRevedit)
        Me.TbDt.Controls.Add(Me.txtrev2)
        Me.TbDt.Controls.Add(Me.txtrev1)
        Me.TbDt.Controls.Add(Me.dtrev1)
        Me.TbDt.Controls.Add(Me.dtrev2)
        Me.TbDt.Controls.Add(Me.chknmx)
        Me.TbDt.Controls.Add(Me.txtnmx2)
        Me.TbDt.Controls.Add(Me.txtnmx1)
        Me.TbDt.Controls.Add(Me.Label2)
        Me.TbDt.Controls.Add(Me.Label3)
        Me.TbDt.Controls.Add(Me.dtnmx1)
        Me.TbDt.Controls.Add(Me.dtnmx2)
        Me.TbDt.Location = New System.Drawing.Point(4, 22)
        Me.TbDt.Name = "TbDt"
        Me.TbDt.Size = New System.Drawing.Size(736, 622)
        Me.TbDt.TabIndex = 1
        Me.TbDt.Text = "Documento de Trabajo"
        Me.TbDt.Visible = False
        '
        'TextDT
        '
        Me.TextDT.Enabled = False
        Me.TextDT.Location = New System.Drawing.Point(624, 592)
        Me.TextDT.Name = "TextDT"
        Me.TextDT.TabIndex = 232
        Me.TextDT.Text = ""
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(552, 594)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(33, 16)
        Me.Label12.TabIndex = 231
        Me.Label12.Text = "Total:"
        '
        'grdresultados_dt
        '
        Me.grdresultados_dt.DataMember = ""
        Me.grdresultados_dt.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdresultados_dt.Location = New System.Drawing.Point(8, 408)
        Me.grdresultados_dt.Name = "grdresultados_dt"
        Me.grdresultados_dt.Size = New System.Drawing.Size(720, 176)
        Me.grdresultados_dt.TabIndex = 93
        '
        'pnlalternativo
        '
        Me.pnlalternativo.Controls.Add(Me.chkadj)
        Me.pnlalternativo.Controls.Add(Me.txtadj2)
        Me.pnlalternativo.Controls.Add(Me.txtadj)
        Me.pnlalternativo.Controls.Add(Me.dtadj)
        Me.pnlalternativo.Controls.Add(Me.dtadj2)
        Me.pnlalternativo.Controls.Add(Me.Label4)
        Me.pnlalternativo.Controls.Add(Me.Label5)
        Me.pnlalternativo.Controls.Add(Me.chkfinResponsable)
        Me.pnlalternativo.Controls.Add(Me.txtfcom2)
        Me.pnlalternativo.Controls.Add(Me.txtfcom1)
        Me.pnlalternativo.Controls.Add(Me.dtfcom1)
        Me.pnlalternativo.Controls.Add(Me.dtfcom2)
        Me.pnlalternativo.Controls.Add(Me.chkResponsableAlternativo)
        Me.pnlalternativo.Controls.Add(Me.txtresponsablealternativo)
        Me.pnlalternativo.Controls.Add(Me.cboresponsablealternativo)
        Me.pnlalternativo.Controls.Add(Me.chkInicioResponsable)
        Me.pnlalternativo.Controls.Add(Me.txtfinicioalter2)
        Me.pnlalternativo.Controls.Add(Me.txtfinicioalter)
        Me.pnlalternativo.Controls.Add(Me.dtfinicioalter)
        Me.pnlalternativo.Controls.Add(Me.dtfinicioalter2)
        Me.pnlalternativo.Location = New System.Drawing.Point(8, 216)
        Me.pnlalternativo.Name = "pnlalternativo"
        Me.pnlalternativo.Size = New System.Drawing.Size(592, 176)
        Me.pnlalternativo.TabIndex = 92
        Me.pnlalternativo.Visible = False
        '
        'chkadj
        '
        Me.chkadj.Location = New System.Drawing.Point(8, 136)
        Me.chkadj.Name = "chkadj"
        Me.chkadj.Size = New System.Drawing.Size(216, 32)
        Me.chkadj.TabIndex = 102
        Me.chkadj.Text = "Por Fecha de Adjunci�n Acta de terminaci�n Procedimiento Alternativo"
        '
        'txtadj2
        '
        Me.txtadj2.Enabled = False
        Me.txtadj2.Location = New System.Drawing.Point(400, 136)
        Me.txtadj2.Name = "txtadj2"
        Me.txtadj2.Size = New System.Drawing.Size(96, 20)
        Me.txtadj2.TabIndex = 99
        Me.txtadj2.Text = ""
        '
        'txtadj
        '
        Me.txtadj.Enabled = False
        Me.txtadj.Location = New System.Drawing.Point(256, 136)
        Me.txtadj.Name = "txtadj"
        Me.txtadj.Size = New System.Drawing.Size(104, 20)
        Me.txtadj.TabIndex = 98
        Me.txtadj.Text = ""
        '
        'dtadj
        '
        Me.dtadj.Enabled = False
        Me.dtadj.Location = New System.Drawing.Point(256, 136)
        Me.dtadj.Name = "dtadj"
        Me.dtadj.Size = New System.Drawing.Size(120, 20)
        Me.dtadj.TabIndex = 100
        '
        'dtadj2
        '
        Me.dtadj2.Enabled = False
        Me.dtadj2.Location = New System.Drawing.Point(400, 136)
        Me.dtadj2.Name = "dtadj2"
        Me.dtadj2.Size = New System.Drawing.Size(112, 20)
        Me.dtadj2.TabIndex = 101
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(400, 48)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 16)
        Me.Label4.TabIndex = 97
        Me.Label4.Text = "Fecha de Fin"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(256, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(88, 16)
        Me.Label5.TabIndex = 96
        Me.Label5.Text = "Fecha de Inicio"
        '
        'chkfinResponsable
        '
        Me.chkfinResponsable.Location = New System.Drawing.Point(8, 104)
        Me.chkfinResponsable.Name = "chkfinResponsable"
        Me.chkfinResponsable.Size = New System.Drawing.Size(208, 24)
        Me.chkfinResponsable.TabIndex = 95
        Me.chkfinResponsable.Text = "Por Fecha Emisi�n Comentarios"
        '
        'txtfcom2
        '
        Me.txtfcom2.Enabled = False
        Me.txtfcom2.Location = New System.Drawing.Point(400, 104)
        Me.txtfcom2.Name = "txtfcom2"
        Me.txtfcom2.Size = New System.Drawing.Size(96, 20)
        Me.txtfcom2.TabIndex = 92
        Me.txtfcom2.Text = ""
        '
        'txtfcom1
        '
        Me.txtfcom1.Enabled = False
        Me.txtfcom1.Location = New System.Drawing.Point(256, 104)
        Me.txtfcom1.Name = "txtfcom1"
        Me.txtfcom1.Size = New System.Drawing.Size(104, 20)
        Me.txtfcom1.TabIndex = 91
        Me.txtfcom1.Text = ""
        '
        'dtfcom1
        '
        Me.dtfcom1.Enabled = False
        Me.dtfcom1.Location = New System.Drawing.Point(256, 104)
        Me.dtfcom1.Name = "dtfcom1"
        Me.dtfcom1.Size = New System.Drawing.Size(120, 20)
        Me.dtfcom1.TabIndex = 93
        '
        'dtfcom2
        '
        Me.dtfcom2.Enabled = False
        Me.dtfcom2.Location = New System.Drawing.Point(400, 104)
        Me.dtfcom2.Name = "dtfcom2"
        Me.dtfcom2.Size = New System.Drawing.Size(112, 20)
        Me.dtfcom2.TabIndex = 94
        '
        'chkResponsableAlternativo
        '
        Me.chkResponsableAlternativo.Location = New System.Drawing.Point(8, 16)
        Me.chkResponsableAlternativo.Name = "chkResponsableAlternativo"
        Me.chkResponsableAlternativo.Size = New System.Drawing.Size(224, 24)
        Me.chkResponsableAlternativo.TabIndex = 90
        Me.chkResponsableAlternativo.Text = "Responsable Tema Proceso Alternativo"
        '
        'txtresponsablealternativo
        '
        Me.txtresponsablealternativo.Enabled = False
        Me.txtresponsablealternativo.Location = New System.Drawing.Point(256, 16)
        Me.txtresponsablealternativo.Name = "txtresponsablealternativo"
        Me.txtresponsablealternativo.Size = New System.Drawing.Size(304, 20)
        Me.txtresponsablealternativo.TabIndex = 89
        Me.txtresponsablealternativo.Text = ""
        '
        'cboresponsablealternativo
        '
        Me.cboresponsablealternativo.ItemHeight = 13
        Me.cboresponsablealternativo.Location = New System.Drawing.Point(256, 16)
        Me.cboresponsablealternativo.Name = "cboresponsablealternativo"
        Me.cboresponsablealternativo.Size = New System.Drawing.Size(320, 21)
        Me.cboresponsablealternativo.TabIndex = 88
        '
        'chkInicioResponsable
        '
        Me.chkInicioResponsable.Location = New System.Drawing.Point(8, 72)
        Me.chkInicioResponsable.Name = "chkInicioResponsable"
        Me.chkInicioResponsable.Size = New System.Drawing.Size(184, 24)
        Me.chkInicioResponsable.TabIndex = 87
        Me.chkInicioResponsable.Text = "Por Fecha  Responsable"
        '
        'txtfinicioalter2
        '
        Me.txtfinicioalter2.Enabled = False
        Me.txtfinicioalter2.Location = New System.Drawing.Point(400, 72)
        Me.txtfinicioalter2.Name = "txtfinicioalter2"
        Me.txtfinicioalter2.Size = New System.Drawing.Size(96, 20)
        Me.txtfinicioalter2.TabIndex = 84
        Me.txtfinicioalter2.Text = ""
        '
        'txtfinicioalter
        '
        Me.txtfinicioalter.Enabled = False
        Me.txtfinicioalter.Location = New System.Drawing.Point(256, 72)
        Me.txtfinicioalter.Name = "txtfinicioalter"
        Me.txtfinicioalter.Size = New System.Drawing.Size(104, 20)
        Me.txtfinicioalter.TabIndex = 83
        Me.txtfinicioalter.Text = ""
        '
        'dtfinicioalter
        '
        Me.dtfinicioalter.Enabled = False
        Me.dtfinicioalter.Location = New System.Drawing.Point(256, 72)
        Me.dtfinicioalter.Name = "dtfinicioalter"
        Me.dtfinicioalter.Size = New System.Drawing.Size(120, 20)
        Me.dtfinicioalter.TabIndex = 85
        '
        'dtfinicioalter2
        '
        Me.dtfinicioalter2.Enabled = False
        Me.dtfinicioalter2.Location = New System.Drawing.Point(400, 72)
        Me.dtfinicioalter2.Name = "dtfinicioalter2"
        Me.dtfinicioalter2.Size = New System.Drawing.Size(112, 20)
        Me.dtfinicioalter2.TabIndex = 86
        '
        'chktipoproceso
        '
        Me.chktipoproceso.Location = New System.Drawing.Point(16, 184)
        Me.chktipoproceso.Name = "chktipoproceso"
        Me.chktipoproceso.Size = New System.Drawing.Size(144, 24)
        Me.chktipoproceso.TabIndex = 91
        Me.chktipoproceso.Text = "Por Tipo de Proceso"
        '
        'txttipoproceso
        '
        Me.txttipoproceso.Enabled = False
        Me.txttipoproceso.Location = New System.Drawing.Point(168, 184)
        Me.txttipoproceso.Name = "txttipoproceso"
        Me.txttipoproceso.Size = New System.Drawing.Size(240, 20)
        Me.txttipoproceso.TabIndex = 90
        Me.txttipoproceso.Text = ""
        '
        'cbotipoproceso
        '
        Me.cbotipoproceso.Enabled = False
        Me.cbotipoproceso.ItemHeight = 13
        Me.cbotipoproceso.Location = New System.Drawing.Point(168, 184)
        Me.cbotipoproceso.Name = "cbotipoproceso"
        Me.cbotipoproceso.Size = New System.Drawing.Size(256, 21)
        Me.cbotipoproceso.TabIndex = 89
        '
        'chktipo
        '
        Me.chktipo.Location = New System.Drawing.Point(16, 144)
        Me.chktipo.Name = "chktipo"
        Me.chktipo.Size = New System.Drawing.Size(120, 24)
        Me.chktipo.TabIndex = 88
        Me.chktipo.Text = "Por Tipo de Tema"
        '
        'txttipo
        '
        Me.txttipo.Enabled = False
        Me.txttipo.Location = New System.Drawing.Point(168, 144)
        Me.txttipo.Name = "txttipo"
        Me.txttipo.Size = New System.Drawing.Size(240, 20)
        Me.txttipo.TabIndex = 87
        Me.txttipo.Text = ""
        '
        'cbotipo
        '
        Me.cbotipo.Enabled = False
        Me.cbotipo.ItemHeight = 13
        Me.cbotipo.Location = New System.Drawing.Point(168, 144)
        Me.cbotipo.Name = "cbotipo"
        Me.cbotipo.Size = New System.Drawing.Size(256, 21)
        Me.cbotipo.TabIndex = 86
        '
        'chkresponsable_dt
        '
        Me.chkresponsable_dt.Location = New System.Drawing.Point(16, 112)
        Me.chkresponsable_dt.Name = "chkresponsable_dt"
        Me.chkresponsable_dt.Size = New System.Drawing.Size(128, 24)
        Me.chkresponsable_dt.TabIndex = 85
        Me.chkresponsable_dt.Text = "Responsable Tema"
        '
        'txtresponsableDt
        '
        Me.txtresponsableDt.Enabled = False
        Me.txtresponsableDt.Location = New System.Drawing.Point(168, 112)
        Me.txtresponsableDt.Name = "txtresponsableDt"
        Me.txtresponsableDt.Size = New System.Drawing.Size(312, 20)
        Me.txtresponsableDt.TabIndex = 84
        Me.txtresponsableDt.Text = ""
        '
        'CboResponsableDt
        '
        Me.CboResponsableDt.ItemHeight = 13
        Me.CboResponsableDt.Location = New System.Drawing.Point(168, 112)
        Me.CboResponsableDt.Name = "CboResponsableDt"
        Me.CboResponsableDt.Size = New System.Drawing.Size(328, 21)
        Me.CboResponsableDt.TabIndex = 83
        '
        'chkRevedit
        '
        Me.chkRevedit.Location = New System.Drawing.Point(16, 72)
        Me.chkRevedit.Name = "chkRevedit"
        Me.chkRevedit.Size = New System.Drawing.Size(128, 32)
        Me.chkRevedit.TabIndex = 82
        Me.chkRevedit.Text = "Por aprobaci�n Revisi�n Editorial"
        '
        'txtrev2
        '
        Me.txtrev2.Enabled = False
        Me.txtrev2.Location = New System.Drawing.Point(312, 72)
        Me.txtrev2.Name = "txtrev2"
        Me.txtrev2.Size = New System.Drawing.Size(96, 20)
        Me.txtrev2.TabIndex = 79
        Me.txtrev2.Text = ""
        '
        'txtrev1
        '
        Me.txtrev1.Enabled = False
        Me.txtrev1.Location = New System.Drawing.Point(168, 72)
        Me.txtrev1.Name = "txtrev1"
        Me.txtrev1.Size = New System.Drawing.Size(104, 20)
        Me.txtrev1.TabIndex = 78
        Me.txtrev1.Text = ""
        '
        'dtrev1
        '
        Me.dtrev1.Enabled = False
        Me.dtrev1.Location = New System.Drawing.Point(168, 72)
        Me.dtrev1.Name = "dtrev1"
        Me.dtrev1.Size = New System.Drawing.Size(120, 20)
        Me.dtrev1.TabIndex = 80
        '
        'dtrev2
        '
        Me.dtrev2.Enabled = False
        Me.dtrev2.Location = New System.Drawing.Point(312, 72)
        Me.dtrev2.Name = "dtrev2"
        Me.dtrev2.Size = New System.Drawing.Size(112, 20)
        Me.dtrev2.TabIndex = 81
        '
        'chknmx
        '
        Me.chknmx.Location = New System.Drawing.Point(16, 32)
        Me.chknmx.Name = "chknmx"
        Me.chknmx.Size = New System.Drawing.Size(128, 32)
        Me.chknmx.TabIndex = 77
        Me.chknmx.Text = "Por Inicio Desarrollo NMX"
        '
        'txtnmx2
        '
        Me.txtnmx2.Enabled = False
        Me.txtnmx2.Location = New System.Drawing.Point(312, 32)
        Me.txtnmx2.Name = "txtnmx2"
        Me.txtnmx2.Size = New System.Drawing.Size(96, 20)
        Me.txtnmx2.TabIndex = 74
        Me.txtnmx2.Text = ""
        '
        'txtnmx1
        '
        Me.txtnmx1.Enabled = False
        Me.txtnmx1.Location = New System.Drawing.Point(168, 32)
        Me.txtnmx1.Name = "txtnmx1"
        Me.txtnmx1.Size = New System.Drawing.Size(104, 20)
        Me.txtnmx1.TabIndex = 73
        Me.txtnmx1.Text = ""
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(336, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 16)
        Me.Label2.TabIndex = 72
        Me.Label2.Text = "Fecha de Fin"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(184, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 71
        Me.Label3.Text = "Fecha de Inicio"
        '
        'dtnmx1
        '
        Me.dtnmx1.Enabled = False
        Me.dtnmx1.Location = New System.Drawing.Point(168, 32)
        Me.dtnmx1.Name = "dtnmx1"
        Me.dtnmx1.Size = New System.Drawing.Size(120, 20)
        Me.dtnmx1.TabIndex = 75
        '
        'dtnmx2
        '
        Me.dtnmx2.Enabled = False
        Me.dtnmx2.Location = New System.Drawing.Point(312, 32)
        Me.dtnmx2.Name = "dtnmx2"
        Me.dtnmx2.Size = New System.Drawing.Size(112, 20)
        Me.dtnmx2.TabIndex = 76
        '
        'tbAnt
        '
        Me.tbAnt.Controls.Add(Me.Textant)
        Me.tbAnt.Controls.Add(Me.Label11)
        Me.tbAnt.Controls.Add(Me.grdresultadosant)
        Me.tbAnt.Controls.Add(Me.chkresponsableant)
        Me.tbAnt.Controls.Add(Me.txtresponsableant)
        Me.tbAnt.Controls.Add(Me.cboresponsableant)
        Me.tbAnt.Controls.Add(Me.Label6)
        Me.tbAnt.Controls.Add(Me.Label7)
        Me.tbAnt.Controls.Add(Me.chkfechaAprob)
        Me.tbAnt.Controls.Add(Me.txtfaprob2)
        Me.tbAnt.Controls.Add(Me.txtfaprob1)
        Me.tbAnt.Controls.Add(Me.dtfaprob1)
        Me.tbAnt.Controls.Add(Me.dtfaprob2)
        Me.tbAnt.Controls.Add(Me.chkclasificacion)
        Me.tbAnt.Controls.Add(Me.txtClasificacionant)
        Me.tbAnt.Location = New System.Drawing.Point(4, 22)
        Me.tbAnt.Name = "tbAnt"
        Me.tbAnt.Size = New System.Drawing.Size(736, 622)
        Me.tbAnt.TabIndex = 2
        Me.tbAnt.Text = "Anteproyecto"
        Me.tbAnt.Visible = False
        '
        'Textant
        '
        Me.Textant.Enabled = False
        Me.Textant.Location = New System.Drawing.Point(624, 584)
        Me.Textant.Name = "Textant"
        Me.Textant.TabIndex = 232
        Me.Textant.Text = ""
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(552, 584)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(33, 16)
        Me.Label11.TabIndex = 231
        Me.Label11.Text = "Total:"
        '
        'grdresultadosant
        '
        Me.grdresultadosant.DataMember = ""
        Me.grdresultadosant.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdresultadosant.Location = New System.Drawing.Point(8, 216)
        Me.grdresultadosant.Name = "grdresultadosant"
        Me.grdresultadosant.Size = New System.Drawing.Size(720, 360)
        Me.grdresultadosant.TabIndex = 94
        '
        'chkresponsableant
        '
        Me.chkresponsableant.Location = New System.Drawing.Point(8, 152)
        Me.chkresponsableant.Name = "chkresponsableant"
        Me.chkresponsableant.Size = New System.Drawing.Size(160, 32)
        Me.chkresponsableant.TabIndex = 88
        Me.chkresponsableant.Text = "Responsable Tema Anteproyecto"
        '
        'txtresponsableant
        '
        Me.txtresponsableant.Enabled = False
        Me.txtresponsableant.Location = New System.Drawing.Point(176, 152)
        Me.txtresponsableant.Name = "txtresponsableant"
        Me.txtresponsableant.Size = New System.Drawing.Size(312, 20)
        Me.txtresponsableant.TabIndex = 87
        Me.txtresponsableant.Text = ""
        '
        'cboresponsableant
        '
        Me.cboresponsableant.ItemHeight = 13
        Me.cboresponsableant.Location = New System.Drawing.Point(176, 152)
        Me.cboresponsableant.Name = "cboresponsableant"
        Me.cboresponsableant.Size = New System.Drawing.Size(328, 21)
        Me.cboresponsableant.TabIndex = 86
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(336, 80)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 16)
        Me.Label6.TabIndex = 85
        Me.Label6.Text = "Fecha de Fin"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(184, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 16)
        Me.Label7.TabIndex = 84
        Me.Label7.Text = "Fecha de Inicio"
        '
        'chkfechaAprob
        '
        Me.chkfechaAprob.Location = New System.Drawing.Point(8, 104)
        Me.chkfechaAprob.Name = "chkfechaAprob"
        Me.chkfechaAprob.Size = New System.Drawing.Size(152, 32)
        Me.chkfechaAprob.TabIndex = 83
        Me.chkfechaAprob.Text = "Por Fecha de Aprobaci�n del CT o Gt"
        '
        'txtfaprob2
        '
        Me.txtfaprob2.Enabled = False
        Me.txtfaprob2.Location = New System.Drawing.Point(320, 104)
        Me.txtfaprob2.Name = "txtfaprob2"
        Me.txtfaprob2.Size = New System.Drawing.Size(96, 20)
        Me.txtfaprob2.TabIndex = 80
        Me.txtfaprob2.Text = ""
        '
        'txtfaprob1
        '
        Me.txtfaprob1.Enabled = False
        Me.txtfaprob1.Location = New System.Drawing.Point(176, 104)
        Me.txtfaprob1.Name = "txtfaprob1"
        Me.txtfaprob1.Size = New System.Drawing.Size(104, 20)
        Me.txtfaprob1.TabIndex = 79
        Me.txtfaprob1.Text = ""
        '
        'dtfaprob1
        '
        Me.dtfaprob1.Enabled = False
        Me.dtfaprob1.Location = New System.Drawing.Point(176, 104)
        Me.dtfaprob1.Name = "dtfaprob1"
        Me.dtfaprob1.Size = New System.Drawing.Size(120, 20)
        Me.dtfaprob1.TabIndex = 81
        '
        'dtfaprob2
        '
        Me.dtfaprob2.Enabled = False
        Me.dtfaprob2.Location = New System.Drawing.Point(320, 104)
        Me.dtfaprob2.Name = "dtfaprob2"
        Me.dtfaprob2.Size = New System.Drawing.Size(112, 20)
        Me.dtfaprob2.TabIndex = 82
        '
        'chkclasificacion
        '
        Me.chkclasificacion.Location = New System.Drawing.Point(8, 48)
        Me.chkclasificacion.Name = "chkclasificacion"
        Me.chkclasificacion.Size = New System.Drawing.Size(160, 32)
        Me.chkclasificacion.TabIndex = 78
        Me.chkclasificacion.Text = "Por Clasificaci�n"
        '
        'txtClasificacionant
        '
        Me.txtClasificacionant.Enabled = False
        Me.txtClasificacionant.Location = New System.Drawing.Point(176, 48)
        Me.txtClasificacionant.Name = "txtClasificacionant"
        Me.txtClasificacionant.Size = New System.Drawing.Size(224, 20)
        Me.txtClasificacionant.TabIndex = 50
        Me.txtClasificacionant.Text = ""
        '
        'tbProy
        '
        Me.tbProy.Controls.Add(Me.Textproy)
        Me.tbProy.Controls.Add(Me.Label10)
        Me.tbProy.Controls.Add(Me.chkDgn)
        Me.tbProy.Controls.Add(Me.txtdgn2)
        Me.tbProy.Controls.Add(Me.txtDgn)
        Me.tbProy.Controls.Add(Me.dtDgn)
        Me.tbProy.Controls.Add(Me.dtdgn2)
        Me.tbProy.Controls.Add(Me.chkfedproyf)
        Me.tbProy.Controls.Add(Me.txtfedproyf2)
        Me.tbProy.Controls.Add(Me.txtfedproyf)
        Me.tbProy.Controls.Add(Me.dtfedproyf)
        Me.tbProy.Controls.Add(Me.dtfedproyf2)
        Me.tbProy.Controls.Add(Me.chkfrevproyf)
        Me.tbProy.Controls.Add(Me.txtfrevproyf2)
        Me.tbProy.Controls.Add(Me.txtfrevproyf)
        Me.tbProy.Controls.Add(Me.dtfrevproyf)
        Me.tbProy.Controls.Add(Me.dtfrevproyf2)
        Me.tbProy.Controls.Add(Me.chkvobo)
        Me.tbProy.Controls.Add(Me.txtvobo2)
        Me.tbProy.Controls.Add(Me.txtvobo)
        Me.tbProy.Controls.Add(Me.dtvobo)
        Me.tbProy.Controls.Add(Me.dtvobo2)
        Me.tbProy.Controls.Add(Me.chkaprobres)
        Me.tbProy.Controls.Add(Me.txtaprobres2)
        Me.tbProy.Controls.Add(Me.txtaprobres)
        Me.tbProy.Controls.Add(Me.dtaprobres)
        Me.tbProy.Controls.Add(Me.dtaprobres2)
        Me.tbProy.Controls.Add(Me.chkres)
        Me.tbProy.Controls.Add(Me.txtres2)
        Me.tbProy.Controls.Add(Me.txtres)
        Me.tbProy.Controls.Add(Me.dtres)
        Me.tbProy.Controls.Add(Me.dtres2)
        Me.tbProy.Controls.Add(Me.chkpubcom)
        Me.tbProy.Controls.Add(Me.txtfpubcom2)
        Me.tbProy.Controls.Add(Me.txtfpubcom)
        Me.tbProy.Controls.Add(Me.dtpubcom)
        Me.tbProy.Controls.Add(Me.dtpubcom2)
        Me.tbProy.Controls.Add(Me.Label8)
        Me.tbProy.Controls.Add(Me.Label9)
        Me.tbProy.Controls.Add(Me.chkapCom)
        Me.tbProy.Controls.Add(Me.txtfaprcom2)
        Me.tbProy.Controls.Add(Me.txtfaprcom1)
        Me.tbProy.Controls.Add(Me.dtfaprocom1)
        Me.tbProy.Controls.Add(Me.dtfaprocom2)
        Me.tbProy.Controls.Add(Me.chkresponsable_proy)
        Me.tbProy.Controls.Add(Me.txtresponsable_proy)
        Me.tbProy.Controls.Add(Me.cboResponsable_proy)
        Me.tbProy.Controls.Add(Me.chkclasificacionproy)
        Me.tbProy.Controls.Add(Me.txtclasificacion_proy)
        Me.tbProy.Controls.Add(Me.grdresultadosproy)
        Me.tbProy.Location = New System.Drawing.Point(4, 22)
        Me.tbProy.Name = "tbProy"
        Me.tbProy.Size = New System.Drawing.Size(736, 622)
        Me.tbProy.TabIndex = 5
        Me.tbProy.Text = "Proyecto"
        Me.tbProy.Visible = False
        '
        'Textproy
        '
        Me.Textproy.Enabled = False
        Me.Textproy.Location = New System.Drawing.Point(608, 414)
        Me.Textproy.Name = "Textproy"
        Me.Textproy.TabIndex = 230
        Me.Textproy.Text = ""
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(536, 416)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(33, 16)
        Me.Label10.TabIndex = 229
        Me.Label10.Text = "Total:"
        '
        'chkDgn
        '
        Me.chkDgn.Location = New System.Drawing.Point(16, 408)
        Me.chkDgn.Name = "chkDgn"
        Me.chkDgn.Size = New System.Drawing.Size(144, 32)
        Me.chkDgn.TabIndex = 228
        Me.chkDgn.Text = "Por Fecha de acuse DGN PROYF"
        '
        'txtdgn2
        '
        Me.txtdgn2.Enabled = False
        Me.txtdgn2.Location = New System.Drawing.Point(296, 408)
        Me.txtdgn2.Name = "txtdgn2"
        Me.txtdgn2.Size = New System.Drawing.Size(88, 20)
        Me.txtdgn2.TabIndex = 225
        Me.txtdgn2.Text = ""
        '
        'txtDgn
        '
        Me.txtDgn.Enabled = False
        Me.txtDgn.Location = New System.Drawing.Point(176, 408)
        Me.txtDgn.Name = "txtDgn"
        Me.txtDgn.Size = New System.Drawing.Size(96, 20)
        Me.txtDgn.TabIndex = 224
        Me.txtDgn.Text = ""
        '
        'dtDgn
        '
        Me.dtDgn.Enabled = False
        Me.dtDgn.Location = New System.Drawing.Point(176, 408)
        Me.dtDgn.Name = "dtDgn"
        Me.dtDgn.Size = New System.Drawing.Size(112, 20)
        Me.dtDgn.TabIndex = 226
        '
        'dtdgn2
        '
        Me.dtdgn2.Enabled = False
        Me.dtdgn2.Location = New System.Drawing.Point(296, 408)
        Me.dtdgn2.Name = "dtdgn2"
        Me.dtdgn2.Size = New System.Drawing.Size(104, 20)
        Me.dtdgn2.TabIndex = 227
        '
        'chkfedproyf
        '
        Me.chkfedproyf.Location = New System.Drawing.Point(16, 368)
        Me.chkfedproyf.Name = "chkfedproyf"
        Me.chkfedproyf.Size = New System.Drawing.Size(144, 40)
        Me.chkfedproyf.TabIndex = 223
        Me.chkfedproyf.Text = "Por Fecha de edici�n PROYF"
        '
        'txtfedproyf2
        '
        Me.txtfedproyf2.Enabled = False
        Me.txtfedproyf2.Location = New System.Drawing.Point(296, 368)
        Me.txtfedproyf2.Name = "txtfedproyf2"
        Me.txtfedproyf2.Size = New System.Drawing.Size(88, 20)
        Me.txtfedproyf2.TabIndex = 220
        Me.txtfedproyf2.Text = ""
        '
        'txtfedproyf
        '
        Me.txtfedproyf.Enabled = False
        Me.txtfedproyf.Location = New System.Drawing.Point(176, 368)
        Me.txtfedproyf.Name = "txtfedproyf"
        Me.txtfedproyf.Size = New System.Drawing.Size(96, 20)
        Me.txtfedproyf.TabIndex = 219
        Me.txtfedproyf.Text = ""
        '
        'dtfedproyf
        '
        Me.dtfedproyf.Enabled = False
        Me.dtfedproyf.Location = New System.Drawing.Point(176, 368)
        Me.dtfedproyf.Name = "dtfedproyf"
        Me.dtfedproyf.Size = New System.Drawing.Size(112, 20)
        Me.dtfedproyf.TabIndex = 221
        '
        'dtfedproyf2
        '
        Me.dtfedproyf2.Enabled = False
        Me.dtfedproyf2.Location = New System.Drawing.Point(296, 368)
        Me.dtfedproyf2.Name = "dtfedproyf2"
        Me.dtfedproyf2.Size = New System.Drawing.Size(104, 20)
        Me.dtfedproyf2.TabIndex = 222
        '
        'chkfrevproyf
        '
        Me.chkfrevproyf.Location = New System.Drawing.Point(16, 328)
        Me.chkfrevproyf.Name = "chkfrevproyf"
        Me.chkfrevproyf.Size = New System.Drawing.Size(144, 40)
        Me.chkfrevproyf.TabIndex = 218
        Me.chkfrevproyf.Text = "Por Fecha de  Revisi�n PROYF"
        '
        'txtfrevproyf2
        '
        Me.txtfrevproyf2.Enabled = False
        Me.txtfrevproyf2.Location = New System.Drawing.Point(296, 328)
        Me.txtfrevproyf2.Name = "txtfrevproyf2"
        Me.txtfrevproyf2.Size = New System.Drawing.Size(88, 20)
        Me.txtfrevproyf2.TabIndex = 215
        Me.txtfrevproyf2.Text = ""
        '
        'txtfrevproyf
        '
        Me.txtfrevproyf.Enabled = False
        Me.txtfrevproyf.Location = New System.Drawing.Point(176, 328)
        Me.txtfrevproyf.Name = "txtfrevproyf"
        Me.txtfrevproyf.Size = New System.Drawing.Size(96, 20)
        Me.txtfrevproyf.TabIndex = 214
        Me.txtfrevproyf.Text = ""
        '
        'dtfrevproyf
        '
        Me.dtfrevproyf.Enabled = False
        Me.dtfrevproyf.Location = New System.Drawing.Point(176, 328)
        Me.dtfrevproyf.Name = "dtfrevproyf"
        Me.dtfrevproyf.Size = New System.Drawing.Size(112, 20)
        Me.dtfrevproyf.TabIndex = 216
        '
        'dtfrevproyf2
        '
        Me.dtfrevproyf2.Enabled = False
        Me.dtfrevproyf2.Location = New System.Drawing.Point(296, 328)
        Me.dtfrevproyf2.Name = "dtfrevproyf2"
        Me.dtfrevproyf2.Size = New System.Drawing.Size(104, 20)
        Me.dtfrevproyf2.TabIndex = 217
        '
        'chkvobo
        '
        Me.chkvobo.Location = New System.Drawing.Point(16, 288)
        Me.chkvobo.Name = "chkvobo"
        Me.chkvobo.Size = New System.Drawing.Size(144, 32)
        Me.chkvobo.TabIndex = 213
        Me.chkvobo.Text = "Por Fecha Vo Bo Comit�"
        '
        'txtvobo2
        '
        Me.txtvobo2.Enabled = False
        Me.txtvobo2.Location = New System.Drawing.Point(296, 288)
        Me.txtvobo2.Name = "txtvobo2"
        Me.txtvobo2.Size = New System.Drawing.Size(88, 20)
        Me.txtvobo2.TabIndex = 210
        Me.txtvobo2.Text = ""
        '
        'txtvobo
        '
        Me.txtvobo.Enabled = False
        Me.txtvobo.Location = New System.Drawing.Point(176, 288)
        Me.txtvobo.Name = "txtvobo"
        Me.txtvobo.Size = New System.Drawing.Size(96, 20)
        Me.txtvobo.TabIndex = 209
        Me.txtvobo.Text = ""
        '
        'dtvobo
        '
        Me.dtvobo.Enabled = False
        Me.dtvobo.Location = New System.Drawing.Point(176, 288)
        Me.dtvobo.Name = "dtvobo"
        Me.dtvobo.Size = New System.Drawing.Size(112, 20)
        Me.dtvobo.TabIndex = 211
        '
        'dtvobo2
        '
        Me.dtvobo2.Enabled = False
        Me.dtvobo2.Location = New System.Drawing.Point(296, 288)
        Me.dtvobo2.Name = "dtvobo2"
        Me.dtvobo2.Size = New System.Drawing.Size(104, 20)
        Me.dtvobo2.TabIndex = 212
        '
        'chkaprobres
        '
        Me.chkaprobres.Location = New System.Drawing.Point(16, 240)
        Me.chkaprobres.Name = "chkaprobres"
        Me.chkaprobres.Size = New System.Drawing.Size(160, 40)
        Me.chkaprobres.TabIndex = 208
        Me.chkaprobres.Text = "Por Fecha de Aprobaci�n de Resoluci�n a comentario P�blico"
        '
        'txtaprobres2
        '
        Me.txtaprobres2.Enabled = False
        Me.txtaprobres2.Location = New System.Drawing.Point(296, 240)
        Me.txtaprobres2.Name = "txtaprobres2"
        Me.txtaprobres2.Size = New System.Drawing.Size(88, 20)
        Me.txtaprobres2.TabIndex = 205
        Me.txtaprobres2.Text = ""
        '
        'txtaprobres
        '
        Me.txtaprobres.Enabled = False
        Me.txtaprobres.Location = New System.Drawing.Point(176, 240)
        Me.txtaprobres.Name = "txtaprobres"
        Me.txtaprobres.Size = New System.Drawing.Size(96, 20)
        Me.txtaprobres.TabIndex = 204
        Me.txtaprobres.Text = ""
        '
        'dtaprobres
        '
        Me.dtaprobres.Enabled = False
        Me.dtaprobres.Location = New System.Drawing.Point(176, 240)
        Me.dtaprobres.Name = "dtaprobres"
        Me.dtaprobres.Size = New System.Drawing.Size(112, 20)
        Me.dtaprobres.TabIndex = 206
        '
        'dtaprobres2
        '
        Me.dtaprobres2.Enabled = False
        Me.dtaprobres2.Location = New System.Drawing.Point(296, 240)
        Me.dtaprobres2.Name = "dtaprobres2"
        Me.dtaprobres2.Size = New System.Drawing.Size(104, 20)
        Me.dtaprobres2.TabIndex = 207
        '
        'chkres
        '
        Me.chkres.Location = New System.Drawing.Point(16, 200)
        Me.chkres.Name = "chkres"
        Me.chkres.Size = New System.Drawing.Size(152, 32)
        Me.chkres.TabIndex = 203
        Me.chkres.Text = "Por Fecha de Resoluci�n a Comentario P�blico"
        '
        'txtres2
        '
        Me.txtres2.Enabled = False
        Me.txtres2.Location = New System.Drawing.Point(296, 200)
        Me.txtres2.Name = "txtres2"
        Me.txtres2.Size = New System.Drawing.Size(88, 20)
        Me.txtres2.TabIndex = 200
        Me.txtres2.Text = ""
        '
        'txtres
        '
        Me.txtres.Enabled = False
        Me.txtres.Location = New System.Drawing.Point(176, 200)
        Me.txtres.Name = "txtres"
        Me.txtres.Size = New System.Drawing.Size(96, 20)
        Me.txtres.TabIndex = 199
        Me.txtres.Text = ""
        '
        'dtres
        '
        Me.dtres.Enabled = False
        Me.dtres.Location = New System.Drawing.Point(176, 200)
        Me.dtres.Name = "dtres"
        Me.dtres.Size = New System.Drawing.Size(112, 20)
        Me.dtres.TabIndex = 201
        '
        'dtres2
        '
        Me.dtres2.Enabled = False
        Me.dtres2.Location = New System.Drawing.Point(296, 200)
        Me.dtres2.Name = "dtres2"
        Me.dtres2.Size = New System.Drawing.Size(104, 20)
        Me.dtres2.TabIndex = 202
        '
        'chkpubcom
        '
        Me.chkpubcom.Location = New System.Drawing.Point(16, 160)
        Me.chkpubcom.Name = "chkpubcom"
        Me.chkpubcom.Size = New System.Drawing.Size(152, 32)
        Me.chkpubcom.TabIndex = 198
        Me.chkpubcom.Text = "Por Fecha de Publicaci�n a periodo de Comentario P�blico"
        '
        'txtfpubcom2
        '
        Me.txtfpubcom2.Enabled = False
        Me.txtfpubcom2.Location = New System.Drawing.Point(296, 160)
        Me.txtfpubcom2.Name = "txtfpubcom2"
        Me.txtfpubcom2.Size = New System.Drawing.Size(88, 20)
        Me.txtfpubcom2.TabIndex = 195
        Me.txtfpubcom2.Text = ""
        '
        'txtfpubcom
        '
        Me.txtfpubcom.Enabled = False
        Me.txtfpubcom.Location = New System.Drawing.Point(176, 160)
        Me.txtfpubcom.Name = "txtfpubcom"
        Me.txtfpubcom.Size = New System.Drawing.Size(96, 20)
        Me.txtfpubcom.TabIndex = 194
        Me.txtfpubcom.Text = ""
        '
        'dtpubcom
        '
        Me.dtpubcom.Enabled = False
        Me.dtpubcom.Location = New System.Drawing.Point(176, 160)
        Me.dtpubcom.Name = "dtpubcom"
        Me.dtpubcom.Size = New System.Drawing.Size(112, 20)
        Me.dtpubcom.TabIndex = 196
        '
        'dtpubcom2
        '
        Me.dtpubcom2.Enabled = False
        Me.dtpubcom2.Location = New System.Drawing.Point(296, 160)
        Me.dtpubcom2.Name = "dtpubcom2"
        Me.dtpubcom2.Size = New System.Drawing.Size(104, 20)
        Me.dtpubcom2.TabIndex = 197
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(312, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 16)
        Me.Label8.TabIndex = 193
        Me.Label8.Text = "Fecha de Fin"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(184, 96)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 16)
        Me.Label9.TabIndex = 192
        Me.Label9.Text = "Fecha de Inicio"
        '
        'chkapCom
        '
        Me.chkapCom.Location = New System.Drawing.Point(16, 120)
        Me.chkapCom.Name = "chkapCom"
        Me.chkapCom.Size = New System.Drawing.Size(144, 32)
        Me.chkapCom.TabIndex = 191
        Me.chkapCom.Text = "Por Fecha de Aprobaci�n Comit� Proy"
        '
        'txtfaprcom2
        '
        Me.txtfaprcom2.Enabled = False
        Me.txtfaprcom2.Location = New System.Drawing.Point(296, 120)
        Me.txtfaprcom2.Name = "txtfaprcom2"
        Me.txtfaprcom2.Size = New System.Drawing.Size(88, 20)
        Me.txtfaprcom2.TabIndex = 188
        Me.txtfaprcom2.Text = ""
        '
        'txtfaprcom1
        '
        Me.txtfaprcom1.Enabled = False
        Me.txtfaprcom1.Location = New System.Drawing.Point(176, 120)
        Me.txtfaprcom1.Name = "txtfaprcom1"
        Me.txtfaprcom1.Size = New System.Drawing.Size(96, 20)
        Me.txtfaprcom1.TabIndex = 187
        Me.txtfaprcom1.Text = ""
        '
        'dtfaprocom1
        '
        Me.dtfaprocom1.Enabled = False
        Me.dtfaprocom1.Location = New System.Drawing.Point(176, 120)
        Me.dtfaprocom1.Name = "dtfaprocom1"
        Me.dtfaprocom1.Size = New System.Drawing.Size(112, 20)
        Me.dtfaprocom1.TabIndex = 189
        '
        'dtfaprocom2
        '
        Me.dtfaprocom2.Enabled = False
        Me.dtfaprocom2.Location = New System.Drawing.Point(296, 120)
        Me.dtfaprocom2.Name = "dtfaprocom2"
        Me.dtfaprocom2.Size = New System.Drawing.Size(104, 20)
        Me.dtfaprocom2.TabIndex = 190
        '
        'chkresponsable_proy
        '
        Me.chkresponsable_proy.Location = New System.Drawing.Point(16, 64)
        Me.chkresponsable_proy.Name = "chkresponsable_proy"
        Me.chkresponsable_proy.Size = New System.Drawing.Size(136, 32)
        Me.chkresponsable_proy.TabIndex = 186
        Me.chkresponsable_proy.Text = "Responsable Tema Proyecto"
        '
        'txtresponsable_proy
        '
        Me.txtresponsable_proy.Enabled = False
        Me.txtresponsable_proy.Location = New System.Drawing.Point(176, 64)
        Me.txtresponsable_proy.Name = "txtresponsable_proy"
        Me.txtresponsable_proy.Size = New System.Drawing.Size(288, 20)
        Me.txtresponsable_proy.TabIndex = 184
        Me.txtresponsable_proy.Text = ""
        '
        'cboResponsable_proy
        '
        Me.cboResponsable_proy.ItemHeight = 13
        Me.cboResponsable_proy.Location = New System.Drawing.Point(176, 64)
        Me.cboResponsable_proy.Name = "cboResponsable_proy"
        Me.cboResponsable_proy.Size = New System.Drawing.Size(304, 21)
        Me.cboResponsable_proy.TabIndex = 185
        '
        'chkclasificacionproy
        '
        Me.chkclasificacionproy.Location = New System.Drawing.Point(16, 24)
        Me.chkclasificacionproy.Name = "chkclasificacionproy"
        Me.chkclasificacionproy.Size = New System.Drawing.Size(152, 32)
        Me.chkclasificacionproy.TabIndex = 183
        Me.chkclasificacionproy.Text = "Por Clasificaci�n"
        '
        'txtclasificacion_proy
        '
        Me.txtclasificacion_proy.Enabled = False
        Me.txtclasificacion_proy.Location = New System.Drawing.Point(176, 32)
        Me.txtclasificacion_proy.Name = "txtclasificacion_proy"
        Me.txtclasificacion_proy.Size = New System.Drawing.Size(304, 20)
        Me.txtclasificacion_proy.TabIndex = 182
        Me.txtclasificacion_proy.Text = ""
        '
        'grdresultadosproy
        '
        Me.grdresultadosproy.DataMember = ""
        Me.grdresultadosproy.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdresultadosproy.Location = New System.Drawing.Point(16, 448)
        Me.grdresultadosproy.Name = "grdresultadosproy"
        Me.grdresultadosproy.Size = New System.Drawing.Size(696, 152)
        Me.grdresultadosproy.TabIndex = 135
        '
        'chkcomite
        '
        Me.chkcomite.Location = New System.Drawing.Point(16, 216)
        Me.chkcomite.Name = "chkcomite"
        Me.chkcomite.Size = New System.Drawing.Size(96, 24)
        Me.chkcomite.TabIndex = 86
        Me.chkcomite.Text = "Por Comit�"
        '
        'txtcomite
        '
        Me.txtcomite.Enabled = False
        Me.txtcomite.Location = New System.Drawing.Point(16, 536)
        Me.txtcomite.Name = "txtcomite"
        Me.txtcomite.Size = New System.Drawing.Size(160, 20)
        Me.txtcomite.TabIndex = 85
        Me.txtcomite.Text = ""
        '
        'TVcomites
        '
        Me.TVcomites.Enabled = False
        Me.TVcomites.ImageList = Me.imgListTreeView
        Me.TVcomites.Location = New System.Drawing.Point(8, 248)
        Me.TVcomites.Name = "TVcomites"
        Me.TVcomites.Size = New System.Drawing.Size(192, 280)
        Me.TVcomites.TabIndex = 83
        '
        'lblpertenece
        '
        Me.lblpertenece.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpertenece.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.lblpertenece.Location = New System.Drawing.Point(248, 768)
        Me.lblpertenece.Name = "lblpertenece"
        Me.lblpertenece.Size = New System.Drawing.Size(336, 32)
        Me.lblpertenece.TabIndex = 18
        '
        'chketapas
        '
        Me.chketapas.Location = New System.Drawing.Point(16, 576)
        Me.chketapas.Name = "chketapas"
        Me.chketapas.Size = New System.Drawing.Size(88, 32)
        Me.chketapas.TabIndex = 91
        Me.chketapas.Text = "Por Etapa"
        Me.chketapas.Visible = False
        '
        'txtetapas
        '
        Me.txtetapas.Enabled = False
        Me.txtetapas.Location = New System.Drawing.Point(8, 616)
        Me.txtetapas.Name = "txtetapas"
        Me.txtetapas.Size = New System.Drawing.Size(208, 20)
        Me.txtetapas.TabIndex = 90
        Me.txtetapas.Text = ""
        Me.txtetapas.Visible = False
        '
        'cboetapas
        '
        Me.cboetapas.Enabled = False
        Me.cboetapas.ItemHeight = 13
        Me.cboetapas.Location = New System.Drawing.Point(8, 616)
        Me.cboetapas.Name = "cboetapas"
        Me.cboetapas.Size = New System.Drawing.Size(224, 21)
        Me.cboetapas.TabIndex = 89
        Me.cboetapas.Visible = False
        '
        'FrmQTemas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1000, 734)
        Me.Controls.Add(Me.lblpertenece)
        Me.Controls.Add(Me.TBpt)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TVPNN)
        Me.Controls.Add(Me.chkcomite)
        Me.Controls.Add(Me.TVcomites)
        Me.Controls.Add(Me.txtcomite)
        Me.Controls.Add(Me.chketapas)
        Me.Controls.Add(Me.txtetapas)
        Me.Controls.Add(Me.cboetapas)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmQTemas"
        Me.Text = "Consulta Temas"
        Me.TBpt.ResumeLayout(False)
        Me.TbPgProgramaTrabajo.ResumeLayout(False)
        CType(Me.grdResultadosPT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TbDt.ResumeLayout(False)
        CType(Me.grdresultados_dt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlalternativo.ResumeLayout(False)
        Me.tbAnt.ResumeLayout(False)
        CType(Me.grdresultadosant, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbProy.ResumeLayout(False)
        CType(Me.grdresultadosproy, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

   

    Private Sub DT1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DT1.ValueChanged
        If chkPeriodoPT.Checked = True Then
            txtf1.Text = Format(DT1.Value, "dd/MM/yyyy")
            DT2.Enabled = True
            txtf2.Text = ""
        End If
    End Sub

    Private Sub DT2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DT2.ValueChanged
        If chkPeriodoPT.Checked = True Then
            txtf2.Text = Format(DT2.Value, "dd/MM/yyyy")
            If txtf1.Text > txtf2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtf2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkPeriodoPT_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkPeriodoPT.CheckedChanged
        If chkPeriodoPT.Checked = True Then
            DT1.Enabled = True
        Else
            DT1.Enabled = False
            DT2.Enabled = False
            txtf1.Text = ""
            txtf2.Text = ""

        End If
    End Sub

    Private Sub FrmQTemas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Llena_Plan()
    End Sub



    Private Sub chkTipoTema_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTipoTema.CheckedChanged
        If chkTipoTema.Checked = True Then
            txttipoTema.Enabled = False
            CboTipoTema.Enabled = True
            dtTiposTema = ObjTiposTema.ListaCombo()
            CboTipoTema.DataSource = dtTiposTema
            CboTipoTema.DisplayMember = dtTiposTema.Columns(1).ColumnName
            CboTipoTema.ValueMember = dtTiposTema.Columns(0).ColumnName
            txttipoTema.Text = CboTipoTema.Text

        Else
            txttipoTema.Text = ""
            CboTipoTema.Enabled = False
            dtTiposTema.Clear()


        End If
    End Sub

    Private Sub CboTipoTema_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboTipoTema.SelectedIndexChanged
        If chkTipoTema.Checked = True Then
            txttipoTema.Text = CboTipoTema.Text
        End If
    End Sub

    Private Sub chkResponsable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkResponsable.CheckedChanged
        If chkResponsable.Checked = True Then
            txtresponsable.Enabled = False
            cboResponsable.Enabled = True
            ObjEmpleados.Bandera = 6
            ObjEmpleados.ListaCombo(cboResponsable)
            txtresponsable.Text = cboResponsable.Text
        Else
            txtresponsable.Text = ""
            txtresponsable.Enabled = False
            cboResponsable.Enabled = False
        End If
    End Sub

    Private Sub cboResponsable_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsable.SelectedIndexChanged
        If chkResponsable.Checked = True Then
            txtresponsable.Text = cboResponsable.Text
        End If
    End Sub

    Private Sub cboRevision_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboRevision.SelectedIndexChanged
        If chkrevision.Checked = True Then
            txtrevision.Text = cboRevision.Text
        End If
    End Sub

    Private Sub chkrevision_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkrevision.CheckedChanged
        If chkrevision.Checked = True Then
            txtrevision.Enabled = False
            cboRevision.Enabled = True
            dtRevision = objRevision.ListaCombo()
            cboRevision.DataSource = dtRevision
            cboRevision.DisplayMember = dtRevision.Columns(1).ColumnName
            cboRevision.ValueMember = dtRevision.Columns(0).ColumnName
            txtrevision.Text = cboRevision.Text

        Else
            txtrevision.Enabled = False
            cboRevision.Enabled = False

        End If
    End Sub

    Private Sub chkcomite_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkcomite.CheckedChanged
        If chkcomite.Checked = True Then
            TVcomites.Enabled = True
            txtcomite.Text = ""
            txtcomite.Enabled = False
            Call llena_TreeView()
        Else
            TVcomites.Enabled = False
            txtcomite.Text = ""
            txtcomite.Enabled = False
            TVcomites.Refresh()
            TVcomites.Nodes.Clear()
        End If
    End Sub

#Region " TreeViews, Metodos y procesos"

#Region " TreeView - TVComites, Metodos y procesos"

#Region " TVComites - llena_TreeView(), Metodos y procesos"

    Private Sub llena_TreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = TVcomites.Nodes.Add("Seleccione un Comit�")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        TVcomites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = TVcomites.Nodes.Add("Seleccione un Comit�")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = TVcomites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        TVcomites.EndUpdate()

        TVcomites.ResetText()

        Cursor.Current = Cursors.Default

    End Sub

#End Region

#Region " TVComites - TVcomites_AfterSelect, Metodos y procesos"

    Private Sub TVcomites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVcomites.AfterSelect
        Dim Matriz As Array
        Dim svariable As String
        Dim sraiz As String
        Dim bandera As Integer
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                sComite = "NA"
                sCt = "NA"
                sSc = "NA"
                sGt = "NA"
                txtcomite.Text = ""
            Case 2
                sComite = Matriz(1)
                sCt = ""
                sSc = ""
                sGt = ""
                txtcomite.Text = ""
                txtcomite.Text = Matriz(1)
            Case 3
                If Microsoft.VisualBasic.Left(Matriz(2), 2) = "GT" Then
                    sComite = Matriz(1)
                    sCt = ""
                    sSc = ""
                    sGt = Matriz(2)
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(2)
                Else
                    sComite = Matriz(1)
                    sCt = Matriz(2)
                    sSc = ""
                    sGt = ""
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(2)
                End If


            Case 4
                If Microsoft.VisualBasic.Left(Matriz(3), 2) = "GT" Then
                    sComite = Matriz(1)
                    sCt = Matriz(2)
                    sSc = ""
                    sGt = Matriz(3)
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(3)
                Else
                    sComite = Matriz(1)
                    sCt = Matriz(2)
                    sSc = Matriz(3)
                    sGt = ""
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(3)
                End If

            Case 5
                sComite = Matriz(1)
                sCt = Matriz(2)
                sSc = Matriz(3)
                sGt = Matriz(4)
                txtcomite.Text = ""
                txtcomite.Text = Matriz(4)
        End Select
    End Sub

#End Region

#End Region

#Region " TreeView - TVPNN, Metodos y procesos"

#Region " TVPNN - Llena_Plan(), Metodos y procesos"

    Sub Llena_Plan()
        oTablaPNN = x.ListaPNN("")
        TVPNN.BeginUpdate()
        nodo = TVPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = TVPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = x.ListaDprog(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
        Next
        TVPNN.EndUpdate()
        TVPNN.AllowDrop = False

    End Sub

#End Region

#Region " TVPNN - TVPNN_AfterSelect(), Metodos y procesos"

    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVPNN.AfterSelect
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                stema = ""
                sPlan = ""
                lblpertenece.Text = ""

            Case 2
                sPlan = Matriz(1)
                sEtapa = "Plan"
                lblpertenece.Text = sPlan

                'Case 3
                '    sPlan = Matriz(1)
                '    stema = Matriz(2)
                '    sEtapa = "Tema"
        End Select

    End Sub

#End Region

#End Region

#End Region

#Region " Toolbar - tlbBotonera, Metodos y procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0
                Dim dt As DataTable
                If TBpt.SelectedTab Is TBpt.TabPages(0) Then
                    ObjPrograma.Bandera = 1
                    Call Arma_where_PT()
                    'ObjPrograma.Consulta_Temas(sSentencia)
                    Call DGStyTemasPT()
                    dt = ObjPrograma.Consulta_Temas(sSentencia)
                    grdResultadosPT.DataSource = dt
                    TextPT.Text = dt.Rows.Count
                End If
                If TBpt.SelectedTab Is TBpt.TabPages(1) Then
                    If chktipoproceso.Checked = True And txttipoproceso.Text = "Proceso Alternativo" Then
                        ObjPrograma.Bandera = 3
                    Else
                        ObjPrograma.Bandera = 2
                    End If
                    Call Arma_where_DT()
                    Call DGStytemasDt()
                    dt = ObjPrograma.Consulta_Temas(sSentencia)
                    grdresultados_dt.DataSource = dt
                    TextDT.Text = dt.Rows.Count
                End If
                If TBpt.SelectedTab Is TBpt.TabPages(2) Then
                    ObjPrograma.Bandera = 4
                    Call Arma_Where_Ant()
                    Call DGStytemasAnt()
                    dt = ObjPrograma.Consulta_Temas(sSentencia)
                    grdresultadosant.DataSource = dt
                    Textant.Text = dt.Rows.Count

                End If
                If TBpt.SelectedTab Is TBpt.TabPages(3) Then
                    ObjPrograma.Bandera = 5
                    Call Arma_where_Proy()
                    Call DGStytemasproy()
                    dt = ObjPrograma.Consulta_Temas(sSentencia)
                    grdresultadosproy.DataSource = dt
                    Textproy.Text = dt.Rows.Count
                End If

            Case 1

            Case 2
                Dim dt As DataTable
                If TBpt.SelectedTab Is TBpt.TabPages(0) Then
                    dt = grdResultadosPT.DataSource
                End If
                If TBpt.SelectedTab Is TBpt.TabPages(1) Then
                    dt = grdresultados_dt.DataSource 
                End If
                If TBpt.SelectedTab Is TBpt.TabPages(2) Then
                    dt = grdresultadosant.DataSource
                End If
                If TBpt.SelectedTab Is TBpt.TabPages(3) Then
                    dt = grdresultadosproy.DataSource
                End If
                If dt.Rows.Count > 0 Then
                    DataTableToExcel(CType(dT, DataTable))
                End If
            Case 4
                Me.Close()

        End Select
    End Sub

#End Region

#Region " TableStyles, Metodos y Procesos"

#Region " TableStyles - DGStytemasDt(), Metodos y Procesos"

    Private Sub DGStytemasDt()
        Dim dtcol As DataColumn = Nothing
        Try
            grdresultados_dt.TableStyles.Clear()
            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdresultados_dt)


            ts1.MappingName = "ClsQTemas"
            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Plan"
            TextCol.HeaderText = "Plan"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Id_Tema"
            TextCol1.HeaderText = "Tema"
            TextCol1.Width = 55
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Clasificacion_Dt"
            TextCol2.HeaderText = "Clasificacion Dt"
            TextCol2.Width = 210
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Titulo_Dt"
            TextCol3.HeaderText = "T�tulo"
            TextCol3.Width = 180
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Act_Aprob"
            TextCol4.HeaderText = "Acta Aprobaci�n"
            TextCol4.Width = 140
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "Responsable"
            TextCol5.HeaderText = "Responsable Dt"
            TextCol5.Width = 140
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "F_Inic_Desarrollo_Nmx"
            TextCol6.HeaderText = "Inicio Nmx"
            TextCol6.Width = 180
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "F_Aprob_Revisi�n_Editorial"
            TextCol7.HeaderText = "Aprob Revisi�n Editorial"
            TextCol7.Width = 140
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "F_Carga_DtFinal"
            TextCol8.HeaderText = "Carga Dt Final"
            TextCol8.Width = 140
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)

            Dim TextCol9 As New DataGridTextBoxColumn
            TextCol9.MappingName = "F_Impresion_ActaAprobacion"
            TextCol9.HeaderText = "Impr Acta Aprobaci�n"
            TextCol9.Width = 140
            TextCol9.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol9)

            Dim TextCol10 As New DataGridTextBoxColumn
            TextCol10.MappingName = "F_Carga_ActaAprobacion"
            TextCol10.HeaderText = "Carga Act Aprob"
            TextCol10.Width = 140
            TextCol10.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol10)

            Dim TextCol11 As New DataGridTextBoxColumn
            TextCol11.MappingName = "Descripcion"
            TextCol11.HeaderText = "Tipo Tema"
            TextCol11.Width = 140
            TextCol11.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol11)

            Dim TextCol12 As New DataGridTextBoxColumn
            TextCol12.MappingName = "Resp_Proc_Alter"
            TextCol12.HeaderText = "Responsable Proc Alter"
            TextCol12.Width = 180
            TextCol12.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol12)

            Dim TextCol13 As New DataGridTextBoxColumn
            TextCol13.MappingName = "F_Inicio_Responsable"
            TextCol13.HeaderText = "Fecha inicio responsable"
            TextCol13.Width = 180
            TextCol13.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol13)

            Dim TextCol14 As New DataGridTextBoxColumn
            TextCol14.MappingName = "F_Fin_Responsable"
            TextCol14.HeaderText = "Fecha Fin responsable"
            TextCol14.Width = 180
            TextCol14.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol14)

            Dim TextCol15 As New DataGridTextBoxColumn
            TextCol15.MappingName = "F_Inicio_Comentarios"
            TextCol15.HeaderText = "Fecha Inicio Comentarios Proc alter"
            TextCol15.Width = 180
            TextCol15.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol15)

            Dim TextCol16 As New DataGridTextBoxColumn
            TextCol16.MappingName = "F_Fin_Comentarios"
            TextCol16.HeaderText = "Fecha Fin Comentarios Proc alter"
            TextCol16.Width = 180
            TextCol16.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol16)

            Dim TextCol17 As New DataGridTextBoxColumn
            TextCol17.MappingName = "F_Carga_Minuta_Terminacion"
            TextCol17.HeaderText = "Fecha Carga Minuta Terminaci�n Proc alternativo"
            TextCol17.Width = 180
            TextCol17.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol17)



            grdresultados_dt.TableStyles.Add(ts1)


        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub
#End Region

#Region " TableStyles - , Metodos y Procesos"
    Private Sub DGStyTemasPT()
        Dim dtcol As DataColumn = Nothing
        Try
            grdResultadosPT.TableStyles.Clear()

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdResultadosPT)


            ts1.MappingName = "ClsQTemas"
            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Plan"
            TextCol.HeaderText = "Plan"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Id_Tema"
            TextCol1.HeaderText = "Tema"
            TextCol1.Width = 55
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Clasificacion"
            TextCol2.HeaderText = "Clasificacion"
            TextCol2.Width = 210
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Titulo"
            TextCol3.HeaderText = "T�tulo"
            TextCol3.Width = 180
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "F_Inicio"
            TextCol4.HeaderText = "Inicio"
            TextCol4.Width = 140
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "F_Fin"
            TextCol5.HeaderText = "Fin"
            TextCol5.Width = 140
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "Descripcion"
            TextCol6.HeaderText = "Revisi�n"
            TextCol6.Width = 180
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "ID_Comite"
            TextCol7.HeaderText = "Comit�"
            TextCol7.Width = 140
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "ID_CT"
            TextCol8.HeaderText = "Comit� T�cnico"
            TextCol8.Width = 140
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)

            Dim TextCol9 As New DataGridTextBoxColumn
            TextCol9.MappingName = "ID_SC"
            TextCol9.HeaderText = "Subcomit�"
            TextCol9.Width = 140
            TextCol9.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol9)

            Dim TextCol10 As New DataGridTextBoxColumn
            TextCol10.MappingName = "ID_Grupo"
            TextCol10.HeaderText = "Grupo de Trabajo"
            TextCol10.Width = 140
            TextCol10.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol10)

            Dim TextCol11 As New DataGridTextBoxColumn
            TextCol11.MappingName = "Responsable"
            TextCol11.HeaderText = "Responsable"
            TextCol11.Width = 140
            TextCol11.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol11)

            Dim TextCol12 As New DataGridTextBoxColumn
            TextCol12.MappingName = "Etapa"
            TextCol12.HeaderText = "Estatus"
            TextCol12.Width = 180
            TextCol12.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol12)

            Dim TextCol13 As New DataGridTextBoxColumn
            TextCol13.MappingName = "Basado_en"
            TextCol13.HeaderText = "Basado en Norma"
            TextCol13.Width = 180
            TextCol13.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol13)

            grdResultadosPT.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region


    Private Sub DGStytemasAnt()
        Dim dtcol As DataColumn = Nothing
        Try
            grdresultadosant.TableStyles.Clear()

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdresultadosant)


            ts1.MappingName = "ClsQTemas"
            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Plan"
            TextCol.HeaderText = "Plan"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Id_Tema"
            TextCol1.HeaderText = "Tema"
            TextCol1.Width = 55
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Clasificacion_Ant"
            TextCol2.HeaderText = "Clasificacion Ant"
            TextCol2.Width = 210
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Titulo_Ant"
            TextCol3.HeaderText = "T�tulo Ant"
            TextCol3.Width = 180
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Num_Paginas"
            TextCol4.HeaderText = "Num P�ginas"
            TextCol4.Width = 140
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "Responsable_Ant"
            TextCol5.HeaderText = "Responsable Ant"
            TextCol5.Width = 140
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "F_Aprobacion_CTGT_ANT"
            TextCol6.HeaderText = "Fecha de Aprob Anteproyecto"
            TextCol6.Width = 140
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "F_Carga_ANTF"
            TextCol7.HeaderText = "Fecha de Carga Ant Final"
            TextCol7.Width = 140
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)


            grdresultadosant.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try

    End Sub

#End Region

    Private Sub DGStytemasproy()
        Dim dtcol As DataColumn = Nothing
        Try
            grdresultadosproy.TableStyles.Clear()

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdresultadosproy)


            ts1.MappingName = "ClsQTemas"
            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Plan"
            TextCol.HeaderText = "Plan"
            TextCol.Width = 80
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Id_Tema"
            TextCol1.HeaderText = "Tema"
            TextCol1.Width = 55
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Clasificacion_Proy"
            TextCol2.HeaderText = "Clasificacion Proy"
            TextCol2.Width = 210
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Titulo_proy"
            TextCol3.HeaderText = "T�tulo Proy"
            TextCol3.Width = 180
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "num"
            TextCol4.HeaderText = "Num P�ginas"
            TextCol4.Width = 140
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "Responsable_Proy"
            TextCol5.HeaderText = "Responsable Proy"
            TextCol5.Width = 140
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "F_Aprobacion_Comite_PROY"
            TextCol6.HeaderText = "Fecha de Aprob Comit� Proy"
            TextCol6.Width = 140
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "F_Publicacion_ComentarioPublico"
            TextCol7.HeaderText = "Fecha de Publicaci�n Comentario P�blico"
            TextCol7.Width = 140
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "F_Limite_ComentarioPublico"
            TextCol8.HeaderText = "Fecha L�mite de Publicaci�n Comentario P�blico"
            TextCol8.Width = 140
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)

            Dim TextCol9 As New DataGridTextBoxColumn
            TextCol9.MappingName = "F_Resolucion_ComentarioPublico"
            TextCol9.HeaderText = "Fecha Resoluci�n de Comentario P�blico"
            TextCol9.Width = 140
            TextCol9.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol9)

            Dim TextCol10 As New DataGridTextBoxColumn
            TextCol10.MappingName = "F_Limite_Aprobacion_Resolucion_ComentarioPublico"
            TextCol10.HeaderText = "Fecha L�mite de Resoluci�n de Comentario P�blico"
            TextCol10.Width = 140
            TextCol10.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol10)

            Dim TextCol11 As New DataGridTextBoxColumn
            TextCol11.MappingName = "F_Aprobacion_Resolucion_ComentarioPublico"
            TextCol11.HeaderText = "Fecha Aprobaci�n de Resoluci�n de Comentario P�blico"
            TextCol11.Width = 140
            TextCol11.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol11)

            Dim TextCol12 As New DataGridTextBoxColumn
            TextCol12.MappingName = "F_VoBo_CONANCE"
            TextCol12.HeaderText = "Fecha Vobo CONANCE"
            TextCol12.Width = 140
            TextCol12.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol12)

            Dim TextCol13 As New DataGridTextBoxColumn
            TextCol13.MappingName = "F_Inicio_Revision_PROYF"
            TextCol13.HeaderText = "Fecha Inicio Revisi�n Proy Final"
            TextCol13.Width = 140
            TextCol13.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol13)

            Dim TextCol14 As New DataGridTextBoxColumn
            TextCol14.MappingName = "F_Termino_Revision_PROYF"
            TextCol14.HeaderText = "Fecha Fin Revisi�n Proy Final"
            TextCol14.Width = 140
            TextCol14.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol14)

            Dim TextCol15 As New DataGridTextBoxColumn
            TextCol15.MappingName = "F_Edicion_PROYF"
            TextCol15.HeaderText = "Fecha Edici�n Proy Final"
            TextCol15.Width = 140
            TextCol15.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol15)

            Dim TextCol16 As New DataGridTextBoxColumn
            TextCol16.MappingName = "F_Impresion_ActaAprobacion_PROYF"
            TextCol16.HeaderText = "Fecha Impr Act Aprob Proy"
            TextCol16.Width = 140
            TextCol16.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol16)

            Dim TextCol17 As New DataGridTextBoxColumn
            TextCol17.MappingName = "F_Carga_ActaAprobacion_PROYF"
            TextCol17.HeaderText = "Fecha Carga Act Aprob Proy"
            TextCol17.Width = 140
            TextCol17.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol17)

            Dim TextCol18 As New DataGridTextBoxColumn
            TextCol18.MappingName = "F_ACUSE_DGN_PROYF"
            TextCol18.HeaderText = "Fecha Acuse DGN"
            TextCol18.Width = 140
            TextCol18.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol18)


            Dim TextCol19 As New DataGridTextBoxColumn
            TextCol19.MappingName = "F_CARGA_PROYF"
            TextCol19.HeaderText = "Fecha Carga PROYF"
            TextCol19.Width = 140
            TextCol19.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol19)

            grdresultadosproy.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub



    Private Sub Arma_where_PT()
        sSentencia = ""
        If sPlan <> "" Then
            sSentencia = " P_Prog_Trab.Id_Plan='" & lblpertenece.Text & "' and P_Prog_Trab.ID_etapa = '1' and P_Prog_Trab.ID_etapa <> '10' and  P_Prog_Trab.ID_etapa <> '11' and  P_Prog_Trab.ID_etapa <> '0' and"
        End If

        If chkPeriodoPT.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.F_Inicio >='" & txtf1.Text & "' and P_Prog_Trab.F_Fin<='" & txtf2.Text & "' and"
        End If
        If chkTipoTema.Checked = True Then
            sSentencia = sSentencia + "  P_Prog_Trab.tipo_tema='" & CboTipoTema.SelectedValue & "' and"
        End If
        If chkResponsable.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.responsable='" & cboResponsable.SelectedValue & "' and"
        End If
        If chkrevision.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.revision='" & cboRevision.SelectedValue & "' and"
        End If
        If chkcomite.Checked = True Then
            If sGt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_grupo='" & sGt & "' and"
            End If
            If sSc <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_sc='" & sSc & "' and"
            End If
            If sCt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_ct='" & sCt & "' and"
            End If
            If sComite <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.Id_comite='" & sComite & "' and"
            End If

        End If
        If chketapas.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.Id_etapa='" & cboetapas.SelectedValue & "' and"
        End If

        'Validacion para indicar si trae o no criterios
        If sPlan = "" And chkPeriodoPT.Checked = False And chkTipoTema.Checked = False And chkResponsable.Checked = False And chkrevision.Checked = False And chkcomite.Checked = False And chketapas.Checked = False Then
            sSentencia = " order by 1, 2"
        Else
            sSentencia = " where " & sSentencia
            sSentencia = Mid(sSentencia, 1, Len(sSentencia) - 3)
            sSentencia = sSentencia + " ORDER BY 1,2"
        End If




    End Sub
    Private Sub Arma_where_DT()
        sSentencia = ""
        If sPlan <> "" Then
            sSentencia = " P_Prog_Trab.Id_Plan='" & lblpertenece.Text & "' and P_Prog_Trab.ID_etapa = '2' and P_Prog_Trab.ID_etapa <> '10' and  P_Prog_Trab.ID_etapa <> '11' and  P_Prog_Trab.ID_etapa <> '0' and P_DT.status <> '10' and P_DT.status <> '11' and"
        End If
        If chknmx.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Inic_Desarrollo_Nmx >='" & txtnmx1.Text & "' and P_Avance_Temas_Fechas.F_Inic_Desarrollo_Nmx <='" & txtnmx2.Text & "' and"
        End If
        If chkRevedit.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Aprob_Revisi�n_Editorial >='" & txtrev1.Text & "' and P_Avance_Temas_Fechas.F_Aprob_Revisi�n_Editorial <='" & txtrev2.Text & "' and"
        End If
        If chkresponsable_dt.Checked = True Then
            sSentencia = sSentencia + " P_DT.Responsable='" & CboResponsableDt.SelectedValue & "' and"
        End If
        If chktipo.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.Tipo_Tema='" & cbotipo.SelectedValue & "' and"
        End If
        If chktipoproceso.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.Tipo_Pro='" & cbotipoproceso.SelectedValue & "' and"
        End If

        If chkResponsableAlternativo.Checked = True Then
            sSentencia = sSentencia + " P_Procedimiento_Alternativo.Responsable='" & cboresponsablealternativo.SelectedValue & "' and"
        End If
        If chkInicioResponsable.Checked = True Then
            sSentencia = sSentencia + " P_Procedimiento_Alternativo.F_Inicio_Responsable>='" & txtfinicioalter.Text & "' and P_Procedimiento_Alternativo.F_Fin_Responsable <='" & txtfinicioalter2.Text & "'"
        End If
        If chkadj.Checked = True Then
            sSentencia = sSentencia + " P_Procedimiento_Alternativo.F_Carga_Minuta_Terminacion >='" & txtadj.Text & "' and P_Procedimiento_Alternativo.F_Carga_Minuta_Terminacion <='" & txtadj2.Text & "'  "
        End If

        If chketapas.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.Id_etapa='" & cboetapas.SelectedValue & "' and"
        End If

        If chkcomite.Checked = True Then
            If sGt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_grupo='" & sGt & "' and"
            End If
            If sSc <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_sc='" & sSc & "' and"
            End If
            If sCt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_ct='" & sCt & "' and"
            End If
            If sComite <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.Id_comite='" & sComite & "' and"
            End If

        End If


        If sPlan = "" And chknmx.Checked = False And chkRevedit.Checked = False And chkresponsable_dt.Checked = False And chktipo.Checked = False And chktipoproceso.Checked = False And chketapas.Checked = False Then
            sSentencia = " order by 1, 2"
        Else
            sSentencia = " where " & sSentencia
            sSentencia = Mid(sSentencia, 1, Len(sSentencia) - 3)
            sSentencia = sSentencia + " ORDER BY 1,2"
        End If

    End Sub
    Private Sub Arma_Where_Ant()
        sSentencia = ""
        If sPlan <> "" Then
            sSentencia = " P_Prog_Trab.Id_Plan='" & lblpertenece.Text & "' and P_Prog_Trab.ID_etapa = '3' and P_Prog_Trab.ID_etapa <> '10' and  P_Prog_Trab.ID_etapa <> '11' and  P_Prog_Trab.ID_etapa <> '0' and P_Ant.status <> '10' and P_Ant.status <> '11' and"
        End If
        If chketapas.Checked = True Then
            sSentencia = sSentencia + " P_Prog_Trab.Id_etapa='" & cboetapas.SelectedValue & "' and"
        End If
        If chkcomite.Checked = True Then
            If sGt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_grupo='" & sGt & "' and"
            End If
            If sSc <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_sc='" & sSc & "' and"
            End If
            If sCt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_ct='" & sCt & "' and"
            End If
            If sComite <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.Id_comite='" & sComite & "' and"
            End If

        End If
        If chkclasificacion.Checked = True Then
            sSentencia = sSentencia + "  P_Ant.Clasificacion like '''% " & txtClasificacionant.Text & " %''' and"
        End If
        If chkfechaAprob.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Aprobacion_CTGT_ANT >='" & txtfaprob1.Text & "' and P_Avance_Temas_Fechas.F_Aprobacion_CTGT_ANT <='" & txtfaprob2.Text & "' and"
        End If
        If chkresponsableant.Checked = True Then
            sSentencia = sSentencia + " P_Ant.Responsable='" & cboresponsableant.SelectedValue & "' and"
        End If

        If sPlan = "" And chkcomite.Checked = False And chketapas.Checked = False And chkclasificacion.Checked = False And chkfechaAprob.Checked = False And chkresponsableant.Checked = False Then
            sSentencia = " order by 1, 2"
        Else
            sSentencia = "  where " & sSentencia
            sSentencia = Mid(sSentencia, 1, Len(sSentencia) - 3)
            sSentencia = sSentencia + " ORDER BY 1,2"
        End If


    End Sub
    Private Sub Arma_where_Proy()
        sSentencia = ""
        If sPlan <> "" Then
            sSentencia = " P_Prog_Trab.Id_Plan='" & lblpertenece.Text & "' and P_Prog_Trab.ID_etapa = '4' and P_Prog_Trab.ID_etapa <> '10' and  P_Prog_Trab.ID_etapa <> '11' and  P_Prog_Trab.ID_etapa <> '0' and P_Proy.status <> '10' and P_Proy.status <> '11' and"
        End If
        If chkclasificacionproy.Checked = True Then
            sSentencia = sSentencia + " P_Proy.Clasificacion like '''%" & txtclasificacion_proy.Text & "%''' and"
        End If
        If chkresponsable_proy.Checked = True Then
            sSentencia = sSentencia + " P_Proy.Responsable='" & cboResponsable_proy.SelectedValue & "' and"
        End If
        If chkapCom.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Aprobacion_Comite_PROY >='" & txtfaprcom1.Text & "' and  P_Avance_Temas_Fechas.F_Aprobacion_Comite_PROY <='" & txtfaprcom2.Text & "' and"
        End If
        If chkpubcom.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Publicacion_ComentarioPublico>='" & txtfpubcom.Text & "' and P_Avance_Temas_Fechas.F_Limite_ComentarioPublico<='" & txtfpubcom2.Text & "' and"
        End If
        If chkres.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Resolucion_ComentarioPublico>='" & txtres.Text & "' and P_Avance_Temas_Fechas.F_Limite_Aprobacion_Resolucion_ComentarioPublico<='" & txtres2.Text & "' and"
        End If
        If chkaprobres.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Aprobacion_Resolucion_ComentarioPublico<='" & txtaprobres.Text & "' and P_Avance_Temas_Fechas.F_Aprobacion_Resolucion_ComentarioPublico<='" & txtaprobres2.Text & "' and"
        End If
        If chkvobo.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_VoBo_CONANCE>='" & txtvobo.Text & "' and P_Avance_Temas_Fechas.F_VoBo_CONANCE<='" & txtvobo2.Text & "' and"
        End If
        If chkfrevproyf.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Inicio_Revision_PROYF>='" & txtfrevproyf.Text & "' and P_Avance_Temas_Fechas.F_Termino_Revision_PROYF<='" & txtfrevproyf2.Text & "' and"
        End If
        If chkfedproyf.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_Edicion_PROYF>='" & txtfedproyf.Text & "' and  P_Avance_Temas_Fechas.F_Edicion_PROYF<='" & txtfedproyf2.Text & "' and"
        End If
        If chkDgn.Checked = True Then
            sSentencia = sSentencia + " P_Avance_Temas_Fechas.F_ACUSE_DGN_PROYF>='" & txtDgn.Text & "' and P_Avance_Temas_Fechas.F_ACUSE_DGN_PROYF<='" & txtdgn2.Text & "' and"
        End If

        If chkcomite.Checked = True Then
            If sGt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_grupo='" & sGt & "' and"
            End If
            If sSc <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_sc='" & sSc & "' and"
            End If
            If sCt <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.id_ct='" & sCt & "' and"
            End If
            If sComite <> "" Then
                sSentencia = sSentencia + " P_Prog_Trab.Id_comite='" & sComite & "' and"
            End If

        End If


        If sPlan = "" And chkcomite.Checked = False And chkclasificacionproy.Checked = False And chkresponsable_proy.Checked = False And chkapCom.Checked = False And chkpubcom.Checked = False And chkres.Checked = False And chkaprobres.Checked = False And chkvobo.Checked = False And chkfrevproyf.Checked = False And chkfedproyf.Checked = False And chkDgn.Checked = False Then
            sSentencia = " order by 1, 2"
        Else
            sSentencia = "  where " & sSentencia
            sSentencia = Mid(sSentencia, 1, Len(sSentencia) - 3)
            sSentencia = sSentencia + " ORDER BY 1,2"
        End If




    End Sub
    Private Sub chknmx_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chknmx.CheckedChanged
        If chknmx.Checked = True Then
            dtnmx1.Enabled = True
            txtnmx1.Text = ""
            txtnmx2.Text = ""

        Else
            dtnmx1.Enabled = False
            dtnmx2.Enabled = False
            txtnmx1.Text = ""
            txtnmx2.Text = ""
        End If
    End Sub

    Private Sub dtnmx1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtnmx1.ValueChanged
        If chknmx.Checked = True Then
            txtnmx1.Text = Format(dtnmx1.Value, "dd/MM/yyyy")
            dtnmx2.Enabled = True
            txtnmx2.Text = ""
        End If
    End Sub

    Private Sub dtnmx2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtnmx2.ValueChanged
        If chknmx.Checked = True Then
            txtnmx2.Text = Format(dtnmx2.Value, "dd/MM/yyyy")
            If txtnmx1.Text > txtnmx2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtnmx2.Text = ""
                Exit Sub
            End If

        End If
    End Sub

    Private Sub chkRevedit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRevedit.CheckedChanged
        If chkRevedit.Checked = True Then
            txtrev1.Text = ""
            txtrev2.Text = ""
            txtrev1.Enabled = False
            txtrev2.Enabled = False
            dtrev1.Enabled = True

        Else
            txtrev1.Text = ""
            txtrev2.Text = ""
            txtrev1.Enabled = False
            txtrev2.Enabled = False
            dtrev1.Enabled = False
            dtrev2.Enabled = False
        End If
    End Sub

    Private Sub dtrev1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtrev1.ValueChanged
        If chkRevedit.Checked = True Then
            txtrev1.Text = Format(dtrev1.Value, "dd/MM/yyyy")
            dtrev2.Enabled = True
            txtrev2.Text = ""
        End If
    End Sub

    Private Sub dtrev2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtrev2.ValueChanged
        If chkRevedit.Checked = True Then
            txtrev2.Text = Format(dtrev2.Value, "dd/MM/yyyy")
            If txtrev1.Text > txtrev2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtrev2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkresponsable_dt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkresponsable_dt.CheckedChanged
        If chkresponsable_dt.Checked = True Then
            txtresponsableDt.Enabled = False
            CboResponsableDt.Enabled = True
            txtresponsableDt.Text = ""
            ObjEmpleados.Bandera = 6
            ObjEmpleados.ListaCombo(CboResponsableDt)
            txtresponsableDt.Text = CboResponsableDt.Text


        Else
            txtresponsableDt.Text = ""
            CboResponsableDt.Enabled = False
            txtresponsableDt.Enabled = False
        End If
    End Sub

    Private Sub CboResponsableDt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboResponsableDt.SelectedIndexChanged
        If chkresponsable_dt.Checked = True Then
            txtresponsableDt.Text = CboResponsableDt.Text
        End If
    End Sub


    Private Sub TBpt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TBpt.SelectedIndexChanged

    End Sub

    Private Sub chktipo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chktipo.CheckedChanged
        If chktipo.Checked = True Then
            txttipo.Enabled = False
            cbotipo.Enabled = True
            dtTiposTema = ObjTiposTema.ListaCombo()
            cbotipo.DataSource = dtTiposTema
            cbotipo.DisplayMember = dtTiposTema.Columns(1).ColumnName
            cbotipo.ValueMember = dtTiposTema.Columns(0).ColumnName
            txttipo.Text = CboTipoTema.Text

        Else
            txttipo.Text = ""
            cbotipo.Enabled = False
            dtTiposTema.Clear()


        End If
    End Sub

    Private Sub cbotipo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbotipo.SelectedIndexChanged
        If chktipo.Checked = True Then
            txttipo.Text = cbotipo.Text
        End If
    End Sub


    Private Sub chktipoproceso_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chktipoproceso.CheckedChanged
        If chktipoproceso.Checked = True Then
            txttipoproceso.Enabled = False
            cbotipoproceso.Enabled = True
            dtTiposProceso = ObjTiposProceso.ListaCombo()
            cbotipoproceso.DataSource = dtTiposProceso
            cbotipoproceso.DisplayMember = dtTiposProceso.Columns(1).ColumnName
            cbotipoproceso.ValueMember = dtTiposProceso.Columns(0).ColumnName
            txttipoproceso.Text = cbotipoproceso.Text

        Else
            txttipoproceso.Text = ""
            cbotipoproceso.Enabled = False
            pnlalternativo.Visible = False
            dtTiposProceso.Clear()


        End If
    End Sub

    Private Sub cbotipoproceso_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbotipoproceso.SelectedIndexChanged
        If chktipoproceso.Checked = True Then
            txttipoproceso.Text = cbotipoproceso.Text
            If txttipoproceso.Text = "Proceso Alternativo" Then
                pnlalternativo.Visible = True
            Else
                pnlalternativo.Visible = False
            End If
        End If

    End Sub

    Private Sub chkResponsableAlternativo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkResponsableAlternativo.CheckedChanged
        If chkResponsableAlternativo.Checked = True Then
            txtresponsablealternativo.Enabled = False
            cboresponsablealternativo.Enabled = True
            txtresponsablealternativo.Text = ""
            ObjEmpleados.Bandera = 6
            ObjEmpleados.ListaCombo(cboresponsablealternativo)
            txtresponsablealternativo.Text = cboresponsablealternativo.Text
        Else
            txtresponsablealternativo.Text = ""
            cboresponsablealternativo.Enabled = False
            txtresponsablealternativo.Enabled = False
        End If
    End Sub

    Private Sub cboresponsablealternativo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboresponsablealternativo.SelectedIndexChanged
        If chkResponsableAlternativo.Checked = True Then
            txtresponsablealternativo.Text = cboresponsablealternativo.Text
        End If
    End Sub

    Private Sub dtfinicioalter_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfinicioalter.ValueChanged
        If chkInicioResponsable.Checked = True Then
            txtfinicioalter.Text = Format(dtfinicioalter.Value, "dd/MM/yyyy")
            dtfinicioalter2.Enabled = True
            txtfinicioalter2.Text = ""

        End If
    End Sub

    Private Sub chkInicioResponsable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInicioResponsable.CheckedChanged
        If chkInicioResponsable.Checked = True Then
            dtfinicioalter.Enabled = True
            dtfinicioalter2.Enabled = False
        Else
            dtfinicioalter.Enabled = False
            dtfinicioalter2.Enabled = False
            txtfinicioalter.Text = ""
            txtfinicioalter2.Text = ""
        End If
    End Sub

    Private Sub dtfinicioalter2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfinicioalter2.ValueChanged
        If chkInicioResponsable.Checked = True Then
            txtfinicioalter2.Text = Format(dtfinicioalter2.Value, "dd/MM/yyyy")
            If txtfinicioalter.Text > txtfinicioalter2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfinicioalter2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkfinResponsable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkfinResponsable.CheckedChanged
        If chkfinResponsable.Checked = True Then
            dtfcom1.Enabled = True
            txtfcom1.Text = ""
            txtfcom2.Text = ""
        Else
            dtfcom1.Enabled = False
            dtfcom2.Enabled = False
            txtfcom1.Text = ""
            txtfcom2.Text = ""
        End If
    End Sub

    Private Sub dtfcom1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfcom1.ValueChanged
        If chkfinResponsable.Checked = True Then
            txtfcom1.Text = Format(dtfcom1.Value, "dd/MM/yyyy")
            txtfcom2.Text = ""
            dtfcom2.Enabled = True
        End If
    End Sub

    Private Sub dtfcom2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfcom2.ValueChanged
        If chkfinResponsable.Checked = True Then
            txtfcom2.Text = Format(dtfcom2.Value, "dd/MM/yyyy")
            If txtfcom1.Text > txtfcom2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfcom2.Text = ""
                Exit Sub
            End If

        End If
    End Sub

    Private Sub chkadj_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkadj.CheckedChanged
        If chkadj.Checked = True Then
            dtadj.Enabled = True
            txtadj.Text = ""
            txtadj2.Text = ""
        Else
            dtadj.Enabled = False
            dtadj2.Enabled = False
            txtadj.Text = ""
            txtadj2.Text = ""
        End If
    End Sub

    Private Sub dtadj_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtadj.ValueChanged
        If chkadj.Checked = True Then
            txtadj.Text = Format(dtadj.Value, "dd/MM/yyyy")
            dtadj2.Enabled = True
            txtadj2.Text = ""

        End If
    End Sub

    Private Sub dtadj2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtadj2.ValueChanged
        If chkadj.Checked = True Then
            txtadj2.Text = Format(dtadj2.Value, "dd/MM/yyyy")
            If txtadj.Text > txtadj2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtadj2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chketapas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chketapas.CheckedChanged
        If chketapas.Checked = True Then
            txtetapas.Text = ""
            txtetapas.Enabled = False
            cboetapas.Enabled = True
            dtEtapas = objEtapas.ListaCombo()
            cboetapas.DataSource = dtEtapas
            cboetapas.DisplayMember = dtEtapas.Columns(1).ColumnName
            cboetapas.ValueMember = dtEtapas.Columns(0).ColumnName
            txtetapas.Text = cboetapas.Text

        Else
            txtetapas.Enabled = False
            txtetapas.Text = ""
            cboetapas.Enabled = False
        End If
    End Sub

    Private Sub cboetapas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboetapas.SelectedIndexChanged
        If chketapas.Checked = True Then
            txtetapas.Text = cboetapas.Text
        End If
    End Sub

    Private Sub chkclasificacion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkclasificacion.CheckedChanged
        If chkclasificacion.Checked = True Then
            txtClasificacionant.Text = ""
            txtClasificacionant.Enabled = True
        Else
            txtClasificacionant.Text = ""
            txtClasificacionant.Enabled = False
        End If
    End Sub

    Private Sub chkfechaAprob_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkfechaAprob.CheckedChanged
        If chkfechaAprob.Checked = True Then
            txtfaprob1.Text = ""
            txtfaprob2.Text = ""
            dtfaprob1.Enabled = True
        Else
            txtfaprob1.Text = ""
            txtfaprob2.Text = ""
            dtfaprob1.Enabled = False
            dtfaprob2.Enabled = False
        End If
    End Sub

    Private Sub dtfaprob1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfaprob1.ValueChanged
        If chkfechaAprob.Checked = True Then
            txtfaprob1.Text = Format(dtfaprob1.Value, "dd/MM/yyyy")
            dtfaprob2.Enabled = True
        End If
    End Sub

    Private Sub dtfaprob2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfaprob2.ValueChanged
        If chkfechaAprob.Checked = True Then
            txtfaprob2.Text = Format(dtfaprob2.Value, "dd/MM/yyyy")
            If txtfaprob1.Text > txtfaprob2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfaprob2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkresponsableant_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkresponsableant.CheckedChanged
        If chkresponsableant.Checked = True Then
            txtresponsableant.Text = ""
            cboresponsableant.Enabled = True
            ObjEmpleados.Bandera = 6
            ObjEmpleados.ListaCombo(cboresponsableant)
            txtresponsableant.Text = cboresponsableant.Text

        Else
            txtresponsableant.Text = ""
            cboresponsableant.Enabled = False
        End If
    End Sub

    Private Sub chkclasificacionproy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkclasificacionproy.CheckedChanged
        If chkclasificacionproy.Checked = True Then
            txtclasificacion_proy.Enabled = True
            txtclasificacion_proy.Text = ""
        Else
            txtclasificacion_proy.Enabled = False
            txtclasificacion_proy.Text = ""

        End If
    End Sub




    Private Sub cbofaprocom1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If chkapCom.Checked = True Then
            txtfaprcom1.Text = Format(dtfaprocom1.Value, "dd/MM/yyyy")
            dtfaprocom2.Enabled = True
        End If
    End Sub

    Private Sub dtfaprocom2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfaprocom2.ValueChanged
        If chkapCom.Checked = True Then
            txtfaprcom2.Text = Format(dtfaprocom2.Value, "dd/MM/yyyy")
            If txtfaprcom1.Text > txtfaprcom2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfaprcom2.Text = ""
                Exit Sub
            End If
        End If

    End Sub

    Private Sub chkpubcom_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkpubcom.CheckedChanged
        If chkpubcom.Checked = True Then
            txtfpubcom.Enabled = False
            dtpubcom.Enabled = True
            txtfpubcom.Text = ""
        Else
            txtfpubcom.Enabled = False
            dtpubcom.Enabled = False
            dtpubcom2.Enabled = False
            txtfpubcom.Text = ""
            txtfpubcom2.Text = ""
        End If
    End Sub

    Private Sub dtpubcom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpubcom.ValueChanged
        If chkpubcom.Checked = True Then
            txtfpubcom.Text = Format(dtpubcom.Value, "dd/MM/yyyy")
            dtpubcom2.Enabled = True
        End If
    End Sub

    Private Sub dtpubcom2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpubcom2.ValueChanged
        If chkpubcom.Checked = True Then
            txtfpubcom2.Text = Format(dtpubcom2.Value, "dd/MM/yyyy")
            If txtfpubcom.Text > txtfpubcom2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfpubcom2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub dtres_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtres.ValueChanged
        If chkres.Checked = True Then
            txtres.Text = Format(dtres.Value, "dd/MM/yyyy")
            dtres2.Enabled = True
        End If
    End Sub

    Private Sub chkres_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkres.CheckedChanged
        If chkres.Checked = True Then
            txtres.Text = ""
            txtres.Enabled = False
            dtres.Enabled = True
        Else
            txtres.Text = ""
            txtres2.Text = ""
            txtres.Enabled = False
            dtres.Enabled = False
            dtres2.Enabled = False
        End If
    End Sub

    Private Sub dtres2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtres2.ValueChanged
        If chkres.Checked = True Then
            txtres2.Text = Format(dtres2.Value, "dd/MM/yyyy")
            If txtres.Text > txtres2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtres2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkaprobres_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkaprobres.CheckedChanged
        If chkaprobres.Checked = True Then
            txtaprobres.Text = ""
            txtaprobres.Enabled = False
            dtaprobres.Enabled = True
        Else
            txtaprobres.Text = ""
            txtaprobres2.Text = ""
            txtaprobres.Enabled = False
            dtaprobres.Enabled = False
            dtaprobres2.Enabled = False
        End If
    End Sub

    Private Sub dtaprobres_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtaprobres.ValueChanged
        If chkaprobres.Checked = True Then
            txtaprobres.Text = Format(dtaprobres.Value, "dd/MM/yyyy")
            dtaprobres2.Enabled = True
        End If

    End Sub

    Private Sub dtaprobres2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtaprobres2.ValueChanged
        If chkaprobres.Checked = True Then
            txtaprobres2.Text = Format(dtaprobres2.Value, "dd/MM/yyyy")
            If txtaprobres.Text > txtaprobres2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtaprobres2.Text = ""
                Exit Sub
            End If


        End If
    End Sub

    Private Sub chkvobo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkvobo.CheckedChanged
        If chkvobo.Checked = True Then
            txtvobo.Enabled = False
            txtvobo.Text = ""
            dtvobo.Enabled = True

        Else
            txtvobo.Enabled = False
            txtvobo.Text = ""
            txtvobo2.Text = ""
            dtvobo.Enabled = False
            dtvobo2.Enabled = False
        End If
    End Sub

    Private Sub dtvobo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtvobo.ValueChanged
        If chkvobo.Checked = True Then
            txtvobo.Text = Format(dtvobo.Value, "dd/MM/yyyy")
            dtvobo2.Enabled = True
        End If
    End Sub

    Private Sub dtvobo2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtvobo2.ValueChanged
        If chkvobo.Checked = True Then
            txtvobo2.Text = Format(dtvobo2.Value, "dd/MM/yyyy")
            If txtvobo.Text > txtvobo2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtvobo2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkfrevproyf_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkfrevproyf.CheckedChanged
        If chkfrevproyf.Checked = True Then
            dtfrevproyf.Enabled = True
            txtfrevproyf.Text = ""
            txtfrevproyf.Enabled = False
        Else
            dtfrevproyf.Enabled = False
            dtfrevproyf2.Enabled = False
            txtfrevproyf.Text = ""
            txtfrevproyf2.Text = ""
            txtfrevproyf.Enabled = False
        End If
    End Sub

    Private Sub dtfrevproyf_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfrevproyf.ValueChanged
        If chkfrevproyf.Checked = True Then
            txtfrevproyf.Text = Format(dtfrevproyf.Value, "dd/MM/yyyy")
            dtfrevproyf2.Enabled = True
        End If
    End Sub

    Private Sub dtfrevproyf2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfrevproyf2.ValueChanged
        If chkfrevproyf.Checked = True Then
            txtfrevproyf2.Text = Format(dtfrevproyf2.Value, "dd/MM/yyyy")
            If txtfrevproyf.Text > txtfrevproyf2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfrevproyf2.Text = ""
                Exit Sub
            End If
        End If

    End Sub

    Private Sub chkfedproyf_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkfedproyf.CheckedChanged
        If chkfedproyf.Checked = True Then
            txtfedproyf.Text = ""
            txtfedproyf.Enabled = False
            dtfedproyf.Enabled = True
        Else
            txtfedproyf.Text = ""
            txtfedproyf2.Text = ""
            dtfedproyf.Enabled = False
            dtfedproyf2.Enabled = False

        End If
    End Sub

    Private Sub dtfedproyf_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfedproyf.ValueChanged
        If chkfedproyf.Checked = True Then
            txtfedproyf.Text = Format(dtfedproyf.Value, "dd/MM/yyyy")
            dtfedproyf2.Enabled = True
        End If
    End Sub

    Private Sub dtfedproyf2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfedproyf2.ValueChanged
        If chkfedproyf.Checked = True Then
            txtfedproyf2.Text = Format(dtfedproyf2.Value, "dd/MM/yyyy")
            If txtfedproyf.Text > txtfedproyf2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtfedproyf2.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub chkDgn_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDgn.CheckedChanged
        If chkDgn.Checked = True Then
            txtDgn.Text = ""
            txtDgn.Enabled = False
            dtDgn.Enabled = True
        Else
            txtDgn.Text = ""
            txtdgn2.Text = ""
            dtDgn.Enabled = False
            dtdgn2.Enabled = False
        End If
    End Sub

    Private Sub dtDgn_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtDgn.ValueChanged
        If chkDgn.Checked = True Then
            txtDgn.Text = Format(dtDgn.Value, "dd/MM/yyyy")
            dtdgn2.Enabled = True
        End If

    End Sub

    Private Sub dtdgn2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtdgn2.ValueChanged
        If chkDgn.Checked = True Then
            txtdgn2.Text = Format(dtdgn2.Value, "dd/MM/yyyy")
            If txtDgn.Text > txtdgn2.Text Then
                MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
                txtdgn2.Text = ""
                Exit Sub
            End If
        End If
    End Sub



    Private Sub chkresponsable_proy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkresponsable_proy.CheckedChanged
        If chkresponsable_proy.Checked = True Then
            txtresponsable_proy.Enabled = False
            txtresponsable_proy.Text = ""
            cboResponsable_proy.Enabled = True
            ObjEmpleados.Bandera = 6
            ObjEmpleados.ListaCombo(cboResponsable_proy)
            txtresponsable_proy.Text = cboResponsable_proy.Text

        Else
            txtresponsable_proy.Enabled = False
            cboResponsable_proy.Enabled = False
            txtresponsable_proy.Text = ""

        End If
    End Sub




    Private Sub cboResponsable_proy_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsable_proy.SelectedIndexChanged
        If chkresponsable_proy.Checked = True Then
            txtresponsable_proy.Text = cboResponsable_proy.Text
        End If
    End Sub

    Private Sub chkapCom_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkapCom.CheckedChanged
        If chkapCom.Checked = True Then
            dtfaprocom1.Enabled = True
            txtfaprcom1.Enabled = False
            txtfaprcom1.Text = ""
        Else
            dtfaprocom1.Enabled = False
            dtfaprocom2.Enabled = False
            txtfaprcom1.Enabled = False
            txtfaprcom1.Text = ""
            txtfaprcom2.Text = ""
        End If
    End Sub



End Class
