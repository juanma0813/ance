Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections
Imports System.Drawing

Public Class FrmRev_Editorial
    Inherits System.Windows.Forms.Form
    Dim existe, Accion As Boolean
    Dim tipo_consulta As Integer
    Dim keyascii As Short
    Dim sCbovalue, illenos As Integer
    Dim sError, iEditar, sValTreeView, svaluescbo, shoraiPk, shoratPk, sGrilla, sCboTxt As String
    Dim lleno As Integer = 0
    Dim DTContenedorErrores As DataTable
    Dim DTDatosResp As DataTable


#Region " ******* Inicializaci�n de Dll's  *******"

    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objstatus_revedit As New Cls_Status_Rev_Edit.Cls_Status_Rev_Edit("principal", gUsuario, gPasswordSql)
    Dim objTipos_RevEdit As New Cls_Tipos_RevEdit.Cls_tipos_RE("principal", gUsuario, gPasswordSql)
    Dim objincisos As New Cls_Incisos_RE.Cls_Incisos_RE("principal", gUsuario, gPasswordSql)
    Dim objPRE As New Cls_P_Rev_edit.Cls_P_Rev_edit("principal", gUsuario, gPasswordSql)
    Dim ObjPERE As New Cls_P_Errores_Rev_Edit.P_Errores_Rev_Edit("PRINCIPAL", gUsuario, gPasswordSql)

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    'Public Sub New(ByVal tipo As Integer)
    '    MyBase.New()
    '    tipo_consulta = tipo

    '    'El Dise�ador de Windows Forms requiere esta llamada.

    '    InitializeComponent()

    '    If tipo_consulta = 1 Then
    '        Me.Text = "Revisi�n Editorial"
    '        Me.tlbBotonera.Buttons(5).Text = "Autorizar"
    '    Else
    '        Me.Text = "Autorizaci�n de Revisi�n Editorial"
    '        Me.tlbBotonera.Buttons(5).Text = "Asignar"
    '    End If
    '    'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
    '    objplanes.Inicializa(0, gUsuario, gPasswordSql)
    '    objempleados.Inicializa(Application.StartupPath & "\principal.ini", "comun", gUsuario, gPasswordSql)
    'End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TVProgTemas As System.Windows.Forms.TreeView
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents LblAntProy As System.Windows.Forms.Label
    Friend WithEvents TxtAntProy As System.Windows.Forms.TextBox
    Friend WithEvents TxtNumPag As System.Windows.Forms.TextBox
    Friend WithEvents LblNumPag As System.Windows.Forms.Label
    Friend WithEvents TxtComTec As System.Windows.Forms.TextBox
    Friend WithEvents LblComTec As System.Windows.Forms.Label
    Friend WithEvents TxtRevisor As System.Windows.Forms.TextBox
    Friend WithEvents LblRevisor As System.Windows.Forms.Label
    Friend WithEvents TxtResponsable As System.Windows.Forms.TextBox
    Friend WithEvents LblResponsable As System.Windows.Forms.Label
    Friend WithEvents TxtPNN As System.Windows.Forms.TextBox
    Friend WithEvents LblPNN As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DTPFecIni As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPCompromiso As System.Windows.Forms.DateTimePicker
    Friend WithEvents LblFecCompro As System.Windows.Forms.Label
    Friend WithEvents DTPReal As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents gp1 As System.Windows.Forms.GroupBox
    Friend WithEvents CboTipos_RevEdit As System.Windows.Forms.ComboBox
    Friend WithEvents DGrid As System.Windows.Forms.DataGrid
    Friend WithEvents LblTipos_RevEdit As System.Windows.Forms.Label
    Friend WithEvents Lbltemas As System.Windows.Forms.Label
    Friend WithEvents TxtTtotal As System.Windows.Forms.TextBox
    Friend WithEvents LblTotal As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtTotalErr As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtComentario As System.Windows.Forms.TextBox
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAsignar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSeguimiento As System.Windows.Forms.ToolBarButton
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmRev_Editorial))
        Me.TVProgTemas = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.Lbltemas = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.LblAntProy = New System.Windows.Forms.Label
        Me.TxtAntProy = New System.Windows.Forms.TextBox
        Me.TxtNumPag = New System.Windows.Forms.TextBox
        Me.LblNumPag = New System.Windows.Forms.Label
        Me.TxtComTec = New System.Windows.Forms.TextBox
        Me.LblComTec = New System.Windows.Forms.Label
        Me.TxtRevisor = New System.Windows.Forms.TextBox
        Me.LblRevisor = New System.Windows.Forms.Label
        Me.TxtResponsable = New System.Windows.Forms.TextBox
        Me.LblResponsable = New System.Windows.Forms.Label
        Me.TxtPNN = New System.Windows.Forms.TextBox
        Me.LblPNN = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.DTPFecIni = New System.Windows.Forms.DateTimePicker
        Me.DTPCompromiso = New System.Windows.Forms.DateTimePicker
        Me.LblFecCompro = New System.Windows.Forms.Label
        Me.DTPReal = New System.Windows.Forms.DateTimePicker
        Me.Label4 = New System.Windows.Forms.Label
        Me.gp1 = New System.Windows.Forms.GroupBox
        Me.DGrid = New System.Windows.Forms.DataGrid
        Me.CboTipos_RevEdit = New System.Windows.Forms.ComboBox
        Me.LblTipos_RevEdit = New System.Windows.Forms.Label
        Me.TxtTtotal = New System.Windows.Forms.TextBox
        Me.LblTotal = New System.Windows.Forms.Label
        Me.TxtTotalErr = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.TxtComentario = New System.Windows.Forms.TextBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.cmdAsignar = New System.Windows.Forms.ToolBarButton
        Me.cmdSeguimiento = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.gp1.SuspendLayout()
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TVProgTemas
        '
        Me.TVProgTemas.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TVProgTemas.ImageIndex = 3
        Me.TVProgTemas.ImageList = Me.imgListTreeView
        Me.TVProgTemas.ItemHeight = 18
        Me.TVProgTemas.Location = New System.Drawing.Point(8, 48)
        Me.TVProgTemas.Name = "TVProgTemas"
        Me.TVProgTemas.SelectedImageIndex = 4
        Me.TVProgTemas.Size = New System.Drawing.Size(200, 416)
        Me.TVProgTemas.TabIndex = 18
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(16, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'Lbltemas
        '
        Me.Lbltemas.AutoSize = True
        Me.Lbltemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbltemas.Location = New System.Drawing.Point(8, 8)
        Me.Lbltemas.Name = "Lbltemas"
        Me.Lbltemas.Size = New System.Drawing.Size(129, 15)
        Me.Lbltemas.TabIndex = 87
        Me.Lbltemas.Text = "Proyecto Seleccionado: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 24)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 15)
        Me.LblTreeView.TabIndex = 86
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LblAntProy
        '
        Me.LblAntProy.AutoSize = True
        Me.LblAntProy.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAntProy.Location = New System.Drawing.Point(216, 8)
        Me.LblAntProy.Name = "LblAntProy"
        Me.LblAntProy.Size = New System.Drawing.Size(77, 15)
        Me.LblAntProy.TabIndex = 88
        Me.LblAntProy.Text = "Anteproyecto:"
        '
        'TxtAntProy
        '
        Me.TxtAntProy.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAntProy.Location = New System.Drawing.Point(312, 8)
        Me.TxtAntProy.Multiline = True
        Me.TxtAntProy.Name = "TxtAntProy"
        Me.TxtAntProy.Size = New System.Drawing.Size(416, 32)
        Me.TxtAntProy.TabIndex = 90
        Me.TxtAntProy.Text = ""
        '
        'TxtNumPag
        '
        Me.TxtNumPag.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNumPag.Location = New System.Drawing.Point(312, 48)
        Me.TxtNumPag.Name = "TxtNumPag"
        Me.TxtNumPag.Size = New System.Drawing.Size(72, 19)
        Me.TxtNumPag.TabIndex = 92
        Me.TxtNumPag.Text = ""
        '
        'LblNumPag
        '
        Me.LblNumPag.AutoSize = True
        Me.LblNumPag.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNumPag.Location = New System.Drawing.Point(216, 51)
        Me.LblNumPag.Name = "LblNumPag"
        Me.LblNumPag.Size = New System.Drawing.Size(69, 15)
        Me.LblNumPag.TabIndex = 91
        Me.LblNumPag.Text = "No. P�ginas:"
        '
        'TxtComTec
        '
        Me.TxtComTec.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtComTec.Location = New System.Drawing.Point(312, 77)
        Me.TxtComTec.Name = "TxtComTec"
        Me.TxtComTec.Size = New System.Drawing.Size(72, 19)
        Me.TxtComTec.TabIndex = 94
        Me.TxtComTec.Text = ""
        '
        'LblComTec
        '
        Me.LblComTec.AutoSize = True
        Me.LblComTec.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblComTec.Location = New System.Drawing.Point(216, 80)
        Me.LblComTec.Name = "LblComTec"
        Me.LblComTec.Size = New System.Drawing.Size(88, 15)
        Me.LblComTec.TabIndex = 93
        Me.LblComTec.Text = "Comite T�cnico:"
        '
        'TxtRevisor
        '
        Me.TxtRevisor.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtRevisor.Location = New System.Drawing.Point(312, 133)
        Me.TxtRevisor.Name = "TxtRevisor"
        Me.TxtRevisor.Size = New System.Drawing.Size(144, 19)
        Me.TxtRevisor.TabIndex = 96
        Me.TxtRevisor.Text = ""
        '
        'LblRevisor
        '
        Me.LblRevisor.AutoSize = True
        Me.LblRevisor.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRevisor.Location = New System.Drawing.Point(216, 136)
        Me.LblRevisor.Name = "LblRevisor"
        Me.LblRevisor.Size = New System.Drawing.Size(47, 15)
        Me.LblRevisor.TabIndex = 95
        Me.LblRevisor.Text = "Revisor:"
        '
        'TxtResponsable
        '
        Me.TxtResponsable.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtResponsable.Location = New System.Drawing.Point(312, 105)
        Me.TxtResponsable.Name = "TxtResponsable"
        Me.TxtResponsable.Size = New System.Drawing.Size(144, 19)
        Me.TxtResponsable.TabIndex = 98
        Me.TxtResponsable.Text = ""
        '
        'LblResponsable
        '
        Me.LblResponsable.AutoSize = True
        Me.LblResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblResponsable.Location = New System.Drawing.Point(216, 108)
        Me.LblResponsable.Name = "LblResponsable"
        Me.LblResponsable.Size = New System.Drawing.Size(74, 15)
        Me.LblResponsable.TabIndex = 97
        Me.LblResponsable.Text = "Responsable:"
        '
        'TxtPNN
        '
        Me.TxtPNN.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPNN.Location = New System.Drawing.Point(584, 48)
        Me.TxtPNN.Name = "TxtPNN"
        Me.TxtPNN.Size = New System.Drawing.Size(144, 19)
        Me.TxtPNN.TabIndex = 100
        Me.TxtPNN.Text = ""
        '
        'LblPNN
        '
        Me.LblPNN.AutoSize = True
        Me.LblPNN.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPNN.Location = New System.Drawing.Point(464, 51)
        Me.LblPNN.Name = "LblPNN"
        Me.LblPNN.Size = New System.Drawing.Size(85, 15)
        Me.LblPNN.TabIndex = 99
        Me.LblPNN.Text = "PNN (No./A�o): "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(464, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 15)
        Me.Label2.TabIndex = 101
        Me.Label2.Text = "Fecha Inicio Revisi�n: "
        '
        'DTPFecIni
        '
        Me.DTPFecIni.CustomFormat = "dd/MM/yyyy"
        Me.DTPFecIni.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPFecIni.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPFecIni.Location = New System.Drawing.Point(608, 77)
        Me.DTPFecIni.Name = "DTPFecIni"
        Me.DTPFecIni.Size = New System.Drawing.Size(120, 19)
        Me.DTPFecIni.TabIndex = 102
        '
        'DTPCompromiso
        '
        Me.DTPCompromiso.CustomFormat = "dd/MM/yyyy"
        Me.DTPCompromiso.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPCompromiso.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPCompromiso.Location = New System.Drawing.Point(608, 105)
        Me.DTPCompromiso.Name = "DTPCompromiso"
        Me.DTPCompromiso.Size = New System.Drawing.Size(120, 19)
        Me.DTPCompromiso.TabIndex = 104
        '
        'LblFecCompro
        '
        Me.LblFecCompro.AutoSize = True
        Me.LblFecCompro.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFecCompro.Location = New System.Drawing.Point(464, 108)
        Me.LblFecCompro.Name = "LblFecCompro"
        Me.LblFecCompro.Size = New System.Drawing.Size(111, 15)
        Me.LblFecCompro.TabIndex = 103
        Me.LblFecCompro.Text = "Fecha Compromiso: "
        '
        'DTPReal
        '
        Me.DTPReal.CustomFormat = "dd/MM/yyyy"
        Me.DTPReal.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPReal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPReal.Location = New System.Drawing.Point(608, 133)
        Me.DTPReal.Name = "DTPReal"
        Me.DTPReal.Size = New System.Drawing.Size(120, 19)
        Me.DTPReal.TabIndex = 106
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(464, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 15)
        Me.Label4.TabIndex = 105
        Me.Label4.Text = "Fecha Real Entrega: "
        '
        'gp1
        '
        Me.gp1.Controls.Add(Me.DGrid)
        Me.gp1.Controls.Add(Me.CboTipos_RevEdit)
        Me.gp1.Controls.Add(Me.LblTipos_RevEdit)
        Me.gp1.Location = New System.Drawing.Point(216, 176)
        Me.gp1.Name = "gp1"
        Me.gp1.Size = New System.Drawing.Size(512, 232)
        Me.gp1.TabIndex = 109
        Me.gp1.TabStop = False
        '
        'DGrid
        '
        Me.DGrid.CaptionVisible = False
        Me.DGrid.DataMember = ""
        Me.DGrid.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DGrid.Location = New System.Drawing.Point(8, 32)
        Me.DGrid.Name = "DGrid"
        Me.DGrid.Size = New System.Drawing.Size(496, 192)
        Me.DGrid.TabIndex = 111
        '
        'CboTipos_RevEdit
        '
        Me.CboTipos_RevEdit.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboTipos_RevEdit.Location = New System.Drawing.Point(96, 0)
        Me.CboTipos_RevEdit.Name = "CboTipos_RevEdit"
        Me.CboTipos_RevEdit.Size = New System.Drawing.Size(400, 21)
        Me.CboTipos_RevEdit.TabIndex = 110
        Me.CboTipos_RevEdit.Text = "ComboBox1"
        '
        'LblTipos_RevEdit
        '
        Me.LblTipos_RevEdit.AutoSize = True
        Me.LblTipos_RevEdit.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTipos_RevEdit.Location = New System.Drawing.Point(9, 3)
        Me.LblTipos_RevEdit.Name = "LblTipos_RevEdit"
        Me.LblTipos_RevEdit.Size = New System.Drawing.Size(76, 15)
        Me.LblTipos_RevEdit.TabIndex = 109
        Me.LblTipos_RevEdit.Text = "Revisi�n por: "
        '
        'TxtTtotal
        '
        Me.TxtTtotal.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTtotal.Location = New System.Drawing.Point(600, 416)
        Me.TxtTtotal.Name = "TxtTtotal"
        Me.TxtTtotal.Size = New System.Drawing.Size(120, 19)
        Me.TxtTtotal.TabIndex = 111
        Me.TxtTtotal.Text = ""
        Me.TxtTtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblTotal
        '
        Me.LblTotal.AutoSize = True
        Me.LblTotal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTotal.Location = New System.Drawing.Point(544, 418)
        Me.LblTotal.Name = "LblTotal"
        Me.LblTotal.Size = New System.Drawing.Size(51, 15)
        Me.LblTotal.TabIndex = 110
        Me.LblTotal.Text = "Subtotal:"
        '
        'TxtTotalErr
        '
        Me.TxtTotalErr.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTotalErr.Location = New System.Drawing.Point(600, 448)
        Me.TxtTotalErr.Name = "TxtTotalErr"
        Me.TxtTotalErr.Size = New System.Drawing.Size(120, 19)
        Me.TxtTotalErr.TabIndex = 113
        Me.TxtTotalErr.Text = ""
        Me.TxtTotalErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(544, 448)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 15)
        Me.Label1.TabIndex = 112
        Me.Label1.Text = "Total:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(216, 418)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 15)
        Me.Label3.TabIndex = 114
        Me.Label3.Text = "Comentario:"
        '
        'TxtComentario
        '
        Me.TxtComentario.Font = New System.Drawing.Font("Arial", 8.181818!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtComentario.Location = New System.Drawing.Point(288, 416)
        Me.TxtComentario.Multiline = True
        Me.TxtComentario.Name = "TxtComentario"
        Me.TxtComentario.Size = New System.Drawing.Size(248, 48)
        Me.TxtComentario.TabIndex = 115
        Me.TxtComentario.Text = ""
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdGuardar, Me.CmdBorrar, Me.cmdAsignar, Me.cmdSeguimiento, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 474)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(736, 62)
        Me.tlbBotonera.TabIndex = 116
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdGuardar
        '
        Me.CmdGuardar.ImageIndex = 2
        Me.CmdGuardar.Text = "Guardar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'cmdAsignar
        '
        Me.cmdAsignar.ImageIndex = 7
        Me.cmdAsignar.Text = "Asignar"
        Me.cmdAsignar.ToolTipText = "Asignas una Revici�n  Editorial al Tema"
        '
        'cmdSeguimiento
        '
        Me.cmdSeguimiento.ImageIndex = 6
        Me.cmdSeguimiento.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        Me.cmdSeguimiento.Text = "Seguimiento"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'FrmRev_Editorial
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(736, 536)
        Me.Controls.Add(Me.TxtComentario)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtTotalErr)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtTtotal)
        Me.Controls.Add(Me.LblTotal)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LblFecCompro)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtPNN)
        Me.Controls.Add(Me.LblPNN)
        Me.Controls.Add(Me.TxtResponsable)
        Me.Controls.Add(Me.LblResponsable)
        Me.Controls.Add(Me.TxtRevisor)
        Me.Controls.Add(Me.LblRevisor)
        Me.Controls.Add(Me.TxtComTec)
        Me.Controls.Add(Me.LblComTec)
        Me.Controls.Add(Me.TxtNumPag)
        Me.Controls.Add(Me.LblNumPag)
        Me.Controls.Add(Me.TxtAntProy)
        Me.Controls.Add(Me.LblAntProy)
        Me.Controls.Add(Me.Lbltemas)
        Me.Controls.Add(Me.gp1)
        Me.Controls.Add(Me.DTPReal)
        Me.Controls.Add(Me.DTPCompromiso)
        Me.Controls.Add(Me.DTPFecIni)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.TVProgTemas)
        Me.Controls.Add(Me.tlbBotonera)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmRev_Editorial"
        Me.Text = "Revisi�n Editorial"
        Me.gp1.ResumeLayout(False)
        CType(Me.DGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos "

#Region "Guarda_Datos, Metodos y Procesos"

    Private Sub Guarda_datos()
        Dim DRregs As DataRow
        Dim DRNRegs As DataRow
        Dim i As Integer
        Dim DTGridTemp As DataTable
        Dim bexiste As Boolean = False
        DTGridTemp = DGrid.DataSource
        For Each DRregs In DTGridTemp.Rows
            For Each DRNRegs In DTContenedorErrores.Rows
                If DRNRegs("Id_Inciso_Rev") = DRregs("Id_Inciso_Rev") Then
                    bexiste = True
                    DRNRegs("no_error") = DRregs("no_error")
                    Exit For
                End If
            Next
            If Not bexiste Then
                DRNRegs = DTContenedorErrores.NewRow
                For i = 0 To DTContenedorErrores.Columns.Count - 1
                    DRNRegs(i) = DRregs(i)
                Next
                DTContenedorErrores.Rows.Add(DRNRegs)
            End If
        Next
    End Sub

#End Region

#Region " SoloNumeros, Metodos y Procesos "

#Region " SoloNumeros - SoloNumeroskeypress(Object,  e), Metodos y Procesos "

    Private Sub SoloNumeroskeypress(ByVal sender As Object, ByVal e As KeyPressEventArgs)

        'Ignora la tecla presionada si no es d�gito o tecla de control
        If e.KeyChar.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf e.KeyChar.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

        'Ignora la tecla presionada si el valor es mas grande de cuatro d�gitos
        If ((sender.Text.Length >= 4) AndAlso Not (e.KeyChar.IsControl(e.KeyChar)) AndAlso sender.SelectionLength = 0) Then
            e.Handled = True
        End If
        'DGrid_CurrentCellChanged(DGrid, e)

    End Sub

#End Region

#Region " SoloNumeros - SoloNumeros(Keyascii), Metodos y Procesos "

    Private Function SoloNumeros(ByVal Keyascii As Short) As Short
        If InStr("1234567890", Chr(Keyascii)) = 0 Then
            SoloNumeros = 0
        Else
            SoloNumeros = Keyascii
        End If
        Select Case Keyascii
            Case 8
                SoloNumeros = Keyascii
            Case 13
                SoloNumeros = Keyascii
        End Select
    End Function

#End Region

#End Region

#Region " Llenar_Datos(Plan, tema, RevEdit), Metodos y Procesos "

    Private Sub Llenar_Datos(ByVal Plan As String, ByVal tema As Integer, ByVal RevEdit As Integer)
        Cursor.Current = Cursors.WaitCursor
        Try
            Dim otablallenadatos As DataTable
            objPRE.Id_Rev_Edit = RevEdit
            objPRE.Bandera = 2
            otablallenadatos = objPRE.Listar
            Dim oreg As DataRow
            If otablallenadatos.Rows.Count > 0 Then
                For Each oreg In otablallenadatos.Rows
                    TxtAntProy.Text = (IIf((IsDBNull(oreg("Titulo"))), "", oreg("Titulo")))
                    TxtNumPag.Text = CStr(IIf((IsDBNull(oreg("Num_Pag_Rev_Edit"))), 0, oreg("Num_Pag_Rev_Edit")))
                    TxtPNN.Text = (IIf((IsDBNull(oreg("Clasificacion"))), "", oreg("Clasificacion")))
                    If (IIf((IsDBNull(oreg("id_Grupo"))), "NA", oreg("id_Grupo"))) <> "NA" Then
                        TxtComTec.Text = oreg("id_Grupo")
                    ElseIf (IIf((IsDBNull(oreg("id_sc"))), "NA", oreg("id_sc"))) <> "NA" Then
                        TxtComTec.Text = oreg("id_sc")
                    ElseIf (IIf((IsDBNull(oreg("id_CT"))), "NA", oreg("id_CT"))) <> "NA" Then
                        TxtComTec.Text = oreg("id_CT")
                    ElseIf (IIf((IsDBNull(oreg("id_Comite"))), "NA", oreg("id_Comite"))) <> "NA" Then
                        TxtComTec.Text = oreg("id_Comite")
                    End If
                    objempleados.Id_usuario = (IIf((IsDBNull(oreg("Responsable"))), "", oreg("Responsable")))
                    objempleados.Bandera = 3
                    objempleados.Buscar()
                    If objempleados.NOMBRE_COMPLETO = "" Then
                        ErrorProvider1.SetError(LblResponsable, "No hay datos de este usuario: " & Chr(13) & Chr(13) & (IIf((IsDBNull(oreg("Responsable"))), "", oreg("Responsable"))) & Chr(13))
                    End If
                    TxtResponsable.Text = objempleados.NOMBRE_COMPLETO
                    DTPCompromiso.Value = CDate((IIf((IsDBNull(oreg("F_Compromiso_Revisor"))), Now(), oreg("F_Compromiso_Revisor"))))
                    objempleados.Id_usuario = (IIf((IsDBNull(oreg("Id_Usuario_Revisor"))), "", oreg("Id_Usuario_Revisor")))
                    objempleados.Bandera = 3
                    objempleados.Buscar()
                    If objempleados.NOMBRE_COMPLETO = "" Then
                        ErrorProvider1.SetError(LblRevisor, "No hay datos de este usuario: " & Chr(13) & Chr(13) & (IIf((IsDBNull(oreg("Responsable"))), "", oreg("Responsable"))) & Chr(13))
                    End If
                    If tipo_consulta = 3 Then
                        DTPFecIni.Value = CDate((IIf((IsDBNull(oreg("Fecha_Revision"))), Now(), oreg("Fecha_Revision"))))
                        TxtComentario.Text = (IIf((IsDBNull(oreg("comentario"))), "", oreg("comentario")))
                        ObjPERE.Id_Rev_Edit = RevEdit
                        ObjPERE.Bandera = 2
                        DTContenedorErrores = ObjPERE.Listar()
                    End If
                    TxtRevisor.Text = objempleados.NOMBRE_COMPLETO
                    Exit For
                Next
            Else
                TxtAntProy.Text = ""
                TxtNumPag.Text = "0"
                TxtPNN.Text = ""
                TxtComTec.Text = ""
                TxtResponsable.Text = ""
                DTPCompromiso.Value = CDate(Now())
                TxtRevisor.Text = ""
                Inactivos(gp1)
            End If
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MessageBox.Show(ex.ToString & " - Revisi�n Editorial - " & ex.Message, "Revisi�n Editorial", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#Region " Validaciones, Metodos y Procesos "

#Region "Validaciones - Validagrid, Metodos y Procesos "
    Private Function Validagrid()
        Dim fil As Integer
        Dim valreturn As Boolean = True
        lleno = 0
        ErrorProvider1.SetError(LblTipos_RevEdit, "")
        For fil = 0 To DGrid.VisibleRowCount - 1
            Dim sPlan = (IIf(IsDBNull(DGrid.Item(fil, 2)), -1, IIf(DGrid.Item(fil, 2) = "", -1, DGrid.Item(fil, 2))))
            If sPlan = -1 Then
                lleno = lleno + 1
                ErrorProvider1.SetError(LblTipos_RevEdit, "Debes llenar el n�mero de error de la opci�n " & Chr(13) & DGrid.Item(fil, 1) & " en la l�nea " & CStr(fil))
                valreturn = False
            End If
        Next
        If lleno = DGrid.VisibleColumnCount Then
            valreturn = True
            ErrorProvider1.SetError(LblTipos_RevEdit, "No se lleno ninguna opci�n de " & sCboTxt)
        End If
        Validagrid = valreturn
    End Function

#End Region

#Region " Funciones - Valida(casos), Metodos y Procesos "

    Private Function Valida(ByVal casos As String) As Boolean
        Try
            Dim aCasos As Array
            Dim valreturn As Boolean = True
            aCasos = Split(casos, " _#_ ")
            Select Case aCasos(0)
                Case "TVProgTemas"
                    If LblTreeView.Text.Length <= 0 Then
                        ErrorProvider1.SetError(LblTreeView, "Debes seleccionar un Tema")
                        valreturn = False
                    Else
                        ErrorProvider1.SetError(LblTreeView, "")
                    End If
                Case "Contenedor"
                    Dim DRregs As DataRow
                    If DTContenedorErrores.Rows.Count > 0 Then
                        For Each DRregs In DTContenedorErrores.Rows
                            If DRregs("no_error") Is System.DBNull.Value Then valreturn = False
                        Next
                    End If
            End Select
            Return valreturn
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

#End Region

#Region " Restaurar Datos, Metodos y Procesos"

    Private Function Restaurar(ByVal caso As String, ByVal Revision_Error As Integer)
        Select Case caso
            Case "editar-incisos"
                ObjPERE.Id_Rev_Edit = Revision_Error
                ObjPERE.Bandera = 200
                Try
                    Accion = ObjPERE.Insertar()
                Catch ex As Exception When Accion = False
                    MsgBox("Error 001R - Al intentar restaurar integridad de los datos..." + Chr(13) + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                End Try
            Case "editar-cambios_f_f"
                objPRE.Id_Rev_Edit = Revision_Error
                objPRE.Bandera = 201
                Try
                    Accion = objPRE.Insertar()
                Catch ex As Exception When Accion = False
                    MsgBox("Error 002R - Al intentar restaurar integridad de los datos..." + Chr(13) + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                End Try
        End Select

    End Function

#End Region

#Region " Guardar, Metodos y Procesos"

    Private Function Guardar() As Boolean
        Dim DRregs As DataRow
        Dim lblarray As Array
        Dim ttore As Integer = 0
        Dim i As Integer
        lblarray = Split(LblTreeView.Text, " - ")
        If tipo_consulta = 1 Then
            Try                   '------------------ Primer Caso General ------------------
                Call Guarda_datos()
                Try                   '------------------ segundo Caso ------------------
                    If DTContenedorErrores.Rows.Count > 0 Then
                        For Each DRregs In DTContenedorErrores.Rows
                            ObjPERE.Id_Rev_Edit = CInt(Mid(lblarray(2), 4))
                            ObjPERE.Id_Inciso_Rev = CInt(DRregs("Id_Inciso_Rev"))
                            ObjPERE.Total_Errores = CInt(DRregs("No_Error"))
                            ObjPERE.Bandera = 1
                            Accion = ObjPERE.Insertar()
                            If DRregs("Id_Status_Rev") = 1 Then ttore = ttore + CInt(DRregs("No_Error"))
                        Next
                    End If
                Catch ex As Exception When Accion = False
                    MsgBox("Error G001  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    If iEditar = "Editar" Then
                        Restaurar("editar-incisos", CInt(Mid(lblarray(2), 4)))
                    End If
                    Return False
                End Try
                If (ttore / CInt(TxtNumPag.Text)) > 1 Then objPRE.Aprobado = 0 Else objPRE.Aprobado = 1
                Try
                    If DTContenedorErrores.Rows.Count > 0 Then
                        objPRE.Total_Errores = ttore
                        objPRE.Comentario = Trim(TxtComentario.Text)
                        objPRE.F_Fin_Revisor = Format(Now.Today, "dd/MM/yyyy")
                        objPRE.Bandera = 2
                        Accion = objPRE.Actualizar()
                    End If
                Catch ex As Exception When Accion = False
                    MsgBox("Error G002  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    If iEditar = "Editar" Then
                        Restaurar("editar-incisos", CInt(Mid(lblarray(2), 4)))
                        Restaurar("editar-cambios_f_f", CInt(Mid(lblarray(3), 4)))
                    End If
                    Return False
                End Try

                Return True
            Catch ex As Exception
                MsgBox("Error G000  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                If iEditar = "Editar" Then
                    Restaurar("editar-borra", CInt(Mid(lblarray(3), 4)))
                End If
                Return False
            End Try
        ElseIf tipo_consulta = 3 Then
            Try
                objPRE.Aprobado = 1
                objPRE.Total_Errores = TxtTotalErr.Text
                objPRE.Comentario = Trim(TxtComentario.Text)
                objPRE.Bandera = 2
                Accion = objPRE.Actualizar()
            Catch ex As Exception When Accion = False
                MsgBox("Error G002  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                If iEditar = "autorizar" Then
                    Restaurar("editar-cambios_f_f", CInt(Mid(lblarray(3), 4)))
                End If
                Return False
            End Try

            Return True
        End If

    End Function

#End Region

#End Region

#Region " Combo de Tipos de Reviciones Editoriales, CboTipos_RevEdit"

    Private Sub CboTipos_RevEdit_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboTipos_RevEdit.SelectedIndexChanged
        Dim accion, blleno As Boolean
        Dim i As Integer
        Dim newscboval = CboTipos_RevEdit.SelectedValue
        Dim newscbotxt = CboTipos_RevEdit.Text
        Dim DTGridTemp As DataTable
        Try
            Cursor.Current = Cursors.WaitCursor
            DTGridTemp = DGrid.DataSource
            If tipo_consulta = 1 Then            '------------------- Llena grid cuando es revision Editorial -------
                If iEditar = "editar" Then
                    If sGrilla = "Llena" Then
                        sGrilla = "Guardando"
                        accion = Validagrid()
                        If Not accion Then
                            ' lleno <> DGrid.VisibleColumnCount 
                            CboTipos_RevEdit.SelectedValue = sCbovalue
                            DGrid.DataSource = DTGridTemp
                            sGrilla = "Llena"
                            Cursor.Current = Cursors.Default
                            Exit Sub
                        ElseIf lleno = DGrid.VisibleColumnCount Then
                            CboTipos_RevEdit.SelectedValue = sCbovalue
                            sGrilla = "Llena"
                            Cursor.Current = Cursors.Default
                            Exit Sub
                        Else
                            MessageBox.Show("Guardando..." & Chr(13) & "Se realiza proceso parcial de Revisi�n Editorial", "Revisi�n Editorial", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            Call Guarda_datos()
                            svaluescbo = sCbovalue & " " & svaluescbo
                            TxtTtotal.Text = "0"
                            GoTo llenando
                        End If
                    ElseIf sGrilla = "Guardando" Then
                        sGrilla = "Llena"
                    Else
llenando:
                        Dim vals As Array
                        ErrorProvider1.SetError(LblTipos_RevEdit, "")
                        vals = Split(Trim(svaluescbo), " ")
                        If Trim(svaluescbo) <> "" Then
                            For i = 0 To vals.Length - 1
                                If newscboval = CInt(vals(i)) Then blleno = True
                            Next
                        End If
                        sGrilla = "Llena"
                        If Not blleno Then
                            illenos = illenos + 1
                            Llena_grid(newscboval)
                            If illenos >= CboTipos_RevEdit.Items.Count Then Activos(tlbBotonera.Buttons(3))
                        Else
                            If MessageBox.Show(" Esta Revisi�n ya ha sido guardada..." & Chr(13) & Chr(13) & "�Deseas modificarla? ", "Revisi�n Editorial", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
llenado1:
                                Dim cm As CurrencyManager
                                cm = CType(BindingContext(DTContenedorErrores), CurrencyManager)
                                Dim Dv As DataView = CType(cm.List, DataView)
                                Dv.AllowNew = False
                                Dv.RowFilter = "Id_tipo_Rev = " & newscboval
                                DGrid.DataSource = DTContenedorErrores
                                Dim contador As Integer = 0
                                Dim ival As Integer
                                DTGridTemp = DGrid.DataSource
                                For i = 0 To DGrid.VisibleRowCount - 1
                                    ival = CInt(IIf((DGrid.Item(i, 2) = ""), "0", DGrid.Item(i, 2)))
                                    If DTGridTemp.Rows(i).Item("Id_Status_Rev") = 1 Then
                                        contador = contador + ival
                                    End If
                                Next
                                TxtTtotal.Text = contador
                                contador = 0
                                Dim drregs As DataRow
                                For Each drregs In DTContenedorErrores.Rows
                                    If drregs("Id_Status_Rev") = 1 Then contador = contador + CInt(drregs("No_Error"))
                                Next
                                TxtTotalErr.Text = contador
                                If tipo_consulta = 1 Then ErrorProvider1.SetError(LblTipos_RevEdit, "Esta editando esta opci�n " & newscboval)
                            Else
                                TxtTtotal.Text = "0"
                                sGrilla = "Vacia"
                                Llena_grid(0)
                            End If
                        End If

                    End If
                End If
            Else
                If tipo_consulta = 3 Then
                    DGrid_Leave(DGrid, e)
                    GoTo llenado1
                Else
                    TxtTtotal.Text = "0"
                    sGrilla = "Vacia"
                    Llena_grid(0)
                End If
            End If
            sCbovalue = newscboval
            sCboTxt = newscbotxt
            Cursor.Current = Cursors.Default

        Catch ex As Exception
            MessageBox.Show(" Error - Revisi�n Editorial  " & Chr(13) & ex.ToString & " - Revisi�n Editorial - " & ex.Message, "Revisi�n Editorial", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#Region " Datagrid, Metodos y Procesos"

#Region " Datagrid - Llena_grid(id_tipo), Metodos y Procesos"

    Private Function Llena_grid(ByVal id_tipo As Integer) As Boolean
        Dim cm As CurrencyManager
        Dim dt As New DataTable

        If tipo_consulta = 1 Then
            objincisos.Id_tipo_Rev = id_tipo
            objincisos.Bandera = 1
            dt = objincisos.Listar
        Else
            dt = DTContenedorErrores
        End If
        cm = CType(BindingContext(dt), CurrencyManager)
        'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyManager
        Dim Dv As DataView = CType(cm.List, DataView)
        'Asignamos el valor que deseamos para evitar o permitir nuevos registros
        If tipo_consulta = 3 Then
            Dv.AllowEdit = False
            Dv.RowFilter = "Id_tipo_Rev = " & id_tipo
        End If
        Dv.AllowDelete = False
        Dv.AllowNew = False
        DGrid.DataSource = dt
        dt.AcceptChanges()
    End Function

#End Region

#Region " Datagrid- colores(PaintRowEventArgs), Metodos y Procesos"

    Private Sub colores(ByVal args As PaintRowEventArgs)

        Try
            Cursor.Current = Cursors.WaitCursor
            Dim dttipos As New DataTable
            dttipos = DGrid.DataSource
            objstatus_revedit.Id_Status_Rev = CInt(dttipos.Rows(args.RowNumber).Item("id_status_rev"))
            objstatus_revedit.Bandera = 2
            objstatus_revedit.Buscar()
            Dim br As New SolidBrush(System.Drawing.Color.FromName(objstatus_revedit.Color))
            args.BackColor = br
            Cursor.Current = Cursors.Default
        Catch ex As Exception When objstatus_revedit.sError <> ""
            MessageBox.Show(ex.ToString & " - Revisi�n Editorial - " & ex.Message, "Revisi�n Editorial", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Cursor.Current = Cursors.Default
        End Try

    End Sub

#End Region

#Region " Datagrid - Crea_gd, Metodo datagridstyle"

    Private Sub Crea_gd()

        Try
            Cursor.Current = Cursors.WaitCursor

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle

            Call Tabla_Color(ts1, DGrid)
            If tipo_consulta = 1 Then
                ts1.MappingName = "Cls_IRE"
            Else
                ts1.MappingName = "Cls_PERE"
            End If

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Requisito"
            TextCol1.HeaderText = "Requisito"
            TextCol1.Width = 80
            TextCol1.Alignment = HorizontalAlignment.Center
            ' TextCol1.ReadOnly = True
            TextCol1.TextBox.Enabled = True


            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Descripcion"
            TextCol2.HeaderText = "Descripci�n"
            TextCol2.TextBox.WordWrap = True
            TextCol2.Width = 320
            'TextCol2.TextBox.ReadOnly = True '.Enabled = True
            TextCol2.TextBox.ScrollBars = ScrollBars.Vertical
            TextCol2.TextBox.WordWrap = True
            TextCol2.TextBox.Multiline = True
            TextCol2.TextBox.Height = 20
            TextCol2.TextBox.Width = 318
            TextCol2.ReadOnly = True
            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "No_Error"
            TextCol3.HeaderText = "Errores"
            TextCol3.Width = 60
            TextCol3.Alignment = HorizontalAlignment.Center
            TextCol3.Format = "g"
            '''''''''''''''''''''''''''''''''''''''                                                 Pendiente                                                  ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


            AddHandler TextCol1.PaintRow, AddressOf colores
            AddHandler TextCol2.PaintRow, AddressOf colores
            AddHandler TextCol3.PaintRow, AddressOf colores


            ts1.PreferredRowHeight = TextCol2.TextBox.Height * 1.75
            ts1.GridColumnStyles.AddRange(New DataGridColumnStyle() {TextCol1, TextCol2, TextCol3})
            Dim tbc As DataGridTextBoxColumn = CType(ts1.GridColumnStyles(2), DataGridTextBoxColumn)
            AddHandler tbc.TextBox.KeyPress, AddressOf SoloNumeroskeypress

            DGrid.TableStyles.Add(ts1)


            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MessageBox.Show(ex.ToString & " - Revision Editorial - " & ex.Message)
            Cursor.Current = Cursors.Default
        End Try

    End Sub

#End Region

#Region " Datagrid - control , Metodos y Procesos"

    Private Sub DGrid_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DGrid.CurrentCellChanged
        DGrid_Leave(DGrid, e)
    End Sub

    Private Sub DGrid_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles DGrid.Leave
        Dim i, ival As Integer
        If DGrid.CurrentCell.ColumnNumber = 2 Then
            Dim DTGridTemp As DataTable = DGrid.DataSource
            Dim DrRegs As DataRow
            Dim contador As Integer = 0
            For i = 0 To DGrid.VisibleRowCount - 1
                ival = CInt(IIf((DGrid.Item(i, 2) = ""), "0", DGrid.Item(i, 2)))
                If DTGridTemp.Rows(i).Item("Id_Status_Rev") = 1 Then
                    contador = contador + ival
                End If
            Next
            TxtTtotal.Text = contador
            For Each DrRegs In DTContenedorErrores.Rows
                If DrRegs("Id_Status_Rev") = 1 Then contador = contador + CInt(DrRegs("No_Error"))
            Next
            TxtTotalErr.Text = contador
        End If
    End Sub

#End Region

#End Region

#Region " Forms, Metodos y eventos del  FrmRev_Editorial"

    Private Sub FrmRev_Editorial_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        Cursor.Current = Cursors.WaitCursor
        iEditar = ""
        Call LlenaTreeView()
        Call Crea_gd()
        Inactivos(CboTipos_RevEdit, TxtAntProy, TxtNumPag, TxtPNN, TxtComTec, TxtResponsable, DTPCompromiso, TxtRevisor, TxtTotalErr, TxtTtotal, TxtComentario, DTPFecIni, DTPReal, tlbBotonera.Buttons(3), tlbBotonera.Buttons(0), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), tlbBotonera.Buttons(2))
        Try
            Dim dt As New DataTable
            If tipo_consulta = 1 Then
                objincisos.Id_tipo_Rev = 0
                objincisos.Bandera = 1
                DTContenedorErrores = objincisos.Listar
            Else
                ObjPERE.Id_Rev_Edit = 0
                ObjPERE.Bandera = 2
                DTContenedorErrores = ObjPERE.Listar()
            End If
            objTipos_RevEdit.Bandera = 1
            objTipos_RevEdit.ListaCombo(CboTipos_RevEdit)
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#Region " ToolBarButton, Metodos y Eventos del tlbBotonera"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0                 '''----------   Agregar     --------
            Case 1                   '''----------   Edita     --------
                If Valida("TVProgTemas") Then
                    If tipo_consulta = 1 Then
                        Activos(tlbBotonera.Buttons(2), CboTipos_RevEdit, TxtComentario)
                        iEditar = "editar"
                        DTContenedorErrores.Rows.Clear()
                        TxtComentario.Text = "" : TxtTotalErr.Text = "0" : TxtTtotal.Text = "0"
                    Else
                        Activos(tlbBotonera.Buttons(5), tlbBotonera.Buttons(2), CboTipos_RevEdit)
                        iEditar = "autoriza"
                    End If
                    sGrilla = "Vacia"
                    Llena_grid(0)
                    Inactivos(TVProgTemas, tlbBotonera.Buttons(1))
                    illenos = 0
                    svaluescbo = ""
                End If
            Case 2                   '''----------   Deshacer     --------
                iEditar = ""
                If tipo_consulta = 1 Then
                    DTContenedorErrores.Rows.Clear()
                End If
                sGrilla = "Vacia"
                Llena_grid(0)
                TxtComentario.Text = "" : TxtTotalErr.Text = "0" : TxtTtotal.Text = "0"
                TVProgTemas.Nodes.Clear()
                Call LlenaTreeView()
                Inactivos(CboTipos_RevEdit, TxtAntProy, TxtNumPag, TxtPNN, TxtComTec, TxtResponsable, DTPCompromiso, TxtRevisor, TxtTotalErr, TxtTtotal, TxtComentario, DTPFecIni, DTPReal, tlbBotonera.Buttons(4), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5), tlbBotonera.Buttons(3))
                Activos(tlbBotonera.Buttons(1), TVProgTemas)
            Case 3                   '''----------   Guardar     --------

                Try
                    If Valida("TVProgTemas") And Valida("contenedor") Then
                        Accion = Guardar()
                        If Accion Then
                            Inactivos(CboTipos_RevEdit, TxtAntProy, TxtNumPag, TxtPNN, TxtComTec, TxtResponsable, DTPCompromiso, TxtRevisor, TxtTotalErr, TxtTtotal, TxtComentario, DTPFecIni, DTPReal, tlbBotonera.Buttons(4), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5), tlbBotonera.Buttons(3))
                            Activos(tlbBotonera.Buttons(1), TVProgTemas)
                            iEditar = ""
                            sGrilla = "Vacia"
                            TxtComentario.Text = "" : TxtTotalErr.Text = "0" : TxtTtotal.Text = "0"
                            Llena_grid(0)
                            TVProgTemas.Nodes.Clear()
                            Call LlenaTreeView()
                        End If
                    End If
                Catch ex As Exception When Accion = False
                    MsgBox("Error C000  " + Chr(13) + Chr(13) + "Faltan datos en el formulario." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                End Try
            Case 4                   '''----------   Eliminar     --------
            Case 5                    ''----------   Autorizar    ---------
                If tipo_consulta = 3 And iEditar = "autoriza" Then
                    Try
                        If Valida("TVProgTemas") Then
                            Accion = Guardar()
                            If Accion Then
                                Inactivos(CboTipos_RevEdit, TxtAntProy, TxtNumPag, TxtPNN, TxtComTec, TxtResponsable, DTPCompromiso, TxtRevisor, TxtTotalErr, TxtTtotal, TxtComentario, DTPFecIni, DTPReal, tlbBotonera.Buttons(4), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5), tlbBotonera.Buttons(3))
                                Activos(tlbBotonera.Buttons(1), TVProgTemas)
                                iEditar = ""
                                sGrilla = "Vacia"
                                Llena_grid(0)
                                DTContenedorErrores.Rows.Clear()
                                TVProgTemas.Nodes.Clear()
                                Call LlenaTreeView()
                            End If
                        End If
                    Catch ex As Exception When Accion = False
                        MsgBox("Error C000  " + Chr(13) + Chr(13) + "Faltan datos en el formulario." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
                End If
            Case 8                   '''----------   Salir     --------
                iEditar = ""
                Me.Close()
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " TreeView, Metodos  para el TVProgTemas"

    Public Sub LlenaTreeView()
        Try
            Cursor.Current = Cursors.WaitCursor
            ErrorProvider1.SetError(LblResponsable, "")
            ErrorProvider1.SetError(LblRevisor, "")
            Dim Tree As TreeNode
            Dim PNN As TreeNode
            Dim DT As TreeNode
            Dim RE As TreeNode

            Dim oTablaPNN As DataTable
            Dim oTablaDT As DataTable
            Dim oTablaRE As DataTable

            TVProgTemas.BeginUpdate()
            Tree = TVProgTemas.Nodes.Add("Seleccione un Tema")
            Tree.ImageIndex = 2
            Tree.SelectedImageIndex = 2
            Dim RegPNN As DataRow
            Dim RegDT As DataRow
            Dim RegRE As DataRow
            objplanes.Bandera = 1
            oTablaPNN = objplanes.Listar()
            For Each RegPNN In oTablaPNN.Rows
                PNN = Tree.Nodes.Add(Trim(RegPNN(1)))
                objprogtrab.Id_Plan = Trim(RegPNN(1))
                If tipo_consulta = 1 Then objprogtrab.Bandera = 13 Else objprogtrab.Bandera = 14
                oTablaDT = objprogtrab.Listar()
                If oTablaDT.Rows.Count <> -1 Then
                    For Each RegDT In oTablaDT.Rows
                        DT = PNN.Nodes.Add(Trim(RegDT(1)))
                        DT.ImageIndex = 5
                        DT.SelectedImageIndex = 5
                        objPRE.Id_Usuario_Revisor = gUsuario
                        objPRE.Id_Plan = RegPNN(1)
                        objPRE.Id_Tema = RegDT(1)
                        objPRE.Bandera = tipo_consulta
                        oTablaRE = objPRE.Listar()
                        If oTablaRE.Rows.Count <> -1 Then
                            For Each RegRE In oTablaRE.Rows
                                RE = DT.Nodes.Add("REV" + Format$(RegRE("id_Rev_Edit"), "0000"))
                                RE.ImageIndex = 6
                                RE.SelectedImageIndex = 6
                            Next
                        End If
                    Next
                End If
            Next
            TVProgTemas.EndUpdate()
            ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
            TVProgTemas.AllowDrop = True
            ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
            ' TVProgTemas.Sorted = True
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MessageBox.Show(ex.ToString & " - Revisi�n Editorial - " & ex.Message, "Revisi�n Editorial", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    Private Sub TVProgTemas_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVProgTemas.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lbltemas, "")
        ErrorProvider1.SetError(LblResponsable, "")
        Dim valor_nodo, valor As String
        Dim ivalor As Integer
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione un Tema" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")

        If iEditar = "Resive" Or iEditar = "Agregar" Or iEditar = "" Then
            Call Llenar_Datos("", 0, 0)
        End If
        Activos(gp1)
        Select Case array_texto.Length
            Case 4
                Call Llenar_Datos(array_texto(1), CInt(array_texto(2)), CInt(Mid(array_texto(3), 4)))
                Activos(tlbBotonera.Buttons(1))
            Case Else
                Inactivos(gp1, tlbBotonera.Buttons(1))
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region


    Public Sub New(ByVal tipo As Integer)
        MyBase.New()
        tipo_consulta = tipo

        'El Dise�ador de Windows Forms requiere esta llamada.

        InitializeComponent()

        If tipo_consulta = 1 Then
            Me.Text = "Revisi�n Editorial"
            Me.tlbBotonera.Buttons(5).Text = "Autorizar"
        Else
            Me.Text = "Autorizaci�n de Revisi�n Editorial"
            Me.tlbBotonera.Buttons(5).Text = "Autorizar"
        End If
        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
        objplanes.Inicializa(0, gUsuario, gPasswordSql)
        objempleados.Inicializa(Application.StartupPath & "\principal.ini", "comun", gUsuario, gPasswordSql)
    End Sub

    Private Sub DGrid_Navigate(ByVal sender As System.Object, ByVal ne As System.Windows.Forms.NavigateEventArgs) Handles DGrid.Navigate

    End Sub
End Class


