
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_Tipo_Proceso Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 08/01/2007 12:18:29 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class C_Tipo_Proceso

     '''''''Declaracion de Variables Privadas
     Private dsC_Tipo_Proceso AS New DataSet
     Private _Id_Proceso as System.Int32
     Private _Proceso as System.String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Proceso() As System.Int32
          Get
              Return _Id_Proceso
          End Get
          Set(Value as System.Int32)
              _Id_Proceso = Value
          End Set
     End Property

     Public Property Proceso() As System.String
          Get
              Return _Proceso
          End Get
          Set(Value as System.String)
              _Proceso = Value
          End Set
     End Property


     '''''''Define la cadena de Conexion a la Base de Datos
     Private  CadenaConexion as String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD

    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Tipo_Proceso")

        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            da = New SqlDataAdapter("SELECT * FROM C_Tipo_Proceso", cn)
            da.Fill(dt)
            cn.Close()
        Catch
            Return Nothing
        End Try
        Return dt

    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As String) As C_Tipo_Proceso
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM C_Tipo_Proceso WHERE Campo_Llave = sClave"
        Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da.Fill(dsC_Tipo_Proceso, "C_Encontrado")
        cn.Close()
        If dsC_Tipo_Proceso.Tables("C_Encontrado").Rows.Count > 0 Then
            _Id_Proceso = dsC_Tipo_Proceso.Tables("C_Encontrado").Rows(0).Item("Id_Proceso")
            _Proceso = dsC_Tipo_Proceso.Tables("C_Encontrado").Rows(0).Item("Proceso")
        Else
            _Id_Proceso = ""
            _Proceso = ""
        End If
        dsC_Tipo_Proceso.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE C_Tipo_Proceso SET Id_Proceso = @Id_Proceso, Proceso = @Proceso, Where ( = @)"
        cmd.Parameters.Add("@Id_Proceso", SqlDbType.Int, 0, "_Id_Proceso")
        cmd.Parameters.Add("@Proceso", SqlDbType.NVarChar, 50, "_Proceso")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "INSERT INTO C_Tipo_Proceso (Id_Proceso)Proceso,  VALUES (@Id_Proceso)@Proceso, "
        cmd.Parameters.Add("@Id_Proceso", SqlDbType.Int, 0, "_Id_Proceso")
        cmd.Parameters.Add("@Proceso", SqlDbType.NVarChar, 50, "_Proceso")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
