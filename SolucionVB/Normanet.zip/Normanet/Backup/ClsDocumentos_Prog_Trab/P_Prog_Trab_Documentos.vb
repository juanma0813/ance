
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Prog_Trab_Documentos Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 20/11/2006 05:14:35 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Prog_Trab_Documentos

     '''''''Declaracion de Variables Privadas
     Private dsP_Prog_Trab_Documentos AS New DataSet
     Private _Id_Plan as System.String
    Private _Id_Tema As Integer
    Private _Id_tipo_doc As Integer
    Private _Encontrado As Boolean
    Private _Documento As String
    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _status As Integer
    Private _sReferencia As String
    Private _tipo As String
    Private _band As Boolean
    Private sSql As String
    Private _id_comentario As Integer
    Private _activo As Boolean
    Private _bandera2 As Integer
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Plan() As System.String
          Get
              Return _Id_Plan
          End Get
          Set(Value as System.String)
              _Id_Plan = Value
          End Set
    End Property

    Public Property Activo() As Boolean
        Get
            Return _activo
        End Get
        Set(ByVal Value As Boolean)
            _activo = Value
        End Set
    End Property

    Public Property Id_Tema() As Integer
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value As Integer)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Id_tipo_doc() As Integer
        Get
            Return _Id_tipo_doc
        End Get
        Set(ByVal Value As Integer)
            _Id_tipo_doc = Value
        End Set
    End Property
    Public Property Bandera2() As Integer
        Get
            Return _bandera2
        End Get
        Set(ByVal Value As Integer)
            _bandera2 = Value
        End Set
    End Property

    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Documento() As String
        Get
            Return _Documento
        End Get
        Set(ByVal Value As String)
            _Documento = Value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property
    Public Property Status() As Integer
        Get
            Return _status
        End Get
        Set(ByVal Value As Integer)
            _status = Value
        End Set
    End Property

    Public Property id_comentario() As Integer
        Get
            Return _id_comentario
        End Get
        Set(ByVal Value As Integer)
            _id_comentario = Value
        End Set
    End Property



    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista(ByVal stema As Integer, ByVal splan As String, ByVal sref As String, ByVal bandera As Integer) As DataTable
        ''sSql = "SELECT * FROM P_Prog_Trab_Documentos  WHERE id_tema='" & stema & "' and id_plan='" & splan & "' and status <> 11 and status <> 10"
        ''sSql = sSql + " and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & sref & "' and (id_tipo_doc = 10 or id_tipo_doc = 11)"
        ''sSql = sSql + " order by id_tipo_doc "
        Dim cmd As New SqlCommand
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Doctos_Temas"
        cmd.Parameters.Add("@Id_Documento", _Id_tipo_doc)
        cmd.Parameters.Add("@id_comentario", _id_comentario)
        cmd.Parameters.Add("@sReferencia", sref)
        cmd.Parameters.Add("@bandera", bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Prog_Trab_Documentos")
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            Return Nothing
        End Try

        Return dt
    End Function

    Public Function buscadocto(ByVal clasificacion As String, ByVal id_Documento As Integer, ByVal bandera As Integer)
        Dim cmd As New SqlCommand
        Dim rs As SqlDataReader
        Dim dt As New DataTable("c_Documentos_Normas")
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Normas_Modificar"
        cmd.Parameters.Add("@id_tipo_doc", id_Documento)
        cmd.Parameters.Add("@clasificacion", clasificacion)
        cmd.Parameters.Add("@bandera", bandera)
        rs = cmd.ExecuteReader
        If rs.Read Then
            _Documento = rs("clasificacion")
            _Id_tipo_doc = rs("id_tipo_doc")
            _activo = rs("Activo")
            Return rs("Documento")
        Else
            Return Nothing
        End If
    End Function
    Public Function StatusDocto(ByVal clasificacion As String, ByVal bandera As Integer, ByVal activo As Boolean, ByVal id_tipo_doc As Integer)
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Normas_Modificar"
        cmd.Parameters.Add("@clasificacion", clasificacion)
        cmd.Parameters.Add("@bandera", bandera)
        cmd.Parameters.Add("@Activo", activo)
        cmd.Parameters.Add("@id_tipo_doc", id_tipo_doc)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sTema As String, ByVal sPlan As String, ByVal id_tipoDoc As String, ByVal sref As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Prog_Trab_Documentos  WHERE id_tema='" & sTema & "' and id_plan='" & sPlan & "' and status <> 11 and status <> 10"
        If id_tipoDoc <> "noRequerido" Then
            sSql = sSql + " and Id_tipo_doc='" & id_tipoDoc & "'"
        End If
        sSql = sSql + " and Status <> 10 and Status <> 11 and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & sref & "'"

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da.Fill(dsP_Prog_Trab_Documentos, "C_Encontrado")
        cn.Close()
        If dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows.Count > 0 Then
            _Id_Plan = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Id_Plan")
            _Id_Tema = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Id_Tema")
            _Id_tipo_doc = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Id_tipo_doc")
            _Documento = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Documento")

            _Ref_A�o = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")
            _Ref_Comite = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")
            _Ref_Consecutivo = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")
            _Ref_Regreso = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")
            _Ref_Traspaso = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")
            _status = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("status")
            _Encontrado = True
        Else
            _Id_Plan = ""
            _Id_Tema = 0
            _Id_tipo_doc = 0
            _Documento = ""
            _Encontrado = False
        End If
        dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza(ByVal stema As String, ByVal splan As String, ByVal tipo_doc As String, ByVal docto As String, ByVal bandera As Integer) As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Doctos_Temas"

        cmd.Parameters.Add("@Id_Plan", splan)
        cmd.Parameters.Add("@Id_Tema", stema)
        cmd.Parameters.Add("@tipo_doc", tipo_doc)
        cmd.Parameters.Add("@Documento", docto)
        cmd.Parameters.Add("@Bandera", bandera)

        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@status", _status)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        cmd.Parameters.Add("@Id_Documento", _Id_tipo_doc)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Doctos_Temas_buscar"
        cmd.Connection = cn
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.Parameters.Add("@Bandera", _bandera2)
            cmd.Parameters.Add("@sreferencia", _sReferencia)

            cmd.Parameters.Add("@Id_Plan", _Id_Plan)
            cmd.Parameters.Add("@Id_Tema", _Id_Tema)
            cmd.Parameters.Add("@Id_tipo_doc", _Id_tipo_doc)
            cmd.Parameters.Add("@Documento", _Documento)
            cmd.Parameters.Add("@Ref_A�o", _Ref_A�o)
            cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
            cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
            cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
            cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
            cmd.Parameters.Add("@Activo", _activo)
            cmd.Parameters.Add("@status", _status)

            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function

    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Doctos_Temas"
        cmd.Parameters.Add("@Bandera", 5)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function BuscarDoctos(ByVal sTema As String, ByVal sPlan As String, ByVal id_tipoDoc As String, ByVal sref As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT *,Documento as namedoc FROM P_Prog_Trab_Documentos  WHERE id_tema='" & sTema & "' and id_plan='" & sPlan & "' "
        If id_tipoDoc <> "noRequerido" Then
            sSql = sSql + " and Id_tipo_doc='" & id_tipoDoc & "'"
        End If
        sSql = sSql + " and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & sref & "'"

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        dsP_Prog_Trab_Documentos.Clear()
        da.Fill(dsP_Prog_Trab_Documentos, "C_Encontrado")
        cn.Close()
        If dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows.Count > 0 Then
            _Id_Plan = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Id_Plan")
            _Id_Tema = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Id_Tema")
            _Id_tipo_doc = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Id_tipo_doc")
            _Documento = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Documento")

            _Ref_A�o = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")
            _Ref_Comite = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")
            _Ref_Consecutivo = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")
            _Ref_Regreso = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")
            _Ref_Traspaso = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")
            _status = dsP_Prog_Trab_Documentos.Tables("C_Encontrado").Rows(0).Item("status")
            _Encontrado = True
        Else
            _Id_Plan = ""
            _Id_Tema = 0
            _Id_tipo_doc = 0
            _Documento = ""
            _Encontrado = False
        End If
        Return dsP_Prog_Trab_Documentos.Tables("C_Encontrado")
    End Function

    Public Sub ListaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Doctos_Temas_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 5)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ID_tipo_docto")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return
        End Try
    End Sub
    Public Sub InactivarDocto()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Doctos_Temas_buscar"
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 6)
        cmd.Parameters.Add("@id_tipo_doc", _Id_tipo_doc)
        cmd.Parameters.Add("@Documento2", _Documento)
        cmd.Parameters.Add("@status", _status)
        cmd.Parameters.Add("@activo", _activo)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return
        End Try
    End Sub
    Public Sub buarcarDocumento()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Doctos_Temas_buscar"
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 7)
        cmd.Parameters.Add("@id_tipo_doc", _Id_tipo_doc)
        cmd.Parameters.Add("@Documento2", _Documento)
        Try
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Plan = dr("Id_Plan")
                _Id_Tema = dr("Id_Tema")
                _Id_tipo_doc = dr("Id_tipo_doc")
                _Documento = dr("Documento")

                _Ref_A�o = dr("Ref_A�o")
                _Ref_Comite = dr("Ref_Comite")
                _Ref_Consecutivo = dr("Ref_Consecutivo")
                _Ref_Regreso = dr("Ref_Regreso")
                _Ref_Traspaso = dr("Ref_Traspaso")
                _status = dr("status")
                If IsDBNull(dr("activo")) Then
                    _activo = IIf(_status = 1, True, False)
                Else
                    _activo = dr("activo")
                End If
                _Encontrado = True
            Else
                _Id_Plan = Nothing
                _Id_Tema = Nothing
                _Id_tipo_doc = Nothing
                _Documento = Nothing

                _Ref_A�o = Nothing
                _Ref_Comite = Nothing
                _Ref_Consecutivo = Nothing
                _Ref_Regreso = Nothing
                _Ref_Traspaso = Nothing
                _status = Nothing
                _activo = Nothing
                _Encontrado = True
            End If
        Catch ex As Exception
            Return
        End Try
    End Sub
    Public Function ListaDocumentos()
        Dim cmd As New SqlCommand
        Dim dt As New DataTable("Documentos")
        Dim da As SqlDataAdapter
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.CommandText = "Sp_Doctos_Temas_buscar"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cn
            cmd.Parameters.Add("@bandera", 8)
            cmd.Parameters.Add("@sReferencia", _sReferencia)
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                _Encontrado = True
                Return dt
            Else
                _Encontrado = False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cmd.Dispose()
        da.Dispose()
    End Function

    Public Sub traspasaDoctos(ByVal plan As String, ByVal tema As Integer)
        Dim dt As DataTable
        Dim dr As DataRow
        Dim index As Integer = 0
        dt = ListaDocumentos()
        Try
            If Not dt Is Nothing Then
                For Each dr In dt.Rows
                    _Id_tipo_doc = dt.Rows(index).Item(7)
                    _Documento = dt.Rows(index).Item(8)
                    buarcarDocumento()
                    '_status = 1
                    _Id_Plan = plan
                    _Id_Tema = tema
                    _bandera2 = 9
                    _Ref_Traspaso = _Ref_Traspaso + 1
                    Insertar()
                    index = index + 1
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
