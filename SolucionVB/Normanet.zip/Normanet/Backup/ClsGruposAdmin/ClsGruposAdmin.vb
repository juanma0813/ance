
'*****************************************************************************
'*****************************************************************************
'           Actualizada por Efren David Tello ver 1.1 BETA
'                       NO TIENE CAMPO LLAVE CUIDADO
'              Puede Afectar el correcto funcionamiento de las funciones
'          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
'*****************************************************************************
'*****************************************************************************

Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient

'agrega la referencia de windows form a la clase
'Imports System.Windows.Forms

Public Class ClsGruposAdmin

    '''''''Declaracion de Variables Privadas
    Private dsClsGruposAdmin As New DataSet
    Private _Id_Sistema As Integer
    Private _Id_Grupo As Integer
    Private _ID_Menu As String
    Private _Nombre_Grupo As String
    Private _Encontrado As Boolean
    Private _bandera As Integer
    Private _id_usuario As String
    Private _Pass As String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo
    'Si utilisas la clase de coneccion qeu todos sabemos descomenta la linea siguiente
    'Private objconexion As New clsConexion.cIsConexion

    '''''''Declaracion de Propiedades publicas
    Public Property Id_Sistema() As Integer
        Get
            Return _Id_Sistema
        End Get
        Set(ByVal Value As Integer)
            _Id_Sistema = Value
        End Set
    End Property

    Public Property Id_Grupo() As Integer
        Get
            Return _Id_Grupo
        End Get
        Set(ByVal Value As Integer)
            _Id_Grupo = Value
        End Set
    End Property

    Public Property Nombre_Grupo() As String
        Get
            Return _Nombre_Grupo
        End Get
        Set(ByVal Value As String)
            _Nombre_Grupo = Value
        End Set
    End Property

    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _bandera
        End Get
        Set(ByVal Value As Integer)
            _bandera = Value
        End Set
    End Property

    Public Property ID_Menu() As String
        Get
            Return _ID_Menu
        End Get
        Set(ByVal Value As String)
            _ID_Menu = Value
        End Set
    End Property

    Public Property ID_Usuario() As String
        Get
            Return _id_usuario
        End Get
        Set(ByVal Value As String)
            _id_usuario = Value
        End Set
    End Property

    Public Property Pass() As String
        Get
            Return _Pass
        End Get
        Set(ByVal Value As String)
            _Pass = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsGruposAdmin")
        Dim cmd As New SqlCommand

        cmd.CommandText = "SP_Grupos"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        If cn.State = 1 Then cn.Close()
        cn.Open()

        cmd.Parameters.Add("@Id_Sistema", 16)
        cmd.Parameters.Add("@id_grupo", _Id_Grupo)
        cmd.Parameters.Add("@bandera", _bandera)
        Try
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cmd.Dispose()
        cn.Close()
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar()
        Dim da As SqlDataAdapter
        Dim cmd As New SqlCommand
        cmd.CommandText = "SP_Grupos"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        cmd.Parameters.Add("@Id_Sistema", 16)
        cmd.Parameters.Add("@Nombre_Grupo", _Nombre_Grupo)
        cmd.Parameters.Add("@bandera", _bandera)
        cmd.Parameters.Add("@id_menu", _ID_Menu)
        cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
        cmd.Parameters.Add("@Id_Usuario", _id_usuario)

        da = New SqlDataAdapter(cmd)
        da.Fill(dsClsGruposAdmin, "C_Encontrado")
        cn.Close()
        If dsClsGruposAdmin.Tables("C_Encontrado").Rows.Count > 0 Then
            _id_usuario = dsClsGruposAdmin.Tables("C_Encontrado").Rows(0).Item("Id_Sistema")
            _Id_Sistema = dsClsGruposAdmin.Tables("C_Encontrado").Rows(0).Item("Id_Grupo")
            _Id_Grupo = dsClsGruposAdmin.Tables("C_Encontrado").Rows(0).Item("Nombre_Grupo")
            _pass = dsClsGruposAdmin.Tables("C_Encontrado").Rows(0).Item("Nombre_Grupo")
            _Encontrado = True
        Else
            _id_usuario = Nothing
            _Id_Sistema = Nothing
            _Id_Grupo = Nothing
            _Pass = Nothing
            _Encontrado = False
        End If
        dsClsGruposAdmin.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_Grupos"
        cmd.Connection = cn

        cmd.Parameters.Add("@Bandera", _bandera)
        cmd.Parameters.Add("@id_grupo", _Id_Grupo)
        cmd.Parameters.Add("@Nombre_Grupo", _Nombre_Grupo)
        cmd.Parameters.Add("@id_sistema", 16)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return MsgBox(ex.Message)
        End Try

        MsgBox("Registro Actualizado")

        cn.Close()
        cmd.Dispose()
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        cmd.CommandText = "SP_Grupos"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        If cn.State = 1 Then cn.Close()
        cn.Open()

        cmd.Parameters.Add("@Id_Sistema", 16)
        cmd.Parameters.Add("@Nombre_Grupo", _Nombre_Grupo)
        cmd.Parameters.Add("@bandera", _bandera)
        cmd.Parameters.Add("@id_menu", _ID_Menu)
        cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)


        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        MsgBox("Dato insertado correctamente")
        cmd.Dispose()
        cn.Close()
    End Function
    Public Function Eliminar() As String
        Dim cmd As New SqlCommand
        cmd.CommandText = "SP_Grupos"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        If cn.State = 1 Then cn.Close()
        cn.Open()

        cmd.Parameters.Add("@Id_Sistema", 16)
        cmd.Parameters.Add("@id_grupo", _Id_Grupo)
        cmd.Parameters.Add("@bandera", _bandera)
        cmd.Parameters.Add("@id_menu", _ID_Menu)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        MsgBox("Dato Eliminado correctamente")
        cmd.Dispose()
        cn.Close()
    End Function
    '''''''''''''''''Funcion que nos permite llenar un combo
    Public Function LlenaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        cmd.CommandText = "SP_Grupos"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        cmd.Parameters.Add("@id_sistema", _Id_Sistema)
        cmd.Parameters.Add("@Bandera", _bandera)

        Dim da As SqlDataAdapter
        Dim dt As New DataTable("clsempleados")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(2).ColumnName
            cbo.ValueMember = dt.Columns(1).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return ex
        End Try

        cmd.Dispose()
        cn.Close()
    End Function
End Class

