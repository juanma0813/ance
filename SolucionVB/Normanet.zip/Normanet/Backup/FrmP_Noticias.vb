Imports System.IO
Public Class FrmP_Noticias

    Inherits System.Windows.Forms.Form
    Private ObjNoticias As New ClsNoticias.P_Noticias(0, gUsuario, gPasswordSql)
    Private ObjCategorias As New ClsCategoria_Noticias.C_Categorias(0, gUsuario, gPasswordSql)
    Private objConexion As New clsConexionArchivo.clsConexionArchivo
    'Private objUsuario As New clsUsuarios.clsUsuarios(0, "", "")
    Dim sEtapa As String
    Dim Id_Noticia As String
    Dim IBandera As Boolean
    Private dtNoticias As DataTable
    Private dtCategorias As DataTable
    Private dtUltimo As DataTable
    Dim Ruta As String

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtFecha As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txttitulo As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents txtNoticia As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents CboId_Noticia As System.Windows.Forms.ComboBox
    Friend WithEvents cboCategoria As System.Windows.Forms.ComboBox
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtfuente As System.Windows.Forms.TextBox
    Friend WithEvents txtcategoria As System.Windows.Forms.TextBox
    Friend WithEvents Dtfecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtdocumento As System.Windows.Forms.TextBox
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents txtid_noticia As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmP_Noticias))
        Me.Label1 = New System.Windows.Forms.Label
        Me.TxtFecha = New System.Windows.Forms.TextBox
        Me.Dtfecha = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txttitulo = New System.Windows.Forms.TextBox
        Me.txtfuente = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtNoticia = New System.Windows.Forms.TextBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.txtcategoria = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtdocumento = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.CboId_Noticia = New System.Windows.Forms.ComboBox
        Me.cboCategoria = New System.Windows.Forms.ComboBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtid_noticia = New System.Windows.Forms.TextBox
        Me.lblStatus = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha"
        '
        'TxtFecha
        '
        Me.TxtFecha.Location = New System.Drawing.Point(88, 40)
        Me.TxtFecha.Name = "TxtFecha"
        Me.TxtFecha.ReadOnly = True
        Me.TxtFecha.Size = New System.Drawing.Size(80, 20)
        Me.TxtFecha.TabIndex = 1
        Me.TxtFecha.Text = ""
        '
        'Dtfecha
        '
        Me.Dtfecha.CustomFormat = "dd/mm/yyyy"
        Me.Dtfecha.Location = New System.Drawing.Point(88, 40)
        Me.Dtfecha.Name = "Dtfecha"
        Me.Dtfecha.Size = New System.Drawing.Size(96, 20)
        Me.Dtfecha.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 23)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "T�tulo"
        '
        'Txttitulo
        '
        Me.Txttitulo.Location = New System.Drawing.Point(88, 72)
        Me.Txttitulo.Name = "Txttitulo"
        Me.Txttitulo.Size = New System.Drawing.Size(376, 20)
        Me.Txttitulo.TabIndex = 4
        Me.Txttitulo.Text = ""
        '
        'txtfuente
        '
        Me.txtfuente.Location = New System.Drawing.Point(88, 104)
        Me.txtfuente.Name = "txtfuente"
        Me.txtfuente.Size = New System.Drawing.Size(376, 20)
        Me.txtfuente.TabIndex = 6
        Me.txtfuente.Text = ""
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 23)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Fuente"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(16, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 23)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Noticia"
        '
        'txtNoticia
        '
        Me.txtNoticia.Location = New System.Drawing.Point(88, 136)
        Me.txtNoticia.Name = "txtNoticia"
        Me.txtNoticia.Size = New System.Drawing.Size(376, 20)
        Me.txtNoticia.TabIndex = 8
        Me.txtNoticia.Text = ""
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 240)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(488, 62)
        Me.tlbBotonera.TabIndex = 9
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'OpenFileDialog1
        '
        '
        'txtcategoria
        '
        Me.txtcategoria.Location = New System.Drawing.Point(88, 168)
        Me.txtcategoria.Name = "txtcategoria"
        Me.txtcategoria.Size = New System.Drawing.Size(240, 20)
        Me.txtcategoria.TabIndex = 11
        Me.txtcategoria.Text = ""
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(16, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 23)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Categor�a"
        '
        'txtdocumento
        '
        Me.txtdocumento.Location = New System.Drawing.Point(88, 200)
        Me.txtdocumento.Name = "txtdocumento"
        Me.txtdocumento.Size = New System.Drawing.Size(256, 20)
        Me.txtdocumento.TabIndex = 13
        Me.txtdocumento.Text = ""
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(16, 200)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 23)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Docto"
        '
        'Label7
        '
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Blue
        Me.Label7.Location = New System.Drawing.Point(352, 208)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 16)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Adjuntar Docto"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(16, 8)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 23)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Id Noticia"
        '
        'CboId_Noticia
        '
        Me.CboId_Noticia.Location = New System.Drawing.Point(88, 8)
        Me.CboId_Noticia.Name = "CboId_Noticia"
        Me.CboId_Noticia.Size = New System.Drawing.Size(96, 22)
        Me.CboId_Noticia.TabIndex = 16
        '
        'cboCategoria
        '
        Me.cboCategoria.Location = New System.Drawing.Point(88, 168)
        Me.cboCategoria.Name = "cboCategoria"
        Me.cboCategoria.Size = New System.Drawing.Size(256, 21)
        Me.cboCategoria.TabIndex = 17
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblStatus)
        Me.GroupBox1.Controls.Add(Me.txtid_noticia)
        Me.GroupBox1.Controls.Add(Me.CboId_Noticia)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(480, 240)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        '
        'txtid_noticia
        '
        Me.txtid_noticia.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtid_noticia.Location = New System.Drawing.Point(88, 8)
        Me.txtid_noticia.Name = "txtid_noticia"
        Me.txtid_noticia.Size = New System.Drawing.Size(80, 20)
        Me.txtid_noticia.TabIndex = 17
        Me.txtid_noticia.Text = ""
        Me.txtid_noticia.Visible = False
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(208, 24)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 22)
        Me.lblStatus.TabIndex = 18
        '
        'FrmP_Noticias
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 302)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtdocumento)
        Me.Controls.Add(Me.txtcategoria)
        Me.Controls.Add(Me.txtNoticia)
        Me.Controls.Add(Me.txtfuente)
        Me.Controls.Add(Me.Txttitulo)
        Me.Controls.Add(Me.TxtFecha)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Dtfecha)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboCategoria)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FrmP_Noticias"
        Me.Text = "Noticias"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ToolBar1_ButtonClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                'dtNoticias.Clear()
                sEtapa = "Agregar"
                Call Habilita(sEtapa)
                Call Carga_Combos()
            Case 1 'Editar
                sEtapa = "Editar"
                Call Habilita(sEtapa)
                Call Carga_Combos()
            Case 2 'Deshacer
                sEtapa = "Nulo"
                Call Habilita(sEtapa)
                Call Limpia_Campos(Txttitulo, txtNoticia, txtfuente, txtcategoria, txtdocumento, TxtFecha)
                Label7.Enabled = False
                Llena_Campos()
            Case 3 'Salvar
                If txtdocumento.Text <> "" And OpenFileDialog1.FileName <> "" Then
                    MsgBox("Desea adjuntar ese Archivo para la Noticia?", MsgBoxStyle.OKCancel)
                    If MsgBoxResult.OK Then
                        Dim clsCopia As New ClsCopiaArchivos.ClsCopiaArchivos
                        Dim objiniarray As New clsIniarray.ClsIniArray
                        Dim path As String
                        Dim archivo
                        path = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")))
                        path = path + ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Noticias")))
                        If Not Directory.Exists(path) Then
                            Directory.CreateDirectory(path)
                        End If
                        archivo = path + txtdocumento.Text
                        clsCopia.CopiaArchivos(Ruta, archivo, path)
                    End If
                    Label7.Enabled = True
                End If

                If sEtapa = "Editar" Then
                    Call Actualizar()
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    IBandera = True
                Else
                    Call Insertar()
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    IBandera = True
                End If
            Case 4
                    MsgBox("Esta seguro de Borrar esta Noticia?", MsgBoxStyle.OKCancel, "Atenci�n")
                    If MsgBoxResult.OK Then
                        Call Borrar()
                    End If
            Case 5
                    Me.Dispose()
        End Select
    End Sub
    Private Sub Carga_Combos()

        ObjCategorias.Bandera = 1
        ObjCategorias.ListaCombo(cboCategoria)
        'cboCategoria.DataSource = dtCategorias
        'cboCategoria.DisplayMember = dtCategorias.Columns(1).ColumnName
        'cboCategoria.ValueMember = dtCategorias.Columns(0).ColumnName
    End Sub
    Private Sub Insertar()
        Dim Ultimo As Integer
        ObjNoticias.maxi()
        ObjNoticias.Actualizar("1", ObjNoticias.Ultimo, TxtFecha.Text, Txttitulo.Text, txtfuente.Text, txtNoticia.Text, cboCategoria.SelectedValue, txtdocumento.Text, False)
        'dtNoticias.Clear()
        ObjNoticias.ListaCombo(CboId_Noticia)
    End Sub
    Private Sub Actualizar()
        ObjNoticias.Actualizar("3", CboId_Noticia.SelectedValue, TxtFecha.Text, Txttitulo.Text, txtfuente.Text, txtNoticia.Text, cboCategoria.SelectedValue, txtdocumento.Text, False)
        ObjNoticias.ListaCombo(CboId_Noticia)
    End Sub
    Private Sub Borrar()
        ObjNoticias.Borrar("2", CboId_Noticia.SelectedValue)
        ObjNoticias.ListaCombo(CboId_Noticia)
    End Sub
    Private Sub Txttitulo_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txttitulo.Validating
        If sEtapa = "Agregar" Then
            If Txttitulo.Text = "" Then
                MsgBox("El campo T�tulo es requerido")
                Txttitulo.Focus()
            End If
        End If
    End Sub
    Private Sub FrmP_Noticias_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sEtapa = "Nulo"
        Call Habilita(sEtapa)
        IBandera = False
        ObjNoticias.ListaCombo(CboId_Noticia)
        Carga_Combos()
        IBandera = True
    End Sub
    Private Sub CboId_Noticia_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboId_Noticia.SelectedIndexChanged
        'If IBandera = True Then
        Call Llena_Campos()
        'End If
    End Sub
    Private Sub Llena_Campos()
        ObjNoticias.Id_Noticia = CboId_Noticia.SelectedValue
        ObjNoticias.Buscar()
        Txttitulo.Text = ObjNoticias.Titulo
        txtNoticia.Text = ObjNoticias.Noticia
        txtfuente.Text = ObjNoticias.Fuente
        TxtFecha.Text = ObjNoticias.Fecha
        ObjNoticias.Categor�a(ObjNoticias.Id_Categoria)
        txtcategoria.Text = ObjNoticias.Categoria_Descripcion
        If ObjNoticias.Inactivo = True Then
            lblStatus.Text = "Inactivo"
        Else
            lblStatus.Text = "Activo"
        End If
        txtdocumento.Text = ObjNoticias.Documento
        If txtdocumento.Text <> "" Then
            Label7.Enabled = False
        Else
            Label7.Enabled = True
        End If
        IBandera = False
    End Sub
    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"
                Call Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Muestra(CboId_Noticia)
                Call Oculta(txtid_noticia)
                Call Activos(CboId_Noticia)
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
                Call Inactivos(Txttitulo, txtNoticia, txtfuente, Dtfecha, txtcategoria, txtdocumento)
            Case "Agregar"
                Call Activos(Label7, tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(Txttitulo, txtNoticia, txtfuente, Dtfecha, txtdocumento, Dtfecha, txtcategoria)
                Call Inactivos(txtid_noticia)
                Call Oculta(CboId_Noticia)
                Call Muestra(txtid_noticia)
                Call Limpia_Campos(Txttitulo, txtNoticia, txtfuente, txtcategoria, txtdocumento, TxtFecha)
                txtid_noticia.Text = "Por Asignar...."
            Case "Editar"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))
                Call Activos(Txttitulo, txtNoticia, txtfuente, Dtfecha)
                Call Inactivos(txtcategoria, CboId_Noticia, txtid_noticia)
                Call Muestra(txtcategoria)
        End Select
    End Sub
    Private Sub CboId_Noticia_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboId_Noticia.Click
        If sEtapa <> "Agregar" Then
            IBandera = True
        Else
            IBandera = False
        End If
    End Sub

    Private Sub Dtfecha_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dtfecha.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            TxtFecha.Visible = True
            TxtFecha.Text = Format(Dtfecha.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub cboCategoria_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategoria.SelectedIndexChanged
        'If sEtapa = "Agregar" Or sEtapa = "Editar" Then
        txtcategoria.Text = cboCategoria.Text
        'End If
    End Sub
    Private Sub txtfuente_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtfuente.Validating
        If sEtapa = "Agregar" Then
            If txtfuente.Text = "" Then
                MsgBox("El campo Fuente es requerido")
                txtfuente.Focus()
            End If
        End If
    End Sub
    Private Sub txtNoticia_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtNoticia.Validating
        If sEtapa = "Agregar" Then
            If txtNoticia.Text = "" Then
                MsgBox("El campo Noticia es requerido")
                txtNoticia.Focus()
            End If
        End If
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

        Dim archivo As String
        Dim IIndice As Integer
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "PDf files (*.pdf)|*.txt|All files (*.*)|*.*"
        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.ShowDialog()
        Ruta = OpenFileDialog1.FileName
        If OpenFileDialog1.FileName = "" Then Exit Sub
        For IIndice = Len(OpenFileDialog1.FileName) To 1 Step -1
            If Mid(OpenFileDialog1.FileName, IIndice, 1) = "\" Then
                archivo = Mid(OpenFileDialog1.FileName, IIndice)
                IIndice = 1
            End If
        Next IIndice

        txtdocumento.Text = Mid(archivo, 2, Len(archivo))
    End Sub
    Private Sub txtcategoria_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcategoria.TextChanged

    End Sub

    Private Sub txtcategoria_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtcategoria.Validating
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            If txtcategoria.Text = "" Then
                MsgBox("El campo Categor�a es requerido")

            End If
        End If
    End Sub

    Private Sub CboId_Noticia_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles CboId_Noticia.Validating

    End Sub

    Private Sub txtid_noticia_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtid_noticia.TextChanged

    End Sub

    Private Sub Dtfecha_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Dtfecha.Validating
        'If sEtapa = "Agregar" Then
        '    If CboId_Noticia.SelectedValue = "" Then
        '        MsgBox("La fecha es Requerida")
        '    End If
        'End If
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub Txttitulo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txttitulo.TextChanged

    End Sub
End Class
