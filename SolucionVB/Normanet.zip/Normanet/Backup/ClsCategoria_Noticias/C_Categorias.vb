
'*************************************************************************************
'Clase C_Categorias Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 02/08/2006 04:10:13 p.m.
'*************************************************************************************

Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class C_Categorias

     '''''''Declaracion de Variables Privadas
     Private dsC_Categorias AS New DataSet
     Private _Id_Categoria as System.Int32
    Private _Descripcion As System.String
    Private _Bandera As System.Int32
    Private _Inactivo As System.Int32
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    'Private objconexion As New clsConexion.cIsConexion
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Categoria() As System.Int32
          Get
              Return _Id_Categoria
          End Get
          Set(Value as System.Int32)
              _Id_Categoria = Value
          End Set
     End Property

     Public Property Descripcion() As System.String
          Get
              Return _Descripcion
          End Get
          Set(Value as System.String)
              _Descripcion = Value
          End Set
     End Property


    Public Property Inactivo()
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value)
            Inactivo = Value
        End Set
    End Property

    Public Property Bandera()
        Get
            Return _Bandera
        End Get
        Set(ByVal Value)
            _Bandera = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""
    Public Sub New(ByVal Identif As String, ByVal Usuario As String, ByVal Password As String)
        'Dim Servidor As String
        'Dim Base As String

        'sSql = objconexion.ConexionAnce(Application.StartupPath + "\principal.ini", Identif, Usuario, Password)
        'cn.ConnectionString = sSql

        'Servidor = objconexion.Server
        'Base = objconexion.Base

        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD

    End Sub

    Public Sub ListaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Categorias")
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Categorias_Buscar"
        cmd.Connection = cn
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.Parameters.Add("@Bandera", _Bandera)
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar() As C_Categorias
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Categorias_Buscar "
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@ID_Categoria", _Id_Categoria)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Categoria = dr("ID_Categorias")
                _Descripcion = dr("Descripcion")
                _Inactivo = dr("Inactivo")
            Else
                _Id_Categoria = ""
                _Descripcion = ""
                _Inactivo = ""
            End If
            cn.Close()
        Catch ex As Exception
        End Try
    End Function


    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        ''' sSql = "UPDATE C_Categorias SET Id_Categoria = @Id_Categoria, Descripcion = @Descripcion, Where ( = @)"
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_Categorias"
            .Parameters.Add("@ID_Categoria", _Id_Categoria)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", _Bandera)
        End With

        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close() 'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try


    End Function


    Public Function Insertar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_categorias"
            '  .Parameters.Add("@ID_categoria", _Id_Categoria)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function borrar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_C_Categorias"
            .Parameters.Add("@Id_Categoria", Id_Categoria)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        '
    End Function
End Class
