
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Prog_Trab Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 07/09/2006 01:12:25 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms


Public Class P_Prog_Trab

     '''''''Declaracion de Variables Privadas
    Private dsP_Prog_Trab As New DataSet
     Private _Id_Plan as System.String
     Private _Id_Tema as System.Int32
     Private _Clasificacion as System.String
     Private _Tipo_Pro as System.String
    Private _Tipo_Tema As Integer
     Private _Titulo as System.String
     Private _Obj as System.String
     Private _Justificacion as System.String
    Private _F_Inicio As System.String
    Private _F_Fin As System.String
     Private _Revision as System.String
     Private _ID_Comite as System.String
     Private _ID_CT as System.String
     Private _ID_SC as System.String
     Private _ID_Grupo as System.String
    Private _ID_etapa As System.Int32
    Private _Basada As Boolean
    Private _Norma As String
    Private _Responsable As System.String
    Private _Existe As Boolean
    Private _Basada_Norma As Boolean
    Private _Id_Norma As String
    Private _Bandera As Integer
    Private _Error As String
    Private _Armonizada As Boolean
    Private _Identificador As String
    Private sSql As String
    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _tipo As String
    Private _sReferencia As String
    Private _band As Boolean
    Private _Justi_Armonizada As String


    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Plan() As System.String
          Get
              Return _Id_Plan
          End Get
          Set(Value as System.String)
              _Id_Plan = Value
          End Set
     End Property

     Public Property Id_Tema() As System.Int32
          Get
              Return _Id_Tema
          End Get
          Set(Value as System.Int32)
              _Id_Tema = Value
          End Set
     End Property

     Public Property Clasificacion() As System.String
          Get
              Return _Clasificacion
          End Get
          Set(Value as System.String)
              _Clasificacion = Value
          End Set
     End Property

     Public Property Tipo_Pro() As System.String
          Get
              Return _Tipo_Pro
          End Get
          Set(Value as System.String)
              _Tipo_Pro = Value
          End Set
     End Property

    Public Property Tipo_Tema() As Integer
        Get
            Return _Tipo_Tema
        End Get
        Set(ByVal Value As Integer)
            _Tipo_Tema = Value
        End Set
    End Property

    Public Property Titulo() As System.String
        Get
            Return _Titulo
        End Get
        Set(ByVal Value As System.String)
            _Titulo = Value
        End Set
    End Property

    Public Property Obj() As System.String
        Get
            Return _Obj
        End Get
        Set(ByVal Value As System.String)
            _Obj = Value
        End Set
    End Property

    Public Property Justificacion() As System.String
        Get
            Return _Justificacion
        End Get
        Set(ByVal Value As System.String)
            _Justificacion = Value
        End Set
    End Property

    Public Property F_Inicio() As System.String
        Get
            Return _F_Inicio
        End Get
        Set(ByVal Value As System.String)
            _F_Inicio = Value
        End Set
    End Property

    Public Property F_Fin() As System.String
        Get
            Return _F_Fin
        End Get
        Set(ByVal Value As System.String)
            _F_Fin = Value
        End Set
    End Property

    Public Property Revision() As System.String
        Get
            Return _Revision
        End Get
        Set(ByVal Value As System.String)
            _Revision = Value
        End Set
    End Property

    Public Property ID_Comite() As System.String
        Get
            Return _ID_Comite
        End Get
        Set(ByVal Value As System.String)
            _ID_Comite = Value
        End Set
    End Property

    Public Property ID_CT() As System.String
        Get
            Return _ID_CT
        End Get
        Set(ByVal Value As System.String)
            _ID_CT = Value
        End Set
    End Property

    Public Property ID_SC() As System.String
        Get
            Return _ID_SC
        End Get
        Set(ByVal Value As System.String)
            _ID_SC = Value
        End Set
    End Property

    Public Property ID_Grupo() As System.String
        Get
            Return _ID_Grupo
        End Get
        Set(ByVal Value As System.String)
            _ID_Grupo = Value
        End Set
    End Property

    Public Property ID_etapa() As System.Int32
        Get
            Return _ID_etapa
        End Get
        Set(ByVal Value As System.Int32)
            _ID_etapa = Value
        End Set
    End Property

    Public Property Responsable() As System.String
        Get
            Return _Responsable
        End Get
        Set(ByVal Value As System.String)
            _Responsable = Value
        End Set
    End Property
    Public Property Band() As Boolean
        Get
            Return _band
        End Get
        Set(ByVal Value As Boolean)
            _band = Value
        End Set
    End Property

    Public Property Basada_Norma() As System.Boolean
        Get
            Return _Basada_Norma
        End Get
        Set(ByVal Value As System.Boolean)
            _Basada_Norma = Value
        End Set
    End Property
    Public Property Id_Norma() As System.String
        Get
            Return _Id_Norma
        End Get
        Set(ByVal Value As System.String)
            _Id_Norma = Value
        End Set
    End Property
    Public Property Existe() As System.Boolean
        Get
            Return _Existe
        End Get
        Set(ByVal Value As System.Boolean)
            _Existe = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property
    Public Property Basada() As Boolean
        Get
            Return _Basada
        End Get
        Set(ByVal Value As Boolean)
            _Basada = Value
        End Set
    End Property
    Public Property Norma() As String
        Get
            Return _Norma
        End Get
        Set(ByVal Value As String)
            _Norma = Value
        End Set
    End Property
    Public Property Identificador() As String
        Get
            Return _Identificador
        End Get
        Set(ByVal Value As String)
            _Identificador = Value
        End Set
    End Property

    Public Property Justi_Armonizada() As String
        Get
            Return _Justi_Armonizada
        End Get
        Set(ByVal Value As String)
            _Justi_Armonizada = Value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property
    Public Property Tipo() As String
        Get
            Return _tipo
        End Get
        Set(ByVal Value As String)
            _tipo = Value
        End Set
    End Property

    Public Property Armonizada() As Boolean
        Get
            Return _Armonizada
        End Get
        Set(ByVal Value As Boolean)
            _Armonizada = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Prog_Trab")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sPlan As String, ByVal sTema As String) As P_Prog_Trab
        If cn.State = ConnectionState.Open Then cn.Close()

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_Programa_Trabajo_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Plan", sPlan)
        cmd.Parameters.Add("@Id_Tema", sTema)
        If _Bandera = 37 Then
            cmd.Parameters.Add("@bandera", _Bandera)
            _Bandera = Nothing
        Else
            If _Bandera = 38 Then
                cmd.Parameters.Add("@bandera", _Bandera)
                _Bandera = Nothing
            Else
                cmd.Parameters.Add("@bandera", 10)
            End If
        End If

        If _band = True Then
            cmd.Parameters.Add("@sReferencia", _sReferencia)
        End If
        cmd.Parameters.Add("@band", _band)

        If _tipo = "abandono" Then cmd.Parameters.Add("@Ordenar", "abandono")
        If _tipo = "traspaso" Then cmd.Parameters.Add("@Ordenar", "traspaso")
        If _tipo = "" Then cmd.Parameters.Add("@Ordenar", "")

        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Encontrado")
        'Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da = New Data.SqlClient.SqlDataAdapter(cmd)
        Try
            da.Fill(dt)
        Catch ex As Exception
            Dim ms
            ms = ex.Message
        End Try
        cn.Close()
        If dt.Rows.Count > 0 Then
            _Id_Plan = IIf(IsDBNull(dt.Rows(0).Item("Id_Plan")), "", dt.Rows(0).Item("Id_Plan"))
            _Id_Tema = IIf(IsDBNull(dt.Rows(0).Item("Id_Tema")), "", dt.Rows(0).Item("Id_Tema"))
            _Clasificacion = IIf(IsDBNull(dt.Rows(0).Item("Clasificacion")), "", dt.Rows(0).Item("Clasificacion"))
            _Tipo_Pro = IIf(IsDBNull(dt.Rows(0).Item("Tipo_Pro")), "", dt.Rows(0).Item("Tipo_Pro"))
            _Tipo_Tema = IIf(IsDBNull(dt.Rows(0).Item("Tipo_Tema")), "", dt.Rows(0).Item("Tipo_Tema"))
            _Titulo = IIf(IsDBNull(dt.Rows(0).Item("Titulo")), "", dt.Rows(0).Item("Titulo"))
            _Obj = IIf(IsDBNull(dt.Rows(0).Item("Obj")), "", dt.Rows(0).Item("Obj"))
            _Justificacion = IIf(IsDBNull(dt.Rows(0).Item("Justificacion")), "", dt.Rows(0).Item("Justificacion"))
            _F_Inicio = IIf(IsDBNull(dt.Rows(0).Item("F_Inicio")), Nothing, dt.Rows(0).Item("F_Inicio"))
            _F_Fin = dt.Rows(0).Item("F_Fin")
            _Revision = IIf(IsDBNull(dt.Rows(0).Item("Revision")), Nothing, dt.Rows(0).Item("Revision"))
            _ID_Comite = IIf(IsDBNull(dt.Rows(0).Item("ID_Comite")), Nothing, dt.Rows(0).Item("ID_Comite"))
            _ID_CT = IIf(IsDBNull(dt.Rows(0).Item("ID_CT")), Nothing, dt.Rows(0).Item("ID_CT"))
            _ID_SC = IIf(IsDBNull(dt.Rows(0).Item("ID_SC")), Nothing, dt.Rows(0).Item("ID_SC"))
            _ID_Grupo = IIf(IsDBNull(dt.Rows(0).Item("ID_Grupo")), Nothing, dt.Rows(0).Item("ID_Grupo"))
            _ID_etapa = IIf(IsDBNull(dt.Rows(0).Item("ID_etapa")), Nothing, dt.Rows(0).Item("ID_etapa"))
            _Basada_Norma = IIf(IsDBNull(dt.Rows(0).Item("basada_norma")), Nothing, dt.Rows(0).Item("basada_norma"))
            _Norma = IIf(IsDBNull(dt.Rows(0).Item("id_norma")), "", dt.Rows(0).Item("id_norma"))
            _Responsable = IIf(IsDBNull(dt.Rows(0).Item("responsable")), "", dt.Rows(0).Item("responsable"))
            _Ref_A�o = IIf(IsDBNull(dt.Rows(0).Item("ref_a�o")), Nothing, dt.Rows(0).Item("ref_a�o"))
            _Ref_Comite = IIf(IsDBNull(dt.Rows(0).Item("ref_comite")), Nothing, dt.Rows(0).Item("ref_comite"))
            _Ref_Consecutivo = IIf(IsDBNull(dt.Rows(0).Item("ref_consecutivo")), Nothing, dt.Rows(0).Item("ref_consecutivo"))
            _Ref_Regreso = IIf(IsDBNull(dt.Rows(0).Item("ref_regreso")), Nothing, dt.Rows(0).Item("ref_regreso"))
            _Ref_Traspaso = IIf(IsDBNull(dt.Rows(0).Item("ref_traspaso")), Nothing, dt.Rows(0).Item("ref_traspaso"))
            _Armonizada = IIf(IsDBNull(dt.Rows(0).Item("Armonizada")), False, dt.Rows(0).Item("Armonizada"))
            _Justi_Armonizada = IIf(IsDBNull(dt.Rows(0).Item("Justi_Armonizada")), "", dt.Rows(0).Item("Justi_Armonizada"))
            _Id_Norma = _Norma
            _Existe = True
        Else
            _Id_Plan = Nothing
            _Id_Tema = 0
            _Clasificacion = Nothing
            _Tipo_Pro = Nothing
            _Tipo_Tema = 0
            _Titulo = Nothing
            _Obj = Nothing
            _Justificacion = Nothing
            _F_Inicio = Nothing
            _F_Fin = Nothing
            _Revision = 0
            _ID_Comite = Nothing
            _ID_CT = Nothing
            _ID_SC = Nothing
            _ID_Grupo = Nothing
            _ID_etapa = 0
            _Responsable = Nothing
            _Existe = False
            _Basada = False
            _Norma = Nothing
            _Ref_A�o = Nothing
            _Ref_Comite = Nothing
            _Ref_Consecutivo = Nothing
            _Ref_Regreso = Nothing
            _Ref_Traspaso = Nothing
            _Justi_Armonizada = Nothing
        End If

    End Function
    '''''''''''''''''Genera una la lista de campos
    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_Programa_Trabajo_buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Encontrado")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt

        Catch ex As Exception
            _Error = "Error " & ex.Source & " - " & ex.Message
            Return Nothing
        End Try

    End Function

    Private Sub llena_parametros(ByVal command As SqlCommand)

        With command

            'llave de c_empleado completo
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Clasificacion", _Clasificacion)
            .Parameters.Add("@Tipo_Pro", _Tipo_Pro)
            .Parameters.Add("@Tipo_Tema", _Tipo_Tema)
            .Parameters.Add("@Titulo", _Titulo)
            .Parameters.Add("@Obj", _Obj)
            .Parameters.Add("@Justificacion", _Justificacion)
            If Not _F_Inicio Is Nothing Then .Parameters.Add("@F_Inicio", CDate(_F_Inicio))
            If Not _F_Inicio Is Nothing Then .Parameters.Add("@F_Fin", CDate(_F_Fin))
            .Parameters.Add("@Revision", _Revision)
            .Parameters.Add("@ID_Comite", _ID_Comite)
            .Parameters.Add("@ID_CT", _ID_CT)
            .Parameters.Add("@ID_SC", _ID_SC)
            .Parameters.Add("@ID_Grupo", _ID_Grupo)
            .Parameters.Add("@ID_etapa", _ID_etapa)
            .Parameters.Add("@Responsable", _Responsable)

            .Parameters.Add("@Bandera", _Bandera)

        End With

    End Sub


    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Programa_Trabajo"
        cmd.Parameters.Add("@Bandera", 3)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal Clasificacion As String, ByVal Tipo_Pro As String, ByVal Tipo_Tema As String, ByVal Titulo As String, ByVal Obj As String, ByVal Justificacion As String, ByVal F_Inicio As String, ByVal F_Fin As String, ByVal Revision As String, ByVal ID_Comite As String, ByVal ID_CT As String, ByVal ID_SC As String, ByVal ID_Grupo As String, ByVal ID_etapa As Integer, ByVal Responsable As String, ByVal Basada As Boolean, ByVal id_Norma As String) As String

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Programa_Trabajo"
        cmd.Parameters.Add("@Bandera", 2)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@Clasificacion", Clasificacion)
        cmd.Parameters.Add("@Tipo_Pro", Tipo_Pro)
        cmd.Parameters.Add("@Tipo_Tema", Tipo_Tema)
        cmd.Parameters.Add("@Titulo", Titulo)
        cmd.Parameters.Add("@Obj", Obj)
        cmd.Parameters.Add("@Justificacion", Justificacion)
        cmd.Parameters.Add("@F_Inicio", F_Inicio)
        cmd.Parameters.Add("@F_Fin", F_Fin)
        cmd.Parameters.Add("@Revision", Revision)
        cmd.Parameters.Add("@ID_Comite", ID_Comite)
        cmd.Parameters.Add("@ID_CT", ID_CT)
        cmd.Parameters.Add("@ID_SC", ID_SC)
        cmd.Parameters.Add("@ID_Grupo", ID_Grupo)
        cmd.Parameters.Add("@ID_etapa", ID_etapa)
        cmd.Parameters.Add("@Basada_Norma", Basada)
        cmd.Parameters.Add("@Id_Norma", id_Norma)
        cmd.Parameters.Add("@Responsable", Responsable)
        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        cmd.Parameters.Add("@armonizada", _Armonizada)
        cmd.Parameters.Add("@justi_armonizada", _Justi_Armonizada)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function Cambia_Proceso(ByVal stema As String, ByVal splan As String, ByVal sref As String)
        Dim cmd As New SqlCommand
        Dim sSQL As String
        sSQL = "update P_Prog_Trab set Tipo_Pro='2' where id_tema='" & stema & "' and id_plan='" & splan & "' and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & sref & "'"
        cmd.Connection = cn
        cmd.CommandText = sSQL
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try



    End Function
    Public Function Consulta_Temas(ByVal Sentencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Q_temas"
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Identificador", Sentencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
            Dim da As SqlDataAdapter

            Dim dt As New DataTable("ClsQTemas")


            da = New Data.SqlClient.SqlDataAdapter(cmd)

            da.Fill(dt)

            Return dt
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function Busca_Referencia(ByVal Splan As String, ByVal sComite As String, ByVal bandera As Integer, Optional ByVal anio As String = "")
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Referencias"
        cmd.Parameters.Add("@Bandera", bandera)
        cmd.Parameters.Add("@Plan", Splan)
        cmd.Parameters.Add("@Comite", sComite)
        cmd.Parameters.Add("@anio", anio)
        If cn.State = 1 Then cn.Close()
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Encontrado")
        'Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da = New Data.SqlClient.SqlDataAdapter(cmd)
        Try
            da.Fill(dt)
            cn.Close()
            If bandera = 1 Then 'Busca el a�o de primera publicaci�n
                If dt.Rows.Count > 0 Then
                    _Ref_A�o = DatePart(DateInterval.Year, dt.Rows(0).Item("F_PrimPub"))
                End If
            End If
            If bandera = 2 Then 'busca el ultimo consecutivo
                If dt.Rows.Count > 0 Then
                    _Ref_Consecutivo = dt.Rows(0).Item("Ref_Consecutivo") + 1
                Else
                    _Ref_Consecutivo = "1"
                End If
            End If

        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function

    Public Function Insertar(ByVal ref_a�o As String, ByVal ref_comite As String, ByVal ref_consecutivo As String, ByVal ref_regreso As String, ByVal ref_traspaso As String, ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal Clasificacion As String, ByVal Tipo_Pro As String, ByVal Tipo_Tema As String, ByVal Titulo As String, ByVal Obj As String, ByVal Justificacion As String, ByVal F_Inicio As String, ByVal F_Fin As String, ByVal Revision As String, ByVal ID_Comite As String, ByVal ID_CT As String, ByVal ID_SC As String, ByVal ID_Grupo As String, ByVal ID_etapa As Integer, ByVal Responsable As String, ByVal Basada As Boolean, ByVal id_Norma As String, ByVal armonizada As Boolean, ByVal justi_armonizada As String, ByVal normaarm As String) As String
        Dim cmd As New SqlCommand


        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Programa_Trabajo"
        cmd.Parameters.Add("@Bandera", 1)
        cmd.Parameters.Add("@ref_a�o", ref_a�o)
        cmd.Parameters.Add("@ref_comite", ref_comite)
        ref_consecutivo = CInt(ref_consecutivo)
        If ref_consecutivo < 10 Then ref_consecutivo = "00" + CStr(ref_consecutivo)
        If ref_consecutivo > 9 And ref_consecutivo < 100 Then ref_consecutivo = "0" + CStr(ref_consecutivo)
        cmd.Parameters.Add("@ref_consecutivo", ref_consecutivo)
        cmd.Parameters.Add("@ref_regreso", ref_regreso)
        cmd.Parameters.Add("@ref_traspaso", ref_traspaso)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@Clasificacion", Clasificacion)
        cmd.Parameters.Add("@Tipo_Pro", Tipo_Pro)
        cmd.Parameters.Add("@Tipo_Tema", Tipo_Tema)
        cmd.Parameters.Add("@Titulo", Titulo)
        cmd.Parameters.Add("@Obj", Obj)
        cmd.Parameters.Add("@Justificacion", Justificacion)
        cmd.Parameters.Add("@F_Inicio", F_Inicio)
        cmd.Parameters.Add("@F_Fin", F_Fin)
        cmd.Parameters.Add("@Revision", Revision)
        cmd.Parameters.Add("@ID_Comite", ID_Comite)
        cmd.Parameters.Add("@ID_CT", ID_CT)
        cmd.Parameters.Add("@ID_SC", ID_SC)
        cmd.Parameters.Add("@ID_Grupo", ID_Grupo)
        cmd.Parameters.Add("@ID_etapa", _ID_etapa)
        cmd.Parameters.Add("@Responsable", Responsable)
        cmd.Parameters.Add("@Basada_Norma", Basada)
        If normaarm <> "" Then
            cmd.Parameters.Add("@Id_Norma", normaarm)
        Else
            cmd.Parameters.Add("@Id_Norma", id_Norma)
        End If

        cmd.Parameters.Add("@Justi_armonizada", justi_armonizada)
        cmd.Parameters.Add("@armonizada", armonizada)



        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Sub ActualizaRefAnterior(Optional ByVal etapaAbandono As Integer = 0)
        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "sp_Programa_Trabajo"
            .CommandType = CommandType.StoredProcedure
            If etapaAbandono = 11 Then
                .Parameters.Add("@bandera", 4)
            Else
                .Parameters.Add("@bandera", 5)
            End If
            '.Parameters.Add("@ref_a�o", _Ref_A�o)
            '.Parameters.Add("@ref_comite", _Ref_Comite)
            '.Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
            '.Parameters.Add("@ref_regreso", (_Ref_Regreso - 1))
            .Parameters.Add("@sReferencia", _sReferencia)
            If cn.State = 1 Then cn.Close()
            cn.Open()
            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Dim ms
                ms = ex.Message
            End Try
        End With
    End Sub
    Public Sub BuscaAbandono()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        If cn.State = 1 Then cn.Close()
        cn.Open()
        With cmd
            .Connection = cn
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_Programa_Trabajo"
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@sReferencia", _sReferencia)
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Existe = True
            Else
                _Existe = False
            End If
        End With
    End Sub
    Public Sub traspasaPrograma(ByVal plan As String, ByVal tema As Integer, ByVal tipo_tema As Integer, ByVal f_inicio As String, ByVal f_fin As String)
        _Id_Plan = plan
        _Id_Tema = tema
        _F_Fin = f_fin
        _F_Inicio = f_inicio
        _Bandera = 7
        _Tipo_Tema = tipo_tema
        _Ref_Traspaso = _Ref_Traspaso + 1
        InsertaTodo()

    End Sub
    Public Sub InsertaTodo()
        Dim cmd As New SqlCommand

        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Programa_Trabajo"
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", Format(CInt(_Ref_Consecutivo), "000"))
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Clasificacion", _Clasificacion)
        cmd.Parameters.Add("@Tipo_Pro", _Tipo_Pro)
        cmd.Parameters.Add("@Tipo_Tema", _Tipo_Tema)
        cmd.Parameters.Add("@Titulo", _Titulo)
        cmd.Parameters.Add("@Obj", _Obj)
        cmd.Parameters.Add("@Justificacion", _Justificacion)
        cmd.Parameters.Add("@F_Inicio", _F_Inicio)
        cmd.Parameters.Add("@F_Fin", _F_Fin)
        cmd.Parameters.Add("@Revision", _Revision)
        cmd.Parameters.Add("@ID_Comite", _ID_Comite)
        cmd.Parameters.Add("@ID_CT", _ID_CT)
        cmd.Parameters.Add("@ID_SC", _ID_SC)
        cmd.Parameters.Add("@ID_Grupo", _ID_Grupo)
        cmd.Parameters.Add("@ID_etapa", _ID_etapa)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@Basada_Norma", _Basada_Norma)
        cmd.Parameters.Add("@Id_Norma", _Id_Norma)
        cmd.Parameters.Add("@Justi_armonizada", _Justi_Armonizada)
        cmd.Parameters.Add("@armonizada", _Armonizada)
        cmd.Parameters.Add("@sreferencia", _sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
