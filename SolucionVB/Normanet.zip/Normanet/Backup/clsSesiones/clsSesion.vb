Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration


Namespace Maple

    Public Class clsSesion

#Region "Propiedades de la clase"
        REM Variables de Propiedad
        Private _Id_Sesion As Integer
        Private _Id_Comite As String
        Private _Id_CT As String
        Private _Id_SC As String
        Private _Id_Grupo As String
        Private _Fecha As String
        Private _HoraI As String
        Private _HoraT As String
        Private _Asunto As String
        Private _Lugar As String
        Private _Responsable As String
        Private _Notas As String
        Private _Status As Integer
        Private _No_Sol_Sala As Integer
        Private _Pertenece As String
        Private _Bandera As String
        Private _respRetorno(1) As String
        Private cn As SqlConnection


        REM Propiedades de la Entidad
        Public Property Id_Sesion() As Integer
            Get
                Return _Id_Sesion
            End Get
            Set(ByVal Value As Integer)
                _Id_Sesion = Value
            End Set
        End Property

        Public Property Id_Comite() As String
            Get
                Return _Id_Comite
            End Get
            Set(ByVal Value As String)
                _Id_Comite = Value
            End Set
        End Property

        Public Property Pertenece() As String
            Get
                Return _Pertenece
            End Get
            Set(ByVal Value As String)
                _Pertenece = Value
            End Set
        End Property

        Public Property Id_CT() As String
            Get
                Return _Id_CT
            End Get
            Set(ByVal Value As String)
                _Id_CT = Value
            End Set
        End Property

        Public Property Id_SC() As String
            Get
                Return _Id_SC
            End Get
            Set(ByVal Value As String)
                _Id_SC = Value
            End Set
        End Property

        Public Property Id_Grupo() As String
            Get
                Return _Id_Grupo
            End Get
            Set(ByVal Value As String)
                _Id_Grupo = Value
            End Set
        End Property

        Public Property Fecha() As String
            Get
                Return _Fecha
            End Get
            Set(ByVal Value As String)
                _Fecha = Value
            End Set
        End Property

        Public Property HoraI() As String
            Get
                Return _HoraI
            End Get
            Set(ByVal Value As String)
                _HoraI = Value
            End Set
        End Property

        Public Property HoraT() As String
            Get
                Return _HoraT
            End Get
            Set(ByVal Value As String)
                _HoraT = Value
            End Set
        End Property

        Public Property Asunto() As String
            Get
                Return _Asunto
            End Get
            Set(ByVal Value As String)
                _Asunto = Value
            End Set
        End Property

        Public Property Lugar() As String
            Get
                Return _Lugar
            End Get
            Set(ByVal Value As String)
                _Lugar = Value
            End Set
        End Property

        Public Property Responsable() As String
            Get
                Return _Responsable
            End Get
            Set(ByVal Value As String)
                _Responsable = Value
            End Set
        End Property

        Public Property Notas() As String
            Get
                Return _Notas
            End Get
            Set(ByVal Value As String)
                _Notas = Value
            End Set
        End Property

        Public Property Status() As Integer
            Get
                Return _Status
            End Get
            Set(ByVal Value As Integer)
                _Status = Value
            End Set
        End Property

        Public Property No_Sol_Sala() As Integer
            Get
                Return _No_Sol_Sala
            End Get
            Set(ByVal Value As Integer)
                _No_Sol_Sala = Value
            End Set
        End Property

        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Bandera() As String
            Get
                Return _Bandera
            End Get
            Set(ByVal Value As String)
                _Bandera = Value
            End Set
        End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 0 contiene el error en caso de fallar :: la posicion 1 Contiene un (1 o 0), '1' indica que el metodo fallo, y '0' indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property


#End Region
#Region "Metodos de la Clase"
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance").ToString)
        End Sub
        REM Funcion que Elimina datos
        ''' <summary>
        '''Metodo para eliminar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Eliminar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "pawSesiones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Comite", _Id_Comite)
                cmd.Parameters.Add("@Id_CT", _Id_CT)
                cmd.Parameters.Add("@Id_SC", _Id_SC)
                cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
                cmd.Parameters.Add("@Fecha", _Fecha)
                cmd.Parameters.Add("@HoraI", _HoraI)
                cmd.Parameters.Add("@HoraT", _HoraT)
                cmd.Parameters.Add("@Asunto", _Asunto)
                cmd.Parameters.Add("@Lugar", _Lugar)
                cmd.Parameters.Add("@Responsable", _Responsable)
                cmd.Parameters.Add("@Notas", _Notas)
                cmd.Parameters.Add("@Status", _Status)
                cmd.Parameters.Add("@No_Sol_Sala", _No_Sol_Sala)
                cmd.Parameters.Add("@Pertenece", _Pertenece)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Actualizar datos
        ''' <summary>
        '''Metodo para Actualizar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Actualizar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "pawSesiones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Comite", _Id_Comite)
                cmd.Parameters.Add("@Id_CT", _Id_CT)
                cmd.Parameters.Add("@Id_SC", _Id_SC)
                cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
                cmd.Parameters.Add("@Fecha", _Fecha)
                cmd.Parameters.Add("@HoraI", _HoraI)
                cmd.Parameters.Add("@HoraT", _HoraT)
                cmd.Parameters.Add("@Asunto", _Asunto)
                cmd.Parameters.Add("@Lugar", _Lugar)
                cmd.Parameters.Add("@Responsable", _Responsable)
                cmd.Parameters.Add("@Notas", _Notas)
                cmd.Parameters.Add("@Status", _Status)
                cmd.Parameters.Add("@No_Sol_Sala", _No_Sol_Sala)
                cmd.Parameters.Add("@Pertenece", _Pertenece)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Insertar datos
        ''' <summary>
        ''' Metodo para insertar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Insertar()
            Dim Consecutivo As Integer = 0

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "pawSesiones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion).Direction = ParameterDirection.InputOutput
                cmd.Parameters.Add("@Id_Comite", _Id_Comite)
                cmd.Parameters.Add("@Id_CT", _Id_CT)
                cmd.Parameters.Add("@Id_SC", _Id_SC)
                cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
                cmd.Parameters.Add("@Fecha", _Fecha)
                cmd.Parameters.Add("@HoraI", _HoraI)
                cmd.Parameters.Add("@HoraT", _HoraT)
                cmd.Parameters.Add("@Asunto", _Asunto)
                cmd.Parameters.Add("@Lugar", _Lugar)
                cmd.Parameters.Add("@Responsable", _Responsable)
                cmd.Parameters.Add("@Notas", _Notas)
                cmd.Parameters.Add("@Status", _Status)
                cmd.Parameters.Add("@No_Sol_Sala", _No_Sol_Sala)
                cmd.Parameters.Add("@Pertenece", _Pertenece)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                _Id_Sesion = cmd.Parameters("@Id_Sesion").Value
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que LlenarDatos datos
        ''' <summary>
        '''llena todas las propiedades en base a una consulta de sql o Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub LlenarDatos()
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "pawSesiones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Comite", _Id_Comite)
                cmd.Parameters.Add("@Id_CT", _Id_CT)
                cmd.Parameters.Add("@Id_SC", _Id_SC)
                cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
                cmd.Parameters.Add("@Fecha", _Fecha)
                cmd.Parameters.Add("@HoraI", _HoraI)
                cmd.Parameters.Add("@HoraT", _HoraT)
                cmd.Parameters.Add("@Asunto", _Asunto)
                cmd.Parameters.Add("@Lugar", _Lugar)
                cmd.Parameters.Add("@Responsable", _Responsable)
                cmd.Parameters.Add("@Notas", _Notas)
                cmd.Parameters.Add("@Status", _Status)
                cmd.Parameters.Add("@No_Sol_Sala", _No_Sol_Sala)
                cmd.Parameters.Add("@Pertenece", _Pertenece)
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                da.Dispose()
                cmd.Dispose()

                If dt.Rows.Count > 0 Then
                    _Id_Sesion = IIf(IsDBNull(dt.Rows(0).Item("Id_Sesion")) = True, Nothing, dt.Rows(0).Item("Id_Sesion"))
                    _Id_Comite = IIf(IsDBNull(dt.Rows(0).Item("Id_Comite")) = True, Nothing, dt.Rows(0).Item("Id_Comite"))
                    _Id_CT = IIf(IsDBNull(dt.Rows(0).Item("Id_CT")) = True, Nothing, dt.Rows(0).Item("Id_CT"))
                    _Id_SC = IIf(IsDBNull(dt.Rows(0).Item("Id_SC")) = True, Nothing, dt.Rows(0).Item("Id_SC"))
                    _Id_Grupo = IIf(IsDBNull(dt.Rows(0).Item("Id_Grupo")) = True, Nothing, dt.Rows(0).Item("Id_Grupo"))
                    _Fecha = IIf(IsDBNull(dt.Rows(0).Item("Fecha")) = True, Nothing, dt.Rows(0).Item("Fecha"))
                    _HoraI = IIf(IsDBNull(dt.Rows(0).Item("HoraI")) = True, Nothing, dt.Rows(0).Item("HoraI"))
                    _HoraT = IIf(IsDBNull(dt.Rows(0).Item("HoraT")) = True, Nothing, dt.Rows(0).Item("HoraT"))
                    _Asunto = IIf(IsDBNull(dt.Rows(0).Item("Asunto")) = True, Nothing, dt.Rows(0).Item("Asunto"))
                    _Lugar = IIf(IsDBNull(dt.Rows(0).Item("Lugar")) = True, Nothing, dt.Rows(0).Item("Lugar"))
                    _Responsable = IIf(IsDBNull(dt.Rows(0).Item("Responsable")) = True, Nothing, dt.Rows(0).Item("Responsable"))
                    _Notas = IIf(IsDBNull(dt.Rows(0).Item("Notas")) = True, Nothing, dt.Rows(0).Item("Notas"))
                    _Status = IIf(IsDBNull(dt.Rows(0).Item("Status")) = True, Nothing, dt.Rows(0).Item("Status"))
                    _No_Sol_Sala = IIf(IsDBNull(dt.Rows(0).Item("No_Sol_Sala")) = True, Nothing, dt.Rows(0).Item("No_Sol_Sala"))
                Else
                    _Id_Sesion = Nothing
                    _Id_Comite = Nothing
                    _Id_CT = Nothing
                    _Id_SC = Nothing
                    _Id_Grupo = Nothing
                    _Fecha = Nothing
                    _HoraI = Nothing
                    _HoraT = Nothing
                    _Asunto = Nothing
                    _Lugar = Nothing
                    _Responsable = Nothing
                    _Notas = Nothing
                    _Status = Nothing
                    _No_Sol_Sala = Nothing
                End If
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = "0"

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "pawSesiones"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Id_Sesion", _Id_Sesion)
                cmd.Parameters.Add("@Id_Comite", _Id_Comite)
                cmd.Parameters.Add("@Id_CT", _Id_CT)
                cmd.Parameters.Add("@Id_SC", _Id_SC)
                cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
                cmd.Parameters.Add("@Fecha", _Fecha)
                cmd.Parameters.Add("@HoraI", _HoraI)
                cmd.Parameters.Add("@HoraT", _HoraT)
                cmd.Parameters.Add("@Asunto", _Asunto)
                cmd.Parameters.Add("@Lugar", _Lugar)
                cmd.Parameters.Add("@Responsable", _Responsable)
                cmd.Parameters.Add("@Notas", _Notas)
                cmd.Parameters.Add("@Status", _Status)
                cmd.Parameters.Add("@No_Sol_Sala", _No_Sol_Sala)
                cmd.Parameters.Add("@Pertenece", _Pertenece)
                cmd.Parameters.Add("@Bandera", _Bandera)
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                da.Dispose()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function


#End Region


    End Class

End Namespace
