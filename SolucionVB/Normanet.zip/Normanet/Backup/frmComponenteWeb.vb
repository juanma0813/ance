Imports System.Configuration
Public Class frmComponenteWeb
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents lstImagenes As System.Windows.Forms.ImageList
    Friend WithEvents tlbGrupos As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents webEdicion As AxSHDocVw.AxWebBrowser
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmComponenteWeb))
        Me.lstImagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbGrupos = New System.Windows.Forms.ToolBar
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.webEdicion = New AxSHDocVw.AxWebBrowser
        CType(Me.webEdicion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lstImagenes
        '
        Me.lstImagenes.ImageSize = New System.Drawing.Size(48, 48)
        Me.lstImagenes.ImageStream = CType(resources.GetObject("lstImagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.lstImagenes.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbGrupos
        '
        Me.tlbGrupos.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton4})
        Me.tlbGrupos.ButtonSize = New System.Drawing.Size(47, 46)
        Me.tlbGrupos.DropDownArrows = True
        Me.tlbGrupos.ImageList = Me.lstImagenes
        Me.tlbGrupos.Location = New System.Drawing.Point(0, 0)
        Me.tlbGrupos.Name = "tlbGrupos"
        Me.tlbGrupos.ShowToolTips = True
        Me.tlbGrupos.Size = New System.Drawing.Size(746, 60)
        Me.tlbGrupos.TabIndex = 6
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 17
        Me.ToolBarButton4.ToolTipText = "Terminar"
        '
        'webEdicion
        '
        Me.webEdicion.Enabled = True
        Me.webEdicion.Location = New System.Drawing.Point(8, 72)
        Me.webEdicion.OcxState = CType(resources.GetObject("webEdicion.OcxState"), System.Windows.Forms.AxHost.State)
        Me.webEdicion.Size = New System.Drawing.Size(728, 552)
        Me.webEdicion.TabIndex = 7
        '
        'frmComponenteWeb
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(746, 628)
        Me.Controls.Add(Me.webEdicion)
        Me.Controls.Add(Me.tlbGrupos)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmComponenteWeb"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Editor Web"
        Me.TopMost = True
        CType(Me.webEdicion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmComponenteWeb_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sPagina As String
        sPagina = ConfigurationSettings.AppSettings.Get("ControlWeb")
        webEdicion.Navigate(sPagina)
    End Sub

    Private Sub tlbGrupos_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbGrupos.ButtonClick
        Select Case tlbGrupos.Buttons.IndexOf(e.Button)
            Case 0
                Me.Close()
        End Select
    End Sub
End Class
