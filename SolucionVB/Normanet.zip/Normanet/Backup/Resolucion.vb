Imports System.IO
Imports System.Data.SqlClient
Imports System.Windows.Forms
Public Class Resolucion
    Inherits System.Windows.Forms.Form

#Region " Referencias instanciadas"

    Dim ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objconexion As New clsConexion.cIsConexion
    Dim cn As New SqlConnection
    Dim objComentarios As New clsComentarios.C_Comentarios("Principal", gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim iCaso As Integer
    Dim dvPNN As DataView
    Dim objComites As New clsComites.clsComites("Principal", gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private ObjProy As New ClsProy.P_Proy(0, gUsuario, gPasswordSql)
    Dim sTipoProceso As String
    Dim ruta As String
    Dim clsCopia As New ClsCopiaArchivos.ClsCopiaArchivos
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Dim nodo1 As New TreeNode
    Dim nodo As New TreeNode
    Dim nodo2 As New TreeNode
    Dim DtCom As DataTable
    Dim Com As DataRow
    Dim array_texto As Array
    Dim srefp As String
    Dim splan As String
    Dim stema As Integer
#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tvPNN As System.Windows.Forms.TreeView
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtkFecPublicacionConsulta As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtTitulo As System.Windows.Forms.TextBox
    Friend WithEvents txtFecLimiteAnalisisComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecLimiteComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecPublicacionConsulta As System.Windows.Forms.TextBox
    Friend WithEvents lblFecPublicacionConsulta As System.Windows.Forms.Label
    Friend WithEvents lblFecLimiteComentarios As System.Windows.Forms.Label
    Friend WithEvents lblFecLimiteAnalisisComentarios As System.Windows.Forms.Label
    Friend WithEvents lblTitulo As System.Windows.Forms.Label
    Friend WithEvents dtkFecLimiteComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkFecLimiteAnalisisComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents gpbDatosPersonales As System.Windows.Forms.GroupBox
    Friend WithEvents gbpComentarios As System.Windows.Forms.GroupBox
    Friend WithEvents txtPropuestasCambios As System.Windows.Forms.TextBox
    Friend WithEvents txtComentario As System.Windows.Forms.TextBox
    Friend WithEvents txtParrafo As System.Windows.Forms.TextBox
    Friend WithEvents txtCapituloInciso As System.Windows.Forms.TextBox
    Friend WithEvents cboTipoComentario As System.Windows.Forms.ComboBox
    Friend WithEvents lblTipoComentario As System.Windows.Forms.Label
    Friend WithEvents lblCapituloInciso As System.Windows.Forms.Label
    Friend WithEvents lblParrafo As System.Windows.Forms.Label
    Friend WithEvents lblComentario As System.Windows.Forms.Label
    Friend WithEvents lblPropuestasCambios As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtDomicilio As System.Windows.Forms.TextBox
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents lblNombre As System.Windows.Forms.Label
    Friend WithEvents lblEmpresa As System.Windows.Forms.Label
    Friend WithEvents lblDomicilio As System.Windows.Forms.Label
    Friend WithEvents lblTelefono As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents lblSB As System.Windows.Forms.Label
    Friend WithEvents txtTema As System.Windows.Forms.TextBox
    Friend WithEvents txtPNN As System.Windows.Forms.TextBox
    Friend WithEvents gpbx As System.Windows.Forms.GroupBox
    Friend WithEvents lblFecUno As System.Windows.Forms.Label
    Friend WithEvents txtDocto As System.Windows.Forms.TextBox
    Friend WithEvents txtResolucion As System.Windows.Forms.TextBox
    Friend WithEvents lblResolucion As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents txtID_Comentarios As System.Windows.Forms.TextBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents cmdSubirDocto As System.Windows.Forms.Button
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdVerMatriz As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents gbxMatriz As System.Windows.Forms.GroupBox
    Friend WithEvents nudComTec As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents nudComEdit As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMatrizDocTemp As System.Windows.Forms.TextBox
    Friend WithEvents txtFecha As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Resolucion))
        Me.tvPNN = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.gpbDatosPersonales = New System.Windows.Forms.GroupBox
        Me.gbpComentarios = New System.Windows.Forms.GroupBox
        Me.txtPropuestasCambios = New System.Windows.Forms.TextBox
        Me.txtComentario = New System.Windows.Forms.TextBox
        Me.txtParrafo = New System.Windows.Forms.TextBox
        Me.txtCapituloInciso = New System.Windows.Forms.TextBox
        Me.cboTipoComentario = New System.Windows.Forms.ComboBox
        Me.lblTipoComentario = New System.Windows.Forms.Label
        Me.lblCapituloInciso = New System.Windows.Forms.Label
        Me.lblParrafo = New System.Windows.Forms.Label
        Me.lblComentario = New System.Windows.Forms.Label
        Me.lblPropuestasCambios = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtTelefono = New System.Windows.Forms.TextBox
        Me.txtDomicilio = New System.Windows.Forms.TextBox
        Me.txtEmpresa = New System.Windows.Forms.TextBox
        Me.txtNombre = New System.Windows.Forms.TextBox
        Me.lblNombre = New System.Windows.Forms.Label
        Me.lblEmpresa = New System.Windows.Forms.Label
        Me.lblDomicilio = New System.Windows.Forms.Label
        Me.lblTelefono = New System.Windows.Forms.Label
        Me.lblFax = New System.Windows.Forms.Label
        Me.lblEmail = New System.Windows.Forms.Label
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dtkFecPublicacionConsulta = New System.Windows.Forms.DateTimePicker
        Me.txtTitulo = New System.Windows.Forms.TextBox
        Me.txtFecLimiteAnalisisComentarios = New System.Windows.Forms.TextBox
        Me.txtFecLimiteComentarios = New System.Windows.Forms.TextBox
        Me.txtFecPublicacionConsulta = New System.Windows.Forms.TextBox
        Me.lblFecPublicacionConsulta = New System.Windows.Forms.Label
        Me.lblFecLimiteComentarios = New System.Windows.Forms.Label
        Me.lblFecLimiteAnalisisComentarios = New System.Windows.Forms.Label
        Me.lblTitulo = New System.Windows.Forms.Label
        Me.dtkFecLimiteComentarios = New System.Windows.Forms.DateTimePicker
        Me.dtkFecLimiteAnalisisComentarios = New System.Windows.Forms.DateTimePicker
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lblResolucion = New System.Windows.Forms.Label
        Me.txtResolucion = New System.Windows.Forms.TextBox
        Me.gbxMatriz = New System.Windows.Forms.GroupBox
        Me.nudComTec = New System.Windows.Forms.NumericUpDown
        Me.Label2 = New System.Windows.Forms.Label
        Me.nudComEdit = New System.Windows.Forms.NumericUpDown
        Me.txtMatrizDocTemp = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.gpbx = New System.Windows.Forms.GroupBox
        Me.cmdSubirDocto = New System.Windows.Forms.Button
        Me.txtDocto = New System.Windows.Forms.TextBox
        Me.lblFecUno = New System.Windows.Forms.Label
        Me.Label80 = New System.Windows.Forms.Label
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdVerMatriz = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.lblSB = New System.Windows.Forms.Label
        Me.txtID_Comentarios = New System.Windows.Forms.TextBox
        Me.txtTema = New System.Windows.Forms.TextBox
        Me.txtPNN = New System.Windows.Forms.TextBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.txtFecha = New System.Windows.Forms.TextBox
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gpbDatosPersonales.SuspendLayout()
        Me.gbpComentarios.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gbxMatriz.SuspendLayout()
        CType(Me.nudComTec, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudComEdit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gpbx.SuspendLayout()
        Me.SuspendLayout()
        '
        'tvPNN
        '
        Me.tvPNN.ImageIndex = 2
        Me.tvPNN.ImageList = Me.imgListTreeView
        Me.tvPNN.Location = New System.Drawing.Point(6, 9)
        Me.tvPNN.Name = "tvPNN"
        Me.tvPNN.SelectedImageIndex = 2
        Me.tvPNN.Size = New System.Drawing.Size(185, 341)
        Me.tvPNN.TabIndex = 54
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(200, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(584, 396)
        Me.TabControl1.TabIndex = 53
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.gpbDatosPersonales)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(576, 370)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos Personales/Comentarios"
        Me.TabPage2.Visible = False
        '
        'gpbDatosPersonales
        '
        Me.gpbDatosPersonales.Controls.Add(Me.gbpComentarios)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmail)
        Me.gpbDatosPersonales.Controls.Add(Me.txtFax)
        Me.gpbDatosPersonales.Controls.Add(Me.txtTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.txtDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.txtNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.lblDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.lblTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.lblFax)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmail)
        Me.gpbDatosPersonales.Location = New System.Drawing.Point(5, 4)
        Me.gpbDatosPersonales.Name = "gpbDatosPersonales"
        Me.gpbDatosPersonales.Size = New System.Drawing.Size(564, 362)
        Me.gpbDatosPersonales.TabIndex = 3
        Me.gpbDatosPersonales.TabStop = False
        '
        'gbpComentarios
        '
        Me.gbpComentarios.Controls.Add(Me.txtPropuestasCambios)
        Me.gbpComentarios.Controls.Add(Me.txtComentario)
        Me.gbpComentarios.Controls.Add(Me.txtParrafo)
        Me.gbpComentarios.Controls.Add(Me.txtCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.cboTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.lblParrafo)
        Me.gbpComentarios.Controls.Add(Me.lblComentario)
        Me.gbpComentarios.Controls.Add(Me.lblPropuestasCambios)
        Me.gbpComentarios.Location = New System.Drawing.Point(8, 144)
        Me.gbpComentarios.Name = "gbpComentarios"
        Me.gbpComentarios.Size = New System.Drawing.Size(440, 212)
        Me.gbpComentarios.TabIndex = 19
        Me.gbpComentarios.TabStop = False
        '
        'txtPropuestasCambios
        '
        Me.txtPropuestasCambios.Location = New System.Drawing.Point(160, 149)
        Me.txtPropuestasCambios.Multiline = True
        Me.txtPropuestasCambios.Name = "txtPropuestasCambios"
        Me.txtPropuestasCambios.Size = New System.Drawing.Size(272, 56)
        Me.txtPropuestasCambios.TabIndex = 60
        Me.txtPropuestasCambios.Text = "txtPropuestasCambios"
        '
        'txtComentario
        '
        Me.txtComentario.Location = New System.Drawing.Point(160, 94)
        Me.txtComentario.Multiline = True
        Me.txtComentario.Name = "txtComentario"
        Me.txtComentario.Size = New System.Drawing.Size(272, 48)
        Me.txtComentario.TabIndex = 59
        Me.txtComentario.Text = "txtComentario"
        '
        'txtParrafo
        '
        Me.txtParrafo.Location = New System.Drawing.Point(160, 66)
        Me.txtParrafo.Name = "txtParrafo"
        Me.txtParrafo.TabIndex = 58
        Me.txtParrafo.Text = "txtParrafo"
        '
        'txtCapituloInciso
        '
        Me.txtCapituloInciso.Location = New System.Drawing.Point(160, 42)
        Me.txtCapituloInciso.Name = "txtCapituloInciso"
        Me.txtCapituloInciso.TabIndex = 57
        Me.txtCapituloInciso.Text = "txtCapituloInciso"
        '
        'cboTipoComentario
        '
        Me.cboTipoComentario.Location = New System.Drawing.Point(160, 16)
        Me.cboTipoComentario.Name = "cboTipoComentario"
        Me.cboTipoComentario.Size = New System.Drawing.Size(260, 21)
        Me.cboTipoComentario.TabIndex = 56
        Me.cboTipoComentario.Text = "cboTipoComentario"
        '
        'lblTipoComentario
        '
        Me.lblTipoComentario.AutoSize = True
        Me.lblTipoComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipoComentario.Location = New System.Drawing.Point(16, 16)
        Me.lblTipoComentario.Name = "lblTipoComentario"
        Me.lblTipoComentario.Size = New System.Drawing.Size(94, 16)
        Me.lblTipoComentario.TabIndex = 52
        Me.lblTipoComentario.Text = "Tipo Comentario"
        '
        'lblCapituloInciso
        '
        Me.lblCapituloInciso.AutoSize = True
        Me.lblCapituloInciso.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCapituloInciso.Location = New System.Drawing.Point(16, 42)
        Me.lblCapituloInciso.Name = "lblCapituloInciso"
        Me.lblCapituloInciso.Size = New System.Drawing.Size(85, 16)
        Me.lblCapituloInciso.TabIndex = 51
        Me.lblCapituloInciso.Text = "Cap�tulo Inciso"
        '
        'lblParrafo
        '
        Me.lblParrafo.AutoSize = True
        Me.lblParrafo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParrafo.Location = New System.Drawing.Point(16, 66)
        Me.lblParrafo.Name = "lblParrafo"
        Me.lblParrafo.Size = New System.Drawing.Size(114, 16)
        Me.lblParrafo.TabIndex = 53
        Me.lblParrafo.Text = "P�rrafo/Tabla/Figura"
        '
        'lblComentario
        '
        Me.lblComentario.AutoSize = True
        Me.lblComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComentario.Location = New System.Drawing.Point(16, 94)
        Me.lblComentario.Name = "lblComentario"
        Me.lblComentario.Size = New System.Drawing.Size(67, 16)
        Me.lblComentario.TabIndex = 55
        Me.lblComentario.Text = "Comentario"
        '
        'lblPropuestasCambios
        '
        Me.lblPropuestasCambios.AutoSize = True
        Me.lblPropuestasCambios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPropuestasCambios.Location = New System.Drawing.Point(16, 149)
        Me.lblPropuestasCambios.Name = "lblPropuestasCambios"
        Me.lblPropuestasCambios.Size = New System.Drawing.Size(133, 16)
        Me.lblPropuestasCambios.TabIndex = 54
        Me.lblPropuestasCambios.Text = "Propuestas de Cambios"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(399, 73)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(160, 20)
        Me.txtEmail.TabIndex = 18
        Me.txtEmail.Text = "txtEmail"
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(399, 41)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(160, 20)
        Me.txtFax.TabIndex = 17
        Me.txtFax.Text = "txtFax"
        '
        'txtTelefono
        '
        Me.txtTelefono.Location = New System.Drawing.Point(399, 9)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(160, 20)
        Me.txtTelefono.TabIndex = 16
        Me.txtTelefono.Text = "txtTelefono"
        '
        'txtDomicilio
        '
        Me.txtDomicilio.Location = New System.Drawing.Point(71, 73)
        Me.txtDomicilio.Multiline = True
        Me.txtDomicilio.Name = "txtDomicilio"
        Me.txtDomicilio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDomicilio.Size = New System.Drawing.Size(264, 70)
        Me.txtDomicilio.TabIndex = 15
        Me.txtDomicilio.Text = "txtDomicilio"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Location = New System.Drawing.Point(71, 41)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(264, 20)
        Me.txtEmpresa.TabIndex = 14
        Me.txtEmpresa.Text = "txtEmpresa"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(71, 9)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(264, 20)
        Me.txtNombre.TabIndex = 13
        Me.txtNombre.Text = "txtNombre"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombre.Location = New System.Drawing.Point(16, 13)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(47, 16)
        Me.lblNombre.TabIndex = 12
        Me.lblNombre.Text = "Nombre"
        '
        'lblEmpresa
        '
        Me.lblEmpresa.AutoSize = True
        Me.lblEmpresa.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpresa.Location = New System.Drawing.Point(11, 42)
        Me.lblEmpresa.Name = "lblEmpresa"
        Me.lblEmpresa.Size = New System.Drawing.Size(52, 16)
        Me.lblEmpresa.TabIndex = 12
        Me.lblEmpresa.Text = "Empresa"
        '
        'lblDomicilio
        '
        Me.lblDomicilio.AutoSize = True
        Me.lblDomicilio.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDomicilio.Location = New System.Drawing.Point(11, 73)
        Me.lblDomicilio.Name = "lblDomicilio"
        Me.lblDomicilio.Size = New System.Drawing.Size(55, 16)
        Me.lblDomicilio.TabIndex = 12
        Me.lblDomicilio.Text = "Domicilio"
        '
        'lblTelefono
        '
        Me.lblTelefono.AutoSize = True
        Me.lblTelefono.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTelefono.Location = New System.Drawing.Point(343, 9)
        Me.lblTelefono.Name = "lblTelefono"
        Me.lblTelefono.Size = New System.Drawing.Size(51, 16)
        Me.lblTelefono.TabIndex = 12
        Me.lblTelefono.Text = "Tel�fono"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFax.Location = New System.Drawing.Point(367, 41)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(24, 16)
        Me.lblFax.TabIndex = 12
        Me.lblFax.Text = "Fax"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(359, 73)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(34, 16)
        Me.lblEmail.TabIndex = 12
        Me.lblEmail.Text = "Email"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(576, 370)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Proyecto                "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtkFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.txtTitulo)
        Me.GroupBox1.Controls.Add(Me.txtFecLimiteAnalisisComentarios)
        Me.GroupBox1.Controls.Add(Me.txtFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.txtFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.lblFecLimiteAnalisisComentarios)
        Me.GroupBox1.Controls.Add(Me.lblTitulo)
        Me.GroupBox1.Controls.Add(Me.dtkFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.dtkFecLimiteAnalisisComentarios)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(496, 271)
        Me.GroupBox1.TabIndex = 53
        Me.GroupBox1.TabStop = False
        '
        'dtkFecPublicacionConsulta
        '
        Me.dtkFecPublicacionConsulta.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecPublicacionConsulta.Location = New System.Drawing.Point(304, 32)
        Me.dtkFecPublicacionConsulta.Name = "dtkFecPublicacionConsulta"
        Me.dtkFecPublicacionConsulta.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecPublicacionConsulta.TabIndex = 31
        Me.dtkFecPublicacionConsulta.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecPublicacionConsulta.Visible = False
        '
        'txtTitulo
        '
        Me.txtTitulo.Location = New System.Drawing.Point(192, 152)
        Me.txtTitulo.Multiline = True
        Me.txtTitulo.Name = "txtTitulo"
        Me.txtTitulo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTitulo.Size = New System.Drawing.Size(294, 73)
        Me.txtTitulo.TabIndex = 28
        Me.txtTitulo.Text = "txtTitulo"
        '
        'txtFecLimiteAnalisisComentarios
        '
        Me.txtFecLimiteAnalisisComentarios.Location = New System.Drawing.Point(192, 112)
        Me.txtFecLimiteAnalisisComentarios.Name = "txtFecLimiteAnalisisComentarios"
        Me.txtFecLimiteAnalisisComentarios.TabIndex = 27
        Me.txtFecLimiteAnalisisComentarios.Text = "txtFecLimiteAnalisisComentarios"
        '
        'txtFecLimiteComentarios
        '
        Me.txtFecLimiteComentarios.Location = New System.Drawing.Point(192, 72)
        Me.txtFecLimiteComentarios.Name = "txtFecLimiteComentarios"
        Me.txtFecLimiteComentarios.TabIndex = 26
        Me.txtFecLimiteComentarios.Text = "txtFecLimiteComentarios"
        '
        'txtFecPublicacionConsulta
        '
        Me.txtFecPublicacionConsulta.Location = New System.Drawing.Point(192, 32)
        Me.txtFecPublicacionConsulta.Name = "txtFecPublicacionConsulta"
        Me.txtFecPublicacionConsulta.TabIndex = 25
        Me.txtFecPublicacionConsulta.Text = "FecPublicacionConsulta"
        '
        'lblFecPublicacionConsulta
        '
        Me.lblFecPublicacionConsulta.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecPublicacionConsulta.Location = New System.Drawing.Point(8, 24)
        Me.lblFecPublicacionConsulta.Name = "lblFecPublicacionConsulta"
        Me.lblFecPublicacionConsulta.Size = New System.Drawing.Size(174, 28)
        Me.lblFecPublicacionConsulta.TabIndex = 19
        Me.lblFecPublicacionConsulta.Text = "Fecha de Publicaci�n a periodo de Comentario P�blico"
        '
        'lblFecLimiteComentarios
        '
        Me.lblFecLimiteComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecLimiteComentarios.Location = New System.Drawing.Point(8, 72)
        Me.lblFecLimiteComentarios.Name = "lblFecLimiteComentarios"
        Me.lblFecLimiteComentarios.Size = New System.Drawing.Size(176, 19)
        Me.lblFecLimiteComentarios.TabIndex = 21
        Me.lblFecLimiteComentarios.Text = "Fecha L�mite para Comentarios"
        '
        'lblFecLimiteAnalisisComentarios
        '
        Me.lblFecLimiteAnalisisComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecLimiteAnalisisComentarios.Location = New System.Drawing.Point(8, 104)
        Me.lblFecLimiteAnalisisComentarios.Name = "lblFecLimiteAnalisisComentarios"
        Me.lblFecLimiteAnalisisComentarios.Size = New System.Drawing.Size(136, 26)
        Me.lblFecLimiteAnalisisComentarios.TabIndex = 23
        Me.lblFecLimiteAnalisisComentarios.Text = "Fecha L�mite a An�lisis Comentarios"
        '
        'lblTitulo
        '
        Me.lblTitulo.AutoSize = True
        Me.lblTitulo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitulo.Location = New System.Drawing.Point(8, 152)
        Me.lblTitulo.Name = "lblTitulo"
        Me.lblTitulo.Size = New System.Drawing.Size(35, 16)
        Me.lblTitulo.TabIndex = 22
        Me.lblTitulo.Text = "T�tulo"
        '
        'dtkFecLimiteComentarios
        '
        Me.dtkFecLimiteComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecLimiteComentarios.Location = New System.Drawing.Point(304, 72)
        Me.dtkFecLimiteComentarios.Name = "dtkFecLimiteComentarios"
        Me.dtkFecLimiteComentarios.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecLimiteComentarios.TabIndex = 31
        Me.dtkFecLimiteComentarios.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecLimiteComentarios.Visible = False
        '
        'dtkFecLimiteAnalisisComentarios
        '
        Me.dtkFecLimiteAnalisisComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecLimiteAnalisisComentarios.Location = New System.Drawing.Point(304, 112)
        Me.dtkFecLimiteAnalisisComentarios.Name = "dtkFecLimiteAnalisisComentarios"
        Me.dtkFecLimiteAnalisisComentarios.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecLimiteAnalisisComentarios.TabIndex = 31
        Me.dtkFecLimiteAnalisisComentarios.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecLimiteAnalisisComentarios.Visible = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox2)
        Me.TabPage3.Controls.Add(Me.gbxMatriz)
        Me.TabPage3.Controls.Add(Me.gpbx)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(576, 370)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Revisi�n de Comentarios   "
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblResolucion)
        Me.GroupBox2.Controls.Add(Me.txtResolucion)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 144)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(560, 112)
        Me.GroupBox2.TabIndex = 169
        Me.GroupBox2.TabStop = False
        '
        'lblResolucion
        '
        Me.lblResolucion.AutoSize = True
        Me.lblResolucion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResolucion.Location = New System.Drawing.Point(8, 24)
        Me.lblResolucion.Name = "lblResolucion"
        Me.lblResolucion.Size = New System.Drawing.Size(65, 16)
        Me.lblResolucion.TabIndex = 16
        Me.lblResolucion.Text = "Resoluci�n"
        '
        'txtResolucion
        '
        Me.txtResolucion.Location = New System.Drawing.Point(88, 24)
        Me.txtResolucion.Multiline = True
        Me.txtResolucion.Name = "txtResolucion"
        Me.txtResolucion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtResolucion.Size = New System.Drawing.Size(456, 70)
        Me.txtResolucion.TabIndex = 17
        Me.txtResolucion.Text = "txtResolucion"
        '
        'gbxMatriz
        '
        Me.gbxMatriz.Controls.Add(Me.nudComTec)
        Me.gbxMatriz.Controls.Add(Me.Label2)
        Me.gbxMatriz.Controls.Add(Me.nudComEdit)
        Me.gbxMatriz.Controls.Add(Me.txtMatrizDocTemp)
        Me.gbxMatriz.Controls.Add(Me.Label1)
        Me.gbxMatriz.Controls.Add(Me.Label3)
        Me.gbxMatriz.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxMatriz.Location = New System.Drawing.Point(8, 8)
        Me.gbxMatriz.Name = "gbxMatriz"
        Me.gbxMatriz.Size = New System.Drawing.Size(560, 128)
        Me.gbxMatriz.TabIndex = 168
        Me.gbxMatriz.TabStop = False
        '
        'nudComTec
        '
        Me.nudComTec.Enabled = False
        Me.nudComTec.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudComTec.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.nudComTec.Location = New System.Drawing.Point(424, 29)
        Me.nudComTec.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudComTec.Name = "nudComTec"
        Me.nudComTec.Size = New System.Drawing.Size(64, 20)
        Me.nudComTec.TabIndex = 167
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(160, 16)
        Me.Label2.TabIndex = 165
        Me.Label2.Text = "No. Comentarios Editoriales:"
        '
        'nudComEdit
        '
        Me.nudComEdit.Enabled = False
        Me.nudComEdit.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudComEdit.Location = New System.Drawing.Point(184, 28)
        Me.nudComEdit.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudComEdit.Name = "nudComEdit"
        Me.nudComEdit.Size = New System.Drawing.Size(64, 20)
        Me.nudComEdit.TabIndex = 166
        '
        'txtMatrizDocTemp
        '
        Me.txtMatrizDocTemp.Enabled = False
        Me.txtMatrizDocTemp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMatrizDocTemp.Location = New System.Drawing.Point(208, 80)
        Me.txtMatrizDocTemp.Name = "txtMatrizDocTemp"
        Me.txtMatrizDocTemp.ReadOnly = True
        Me.txtMatrizDocTemp.Size = New System.Drawing.Size(224, 20)
        Me.txtMatrizDocTemp.TabIndex = 161
        Me.txtMatrizDocTemp.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(264, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 16)
        Me.Label1.TabIndex = 164
        Me.Label1.Text = "No. Comentarios T�cnicos:"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(192, 16)
        Me.Label3.TabIndex = 159
        Me.Label3.Text = "Adjuntar Matriz de Comentarios:"
        '
        'gpbx
        '
        Me.gpbx.Controls.Add(Me.txtFecha)
        Me.gpbx.Controls.Add(Me.cmdSubirDocto)
        Me.gpbx.Controls.Add(Me.txtDocto)
        Me.gpbx.Controls.Add(Me.lblFecUno)
        Me.gpbx.Controls.Add(Me.Label80)
        Me.gpbx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gpbx.Location = New System.Drawing.Point(8, 264)
        Me.gpbx.Name = "gpbx"
        Me.gpbx.Size = New System.Drawing.Size(560, 88)
        Me.gpbx.TabIndex = 2
        Me.gpbx.TabStop = False
        '
        'cmdSubirDocto
        '
        Me.cmdSubirDocto.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.cmdSubirDocto.Location = New System.Drawing.Point(464, 48)
        Me.cmdSubirDocto.Name = "cmdSubirDocto"
        Me.cmdSubirDocto.Size = New System.Drawing.Size(40, 16)
        Me.cmdSubirDocto.TabIndex = 32
        Me.cmdSubirDocto.Text = "......"
        '
        'txtDocto
        '
        Me.txtDocto.Location = New System.Drawing.Point(152, 48)
        Me.txtDocto.Name = "txtDocto"
        Me.txtDocto.Size = New System.Drawing.Size(304, 20)
        Me.txtDocto.TabIndex = 28
        Me.txtDocto.Text = "txtDocto"
        '
        'lblFecUno
        '
        Me.lblFecUno.AutoSize = True
        Me.lblFecUno.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecUno.Location = New System.Drawing.Point(16, 24)
        Me.lblFecUno.Name = "lblFecUno"
        Me.lblFecUno.Size = New System.Drawing.Size(41, 16)
        Me.lblFecUno.TabIndex = 22
        Me.lblFecUno.Text = "Fecha:"
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(152, 24)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(248, 24)
        Me.Label80.TabIndex = 160
        Me.Label80.Text = "Adjuntar Matriz Resoluci�n de Comentarios:"
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdVerMatriz, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 408)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(792, 62)
        Me.tlbBotonera.TabIndex = 52
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        Me.Separador1.Text = "cmdVerMatriz"
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdVerMatriz
        '
        Me.cmdVerMatriz.ImageIndex = 6
        Me.cmdVerMatriz.Text = "Ver Matriz"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'lblSB
        '
        Me.lblSB.Location = New System.Drawing.Point(16, 384)
        Me.lblSB.Name = "lblSB"
        Me.lblSB.Size = New System.Drawing.Size(167, 16)
        Me.lblSB.TabIndex = 61
        Me.lblSB.Visible = False
        '
        'txtID_Comentarios
        '
        Me.txtID_Comentarios.Location = New System.Drawing.Point(109, 360)
        Me.txtID_Comentarios.Name = "txtID_Comentarios"
        Me.txtID_Comentarios.Size = New System.Drawing.Size(48, 20)
        Me.txtID_Comentarios.TabIndex = 59
        Me.txtID_Comentarios.Text = ""
        Me.txtID_Comentarios.Visible = False
        '
        'txtTema
        '
        Me.txtTema.Location = New System.Drawing.Point(56, 360)
        Me.txtTema.Name = "txtTema"
        Me.txtTema.Size = New System.Drawing.Size(48, 20)
        Me.txtTema.TabIndex = 58
        Me.txtTema.Text = ""
        Me.txtTema.Visible = False
        '
        'txtPNN
        '
        Me.txtPNN.Location = New System.Drawing.Point(4, 360)
        Me.txtPNN.Name = "txtPNN"
        Me.txtPNN.Size = New System.Drawing.Size(46, 20)
        Me.txtPNN.TabIndex = 57
        Me.txtPNN.Text = ""
        Me.txtPNN.Visible = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = """Adobe (*.pdf)|*.pdf|Word (*.Doc)|*.Doc|Excel (*.xls)|*.xls|PowerPoint (*.ppt)|*." & _
        "ppt"""
        '
        'txtFecha
        '
        Me.txtFecha.Enabled = False
        Me.txtFecha.Location = New System.Drawing.Point(16, 48)
        Me.txtFecha.Name = "txtFecha"
        Me.txtFecha.Size = New System.Drawing.Size(120, 20)
        Me.txtFecha.TabIndex = 161
        Me.txtFecha.Text = "txtFecha"
        '
        'Resolucion
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 470)
        Me.Controls.Add(Me.lblSB)
        Me.Controls.Add(Me.txtID_Comentarios)
        Me.Controls.Add(Me.txtTema)
        Me.Controls.Add(Me.txtPNN)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.tvPNN)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Resolucion"
        Me.Text = "Revisi�n de Comentarios"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.gpbDatosPersonales.ResumeLayout(False)
        Me.gbpComentarios.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.gbxMatriz.ResumeLayout(False)
        CType(Me.nudComTec, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudComEdit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gpbx.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Variables globales mmendoza
    Dim myStream As String
    Dim SDocumento As String
    Public rutaOriginal As String
    Private clsDoctosTemas As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)

    Private tipoCom As TiposComentario

    Private Enum TiposComentario As Integer
        Normal = 0
        Matriz = 1
        Nulo = 3
    End Enum

#Region " Forms - Resolucion, Metodos y Procesos"

    Private Sub Resolucion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sTipoProceso = "Nulo"
        Call Habilita(sTipoProceso)

        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        Call inicializa()

        objComentarios.Bandera = 6 'cboComentario
        Call Carga_Combo(cboTipoComentario)

        Call llena_TreeView()
        'Call Formato_Grid(grdDoctos) 'grdDoctos
    End Sub

#End Region

#Region " Carga_Combo"
    Sub Carga_Combo(ByVal cbo As Object)
        objComentarios.ListaCombo(cbo)
        If objComentarios Is Nothing Then
            cboTipoComentario.Items.Add("Lista vacia")
            Exit Sub
        End If
    End Sub
#End Region

#Region " Inicializa"

    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"

            Case "Agregar"
                
            Case "Editar"
                Activos(cmdDeshacer, cmdGuardar, cmdSubirDocto, txtResolucion, txtDocto)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
                Muestra(cmdSubirDocto)

                If txtFecha.Text = "" Then
                    txtFecha.Text = Today.ToShortDateString
                End If

                If myStream <> "" Then
                    Activos(cmdVerMatriz)
                End If
        End Select
    End Sub

    Sub inicializa()
        tipoCom = TiposComentario.Nulo

        'Datos Personales
        Limpia_Campos(txtNombre, txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        'Proyecto
        Limpia_Campos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios, txtTitulo)
        'Comentarios
        Limpia_Campos(cboTipoComentario, txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios)
        'Comentarios matriz
        Limpia_Campos(txtResolucion, txtDocto, nudComEdit, nudComTec, txtMatrizDocTemp)
        'Revisi�n de Comentarios
        Limpia_Campos(txtID_Comentarios, txtResolucion, txtFecha, txtDocto)

        Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar, cmdSubirDocto, cmdVerMatriz, cmdVerMatriz)
        Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios, txtTitulo)
        Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        cboTipoComentario.Enabled = False

        'matriz
        Oculta(cmdSubirDocto)

        'Revisi�n de Comentarios
        Inactivos(txtID_Comentarios, txtResolucion, txtDocto, cmdSubirDocto)
        'Inactivos(grdDoctos)       

    End Sub
#End Region

#Region " AfterSelect (Despues de selccionar un nodo)"
    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvPNN.AfterSelect
        Dim i As Integer

        lblSB.Text = e.Node.FullPath
        iCaso = 0
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        array_texto = Split(lblSB.Text, "\")

        For i = 0 To array_texto.Length - 1
            Select Case i
                Case 1
                    txtPNN.Text = array_texto(i)
                Case 2
                    txtTema.Text = array_texto(i)
            End Select
        Next
        'Limpia_Campos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios)
        'Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        'Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        'Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        'Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        inicializa()

        Select Case array_texto.Length
            Case 1
                Inactivos(cmdAgregar, cmdEditar, cmdVerMatriz, cmdDeshacer, cmdGuardar, cmdBorrar)

                objComentarios.Id_Tema = Nothing
                objComentarios.Id_Plan = Nothing
                objComentarios.Id_Comentario = Nothing
                objComentarios.Bandera = 7
                'Call Llena_GridDocto(grdDoctos)
                'grdDoctos.ReadOnly = True

                iCaso = 2
            Case 3
                txtPNN.Text = array_texto(1)
                Inactivos(cmdAgregar, cmdEditar, cmdVerMatriz, cmdDeshacer, cmdGuardar, cmdBorrar)

                objComentarios.Bandera = 4
                objComentarios.Id_Plan = array_texto(1)
                'objComentarios.Id_Comentario = CInt(Mid(array_texto(3), 4))
                objComentarios.Id_Tema = array_texto(2)
                objComentarios.Llena_Campos()
                pestProyecto()
                'txtTitulo.Text = objComentarios.

                objComentarios.Id_Tema = Nothing
                objComentarios.Id_Plan = Nothing
                objComentarios.Id_Comentario = Nothing
                objComentarios.Bandera = 7
                'Call Llena_GridDocto(grdDoctos)
                'grdDoctos.ReadOnly = True

                txtTema.Text = array_texto(2)
                iCaso = 3
            Case 4
                Dim idCom As String
                idCom = array_texto(3)

                Inactivos(cmdAgregar, cmdVerMatriz, cmdDeshacer, cmdGuardar, cmdBorrar)
                Activos(cmdEditar)
                Oculta(cmdSubirDocto)

                objComentarios.Id_Plan = array_texto(1)
                objComentarios.Id_Tema = array_texto(2)
                objComentarios.Id_Comentario = CInt(Mid(idCom, idCom.Length - 3))

                If array_texto(3) = "COMATRIZ0001" Then
                    tipoCom = TiposComentario.Matriz

                    objComentarios.Bandera = 5
                    objComentarios.Id_Etapa = 4
                    objComentarios.Llena_Campos_Matriz()
                    nudComEdit.Text = objComentarios.NumComEdit
                    nudComTec.Text = objComentarios.NumComTec
                    txtMatrizDocTemp.Text = objComentarios.DocMatriz
                    txtResolucion.Text = objComentarios.Resolucion
                    txtFecha.text = objComentarios.Fecha_Resolucion

                    TabControl1.SelectedTab = TabControl1.TabPages.Item(2)
                Else
                    tipoCom = TiposComentario.Normal

                    objComentarios.Bandera = 5
                    objComentarios.Llena_Campos()

                    txtFecPublicacionConsulta.Text = objComentarios.Fecha_inicio
                    txtFecLimiteComentarios.Text = objComentarios.Fecha_Fin

                    txtCapituloInciso.Text = objComentarios.Capitulo_inciso
                    txtParrafo.Text = objComentarios.Parrafotablafigura
                    txtComentario.Text = objComentarios.Comentarios
                    txtPropuestasCambios.Text = objComentarios.Propuesta_cambios
                    txtNombre.Text = objComentarios.Nombre
                    txtEmpresa.Text = objComentarios.Empresa
                    txtDomicilio.Text = objComentarios.Domicilio_Empresa
                    txtTelefono.Text = objComentarios.Telefono
                    txtFax.Text = objComentarios.Fax
                    txtEmail.Text = objComentarios.Email
                    txtResolucion.Text = objComentarios.Resolucion
                    txtFecha.Text = objComentarios.Fecha_Resolucion

                    objComentarios.Bandera = 8 'cboComentario

                    Call Carga_Combo(cboTipoComentario)
                    cboTipoComentario.SelectedValue = objComentarios.Tipo_comentario
                    TabControl1.SelectedTab = TabControl1.TabPages.Item(2)
                End If

                Dim dtAux As DataTable

                objComentarios.Id_tipo_doc = 5
                objComentarios.Bandera = 7
                dtAux = objComentarios.ListaGridDoctos
                If dtAux.Rows.Count > 0 Then
                    txtDocto.Text = dtAux.Rows(0).Item(3)
                    Activos(cmdVerMatriz, cmdBorrar)
                    PathDocMatriz()
                End If

                pestProyecto()

                txtID_Comentarios.Text = array_texto(3)
                iCaso = 4
        End Select

        'If lblSB.Text = "" Or lblSB.Text = "Selecciona un Plan" Then
        '    Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre, txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        '    Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
        '    Limpia_Campos(txtPNN)
        '    objComentarios.Id_Tema = Nothing
        '    objComentarios.Id_Plan = Nothing
        '    objComentarios.Id_Comentario = Nothing
        '    objComentarios.Bandera = 7
        '    Call Llena_GridDocto(grdDoctos)
        '    grdDoctos.ReadOnly = True

        '    iCaso = 1
        '    Exit Sub
        'End If
        'Activos(cmdBorrar)


        If array_texto.Length <= 1 Then 'PNN
            Limpia_Campos(txtPNN)
        Else

        End If

        If array_texto.Length <= 2 Then 'Temas
            txtTema.Text = ""
        Else

            'cmdBusca2.Dispose()
        End If

        If array_texto.Length <= 3 Then 'Comentarios
            txtID_Comentarios.Text = ""
        Else


        End If


        If array_texto.Length > 4 Then
            iCaso = 5
        End If

    End Sub

    Private Sub pestProyecto()
        Referenciar("abandono")
        ObjFechasavance.Buscar(array_texto(2), array_texto(1), srefp)
        txtFecPublicacionConsulta.Text = IIf(IsDBNull(ObjFechasavance.F_Publicacion_ComentarioPublico) = True, "", ObjFechasavance.F_Publicacion_ComentarioPublico) 'objComentarios.Fecha_inicio
        txtFecLimiteComentarios.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_ComentarioPublico) 'objComentarios.Fecha_Fin
        txtFecLimiteAnalisisComentarios.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico) 'objComentarios.Fecha_Fin
        ObjProy.Buscar(array_texto(2), array_texto(1), srefp)
        txtTitulo.Text = ObjProy.Titulo
    End Sub

    Private Sub PathDocMatriz()
        Dim ruta As String

        splan = array_texto(1)
        stema = array_texto(2)
        Referenciar("abandono")

        'If ObjPrograma.ID_Grupo <> "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
        'If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
        'If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
        'If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite

        ruta = ObjPrograma.ID_Comite
        If ObjPrograma.ID_CT <> "NA" Or ObjPrograma.ID_CT <> "" Then ruta = ruta + "\" + ObjPrograma.ID_CT
        If ObjPrograma.ID_SC <> "NA" Or ObjPrograma.ID_SC <> "" Then ruta = ruta + "\" + ObjPrograma.ID_SC
        If ObjPrograma.ID_Grupo <> "NA" Or ObjPrograma.ID_Grupo <> "" Then ruta = ruta + "\" + ObjPrograma.ID_Grupo

        Dim server = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")
        'Dim carpeta = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Comentarios")
        'Dim rutaCarpetas = server + carpeta + "\" + ruta + "\"
        Dim rutaCarpetas = server + "\" + ruta + "\"
        Dim sPath = rutaCarpetas + txtDocto.Text

        rutaOriginal = sPath
    End Sub

#End Region

#Region " AGREGAR"
    Private Sub Agregar()
        Inactivos(tvPNN, cmdBorrar)
        Dim sSqlAgregar As String

        If iCaso = 3 Then 'Agregar Comentario
            Activos(cmdDeshacer, cmdGuardar)
            'Activos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
            Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios, txtFecLimiteAnalisisComentarios)

            Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)

            cboTipoComentario.Enabled = True

            Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
            '''Activos(cmdDeshacer, cmdGuardar, txtSC, txtDescripcion, txtObjetivo)
            '''Activos(cboResponsable)
            '''Limpia_Campos(txtSC, txtDescripcion, txtObjetivo)
            '''Exit Sub
        End If

        If iCaso = 4 Then 'Editar Comentario
            Activos(cmdDeshacer, cmdGuardar)
            Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
            cboTipoComentario.Enabled = True
            '''Activos(cmdDeshacer, cmdGuardar, txtGT, txtDescripcion, txtObjetivo)
            '''Activos(cboResponsable)
            '''Limpia_Campos(txtGT, txtDescripcion, txtObjetivo)
            '''Exit Sub
        End If

        If iCaso <> 1 Or iCaso <> 2 Or iCaso <> 3 Or iCaso <> 4 Then
            '''MsgBox("Este es el ultimo nivel, no se pueden agregar m�s nodos")
            '''Activos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            ''''Inactivos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            ''''Activos(cmdAgregar, cmdEditar, tvComites, cmdBorrar)
            ''''Inactivos(cboResponsable)
            '''Exit Sub
        End If
    End Sub
#End Region

#Region " BORRAR"
    Public Sub Borrar()
        If MsgBox("�Estas seguro que deseas eliminar este Comentario: " & txtPNN.Text & "/" & txtTema.Text & "/" & txtID_Comentarios.Text & " ", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
            Dim idCom As String

            splan = array_texto(1)
            stema = array_texto(2)
            idCom = array_texto(3)

            Referenciar("abandono")

            With objComentarios
                .Bandera = 7
                .Id_Plan = txtPNN.Text
                .Id_Tema = txtTema.Text
                .Id_Comentario = CInt(Mid(idCom, idCom.Length - 3))
                .RefA�o = ObjPrograma.RefA�o
                .RefComite = ObjPrograma.RefComite
                .RefConsecutivo = ObjPrograma.RefConsecutivo
                .RefRegreso = ObjPrograma.RefRegreso
                .RefTraspaso = ObjPrograma.RefTraspaso
                .Referencia = .RefA�o + .RefComite + .RefConsecutivo + .RefRegreso + .RefTraspaso
                .Documento = txtDocto.Text
                .Id_tipo_doc = 5
                .Activo = False

                .BorrarResolucion()

                .Bandera = 8
                .BorrarResolucion()
            End With

            tvPNN.Nodes.Clear()
            Call llena_TreeView()
        Else
            Exit Sub
        End If
    End Sub
#End Region

#Region " Botonera"
    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                tvPNN.Enabled = False
                sTipoProceso = "Agregar"
                Call Habilita(sTipoProceso)
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)
                'Call Agregar()

            Case 2 'EDITAR
                tvPNN.Enabled = False
                If iCaso = 4 Then 'Editar Comentario
                    sTipoProceso = "Editar"
                    Call Habilita(sTipoProceso)
                    TabControl1.SelectedTab = TabControl1.TabPages.Item(2)
                End If
            Case 3 'matriz
                If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
                    'abre el archivo que se desea adjuntar para verificar que sea el correcto
                    If myStream <> "" Then
                        Try
                            System.Diagnostics.Process.Start(myStream)
                        Catch ex As Exception
                            MsgBox("Archivo no encontrado en la ruta : " + myStream)
                        End Try
                    Else
                        Try
                            System.Diagnostics.Process.Start(rutaOriginal)
                        Catch ex As Exception
                            MsgBox("Archivo no encontrado en la ruta : " + rutaOriginal)
                        End Try
                    End If
                Else
                    'consulta el documento guardado
                    If rutaOriginal <> "" Then
                        Try
                            System.Diagnostics.Process.Start(rutaOriginal)
                        Catch ex As Exception
                            MsgBox("Archivo no encontrado en la ruta : " + rutaOriginal)
                        End Try
                        rutaOriginal = ""
                    End If
                End If

            Case 4 'DESHACER
                Activos(tvPNN)
                Call Deshacer()
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                ', cmdAgregar, cmdEditar, cmdBorrar)

            Case 5 'GUARDAR
                '''Inactivos(cmdDeshacer, cmdGuardar, grdCanceladas)
                '''Activos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Call Guardar()

            Case 6 'BORRAR
                Call Borrar()

            Case 8 'SALIR
                Me.Close()
        End Select
    End Sub
#End Region

#Region " DESHACER"
    Public Sub Deshacer()
        tvPNN.Nodes.Clear()
        Call llena_TreeView()
        Call inicializa()

        cboTipoComentario.Enabled = False
    End Sub

#End Region

#Region " EDITAR"

#End Region

#Region " GUARDAR"
    Dim iDetalle As Integer
    Private Sub Guardar()
        ''Dim sSqlAgregar As String

        ''If sTipoProceso = "Editar" Then '*****************IF*************AGREGAR



        ''    If txtResolucion.Text = "" Then
        ''        MsgBox("Falta la Resoluci�n al comentario", MsgBoxStyle.Information, "Resoluci�n de Comentarios")
        ''        Exit Sub
        ''    End If
        ''    With objComentarios
        ''        .Bandera = 3
        ''        .Id_Plan = array_texto(1)
        ''        .Id_Tema = array_texto(2)
        ''        .Id_Comentario = CInt(Mid(array_texto(3), 4))
        ''        .Fecha_Resolucion = txtFecha.Text
        ''        .Resolucion = txtResolucion.Text
        ''        .Actualizar()

        ''        Dim dt As New DataTable
        ''        Dim dr As DataRow
        ''        Dim bInactivo As Boolean
        ''        Dim accion As Boolean
        ''        dt = grdDoctos.DataSource()
        ''        If dt.Rows.Count <> 0 Then
        ''            Dim archivo As String
        ''            Dim indice As Integer
        ''            Dim nombre As String
        ''            Dim comitepath As String
        ''            For Each dr In dt.Rows
        ''                '*****************************************Copia los Doctos a la carpeta
        ''                .Bandera = 4
        ''                .Id_tipo_doc = 5
        ''                ruta = dr(3)
        ''                .Actualizar()
        ''                ObjPrograma.Buscar(array_texto(1), array_texto(2))
        ''                comitepath = ObjPrograma.ID_Comite
        ''                If ObjPrograma.ID_CT <> "NA" Or ObjPrograma.ID_CT <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_CT
        ''                If ObjPrograma.ID_SC <> "NA" Or ObjPrograma.ID_SC <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_SC
        ''                If ObjPrograma.ID_Grupo <> "NA" Or ObjPrograma.ID_Grupo <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_Grupo

        ''                If File.Exists(comitepath + "\" + dr(7)) Then
        ''                    If MsgBox("El archivo (" + CStr(archivo) + ") ya existe en el Servidor..." + Chr(13) + Chr(13) + " �Desea sobrescribir el archivo?", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
        ''                        File.Copy(dr(3), comitepath + "\" + dr(7), True)
        ''                    End If
        ''                Else
        ''                    File.Copy(dr(3), comitepath + "\" + dr(7))
        ''                End If
        ''                'clsCopia.CopiaArchivos(dr(3), "\\ance-dc\Docs_ONN_WWW" + comite)
        ''                '****************************************Guarda Doctos en la tabla
        ''                .Id_tipo_doc = 5
        ''                If dr(4) = 1 Or dr(4) = True Then
        ''                    .Activo = dr(4)
        ''                    ' txtDocto.Text
        ''                    .Documento = dr(7)
        ''                    .Actualizar_Documentos()
        ''                End If
        ''            Next
        ''        End If



        ''    End With
        ''    tvPNN.Nodes.Clear()
        ''    Call inicializa()
        ''    Call llena_TreeView()
        ''    tvPNN.Enabled = True


        ''    If iCaso = 5 Then
        ''    End If

        ''End If
        Dim sSqlAgregar As String
        Dim idCom As String
        Referenciar("abandono")
        If sTipoProceso = "Editar" Then '*****************IF*************AGREGAR
            If txtResolucion.Text = "" Then
                MsgBox("Falta la Resoluci�n al comentario", MsgBoxStyle.Information, "Resoluci�n de Comentarios")
                Exit Sub
            End If
            Try
                With objComentarios
                    idCom = array_texto(3)

                    .Id_Plan = array_texto(1)
                    .Id_Tema = array_texto(2)
                    .Id_Comentario = CInt(Mid(idCom, idCom.Length - 3))

                    If tipoCom = TiposComentario.Normal Then
                        .Bandera = 3
                        .Fecha_Resolucion = Today
                        .Resolucion = txtResolucion.Text
                        .Actualizar()
                    ElseIf tipoCom = TiposComentario.Matriz Then
                        splan = array_texto(1)
                        stema = array_texto(2)
                        Referenciar("abandono")

                        .RefA�o = ObjPrograma.RefA�o
                        .RefComite = ObjPrograma.RefComite
                        .RefConsecutivo = ObjPrograma.RefConsecutivo
                        .RefRegreso = ObjPrograma.RefRegreso
                        .RefTraspaso = ObjPrograma.RefTraspaso

                        .Bandera = 7
                        .Fecha_Resolucion = Today
                        .Resolucion = txtResolucion.Text
                        .ActualizarComMatriz()
                    End If


                    'Dim dt As New DataTable
                    'Dim dr As DataRow
                    Dim bInactivo As Boolean
                    Dim accion As Boolean
                    'dt = grdDoctos.DataSource()
                    'If dt.Rows.Count <> 0 Then
                    'Dim archivo As String
                    Dim indice As Integer
                    Dim nombre As String
                    Dim comitepath As String
                    'For Each dr In dt.Rows
                    '*****************************************Copia los Doctos a la carpeta
                    .Bandera = 4
                    .Id_tipo_doc = 5
                    .Documento = txtDocto.Text
                    .RefA�o = ObjPrograma.RefA�o
                    .RefComite = ObjPrograma.RefComite
                    .RefConsecutivo = ObjPrograma.RefConsecutivo
                    .RefRegreso = ObjPrograma.RefRegreso
                    .RefTraspaso = ObjPrograma.RefTraspaso
                    .Id_tipo_doc = 5
                    .Activo = True
                    .Status = 1
                    .Documento = txtDocto.Text
                    ObjPrograma.Buscar(array_texto(1), array_texto(2))
                    comitepath = ObjPrograma.ID_Comite
                    If ObjPrograma.ID_CT <> "NA" Or ObjPrograma.ID_CT <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_CT
                    If ObjPrograma.ID_SC <> "NA" Or ObjPrograma.ID_SC <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_SC
                    If ObjPrograma.ID_Grupo <> "NA" Or ObjPrograma.ID_Grupo <> "" Then comitepath = comitepath + "\" + ObjPrograma.ID_Grupo
                    ruta = myStream

                    Dim server = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")
                    Dim rutaCarpetas = server + "\" + comitepath + "\"
                    Dim sPath = rutaCarpetas + txtDocto.Text

                    'clsCopia.CopiaArchivos_Noticias(dr.Item(3), "c:\ance")
                    'clsCopia.CopiaArchivos(dr.Item(3), "\\ance-dc\Docs_ONN_WWW")

                    ' Prueba de inactiva
                    ' Dim rutaInicial As String
                    ' rutaInicial = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")))
                    If ruta <> txtDocto.Text And Not ruta Is Nothing Then
                        '.Actualizar()

                        ' Prueba de inactiva
                        'archivo = rutaInicial & "\" & comitepath & "\" + txtDocto.Text

                        If File.Exists(sPath) Then
                            If MsgBox("El archivo (" + CStr(sPath) + ") ya existe en el Servidor..." + Chr(13) + Chr(13) + " �Desea sobrescribir el archivo?", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                                File.Delete(sPath)
                                File.Copy(myStream, sPath)
                                .Actualizar()
                            End If
                        Else
                            clsCopia.CopiaArchivos(myStream, sPath, rutaCarpetas)
                            'File.Copy(myStream, sPath)

                            If clsCopia.er = False Then
                                .Actualizar()
                            End If

                        End If
                    End If
                    '****************************************Guarda Doctos en la tabla
                    'Next
                    'End If
                End With
            Catch ex As Exception
                MsgBox("No se encuentra la ruta verifica que existan las carpetas pertinentes dentro de normanet")
            End Try
            Dim resolucion_normal As New Resolucion
            resolucion_normal.MdiParent = Me.MdiParent
            resolucion_normal.Show()
            Me.Dispose()
        End If
    End Sub
#End Region

#Region " Llena TreeView"
    Private Sub llena_TreeView()
        objComentarios.Bandera = 2
        oTablaPNN = objComentarios.Buscar_PNN
        'oTablaPNN = x.ListaPNN("")

        tvPNN.Nodes.Clear()
        tvPNN.BeginUpdate()

        nodo = tvPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            objComentarios.Bandera = 11
            objComentarios.Id_Plan = RegPNN("id_plan")
            oTablaDPy = objComentarios.Buscar_PNN
            ' oTablaDPy = x.Temas_Resolucion_Alter(RegPNN("id_plan"))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                objComentarios.Bandera = 402
                objComentarios.Id_Plan = RegPNN("id_plan")
                objComentarios.Id_Tema = RegDPy("id_tema")
                DtCom = objComentarios.Buscar_PNN
                nodo1.ImageIndex = 5
                nodo1.SelectedImageIndex = 5
                If DtCom.Rows.Count <> 0 Then
                    For Each Com In DtCom.Rows
                        'nodo2 = nodo1.Nodes.Add(Com("Id_Comentario"))
                        nodo2 = nodo1.Nodes.Add("COM" + Format$(Com("Id_Comentario"), "0000"))
                        nodo2.ImageIndex = 6
                        nodo2.SelectedImageIndex = 6
                    Next
                Else
                    objComentarios.Id_Etapa = 4
                    objComentarios.Bandera = 8
                    DtCom = Nothing
                    DtCom = objComentarios.Buscar_ComMatriz
                    If DtCom.Rows.Count <> 0 Then
                        For Each Com In DtCom.Rows
                            nodo2 = nodo1.Nodes.Add("COMATRIZ0001")
                            nodo2.ImageIndex = 6
                            nodo2.SelectedImageIndex = 6
                        Next
                    End If
                End If
            Next
        Next
        tvPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvPNN.Sorted = True

    End Sub
#End Region

#Region "  Subir documento"
    Private Sub lblSubirDocto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim archivo, namearch As Array
        Dim indice As Integer
        Dim dtAgrega As New DataTable
        Dim drAgrega As DataRow      '
        Dim dt As New DataTable
        'dtAgrega = 
        'grdDoctos.DataSource()
        OpenFileDialog1.Filter = "Todos los archivos (*.*)|*.*"
        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.ShowDialog()
        ruta = OpenFileDialog1.FileName
        archivo = Split(ruta, "\")
        indice = dtAgrega.Rows.Count
        objComentarios.Bandera = 7
        dt = objComentarios.ListaGridDoctos
        namearch = Split(archivo(Len(archivo) - 1), ".")
        txtDocto.Text = "TEMRCN_" + Mid(txtPNN.Text, txtPNN.TextLength - 4) + Format(CInt(dt.Rows(0).Item(0)), "0000") + "." + namearch(namearch.Length - 1)

        If txtDocto.Text <> "" Then

            'Dim dvAgrega As DataView

            drAgrega = dtAgrega.NewRow
            drAgrega("id_plan") = txtPNN.Text
            drAgrega("id_tema") = txtTema.Text
            drAgrega("Id_tipo_doc") = 5
            drAgrega("Documento") = ruta
            drAgrega("namedoc") = txtDocto.Text
            drAgrega("Activo") = 1
            dtAgrega.Rows.Add(drAgrega)
            'grdDoctos.DataSource = dtAgrega
            'grdDoctos.Refresh()

            'txtFecha.Text = Format(Now, "dd/MM/yyyy") 'este es aparte del grid
        End If
    End Sub
#End Region

#Region " Formato Grid "
    Sub Formato_Grid(ByVal grd As Object)
        Dim dgEstiloGrid As New DataGridTableStyle
        With dgEstiloGrid
            .AlternatingBackColor = Color.GhostWhite
            .BackColor = Color.GhostWhite
            .ForeColor = Color.MidnightBlue
            .GridLineColor = Color.RoyalBlue
            .HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .HeaderForeColor = Color.Lavender
            .SelectionBackColor = Color.Teal
            .SelectionForeColor = Color.PaleGreen
            .RowHeaderWidth = 15 'ajusta el tama�o de la columna de la izquierda que trae el grid
            .RowHeadersVisible = False
            .ColumnHeadersVisible = False
            .MappingName = "P_Prog_Trab_Documentos" 'el nombre que regresa el dataset
            '.ReadOnly = True
        End With
        Call Tabla_Color(dgEstiloGrid, grd)
        Dim ColEstilo0 As New DataGridTextBoxColumn '
        Dim ColEstilo1 As New DataGridBoolColumn ' 
        Dim ColEstilo2 As New DataGridTextBoxColumn ' 
        Dim ColEstilo3 As New DataGridTextBoxColumn ' 
        Dim ColEstilo4 As New DataGridBoolColumn ' 
        Dim ColEstilo5 As New DataGridTextBoxColumn ' 

        With ColEstilo0 'PLAN
            .MappingName = "id_Plan"
            .HeaderText = "id_Plan"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEstilo1 'TEMA
            .MappingName = "id_Tema"
            .HeaderText = "id_Tema"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEstilo2 'ID_TIPO_DOC
            .MappingName = "id_tipo_doc"
            .HeaderText = "id_tipo_doc"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEstilo3 'DOCUMENTO
            .MappingName = "namedoc"
            .HeaderText = "Documento"
            .Width = 450
            .ReadOnly = True 'este se muestra en el grid
        End With

        With ColEstilo4 'ACTIVO
            .MappingName = "Activo"
            .HeaderText = "Activo"
            .Width = 70
            .FalseValue = False
            .NullValue = False
            .TrueValue = True
            '.ReadOnly = True 'este se muestra en el grid
        End With

        With ColEstilo5 'DOCUMENTO
            .MappingName = "ID_Cometario"
            .HeaderText = "ID_Cometario"
            .Width = 0
            .ReadOnly = True 'este se muestra en el grid
        End With

        dgEstiloGrid.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEstilo0, ColEstilo1, ColEstilo2, ColEstilo3, ColEstilo4, ColEstilo5})
        grd.TableStyles.Add(dgEstiloGrid)
    End Sub
#End Region

#Region "  Llena Grid"
    Sub Llena_GridDocto(ByVal grd As Object)
        If objComentarios.ListaGridDoctos Is Nothing Then
            Exit Sub
        End If
        grd.DataSource = objComentarios.ListaGridDoctos
        grd.readonly = False
    End Sub
#End Region

    Private Sub dtkFecPublicacionConsulta_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecPublicacionConsulta.ValueChanged
        txtFecPublicacionConsulta.Text = dtkFecPublicacionConsulta.Value
    End Sub
    Private Sub dtkFecLimiteComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecLimiteComentarios.ValueChanged
        txtFecLimiteComentarios.Text = dtkFecLimiteComentarios.Value
    End Sub
    Private Sub dtkFecLimiteAnalisisComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecLimiteAnalisisComentarios.ValueChanged
        txtFecLimiteAnalisisComentarios.Text = dtkFecLimiteAnalisisComentarios.Value
    End Sub
    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(array_texto(1), array_texto(2))
        srefp = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
    End Sub
    Private Sub tvPNN_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles tvPNN.BeforeExpand
        tvPNN.SelectedImageIndex = 1
    End Sub

    '#Region "  chk SUBIR DOCUMENTO"""
    '    Private Sub chkSubirDocto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '        If sTipoProceso = "Agregar" Then
    '            ''If chkAdoptada.Checked = True Then
    '            ''    Activos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada) ', grdAdoptada)
    '            ''    grdAdoptada.ReadOnly = False
    '            ''ElseIf chkAdoptada.Checked = False Then
    '            ''    Inactivos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada, grdAdoptada)
    '            ''    grdAdoptada.ReadOnly = True
    '            ''    Dim dtLimpia As DataTable
    '            ''    dtLimpia = grdAdoptada.DataSource
    '            ''    dtLimpia.Rows.Clear()
    '            ''End If
    '        ElseIf sTipoProceso = "Editar" Then
    '            If chkSubirDocto.Checked = True Then
    '                objComentarios.Id_Tema = Nothing
    '                objComentarios.Id_Plan = Nothing
    '                objComentarios.Id_Comentario = Nothing
    '                objComentarios.Bandera = 7
    '                'Call Formato_Grid(grdDoctos)
    '                'Call Llena_GridDocto(grdDoctos)
    '                Inactivos(cmdSubirDocto)
    '                ''Inactivos(grdAdoptada)
    '                'grdDoctos.ReadOnly = True
    '                Activos(cmdSubirDocto)
    '                'Activos(grdDoctos)

    '            ElseIf chkSubirDocto.Checked = False Then
    '                objComentarios.Id_Tema = txtTema.Text
    '                objComentarios.Id_Plan = txtPNN.Text
    '                objComentarios.Id_Comentario = txtID_Comentarios.Text    'CInt(txtComentario.Text)
    '                objComentarios.Id_tipo_doc = 5
    '                objComentarios.Bandera = 7
    '                ''Call Formato_Grid(grdDoctos)
    '                'Call Llena_GridDocto(grdDoctos)
    '                'grdDoctos.ReadOnly = False
    '            End If
    '        End If
    '    End Sub
    '#End Region

    Private Sub cmdSubirDocto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSubirDocto.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String
        Dim sExt As String
        Dim idCom As String

        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.pdf)|*.pdf|(*.doc)|*.doc|(*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True

        Archivo = myStream = ""
        iIndice = 0
        idCom = array_texto(3)

        splan = array_texto(1)
        stema = array_texto(2)
        Referenciar("abandono")

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream = openFileDialog1.FileName()
            If Not (myStream = "") Then
                For iIndice = Len(myStream) To 1 Step -1
                    If Mid(myStream, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'SDocumento = "TEMRPN" + "_" + Format(ObjPrograma.Id_Tema, "0000") + "_1" + Part
                SDocumento = "TEMRPN_" + Mid(ObjPrograma.Id_Plan, ObjPrograma.Id_Plan.Length - 4) + Format(ObjPrograma.Id_Tema, "0000") + Mid(idCom, idCom.Length - 1) + Part

                txtDocto.Text = SDocumento
                Activos(cmdVerMatriz)
            End If
        End If
    End Sub

    'Private Sub cmdSubirDocto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSubirDocto.Click
    '    Dim archivo As String
    '    Dim indice As Integer
    '    Dim dtAgrega As New DataTable
    '    Dim drAgrega As DataRow
    '    Dim dt As New DataTable
    '    Dim iIndice As Integer = 0
    '    Dim sext As String
    '    Dim sext2 As String
    '    OpenFileDialog1.FilterIndex = 1
    '    OpenFileDialog1.ShowDialog()
    '    ruta = OpenFileDialog1.FileName
    '    'archivo = Split(ruta, "\")
    '    dtAgrega = grdDoctos.DataSource
    '    indice = dtAgrega.Rows.Count
    '    objComentarios.Bandera = 42
    '    objComentarios.Id_Plan = array_texto(1)
    '    objComentarios.Id_Tema = array_texto(2)
    '    dt = objComentarios.ListaGridDoctos
    '    'namearch = Split(archivo(Len(archivo) - 1), ".")
    '    Try
    '        For iIndice = Len(ruta) To 1 Step -1
    '            If Mid(ruta, iIndice, 1) = "\" Then
    '                archivo = Mid(ruta, iIndice + 1)
    '                iIndice = 1
    '            End If
    '        Next iIndice
    '        sext = Len(archivo)
    '        Dim Part As String
    '        Part = Mid(archivo, CInt(sext - 3), 4)
    '        Dim pnn As New TextBox
    '        pnn.Text = array_texto(1)
    '        Dim longCampo As Integer
    '        Dim Consecutivo As Integer
    '        Dim textTemp As String
    '        Dim partAnt As String


    '        ''If txtDocto.Text <> "" Then
    '        ''    Consecutivo = Replace(Mid(txtDocto.Text, 13), Part, "") + 1
    '        ''    txtDocto.Text = "TEMRPN_" + Mid(array_texto(1), pnn.TextLength - 4) + Format(Consecutivo, "0000") + Part
    '        ''Else
    '        ''    txtDocto.Text = "TEMRPN_" + Mid(array_texto(1), pnn.TextLength - 4) + Format(CInt(dt.Rows.Count), "0000") + Part
    '        ''End If

    '        Dim temporal As String
    '        If txtDocto.Text <> "" Then
    '            sext2 = Len(txtDocto.Text)
    '            partAnt = Mid(txtDocto.Text, CInt(sext2 - 3), 4)
    '            temporal = Replace(Mid(txtDocto.Text, 13), partAnt, "")
    '            Consecutivo = CInt(temporal) + 1
    '            txtDocto.Text = "TEMRPN_" + Mid(array_texto(1), pnn.TextLength - 4) + Format(Consecutivo, "0000") + Part
    '        Else
    '            txtDocto.Text = "TEMRPN_" + Mid(array_texto(1), pnn.TextLength - 4) + Format(CInt(dt.Rows.Count), "0000") + Part
    '        End If

    '        If txtDocto.Text <> "" Then
    '            'Dim dvAgrega As DataView
    '            drAgrega = dtAgrega.NewRow
    '            drAgrega("id_plan") = array_texto(1)
    '            drAgrega("id_tema") = array_texto(2)
    '            drAgrega("Id_tipo_doc") = 5
    '            drAgrega("Documento") = ruta
    '            drAgrega("namedoc") = txtDocto.Text
    '            drAgrega("Activo") = 1
    '            dtAgrega.Rows.Add(drAgrega)
    '            grdDoctos.DataSource = dtAgrega
    '            grdDoctos.Refresh()

    '            txtFecha.Text = Format(Now, "dd/MM/yyyy") 'este es aparte del grid
    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub

End Class

