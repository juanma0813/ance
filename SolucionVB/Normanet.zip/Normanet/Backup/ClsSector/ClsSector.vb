
'*************************************************************************************
'Clase C_Sector Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 27/07/2006 02:48:18 p.m.
'*************************************************************************************


Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class ClsSector

    '''''''Declaracion de Variables Privadas
    Private dsC_Sector As New DataSet
    Private cn As New SqlConnection
    Private _Bandera As Integer
    Private _ID_Sector As Integer
    Private _Descripcion As String
    Private _Error As String
    Private _Inactivo As Integer
    Private sSql As String
    Dim objconexion1 As New clsConexion.cIsConexion

    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        objconexion1.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
        cn.ConnectionString = "Data source = " + objconexion1.Server + "; Initial Catalog = " + objconexion1.Base + "; User Id = " + Usuario + "; Pwd =  " + Password

    End Sub

    '''''''Declaracion de Propiedades publicas
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property ID_Sector() As Integer
        Get
            Return _ID_Sector
        End Get
        Set(ByVal Value As Integer)
            _ID_Sector = Value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As String)
            _Descripcion = Value
        End Set
    End Property
    Public Property pError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property
    Public Property Inactivo() As Integer
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Integer)
            _Inactivo = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Sector_Buscar" 'Cargo
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera) '2
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Sector")

        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return ex
        End Try

    End Function

    Public Function Listar() As DataTable
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Sector_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera) '2
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Sector")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return Nothing
        End Try
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar()
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM C_Sector WHERE ID_Sector =" & _ID_Sector
        Dim cmd As New SqlCommand(sSql, cn)
        Dim dr As SqlDataReader
        If cn.State = 1 Then cn.Close()
        cn.Open()
        dr = cmd.ExecuteReader
        If dr.Read Then
            _ID_Sector = dr("ID_Sector")
            _Descripcion = dr("Descripcion")
            _Inactivo = dr("Inactivo")
        Else
            _ID_Sector = ""
            _Descripcion = ""
            _Inactivo = Nothing
        End If
    End Sub
    Public Function maxi() As Integer
        Dim cmd As New SqlCommand

        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Sector_Buscar"
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cn.Open()
            Dim dr As SqlDataAdapter
            dr = New SqlDataAdapter(cmd)
            Dim dt As New DataTable("C_Sector")
            Dim iContador As Integer
            iContador = cmd.ExecuteScalar
            'dr.Fill(dt)
            cn.Close()
            Return iContador
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        '''sSql = "UPDATE C_Sector SET Descripcion = @Descripcion, Where (ID_Sector = @ID_Sector)"
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_sector"
            .Parameters.Add("@ID_Sector", _ID_Sector)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Inactivo", _Inactivo)
        End With

        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close() 'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function

    Public Function Eliminar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_sector"
            .Parameters.Add("@ID_Sector", _ID_Sector)
            .Parameters.Add("@Bandera", 3)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        '
    End Function

    Public Function Insertar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_sector"
            .Parameters.Add("@ID_Sector", _ID_Sector)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", 1)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        '
    End Function
End Class


