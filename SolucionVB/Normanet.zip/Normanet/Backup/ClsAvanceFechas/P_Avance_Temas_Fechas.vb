
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Avance_Temas_Fechas Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 18/10/2006 05:32:10 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Avance_Temas_Fechas

     '''''''Declaracion de Variables Privadas
     Private dsP_Avance_Temas_Fechas AS New DataSet
    Private _Id_Plan As String
    Private _Id_Tema As Integer
    Private _F_Inic_Desarrollo_Nmx As String
    Private _F_Aprob_Revisión_Editorial As String
    Private _F_Carga_DtFinal As String
    Private _F_Impresion_ActaAprobacion As String
    Private _F_Carga_ActaAprobacion As String
    Private _F_Aprobacion_CTGT_ANT As String
    Private _F_Aprobacion_Comite_PROY As String
    Private _F_Publicacion_ComentarioPublico As String
    Private _F_Limite_ComentarioPublico As String
    Private _F_Resolucion_ComentarioPublico As String
    Private _F_Limite_Aprobacion_Resolucion_ComentarioPublico As String
    Private _F_Aprobacion_Resolucion_ComentarioPublico As String
    Private _F_VoBo_CONANCE As String
    Private _F_Inicio_Revision_PROYF As String
    Private _F_Termino_Revision_PROYF As String
    Private _F_Edicion_PROYF As String
    Private _F_Impresion_ActaAprobacion_PROYF As String
    Private _F_Carga_ActaAprobacion_PROYF As String
    Private _F_ACUSE_DGN_PROYF As String
    Private _F_CARGA_PROYF As String
    Private _F_CARGA_ANTF As String
    Private _F_Carga_minuta_Apro As String
    Private _BANDERA As Integer
    Private _date1 As String
    Private _date2 As String
    Private _tipo As String
    Private sSql As String

    Private _F_carga_minuta As String
    Private _Ref_Año As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _Encontrado As Boolean
    Private _Status As Integer
    Private _sReferencia As String
    Private _F_VerifRev_PROYF As String
    Private _F_Amp_Resolucion As String
    Private _sEtapa As String

    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

    '''''''Declaracion de Propiedades publicas
    Public Property Id_Plan() As String
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value As String)
            _Id_Plan = Value
        End Set
    End Property

    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property

    Public Property Id_Tema() As Integer
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value As Integer)
            _Id_Tema = Value
        End Set
    End Property

    Public Property date1() As String
        Get
            Return _date1
        End Get
        Set(ByVal Value As String)
            _date1 = Value
        End Set
    End Property

    Public Property date2() As String
        Get
            Return _date2
        End Get
        Set(ByVal Value As String)
            _date2 = Value
        End Set
    End Property

    Public Property BANDERA() As Integer
        Get
            Return _BANDERA
        End Get
        Set(ByVal Value As Integer)
            _BANDERA = Value
        End Set
    End Property

    Public Property sEtapa() As String
        Get
            Return _sEtapa
        End Get
        Set(ByVal Value As String)
            _sEtapa = Value
        End Set
    End Property


    Public Property F_Inic_Desarrollo_Nmx() As String
        Get
            If _F_Inic_Desarrollo_Nmx Is Nothing Then
                Return ""
            Else
                Return _F_Inic_Desarrollo_Nmx
            End If
            Return _F_Inic_Desarrollo_Nmx
        End Get

        Set(ByVal Value As String)
            _F_Inic_Desarrollo_Nmx = Value
        End Set
    End Property
    Public Property F_Aprob_Revisión_Editorial() As String
        Get
            If _F_Aprob_Revisión_Editorial Is Nothing Then
                Return ""
            Else
                Return _F_Aprob_Revisión_Editorial
            End If

        End Get
        Set(ByVal Value As String)
            _F_Aprob_Revisión_Editorial = Value
        End Set
    End Property

    Public Property F_Carga_minuta_Apro() As String
        Get
            Return _F_Carga_minuta_Apro
        End Get
        Set(ByVal Value As String)
            _F_Carga_minuta_Apro = Value
        End Set
    End Property

    Public Property F_Carga_DtFinal() As String
        Get
            If _F_Carga_DtFinal Is Nothing Then
                Return ""
            Else
                Return _F_Carga_DtFinal
            End If

        End Get
        Set(ByVal Value As String)
            _F_Carga_DtFinal = Value
        End Set
    End Property

    Public Property F_Impresion_ActaAprobacion() As String
        Get
            If _F_Impresion_ActaAprobacion Is Nothing Then
                Return ""
            Else
                Return _F_Impresion_ActaAprobacion
            End If

        End Get
        Set(ByVal Value As String)
            _F_Impresion_ActaAprobacion = Value
        End Set
    End Property

    Public Property F_Carga_ActaAprobacion() As String
        Get
            If _F_Carga_ActaAprobacion Is Nothing Then
                Return ""
            Else
                Return _F_Carga_ActaAprobacion
            End If

        End Get
        Set(ByVal Value As String)
            _F_Carga_ActaAprobacion = Value
        End Set
    End Property

    Public Property F_Aprobacion_CTGT_ANT() As String
        Get
            If _F_Aprobacion_CTGT_ANT Is Nothing Then
                Return ""
            Else
                Return _F_Aprobacion_CTGT_ANT
            End If

        End Get
        Set(ByVal Value As String)
            _F_Aprobacion_CTGT_ANT = Value
        End Set
    End Property

    Public Property F_Aprobacion_Comite_PROY() As String
        Get
            If _F_Aprobacion_Comite_PROY Is Nothing Then
                Return ""
            Else
                Return _F_Aprobacion_Comite_PROY
            End If

        End Get
        Set(ByVal Value As String)
            _F_Aprobacion_Comite_PROY = Value
        End Set
    End Property

    Public Property F_Publicacion_ComentarioPublico() As String
        Get
            If _F_Publicacion_ComentarioPublico Is Nothing Then
                Return ""
            Else
                Return _F_Publicacion_ComentarioPublico
            End If

        End Get
        Set(ByVal Value As String)
            _F_Publicacion_ComentarioPublico = Value
        End Set
    End Property

    Public Property F_Limite_ComentarioPublico() As String
        Get
            If _F_Limite_ComentarioPublico Is Nothing Then
                Return ""
            Else
                Return _F_Limite_ComentarioPublico
            End If
        End Get
        Set(ByVal Value As String)
            _F_Limite_ComentarioPublico = Value
        End Set
    End Property

    Public Property F_Resolucion_ComentarioPublico() As String
        Get
            If _F_Resolucion_ComentarioPublico Is Nothing Then
                Return ""
            Else
                Return _F_Resolucion_ComentarioPublico
            End If

        End Get
        Set(ByVal Value As String)
            _F_Resolucion_ComentarioPublico = Value
        End Set
    End Property

    Public Property F_Limite_Aprobacion_Resolucion_ComentarioPublico() As String
        Get
            If _F_Limite_Aprobacion_Resolucion_ComentarioPublico Is Nothing Then
                Return ""
            Else
                Return _F_Limite_Aprobacion_Resolucion_ComentarioPublico
            End If

        End Get
        Set(ByVal Value As String)
            _F_Limite_Aprobacion_Resolucion_ComentarioPublico = Value
        End Set
    End Property

    Public Property F_Aprobacion_Resolucion_ComentarioPublico() As String
        Get
            If _F_Aprobacion_Resolucion_ComentarioPublico Is Nothing Then
                Return ""
            Else
                Return _F_Aprobacion_Resolucion_ComentarioPublico
            End If

        End Get
        Set(ByVal Value As String)
            _F_Aprobacion_Resolucion_ComentarioPublico = Value
        End Set
    End Property

    Public Property F_VoBo_CONANCE() As String
        Get
            If _F_VoBo_CONANCE Is Nothing Then
                Return ""
            Else
                Return _F_VoBo_CONANCE
            End If
        End Get
        Set(ByVal Value As String)
            _F_VoBo_CONANCE = Value
        End Set
    End Property

    Public Property F_Inicio_Revision_PROYF() As String
        Get
            If _F_Inicio_Revision_PROYF Is Nothing Then
                Return ""
            Else
                Return _F_Inicio_Revision_PROYF
            End If
        End Get
        Set(ByVal Value As String)
            _F_Inicio_Revision_PROYF = Value
        End Set
    End Property

    Public Property F_Termino_Revision_PROYF() As String
        Get
            If _F_Termino_Revision_PROYF Is Nothing Then

            Else
                Return _F_Termino_Revision_PROYF
            End If

        End Get
        Set(ByVal Value As String)
            _F_Termino_Revision_PROYF = Value
        End Set
    End Property

    Public Property F_Edicion_PROYF() As String
        Get
            If _F_Edicion_PROYF Is Nothing Then
                Return ""
            Else
                Return _F_Edicion_PROYF
            End If

        End Get
        Set(ByVal Value As String)
            _F_Edicion_PROYF = Value
        End Set
    End Property

    Public Property F_Impresion_ActaAprobacion_PROYF() As String
        Get
            If _F_Impresion_ActaAprobacion_PROYF Is Nothing Then
                Return ""
            Else
                Return _F_Impresion_ActaAprobacion_PROYF
            End If

        End Get
        Set(ByVal Value As String)
            _F_Impresion_ActaAprobacion_PROYF = Value
        End Set
    End Property

    Public Property F_Carga_ActaAprobacion_PROYF() As String
        Get
            If _F_Carga_ActaAprobacion_PROYF Is Nothing Then
                Return ""
            Else
                Return _F_Carga_ActaAprobacion_PROYF
            End If

        End Get
        Set(ByVal Value As String)
            _F_Carga_ActaAprobacion_PROYF = Value
        End Set
    End Property

    Public Property F_ACUSE_DGN_PROYF() As String
        Get
            If _F_ACUSE_DGN_PROYF Is Nothing Then
                Return ""
            Else
                Return _F_ACUSE_DGN_PROYF
            End If

        End Get
        Set(ByVal Value As String)
            _F_ACUSE_DGN_PROYF = Value
        End Set
    End Property

    Public Property F_CARGA_PROYF() As String
        Get
            If _F_CARGA_PROYF Is Nothing Then
                Return ""
            Else
                Return _F_CARGA_PROYF
            End If

        End Get
        Set(ByVal Value As String)
            _F_CARGA_PROYF = Value
        End Set
    End Property
    Public Property F_CARGA_ANTF() As String
        Get
            If _F_CARGA_ANTF Is Nothing Then
                Return ""
            Else
                Return _F_CARGA_ANTF
            End If

        End Get
        Set(ByVal Value As String)
            _F_CARGA_ANTF = Value
        End Set
    End Property
    Public Property F_carga_minuta() As String
        Get
            Return _F_carga_minuta
        End Get
        Set(ByVal Value As String)
            _F_carga_minuta = Value
        End Set
    End Property
    Public Property Tipo() As String
        Get
            Return _tipo
        End Get
        Set(ByVal Value As String)
            _tipo = Value
        End Set
    End Property
    Public Property RefAño() As String
        Get
            Return _Ref_Año
        End Get
        Set(ByVal Value As String)
            _Ref_Año = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property

    Public Property Status() As Integer
        Get
            Return _Status
        End Get
        Set(ByVal Value As Integer)
            _Status = Value
        End Set
    End Property
    Public Property F_VerifRev_PROYF() As String
        Get
            Return _F_VerifRev_PROYF
        End Get
        Set(ByVal Value As String)
            _F_VerifRev_PROYF = Value
        End Set
    End Property

    Public Property F_Amp_Resolucion() As String
        Get
            Return _F_Amp_Resolucion
        End Get
        Set(ByVal Value As String)
            _F_Amp_Resolucion = Value
        End Set
    End Property
    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub
    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Avance_Temas_Fechas")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function


    '''''''''''''''''Genera una la lista de campos
    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Fechas_Avance_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@date1", _date1)
        cmd.Parameters.Add("@date2", _date2)
        cmd.Parameters.Add("@Bandera", _BANDERA)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsFechasAvance")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt

        Catch ex As Exception
            Return dt
        End Try

    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sTema As String, ByVal splan As String, ByVal sref As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT *  FROM dbo.P_Avance_Temas_Fechas INNER JOIN P_Prog_Trab ON dbo.P_Avance_Temas_Fechas.Id_Plan = dbo.P_Prog_Trab.Id_Plan AND P_Avance_Temas_Fechas.Id_Tema = dbo.P_Prog_Trab.Id_Tema WHERE status <> 10 and status <> 11"
        sSql = sSql + " and P_Prog_Trab.id_tema='" & sTema & "' and P_Prog_Trab.id_plan='" & splan & "' and P_Prog_Trab.ID_etapa <> 0"
        sSql = sSql + " and P_Avance_Temas_Fechas.ref_año + P_Avance_Temas_Fechas.ref_comite + P_Avance_Temas_Fechas.ref_consecutivo + P_Avance_Temas_Fechas.ref_regreso + P_Avance_Temas_Fechas.ref_traspaso = '" & sref & "'"

        If _tipo = "abandono" Then sSql = sSql + "Order by P_Avance_Temas_Fechas.ref_regreso desc"
        If _tipo = "traspaso" Then sSql = sSql + "Order by P_Avance_Temas_Fechas.ref_regreso desc"

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            da.Fill(dsP_Avance_Temas_Fechas, "C_Encontrado")
            If dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows.Count > 0 Then
                _BANDERA = True

                _Ref_Traspaso = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))
                _Ref_Año = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Año")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Año"))
                _Ref_Comite = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
                _Ref_Regreso = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
                _Ref_Consecutivo = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
                _Status = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Status")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Status"))

                _Id_Plan = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Id_Plan")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Id_Plan"))
                _Id_Tema = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Id_Tema")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("Id_Tema"))
                _F_Inic_Desarrollo_Nmx = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Inic_Desarrollo_Nmx")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Inic_Desarrollo_Nmx"))
                _F_Aprob_Revisión_Editorial = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprob_Revisión_Editorial")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprob_Revisión_Editorial"))
                _F_Carga_DtFinal = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_DtFinal")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_DtFinal"))
                _F_Impresion_ActaAprobacion = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Impresion_ActaAprobacion")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Impresion_ActaAprobacion"))
                _F_Carga_ActaAprobacion = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_ActaAprobacion")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_ActaAprobacion"))
                _F_Aprobacion_CTGT_ANT = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_CTGT_ANT")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_CTGT_ANT"))
                _F_Aprobacion_Comite_PROY = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_Comite_PROY")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_Comite_PROY"))
                _F_Publicacion_ComentarioPublico = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Publicacion_ComentarioPublico")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Publicacion_ComentarioPublico"))
                _F_Limite_ComentarioPublico = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Limite_ComentarioPublico")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Limite_ComentarioPublico"))
                _F_Resolucion_ComentarioPublico = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Resolucion_ComentarioPublico")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Resolucion_ComentarioPublico"))
                _F_Limite_Aprobacion_Resolucion_ComentarioPublico = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Limite_Aprobacion_Resolucion_ComentarioPublico")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Limite_Aprobacion_Resolucion_ComentarioPublico"))
                _F_Aprobacion_Resolucion_ComentarioPublico = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_Resolucion_ComentarioPublico")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_Resolucion_ComentarioPublico"))
                _F_VoBo_CONANCE = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_VoBo_CONANCE")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_VoBo_CONANCE"))
                _F_Inicio_Revision_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Revision_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Revision_PROYF"))
                _F_Termino_Revision_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Termino_Revision_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Termino_Revision_PROYF"))
                _F_Edicion_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Edicion_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Edicion_PROYF"))
                _F_Impresion_ActaAprobacion_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Impresion_ActaAprobacion_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Impresion_ActaAprobacion_PROYF"))
                _F_Carga_ActaAprobacion_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_ActaAprobacion_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_ActaAprobacion_PROYF"))
                _F_ACUSE_DGN_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_ACUSE_DGN_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_ACUSE_DGN_PROYF"))
                _F_CARGA_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_CARGA_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_CARGA_PROYF"))
                _F_CARGA_ANTF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_CARGA_ANTF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_CARGA_ANTF"))
                _F_Carga_minuta_Apro = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_minuta_Apro")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Carga_minuta_Apro"))
                _F_VerifRev_PROYF = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_VerifRev_PROYF")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_VerifRev_PROYF"))
                _F_Amp_Resolucion = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Amp_Resolucion")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Amp_Resolucion"))
                _F_Aprobacion_CTGT_ANT = IIf(IsDBNull(dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_CTGT_ANT")) = True, Nothing, dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Rows(0).Item("F_Aprobacion_CTGT_ANT"))
                _Encontrado = True
            Else
                _Id_Plan = ""
                _Id_Tema = 0
                _F_Inic_Desarrollo_Nmx = Nothing
                _F_Aprob_Revisión_Editorial = Nothing
                _F_Carga_DtFinal = Nothing
                _F_Impresion_ActaAprobacion = Nothing
                _F_Carga_ActaAprobacion = Nothing
                _F_Aprobacion_CTGT_ANT = Nothing
                _F_Aprobacion_Comite_PROY = Nothing
                _F_Publicacion_ComentarioPublico = Nothing
                _F_Limite_ComentarioPublico = Nothing
                _F_Resolucion_ComentarioPublico = Nothing
                _F_Limite_Aprobacion_Resolucion_ComentarioPublico = Nothing
                _F_Aprobacion_Resolucion_ComentarioPublico = Nothing
                _F_VoBo_CONANCE = Nothing
                _F_Inicio_Revision_PROYF = Nothing
                _F_Termino_Revision_PROYF = Nothing
                _F_Edicion_PROYF = Nothing
                _F_Impresion_ActaAprobacion_PROYF = Nothing
                _F_Carga_ActaAprobacion_PROYF = Nothing
                _F_ACUSE_DGN_PROYF = Nothing
                _F_CARGA_PROYF = Nothing
                F_CARGA_ANTF = Nothing
                _BANDERA = False
                _Encontrado = False
                _F_Amp_Resolucion = Nothing
            End If
            dsP_Avance_Temas_Fechas.Tables("C_Encontrado").Clear()

        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try


        cn.Close()

    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza(ByVal Bandera As Integer, ByVal sPlan As String, ByVal sTema As String, ByVal F_Inic_Desarrollo_Nmx As String, ByVal F_Aprob_Revisión_Editorial As String, ByVal F_Carga_DtFinal As String, ByVal F_Impresion_ActaAprobacion As String, ByVal F_Carga_ActaAprobacion As String, ByVal F_Aprobacion_CTGT_ANT As String, ByVal F_Aprobacion_Comite_PROY As String, ByVal F_Publicacion_ComentarioPublico As String, ByVal F_Limite_ComentarioPublico As String, ByVal F_Resolucion_ComentarioPublico As String, ByVal F_Limite_Aprobacion_Resolucion_ComentarioPublico As String, ByVal F_Aprobacion_Resolucion_ComentarioPublico As String, ByVal F_VoBo_CONANCE As String, ByVal F_Inicio_Revision_PROYF As String, ByVal F_Termino_Revision_PROYF As String, ByVal F_Edicion_PROYF As String, ByVal F_Impresion_ActaAprobacion_PROYF As String, ByVal F_Carga_ActaAprobacion_PROYF As String, ByVal F_ACUSE_DGN_PROYF As String, ByVal F_CARGA_PROYF As String, ByVal F_CARGA_ANTF As String) As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Fechas_Avance"

        cmd.Parameters.Add("@Id_Plan", sPlan)
        cmd.Parameters.Add("@Id_Tema", sTema)
        cmd.Parameters.Add("@F_Inic_Desarrollo_Nmx", IIf(F_Inic_Desarrollo_Nmx = "" = True, Nothing, F_Inic_Desarrollo_Nmx))
        cmd.Parameters.Add("@F_Aprob_Revisión_Editorial", IIf(F_Aprob_Revisión_Editorial = "" = True, Nothing, F_Aprob_Revisión_Editorial))
        cmd.Parameters.Add("@F_Carga_DtFinal", IIf(F_Carga_DtFinal = "" = True, Nothing, F_Carga_DtFinal))

        cmd.Parameters.Add("@F_Impresion_ActaAprobacion", IIf(F_Impresion_ActaAprobacion = "" = True, Nothing, F_Impresion_ActaAprobacion))
        cmd.Parameters.Add("@F_Carga_ActaAprobacion", IIf(F_Carga_ActaAprobacion = "" = True, Nothing, F_Carga_ActaAprobacion))
        cmd.Parameters.Add("@F_Aprobacion_CTGT_ANT", IIf(F_Aprobacion_CTGT_ANT = "" = True, Nothing, F_Aprobacion_CTGT_ANT))
        cmd.Parameters.Add("@F_Aprobacion_Comite_PROY", IIf(F_Aprobacion_Comite_PROY = "" = True, Nothing, F_Aprobacion_Comite_PROY))
        cmd.Parameters.Add("@F_Publicacion_ComentarioPublico", IIf(F_Publicacion_ComentarioPublico = "" = True, Nothing, F_Publicacion_ComentarioPublico))

        cmd.Parameters.Add("@F_Limite_ComentarioPublico", IIf(F_Limite_ComentarioPublico = "" = True, Nothing, F_Limite_ComentarioPublico))
        cmd.Parameters.Add("@F_Resolucion_ComentarioPublico", IIf(F_Resolucion_ComentarioPublico = "" = True, Nothing, F_Resolucion_ComentarioPublico))
        cmd.Parameters.Add("@F_Limite_Aprobacion_Resolucion_ComentarioPublico", IIf(F_Limite_Aprobacion_Resolucion_ComentarioPublico = "" = True, Nothing, F_Limite_Aprobacion_Resolucion_ComentarioPublico))
        cmd.Parameters.Add("@F_Aprobacion_Resolucion_ComentarioPublico", IIf(F_Aprobacion_Resolucion_ComentarioPublico = "" = True, Nothing, F_Aprobacion_Resolucion_ComentarioPublico))
        cmd.Parameters.Add("@F_VoBo_CONANCE", IIf(F_VoBo_CONANCE = "" = True, Nothing, F_VoBo_CONANCE))

        cmd.Parameters.Add("@F_Inicio_Revision_PROYF", IIf(F_Inicio_Revision_PROYF = "" = True, Nothing, F_Inicio_Revision_PROYF))
        cmd.Parameters.Add("@F_Termino_Revision_PROYF", IIf(F_Termino_Revision_PROYF = "" = True, Nothing, F_Termino_Revision_PROYF))
        cmd.Parameters.Add("@F_Edicion_PROYF", IIf(F_Edicion_PROYF = "" = True, Nothing, F_Edicion_PROYF))
        cmd.Parameters.Add("@F_Impresion_ActaAprobacion_PROYF", IIf(F_Impresion_ActaAprobacion_PROYF = "" = True, Nothing, F_Impresion_ActaAprobacion_PROYF))
        cmd.Parameters.Add("@F_Carga_ActaAprobacion_PROYF", IIf(F_Carga_ActaAprobacion_PROYF = "" = True, Nothing, F_Carga_ActaAprobacion_PROYF))

        cmd.Parameters.Add("@F_ACUSE_DGN_PROYF", IIf(F_ACUSE_DGN_PROYF = "" = True, Nothing, F_ACUSE_DGN_PROYF))
        cmd.Parameters.Add("@F_CARGA_PROYF", IIf(F_CARGA_PROYF = "" = True, Nothing, F_CARGA_PROYF))
        cmd.Parameters.Add("@F_CARGA_ANTF", IIf(F_CARGA_PROYF = "" = True, Nothing, F_CARGA_PROYF))
        cmd.Parameters.Add("@F_VerifRev_PROYF", IIf(F_CARGA_PROYF = "" = True, Nothing, _F_VerifRev_PROYF))

        cmd.Parameters.Add("@Bandera", Bandera)

        cmd.Parameters.Add("@ref_año", _Ref_Año)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)

        cmd.Parameters.Add("@Status", _Status)
        cmd.Parameters.Add("@sReferencia", _sReferencia)

        cmd.Parameters.Add("@F_Amp_Resolucion", _F_Amp_Resolucion)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function Avance_Fechas_Editar_DT(ByVal sTema As String, ByVal sPlan As String, ByVal F_Inic_Desarrollo_Nmx As String, ByVal F_Carga_DtFinal As String, ByVal F_Aprob_Revisión_Editorial As String, ByVal Status As Integer)

        ''ByVal F_Aprob_Revisión_Editorial As String,

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Fechas_Avance_Editar"

        cmd.Parameters.Add("@Bandera", 1)
        If F_Inic_Desarrollo_Nmx <> "" Then F_Inic_Desarrollo_Nmx = Format(CDate(F_Inic_Desarrollo_Nmx), "dd/MM/yyyy")
        cmd.Parameters.Add("@F_Inic_Desarrollo_Nmx", IIf(F_Inic_Desarrollo_Nmx = "", Nothing, F_Inic_Desarrollo_Nmx))

        If F_Aprob_Revisión_Editorial <> "" Then F_Aprob_Revisión_Editorial = Format(CDate(F_Aprob_Revisión_Editorial), "dd/MM/yyyy")
        cmd.Parameters.Add("@F_Aprob_Revisión_Editorial", IIf(F_Aprob_Revisión_Editorial = "", Nothing, F_Aprob_Revisión_Editorial))

        If F_Carga_DtFinal <> "" Then F_Carga_DtFinal = Format(CDate(F_Carga_DtFinal), "dd/MM/yyyy")
        cmd.Parameters.Add("@F_Carga_DtFinal", IIf(F_Carga_DtFinal = "", Nothing, F_Carga_DtFinal))

        If F_Impresion_ActaAprobacion <> "" Then F_Impresion_ActaAprobacion = Format(CDate(F_Impresion_ActaAprobacion), "dd/MM/yyyy")
        cmd.Parameters.Add("@F_Impresion_ActaAprobacion", IIf(F_Impresion_ActaAprobacion = "", Nothing, F_Impresion_ActaAprobacion))

        If F_Carga_ActaAprobacion <> "" Then F_Carga_ActaAprobacion = Format(CDate(F_Carga_ActaAprobacion), "dd/MM/yyyy")
        cmd.Parameters.Add("@F_Carga_ActaAprobacion", IIf(F_Carga_ActaAprobacion = "", Nothing, F_Carga_ActaAprobacion))

        cmd.Parameters.Add("@Id_Etapa", Status)
        cmd.Parameters.Add("@Id_tema", sTema)
        cmd.Parameters.Add("@Id_plan", sPlan)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function
    Public Function Avance_Fechas_Editar_Ant(ByVal sTema As String, ByVal sPlan As String, ByVal id_etapa As Integer, ByVal f_aprobctgt As String, ByVal F_CARGA_ANTF As String, ByVal sref As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Fechas_Avance_Editar"

        cmd.Parameters.Add("@Bandera", 2)
        'cmd.Parameters.Add("@F_Aprobacion_CTGT_ANT", IIf(IsDBNull(f_aprobctgt) = True, Nothing, f_aprobctgt))
        cmd.Parameters.Add("@F_Aprobacion_CTGT_ANT", IIf(f_aprobctgt = "", Nothing, f_aprobctgt))
        cmd.Parameters.Add("@Id_Etapa", IIf(IsDBNull(id_etapa) = True, Nothing, id_etapa))
        cmd.Parameters.Add("@F_CARGA_ANTF", _F_CARGA_ANTF)

        cmd.Parameters.Add("@F_impresion_ActaAprobacion", _F_Impresion_ActaAprobacion)
        cmd.Parameters.Add("@F_Carga_ActaAprobacion", _F_Carga_ActaAprobacion)
        cmd.Parameters.Add("@F_Carga_minuta_Apro", _F_Carga_minuta_Apro)

        cmd.Parameters.Add("@Id_tema", sTema)
        cmd.Parameters.Add("@Id_plan", sPlan)
        cmd.Parameters.Add("@sReferencia", sref)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function Avance_Fechas_Editar_Proy(ByVal sTema As String, ByVal sPlan As String, ByVal id_etapa As Integer, ByVal F_Aprobacion_Comite_PROY As String, ByVal F_Publicacion_ComentarioPublico As String, ByVal F_Limite_ComentarioPublico As String, ByVal F_Resolucion_ComentarioPublico As String, ByVal F_Limite_Aprobacion_Resolucion_ComentarioPublico As String, ByVal F_Aprobacion_Resolucion_ComentarioPublico As String, ByVal F_VoBo_CONANCE As String, ByVal F_Inicio_Revision_PROYF As String, ByVal F_Termino_Revision_PROYF As String, ByVal F_Edicion_PROYF As String, ByVal F_Impresion_ActaAprobacion_PROYF As String, ByVal F_Carga_ActaAprobacion_PROYF As String, ByVal F_ACUSE_DGN_PROYF As String, ByVal F_CARGA_PROYF As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Fechas_Avance_Editar"

        cmd.Parameters.Add("@Bandera", 3)

        cmd.Parameters.Add("@F_Aprobacion_Comite_PROY", IIf(F_Aprobacion_Comite_PROY = "" = True, Nothing, F_Aprobacion_Comite_PROY))
        cmd.Parameters.Add("@F_Publicacion_ComentarioPublico", IIf(F_Publicacion_ComentarioPublico = "", Nothing, F_Publicacion_ComentarioPublico))
        cmd.Parameters.Add("@F_Limite_ComentarioPublico", IIf(F_Limite_ComentarioPublico = "", Nothing, F_Limite_ComentarioPublico))
        cmd.Parameters.Add("@F_Resolucion_ComentarioPublico", IIf(F_Resolucion_ComentarioPublico = "" = True, Nothing, F_Resolucion_ComentarioPublico))
        cmd.Parameters.Add("@F_Limite_Aprobacion_Resolucion_ComentarioPublico", IIf(F_Limite_Aprobacion_Resolucion_ComentarioPublico = "" = True, Nothing, F_Limite_Aprobacion_Resolucion_ComentarioPublico))
        cmd.Parameters.Add("@F_Aprobacion_Resolucion_ComentarioPublico", IIf(F_Aprobacion_Resolucion_ComentarioPublico = "" = True, Nothing, F_Aprobacion_Resolucion_ComentarioPublico))
        cmd.Parameters.Add("@F_VoBo_CONANCE", IIf(F_VoBo_CONANCE = "" = True, Nothing, F_VoBo_CONANCE))
        cmd.Parameters.Add("@F_Inicio_Revision_PROYF", IIf(F_Inicio_Revision_PROYF = "" = True, Nothing, F_Inicio_Revision_PROYF))
        cmd.Parameters.Add("@F_Termino_Revision_PROYF", IIf(F_Termino_Revision_PROYF = "" = True, Nothing, F_Termino_Revision_PROYF))
        cmd.Parameters.Add("@F_Edicion_PROYF", IIf(F_Edicion_PROYF = "" = True, Nothing, F_Edicion_PROYF))
        cmd.Parameters.Add("@F_Impresion_ActaAprobacion_PROYF", IIf(F_Impresion_ActaAprobacion_PROYF = "" = True, Nothing, F_Impresion_ActaAprobacion_PROYF))
        cmd.Parameters.Add("@F_Carga_ActaAprobacion_PROYF", IIf(F_Carga_ActaAprobacion_PROYF = "" = True, Nothing, F_Carga_ActaAprobacion_PROYF))
        cmd.Parameters.Add("@F_ACUSE_DGN_PROYF", IIf(F_ACUSE_DGN_PROYF = "" = True, Nothing, F_ACUSE_DGN_PROYF))
        cmd.Parameters.Add("@F_CARGA_PROYF", IIf(F_CARGA_PROYF = "" = True, Nothing, F_CARGA_PROYF))
        cmd.Parameters.Add("@Id_Etapa", IIf(IsDBNull(id_etapa) = True, Nothing, id_etapa))
        cmd.Parameters.Add("@F_VerifRev_PROYF", IIf(IsDBNull(_F_VerifRev_PROYF) = True, Nothing, _F_VerifRev_PROYF))
        cmd.Parameters.Add("@Id_tema", sTema)
        cmd.Parameters.Add("@Id_plan", sPlan)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        cmd.Parameters.Add("@status", _Status)

        cmd.Parameters.Add("@F_Amp_Resolucion", _F_Amp_Resolucion)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function Insertar(ByVal etapa As String) As String

        Dim cmd As New SqlCommand
        cmd.CommandText = "Sp_Fechas_Avance_Editar"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Ref_Año", _Ref_Año)
        cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
        cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
        cmd.Parameters.Add("@Status", _Status)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Bandera", _BANDERA)
        cmd.Parameters.Add("@sReferencia", _sReferencia)


        If etapa = "DT" Or etapa = "ANT" Then
            cmd.Parameters.Add("@F_Inic_Desarrollo_Nmx", _F_Inic_Desarrollo_Nmx)
            cmd.Parameters.Add("@F_Aprob_Revisión_Editorial", _F_Aprob_Revisión_Editorial)
            cmd.Parameters.Add("@F_Carga_DtFinal", _F_Carga_DtFinal)
        End If

        If etapa = "ANT" Then
            cmd.Parameters.Add("@F_Impresion_ActaAprobacion", _F_Impresion_ActaAprobacion)
            cmd.Parameters.Add("@F_Carga_ActaAprobacion", _F_Carga_ActaAprobacion)
            'cmd.Parameters.Add("@F_Aprobacion_CTGT_ANT", _F_Aprobacion_CTGT_ANT)
            cmd.Parameters.Add("@F_Aprobacion_CTGT_ANT", Nothing)
            cmd.Parameters.Add("@F_Carga_minuta_Apro", _F_Carga_minuta_Apro)
            cmd.Parameters.Add("@F_CARGA_ANTF", _F_CARGA_ANTF)
        End If

        If etapa <> "PT" And etapa <> "DT" And etapa <> "ANT" Then
            cmd.Parameters.Add("@F_Aprobacion_Comite_PROY", _F_Aprobacion_Comite_PROY)
            cmd.Parameters.Add("@F_Publicacion_ComentarioPublico", _F_Publicacion_ComentarioPublico)
            cmd.Parameters.Add("@F_Limite_ComentarioPublico", _F_Limite_ComentarioPublico)
            cmd.Parameters.Add("@F_Resolucion_ComentarioPublico", _F_Resolucion_ComentarioPublico)
            cmd.Parameters.Add("@F_Limite_Aprobacion_Resolucion_ComentarioPublico", _F_Limite_Aprobacion_Resolucion_ComentarioPublico)
            cmd.Parameters.Add("@F_Aprobacion_Resolucion_ComentarioPublico", _F_Aprobacion_Resolucion_ComentarioPublico)
            cmd.Parameters.Add("@F_VoBo_CONANCE", _F_VoBo_CONANCE)
            cmd.Parameters.Add("@F_Inicio_Revision_PROYF", _F_Inicio_Revision_PROYF)
            cmd.Parameters.Add("@F_Termino_Revision_PROYF", _F_Termino_Revision_PROYF)
            cmd.Parameters.Add("@F_Edicion_PROYF", _F_Edicion_PROYF)
            cmd.Parameters.Add("@F_Impresion_ActaAprobacion_PROYF", _F_Impresion_ActaAprobacion_PROYF)
            cmd.Parameters.Add("@F_Carga_ActaAprobacion_PROYF", _F_Carga_ActaAprobacion_PROYF)
            cmd.Parameters.Add("@F_ACUSE_DGN_PROYF", _F_ACUSE_DGN_PROYF)
            cmd.Parameters.Add("@F_CARGA_PROYF", _F_CARGA_PROYF)
            cmd.Parameters.Add("@F_VerifRev_PROYF", _F_VerifRev_PROYF)
            cmd.Parameters.Add("@F_Amp_Resolucion", _F_Amp_Resolucion)
            If etapa = "DT" Then
                cmd.Parameters.Add("@F_Inic_Desarrollo_Nmx", Nothing)
            End If
        End If
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Sub ActualizaRefAnterior(ByVal bande As Integer)
        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "Sp_Fechas_Avance_Editar"
            .CommandType = CommandType.StoredProcedure

            .Parameters.Add("@bandera", bande)
            .Parameters.Add("@ref_año", _Ref_Año)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@sReferencia", _sReferencia)
            If cn.State = 1 Then cn.Close()
            cn.Open()
            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Dim ms
                ms = ex.Message
            End Try
        End With
    End Sub
    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Fechas_Avance"
        cmd.Parameters.Add("@Bandera", 3)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function ActualizaF_DesarrolloNMX()
        Dim cmd As New SqlCommand
        cmd.CommandText = "Sp_Fechas_Avance_Editar"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.Parameters.Add("@sReferencia", sReferencia)
        cmd.Parameters.Add("@Bandera", _BANDERA)
        cmd.Parameters.Add("@F_DesarrolloNMX", _F_Inic_Desarrollo_Nmx)
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function
    Public Sub traspasaFavance(ByVal plan As String, ByVal tema As Integer)
        _Status = 1
        _Id_Plan = plan
        _Id_Tema = tema
        _BANDERA = 8
        _Ref_Traspaso = _Ref_Traspaso + 1
        insertaTodo()
    End Sub
    Public Sub insertaTodo()
        Dim cmd As New SqlCommand
        cmd.CommandText = "Sp_Fechas_Avance_Editar"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Ref_Año", _Ref_Año)
        cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
        cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
        cmd.Parameters.Add("@Status", _Status)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Bandera", _BANDERA)
        cmd.Parameters.Add("@sReferencia", _sReferencia)

        cmd.Parameters.Add("@F_Inic_Desarrollo_Nmx", _F_Inic_Desarrollo_Nmx)
        cmd.Parameters.Add("@F_Aprob_Revisión_Editorial", _F_Aprob_Revisión_Editorial)
        cmd.Parameters.Add("@F_Carga_DtFinal", _F_Carga_DtFinal)

        cmd.Parameters.Add("@F_Impresion_ActaAprobacion", _F_Impresion_ActaAprobacion)
        cmd.Parameters.Add("@F_Carga_ActaAprobacion", _F_Carga_ActaAprobacion)
        cmd.Parameters.Add("@F_Aprobacion_CTGT_ANT", _F_Aprobacion_CTGT_ANT)
        cmd.Parameters.Add("@F_Carga_minuta_Apro", _F_Carga_minuta_Apro)
        cmd.Parameters.Add("@F_CARGA_ANTF", _F_CARGA_ANTF)
        cmd.Parameters.Add("@F_Aprobacion_Comite_PROY", _F_Aprobacion_Comite_PROY)
        cmd.Parameters.Add("@F_Publicacion_ComentarioPublico", _F_Publicacion_ComentarioPublico)
        cmd.Parameters.Add("@F_Limite_ComentarioPublico", _F_Limite_ComentarioPublico)
        cmd.Parameters.Add("@F_Resolucion_ComentarioPublico", _F_Resolucion_ComentarioPublico)
        cmd.Parameters.Add("@F_Limite_Aprobacion_Resolucion_ComentarioPublico", _F_Limite_Aprobacion_Resolucion_ComentarioPublico)
        cmd.Parameters.Add("@F_Aprobacion_Resolucion_ComentarioPublico", _F_Aprobacion_Resolucion_ComentarioPublico)
        cmd.Parameters.Add("@F_VoBo_CONANCE", _F_VoBo_CONANCE)
        cmd.Parameters.Add("@F_Inicio_Revision_PROYF", _F_Inicio_Revision_PROYF)
        cmd.Parameters.Add("@F_Termino_Revision_PROYF", _F_Termino_Revision_PROYF)
        cmd.Parameters.Add("@F_Edicion_PROYF", _F_Edicion_PROYF)
        cmd.Parameters.Add("@F_Impresion_ActaAprobacion_PROYF", _F_Impresion_ActaAprobacion_PROYF)
        cmd.Parameters.Add("@F_Carga_ActaAprobacion_PROYF", _F_Carga_ActaAprobacion_PROYF)
        cmd.Parameters.Add("@F_ACUSE_DGN_PROYF", _F_ACUSE_DGN_PROYF)
        cmd.Parameters.Add("@F_CARGA_PROYF", _F_CARGA_PROYF)
        cmd.Parameters.Add("@F_VerifRev_PROYF", _F_VerifRev_PROYF)
        cmd.Parameters.Add("@F_Amp_Resolucion", _F_Amp_Resolucion)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
