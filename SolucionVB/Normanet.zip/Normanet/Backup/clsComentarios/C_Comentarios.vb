Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class C_Comentarios

#Region " Declaracion de Variables Privadas"

    Private dsC_Comentarios As New DataSet
    Private cn As New SqlConnection
    Private _Id_Comentario As String
    Private _Fecha_Comentario As String  'DateTime
    Private _Id_Plan As String
    Private _Id_Tema As Integer
    Private _Id_Etapa As Integer
    Private _Nombre As String
    Private _Empresa As String
    Private _Domicilio_Empresa As String
    Private _Telefono As String
    Private _Email As String
    Private _Fax As String
    Private _Tipo_comentario As String
    Private _Capitulo_inciso As String
    Private _Parrafotablafigura As String
    Private _Comentarios As String
    Private _Propuesta_cambios As String
    Private _Respuesta As String ' DateTime
    Private _Fecha_inicio As String ' DateTime
    Private _Fecha_Fin As String ' DateTime
    Private _criterios As String
    Private _Tipo_Fecha As Integer
    Private _Referencia As String
    Private sSql As String
    Private _Bandera As Integer

    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _bandera2 As Integer
    Private _Tipo As String
    Private _sReferencia As String
    Private _Status As Integer

    Private sStatus As String

    Private objConexion As New clsConexion.cIsConexion
    Private _Resolucion As String ' DateTime
    Private _Fecha_Resolucion As String

    Private _Id_tipo_doc As Integer
    Private _Documento As String
    Private _Activo As Boolean
    Private _traeComentarios As Boolean
    Private _Contador As Integer
    Private _JustiAbandono As String

    Private _NumComTec As Integer
    Private _NumComEdit As Integer
    Private _DocMatriz As String

#End Region

#Region " Declaracion de Propiedades publicas"

    Public Property DocMatriz() As String
        Get
            Return _DocMatriz
        End Get
        Set(ByVal Value As String)
            _DocMatriz = Value
        End Set
    End Property

    Public Property NumComEdit()
        Get
            Return _NumComEdit
        End Get
        Set(ByVal Value)
            _NumComEdit = Value
        End Set
    End Property

    Public Property NumComTec()
        Get
            Return _NumComTec
        End Get
        Set(ByVal Value)
            _NumComTec = Value
        End Set
    End Property

    Public Property Id_Comentario()
        Get
            Return _Id_Comentario
        End Get
        Set(ByVal Value)
            _Id_Comentario = Value
        End Set
    End Property

    Public Property Tipo_Fecha() As Integer
        Get
            Return _Tipo_Fecha
        End Get
        Set(ByVal Value As Integer)
            _Tipo_Fecha = Value
        End Set
    End Property

    Public Property Status() As Integer
        Get
            Return _Status
        End Get
        Set(ByVal Value As Integer)
            _Status = Value
        End Set
    End Property

    Public Property Fecha_Comentario()
        Get
            Return _Fecha_Comentario
        End Get
        Set(ByVal Value)
            _Fecha_Comentario = Value
        End Set
    End Property

    Public Property Id_Plan()
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value)
            _Id_Plan = Value
        End Set
    End Property

    Public Property Id_Tema()
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Id_Etapa()
        Get
            Return _Id_Etapa
        End Get
        Set(ByVal Value)
            _Id_Etapa = Value
        End Set
    End Property

    Public Property Nombre()
        Get
            Return _Nombre
        End Get
        Set(ByVal Value)
            _Nombre = Value
        End Set
    End Property

    Public Property Empresa()
        Get
            Return _Empresa
        End Get
        Set(ByVal Value)
            _Empresa = Value
        End Set
    End Property

    Public Property Domicilio_Empresa()
        Get
            Return _Domicilio_Empresa
        End Get
        Set(ByVal Value)
            _Domicilio_Empresa = Value
        End Set
    End Property

    Public Property Telefono()
        Get
            Return _Telefono
        End Get
        Set(ByVal Value)
            _Telefono = Value
        End Set
    End Property

    Public Property Email()
        Get
            Return _Email
        End Get
        Set(ByVal Value)
            _Email = Value
        End Set
    End Property

    Public Property Fax()
        Get
            Return _Fax
        End Get
        Set(ByVal Value)
            _Fax = Value
        End Set
    End Property

    Public Property Tipo_comentario()
        Get
            Return _Tipo_comentario
        End Get
        Set(ByVal Value)
            _Tipo_comentario = Value
        End Set
    End Property

    Public Property Capitulo_inciso()
        Get
            Return _Capitulo_inciso
        End Get
        Set(ByVal Value)
            _Capitulo_inciso = Value
        End Set
    End Property

    Public Property Parrafotablafigura()
        Get
            Return _Parrafotablafigura
        End Get
        Set(ByVal Value)
            _Parrafotablafigura = Value
        End Set
    End Property

    Public Property Comentarios()
        Get
            Return _Comentarios
        End Get
        Set(ByVal Value)
            _Comentarios = Value
        End Set
    End Property

    Public Property Propuesta_cambios()
        Get
            Return _Propuesta_cambios
        End Get
        Set(ByVal Value)
            _Propuesta_cambios = Value
        End Set
    End Property

    Public Property Respuesta()
        Get
            Return _Respuesta
        End Get
        Set(ByVal Value)
            _Respuesta = Value
        End Set
    End Property

    Public Property Fecha_inicio()
        Get
            Return _Fecha_inicio
        End Get
        Set(ByVal Value)
            _Fecha_inicio = Value
        End Set
    End Property

    Public Property Fecha_Fin()
        Get
            Return _Fecha_Fin
        End Get
        Set(ByVal Value)
            _Fecha_Fin = Value
        End Set
    End Property

    Public Property Bandera()
        Get
            Return _Bandera
        End Get
        Set(ByVal Value)
            _Bandera = Value
        End Set
    End Property

    Public Property Resolucion()
        Get
            Return _Resolucion
        End Get
        Set(ByVal Value)
            _Resolucion = Value
        End Set
    End Property

    Public Property Fecha_Resolucion()
        Get
            Return _Fecha_Resolucion
        End Get
        Set(ByVal Value)
            _Fecha_Resolucion = Value
        End Set
    End Property

    Public Property Id_tipo_doc()
        Get
            Return _Id_tipo_doc
        End Get
        Set(ByVal Value)
            _Id_tipo_doc = Value
        End Set
    End Property

    Public Property Documento()
        Get
            Return _Documento
        End Get
        Set(ByVal Value)
            _Documento = Value
        End Set
    End Property

    Public Property Activo()
        Get
            Return _Activo
        End Get
        Set(ByVal Value)
            _Activo = Value
        End Set
    End Property

    Public Property Criterios() As String
        Get
            Return _criterios
        End Get
        Set(ByVal Value As String)
            _criterios = Value
        End Set
    End Property
    Public Property Contador() As Integer
        Get
            Return _Contador
        End Get
        Set(ByVal Value As Integer)
            _Contador = Value
        End Set
    End Property

    Public Property traeComentarios() As Boolean
        Get
            Return _traeComentarios
        End Get
        Set(ByVal Value As Boolean)
            _traeComentarios = Value
        End Set
    End Property

    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Referencia() As String
        Get
            Return _Referencia
        End Get
        Set(ByVal Value As String)
            _Referencia = Value
        End Set
    End Property

    Public Property JustiAbandono() As String
        Get
            Return _JustiAbandono
        End Get
        Set(ByVal Value As String)
            _JustiAbandono = Value
        End Set
    End Property
    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property
#End Region

    Public Sub New(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
    End Sub


    Public Sub Llena_Campos()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@ID_Comentario", _Id_Comentario)
            .Parameters.Add("@sreferencia", _sReferencia)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmd.ExecuteReader()
            If dr.Read Then


                _Ref_A�o = IIf((IsDBNull(dr("Ref_A�o"))), "", dr("Ref_A�o"))
                _Ref_Comite = IIf((IsDBNull(dr("Ref_Comite"))), "", dr("Ref_Comite"))
                _Ref_Consecutivo = IIf((IsDBNull(dr("Ref_Consecutivo"))), "", dr("Ref_Consecutivo"))
                _Ref_Regreso = IIf((IsDBNull(dr("Ref_Regreso"))), "", dr("Ref_Regreso"))
                _Ref_Traspaso = IIf((IsDBNull(dr("Ref_Traspaso"))), "", dr("Ref_Traspaso"))

                _Id_Comentario = IIf((IsDBNull(dr("Id_Comentario"))), "", dr("Id_Comentario"))
                _Fecha_Comentario = IIf((IsDBNull(dr("Fecha_Comentario"))), "00/00/0000", dr("Fecha_Comentario"))
                _Id_Plan = IIf((IsDBNull(dr("Id_Plan"))), "", dr("Id_Plan"))
                _Id_Tema = IIf((IsDBNull(dr("Id_Tema"))), "", dr("Id_Tema"))
                _Id_Etapa = IIf((IsDBNull(dr("Id_Etapa"))), "", dr("Id_Etapa"))
                _Nombre = IIf((IsDBNull(dr("Nombre"))), "", dr("Nombre"))
                _Empresa = IIf((IsDBNull(dr("Empresa"))), "", dr("Empresa"))
                _Domicilio_Empresa = IIf((IsDBNull(dr("Domicilio_Empresa"))), "", dr("Domicilio_Empresa"))
                _Telefono = IIf((IsDBNull(dr("Telefono"))), "", dr("Telefono"))
                _Fax = IIf((IsDBNull(dr("Fax"))), "", dr("Fax"))
                _Email = IIf((IsDBNull(dr("Email"))), "", dr("Email"))
                _Tipo_comentario = IIf((IsDBNull(dr("Tipo_comentario"))), "", dr("Tipo_comentario"))
                _Capitulo_inciso = IIf((IsDBNull(dr("Capitulo_inciso"))), "", dr("Capitulo_inciso"))
                _Parrafotablafigura = IIf((IsDBNull(dr("Parrafotablafigura"))), "", dr("Parrafotablafigura"))
                _Comentarios = IIf((IsDBNull(dr("Comentarios"))), "", dr("Comentarios"))
                _Propuesta_cambios = IIf((IsDBNull(dr("Propuesta_cambios"))), "", dr("Propuesta_cambios"))
                _Respuesta = IIf((IsDBNull(dr("Respuesta"))), "", dr("Respuesta"))
                '  _Fecha_inicio = IIf((IsDBNull(dr("Fecha_inicio"))), "00/00/0000", dr("Fecha_inicio"))
                '  _Fecha_Fin = IIf((IsDBNull(dr("Fecha_Fin"))), "00/00/0000", dr("Fecha_Fin"))
                _Resolucion = IIf((IsDBNull(dr("Resolucion"))), "", dr("Resolucion"))
                _JustiAbandono = IIf((IsDBNull(dr("JustiAbandono"))), "", dr("JustiAbandono"))
                _Status = IIf((IsDBNull(dr("Status"))), Nothing, dr("Status"))

                _Fecha_Resolucion = IIf((IsDBNull(dr("fechaRes"))), "", dr("fechaRes"))
            Else
                _Id_Comentario = ""
                _Fecha_Comentario = ""
                _Id_Plan = ""
                _Id_Tema = 0
                _Id_Etapa = ""
                _Nombre = ""
                _Empresa = ""
                _Domicilio_Empresa = ""
                _Telefono = ""
                _Fax = ""
                _Email = ""
                _Tipo_comentario = ""
                _Capitulo_inciso = ""
                _Parrafotablafigura = ""
                _Comentarios = ""
                _Propuesta_cambios = ""
                _Respuesta = ""
                _Fecha_inicio = ""
                _Fecha_Fin = ""
                _Resolucion = ""
                _JustiAbandono = ""
                _Fecha_Resolucion = ""
            End If
            cn.Close()
            cmd.Dispose()
            cmd.Parameters.Clear()
        Catch ex As Exception
            Return
        End Try
    End Sub

    Public Sub Llena_Campos_Matriz()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "spComentariosMatriz"
            .Connection = cn
            .Parameters.Add("@ban", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            '.Parameters.Add("@ref", _sReferencia)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmd.ExecuteReader()
            If dr.Read Then
                _Ref_A�o = IIf((IsDBNull(dr("Ref_A�o"))), "", dr("Ref_A�o"))
                _Ref_Comite = IIf((IsDBNull(dr("Ref_Comite"))), "", dr("Ref_Comite"))
                _Ref_Consecutivo = IIf((IsDBNull(dr("Ref_Consecutivo"))), "", dr("Ref_Consecutivo"))
                _Ref_Regreso = IIf((IsDBNull(dr("Ref_Regreso"))), "", dr("Ref_Regreso"))
                _Ref_Traspaso = IIf((IsDBNull(dr("Ref_Traspaso"))), "", dr("Ref_Traspaso"))

                _NumComTec = IIf((IsDBNull(dr("numComTec"))), "", dr("numComTec"))
                _NumComEdit = IIf((IsDBNull(dr("numComEdit"))), "", dr("numComEdit"))
                _DocMatriz = IIf((IsDBNull(dr("archivoMatriz"))), "", dr("archivoMatriz"))
                _Fecha_Resolucion = IIf((IsDBNull(dr("fechaRes"))), "", dr("fechaRes"))
                _Resolucion = IIf((IsDBNull(dr("resolucion"))), "", dr("resolucion"))
                _Status = IIf((IsDBNull(dr("status"))), "", dr("status"))
            Else
                _Ref_A�o = ""
                _Ref_Comite = ""
                _Ref_Consecutivo = ""
                _Ref_Regreso = ""
                _Ref_Traspaso = ""

                _NumComTec = 0
                _NumComEdit = 0
                _DocMatriz = ""
                _Fecha_Resolucion = ""
                _Resolucion = ""
            End If
            cn.Close()
            cmd.Dispose()
            cmd.Parameters.Clear()
        Catch ex As Exception
            Return
        End Try
    End Sub



    Public Function Buscar_ID_Detalle()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_tema", _Id_Tema)
            .Parameters.Add("@Id_plan", _Id_Plan)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmd.ExecuteReader

            If dr.Read Then
                _Id_Comentario = dr("id_comentario")
            End If
            cmd.Dispose()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
            '_Objetivo = ex.Message
            'Return Nothing
        End Try
        cn.Close()
    End Function

    Public Sub ListaCombo(ByVal cbo As Object) 'este sustituye a los dos de abajo
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@ID_Comentario", _Id_Comentario)
        End With
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Comentarios")
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            'cmd.Parameters.Clear()
            da.Fill(dt)
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Comentarios = ex.Message
            Return
        End Try
    End Sub

    Public Function Buscar_PNN()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@ID_Comentario", _Id_Comentario)
            .Parameters.Add("@ID_Etapa", _Id_Etapa)
            .Parameters.Add("@Tipo_Fecha", _Tipo_Fecha)
            .Parameters.Add("@Fecha_inicio", _Fecha_inicio)
            .Parameters.Add("@Fecha_Fin", _Fecha_Fin)
            .Parameters.Add("@Tipo_comentario", _Tipo_comentario)
        End With
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("PNN")
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            'cmd.Parameters.Clear()
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Comentarios = ex.Message
            Return Nothing
        End Try
    End Function


    Public Function Buscar_ComMatriz()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "spComentariosMatriz"
            .Connection = cn
            .Parameters.Add("@ban", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)
        End With
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ComMatriz")
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            'cmd.Parameters.Clear()
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Comentarios = ex.Message
            Return Nothing
        End Try
    End Function




    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Comentarios")
        Try
            'da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    Public Function Actualizar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Modificar"

            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Fecha_Comentario", Format(Now.Today, "dd/MM/yyyy"))
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Id_Comentario", _Id_Comentario)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)
            .Parameters.Add("@Nombre", _Nombre)
            .Parameters.Add("@Empresa", _Empresa)
            .Parameters.Add("@Domicilio_Empresa", _Domicilio_Empresa)
            .Parameters.Add("@Telefono", _Telefono)
            .Parameters.Add("@Fax", _Fax)
            .Parameters.Add("@Email", _Email)
            .Parameters.Add("@Tipo_comentario", _Tipo_comentario)
            .Parameters.Add("@Capitulo_inciso", _Capitulo_inciso)
            .Parameters.Add("@Parrafotablafigura", _Parrafotablafigura)
            .Parameters.Add("@Comentarios", _Comentarios)
            .Parameters.Add("@Propuesta_cambios", _Propuesta_cambios)
            .Parameters.Add("@Resolucion", _Resolucion)
            .Parameters.Add("@Respuesta", _Respuesta)
            .Parameters.Add("@sReferencia", _sReferencia)
            .Parameters.Add("@JustiAbandono", _JustiAbandono)
            .Parameters.Add("@Ref_A�o", _Ref_A�o)
            .Parameters.Add("@Ref_Comite", _Ref_Comite)
            .Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@Ref_Regreso", _Ref_Regreso)
            .Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
            .Parameters.Add("@Documento", _Documento)
            .Parameters.Add("@Activo", _Activo)
            .Parameters.Add("@Id_tipo_doc", _Id_tipo_doc)
            .Parameters.Add("@status", _Status)
            .Parameters.Add("@Fecha_Resolucion", _Fecha_Resolucion)

        End With
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Dispose()
            'Return sStatus = "ok"
        Catch ex As Exception
            MsgBox("Error al tratar de actualizar los datos", MsgBoxStyle.Exclamation, "Error")
            'Return sStatus = "fallo"
        End Try
    End Function

    Public Sub ActualizarComMatriz()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "spComentariosMatriz"
            .Connection = cn

            .Parameters.Add("@ban", _Bandera)
            .Parameters.Add("@numComTec", _NumComTec)
            .Parameters.Add("@numComEdit", _NumComEdit)
            .Parameters.Add("@archivoMatriz", _DocMatriz)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)

            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@ref_traspaso", _Ref_Traspaso)

            If _Fecha_Resolucion <> "" Then
                .Parameters.Add("@fechaRes", CDate(_Fecha_Resolucion))
                .Parameters.Add("@resolucion", _Resolucion)
            End If

        End With
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Dispose()
        Catch ex As Exception
            MsgBox("Error al tratar de actualizar los datos", MsgBoxStyle.Exclamation, "Error")
        End Try
    End Sub

    Public Function Actualizar_Documentos() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_P_comentarios_Modificar"
            .Parameters.Add("@Bandera", _Bandera)
            '.Parameters.Add("@Id_Comentario", _Id_Comentario)
            '.Parameters.Add("@Fecha_Comentario", _Fecha_Comentario)
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Id_Comentario", _Id_Comentario)
            .Parameters.Add("@Resolucion", _Resolucion)
            .Parameters.Add("@Fecha_Resolucion", _Fecha_Resolucion)
            .Parameters.Add("@Id_tipo_doc", _Id_tipo_doc)
            .Parameters.Add("@Documento", _Documento)
            .Parameters.Add("@Activo", _Activo)
        End With
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Dispose()
            Return True
            Exit Function
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este documento - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Documento Existente")
            'Return "ERROR: " & ex.Message
            Return False
        End Try

    End Function

    Function ListaGridDoctos() As DataTable  'para cargar el grid de P_Prog_Trab_Documentos
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        Dim dtGrig As SqlDataReader
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Buscar" '"sp_C_Norma_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Id_tipo_doc", _Id_tipo_doc)
            .Parameters.Add("@Id_Comentario", _Id_Comentario)
            .Parameters.Add("@Documento", _Documento)
            .Parameters.Add("@Activo", _Activo)
        End With
        Dim dsGrid As New DataSet
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dsGrid, "P_Prog_Trab_Documentos")
            cmd.Dispose()
        Catch ex As Exception
            _Respuesta = ex.Message
            Return Nothing
            'Return 
        End Try
        Return dsGrid.Tables("P_Prog_Trab_Documentos")
    End Function
    Public Sub Agregar()
        '''If _ID_Comite = "" Or _ID_CT = "" Or _ID_SC = "" Or _Descripcion = "" Or _Objetivo = "" Then
        '''    MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
        '''    Exit Sub
        '''End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Modificar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            '.Parameters.Add("@", )
            .Parameters.Add("@Id_Comentario", _Id_Comentario)
            .Parameters.Add("@Fecha_Comentario", Format(Now.Today, "dd/MM/yyyy"))
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_Tema)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)
            .Parameters.Add("@Nombre", _Nombre)
            .Parameters.Add("@Empresa", _Empresa)
            .Parameters.Add("@Domicilio_Empresa", _Domicilio_Empresa)
            .Parameters.Add("@Telefono", _Telefono)
            .Parameters.Add("@Fax", _Fax)
            .Parameters.Add("@Email", _Email)
            .Parameters.Add("@Tipo_comentario", _Tipo_comentario)
            .Parameters.Add("@Capitulo_inciso", _Capitulo_inciso)
            .Parameters.Add("@Parrafotablafigura", _Parrafotablafigura)
            .Parameters.Add("@Comentarios", _Comentarios)
            .Parameters.Add("@Propuesta_cambios", _Propuesta_cambios)
            .Parameters.Add("@Respuesta", _Respuesta)

            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@ref_traspaso", _Ref_Traspaso)
            .Parameters.Add("@Status", _Status)

        End With
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
        End Try
        Exit Sub
    End Sub
    Public Sub AgregarComMatriz()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        Dim ref As String
        With cmd
            ref = RefA�o & RefComite & RefConsecutivo & RefRegreso & RefTraspaso

            .CommandType = CommandType.StoredProcedure
            .CommandText = "spComentariosMatriz"
            .Connection = cn
            .Parameters.Add("@ban", _Bandera)
            .Parameters.Add("@numComTec", _NumComTec)
            .Parameters.Add("@numComEdit", _NumComEdit)
            .Parameters.Add("@archivoMatriz", _DocMatriz)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)
            .Parameters.Add("@ref", ref)

            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@ref_traspaso", _Ref_Traspaso)

        End With
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
        End Try
        Exit Sub
    End Sub
    Public Sub Buscar()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@ID_Comentario", _Id_Comentario)
        End With
        Try
            If cn.State Then cn.Close()
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                ''_ID_Comite = dr("ID_Comite")
                ''_Descripcion = dr("Descripcion")
                ''_Objetivo = IIf((IsNothing(dr("Objetivo"))), "", dr("Objetivo"))
                ''_ID_CT = IIf((IsNothing(dr("ID_CT"))), "", dr("ID_CT"))
                ''_ID_SC = IIf((IsNothing(dr("ID_SC"))), "", dr("ID_SC"))
                ''_Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
                '''''_ID_GT = IIf((IsNothing(dr("GT"))), "", dr("GT"))
                ''_ID_GT = ""
                ''_ID_SGT = ""
            Else
                ''_ID_Comite = ""
                ''_Descripcion = ""
                ''_Objetivo = ""
                ''_ID_CT = ""
                ''_ID_SC = ""
                ''_ID_GT = ""
                ''_ID_SGT = ""
            End If
            cn.Close()
            cmd.Parameters.Clear()
            cmd.Dispose()
        Catch ex As Exception
            Return
        End Try
    End Sub

    Public Function Borrar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBorrar As New SqlCommand

        With cmdBorrar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Modificar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@ID_Comentario", _Id_Comentario)
        End With
        Try
            cn.Open()
            cmdBorrar.ExecuteNonQuery()
            cn.Close()
            cmdBorrar.Parameters.Clear()
            cmdBorrar.Dispose()
        Catch ex As Exception
            MsgBox("Error al tratar de borrar el Comentario - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Cat�logo de Comentarios")
            sStatus = "Fallo"
            Return sStatus
        End Try

    End Function

    Public Function BorrarResolucion() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBorrar As New SqlCommand

        With cmdBorrar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comentarios_Modificar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Plan", _Id_Plan)
            .Parameters.Add("@ID_Tema", _Id_Tema)
            .Parameters.Add("@ID_Comentario", _Id_Comentario)
            .Parameters.Add("@Id_tipo_doc", _Id_tipo_doc)
            .Parameters.Add("@documento", _Documento)
            .Parameters.Add("@sReferencia", _Referencia)
            .Parameters.Add("@Activo", _Activo)

        End With
        Try
            cn.Open()
            cmdBorrar.ExecuteNonQuery()
            cn.Close()
            cmdBorrar.Parameters.Clear()
            cmdBorrar.Dispose()
        Catch ex As Exception
            MsgBox("Error al tratar de borrar el Comentario - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Cat�logo de Comentarios")
            sStatus = "Fallo"
            Return sStatus
        End Try

    End Function

    Public Function BorrarComMatriz() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBorrar As New SqlCommand
        With cmdBorrar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "spComentariosMatriz"
            .Connection = cn

            .Parameters.Add("@ban", _Bandera)
            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@ref_traspaso", _Ref_Traspaso)
            .Parameters.Add("@Id_Etapa", _Id_Etapa)
            .Parameters.Add("@status", _Status)
        End With
        Try
            cn.Open()
            cmdBorrar.ExecuteNonQuery()
            cn.Close()
            cmdBorrar.Parameters.Clear()
            cmdBorrar.Dispose()
        Catch ex As Exception
            MsgBox("Error al tratar de borrar el Comentario - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Cat�logo de Comentarios")
            sStatus = "Fallo"
            Return sStatus
        End Try
    End Function

    Public Sub BuscaComentario() 'busca si existen comentarios para un determinado plan
        Dim cmdComentarios As New SqlCommand
        Dim drComentarios As SqlDataReader
        Try
            With cmdComentarios
                .CommandType = CommandType.StoredProcedure
                .CommandText = "sp_P_Comentarios_Buscar"
                .Connection = cn
                .Parameters.Add("@Bandera", 41)
                .Parameters.Add("@ID_Plan", _Id_Plan)
                .Parameters.Add("@Id_Tema", _Id_Tema)
                .Parameters.Add("@Id_Etapa", _Id_Etapa)
                .Parameters.Add("@Tipo_comentario", _Tipo_comentario)
                .Parameters.Add("@Referencia", _Referencia)
            End With
            If cn.State = 1 Then cn.Close()
            cn.Open()
            drComentarios = cmdComentarios.ExecuteReader()
            If drComentarios.Read Then
                _Contador = drComentarios("Items")
                If _Contador > 0 Then
                    _traeComentarios = True
                Else
                    _traeComentarios = False
                End If
            End If
            cn.Close()
            cmdComentarios.Dispose()

            If _traeComentarios = False Then
                Dim cmdComentariosMat As New SqlCommand
                Dim drComentariosMat As SqlDataReader
                _Contador = 0
                With cmdComentariosMat
                    .CommandType = CommandType.StoredProcedure
                    .CommandText = "spComentariosMatriz"
                    .Connection = cn
                    .Parameters.Add("@ban", 6)
                    .Parameters.Add("@TipoComentario", _Tipo_comentario)
                    .Parameters.Add("@ref", _Referencia)
                    .Parameters.Add("@Id_Etapa", _Id_Etapa)
                End With
                If cn.State = 1 Then cn.Close()
                cn.Open()
                drComentariosMat = cmdComentariosMat.ExecuteReader()
                If drComentariosMat.Read Then
                    _Contador = drComentariosMat("Items")
                    If _Contador > 0 Then
                        _traeComentarios = True
                    Else
                        _traeComentarios = False
                    End If
                End If
                cn.Close()
                drComentariosMat.Close()
                cmdComentariosMat.Dispose()
            End If
        Catch ex As Exception
            Dim ms
            ms = ex.Message()
            Return
        End Try
    End Sub

    Public Function BorrarComentario(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_P_Comentarios_Modificar"
        cmd.Parameters.Add("@Bandera", 6)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


End Class
