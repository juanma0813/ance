Imports Microsoft.VisualBasic
Imports System
Imports System.ComponentModel
Imports System.Data
Imports System.Data.Common
Imports System.Data.OleDb
Imports System.Drawing
Imports System.Windows.Forms

Public Class DataGridColumnTreeView

    Inherits DataGridTextBoxColumn
    Public ColumnTreeView As TreeViewsinkeyup 'Atenci�n aqu� con esta declaraci�n
    Private _Origen As System.Windows.Forms.CurrencyManager
    Private _NroRenglon As Integer
    Private _EstaEditando As Boolean
    Private _bError As Boolean
    Public Shared _RowCount As Integer
    Private _grid As DataGrid


#Region " Inicializaci�n de   Dll's"

    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)

#End Region

#Region " C�digo generado por Mariano Ascencio, para el constructor"

    Public Sub New(ByVal obj As Object)
        _Origen = Nothing
        _EstaEditando = False
        _RowCount = -1
        _grid = obj

        ColumnTreeView = New TreeViewsinkeyup
        AddHandler ColumnTreeView.DoubleClick, AddressOf DejaColumnTreeView
        AddHandler ColumnTreeView.MouseHover, AddressOf ComienzaEditarTreeView
        AddHandler ColumnTreeView.Leave, AddressOf DejaColumnTreeView
        '  AddHandler ColumnTreeView.Enter, AddressOf DejaColumnTreeView

    End Sub

#End Region

#Region "Metodos de la Clase"


    Protected Overrides Sub ConcedeFocus()
        MyBase.ConcedeFocus()
    End Sub

#Region "Metodos de ColumnTreeView"
    Public Sub ComienzaEditarTreeView(ByVal sender As Object, ByVal e As EventArgs)
        _EstaEditando = True
        MyBase.ColumnStartedEditing(sender)
    End Sub

    Private Sub DejaColumnTreeView(ByVal sender As Object, ByVal e As EventArgs) 'As System.Windows.Forms.TreeViewEventArgs)
        Dim valor_nodo, valor As String
        Dim ivalor, i, rows_grid, barrido As Integer
        Dim existetree As Boolean = False
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        _bError = False
        valor_nodo = ColumnTreeView.SelectedNode.FullPath
        ivalor = ColumnTreeView.SelectedNode.ImageIndex
        array_texto = Split(valor_nodo, "\")

        Select Case array_texto.Length
            Case 3
                If _EstaEditando Then
                    rows_grid = _grid.VisibleRowCount
                    For i = 0 To rows_grid - 2
                        If _NroRenglon <> i Then
                            If array_texto(1) + " " + array_texto(2) = _grid.Item(i, 0) + " " + CStr(IIf(IsDBNull(_grid.Item(i, 1)), -1, _grid.Item(i, 1))) Then existetree = True
                        End If
                    Next
                    If Not existetree Then
                        Try
                        SetColumnValueAtRow(_Origen, _NroRenglon, array_texto(1))
                        _grid.Item(_NroRenglon, 1) = array_texto(2)
                        objprogtrab.Id_Tema = _grid.Item(_NroRenglon, 1)
                        objprogtrab.Id_Plan = _grid.Item(_NroRenglon, 0)
                        objprogtrab.Bandera = 10
                        objprogtrab.Buscar(_grid.Item(_NroRenglon, 0), _grid.Item(_NroRenglon, 1))
                        _grid.Item(_NroRenglon, 2) = objprogtrab.Clasificacion
                        _grid.Item(_NroRenglon, 3) = True
                        _EstaEditando = False
                        Invalidate()
                            ColumnTreeView.CollapseAll()
                        Catch ex As Exception
                            MsgBox("Teclas bloquedas")
                            Exit Sub
                        End Try
                    End If
                End If
        End Select
        ColumnTreeView.Hide()
        _grid.Focus()
        AddHandler Me.DataGridTableStyle.DataGrid.Scroll, New EventHandler(AddressOf ManejaScroll)
    End Sub

    Private Sub ManejaScroll(ByVal sender As Object, ByVal e As EventArgs)
        If ColumnTreeView.Visible Then
            ColumnTreeView.Hide()
        End If
    End Sub

    Protected Overloads Overrides Sub Edit(ByVal [source] As System.Windows.Forms.CurrencyManager, ByVal rowNum As Integer, ByVal bounds As System.Drawing.Rectangle, ByVal [readOnly] As Boolean, ByVal instantText As String, ByVal cellIsVisible As Boolean)
        Dim sverifica As Integer
        If _grid.Item(rowNum, 3) Is System.DBNull.Value Then sverifica = (0) Else sverifica = IIf(_grid.Item(rowNum, 3), 1, 0)
        If (sverifica = 0) And itemas - 1 < rowNum Then
            MyBase.Edit([source], rowNum, bounds, [readOnly], instantText, cellIsVisible)
            _NroRenglon = rowNum
            _Origen = [source]
            ColumnTreeView.Parent = Me.TextBox.Parent
            ' ColumnTreeView.Location = Me.TextBox.Location
            ColumnTreeView.Location = New Point(17, 17)
            'ColumnTreeView.Size = New Size(Me.TextBox.Size.Width, ColumnTreeView.Size.Height)
            ColumnTreeView.CollapseAll()
            Me.TextBox.Visible = False
            ColumnTreeView.Visible = True
            AddHandler Me.DataGridTableStyle.DataGrid.Scroll, AddressOf ManejaScroll
            ColumnTreeView.BringToFront()
            ColumnTreeView.Focus()
        End If

    End Sub
#End Region

#End Region


End Class

#Region " TreeView - TreeViewsinkeyup"

Public Class TreeViewsinkeyup
    Inherits TreeView
    Dim evento As EventArgs

    Private WM_KEYUP As Integer = &H101

    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        If m.Msg = WM_KEYUP Then
            'Ignora el keyup para evita problemas de tabulaci�n
            Return
        End If

        MyBase.WndProc(m)
    End Sub

End Class

#End Region