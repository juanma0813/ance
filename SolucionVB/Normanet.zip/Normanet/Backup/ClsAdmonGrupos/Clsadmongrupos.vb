
Imports System
Imports System.Data.SqlClient
Public Class ClsadmonGrupos
    Private cn As New SqlConnection
    Private sPath_OCP As String
    Private cn_OCP As New SqlConnection
    Private dr As SqlDataReader
    Private _Bandera As Integer
    Private _Id_usuario As String
    Private _Id_grupo As Integer
    Private _Id_sistema As Integer


    Dim objConexion As New clsConexion.cIsConexion
    'Public Overloads Sub Inicializa(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
    '    cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "COMUN", guser, gpassword)
    'End Sub

    Public Sub New(ByVal sPath As String, ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(sPath, Identificador, guser, gpassword)
        sPath_OCP = sPath
    End Sub
    Public Property Id_usuario() As String
        Get
            Return _Id_usuario
        End Get
        Set(ByVal Value As String)
            _Id_usuario = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property
    Public Property Id_grupo() As Integer
        Get
            Return _Id_grupo
        End Get
        Set(ByVal Value As Integer)
            _Id_grupo = Value
        End Set
    End Property


    Public Function ListaCombo() As DataTable
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Grupo_Detalle_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 2)
        cmd.Parameters.Add("@ID_Usuario", _Id_usuario)
        cmd.Parameters.Add("@Id_Sistema", 16)

        Dim da As SqlDataAdapter
        Dim dt As New DataTable("clsGrupos")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)

        Catch ex As Exception
            Return Nothing
        End Try
        Return dt
    End Function
    Public Function Buscar()

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Grupo_Detalle_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Id_Sistema", 16)
        cmd.Parameters.Add("@Id_grupo", _Id_grupo)
        Dim da2 As SqlDataAdapter
        Dim dt2 As New DataTable("clsMenus")
        Try
            da2 = New Data.SqlClient.SqlDataAdapter(cmd)
            da2.Fill(dt2)

        Catch ex As Exception
            Return Nothing
        End Try
        Return dt2


    End Function
   

End Class
