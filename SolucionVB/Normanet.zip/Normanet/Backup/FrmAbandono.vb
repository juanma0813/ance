Public Class FrmAbandono
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtJustificacion As System.Windows.Forms.TextBox
    Friend WithEvents cmdAceptar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtJustificacion = New System.Windows.Forms.TextBox
        Me.cmdAceptar = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(163, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Justificacion del abandono"
        '
        'txtJustificacion
        '
        Me.txtJustificacion.Location = New System.Drawing.Point(8, 32)
        Me.txtJustificacion.Multiline = True
        Me.txtJustificacion.Name = "txtJustificacion"
        Me.txtJustificacion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtJustificacion.Size = New System.Drawing.Size(272, 128)
        Me.txtJustificacion.TabIndex = 1
        Me.txtJustificacion.Text = ""
        '
        'cmdAceptar
        '
        Me.cmdAceptar.Location = New System.Drawing.Point(200, 168)
        Me.cmdAceptar.Name = "cmdAceptar"
        Me.cmdAceptar.TabIndex = 2
        Me.cmdAceptar.Text = "Aceptar"
        '
        'FrmAbandono
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 206)
        Me.Controls.Add(Me.cmdAceptar)
        Me.Controls.Add(Me.txtJustificacion)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmAbandono"
        Me.Text = "Justificacion de abandono"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub cmdAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAceptar.Click
        If txtJustificacion.Text = "" Then
            MsgBox("La justificacion no puede ir vacia")
            Exit Sub
        Else
            respuesta = txtJustificacion.Text
            Me.Dispose()
        End If
    End Sub

    Private Sub FrmAbandono_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        respuesta = ""
    End Sub
End Class
