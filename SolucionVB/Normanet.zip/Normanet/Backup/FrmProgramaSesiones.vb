Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms


    Public Class FrmProgramaSesiones

    Inherits System.Windows.Forms.Form
    Private oVista As DataView
    Dim dvComite As DataView
    Dim dvCT As DataView
    Dim dvC As DataView
    Dim dvGT As DataView
    Dim DTRes As DataTable = New DataTable("fechas")  ''' datos editables para resultados
    Dim DTResRes As New DataTable ''' datos editables para restaurar los resultados
    '''''     Otras Variables
    Dim existe, Accion, formactivo As Boolean
    Dim ValEditar As Integer
    Dim sError, iEditar, sValTreeView, sFechaPk, shoraiPk, shoratPk, sReubica, stvcpath As String
    Dim sesion, i, solicitud, istasol, istasesion As Integer


#Region " Inicializaci�n de   Dll's"

    '''''     dll's
    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objsalas As New Cls_Salas.Cls_Salas("EXTRA", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents Lblchksala As System.Windows.Forms.Label
    Friend WithEvents Lblsal As System.Windows.Forms.Label
    Friend WithEvents LblSol As System.Windows.Forms.Label
    Friend WithEvents TxtLugar As System.Windows.Forms.TextBox
    Friend WithEvents TxtAsunto As System.Windows.Forms.TextBox
    Friend WithEvents CkBxSalasANCE As System.Windows.Forms.CheckBox
    Friend WithEvents CboSalas As System.Windows.Forms.ComboBox
    Friend WithEvents CboEquipo As System.Windows.Forms.ComboBox
    Friend WithEvents GpBoxSincroniza As System.Windows.Forms.GroupBox
    Friend WithEvents GpBoxDefineProg As System.Windows.Forms.GroupBox
    Friend WithEvents LblCada As System.Windows.Forms.Label
    Friend WithEvents Lblcada2 As System.Windows.Forms.Label
    Friend WithEvents CkBLun As System.Windows.Forms.CheckBox
    Friend WithEvents CkBmartes As System.Windows.Forms.CheckBox
    Friend WithEvents CkBJueves As System.Windows.Forms.CheckBox
    Friend WithEvents CkBMiercoles As System.Windows.Forms.CheckBox
    Friend WithEvents CkBViernes As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DTPkrhoratem As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPkrhoraini As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lblht As System.Windows.Forms.Label
    Friend WithEvents Lblhi As System.Windows.Forms.Label
    Friend WithEvents cmdGenerar As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DTPKFecfin As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPKFecini As System.Windows.Forms.DateTimePicker
    Friend WithEvents RBnSucede3 As System.Windows.Forms.RadioButton
    Friend WithEvents RBnSucede2 As System.Windows.Forms.RadioButton
    Friend WithEvents RBnSucede1 As System.Windows.Forms.RadioButton
    Friend WithEvents NUDFrec As System.Windows.Forms.NumericUpDown
    Friend WithEvents Lblcada3 As System.Windows.Forms.Label
    Friend WithEvents Lblcada4 As System.Windows.Forms.Label
    Friend WithEvents NUDFrec2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents GridResultados As System.Windows.Forms.DataGrid
    Friend WithEvents Lblff As System.Windows.Forms.Label
    Friend WithEvents Lblfi As System.Windows.Forms.Label
    Friend WithEvents Lbllugar As System.Windows.Forms.Label
    Friend WithEvents LblAsunto As System.Windows.Forms.Label
    Friend WithEvents LblRes As System.Windows.Forms.Label
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmProgramaSesiones))
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.Lblchksala = New System.Windows.Forms.Label
        Me.Lblsal = New System.Windows.Forms.Label
        Me.LblSol = New System.Windows.Forms.Label
        Me.TxtLugar = New System.Windows.Forms.TextBox
        Me.Lbllugar = New System.Windows.Forms.Label
        Me.TxtAsunto = New System.Windows.Forms.TextBox
        Me.LblAsunto = New System.Windows.Forms.Label
        Me.CkBxSalasANCE = New System.Windows.Forms.CheckBox
        Me.CboSalas = New System.Windows.Forms.ComboBox
        Me.CboEquipo = New System.Windows.Forms.ComboBox
        Me.GpBoxSincroniza = New System.Windows.Forms.GroupBox
        Me.RBnSucede3 = New System.Windows.Forms.RadioButton
        Me.RBnSucede2 = New System.Windows.Forms.RadioButton
        Me.RBnSucede1 = New System.Windows.Forms.RadioButton
        Me.GpBoxDefineProg = New System.Windows.Forms.GroupBox
        Me.CkBViernes = New System.Windows.Forms.CheckBox
        Me.CkBJueves = New System.Windows.Forms.CheckBox
        Me.CkBMiercoles = New System.Windows.Forms.CheckBox
        Me.CkBmartes = New System.Windows.Forms.CheckBox
        Me.CkBLun = New System.Windows.Forms.CheckBox
        Me.Lblcada4 = New System.Windows.Forms.Label
        Me.NUDFrec2 = New System.Windows.Forms.NumericUpDown
        Me.Lblcada2 = New System.Windows.Forms.Label
        Me.LblCada = New System.Windows.Forms.Label
        Me.NUDFrec = New System.Windows.Forms.NumericUpDown
        Me.Lblcada3 = New System.Windows.Forms.Label
        Me.GridResultados = New System.Windows.Forms.DataGrid
        Me.Label1 = New System.Windows.Forms.Label
        Me.DTPkrhoratem = New System.Windows.Forms.DateTimePicker
        Me.DTPkrhoraini = New System.Windows.Forms.DateTimePicker
        Me.Lblht = New System.Windows.Forms.Label
        Me.Lblhi = New System.Windows.Forms.Label
        Me.cmdGenerar = New System.Windows.Forms.Button
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.Label9 = New System.Windows.Forms.Label
        Me.CboResponsable = New System.Windows.Forms.ComboBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Lblff = New System.Windows.Forms.Label
        Me.DTPKFecfin = New System.Windows.Forms.DateTimePicker
        Me.Lblfi = New System.Windows.Forms.Label
        Me.DTPKFecini = New System.Windows.Forms.DateTimePicker
        Me.LblRes = New System.Windows.Forms.Label
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.GpBoxSincroniza.SuspendLayout()
        Me.GpBoxDefineProg.SuspendLayout()
        CType(Me.NUDFrec2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDFrec, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridResultados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tvComites
        '
        Me.tvComites.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 56)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = 1
        Me.tvComites.Size = New System.Drawing.Size(208, 320)
        Me.tvComites.TabIndex = 1
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblcomite.Location = New System.Drawing.Point(8, 16)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(122, 15)
        Me.Lblcomite.TabIndex = 87
        Me.Lblcomite.Text = "Comite SeleccioNAdo: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblTreeView.Location = New System.Drawing.Point(11, 32)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 15)
        Me.LblTreeView.TabIndex = 86
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Lblchksala
        '
        Me.Lblchksala.AutoSize = True
        Me.Lblchksala.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblchksala.Location = New System.Drawing.Point(512, 48)
        Me.Lblchksala.Name = "Lblchksala"
        Me.Lblchksala.Size = New System.Drawing.Size(117, 15)
        Me.Lblchksala.TabIndex = 98
        Me.Lblchksala.Text = "Solicitar Sala a ANCE:"
        '
        'Lblsal
        '
        Me.Lblsal.AutoSize = True
        Me.Lblsal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsal.Location = New System.Drawing.Point(232, 80)
        Me.Lblsal.Name = "Lblsal"
        Me.Lblsal.Size = New System.Drawing.Size(30, 15)
        Me.Lblsal.TabIndex = 97
        Me.Lblsal.Text = "Sala:"
        '
        'LblSol
        '
        Me.LblSol.AutoSize = True
        Me.LblSol.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSol.Location = New System.Drawing.Point(463, 80)
        Me.LblSol.Name = "LblSol"
        Me.LblSol.Size = New System.Drawing.Size(53, 15)
        Me.LblSol.TabIndex = 96
        Me.LblSol.Text = "Solicitud:"
        '
        'TxtLugar
        '
        Me.TxtLugar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLugar.Location = New System.Drawing.Point(288, 46)
        Me.TxtLugar.Name = "TxtLugar"
        Me.TxtLugar.Size = New System.Drawing.Size(176, 19)
        Me.TxtLugar.TabIndex = 89
        Me.TxtLugar.Text = ""
        '
        'Lbllugar
        '
        Me.Lbllugar.AutoSize = True
        Me.Lbllugar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbllugar.Location = New System.Drawing.Point(232, 48)
        Me.Lbllugar.Name = "Lbllugar"
        Me.Lbllugar.Size = New System.Drawing.Size(37, 15)
        Me.Lbllugar.TabIndex = 94
        Me.Lbllugar.Text = "Lugar:"
        '
        'TxtAsunto
        '
        Me.TxtAsunto.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAsunto.Location = New System.Drawing.Point(288, 14)
        Me.TxtAsunto.Multiline = True
        Me.TxtAsunto.Name = "TxtAsunto"
        Me.TxtAsunto.Size = New System.Drawing.Size(376, 19)
        Me.TxtAsunto.TabIndex = 88
        Me.TxtAsunto.Text = ""
        '
        'LblAsunto
        '
        Me.LblAsunto.AutoSize = True
        Me.LblAsunto.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAsunto.Location = New System.Drawing.Point(232, 16)
        Me.LblAsunto.Name = "LblAsunto"
        Me.LblAsunto.Size = New System.Drawing.Size(45, 15)
        Me.LblAsunto.TabIndex = 93
        Me.LblAsunto.Text = "Asunto:"
        '
        'CkBxSalasANCE
        '
        Me.CkBxSalasANCE.Location = New System.Drawing.Point(648, 47)
        Me.CkBxSalasANCE.Name = "CkBxSalasANCE"
        Me.CkBxSalasANCE.Size = New System.Drawing.Size(16, 16)
        Me.CkBxSalasANCE.TabIndex = 90
        '
        'CboSalas
        '
        Me.CboSalas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboSalas.Location = New System.Drawing.Point(288, 80)
        Me.CboSalas.Name = "CboSalas"
        Me.CboSalas.Size = New System.Drawing.Size(160, 21)
        Me.CboSalas.TabIndex = 91
        '
        'CboEquipo
        '
        Me.CboEquipo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboEquipo.Location = New System.Drawing.Point(528, 80)
        Me.CboEquipo.Name = "CboEquipo"
        Me.CboEquipo.Size = New System.Drawing.Size(136, 21)
        Me.CboEquipo.TabIndex = 92
        '
        'GpBoxSincroniza
        '
        Me.GpBoxSincroniza.Controls.Add(Me.RBnSucede3)
        Me.GpBoxSincroniza.Controls.Add(Me.RBnSucede2)
        Me.GpBoxSincroniza.Controls.Add(Me.RBnSucede1)
        Me.GpBoxSincroniza.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GpBoxSincroniza.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GpBoxSincroniza.Location = New System.Drawing.Point(232, 112)
        Me.GpBoxSincroniza.Name = "GpBoxSincroniza"
        Me.GpBoxSincroniza.Size = New System.Drawing.Size(120, 104)
        Me.GpBoxSincroniza.TabIndex = 100
        Me.GpBoxSincroniza.TabStop = False
        Me.GpBoxSincroniza.Text = "Sucede"
        '
        'RBnSucede3
        '
        Me.RBnSucede3.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.RBnSucede3.Location = New System.Drawing.Point(8, 72)
        Me.RBnSucede3.Name = "RBnSucede3"
        Me.RBnSucede3.TabIndex = 2
        Me.RBnSucede3.Text = "Mensualmente"
        '
        'RBnSucede2
        '
        Me.RBnSucede2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.RBnSucede2.Location = New System.Drawing.Point(8, 41)
        Me.RBnSucede2.Name = "RBnSucede2"
        Me.RBnSucede2.TabIndex = 1
        Me.RBnSucede2.Text = "SemaNAlmente"
        '
        'RBnSucede1
        '
        Me.RBnSucede1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.RBnSucede1.Location = New System.Drawing.Point(8, 16)
        Me.RBnSucede1.Name = "RBnSucede1"
        Me.RBnSucede1.Size = New System.Drawing.Size(96, 24)
        Me.RBnSucede1.TabIndex = 0
        Me.RBnSucede1.Text = "Diariamente"
        '
        'GpBoxDefineProg
        '
        Me.GpBoxDefineProg.Controls.Add(Me.CkBViernes)
        Me.GpBoxDefineProg.Controls.Add(Me.CkBJueves)
        Me.GpBoxDefineProg.Controls.Add(Me.CkBMiercoles)
        Me.GpBoxDefineProg.Controls.Add(Me.CkBmartes)
        Me.GpBoxDefineProg.Controls.Add(Me.CkBLun)
        Me.GpBoxDefineProg.Controls.Add(Me.Lblcada4)
        Me.GpBoxDefineProg.Controls.Add(Me.NUDFrec2)
        Me.GpBoxDefineProg.Controls.Add(Me.Lblcada2)
        Me.GpBoxDefineProg.Controls.Add(Me.LblCada)
        Me.GpBoxDefineProg.Controls.Add(Me.NUDFrec)
        Me.GpBoxDefineProg.Controls.Add(Me.Lblcada3)
        Me.GpBoxDefineProg.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GpBoxDefineProg.Location = New System.Drawing.Point(360, 112)
        Me.GpBoxDefineProg.Name = "GpBoxDefineProg"
        Me.GpBoxDefineProg.Size = New System.Drawing.Size(304, 104)
        Me.GpBoxDefineProg.TabIndex = 101
        Me.GpBoxDefineProg.TabStop = False
        '
        'CkBViernes
        '
        Me.CkBViernes.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CkBViernes.Location = New System.Drawing.Point(240, 64)
        Me.CkBViernes.Name = "CkBViernes"
        Me.CkBViernes.Size = New System.Drawing.Size(52, 24)
        Me.CkBViernes.TabIndex = 107
        Me.CkBViernes.Text = "Vie."
        '
        'CkBJueves
        '
        Me.CkBJueves.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CkBJueves.Location = New System.Drawing.Point(182, 64)
        Me.CkBJueves.Name = "CkBJueves"
        Me.CkBJueves.Size = New System.Drawing.Size(52, 24)
        Me.CkBJueves.TabIndex = 106
        Me.CkBJueves.Text = "Jue."
        '
        'CkBMiercoles
        '
        Me.CkBMiercoles.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CkBMiercoles.Location = New System.Drawing.Point(128, 64)
        Me.CkBMiercoles.Name = "CkBMiercoles"
        Me.CkBMiercoles.Size = New System.Drawing.Size(48, 24)
        Me.CkBMiercoles.TabIndex = 105
        Me.CkBMiercoles.Text = "Mi�."
        '
        'CkBmartes
        '
        Me.CkBmartes.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CkBmartes.Location = New System.Drawing.Point(70, 64)
        Me.CkBmartes.Name = "CkBmartes"
        Me.CkBmartes.Size = New System.Drawing.Size(52, 24)
        Me.CkBmartes.TabIndex = 104
        Me.CkBmartes.Text = "Mar."
        '
        'CkBLun
        '
        Me.CkBLun.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CkBLun.Location = New System.Drawing.Point(16, 64)
        Me.CkBLun.Name = "CkBLun"
        Me.CkBLun.Size = New System.Drawing.Size(48, 24)
        Me.CkBLun.TabIndex = 103
        Me.CkBLun.Text = "Lun."
        '
        'Lblcada4
        '
        Me.Lblcada4.AllowDrop = True
        Me.Lblcada4.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Lblcada4.Location = New System.Drawing.Point(224, 37)
        Me.Lblcada4.Name = "Lblcada4"
        Me.Lblcada4.Size = New System.Drawing.Size(48, 14)
        Me.Lblcada4.TabIndex = 113
        Me.Lblcada4.Text = "meses."
        '
        'NUDFrec2
        '
        Me.NUDFrec2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.NUDFrec2.Location = New System.Drawing.Point(168, 35)
        Me.NUDFrec2.Name = "NUDFrec2"
        Me.NUDFrec2.Size = New System.Drawing.Size(49, 19)
        Me.NUDFrec2.TabIndex = 111
        Me.NUDFrec2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lblcada2
        '
        Me.Lblcada2.AllowDrop = True
        Me.Lblcada2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Lblcada2.Location = New System.Drawing.Point(128, 37)
        Me.Lblcada2.Name = "Lblcada2"
        Me.Lblcada2.Size = New System.Drawing.Size(72, 15)
        Me.Lblcada2.TabIndex = 102
        Me.Lblcada2.Text = "Cada"
        '
        'LblCada
        '
        Me.LblCada.AllowDrop = True
        Me.LblCada.AutoSize = True
        Me.LblCada.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.LblCada.Location = New System.Drawing.Point(16, 37)
        Me.LblCada.Name = "LblCada"
        Me.LblCada.Size = New System.Drawing.Size(30, 15)
        Me.LblCada.TabIndex = 101
        Me.LblCada.Text = "Cada"
        '
        'NUDFrec
        '
        Me.NUDFrec.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.NUDFrec.Location = New System.Drawing.Point(64, 35)
        Me.NUDFrec.Name = "NUDFrec"
        Me.NUDFrec.Size = New System.Drawing.Size(49, 19)
        Me.NUDFrec.TabIndex = 100
        Me.NUDFrec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lblcada3
        '
        Me.Lblcada3.AllowDrop = True
        Me.Lblcada3.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Lblcada3.Location = New System.Drawing.Point(120, 38)
        Me.Lblcada3.Name = "Lblcada3"
        Me.Lblcada3.Size = New System.Drawing.Size(48, 14)
        Me.Lblcada3.TabIndex = 112
        Me.Lblcada3.Text = "de cada"
        '
        'GridResultados
        '
        Me.GridResultados.CaptionVisible = False
        Me.GridResultados.DataMember = ""
        Me.GridResultados.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.GridResultados.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GridResultados.Location = New System.Drawing.Point(8, 400)
        Me.GridResultados.Name = "GridResultados"
        Me.GridResultados.Size = New System.Drawing.Size(656, 104)
        Me.GridResultados.TabIndex = 102
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 383)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 15)
        Me.Label1.TabIndex = 103
        Me.Label1.Text = "Resultados: "
        '
        'DTPkrhoratem
        '
        Me.DTPkrhoratem.CustomFormat = "HH:mm "
        Me.DTPkrhoratem.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoratem.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPkrhoratem.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoratem.Location = New System.Drawing.Point(568, 230)
        Me.DTPkrhoratem.Name = "DTPkrhoratem"
        Me.DTPkrhoratem.ShowUpDown = True
        Me.DTPkrhoratem.Size = New System.Drawing.Size(74, 19)
        Me.DTPkrhoratem.TabIndex = 107
        Me.DTPkrhoratem.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'DTPkrhoraini
        '
        Me.DTPkrhoraini.CustomFormat = "HH:mm"
        Me.DTPkrhoraini.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoraini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPkrhoraini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoraini.Location = New System.Drawing.Point(352, 230)
        Me.DTPkrhoraini.Name = "DTPkrhoraini"
        Me.DTPkrhoraini.ShowUpDown = True
        Me.DTPkrhoraini.Size = New System.Drawing.Size(74, 19)
        Me.DTPkrhoraini.TabIndex = 106
        Me.DTPkrhoraini.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'Lblht
        '
        Me.Lblht.AutoSize = True
        Me.Lblht.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblht.Location = New System.Drawing.Point(496, 232)
        Me.Lblht.Name = "Lblht"
        Me.Lblht.Size = New System.Drawing.Size(61, 15)
        Me.Lblht.TabIndex = 105
        Me.Lblht.Text = "TermiNA a:"
        '
        'Lblhi
        '
        Me.Lblhi.AutoSize = True
        Me.Lblhi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblhi.Location = New System.Drawing.Point(272, 232)
        Me.Lblhi.Name = "Lblhi"
        Me.Lblhi.Size = New System.Drawing.Size(67, 15)
        Me.Lblhi.TabIndex = 104
        Me.Lblhi.Text = "Comienza a:"
        '
        'cmdGenerar
        '
        Me.cmdGenerar.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.cmdGenerar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdGenerar.ImageIndex = 6
        Me.cmdGenerar.ImageList = Me.imgListBotonera
        Me.cmdGenerar.Location = New System.Drawing.Point(592, 328)
        Me.cmdGenerar.Name = "cmdGenerar"
        Me.cmdGenerar.Size = New System.Drawing.Size(64, 56)
        Me.cmdGenerar.TabIndex = 119
        Me.cmdGenerar.Text = "Generar"
        Me.cmdGenerar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label9.Location = New System.Drawing.Point(232, 336)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 15)
        Me.Label9.TabIndex = 118
        Me.Label9.Text = "Responsable:"
        '
        'CboResponsable
        '
        Me.CboResponsable.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CboResponsable.Location = New System.Drawing.Point(320, 336)
        Me.CboResponsable.Name = "CboResponsable"
        Me.CboResponsable.Size = New System.Drawing.Size(248, 21)
        Me.CboResponsable.TabIndex = 117
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Lblff)
        Me.GroupBox1.Controls.Add(Me.DTPKFecfin)
        Me.GroupBox1.Controls.Add(Me.Lblfi)
        Me.GroupBox1.Controls.Add(Me.DTPKFecini)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.Location = New System.Drawing.Point(232, 264)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(432, 56)
        Me.GroupBox1.TabIndex = 116
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Durante:"
        '
        'Lblff
        '
        Me.Lblff.AutoSize = True
        Me.Lblff.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lblff.Location = New System.Drawing.Point(232, 24)
        Me.Lblff.Name = "Lblff"
        Me.Lblff.Size = New System.Drawing.Size(70, 15)
        Me.Lblff.TabIndex = 107
        Me.Lblff.Text = "Fecha FiNAl:"
        '
        'DTPKFecfin
        '
        Me.DTPKFecfin.CustomFormat = "dd/MM/yyyy"
        Me.DTPKFecfin.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPKFecfin.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPKFecfin.Location = New System.Drawing.Point(312, 24)
        Me.DTPKFecfin.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPKFecfin.Name = "DTPKFecfin"
        Me.DTPKFecfin.Size = New System.Drawing.Size(109, 19)
        Me.DTPKFecfin.TabIndex = 106
        '
        'Lblfi
        '
        Me.Lblfi.AutoSize = True
        Me.Lblfi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lblfi.Location = New System.Drawing.Point(24, 24)
        Me.Lblfi.Name = "Lblfi"
        Me.Lblfi.Size = New System.Drawing.Size(70, 15)
        Me.Lblfi.TabIndex = 105
        Me.Lblfi.Text = "Fecha Inicio:"
        '
        'DTPKFecini
        '
        Me.DTPKFecini.CustomFormat = "dd/MM/yyyy"
        Me.DTPKFecini.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.DTPKFecini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPKFecini.Location = New System.Drawing.Point(104, 24)
        Me.DTPKFecini.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPKFecini.Name = "DTPKFecini"
        Me.DTPKFecini.Size = New System.Drawing.Size(109, 19)
        Me.DTPKFecini.TabIndex = 3
        '
        'LblRes
        '
        Me.LblRes.AutoSize = True
        Me.LblRes.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRes.Location = New System.Drawing.Point(80, 383)
        Me.LblRes.Name = "LblRes"
        Me.LblRes.Size = New System.Drawing.Size(0, 15)
        Me.LblRes.TabIndex = 122
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 507)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(670, 62)
        Me.tlbBotonera.TabIndex = 123
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.Enabled = False
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'FrmProgramaSesiones
        '
        Me.AutoScale = False
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 12)
        Me.ClientSize = New System.Drawing.Size(670, 569)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.LblRes)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Lblht)
        Me.Controls.Add(Me.Lblhi)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Lblchksala)
        Me.Controls.Add(Me.Lblsal)
        Me.Controls.Add(Me.LblSol)
        Me.Controls.Add(Me.TxtLugar)
        Me.Controls.Add(Me.Lbllugar)
        Me.Controls.Add(Me.TxtAsunto)
        Me.Controls.Add(Me.LblAsunto)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.cmdGenerar)
        Me.Controls.Add(Me.CboResponsable)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DTPkrhoratem)
        Me.Controls.Add(Me.DTPkrhoraini)
        Me.Controls.Add(Me.GridResultados)
        Me.Controls.Add(Me.GpBoxDefineProg)
        Me.Controls.Add(Me.GpBoxSincroniza)
        Me.Controls.Add(Me.CkBxSalasANCE)
        Me.Controls.Add(Me.CboSalas)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.tvComites)
        Me.Controls.Add(Me.CboEquipo)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmProgramaSesiones"
        Me.Text = "Programar Sesiones"
        Me.GpBoxSincroniza.ResumeLayout(False)
        Me.GpBoxDefineProg.ResumeLayout(False)
        CType(Me.NUDFrec2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDFrec, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridResultados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

#Region "Limpia(Casos), Metodos y Procesos"

    Private Function limpia(ByVal Casos As String) As Boolean
        Try
            TxtAsunto.Text = "" : TxtLugar.Text = ""
            DTPkrhoraini.ResetText() : DTPkrhoratem.ResetText()
            DTPKFecini.ResetText() : DTPKFecfin.ResetText()
            CboSalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
            NUDFrec.Value = 0 : NUDFrec2.Value = 0
            RBnSucede1.Checked = True
            DTRes.Rows.Clear()
            If Casos = "tvcomites" Then
                LblTreeView.Text = ""
                tvComites.Nodes.Clear()
                Call lleNA_ComiteTreeView()
            End If
            iEditar = ""
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

#Region " Valida(casos), Metodos y Procesos"

    Private Function valida(ByVal casos As String) As Boolean
        Cursor.Current = Cursors.WaitCursor
        Dim aCasos As Array
        Dim valreturn As Boolean = True
        aCasos = Split(casos, " _#_ ")
        Select Case aCasos(0)
            Case "comites"
                If LblTreeView.Text.Length <= 0 Then
                    ErrorProvider1.SetError(Lblcomite, "Debes seleccioNAr un Comite")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblcomite, "")
                End If
            Case "dtpker"
                If CStr(DTPKFecini.Value) = "" Then
                    ErrorProvider1.SetError(Lblfi, "Debes escribir la fecha de inicio de las  sesi�nes")
                    valreturn = False
                ElseIf CStr(DTPKFecfin.Value) = "" Then
                    ErrorProvider1.SetError(Lblff, "Debes escribir la fecha de fin de las  sesi�nes")
                    valreturn = False
                ElseIf (DTPKFecini.Value >= DTPKFecfin.Value) Then
                    ErrorProvider1.SetError(Lblfi, "No se puede programar uNA  sesi�n," + Chr(13) + "si no existe un periodo de fechas correcto.")
                    ErrorProvider1.SetError(Lblff, "Define un periodo de fechas correcto.")
                    valreturn = False
                ElseIf DTPKFecini.Value.ToShortDateString < Date.Now.ToShortDateString Then
                    ErrorProvider1.SetError(Lblfi, "No se puede programar uNA  sesi�n," + Chr(13) + "si con uNA  fecha menor a la actual.")
                    ErrorProvider1.SetError(Lblff, "Define un periodo de fechas correcto.")
                Else
                    ErrorProvider1.SetError(Lblfi, "")
                    ErrorProvider1.SetError(Lblff, "")
                End If

            Case "Asunto"
                If TxtAsunto.Text = "" Then
                    ErrorProvider1.SetError(LblAsunto, "Debes escribir el tema principal de la sesi�n")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(LblAsunto, "")
                End If

            Case "Lugar"
                If TxtLugar.Text = "" Then
                    ErrorProvider1.SetError(Lbllugar, "Debes escribir el Lugar de la sesi�n")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lbllugar, "")
                End If

            Case "salas"
                If CboSalas.SelectedValue = 0 Then
                    ErrorProvider1.SetError(CboSalas, "SeleccioNAste apartado de sala en ANCE." + Chr(13) + " Debes elegir uNA sala ahora o deshactivar la casilla de Apartado de sala.")
                    ErrorProvider1.SetError(Lblchksala, "Debes seleccioNAr la sala en  ANCE." + Chr(13) + " para habilitar las Salas")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(CboSalas, "")
                    ErrorProvider1.SetError(CkBxSalasANCE, "")
                End If

            Case "Horario"
                Dim HoraI As DateTime = DTPkrhoraini.Value
                Dim Horat As DateTime = DTPkrhoratem.Value
                If HoraI >= Horat Then
                    ErrorProvider1.SetError(Lblhi, "Debes escribir un Horario de inicio menor al de Termino de la sesion")
                    ErrorProvider1.SetError(Lblht, "Debes escribir un Horario de Termino mayor al de Inicio de  la sesion")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblhi, "")
                    ErrorProvider1.SetError(Lblht, "")
                End If
            Case "sucede"
                If RBnSucede1.Checked Then
                    If NUDFrec.Value = 0 Then
                        ErrorProvider1.SetError(LblCada, "Debes indicar la frecuencia en que se realizaran las sesiones")
                        valreturn = False
                    Else
                        ErrorProvider1.SetError(LblCada, "")
                    End If
                ElseIf RBnSucede2.Checked Then
                    If NUDFrec.Value = 0 Then
                        ErrorProvider1.SetError(LblCada, "Debes indicar la frecuencia en que se realizaran las sesiones")
                        valreturn = False
                    Else
                        ErrorProvider1.SetError(LblCada, "")
                    End If
                    If CkBLun.Checked Or CkBmartes.Checked Or CkBMiercoles.Checked Or CkBJueves.Checked Or CkBViernes.Checked Then
                        ErrorProvider1.SetError(CkBLun, "")
                    Else
                        ErrorProvider1.SetError(CkBLun, "Debes  indicar por lo menos un d�a de la semaNA")
                        valreturn = False
                    End If
                End If
        End Select
        Cursor.Current = Cursors.Default
        Return valreturn
    End Function

#End Region

#Region " Guardar(), Metodos y Procesos"

    Private Function guardar() As Boolean
        Cursor.Current = Cursors.WaitCursor
        Dim dt As New DataTable
        Dim dr As DataRow
        Dim dr2 As DataRow
        Dim array_texto As Array
        Dim i As Integer
        Try
            If iEditar = "Agregar" Then
                If valida("comites") And valida("dtpker") And valida("Horario") And valida("Asunto") And valida("Lugar") And valida("sucede") Then
                    array_texto = Split(stvcpath, " \ ")
                    dt = GridResultados.DataSource()
                    If dt.Rows.Count > 0 Then
                        Try
                            With objsesiones
                                Select Case array_texto.Length                   ''''''''''''''''''''''''''''' LleNAdo de las propiedades De Comite
                                    Case 1
                                        .Id_Comite = array_texto(0)
                                        .Id_CT = "NA"
                                        .Id_SC = "NA"
                                        .Id_Grupo = "NA"
                                    Case 2
                                        .Id_Comite = array_texto(0)
                                        .Id_CT = array_texto(1)
                                        .Id_SC = "NA"
                                        .Id_Grupo = "NA"
                                    Case 3
                                        .Id_Comite = array_texto(0)
                                        .Id_CT = array_texto(1)
                                        .Id_SC = array_texto(2)
                                        .Id_Grupo = "NA"
                                    Case 4
                                        .Id_Comite = array_texto(0)
                                        .Id_CT = array_texto(1)
                                        .Id_SC = array_texto(2)
                                        .Id_Grupo = array_texto(3)
                                End Select
                                For Each dr In dt.Rows
                                    ''''''''''''''''''''''''''''' Inserta datos en P_sesion, nuevo registro ''''''''''''''''''''''''''''' 
                                    .Fecha = Format$(CDate(dr(0)), "dd/MM/yyyy")
                                    .HoraI = Format(DTPkrhoraini.Value, "HH:mm")
                                    .HoraT = Format(DTPkrhoratem.Value, "HH:mm")
                                    .Asunto = TxtAsunto.Text()
                                    .Lugar = TxtLugar.Text
                                    .Responsable = CboResponsable.SelectedValue
                                    .Notas = ""
                                    .Status = 0
                                    .Bandera = 6
                                    Try
                                        Accion = .Insertar()
                                        sesion = .Id_Sesion
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G002 - Al intentar guardar Registro..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("agrega-borra", .Id_Sesion)
                                        Cursor.Current = Cursors.Default
                                        Return False
                                    End Try
                                    If CkBxSalasANCE.CheckState = CheckState.Checked Then
                                        If valida("salas") Then
                                            With objsalas
                                                .F_Solicitada = Format$(CDate(dr(0)), "dd/MM/yyyy")
                                                .F_Apartado = Format$(Now(), "dd/MM/yyyy")
                                                .Id_Area = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Sistema", "id_area")
                                                .Id_Propuesta = CboSalas.SelectedValue
                                                .Id_Responsable = CboResponsable.SelectedValue
                                                .Id_CoordiNAdor = CboResponsable.SelectedValue
                                                .H_Entrada = Format(DTPkrhoraini.Value, "HH:mm")
                                                .H_Salida = Format(DTPkrhoratem.Value, "HH:mm")
                                                .No_PersoNAs = 5
                                                .Reunion = TxtAsunto.Text
                                                .Servicio = ""
                                                .Acomodo = "Acomodo Unico"
                                                .Bandera = 1
                                                Try
                                                    Accion = .Insertar
                                                    solicitud = .No_Solicitud
                                                Catch ex As Exception When Accion = False Or solicitud = -1
                                                    MsgBox("Error G003 - Al intentar guardar o leer el  Registro de Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                    Restaurar("agrega-borra", sesion)
                                                    Cursor.Current = Cursors.Default
                                                    Return False
                                                End Try
                                            End With
                                            If CboEquipo.SelectedValue <> 0 Then
                                                With objsalas
                                                    .Equipo = CboEquipo.SelectedValue
                                                    .Bandera = 2
                                                    Try
                                                        Accion = .Insertar
                                                    Catch ex As Exception When Accion = False Or solicitud = -1
                                                        MsgBox("Error G004 - Al intentar guardar o leer el  Registro de Equipo en Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                        Restaurar("agrega-borra", sesion)
                                                        Restaurar("agrega-borra", solicitud)
                                                        Cursor.Current = Cursors.Default
                                                        Return False
                                                    End Try
                                                End With
                                            End If
                                            Try
                                                .No_Sol_Sala = solicitud
                                                .Id_Sesion = sesion
                                                .Bandera = 4
                                                Accion = .Actualizar
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G005 - Al intentar guardar o leer el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("agrega-borra", sesion)
                                                Restaurar("agrega-borra-solicitud", solicitud)
                                                Cursor.Current = Cursors.Default
                                                Return False
                                            End Try
                                            Try
                                                Accion = correo(CboSalas.SelectedValue, CboSalas.Text, solicitud)                    '''------------------- Correo  ------------------
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G006 - Al intentar Enviar un Mail, para el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message + Chr(13) + Chr(13) + "Favor de renviar un mail de tu solicitud " + CStr(solicitud) + " al encargado, para notificar el apartado de la sala.", MsgBoxStyle.Critical)
                                                Cursor.Current = Cursors.Default
                                            End Try
                                        End If
                                    End If

                                Next
                            End With
                        Catch ex As Exception
                            MsgBox("Error G001  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                            Restaurar("agrega-borra", sesion)
                            Restaurar("agrega-borra-solicitud", solicitud)
                            Cursor.Current = Cursors.Default
                            Return False
                        End Try
                    End If
                    MsgBox("NormaNET - Los datos se registraron de manera exitosa..." + Chr(13) + Chr(13), MsgBoxStyle.Information)
                Else
                    Return False
                End If
            Else
            End If
            Cursor.Current = Cursors.Default
            Return True
        Catch ex As Exception
            MsgBox("Error G001  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
            Restaurar("agrega-borra", sesion)
            Restaurar("agrega-borra-solicitud", solicitud)
            Cursor.Current = Cursors.Default
        End Try
    End Function

#End Region

#Region " Correo(Sala,salatxt,numsol), Metodos y Procesos"

    Public Function correo(ByVal sala As Integer, ByVal salatxt As String, ByVal numsol As Integer) As Boolean
        Dim mail As New clsCorreo.ClsCorreo
        Dim sto, scc
        Select Case sala
            Case 5
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion2")
            Case 9
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion2")
            Case 10
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecHum1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecHum2")
            Case 8
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Monterrey1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Monterrey2")
            Case 7
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Guadalajara1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Guadalajara2")
            Case Else
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecMat1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecMat2")
        End Select
        Try
            objempleados.Id_usuario = sto
            objempleados.Bandera = 3
            objempleados.Buscar()
            sto = objempleados.Email
            objempleados.Id_usuario = scc
            objempleados.Bandera = 3
            objempleados.Buscar()
            scc = objempleados.Email
            Dim Body = "<html><body background='http://intranet.ance.org.mx/salas/Imagenes/back2.jpg'><font color='#000000' face='Arial' size='3' ><font color='#660000' size='10'>Solicitud de Sala</font><br><br>Se ha generado uNA solicitud para el uso de  " + salatxt + ",<br>con la referencia n�mero:<br><br><font color='#006600' size='4'>" + CStr(numsol) + "<br><br> </font><font color='#660000' size='6'><a href='http://intranet.ance.org.mx/aplicaciones.asp' style='cursor:hand; color:#660000'>Aplicaciones de Intranet</a></font><br><br></font></body></html>" '
            mail.EnviarCorreo("Solicitud de Salas de NormaNET", sto, scc, "Solicitud de Salas", Body)
            Return True
        Catch ex As Exception
            MsgBox("Error G0012 - Al intentar Enviar un Mail, para el  Registro de Salas - NormaNET..." + Chr(13) + ex.Message + Chr(13) + Chr(13) + "Favor de renviar un mail de tu solicitud " + CStr(solicitud) + " al encargado, para notificar el apartado de la sala.", MsgBoxStyle.Critical)
            Return False
        End Try
    End Function

#End Region

#Region " Restaurar(casos,sesion), Metodos y Procesos"

    Public Sub Restaurar(ByVal caso As String, ByVal sesion As Integer)
        With objsesiones
            Select Case caso
                Case "agrega-borra"
                    .Id_Sesion = sesion
                    .Bandera = 200
                    Try
                        Accion = .Insertar()
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 001R - Al intentar restaurar integridad de los datos..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
                Case "agrega-borra-solicitud"
                    With objsalas
                        .No_Solicitud = sesion
                        .Bandera = 200
                        Try
                            Accion = .Insertar()
                        Catch ex As Exception When Accion = False
                            MsgBox("Error 002R - Al intentar restaurar integridad de los datos..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                        End Try
                    End With
            End Select
        End With
    End Sub

#End Region

#End Region

#Region " DataGrid - GridResultados, Medotos y Procesos"

    Private Sub Crea_gds()
        Try
            Cursor.Current = Cursors.WaitCursor
            DTRes.Columns.Add("Fecha")
            DTRes.Columns.Add("Hora_Inicio")
            DTRes.Columns.Add("Hora_fin")
            DTRes.Columns.Add("Comite")
            GridResultados.DataSource = DTRes

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, GridResultados)


            ts1.MappingNAme = "fechas"
            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingNAme = "Fecha"
            TextCol2.HeaderText = "Fecha Programada"
            TextCol2.Width = 160
            TextCol2.TextBox.ENAbled = False

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingNAme = "Hora_Inicio"
            TextCol3.HeaderText = "Hora Inicio"
            TextCol3.Width = 80
            TextCol3.TextBox.ENAbled = False

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingNAme = "Hora_fin"
            TextCol4.HeaderText = "Hora Termino"
            TextCol4.Width = 80
            TextCol4.TextBox.ENAbled = False

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingNAme = "Comite"
            TextCol5.HeaderText = "Comites"
            TextCol5.Width = 160
            TextCol5.TextBox.ENAbled = False

            ts1.GridColumnStyles.AddRange(New DataGridColumnStyle() {TextCol5, TextCol2, TextCol3, TextCol4})

            GridResultados.TableStyles.Add(ts1)


            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar dar formato al grid" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#Region " Forms -  FrmProgramaSesiones, Metodos y Procesos"

    Private Sub FrmProgramaSesiones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        formactivo = True
        Cursor.Current = Cursors.WaitCursor
        Call Crea_gds()
        Dim min As DateTime = DateTime.Now
        Dim time As TimeSpan = New TimeSpan(min.TimeOfDay.Days, 7, 0, 0, 0)
        min = DateTime.Today.Add(time)
        DTPkrhoraini.MinDate = min
        DTPkrhoraini.MaxDate = min.AddHours(16)
        DTPkrhoratem.MinDate = DTPkrhoraini.MinDate
        DTPkrhoratem.MaxDate = DTPkrhoraini.MaxDate
        Call lleNA_ComiteTreeView()
        RBnSucede1.Checked = True
        objempleados.Inicializa(Application.StartupPath & "\principal.ini", "comun", gUsuario, gPasswordSql)
        objempleados.Bandera = 6
        objempleados.ListaCombo(CboResponsable)
        objsalas.Bandera = 1
        objsalas.ListaCombo(CboSalas)
        objsalas.Bandera = 2
        objsalas.ListaCombo(CboEquipo)
        GridResultados.ReadOnly = True
        RBnSucede1.Checked = True
        INActivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, CboResponsable, CboSalas, CboEquipo, TxtAsunto, TxtLugar, CkBxSalasANCE, tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), tlbBotonera.Buttons(7), DTPkrhoraini, DTPkrhoratem, RBnSucede1, RBnSucede2, RBnSucede3, DTPKFecini, DTPKFecfin, cmdGenerar)
        Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(7))
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub FrmProgramaSesiones_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated

        If iEditar = Nothing Or iEditar = "" Then
            tvComites.Nodes.Clear()
            Call lleNA_ComiteTreeView()
        End If

    End Sub

#End Region

#Region " TreeView - tvComites, Metodos y Procesos"

#Region " tvComites - lleNA_ComiteTreeView, Metodos y Procesos"

    Private Sub lleNA_ComiteTreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        tvComites.EndUpdate()
        tvComites.ResetText()
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  tvComites -  tvComites_AfterSelect(Object,TreeViewEventArgs) , Control TreeView"

    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblcomite, "")
        Dim valor_nodo, valor As String
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione el comite" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")

        Select Case UCase(Mid(lblarray(lblarray.Length - 1), 1, 2))
            Case "CT"
                stvcpath = lblarray(0) + " \ " + lblarray(1)

            Case "SC"
                Select Case lblarray.Length
                    Case 2
                        stvcpath = lblarray(0) + " \ NA \ " + lblarray(1)
                    Case 3
                        stvcpath = lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2)
                End Select

            Case "GT"
                Select Case lblarray.Length
                    Case 2
                        stvcpath = lblarray(0) + " \ NA \ NA \ " + lblarray(1)
                    Case 3
                        If UCase(Mid(lblarray(1), 1, 2)) = "CT" Then
                            stvcpath = lblarray(0) + " \ " + lblarray(1) + " \ NA \ " + lblarray(2)
                        ElseIf UCase(Mid(lblarray(1), 1, 2)) = "SC" Then
                            stvcpath = lblarray(0) + " \ NA \ " + lblarray(1) + " \ " + lblarray(2)
                        End If
                    Case 4
                        stvcpath = lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ " + lblarray(3)
                End Select

            Case Else
                If lblarray.Length = 1 Then
                    stvcpath = lblarray(0)
                End If

        End Select
        TxtAsunto.Focus()
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

#Region " ToolBar - tlbBotonera, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1                   '''------------------   Agregar     ----------------
                If valida("comites") Then
                    Call limpia("")
                    iEditar = "Agregar"
                    Activos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, CboResponsable, TxtAsunto, TxtLugar, DTPkrhoraini, DTPkrhoratem, RBnSucede1, RBnSucede2, RBnSucede3, DTPKFecini, DTPKFecfin, tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(7))
                    Inactivos(tlbBotonera.Buttons(1), cmdGenerar, tvComites)
                Else
                    formactivo = False
                    Dim Frmcomite As New frmP_Comite
                    If MsgBox("�Deseas crear un nuevo comite?", MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        ErrorProvider1.SetError(Lblcomite, "")
                        Frmcomite.Show()
                    End If
                End If
            Case 2                   '''----------   Edita     --------
            Case 3                   '''------------------   Deshacer     ------------------
                Call limpia("tvcomites")
                Inactivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, CboResponsable, CboSalas, CboEquipo, TxtAsunto, TxtLugar, CkBxSalasANCE, tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), tlbBotonera.Buttons(7), DTPkrhoraini, DTPkrhoratem, RBnSucede1, RBnSucede2, RBnSucede3, DTPKFecini, DTPKFecfin, cmdGenerar)
                Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(7), tvComites)

            Case 4                   '''--------------------   Guardar     ------------------
                Try
                    If GridResultados.VisibleRowCount > 0 Then
                        Inactivos(tlbBotonera)
                        Accion = guardar()
                        If Accion Then
                            Call limpia("tvcomites")
                            Inactivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, CboResponsable, CboSalas, CboEquipo, TxtAsunto, TxtLugar, CkBxSalasANCE, tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), tlbBotonera.Buttons(7), DTPkrhoraini, DTPkrhoratem, RBnSucede1, RBnSucede2, RBnSucede3, DTPKFecini, DTPKFecfin, cmdGenerar)
                            Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(7), tvComites)
                        End If
                        Activos(tlbBotonera)
                    Else
                        Call limpia("tvcomites")
                        Inactivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, CboResponsable, CboSalas, CboEquipo, TxtAsunto, TxtLugar, CkBxSalasANCE, tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), tlbBotonera.Buttons(7), DTPkrhoraini, DTPkrhoratem, RBnSucede1, RBnSucede2, RBnSucede3, DTPKFecini, DTPKFecfin, cmdGenerar)
                        Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(7), tvComites)
                    End If

                Catch ex As Exception When Accion = False
                    MsgBox("Error C000  " + Chr(13) + Chr(13) + "Faltan datos en el formulario." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    Activos(tlbBotonera)
                    Cursor.Current = Cursors.Default
                End Try
            Case 5                   '''----------   ElimiNAr     --------
            Case 7                   '''--------------------   Salir     ------------------
                iEditar = "Espera"
                Me.Close()
        End Select

        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Radiobutton, Metodos y Procesos"

#Region "Radiobutton - RBnSucede1, Metodos y Procesos"

    Private Sub RBnSucede1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RBnSucede1.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        NUDFrec.Value = 0
        If RBnSucede1.Checked Then
            Oculta(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            INActivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            RBnSucede2.Checked = False
            RBnSucede3.Checked = False
            GpBoxDefineProg.Text = "Diariamente"
            Lblcada2.Text = " d�as."
            LblCada.Text = "Cada"
            Muestra(LblCada, Lblcada2, NUDFrec)
            Activos(cmdGenerar, LblCada, Lblcada2, NUDFrec)
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "Radiobutton - RBnSucede2, Metodos y Procesos"

    Private Sub RBnSucede2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RBnSucede2.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        CkBLun.Checked = False : CkBmartes.Checked = False : CkBMiercoles.Checked = False : CkBJueves.Checked = False : CkBViernes.Checked = False
        NUDFrec.Value = 0
        If RBnSucede2.Checked Then
            Oculta(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            INActivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            RBnSucede1.Checked = False
            RBnSucede3.Checked = False
            GpBoxDefineProg.Text = "SemaNAlmente"
            Lblcada2.Text = " semaNAs el:"
            LblCada.Text = "Cada"
            Muestra(LblCada, Lblcada2, NUDFrec, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            Activos(LblCada, Lblcada2, NUDFrec, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, cmdGenerar)
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "Radiobutton -RBnSucede3, Metodos y Procesos"

    Private Sub RBnSucede3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RBnSucede3.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        NUDFrec.Value = 0 : NUDFrec2.Value = 0
        If RBnSucede3.Checked Then
            Oculta(Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            INActivos(Lblcada3, Lblcada4, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes)
            RBnSucede1.Checked = False
            RBnSucede2.Checked = False
            LblCada.Text = "El d�a"
            GpBoxDefineProg.Text = "Mensualmente"
            Muestra(Lblcada3, Lblcada4, NUDFrec, NUDFrec2)
            Activos(Lblcada3, Lblcada4, NUDFrec2, cmdGenerar)
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

#Region "CheckBox, Metodos y Procesos"

#Region "CheckBox - CkBxSalasANCE, Metodos y Procesos"

    Private Sub CkBxSalasANCE_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CkBxSalasANCE.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        CboEquipo.Text = ""
        CboSalas.Text = ""
        If CkBxSalasANCE.CheckState = CheckState.Checked Then
            Activos(CboSalas, CboEquipo)
        Else
            INActivos(CboSalas, CboEquipo)
        End If
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub CkBxSalasANCE_ENAbledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBxSalasANCE.ENAbledChanged
        If iEditar <> "Genera" Then CkBxSalasANCE.Checked = CheckState.Unchecked
    End Sub
#End Region

#Region "CheckBox - ckblun, Metodos y Procesos"

    Private Sub CkBLun_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBLun.CheckStateChanged
        ErrorProvider1.SetError(CkBLun, "")
    End Sub

#End Region

#Region "CheckBox - CkBmartes, Metodos y Procesos"

    Private Sub CkBmartes_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBmartes.CheckStateChanged
        ErrorProvider1.SetError(CkBLun, "")
    End Sub

#End Region

#Region "CheckBox - CkBMiercoles, Metodos y Procesos"

    Private Sub CkBMiercoles_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBMiercoles.CheckStateChanged
        ErrorProvider1.SetError(CkBLun, "")
    End Sub

#End Region

#Region "CheckBox - CkBJueves, Metodos y Procesos"

    Private Sub CkBJueves_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBJueves.CheckStateChanged
        ErrorProvider1.SetError(CkBLun, "")
    End Sub

#End Region

#Region "CheckBox - CkBViernes, Metodos y Procesos"

    Private Sub CkBViernes_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBViernes.CheckStateChanged
        ErrorProvider1.SetError(CkBLun, "")
    End Sub

#End Region

#End Region

#Region " Bot�n - CmdGenerar, Metodos y Procesos"

    Private Sub cmdGenerar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGenerar.Click
        Dim dr As DataRow
        Dim dr2 As DataRow
        Dim di As DateTime = DTPKFecini.Value
        Dim din, dfn As DateTime
        Cursor.Current = Cursors.WaitCursor
        Dim inumero As Integer = 0
        Dim JoursOuvrables
        Try
            If iEditar = "Agregar" And valida("comites") And valida("dtpker") And valida("Horario") And valida("Asunto") And valida("sucede") Then
                DTRes.Rows.Clear()
                iEditar = "Genera"
                i = 0
                din = di
                INActivos(LblCada, Lblcada2, Lblcada3, Lblcada4, NUDFrec, NUDFrec2, CkBLun, CkBmartes, CkBMiercoles, CkBJueves, CkBViernes, CboResponsable, CboSalas, CboEquipo, TxtAsunto, TxtLugar, CkBxSalasANCE, DTPkrhoraini, DTPkrhoratem, RBnSucede1, RBnSucede2, RBnSucede3, DTPKFecini, DTPKFecfin, tvComites)
                While di <= DTPKFecfin.Value
                    If RBnSucede1.Checked Then
                        If Format$(di, "dddd").ToLower <> "s�bado" And Format$(di, "dddd").ToLower <> "domingo" Then
                            dr = DTRes.NewRow
                            dr(0) = Format$(di, "dddd, dd/MM/yyyy")
                            dr(1) = Format$(DTPkrhoraini.Value, "HH:mm")
                            dr(2) = Format$(DTPkrhoratem.Value, "HH:mm")
                            dr(3) = LblTreeView.Text
                            DTRes.Rows.Add(dr)
                        End If
                        di = di.AddDays(NUDFrec.Value)
                    ElseIf RBnSucede2.Checked Then
                        Dim fecha As Boolean
                        dfn = din
                        While din <= dfn.AddDays(5) And din <= DTPKFecfin.Value
                            If CkBLun.Checked And Weekday(din, FirstDayOfWeek.Monday) = 1 Then
                                fecha = True
                            ElseIf CkBmartes.Checked And Weekday(din, FirstDayOfWeek.Tuesday) = 1 Then
                                fecha = True
                            ElseIf CkBMiercoles.Checked And Weekday(din, FirstDayOfWeek.Wednesday) = 1 Then
                                fecha = True
                            ElseIf CkBJueves.Checked And Weekday(din, FirstDayOfWeek.Thursday) = 1 Then
                                fecha = True
                            ElseIf CkBViernes.Checked And Weekday(din, FirstDayOfWeek.Friday) = 1 Then
                                fecha = True
                            ElseIf Weekday(din, FirstDayOfWeek.Saturday) = 1 Then
                                di = din.AddDays(-5)
                                Exit While
                            End If
                            If fecha Then
                                dr = DTRes.NewRow
                                dr(0) = Format$(din, "dddd, dd/MM/yyyy")
                                dr(1) = Format$(DTPkrhoraini.Value, "HH:mm")
                                dr(2) = Format$(DTPkrhoratem.Value, "HH:mm")
                                dr(3) = LblTreeView.Text
                                DTRes.Rows.Add(dr)
                                fecha = False
                            End If
                            din = din.AddDays(1)
                        End While
                        di = di.AddDays(CInt(NUDFrec.Value) * 7)
                        din = di
                    ElseIf RBnSucede3.Checked Then

                        dfn = DTPKFecfin.Value
                        dr = DTRes.NewRow
                        din = CDate("" + CStr(CInt(NUDFrec.Value)) + "/" + Format(din, "MM/yyyy"))
                        If din > DTPKFecini.Value And din < DTPKFecfin.Value Then
                            If Weekday(din, FirstDayOfWeek.Saturday) <> 1 And Weekday(din, FirstDayOfWeek.Sunday) <> 1 Then
                                dr(0) = Format$(din, "dddd, dd/MM/yyyy")
                                dr(1) = Format$(DTPkrhoraini.Value, "HH:mm")
                                dr(2) = Format$(DTPkrhoratem.Value, "HH:mm")
                                dr(3) = LblTreeView.Text
                                DTRes.Rows.Add(dr)
                            End If
                        End If
                        din = din.AddMonths(CInt(NUDFrec2.Value))
                        di = ("01/" + Format(din, "MM/yyyy"))

                    End If
                End While
                GridResultados.DataSource = DTRes
                Activos(tlbBotonera.Buttons(4))
                LblRes.Text = CStr(DTRes.Rows.Count)
                iEditar = "Agregar"
            End If
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar crear fechas para sesioNAr" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

#End Region

#Region " Textbox, Todos los metodos y procedimientos"

#Region " TxtLugar, Todos los metodos y procedimientos"

    Private Sub TxtLugar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtLugar.KeyPress
        Dim ahora As Array
        If e.KeyChar.IsLetterOrDigit(e.KeyChar) AndAlso Not e.KeyChar.IsControl(e.KeyChar) Or e.KeyChar = ControlChars.Back Then
            e.Handled = False
            Activos(cmdGenerar)
            TxtLugar_TextChanged(TxtLugar, e)
        End If
        If e.KeyChar = "'"c Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtLugar_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtLugar.TextChanged
        If iEditar = "Agregar" Then
            If Trim(TxtLugar.Text.ToUpper) = "ANCE" Then
                Activos(CkBxSalasANCE, Lblchksala) ', CboEquipo, LblSol
            Else
                INActivos(CkBxSalasANCE, Lblchksala)
            End If
        End If
    End Sub

#End Region

#Region " TxtAsunto, Todos los metodos y procedimientos"

    Private Sub TxtAsunto_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtAsunto.TextChanged
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(LblAsunto, "")
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub TxtAsunto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtAsunto.KeyPress
        If e.KeyChar = "'"c Then
            e.Handled = True
        Else
            Activos(cmdGenerar)
        End If
    End Sub

#End Region

#End Region

#Region " DatePacker, Todos los Metodos y Procesos"

#Region "  DatePacker - DTPkrhoraini, Todos los Metodos y Procesos"

    Private Sub DTPkrhoraini_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPkrhoraini.ValueChanged
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblhi, "")
        ErrorProvider1.SetError(Lblht, "")
        Activos(cmdGenerar)
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  DatePacker - DTPkrhoratem, Todos los Metodos y Procesos"

    Private Sub DTPkrhoratem_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPkrhoratem.ValueChanged
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblhi, "")
        ErrorProvider1.SetError(Lblht, "")
        Activos(cmdGenerar)
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  DatePacker - DTPKFecini, Todos los Metodos y Procesos"

    Private Sub DTPKFecini_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPKFecini.ValueChanged
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblfi, "")
        ErrorProvider1.SetError(Lblff, "")
        Activos(cmdGenerar)
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " DatePacker - DTPKFecfin, Todos los Metodos y Procesos"

    Private Sub DTPKFecfin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPKFecfin.ValueChanged
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblfi, "")
        ErrorProvider1.SetError(Lblff, "")
        Activos(cmdGenerar)
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region





End Class
