Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections
Imports System.Drawing


Public Class FrmAsig_Rev_Edit
    Inherits System.Windows.Forms.Form
    Dim existe, Accion As Boolean
    Dim keyascii As Short
    Dim sCbovalue, illenos As Integer
    Dim sError, iEditar, sValTreeView, svaluescbo, shoraiPk, shoratPk, sArchivo, sCboTxt As String
    Dim lleno As Integer = 0
    Dim DTContenedorErrores As DataTable

#Region " ******* Inicializaci�n de Dll's  *******"

    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objstatus_revedit As New Cls_Status_Rev_Edit.Cls_Status_Rev_Edit("principal", gUsuario, gPasswordSql)
    Dim objTipos_RevEdit As New Cls_Tipos_RevEdit.Cls_tipos_RE("principal", gUsuario, gPasswordSql)
    Dim objincisos As New Cls_Incisos_RE.Cls_Incisos_RE("principal", gUsuario, gPasswordSql)
    Dim objPRE As New Cls_P_Rev_edit.Cls_P_Rev_edit("principal", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
        objplanes.Inicializa(0, gUsuario, gPasswordSql)
        objempleados.Inicializa(Application.StartupPath & "\principal.ini","comun",gUsuario, gPasswordSql)

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSeguimiento As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents f1 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents txtdocumento As System.Windows.Forms.TextBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents CmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents DTPkFech_Entrega As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPkFech_compromiso As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbltemas As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents LblResponsable As System.Windows.Forms.Label
    Friend WithEvents TVProgTemas As System.Windows.Forms.TreeView
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtnumpag As System.Windows.Forms.TextBox
    Friend WithEvents cmdExaminar As System.Windows.Forms.Button
    Friend WithEvents cmdAsignar As System.Windows.Forms.ToolBarButton
    Friend WithEvents lblnumpag As System.Windows.Forms.Label
    Friend WithEvents LblDocumento As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmAsig_Rev_Edit))
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.cmdAsignar = New System.Windows.Forms.ToolBarButton
        Me.cmdSeguimiento = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.DTPkFech_Entrega = New System.Windows.Forms.DateTimePicker
        Me.f1 = New System.Windows.Forms.Label
        Me.DTPkFech_compromiso = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.TVProgTemas = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.LblResponsable = New System.Windows.Forms.Label
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.txtnumpag = New System.Windows.Forms.TextBox
        Me.lblnumpag = New System.Windows.Forms.Label
        Me.txtdocumento = New System.Windows.Forms.TextBox
        Me.LblDocumento = New System.Windows.Forms.Label
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.Lbltemas = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.cmdExaminar = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdGuardar, Me.CmdBorrar, Me.cmdAsignar, Me.cmdSeguimiento, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 290)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(594, 62)
        Me.tlbBotonera.TabIndex = 16
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdGuardar
        '
        Me.CmdGuardar.ImageIndex = 2
        Me.CmdGuardar.Text = "Guardar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'cmdAsignar
        '
        Me.cmdAsignar.ImageIndex = 7
        Me.cmdAsignar.Text = "Asignar"
        Me.cmdAsignar.ToolTipText = "Asignas una Revici�n  Editorial al Tema"
        '
        'cmdSeguimiento
        '
        Me.cmdSeguimiento.ImageIndex = 6
        Me.cmdSeguimiento.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        Me.cmdSeguimiento.Text = "Seguimiento"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'DTPkFech_Entrega
        '
        Me.DTPkFech_Entrega.CustomFormat = "dd/MM/yyyy"
        Me.DTPkFech_Entrega.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPkFech_Entrega.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkFech_Entrega.Location = New System.Drawing.Point(352, 32)
        Me.DTPkFech_Entrega.Name = "DTPkFech_Entrega"
        Me.DTPkFech_Entrega.Size = New System.Drawing.Size(112, 19)
        Me.DTPkFech_Entrega.TabIndex = 38
        Me.DTPkFech_Entrega.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'f1
        '
        Me.f1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.f1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.f1.Location = New System.Drawing.Point(192, 32)
        Me.f1.Name = "f1"
        Me.f1.Size = New System.Drawing.Size(160, 32)
        Me.f1.TabIndex = 39
        Me.f1.Text = "Fecha de Entrega al Revisor:"
        '
        'DTPkFech_compromiso
        '
        Me.DTPkFech_compromiso.CustomFormat = "dd/MM/yyyy"
        Me.DTPkFech_compromiso.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPkFech_compromiso.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkFech_compromiso.Location = New System.Drawing.Point(352, 152)
        Me.DTPkFech_compromiso.Name = "DTPkFech_compromiso"
        Me.DTPkFech_compromiso.Size = New System.Drawing.Size(112, 19)
        Me.DTPkFech_compromiso.TabIndex = 41
        Me.DTPkFech_compromiso.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label1.Location = New System.Drawing.Point(192, 152)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 32)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "Fecha Compromiso de Respuesta del Revisor:"
        '
        'TVProgTemas
        '
        Me.TVProgTemas.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TVProgTemas.ImageIndex = 3
        Me.TVProgTemas.ImageList = Me.imgListTreeView
        Me.TVProgTemas.Location = New System.Drawing.Point(16, 48)
        Me.TVProgTemas.Name = "TVProgTemas"
        Me.TVProgTemas.SelectedImageIndex = 4
        Me.TVProgTemas.Size = New System.Drawing.Size(168, 232)
        Me.TVProgTemas.TabIndex = 44
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(16, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'LblResponsable
        '
        Me.LblResponsable.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.LblResponsable.Location = New System.Drawing.Point(192, 72)
        Me.LblResponsable.Name = "LblResponsable"
        Me.LblResponsable.Size = New System.Drawing.Size(160, 16)
        Me.LblResponsable.TabIndex = 45
        Me.LblResponsable.Text = "Responsable Revisi�n:"
        '
        'cboResponsable
        '
        Me.cboResponsable.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboResponsable.ItemHeight = 13
        Me.cboResponsable.Location = New System.Drawing.Point(352, 70)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(232, 21)
        Me.cboResponsable.TabIndex = 47
        '
        'txtnumpag
        '
        Me.txtnumpag.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumpag.Location = New System.Drawing.Point(352, 112)
        Me.txtnumpag.Name = "txtnumpag"
        Me.txtnumpag.Size = New System.Drawing.Size(64, 19)
        Me.txtnumpag.TabIndex = 60
        Me.txtnumpag.Text = ""
        '
        'lblnumpag
        '
        Me.lblnumpag.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblnumpag.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblnumpag.Location = New System.Drawing.Point(192, 114)
        Me.lblnumpag.Name = "lblnumpag"
        Me.lblnumpag.Size = New System.Drawing.Size(160, 16)
        Me.lblnumpag.TabIndex = 59
        Me.lblnumpag.Text = "N�mero Paginas:"
        '
        'txtdocumento
        '
        Me.txtdocumento.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdocumento.Location = New System.Drawing.Point(296, 249)
        Me.txtdocumento.Name = "txtdocumento"
        Me.txtdocumento.Size = New System.Drawing.Size(256, 19)
        Me.txtdocumento.TabIndex = 62
        Me.txtdocumento.Text = ""
        '
        'LblDocumento
        '
        Me.LblDocumento.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblDocumento.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.LblDocumento.Location = New System.Drawing.Point(192, 251)
        Me.LblDocumento.Name = "LblDocumento"
        Me.LblDocumento.Size = New System.Drawing.Size(56, 16)
        Me.LblDocumento.TabIndex = 61
        Me.LblDocumento.Text = "Archivo:"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'Lbltemas
        '
        Me.Lbltemas.AutoSize = True
        Me.Lbltemas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Lbltemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Lbltemas.Location = New System.Drawing.Point(8, 8)
        Me.Lbltemas.Name = "Lbltemas"
        Me.Lbltemas.Size = New System.Drawing.Size(122, 15)
        Me.Lbltemas.TabIndex = 89
        Me.Lbltemas.Text = "Proyecto Seleccionado: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.93!)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 24)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 14)
        Me.LblTreeView.TabIndex = 88
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmdExaminar
        '
        Me.cmdExaminar.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExaminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdExaminar.Location = New System.Drawing.Point(560, 248)
        Me.cmdExaminar.Name = "cmdExaminar"
        Me.cmdExaminar.Size = New System.Drawing.Size(24, 23)
        Me.cmdExaminar.TabIndex = 90
        Me.cmdExaminar.Text = "...."
        '
        'FrmAsig_Rev_Edit
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 12)
        Me.ClientSize = New System.Drawing.Size(594, 352)
        Me.Controls.Add(Me.cmdExaminar)
        Me.Controls.Add(Me.Lbltemas)
        Me.Controls.Add(Me.txtdocumento)
        Me.Controls.Add(Me.txtnumpag)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.LblDocumento)
        Me.Controls.Add(Me.lblnumpag)
        Me.Controls.Add(Me.LblResponsable)
        Me.Controls.Add(Me.cboResponsable)
        Me.Controls.Add(Me.TVProgTemas)
        Me.Controls.Add(Me.DTPkFech_compromiso)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DTPkFech_Entrega)
        Me.Controls.Add(Me.f1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmAsig_Rev_Edit"
        Me.Text = "Asignaci�n de Revisi�n Editorial"
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos "

#Region " Funciones - Valida(casos), Metodos y Procesos "

    Private Function Valida(ByVal casos As String) As Boolean
        Dim aCasos As Array
        Dim valreturn As Boolean = True
        aCasos = Split(casos, " _#_ ")
        Select Case aCasos(0)
            Case "TVProgTemas"
                If LblTreeView.Text.Length <= 0 Then
                    ErrorProvider1.SetError(LblTreeView, "Debes seleccionar un Tema")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(LblTreeView, "")
                End If
            Case "Paginas"
                If txtnumpag.Text.Trim = "" Then
                    ErrorProvider1.SetError(lblnumpag, "Debes indicar el n�mero de p�ginas" + Chr(13) + "del documento.")
                    valreturn = False
                Else
                    If Not IsNumeric(txtnumpag.Text.Trim) Then
                        ErrorProvider1.SetError(lblnumpag, "Debes escribir s�lo n�meros")
                        valreturn = False
                    Else
                        ErrorProvider1.SetError(lblnumpag, "")
                    End If
                End If
            Case "Revisor"
                If cboResponsable.SelectedValue = "" Then
                    ErrorProvider1.SetError(LblResponsable, "Debes seleccionar un Revisor al Tema")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(LblResponsable, "")
                End If
            Case "Directorio"
                Dim sPath = aCasos(1)
                Try
                    If Directory.Exists(sPath) = False Then
                        valreturn = False
                        'MkDir(sPath)
                    End If
                Catch ex As Exception
                    MsgBox("Error V004 - Al intentar crear una carpeta en el servidor ..." + Chr(13) + sPath + Chr(13) + ex.Message, MsgBoxStyle.Critical) '
                    valreturn = False
                End Try
            Case "Archivo"
                If txtdocumento.Text = "" Then
                    ErrorProvider1.SetError(LblDocumento, "Debes seleccionar un Revisor al Tema")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(LblDocumento, "")
                End If
        End Select
        Return valreturn
    End Function

#End Region

#Region " Restaurar Datos, Metodos y Procesos"

    Private Function Restaurar(ByVal caso As String, ByVal Revision_Error As Integer)
        Select Case caso
            Case "agrega-borra"
                objPRE.Id_Rev_Edit = Revision_Error
                objPRE.Bandera = 201
                Try
                    Accion = objPRE.Insertar()
                Catch ex As Exception When Accion = False
                    MsgBox("Error 002R - Al intentar restaurar integridad de los datos..." + Chr(13) + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                End Try
        End Select

    End Function

#End Region

#Region " Funciones - Asignar(), Metodos y Procesos "

    Private Function Asignar() As Boolean
        Dim array_texto As Array
        Dim i As Integer
        Try
            array_texto = Split(LblTreeView.Text, " - ")
            If Valida("TVProgTemas") And Valida("Paginas") And Valida("Revisor") And Valida("Archivo") Then
                If iEditar = "Agregar" Then          ''''''''''''''''''''''''''''''''''''''''''''''''''''''''Agregando Asignaci�n--------------------------------------------------------------------------------------
                    With objPRE
                        '    Dim namefile As Array = Split(sArchivo, "\")
                        Dim comite As String
                        .Bandera = 1
                        .Id_Plan = array_texto(0)
                        .Id_Tema = array_texto(1)
                        objprogtrab.Buscar(array_texto(0), array_texto(1))
                        If objprogtrab.ID_Comite <> "NA" Then comite = objprogtrab.ID_Comite
                        If objprogtrab.ID_CT <> "NA" Then comite = comite + "\" + objprogtrab.ID_CT
                        If objprogtrab.ID_SC <> "NA" Then comite = comite + "\" + objprogtrab.ID_SC
                        If objprogtrab.ID_Grupo <> "NA" Then comite = comite + "\" + objprogtrab.ID_Grupo
                        Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + comite)
                        Try
                            Accion = Valida("Directorio" + " _#_ " + sPath)
                        Catch ex As Exception When Accion = False
                            Return False
                        End Try
                        Try
                            If txtdocumento.Text <> "" Then
                                If File.Exists(sPath + "\" + txtdocumento.Text) Then       'namefile(namefile.Length - 1)
                                    If MsgBox("El archivo (" + txtdocumento.Text + ") ya existe en el Servidor..." + Chr(13) + Chr(13) + " �Desea sobrescribir el archivo?", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                                        File.Copy(sArchivo, sPath + "\" + txtdocumento.Text, True)
                                    End If
                                Else
                                    File.Copy(sArchivo, sPath + "\" + txtdocumento.Text)
                                End If
                            End If
                        Catch ex As Exception When Accion = False
                            MsgBox("Error - No se pudo copiar el archivo al lugar de destino" + Chr(13) + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                            Return False
                        End Try
                        .Documento = txtdocumento.Text
                        .F_Entrega_Revisor = DTPkFech_Entrega.Text
                        .F_Compromiso_Revisor = DTPkFech_compromiso.Text
                        .Id_Usuario_Revisor = cboResponsable.SelectedValue
                        .Num_Pag_Rev_Edit = txtnumpag.Text
                        .Insertar()
                    End With
                    Return True
                End If
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox("Error G000  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
            If iEditar = "Agregar" Then
                Restaurar("agrega-borra", objPRE.Id_Rev_Edit)
            End If
            Return False
        End Try
    End Function

#End Region

#Region "Sub - Limpia,  Metodos y Procesos "

    Private Sub Limpia()
        LblTreeView.ResetText()
        cboResponsable.SelectedValue = 0 : txtnumpag.ResetText() : txtdocumento.ResetText()
        DTPkFech_Entrega.ResetText() : DTPkFech_compromiso.ResetText()
        TVProgTemas.Nodes.Clear()
        Call LlenaTreeView()
        sArchivo = Nothing
    End Sub

#End Region


#End Region

#Region " TreeView - TVProgTemas, Metodos y Procesos"

    Public Sub LlenaTreeView()
        Try
            Cursor.Current = Cursors.WaitCursor
            Dim Planes As TreeNode
            Dim Plan As TreeNode
            Dim Temas As TreeNode

            Dim oTablaPlan As DataTable
            Dim oTablaTemas As DataTable

            Dim RegPlan As DataRow
            Dim RegTemas As DataRow
            objplanes.Bandera = 1
            oTablaPlan = objplanes.Listar
            TVProgTemas.BeginUpdate()
            Planes = TVProgTemas.Nodes.Add("Seleccione un Tema")
            Planes.ImageIndex = 2
            Planes.SelectedImageIndex = 2

            If oTablaPlan.Rows Is Nothing Then
                TVProgTemas.EndUpdate()
                TVProgTemas.AllowDrop = True
                TVProgTemas.Sorted = True
                Cursor.Current = Cursors.Default
                Exit Sub
            End If

            For Each RegPlan In oTablaPlan.Rows '******Planes
                Plan = Planes.Nodes.Add(Trim(RegPlan("id_plan")))
                objprogtrab.Bandera = 12
                objprogtrab.Id_Plan = Trim(RegPlan("id_plan"))
                oTablaTemas = objprogtrab.Listar
                If oTablaTemas.Rows Is Nothing Then 'Valida si no existen nodos hijos
                    GoTo temas
                End If
                For Each RegTemas In oTablaTemas.Rows '******Temas de PNN
                    Temas = Plan.Nodes.Add(Trim(RegTemas("id_tema")))
                    Temas.ImageIndex = 5
                    Temas.SelectedImageIndex = 5
                Next
temas:
            Next
            TVProgTemas.EndUpdate()
            ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
            TVProgTemas.AllowDrop = True
            ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
            'TVProgTemas.Sorted = True
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MessageBox.Show("Error - Revisi�n Editorial " & Chr(13) & Chr(13) & ex.ToString & ex.Message, "Revisi�n Editorial", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    Private Sub TVProgTemas_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVProgTemas.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(LblTreeView, "")
        Dim valor_nodo, valor As String
        Dim ivalor As Integer
        Dim array_texto As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione un Tema" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        Select Case array_texto.Length
            Case 0
                Activos(tlbBotonera.Buttons(0))
            Case 3
                Activos(tlbBotonera.Buttons(0))
            Case Else
                Inactivos(tlbBotonera.Buttons(0))
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Forms - FrmRevisionEditorial, Metodos y Procesos"

    Private Sub FrmRevisionEditorial_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        Cursor.Current = Cursors.WaitCursor
        iEditar = ""
        Call Limpia()
        objempleados.Bandera = 6
        objempleados.ListaCombo(cboResponsable)
        Cursor.Current = Cursors.Default
        With tlbBotonera
            Inactivos(.Buttons(1), .Buttons(2), .Buttons(3), .Buttons(4), .Buttons(5), .Buttons(6), DTPkFech_compromiso, DTPkFech_Entrega, txtnumpag, txtdocumento, cboResponsable, cmdExaminar)
        End With


    End Sub

#End Region

#Region " ToolBar - TlbBotonera, Metodos y Procesos "

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        With tlbBotonera
            Select Case tlbBotonera.Buttons.IndexOf(e.Button)
                Case 0
                    If Valida("TVProgTemas") Then
                        iEditar = "Agregar"
                        Inactivos(TVProgTemas, .Buttons(0))
                        Activos(cboResponsable, txtnumpag, cmdExaminar, .Buttons(5), .Buttons(2))
                    Else
                        Dim frmPNN As New frmPNN
                        If MsgBox("�Deseas crear un nuevo Plan?", MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                            ErrorProvider1.SetError(LblTreeView, "")
                            frmPNN.Show()
                        End If
                        Call Limpia()
                    End If
                Case 2
                    Call Limpia()
                    Inactivos(cboResponsable, txtnumpag, cmdExaminar, .Buttons(5), .Buttons(2))
                    Activos(TVProgTemas, .Buttons(0))
                Case 5
                    If Asignar() Then MsgBox("La asignaci�n se realizo correctamente," + Chr(13) + "n�mero de asignaci�n:" + Chr(13) + Chr(13) + "                            REV " + Format$(CInt(objPRE.Id_Rev_Edit), "0000"))
                    Call Limpia()
                    Inactivos(cboResponsable, txtnumpag, cmdExaminar, .Buttons(5), .Buttons(2))
                    Activos(TVProgTemas, .Buttons(0))
                Case 8
                    iEditar = Nothing
                    Me.Dispose()
            End Select
        End With
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Commandbutton - cmdExaminar, Metodos y Procesos "

    Private Sub cmdExaminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdExaminar.Click
        Dim arch As New OpenFileDialog
        arch.Filter = "Bloc de Notas, Txt  files (*.txt)|*.txt|Word, Doc files (*.doc)|*.doc|Adobe, Pdf files (*.pdf)|*.pdf"
        arch.FilterIndex = 2
        arch.RestoreDirectory = True
        If arch.ShowDialog() = DialogResult.OK Then
            Dim namefile As Array = Split(arch.FileName, "\")
            Dim armname As Array = Split(namefile(namefile.Length - 1), ".")
            Dim tem As Array = Split(LblTreeView.Text, " - ")
            objplanes.Buscar(tem(tem.Length - 2))
            txtdocumento.Text = "TEMRE_" + Mid(tem(tem.Length - 2), Len(tem(tem.Length - 2)) - 3, 4) + Format(CInt(tem(tem.Length - 1)), "0000") + "." + armname(armname.Length - 1)
            sArchivo = arch.FileName
        End If
    End Sub

#End Region

#Region " TextBox - txtnumpag, Metodos y Procesos "

    Private Sub txtnumpag_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtnumpag.TextChanged
        Dim di As DateTime = DTPkFech_Entrega.Value
        Dim i As Integer
        If txtnumpag.Text.Trim <> "" Then i = CInt(txtnumpag.Text.Trim) Else i = 0
        Select Case i
            Case 1 To 15
                di = di.AddDays(7)
            Case 16 To 50
                di = di.AddDays(14)
            Case 51 To 100
                di = di.AddDays(21)
            Case Is >= 101
                di = di.AddDays(28)
            Case Else
                di = Now()
        End Select
        DTPkFech_compromiso.Value = di
    End Sub

    Private Sub txtnumpag_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnumpag.KeyPress
        Call SoloNumeroskeypress(txtnumpag, e)
        Call txtnumpag_TextChanged(txtnumpag, e)
    End Sub

#End Region


End Class
