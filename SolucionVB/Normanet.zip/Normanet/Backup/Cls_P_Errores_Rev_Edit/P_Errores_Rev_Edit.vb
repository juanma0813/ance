Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms


Public Class P_Errores_Rev_Edit

    Private _Id_Rev_Edit As Integer
    Private _Total_Errores As Integer
    Private _Id_Inciso_Rev As Integer

    Private _Bandera As Integer
    Private _Error As String

#Region " Constructor, C�digo generado por Mariano Ascencio "

    ' Conexion 
    Private cn As New SqlConnection
    Private dr As SqlDataReader
    Dim objConexion As New clsConexion.cIsConexion


    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
    End Sub

#End Region

#Region " Propiedades, C�digo generado por Mariano Ascencio "

    Public Property Id_Inciso_Rev() As Integer
        Get
            Return _Id_Inciso_Rev
        End Get
        Set(ByVal Value As Integer)
            _Id_Inciso_Rev = Value
        End Set
    End Property

    Public Property Total_Errores() As Integer
        Get
            Return _Total_Errores
        End Get
        Set(ByVal Value As Integer)
            _Total_Errores = Value
        End Set
    End Property

    Public Property Id_Rev_Edit() As Integer
        Get
            Return _Id_Rev_Edit
        End Get
        Set(ByVal Value As Integer)
            _Id_Rev_Edit = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

#End Region

#Region " Funcion - Listar, C�digo generado por Mariano Ascencio "

    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Errores_Rev_Edit_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Rev_Edit", _Id_Rev_Edit)
        cmd.Parameters.Add("@Id_Inciso", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Errores", _Total_Errores)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_PERE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

#End Region

#Region " Funcion - Buscar, C�digo generado por Mariano Ascencio "

    Public Function buscar()

        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Errores_Rev_Edit_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Rev_Edit", _Id_Rev_Edit)
        cmd.Parameters.Add("@Id_Inciso", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Errores", _Total_Errores)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Inciso_Rev = IIf((IsDBNull(dr("Id_Inciso_Rev"))), 0, dr("Id_Inciso_Rev"))
                _Id_Rev_Edit = IIf((IsDBNull(dr("Id_Rev_Edit"))), 0, dr("Id_Rev_Edit"))
                _Total_Errores = IIf((IsDBNull(dr("Errores"))), 0, dr("Errores"))
            Else
                _Id_Inciso_Rev = 0
                _Id_Rev_Edit = 0
                _Total_Errores = 0
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try

    End Function
#End Region

#Region " Funcion - Insertar, C�digo generado por Mariano Ascencio "

    Public Function Insertar() As Boolean
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Errores_Rev_Edit"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Rev_Edit", _Id_Rev_Edit)
        cmd.Parameters.Add("@Id_Inciso", _Id_Inciso_Rev)
        cmd.Parameters.Add("@Errores", _Total_Errores)
        cmd.Parameters.Add("@Bandera", _Bandera)

        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

End Class
