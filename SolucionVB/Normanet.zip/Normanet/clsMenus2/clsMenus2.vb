'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
'   NOMBRE DE LA CLASE:     CLSMENU
'   DESARROLLADA POR :      EXTI, S.C. PARA ANCE, A.C.
'                           CHRISTIAN C�RDENAS OLIVARES
'   FECHA DE CREACI�N:      12 FEBRERO 2006
'
'   BASES RELACIONADAS:     DBANCE
'
'   TABLAS RELACIONADAS:    C_Grupos_Detalle Y C_Sistema_Menu
'
'   DESCRIPCION:            HABILITA LOS MENUS DE UNA APLICACI�N EN .NET
'                           DE ACUERDO A LA PROPIEDAD TEXTO DEL ITEM DEL MENU. 
'                           EL VALOR DE ESTA PROPIEDAD SE ENCUENTRA EN LAS TABLAS C_Grupos_Detalle Y C_Sistema_Menu
'
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class clsMenus2
    Private cn As New SqlClient.SqlConnection
    Private dsMenus As New DataSet
    Private objConexion As New clsConexion.cIsConexion
    ''Private objUsuarios As New clsUsuarios.clsUsuarios(1, "", "")
    Private sSQL As String
    Private _Grupo As Integer
    Private _Id_Usuario As String
    Private _sistema As Integer
    Private _Bandera As Integer

    Public Property Id_Usuario() As String
        Get
            Return _Id_Usuario

        End Get
        Set(ByVal Value As String)
            _Id_Usuario = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera

        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sistema() As Integer
        Get
            Return _sistema

        End Get
        Set(ByVal Value As Integer)
            _sistema = Value
        End Set
    End Property

    Public Property Id_Grupo() As Integer
        Get
            Return _Grupo

        End Get
        Set(ByVal Value As Integer)
            _Grupo = Value
        End Set
    End Property

    ''OBTIENE LAS OPCIONES A LAS QUE TIENE DERECHO EL USUARIO
    Public Function Menus() As DataSet
        Dim cmd As New SqlCommand
        If cn.State = ConnectionState.Open Then cn.Close()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Grupo_Detalle_Buscar "
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Usuario", _Id_Usuario)
        cmd.Parameters.Add("@Id_Grupo", _Grupo)
        cmd.Parameters.Add("@Id_sistema", _sistema)
        cmd.Parameters.Add("@Bandera", 1)
        cn.Open()

        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dsMenus, "C_Menus")
        cn.Close()
        cmd.Dispose()
        Return dsMenus
    End Function


    Public Function Habilita_menus(ByVal dsmenu As DataSet, ByVal Forma As Form)
        ''PARA DESHABILITAR
        If Not Deshabilita(x.MenuItems) Then
            Exit Function
        End If
        ''''PARA HABILITAR
        sStatus = Habilita(x.MenuItems, dsmenu)
        If sStatus <> "Ok" Then
            MsgBox(sStatus)
            Exit Function
        End If

    End Function
    Private Function Deshabilita(ByVal Menu As MainMenu.MenuItemCollection) As Boolean
        Try
            Dim i As Integer
            For i = 0 To Menu.Count - 1 Step 1
                Menu.Item(i).Enabled = False
                If Menu.Item(i).IsParent Then Deshabilita(Menu.Item(i).MenuItems)
            Next
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Habilita(ByVal Menu As MainMenu.MenuItemCollection, ByVal dsmenu As DataSet) As String
        Try
            Dim i, j As Integer
            For i = 0 To Menu.Count - 1 Step 1
                For j = 0 To dsmenu.Tables("C_Menus").Rows.Count - 1 Step 1
                    If Menu.Item(i).Text = dsmenu.Tables("C_Menus").Rows(j).Item("Id_Menu") Then
                        Menu.Item(i).Enabled = True
                        If Menu.Item(i).IsParent Then Habilita(Menu.Item(i).MenuItems, dsmenu)
                    End If
                Next
            Next
            Return "Ok"
        Catch ex As Exception
            Return "Error " & ex.Message
        End Try
    End Function

    Public Sub New()
        sSQL = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", "COMUN", "usradmsistemas", "usradmsistemas")
        cn.ConnectionString = sSQL
    End Sub
End Class
