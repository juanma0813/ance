
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Noticias Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 27/07/2006 11:21:50 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Noticias


    '''''''Declaracion de Variables Privadas
    Private dsP_Noticias As New DataSet
    Private _Id_Noticia As System.Int32
    Private _Fecha As System.DateTime
    Private _Titulo As System.String
    Private _Fuente As System.String
    Private _Noticia As System.String
    Private _Id_Categoria As System.Int32
    Private _Documento As System.String
    Private _Inactivo As System.Boolean
    Private _Descripcion As System.String
    Public Categoria_Descripcion As String
    Private _Ultimo As Integer

    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo
    Dim iultimo As Integer




    '''''''Declaracion de Propiedades publicas
    Public Property Id_Noticia() As System.Int32
        Get
            Return _Id_Noticia
        End Get
        Set(ByVal Value As System.Int32)
            _Id_Noticia = Value
        End Set
    End Property

    Public Property Fecha() As System.DateTime
        Get
            Return _Fecha
        End Get
        Set(ByVal Value As System.DateTime)
            _Fecha = Value
        End Set
    End Property

    Public Property Titulo() As System.String
        Get
            Return _Titulo
        End Get
        Set(ByVal Value As System.String)
            _Titulo = Value
        End Set
    End Property

    Public Property Fuente() As System.String
        Get
            Return _Fuente
        End Get
        Set(ByVal Value As System.String)
            _Fuente = Value
        End Set
    End Property

    Public Property Noticia() As System.String
        Get
            Return _Noticia
        End Get
        Set(ByVal Value As System.String)
            _Noticia = Value
        End Set
    End Property

    Public Property Id_Categoria() As System.Int32
        Get
            Return _Id_Categoria
        End Get
        Set(ByVal Value As System.Int32)
            _Id_Categoria = Value
        End Set
    End Property

    Public Property Documento() As System.String
        Get
            Return _Documento
        End Get
        Set(ByVal Value As System.String)
            _Documento = Value
        End Set
    End Property

    Public Property Inactivo() As System.Boolean
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As System.Boolean)
            _Inactivo = Value
        End Set
    End Property
    Public Property Ultimo()
        Get
            Return _Ultimo
        End Get
        Set(ByVal Value)
            _Ultimo = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""


    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD


    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal cbo As Object) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Noticias")
        'Dim sSQL As String = "select Id_Noticia From P_Noticias where inactivo = 0 order by id_noticia desc"
        Dim sSQL As String = "select Id_Noticia From P_Noticias order by id_noticia desc"
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            da = New SqlDataAdapter(sSQL, cn)
            da.Fill(dt)
            cn.Close()
            cbo.DisplayMember = dt.Columns(0).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch
            Return Nothing
        End Try
    End Function


    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar()
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****


        sSql = "SELECT * FROM P_Noticias "
        sSql = sSql + " WHERE Id_Noticia = " + Str(_Id_Noticia)
        sSql = sSql + " order by id_noticia desc"

        Dim cmd As New SqlCommand(sSql, cn)
        Dim dr As SqlDataReader
        If cn.State = 1 Then cn.Close()

        cn.Open()
        dr = cmd.ExecuteReader

        If dr.Read Then
            _Id_Noticia = dr("Id_Noticia")
            _Fecha = dr("Fecha")
            _Titulo = dr("Titulo")
            _Fuente = dr("Fuente")
            _Noticia = dr("Noticia")
            _Id_Categoria = dr("Id_Categoria")
            ''' _Documento = dsP_Noticias.Tables("C_Noticias").Rows(0).Item("Documento")
            _Inactivo = dr("Inactivo")
            '_Descripcion = dr("Descripcion")
            _Documento = dr("Documento")
        Else
            _Id_Noticia = ""
            _Fecha = ""
            _Titulo = ""
            _Fuente = ""
            _Noticia = ""
            _Id_Categoria = ""
            '_Documento = ""
            _Inactivo = ""
            _Descripcion = ""
        End If
        cn.Close()
        cmd.Dispose()
    End Sub
    Public Function maxi() As Integer

        Dim cmd As New SqlCommand
        Dim iEncontrado As Integer

        Dim ds As New DataSet
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Noticias_Buscar"
        cmd.Parameters.Add("@bandera", "1")
        Dim da As New SqlClient.SqlDataAdapter(cmd)
        da.Fill(ds, "Ultimo")
        cn.Close()
        cmd.Dispose()

        If IsDBNull((ds.Tables("Ultimo").Rows(0).Item("contador"))) Then
            _Ultimo = 1
        Else
            _Ultimo = (ds.Tables("Ultimo").Rows(0).Item("contador"))
        End If

    End Function

    Public Function Categor�a(ByVal Id_categoria As String)

        sSql = "Select * from c_categorias"
        sSql = sSql + " where id_categoria='" & Id_categoria & "'"
        Dim cmd As New SqlCommand(sSql, cn)
        Dim dr As SqlDataReader

        cn.Open()
        dr = cmd.ExecuteReader

        If dr.Read Then
            _Id_Categoria = dr("Id_categoria")
            Categoria_Descripcion = dr("Descripcion")
        Else
            _Id_Categoria = Nothing
            Categoria_Descripcion = Nothing
        End If
        cn.Close()
        cmd.Dispose()

    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE P_Noticias SET Id_Noticia = @Id_Noticia, Fecha = @Fecha, Titulo = @Titulo, Fuente = @Fuente, Noticia = @Noticia, Id_Categoria = @Id_Categoria, Documento = @Documento, Inactivo = @Inactivo, Where ( = @)"
        cmd.Parameters.Add("@Id_Noticia", SqlDbType.Int, 0, "_Id_Noticia")
        cmd.Parameters.Add("@Fecha", SqlDbType.DateTime, 0, "_Fecha")
        cmd.Parameters.Add("@Titulo", SqlDbType.NVarChar, 50, "_Titulo")
        cmd.Parameters.Add("@Fuente", SqlDbType.NVarChar, 50, "_Fuente")
        cmd.Parameters.Add("@Noticia", SqlDbType.NVarChar, 50, "_Noticia")
        cmd.Parameters.Add("@Id_Categoria", SqlDbType.Int, 0, "_Id_Categoria")
        cmd.Parameters.Add("@Documento", SqlDbType.NVarChar, 50, "_Documento")
        cmd.Parameters.Add("@Inactivo", SqlDbType.Real, 0, "_Inactivo")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function Actualizar(ByVal bandera As String, ByVal id_noticia As Integer, ByVal Fecha As Date, ByVal titulo As String, ByVal Fuente As String, ByVal Noticia As String, ByVal Id_categoria As Integer, ByVal Documento As String, ByVal Inactivo As Boolean) As String

        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Noticias"
        cmd.Parameters.Add("@Id_Noticia", id_noticia)
        cmd.Parameters.Add("@fecha", Format(Fecha, "dd/MM/yyyy"))
        cmd.Parameters.Add("@Titulo", titulo)
        cmd.Parameters.Add("@Fuente", Fuente)
        cmd.Parameters.Add("@Noticia", Noticia)
        cmd.Parameters.Add("@Id_Categoria", Id_categoria)
        cmd.Parameters.Add("@Documento", Documento)
        cmd.Parameters.Add("@Inactivo", Inactivo)
        cmd.Parameters.Add("@Bandera", bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function Borrar(ByVal bandera As String, ByVal id_noticia As Integer)
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Noticias"
        cmd.Parameters.Add("@Bandera", bandera)
        cmd.Parameters.Add("@Id_Noticia", id_noticia)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try



    End Function
End Class
