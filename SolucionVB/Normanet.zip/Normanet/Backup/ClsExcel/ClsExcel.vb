'imports
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Public Class ClsExcel
    'variables
    Private _Bandera As Boolean
    Private _NombreDoc As String
    Private _Ruta as String 

    'propiedades
    Public Property Bandera() As Boolean
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Boolean)
            _Bandera = Value
        End Set
    End Property
    Public Property NombreDoc() As String
        Get
            Return _NombreDoc
        End Get
        Set(ByVal Value As String)
            _NombreDoc = Value
        End Set
    End Property
    Public Property Ruta() As String
        Get
            Return _Ruta
        End Get
        Set(ByVal Value As String)
            _Ruta = Value
        End Set
    End Property
#Region " ExpotaExcel - DataTableToExcel(pDataTable), Metodos y Procesos"

    Public Sub DataTableToExcel(ByVal pDataTable As DataTable)
        'ruta en la que se guarda
        Dim vFileName As String = Path.GetTempFileName()
        FileOpen(1, vFileName, OpenMode.Output)

        Dim sb As String
        Dim dc As DataColumn
        For Each dc In pDataTable.Columns
            sb &= dc.Caption & Microsoft.VisualBasic.ControlChars.Tab
        Next
        PrintLine(1, sb)

        Dim i As Integer = 0
        Dim dr As DataRow
        For Each dr In pDataTable.Rows
            i = 0 : sb = ""
            For Each dc In pDataTable.Columns
                If Not IsDBNull(dr(i)) Then
                    sb &= CStr(dr(i)) & Microsoft.VisualBasic.ControlChars.Tab
                Else
                    sb &= Microsoft.VisualBasic.ControlChars.Tab
                End If
                i += 1
            Next

            PrintLine(1, sb)
        Next

        FileClose(1)
        TextToExcel(vFileName)

    End Sub

#End Region

#Region " ExpotaExcel - TextToExcel(pFileName), Metodos y Procesos"

    Public Sub TextToExcel(ByVal pFileName As String)
        Dim vFormato As Excel.XlRangeAutoFormat
        Dim vCultura As System.Globalization.CultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture

        'Es importante definirle la cultura al sistema
        'ya que podria generar errores
        System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US")
        Dim Exc As Excel.Application = New Excel.Application
        Exc.Workbooks.OpenText(pFileName, , , , Excel.XlTextQualifier.xlTextQualifierNone, , True)
        Dim Wb As Excel.Workbook = Exc.ActiveWorkbook
        Dim Ws As Excel.Worksheet = Wb.ActiveSheet
        Dim valor As Integer = 1

        'con esta linea se le da formato a la tabla de excel
        vFormato = Excel.XlRangeAutoFormat.xlRangeAutoFormatSimple

        Ws.Range(Ws.Cells(1, 1), Ws.Cells(Ws.UsedRange.Rows.Count, Ws.UsedRange.Columns.Count)).AutoFormat(vFormato)
        'genera un nombre aleatorio
            pFileName = Path.GetTempFileName.Replace("tmp", "xls")
        File.Delete(pFileName)
        Exc.ActiveWorkbook.SaveAs(pFileName, Excel.XlTextQualifier.xlTextQualifierNone - 1)

        Exc.Quit()

        Ws = Nothing
        Wb = Nothing
        Exc = Nothing

        GC.Collect()
        If valor > -1 Then

            Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
            p.EnableRaisingEvents = False
            p.Start("Excel.exe", pFileName)
            p.Dispose()

        End If
        System.Threading.Thread.CurrentThread.CurrentCulture = vCultura
    End Sub

#End Region

End Class
