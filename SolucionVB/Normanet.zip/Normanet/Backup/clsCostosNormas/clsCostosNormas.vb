Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Namespace Maple

    Public Class clsCostosNormas


#Region "Propiedades de la clase"
        REM Variables de Propiedad
        Private _CostoCorporativa As String
        Private _CostoImpresa As String
        Private _CostoPersonal As String
        Private _Id As Integer
        Private _Norma As String
        Private _Bandera As String
        Private _respRetorno(1) As String
        Private cn As SqlConnection


        REM Propiedades de la Entidad
        Public Property CostoCorporativa() As String
            Get
                Return _CostoCorporativa
            End Get
            Set(ByVal Value As String)
                _CostoCorporativa = Value
            End Set
        End Property

        Public Property CostoImpresa() As String
            Get
                Return _CostoImpresa
            End Get
            Set(ByVal Value As String)
                _CostoImpresa = Value
            End Set
        End Property

        Public Property CostoPersonal() As String
            Get
                Return _CostoPersonal
            End Get
            Set(ByVal Value As String)
                _CostoPersonal = Value
            End Set
        End Property

        Public Property Id() As Integer
            Get
                Return _Id
            End Get
            Set(ByVal Value As Integer)
                _Id = Value
            End Set
        End Property

        Public Property Norma() As String
            Get
                Return _Norma
            End Get
            Set(ByVal Value As String)
                _Norma = Value
            End Set
        End Property

        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Bandera() As String
            Get
                Return _Bandera
            End Get
            Set(ByVal Value As String)
                _Bandera = Value
            End Set
        End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 1 contiene el error en caso de fallar :: la posicion 0 Contiene un (1 o 0), 1 indica que el metodo fallo, y 0 indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property


#End Region
#Region "Metodos de la Clase"
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            Dim con As String = ConfigurationSettings.AppSettings.Get("Ance")
            cn = New SqlConnection(con)
        End Sub
        REM Funcion que Elimina datos
        ''' <summary>
        '''Metodo para eliminar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Eliminar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspCostosNormas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@CostoCorporativa", _CostoCorporativa)
                cmd.Parameters.Add("@CostoImpresa", _CostoImpresa)
                cmd.Parameters.Add("@CostoPersonal", _CostoPersonal)
                cmd.Parameters.Add("@Id", _Id)
                cmd.Parameters.Add("@Norma", _Norma)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Actualizar datos
        ''' <summary>
        '''Metodo para Actualizar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Actualizar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspCostosNormas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@CostoCorporativa", _CostoCorporativa)
                cmd.Parameters.Add("@CostoImpresa", _CostoImpresa)
                cmd.Parameters.Add("@CostoPersonal", _CostoPersonal)
                cmd.Parameters.Add("@Id", _Id)
                cmd.Parameters.Add("@Norma", _Norma)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Insertar datos
        ''' <summary>
        ''' Metodo para insertar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Insertar()
            Dim Consecutivo As Integer = 0

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspCostosNormas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@CostoCorporativa", _CostoCorporativa)
                cmd.Parameters.Add("@CostoImpresa", _CostoImpresa)
                cmd.Parameters.Add("@CostoPersonal", _CostoPersonal)
                cmd.Parameters.Add("@Id", _Id)
                cmd.Parameters.Add("@Norma", _Norma)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que LlenarDatos datos
        ''' <summary>
        '''llena todas las propiedades en base a una consulta de sql o Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub LlenarDatos()
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspCostosNormas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@CostoCorporativa", _CostoCorporativa)
                cmd.Parameters.Add("@CostoImpresa", _CostoImpresa)
                cmd.Parameters.Add("@CostoPersonal", _CostoPersonal)
                cmd.Parameters.Add("@Id", _Id)
                cmd.Parameters.Add("@Norma", _Norma)
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                cmd.Dispose()
                da.Dispose()

                If dt.Rows.Count > 0 Then
                    _CostoCorporativa = IIf(IsDBNull(dt.Rows(0).Item("CostoCorporativa")) = True, Nothing, dt.Rows(0).Item("CostoCorporativa"))
                    _CostoImpresa = IIf(IsDBNull(dt.Rows(0).Item("CostoImpresa")) = True, Nothing, dt.Rows(0).Item("CostoImpresa"))
                    _CostoPersonal = IIf(IsDBNull(dt.Rows(0).Item("CostoPersonal")) = True, Nothing, dt.Rows(0).Item("CostoPersonal"))
                    _Id = IIf(IsDBNull(dt.Rows(0).Item("Id")) = True, Nothing, dt.Rows(0).Item("Id"))
                    _Norma = IIf(IsDBNull(dt.Rows(0).Item("Norma")) = True, Nothing, dt.Rows(0).Item("Norma"))
                Else
                    _CostoCorporativa = Nothing
                    _CostoImpresa = Nothing
                    _CostoPersonal = Nothing
                    _Id = Nothing
                    _Norma = Nothing
                End If
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspCostosNormas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@CostoCorporativa", _CostoCorporativa)
                cmd.Parameters.Add("@CostoImpresa", _CostoImpresa)
                cmd.Parameters.Add("@CostoPersonal", _CostoPersonal)
                cmd.Parameters.Add("@Id", _Id)
                cmd.Parameters.Add("@Norma", _Norma)
                cmd.Parameters.Add("@Bandera", _Bandera)
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                da.Dispose()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function


#End Region


    End Class

End Namespace
