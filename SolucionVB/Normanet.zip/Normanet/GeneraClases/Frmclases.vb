Imports System.IO
Imports System.Data.SqlClient

Public Class FrmClases
    Inherits System.Windows.Forms.Form
    Private xCon As New Conexion

    '********************************************************************************

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents BtnGenera As System.Windows.Forms.Button
    Friend WithEvents LstTablas As System.Windows.Forms.ListBox
    Friend WithEvents LstFields As System.Windows.Forms.ListBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents LblTabla As System.Windows.Forms.Label
    Friend WithEvents BarAvance As System.Windows.Forms.ProgressBar
    Friend WithEvents Lblconexion As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.BtnGenera = New System.Windows.Forms.Button
        Me.LstTablas = New System.Windows.Forms.ListBox
        Me.LstFields = New System.Windows.Forms.ListBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.LblTabla = New System.Windows.Forms.Label
        Me.BarAvance = New System.Windows.Forms.ProgressBar
        Me.Lblconexion = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BtnGenera
        '
        Me.BtnGenera.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnGenera.Location = New System.Drawing.Point(356, 396)
        Me.BtnGenera.Name = "BtnGenera"
        Me.BtnGenera.Size = New System.Drawing.Size(104, 48)
        Me.BtnGenera.TabIndex = 0
        Me.BtnGenera.Text = "Generar Clase"
        '
        'LstTablas
        '
        Me.LstTablas.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LstTablas.ItemHeight = 15
        Me.LstTablas.Location = New System.Drawing.Point(32, 36)
        Me.LstTablas.Name = "LstTablas"
        Me.LstTablas.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.LstTablas.Size = New System.Drawing.Size(168, 424)
        Me.LstTablas.TabIndex = 2
        '
        'LstFields
        '
        Me.LstFields.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LstFields.ItemHeight = 15
        Me.LstFields.Location = New System.Drawing.Point(608, 36)
        Me.LstFields.Name = "LstFields"
        Me.LstFields.Size = New System.Drawing.Size(168, 424)
        Me.LstFields.TabIndex = 3
        '
        'LblTabla
        '
        Me.LblTabla.BackColor = System.Drawing.Color.Transparent
        Me.LblTabla.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTabla.ForeColor = System.Drawing.Color.Black
        Me.LblTabla.Location = New System.Drawing.Point(208, 80)
        Me.LblTabla.Name = "LblTabla"
        Me.LblTabla.Size = New System.Drawing.Size(376, 40)
        Me.LblTabla.TabIndex = 4
        Me.LblTabla.Text = "Procesando"
        '
        'BarAvance
        '
        Me.BarAvance.Location = New System.Drawing.Point(224, 168)
        Me.BarAvance.Name = "BarAvance"
        Me.BarAvance.Size = New System.Drawing.Size(344, 16)
        Me.BarAvance.TabIndex = 5
        '
        'Lblconexion
        '
        Me.Lblconexion.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblconexion.Location = New System.Drawing.Point(32, 8)
        Me.Lblconexion.Name = "Lblconexion"
        Me.Lblconexion.Size = New System.Drawing.Size(752, 24)
        Me.Lblconexion.TabIndex = 6
        '
        'FrmClases
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(800, 466)
        Me.Controls.Add(Me.Lblconexion)
        Me.Controls.Add(Me.BarAvance)
        Me.Controls.Add(Me.LblTabla)
        Me.Controls.Add(Me.LstFields)
        Me.Controls.Add(Me.LstTablas)
        Me.Controls.Add(Me.BtnGenera)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmClases"
        Me.Text = "Clases"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Clases_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim I As Integer
        Dim FormConexion As New FrmConexion

        FormConexion.ShowDialog()

        If Not xCon._Valor Then
            MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
            End
        End If
        Me.Lblconexion.Text = Mid(sConexion, 1, InStr(sConexion, "Pas") - 1)

        If ObtenTablas() = True Then
            MessageBox.Show("", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
        End If
        For I = 1 To DimensionTabla
            Me.LstTablas.Items.Add(Tabla(I).ToString())
        Next

    End Sub

    Private Sub BtnGenera_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGenera.Click
        Dim I As Integer
        Dim j As Integer
        Dim str As String
        Dim myStream As Stream
        Dim openFileDialog1 As New OpenFileDialog

        BarAvance.Visible = True
        BarAvance.Minimum = 1
        BarAvance.Maximum = DimensionTabla
        BarAvance.Value = 1
        BarAvance.Step = 1

        LstFields.Items.Clear()

        For I = 0 To LstTablas.Items.Count - 1
            If LstTablas.GetSelected(I) Then
                ObtenCampos(Tabla(I + 1).ToString())
                Me.Refresh()
                Me.LblTabla.Text = "Procesando: " & Tabla(I + 1).ToString()
                Me.LblTabla.Refresh()
                For j = 0 To DimensionCampos - 1
                    Me.LstFields.Items.Add(Campos(0, j).ToString())
                Next
                Me.LstFields.Items.Add("------------")
                ArcClase = Tabla(I + 1).ToString()
                RutaPath = "C:\ance\"
                EscribeClase()
            End If
            BarAvance.PerformStep()
        Next
        MessageBox.Show("Ya Termino")
    End Sub

    '********************************************************************************
    Public Property DimensionCampos() As System.Int32
        Get
            Return _DimensionCampos
        End Get
        Set(ByVal value As System.Int32)
            _DimensionCampos = value
        End Set
    End Property

    '********************************************************************************
    Public Function ObtenTablas() As Boolean
        Dim i As Integer
        Dim sCon As New Conexion
        Dim xCon As New SqlClient.SqlConnection(sConexion)
        Dim sqlcmd As New SqlClient.SqlCommand("Select * FROM Information_Schema.tables Where Table_type ='BASE TABLE' order by 2", xCon)
        Dim myReader As SqlDataReader
        xCon.Open()
        myReader = sqlcmd.ExecuteReader(CommandBehavior.CloseConnection)
        sqlcmd.Dispose()
        While myReader.Read
            i = i + 1

            Tabla(i) = myReader.GetString(2)
        End While
        DimensionTabla = i
        ReDim Preserve Tabla(i + 1)
        xCon.Close()
    End Function

    '********************************************************************************
    Public Function ObtenCampos(ByVal Tabla As String) As Boolean
        ReDim Campos(25, 50)
        Dim I As Integer
        Dim j As Integer
        Dim sCon As New Conexion
        Dim xCon As New SqlClient.SqlConnection(sConexion)
        Dim sqlcmd As New SqlClient.SqlCommand("select * from [" & Tabla & "]", xCon)
        Dim myReader As SqlDataReader
        Dim Mensaje As String
        Dim Datatable As DataTable
        xCon.Open()
        Try
            myReader = sqlcmd.ExecuteReader(CommandBehavior.KeyInfo)
        Catch ex As SqlException
            MessageBox.Show(ex.Message)
        End Try
        Try
            Datatable = myReader.GetSchemaTable()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Dim dataRow As DataRow
        Dim dataColumn As DataColumn
        Dim obj As System.Object
        j = 0
        For Each dataRow In Datatable.Rows
            For Each dataColumn In Datatable.Columns
                'Campos(j, I) = dataColumn.ColumnName
                Campos(j, I) = dataRow(dataColumn).ToString()
                j = j + 1
            Next
            j = 0
            I = I + 1
        Next
        _DimensionCampos = I
    End Function


End Class
