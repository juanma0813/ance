Option Strict On
Option Explicit On 

Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class Conexion
    Private _Proveedor As System.String
    Private _Servidor As System.String
    Private _BaseDatos As System.String
    Private _Usuario As System.String
    Private _Password As System.String
    Private _CadenaConexion As System.String
    Public _Valor As Boolean = True
    '********************************************************************************
    Public Property Proveedor() As String
        Get
            Return _Proveedor
        End Get
        Set(ByVal value As System.String)
            _Proveedor = value
        End Set
    End Property
    '********************************************************************************
    Public Property Servidor() As String
        Get
            Return _Servidor
        End Get
        Set(ByVal value As System.String)
            _Servidor = value
        End Set
    End Property
    '********************************************************************************
    Public Property BaseDatos() As String
        Get
            Return _BaseDatos
        End Get
        Set(ByVal value As System.String)
            _BaseDatos = value
        End Set
    End Property
    '********************************************************************************
    Public Property Usuario() As String
        Get
            Return _Usuario
        End Get
        Set(ByVal value As System.String)
            _Usuario = value
        End Set
    End Property
    '********************************************************************************
    Public Property Password() As String
        Get
            Return _Password
        End Get
        Set(ByVal value As System.String)
            _Password = value
        End Set
    End Property
    '********************************************************************************
    Public Property Cadenaconexion() As String
        Get
            Return _CadenaConexion
        End Get
        Set(ByVal value As System.String)
            _CadenaConexion = value
        End Set
    End Property
    '********************************************************************************
    Public Function GeneraCadena() As Boolean
        _CadenaConexion = "Data Source=" & _Servidor & "; Initial Catalog=" & _BaseDatos & "; User ID=" & _Usuario & "; Password=" & _Password
    End Function
    '********************************************************************************
    Public Function Conecta(ByVal cad As String) As Boolean
        Dim xCon As New SqlClient.SqlConnection(cad)
        Try
            xCon.Open()
        Catch exc1 As Exception
            MessageBox.Show("Algo anda mal no pudo realizar la conexion " & exc1.Message)
            _Valor = False
            Exit Try
        End Try
        If _Valor Then
            _Valor = True
            xCon.Close()
            sConexion = cad
        End If
    End Function
End Class
