Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Namespace Maple

    Public Class clsPaginas

#Region "Propiedades de la clase"
        REM Variables de Propiedad
        Private _Activo As Boolean
        Private _Id_Pagina As Integer
        Private _Id_TipoPagina As Integer
        Private _LigaPreestablecida As String
        Private _Nombre As String
        Private _Terminada As Boolean
        Private _Titulo As String
        Private _esIndex As Boolean
        Private _Bandera As String
        Private _respRetorno(1) As String
        Private cn As SqlConnection


        REM Propiedades de la Entidad
        Public Property Activo() As Boolean
            Get
                Return _Activo
            End Get
            Set(ByVal Value As Boolean)
                _Activo = Value
            End Set
        End Property

        Public Property Id_Pagina() As Integer
            Get
                Return _Id_Pagina
            End Get
            Set(ByVal Value As Integer)
                _Id_Pagina = Value
            End Set
        End Property

        Public Property Id_TipoPagina() As Integer
            Get
                Return _Id_TipoPagina
            End Get
            Set(ByVal Value As Integer)
                _Id_TipoPagina = Value
            End Set
        End Property

        Public Property LigaPreestablecida() As String
            Get
                Return _LigaPreestablecida
            End Get
            Set(ByVal Value As String)
                _LigaPreestablecida = Value
            End Set
        End Property

        Public Property Nombre() As String
            Get
                Return _Nombre
            End Get
            Set(ByVal Value As String)
                _Nombre = Value
            End Set
        End Property

        Public Property Terminada() As Boolean
            Get
                Return _Terminada
            End Get
            Set(ByVal Value As Boolean)
                _Terminada = Value
            End Set
        End Property

        Public Property Titulo() As String
            Get
                Return _Titulo
            End Get
            Set(ByVal Value As String)
                _Titulo = Value
            End Set
        End Property

        Public Property esIndex() As Boolean
            Get
                Return _esIndex
            End Get
            Set(ByVal Value As Boolean)
                _esIndex = Value
            End Set
        End Property

        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Bandera() As String
            Get
                Return _Bandera
            End Get
            Set(ByVal Value As String)
                _Bandera = Value
            End Set
        End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 1 contiene el error en caso de fallar :: la posicion 0 Contiene un (1 o 0), 1 indica que el metodo fallo, y 0 indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property


#End Region
#Region "Metodos de la Clase"
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            Dim con As String = ConfigurationSettings.AppSettings.Get("Ance")
            cn = New SqlConnection(con)
        End Sub
        REM Funcion que Elimina datos
        ''' <summary>
        '''Metodo para eliminar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Eliminar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspPaginas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Activo", _Activo)
                cmd.Parameters.Add("@Id_Pagina", _Id_Pagina)
                cmd.Parameters.Add("@Id_TipoPagina", _Id_TipoPagina)
                cmd.Parameters.Add("@LigaPreestablecida", _LigaPreestablecida)
                cmd.Parameters.Add("@Nombre", _Nombre)
                cmd.Parameters.Add("@Terminada", _Terminada)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@esIndex", _esIndex)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Actualizar datos
        ''' <summary>
        '''Metodo para Actualizar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Actualizar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()

                Dim cmd As New SqlCommand
                cmd.CommandText = "uspPaginas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Activo", _Activo)
                cmd.Parameters.Add("@Id_Pagina", _Id_Pagina)
                cmd.Parameters.Add("@Id_TipoPagina", _Id_TipoPagina)
                cmd.Parameters.Add("@LigaPreestablecida", _LigaPreestablecida)
                cmd.Parameters.Add("@Nombre", _Nombre)
                cmd.Parameters.Add("@Terminada", _Terminada)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@esIndex", _esIndex)
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Insertar datos
        ''' <summary>
        ''' Metodo para insertar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Insertar()
            Dim Consecutivo As Integer = 0
            Dim dr As SqlDataReader

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspPaginas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Activo", _Activo)
                cmd.Parameters.Add("@Id_Pagina", _Id_Pagina)
                cmd.Parameters.Add("@Id_TipoPagina", _Id_TipoPagina)
                cmd.Parameters.Add("@LigaPreestablecida", _LigaPreestablecida)
                cmd.Parameters.Add("@Nombre", _Nombre)
                cmd.Parameters.Add("@Terminada", _Terminada)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@esIndex", _esIndex)
                cmd.Parameters.Add("@Bandera", _Bandera)

                dr = cmd.ExecuteReader

                If dr.Read Then
                    Id_Pagina = dr("Id_Pagina")
                End If

                cmd.Dispose()
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
                dr.Close()
                dr = Nothing
            End Try
        End Sub


        REM Funcion que LlenarDatos datos
        ''' <summary>
        '''llena todas las propiedades en base a una consulta de sql o Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub LlenarDatos()
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspPaginas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Activo", _Activo)
                cmd.Parameters.Add("@Id_Pagina", _Id_Pagina)
                cmd.Parameters.Add("@Id_TipoPagina", _Id_TipoPagina)
                cmd.Parameters.Add("@LigaPreestablecida", _LigaPreestablecida)
                cmd.Parameters.Add("@Nombre", _Nombre)
                cmd.Parameters.Add("@Terminada", _Terminada)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@esIndex", _esIndex)
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)

                da.Dispose()
                cmd.Dispose()

                If dt.Rows.Count > 0 Then
                    _Activo = IIf(IsDBNull(dt.Rows(0).Item("Activo")) = True, Nothing, dt.Rows(0).Item("Activo"))
                    _Id_Pagina = IIf(IsDBNull(dt.Rows(0).Item("Id_Pagina")) = True, Nothing, dt.Rows(0).Item("Id_Pagina"))
                    _Id_TipoPagina = IIf(IsDBNull(dt.Rows(0).Item("Id_TipoPagina")) = True, Nothing, dt.Rows(0).Item("Id_TipoPagina"))
                    _LigaPreestablecida = IIf(IsDBNull(dt.Rows(0).Item("LigaPreestablecida")) = True, Nothing, dt.Rows(0).Item("LigaPreestablecida"))
                    _Nombre = IIf(IsDBNull(dt.Rows(0).Item("Nombre")) = True, Nothing, dt.Rows(0).Item("Nombre"))
                    _Terminada = IIf(IsDBNull(dt.Rows(0).Item("Terminada")) = True, Nothing, dt.Rows(0).Item("Terminada"))
                    _Titulo = IIf(IsDBNull(dt.Rows(0).Item("Titulo")) = True, Nothing, dt.Rows(0).Item("Titulo"))
                    _esIndex = IIf(IsDBNull(dt.Rows(0).Item("esIndex")) = True, Nothing, dt.Rows(0).Item("esIndex"))
                Else
                    _Activo = Nothing
                    _Id_Pagina = Nothing
                    _Id_TipoPagina = Nothing
                    _LigaPreestablecida = Nothing
                    _Nombre = Nothing
                    _Terminada = Nothing
                    _Titulo = Nothing
                    _esIndex = Nothing
                End If
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspPaginas"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Activo", _Activo)
                cmd.Parameters.Add("@Id_Pagina", _Id_Pagina)
                cmd.Parameters.Add("@Id_TipoPagina", _Id_TipoPagina)
                cmd.Parameters.Add("@LigaPreestablecida", _LigaPreestablecida)
                cmd.Parameters.Add("@Nombre", _Nombre)
                cmd.Parameters.Add("@Terminada", _Terminada)
                cmd.Parameters.Add("@Titulo", _Titulo)
                cmd.Parameters.Add("@esIndex", _esIndex)
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)

                da.Dispose()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function


#End Region



    End Class

End Namespace
