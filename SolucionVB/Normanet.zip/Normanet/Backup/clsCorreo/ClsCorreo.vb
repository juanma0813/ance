Option Explicit On 

Imports System
Imports System.Windows.Forms

Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Public Class ClsCorreo
    Private _Bandera As String
    Private _sXML As String
    Private _Subject As String
    Private _sTo As String
    Private _scc As String

    Public Property Bandera() As String
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As String)
            _Bandera = Value
        End Set
    End Property

    Public Property XML() As String
        Get
            Return _sXML
        End Get
        Set(ByVal Value As String)
            _sXML = Value
        End Set
    End Property

    Public Property Subject() As String
        Get
            Return _Subject
        End Get
        Set(ByVal Value As String)
            _Subject = Value
        End Set
    End Property

    Public Property sTo() As String
        Get
            Return _sTo
        End Get
        Set(ByVal Value As String)
            _sTo = Value
        End Set
    End Property

    Public Property scc() As String
        Get
            Return _scc
        End Get
        Set(ByVal Value As String)
            _scc = Value
        End Set
    End Property

    Private cn As New SqlClient.SqlConnection
    Public Sub New()
        cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance").ToString)
    End Sub

    Public Sub EnviarCorreo(ByVal sFrom As String, ByVal sTo As String, ByVal scc As String, ByVal sSubject As String, ByVal sBody As String)
        Dim omail = New System.Web.Mail.MailMessage
        Dim objini As New clsIniarray.ClsIniArray
        omail.from = sFrom
        omail.to = sTo
        omail.Cc = scc
        omail.subject = sSubject
        omail.BODY = sBody
        omail.bodyformat = System.Web.Mail.MailFormat.Html
        System.Web.Mail.SmtpMail.SmtpServer = objini.IniGet(Application.StartupPath + "\Principal.ini", "correo", "ip")
        System.Web.Mail.SmtpMail.Send(omail)

    End Sub

    Public Function CorreoPersonalizado() As Boolean
        Dim bError As Boolean = False
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "upsCorreosPersonalizados"

        cmd.Parameters.Add("@asunto", _Subject)
        cmd.Parameters.Add("@Para", _sTo)
        cmd.Parameters.Add("@CC", _scc)
        cmd.Parameters.Add("@Perfil", ConfigurationSettings.AppSettings("Perfil").ToString)
        cmd.Parameters.Add("@xml", _sXML)
        cmd.Parameters.Add("@Bandera", _Bandera)

        If cn.State = 1 Then cn.Close()
        cn.Open()

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            bError = True
        End Try

        Return bError
    End Function
End Class
