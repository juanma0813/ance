Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms


Public Class Cls_sesiones


    '''''     Declaraci�n de variables 
    '''''     Tabla de P_sesiones

    Private _Id_Sesion As Integer
    Private _Id_Comite As String
    Private _Id_CT As String
    Private _Id_SC As String
    Private _Id_Grupo As String
    Private _Fecha As String
    Private _HoraI As String
    Private _HoraT As String
    Private _Asunto As String
    Private _Lugar As String
    Private _Responsable As String
    Private _Notas As String
    Private _Status As Integer
    Private _No_Sol_Sala As String

    '''''     Tabla de P_Sesion_doctos
    Private _Id_Docto As Integer
    Private _Id_Tipo As Integer
    Private _Inactivo As Integer
    Private _Docto As String

    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String

    '''''     Tabla de S_tipos_doctos
    Private _Descripcion_Docto As String

    '''''     Tabla de P_Sesion_tema

    Private _Id_Plan As String
    Private _Id_tema As Integer


    '''''     Tabla de S_Status_Sesion

    Private _id_status_sesion As Integer
    Private _Descripcion As String

    '''''     Variables Generales

    Private _Bandera As Integer
    Private scadena As String
    Private _Error As String
    ' Conexion 

    Private cn As New SqlConnection
    Private dr As SqlDataReader
    Dim objConexion As New clsConexion.cIsConexion

    '''''''Declaracion de Propiedades publicas
    Public Property Docto() As String
        Get
            Return _Docto
        End Get
        Set(ByVal Value As String)
            _Docto = Value
        End Set
    End Property

    Public Property Id_Sesion() As Integer
        Get
            Return _Id_Sesion
        End Get
        Set(ByVal Value As Integer)
            _Id_Sesion = Value
        End Set
    End Property

    Public Property Id_Comite() As String
        Get
            Return _Id_Comite
        End Get
        Set(ByVal Value As String)
            _Id_Comite = Value
        End Set
    End Property

    Public Property Id_CT() As String
        Get
            Return _Id_CT
        End Get
        Set(ByVal Value As String)
            _Id_CT = Value
        End Set
    End Property

    Public Property Id_SC() As String
        Get
            Return _Id_SC
        End Get
        Set(ByVal Value As String)
            _Id_SC = Value
        End Set
    End Property

    Public Property Id_Grupo() As String
        Get
            Return _Id_Grupo
        End Get
        Set(ByVal Value As String)
            _Id_Grupo = Value
        End Set
    End Property

    Public Property Fecha() As String
        Get
            Return _Fecha
        End Get
        Set(ByVal Value As String)
            _Fecha = Value
        End Set
    End Property

    Public Property HoraI() As String
        Get
            Return _HoraI
        End Get
        Set(ByVal Value As String)
            _HoraI = Value
        End Set
    End Property

    Public Property HoraT() As String
        Get
            Return _HoraT
        End Get
        Set(ByVal Value As String)
            _HoraT = Value
        End Set
    End Property

    Public Property Asunto() As String
        Get
            Return _Asunto
        End Get
        Set(ByVal Value As String)
            _Asunto = Value
        End Set
    End Property

    Public Property Lugar() As String
        Get
            Return _Lugar
        End Get
        Set(ByVal Value As String)
            _Lugar = Value
        End Set
    End Property

    Public Property Responsable() As String
        Get
            Return _Responsable
        End Get
        Set(ByVal Value As String)
            _Responsable = Value
        End Set
    End Property

    Public Property Notas() As String
        Get
            Return _Notas
        End Get
        Set(ByVal Value As String)
            _Notas = Value
        End Set
    End Property

    Public Property Status() As Integer
        Get
            Return _Status
        End Get
        Set(ByVal Value As Integer)
            _Status = Value
        End Set
    End Property

    Public Property No_Sol_Sala() As String
        Get
            Return _No_Sol_Sala
        End Get
        Set(ByVal Value As String)
            _No_Sol_Sala = Value
        End Set
    End Property

    Public Property Descripcion_Docto() As String
        Get
            Return _Descripcion_Docto
        End Get
        Set(ByVal Value As String)
            _Descripcion_Docto = Value
        End Set
    End Property

    Public Property Inactivo() As Integer
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Integer)
            _Inactivo = Value
        End Set
    End Property

    Public Property Id_Tipo() As Integer
        Get
            Return _Id_Tipo
        End Get
        Set(ByVal Value As Integer)
            _Id_Tipo = Value
        End Set
    End Property

    Public Property Id_Docto() As Integer
        Get
            Return _Id_Docto
        End Get
        Set(ByVal Value As Integer)
            _Id_Docto = Value
        End Set
    End Property

    Public Property Id_tema() As Integer
        Get
            Return _Id_tema
        End Get
        Set(ByVal Value As Integer)
            _Id_tema = Value
        End Set
    End Property

    Public Property Id_Plan() As String
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value As String)
            _Id_Plan = Value
        End Set
    End Property

    Public Property id_status_sesion() As Integer
        Get
            Return _id_status_sesion
        End Get
        Set(ByVal Value As Integer)
            _id_status_sesion = Value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As String)
            _Descripcion = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property

    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property

    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", "Principal", Usuario, Password)
        '"Data source = " + objConexion.Server + "; Initial Catalog = " + objConexion.Base + "; User Id = " + Usuario + "; Pwd =  " + Password
    End Sub

    Private Sub llena_parametros(ByVal command As SqlCommand)
        With command
            'llave de c_empleado completo
            If _Bandera = 1 Then
                .Parameters.Add("@Id_Sesion2", SqlDbType.Int)
                .Parameters("@Id_Sesion2").Direction = ParameterDirection.InputOutput
            End If
            .Parameters.Add("@Id_Sesion", _Id_Sesion)

            .Parameters.Add("@Id_Comite", _Id_Comite)
            .Parameters.Add("@Id_CT", _Id_CT)
            .Parameters.Add("@Id_SC", _Id_SC)
            .Parameters.Add("@Id_Grupo", _Id_Grupo)
            .Parameters.Add("@Fecha", _Fecha)
            .Parameters.Add("@HoraI", _HoraI)
            .Parameters.Add("@HoraT", _HoraT)
            .Parameters.Add("@Asunto", _Asunto)
            .Parameters.Add("@Lugar", _Lugar)
            .Parameters.Add("@Responsable", _Responsable)
            .Parameters.Add("@Notas", _Notas)
            .Parameters.Add("@Status", _Status)
            .Parameters.Add("@No_Sol_Sala", _No_Sol_Sala)
            .Parameters.Add("@Id_Docto", _Id_Docto)
            .Parameters.Add("@Id_Tipo", _Id_Tipo)
            .Parameters.Add("@Inactivo", _Inactivo)
            .Parameters.Add("@Docto", _Docto)
            .Parameters.Add("@Descripcion_Docto", _Descripcion_Docto)
            .Parameters.Add("@Id_Plan", _Id_Plan)
            .Parameters.Add("@Id_Tema", _Id_tema)
            .Parameters.Add("@Id_Status_sesion", _id_status_sesion)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        End With
    End Sub

    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Sesiones"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cmd.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            _Error = "ERROR - Bandera " + _Bandera + " " + ex.Message
            Return False
        End Try
    End Function

    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Sesiones"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cmd.ExecuteNonQuery()
            If _Bandera = 1 Then
                _Id_Sesion = IIf(IsDBNull(cmd.Parameters("@Id_Sesion2").Value), -1, cmd.Parameters("@Id_Sesion2").Value)
            End If
            Return True
        Catch ex As Exception When _Id_Sesion = -1 And Bandera = 1
            _Error = ""
            If _Id_Sesion = -1 Then _Error = Chr(13) + "El valor devuelto por el Procedimiento de Sql es un DBNULL"
            _Error = "ERROR - Bandera " + _Bandera + " " + _Error + ex.Message
            Return False
        End Try
    End Function

    Public Sub ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Sesiones_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsSesiones")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return
        End Try
    End Sub

    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Sesiones_Buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsSesiones")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return Nothing
        End Try
    End Function
    Public Function Trae_Fecha()
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmd
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_P_Sesiones_Buscar"
            .Parameters.Add("@Bandera", 8)
            .Parameters.Add("@Id_tema", _Id_tema)
            .Parameters.Add("@ID_plan", _Id_Plan)
            cmd.Connection = cn
            cn.Open()
            Dim dr As SqlDataReader
            Try
                dr = cmd.ExecuteReader
                If dr.Read Then
                    _Fecha = IIf(IsDBNull(dr("Fecha")) = True, Nothing, Format(dr("fecha"), "dd/MM/yyyy"))
                End If


            Catch ex As Exception
                Return "ERROR: " & ex.Message
            End Try
        End With

    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar()
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        ' sSql = "SELECT * FROM C_Representacion WHERE Campo_Llave = sClave"
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_Sesiones_Buscar "
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Sesion = IIf((IsDBNull(dr("Id_Sesion"))), 0, dr("Id_Sesion"))
                _Id_Comite = IIf((IsDBNull(dr("Id_Comite"))), "", dr("Id_Comite"))
                _Id_CT = IIf((IsDBNull(dr("Id_CT"))), "", dr("Id_CT"))
                _Id_SC = IIf((IsDBNull(dr("Id_sc"))), "", dr("Id_SC"))
                _Id_Grupo = IIf((IsDBNull(dr("Id_Grupo"))), "", dr("Id_Grupo"))
                _Fecha = IIf((IsDBNull(dr("Fecha"))), Format$(Now(), "dd/MM/yyyy"), Format$(dr("Fecha"), "dd/MM/yyyy"))
                _HoraI = IIf((IsDBNull(dr("HoraI"))), Format$(Now(), "hh:mm"), dr("HoraI"))
                _HoraT = IIf((IsDBNull(dr("HoraT"))), Format$(Now(), "hh:mm"), dr("HoraT"))
                _Asunto = IIf((IsDBNull(dr("Asunto"))), "", dr("Asunto"))
                _Lugar = IIf((IsDBNull(dr("Lugar"))), "", dr("Lugar"))
                _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
                _Notas = IIf((IsDBNull(dr("Notas"))), "", dr("Notas"))
                _Status = IIf((IsDBNull(dr("Status"))), 0, dr("Status"))
                _No_Sol_Sala = IIf((IsDBNull(dr("No_Sol_Sala"))), "", dr("No_Sol_Sala"))
                _Id_Docto = IIf((IsDBNull(dr("Id_Docto"))), 0, dr("Id_Docto"))
                _Id_Tipo = IIf((IsDBNull(dr("Id_Tipo"))), 0, dr("Id_Tipo"))
                _Inactivo = IIf((IsDBNull(dr("Inactivo"))), 0, dr("Inactivo"))
                _Descripcion_Docto = IIf((IsDBNull(dr("Descripcion_Docto"))), "", dr("Descripcion_Docto"))
                _Id_Plan = IIf((IsDBNull(dr("Id_Plan"))), 0, dr("Id_Plan"))
                _Id_tema = IIf((IsDBNull(dr("Id_tema"))), 0, dr("Id_tema"))
                _id_status_sesion = IIf((IsDBNull(dr("id_status_sesion"))), 0, dr("id_status_sesion"))
                _Descripcion = IIf((IsDBNull(dr("Descripcion"))), "", dr("Descripcion"))
            Else
                _Id_Sesion = ""
                _Id_Comite = ""
                _Id_CT = ""
                _Id_SC = ""
                _Id_Grupo = ""
                _Fecha = ""
                _HoraI = ""
                _HoraT = ""
                _Asunto = ""
                _Lugar = ""
                _Responsable = ""
                _Notas = ""
                _Status = ""
                _No_Sol_Sala = ""
                _Id_Docto = ""
                _Id_Tipo = ""
                _Inactivo = ""
                _Descripcion_Docto = ""
                _Id_Plan = ""
                _Id_tema = ""
                _id_status_sesion = ""
                _Descripcion = ""
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Sub

    Public Function sesionDocumentos()
        Dim cmd As New SqlCommand
        Dim dt As New DataTable("DocumentosSesiones")
        Dim da As SqlDataAdapter
        cmd.CommandText = "sp_P_Sesiones"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.Parameters.Add("@id_sesion", _Id_Sesion)
        cmd.Parameters.Add("@Bandera", _Bandera)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function
    Public Sub ActivaInactiva()
        Dim cmd As New SqlCommand
        cmd.CommandText = "sp_P_Sesiones"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Parameters.Add("@id_sesion", _Id_Sesion)
        cmd.Parameters.Add("@docto", _Docto)
        cmd.Parameters.Add("@Inactivo", _Inactivo)
        cmd.Parameters.Add("@bandera", _Bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub BuscaDocto()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        cmd.CommandText = "sp_P_Sesiones"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Parameters.Add("@id_sesion", _Id_Sesion)
        cmd.Parameters.Add("@docto", _Docto)
        cmd.Parameters.Add("@bandera", _Bandera)
        Try
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Sesion = IIf(IsDBNull(dr("Id_Sesion")), Nothing, dr("Id_Sesion"))
                _Id_Docto = IIf(IsDBNull(dr("Id_Docto")), Nothing, dr("Id_Docto"))
                _Docto = IIf(IsDBNull(dr("Docto")), Nothing, dr("Docto"))
                _Id_Tipo = IIf(IsDBNull(dr("Id_Tipo")), Nothing, dr("Id_Tipo"))
                _Inactivo = IIf(IsDBNull(dr("Inactivo")), Nothing, dr("Inactivo"))
            Else
                _Id_Sesion = Nothing
                _Id_Docto = Nothing
                _Docto = Nothing
                _Id_Tipo = Nothing
                _Inactivo = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
