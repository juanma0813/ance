Public Class FrmTraspaso
    Inherits System.Windows.Forms.Form
    Private clsTree As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    ' defino variable del tipo DataRow
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim RegGT As DataRow
    Dim nodo1 As New TreeNode
    Dim Matriz As Array
    Dim Matriz_destino As Array
    Dim svariable As String
    Dim svariable_Destino As String
    Dim sPlan As String
    Dim sPlan_destino As String
    Dim stema As String
    Dim stema_destino As String
    Dim sraiz As String
    Dim sraiz_destino As String
    Dim sEtapa As String
    Public errors As Boolean
    Public srefP As String
    Public sEtapazok As String
    Private dtTiposTema As DataTable
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private ObjTiposTema As New ClsTipos_tema.C_Tipos_Tema(0, gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Private ObjTraspasoTemas As New ClsTraspasoTemas.P_Traspasos_TemasPNN(0, gUsuario, gPasswordSql)
    Private ObjProy As New ClsProy.P_Proy(0, gUsuario, gPasswordSql)
    Private ObjAnt As New ClsAnt.P_Ant(0, gUsuario, gPasswordSql)
    Private ObjDt As New ClsDt.P_DT(0, gUsuario, gPasswordSql)
    Private objProcAlter As New ClsProcedimientoAlternativo.P_Procedimiento_Alternativo(0, gUsuario, gPasswordSql)
    Private clsDoctosTemas As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)
    Private objTemasnormas As New ClsTemas_Normas.P_Temas_Normas(0, gUsuario, gPasswordSql)




#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents cmdTraspasar As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtnumerotema As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtClasificacionPT As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txttipoTema As System.Windows.Forms.TextBox
    Friend WithEvents cmdsalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtf1 As System.Windows.Forms.TextBox
    Friend WithEvents f1 As System.Windows.Forms.Label
    Friend WithEvents txtf2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents CboTipoTema As System.Windows.Forms.ComboBox
    Friend WithEvents pnldestino As System.Windows.Forms.Panel
    Friend WithEvents txtnvoNum As System.Windows.Forms.TextBox
    Friend WithEvents txtnvotipo As System.Windows.Forms.TextBox
    Friend WithEvents DT1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DT2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtnvafecha1 As System.Windows.Forms.TextBox
    Friend WithEvents txtnvafecha2 As System.Windows.Forms.TextBox
    Friend WithEvents tvpnndestino As System.Windows.Forms.TreeView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtpnndestino As System.Windows.Forms.TextBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmTraspaso))
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.tvpnndestino = New System.Windows.Forms.TreeView
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdTraspasar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdsalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.txtnumerotema = New System.Windows.Forms.TextBox
        Me.Label47 = New System.Windows.Forms.Label
        Me.txtClasificacionPT = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txttipoTema = New System.Windows.Forms.TextBox
        Me.txtf1 = New System.Windows.Forms.TextBox
        Me.f1 = New System.Windows.Forms.Label
        Me.txtf2 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.pnldestino = New System.Windows.Forms.Panel
        Me.txtpnndestino = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtnvafecha2 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtnvafecha1 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtnvoNum = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtnvotipo = New System.Windows.Forms.TextBox
        Me.CboTipoTema = New System.Windows.Forms.ComboBox
        Me.DT2 = New System.Windows.Forms.DateTimePicker
        Me.DT1 = New System.Windows.Forms.DateTimePicker
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.pnldestino.SuspendLayout()
        Me.SuspendLayout()
        '
        'TVPNN
        '
        Me.TVPNN.ImageIndex = 2
        Me.TVPNN.ImageList = Me.imgListTreeView
        Me.TVPNN.Location = New System.Drawing.Point(16, 16)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = 2
        Me.TVPNN.Size = New System.Drawing.Size(184, 408)
        Me.TVPNN.TabIndex = 14
        '
        'tvpnndestino
        '
        Me.tvpnndestino.ImageIndex = 2
        Me.tvpnndestino.ImageList = Me.imgListTreeView
        Me.tvpnndestino.Location = New System.Drawing.Point(560, 24)
        Me.tvpnndestino.Name = "tvpnndestino"
        Me.tvpnndestino.SelectedImageIndex = 2
        Me.tvpnndestino.Size = New System.Drawing.Size(184, 408)
        Me.tvpnndestino.TabIndex = 15
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdTraspasar, Me.CmdDeshacer, Me.cmdsalvar, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 464)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(752, 62)
        Me.tlbBotonera.TabIndex = 16
        '
        'cmdTraspasar
        '
        Me.cmdTraspasar.ImageIndex = 8
        Me.cmdTraspasar.Text = "Traspasar"
        Me.cmdTraspasar.ToolTipText = "Se agregan las noticias"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'cmdsalvar
        '
        Me.cmdsalvar.ImageIndex = 2
        Me.cmdsalvar.Text = "Salvar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'txtnumerotema
        '
        Me.txtnumerotema.Location = New System.Drawing.Point(320, 104)
        Me.txtnumerotema.Multiline = True
        Me.txtnumerotema.Name = "txtnumerotema"
        Me.txtnumerotema.Size = New System.Drawing.Size(64, 20)
        Me.txtnumerotema.TabIndex = 59
        Me.txtnumerotema.Text = ""
        '
        'Label47
        '
        Me.Label47.Location = New System.Drawing.Point(224, 104)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(80, 16)
        Me.Label47.TabIndex = 67
        Me.Label47.Text = "N�mero  tema"
        '
        'txtClasificacionPT
        '
        Me.txtClasificacionPT.Location = New System.Drawing.Point(320, 72)
        Me.txtClasificacionPT.Name = "txtClasificacionPT"
        Me.txtClasificacionPT.Size = New System.Drawing.Size(232, 20)
        Me.txtClasificacionPT.TabIndex = 58
        Me.txtClasificacionPT.Text = ""
        '
        'Label44
        '
        Me.Label44.Location = New System.Drawing.Point(224, 72)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(80, 24)
        Me.Label44.TabIndex = 64
        Me.Label44.Text = "Clasificaci�n"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(224, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 23)
        Me.Label2.TabIndex = 62
        Me.Label2.Text = "Tipo de Tema:"
        '
        'txttipoTema
        '
        Me.txttipoTema.Enabled = False
        Me.txttipoTema.Location = New System.Drawing.Point(320, 136)
        Me.txttipoTema.Name = "txttipoTema"
        Me.txttipoTema.Size = New System.Drawing.Size(184, 20)
        Me.txttipoTema.TabIndex = 63
        Me.txttipoTema.Text = ""
        '
        'txtf1
        '
        Me.txtf1.Enabled = False
        Me.txtf1.Location = New System.Drawing.Point(320, 168)
        Me.txtf1.Name = "txtf1"
        Me.txtf1.Size = New System.Drawing.Size(104, 20)
        Me.txtf1.TabIndex = 70
        Me.txtf1.Text = ""
        '
        'f1
        '
        Me.f1.Location = New System.Drawing.Point(232, 168)
        Me.f1.Name = "f1"
        Me.f1.Size = New System.Drawing.Size(88, 16)
        Me.f1.TabIndex = 69
        Me.f1.Text = "Fecha de Inicio"
        '
        'txtf2
        '
        Me.txtf2.Enabled = False
        Me.txtf2.Location = New System.Drawing.Point(320, 200)
        Me.txtf2.Name = "txtf2"
        Me.txtf2.Size = New System.Drawing.Size(104, 20)
        Me.txtf2.TabIndex = 73
        Me.txtf2.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(232, 200)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 72
        Me.Label1.Text = "Fecha de Fin"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(232, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(136, 23)
        Me.Label8.TabIndex = 83
        Me.Label8.Text = "Plan or�gen"
        '
        'pnldestino
        '
        Me.pnldestino.Controls.Add(Me.txtpnndestino)
        Me.pnldestino.Controls.Add(Me.Label9)
        Me.pnldestino.Controls.Add(Me.Label7)
        Me.pnldestino.Controls.Add(Me.txtnvafecha2)
        Me.pnldestino.Controls.Add(Me.Label3)
        Me.pnldestino.Controls.Add(Me.txtnvafecha1)
        Me.pnldestino.Controls.Add(Me.Label4)
        Me.pnldestino.Controls.Add(Me.txtnvoNum)
        Me.pnldestino.Controls.Add(Me.Label5)
        Me.pnldestino.Controls.Add(Me.Label6)
        Me.pnldestino.Controls.Add(Me.txtnvotipo)
        Me.pnldestino.Controls.Add(Me.CboTipoTema)
        Me.pnldestino.Controls.Add(Me.DT2)
        Me.pnldestino.Controls.Add(Me.DT1)
        Me.pnldestino.Location = New System.Drawing.Point(224, 232)
        Me.pnldestino.Name = "pnldestino"
        Me.pnldestino.Size = New System.Drawing.Size(320, 216)
        Me.pnldestino.TabIndex = 84
        '
        'txtpnndestino
        '
        Me.txtpnndestino.Location = New System.Drawing.Point(104, 40)
        Me.txtpnndestino.Multiline = True
        Me.txtpnndestino.Name = "txtpnndestino"
        Me.txtpnndestino.Size = New System.Drawing.Size(184, 20)
        Me.txtpnndestino.TabIndex = 95
        Me.txtpnndestino.Text = ""
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(16, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 16)
        Me.Label9.TabIndex = 96
        Me.Label9.Text = "PNN Destino"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(136, 23)
        Me.Label7.TabIndex = 91
        Me.Label7.Text = "Plan destino"
        '
        'txtnvafecha2
        '
        Me.txtnvafecha2.Enabled = False
        Me.txtnvafecha2.Location = New System.Drawing.Point(104, 176)
        Me.txtnvafecha2.Name = "txtnvafecha2"
        Me.txtnvafecha2.Size = New System.Drawing.Size(104, 20)
        Me.txtnvafecha2.TabIndex = 90
        Me.txtnvafecha2.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 89
        Me.Label3.Text = "Fecha de Fin"
        '
        'txtnvafecha1
        '
        Me.txtnvafecha1.Enabled = False
        Me.txtnvafecha1.Location = New System.Drawing.Point(104, 144)
        Me.txtnvafecha1.Name = "txtnvafecha1"
        Me.txtnvafecha1.Size = New System.Drawing.Size(104, 20)
        Me.txtnvafecha1.TabIndex = 88
        Me.txtnvafecha1.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 144)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 16)
        Me.Label4.TabIndex = 87
        Me.Label4.Text = "Fecha de Inicio"
        '
        'txtnvoNum
        '
        Me.txtnvoNum.Location = New System.Drawing.Point(104, 80)
        Me.txtnvoNum.Multiline = True
        Me.txtnvoNum.Name = "txtnvoNum"
        Me.txtnvoNum.Size = New System.Drawing.Size(64, 20)
        Me.txtnvoNum.TabIndex = 83
        Me.txtnvoNum.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 16)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "N�mero  tema"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 112)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 23)
        Me.Label6.TabIndex = 84
        Me.Label6.Text = "Tipo de Tema:"
        '
        'txtnvotipo
        '
        Me.txtnvotipo.Enabled = False
        Me.txtnvotipo.Location = New System.Drawing.Point(104, 112)
        Me.txtnvotipo.Name = "txtnvotipo"
        Me.txtnvotipo.Size = New System.Drawing.Size(176, 20)
        Me.txtnvotipo.TabIndex = 85
        Me.txtnvotipo.Text = ""
        '
        'CboTipoTema
        '
        Me.CboTipoTema.ItemHeight = 13
        Me.CboTipoTema.Location = New System.Drawing.Point(104, 112)
        Me.CboTipoTema.Name = "CboTipoTema"
        Me.CboTipoTema.Size = New System.Drawing.Size(192, 21)
        Me.CboTipoTema.TabIndex = 92
        '
        'DT2
        '
        Me.DT2.Location = New System.Drawing.Point(104, 176)
        Me.DT2.Name = "DT2"
        Me.DT2.Size = New System.Drawing.Size(120, 20)
        Me.DT2.TabIndex = 94
        '
        'DT1
        '
        Me.DT1.Location = New System.Drawing.Point(104, 144)
        Me.DT1.Name = "DT1"
        Me.DT1.Size = New System.Drawing.Size(120, 20)
        Me.DT1.TabIndex = 93
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'FrmTraspaso
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(752, 526)
        Me.Controls.Add(Me.pnldestino)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtf2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtf1)
        Me.Controls.Add(Me.f1)
        Me.Controls.Add(Me.txtnumerotema)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.txtClasificacionPT)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txttipoTema)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.tvpnndestino)
        Me.Controls.Add(Me.TVPNN)
        Me.Name = "FrmTraspaso"
        Me.Text = "FrmTraspaso"
        Me.pnldestino.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FrmTraspaso_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sEtapa = "Inactivo"
        Call Habilita(sEtapa)
        Call Llena_PNN()
    End Sub

#Region " TreeView, Metodos y Procesos de FrmTraspaso"

#Region " TreeView - TVPNN, Metodos y Procesos de FrmTraspaso"

#Region " TVPNN - Llena_PNN, Metodos y Procesos de FrmTraspaso"

    Sub Llena_PNN()
        oTablaPNN = x.ListaPNN("")
        TVPNN.BeginUpdate()
        nodo = TVPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = TVPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = x.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.ImageIndex = 5
                nodo1.SelectedImageIndex = 6
            Next
        Next
        TVPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVPNN.AllowDrop = False

    End Sub

#End Region

#Region " TVPNN - TVPNN_AfterSelect, Metodos y Procesos de FrmTraspaso"

    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVPNN.AfterSelect
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                stema = ""
                sPlan = ""
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2))
            Case 2
                sPlan = Matriz(1)
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2))
            Case 3
                sPlan = Matriz(1)
                stema = Matriz(2)
                If sPlan <> "" And stema <> "" Then
                    Call Llena_Temas(sPlan, stema)
                    Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2))
                End If
        End Select
    End Sub

#End Region

#End Region

#Region " TreeView - tvpnndestino, Metodos y Procesos de FrmTraspaso"

#Region " tvpnndestino - tvpnndestino_AfterSelect, Metodos y Procesos de FrmTraspaso"

    Private Sub tvpnndestino_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvpnndestino.AfterSelect
        svariable_Destino = e.Node.FullPath
        Matriz_destino = Split(svariable_Destino, "\")

        Select Case Matriz_destino.Length
            Case 1
                sraiz_destino = Matriz_destino(0)
                stema_destino = ""
                sPlan_destino = ""
                Inactivos(tlbBotonera.Buttons.Item(0))
            Case 2
                sPlan_destino = Matriz_destino(1)
                If sPlan_destino = sPlan Then
                    MsgBox("No puede traspasarse el tema a un mismo plan de Trabajo")
                    txtpnndestino.Text = ""
                    Exit Sub
                Else
                    Inactivos(tlbBotonera.Buttons.Item(0))
                    txtpnndestino.Text = sPlan_destino
                    Activos(pnldestino, txtnvoNum, CboTipoTema, DT1, DT2, txtnvotipo)
                    Inactivos(txtnvotipo, txtnvafecha1, txtnvafecha2)

                End If
        End Select

    End Sub

#End Region

#Region " tvpnndestino - Llena_PNN_destino, Metodos y Procesos de FrmTraspaso"

    Sub Llena_PNN_destino()
        oTablaPNN = x.ListaPNN("")
        tvpnndestino.BeginUpdate()
        nodo = tvpnndestino.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvpnndestino.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = x.ListaDprog(Trim(RegPNN("id_plan")))
            'For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
            '    nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
            'Next
        Next
        tvpnndestino.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvpnndestino.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvpnndestino.Sorted = True
    End Sub

#End Region

#End Region

#End Region

#Region " tlbBotonera - tlbBotonera_ButtonClick"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Dim Ibandera As Integer
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                IdentificaEtapa()
                If sEtapazok = "NMX" Then
                    MsgBox("No puede traspasarse el tema que esta en etapa de Norma")
                    Exit Sub
                End If
                sEtapa = "TRASPASO"
                Call Habilita(sEtapa)
                Call Llena_PNN_destino()
                dtTiposTema = ObjTiposTema.ListaCombo()
                CboTipoTema.DataSource = dtTiposTema
                CboTipoTema.DisplayMember = dtTiposTema.Columns(1).ColumnName
                CboTipoTema.ValueMember = dtTiposTema.Columns(0).ColumnName
            Case 1 'deshacer
                sEtapa = "Inactivo"
                Call Habilita(sEtapa)
                TVPNN.Nodes.Clear()
                tvpnndestino.Nodes.Clear()
                TVPNN.Refresh()
                tvpnndestino.Refresh()
                Call Llena_PNN()
                Call Limpia_Campos(txtClasificacionPT, txttipoTema, txtf1, txtf2, txtnumerotema, pnldestino, txtnvoNum, txtnvafecha1, txtnvafecha2, txtnvotipo, txtpnndestino)

            Case 2 'Salvar
                Call Valida()
                If errors = True Then Exit Sub
                'Busca si el tema destino ya existe en el plan de trabajo
                Referenciar("traspaso")
                ObjPrograma.Band = True
                ObjPrograma.sReferencia = srefP
                ObjPrograma.Bandera = 38
                ObjPrograma.Buscar(txtpnndestino.Text, txtnvoNum.Text)
                If ObjPrograma.Existe = True Then
                    MsgBox("El n�mero de tema ya existe en ese plan, Verificar")
                    Exit Sub
                Else
                    ObjPrograma.Buscar(sPlan, stema)
                    'Dim trasp As Integer = cint(ObjPrograma.RefTraspaso) + 1
                    'ObjPrograma.Insertar(ObjPrograma.RefA�o, ObjPrograma.RefComite, ObjPrograma.RefConsecutivo, ObjPrograma.RefRegreso, CStr(trasp), txtpnndestino.Text, txtnvoNum.Text, ObjPrograma.Clasificacion, ObjPrograma.Tipo_Pro, CboTipoTema.SelectedValue, ObjPrograma.Titulo, ObjPrograma.Obj, ObjPrograma.Justificacion, txtnvafecha1.Text, txtnvafecha2.Text, ObjPrograma.Revision, ObjPrograma.ID_Comite, ObjPrograma.ID_CT, ObjPrograma.ID_SC, ObjPrograma.ID_Grupo, ObjPrograma.ID_etapa, ObjPrograma.Responsable, ObjPrograma.Basada_Norma, ObjPrograma.Id_Norma, False, "", ObjPrograma.Id_Norma)
                    ''' traspaso()
                    Dim sResultado As String = TraspasoSQL()

                    'zok1
                    'busco los datos para la referencia y solo busco en el store esto
                    Dim sRef As String
                    ObjPrograma.Band = False
                    ObjPrograma.Buscar(sPlan, stema)
                    sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
                    'zok1
                    ObjFechasavance.Buscar(stema, sPlan, sRef)
                    'Busca si existe avance en fechas si existe las copia si no existen las crea con el nuevo tema y plan.
                    'If ObjFechasavance.BANDERA = True Then
                    'ObjFechasavance.Actualiza(1, txtpnndestino.Text, txtnvoNum.Text, ObjFechasavance.F_Inic_Desarrollo_Nmx, ObjFechasavance.F_Aprob_Revisi�n_Editorial, ObjFechasavance.F_Carga_DtFinal, ObjFechasavance.F_Impresion_ActaAprobacion, ObjFechasavance.F_Carga_ActaAprobacion, ObjFechasavance.F_Aprobacion_CTGT_ANT, ObjFechasavance.F_Aprobacion_Comite_PROY, ObjFechasavance.F_Publicacion_ComentarioPublico, ObjFechasavance.F_Limite_ComentarioPublico, ObjFechasavance.F_Resolucion_ComentarioPublico, ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico, ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico, ObjFechasavance.F_VoBo_CONANCE, ObjFechasavance.F_Inicio_Revision_PROYF, ObjFechasavance.F_Termino_Revision_PROYF, ObjFechasavance.F_Edicion_PROYF, ObjFechasavance.F_Impresion_ActaAprobacion_PROYF, ObjFechasavance.F_Carga_ActaAprobacion_PROYF, ObjFechasavance.F_ACUSE_DGN_PROYF, ObjFechasavance.F_CARGA_PROYF, ObjFechasavance.F_CARGA_ANTF)
                    'Else
                    '    ObjFechasavance.Actualiza(1, txtpnndestino.Text, txtnvoNum.Text, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
                    'End If
                    'Inserta en la tabla de Traspasos los movimientos
                    'ObjTraspasoTemas.Actualiza(sPlan, stema, gUsuario, txtpnndestino.Text, txtnvoNum.Text)
                    'Inhabilita el tema anterior o que fue traspasado
                    'ObjPrograma.Borrar(sPlan, stema)
                    TVPNN.Nodes.Clear()
                    tvpnndestino.Nodes.Clear()

                    If sResultado = "CORRECTO" Then
                        MsgBox("El tema fu� traspasado correctamente")
                    Else
                        MsgBox("Ocurrio un problema al trasladar el tema, favor de contactar al �rea de sistemas de computo." & Chr(13) & "Detalle: " & sResultado, MsgBoxStyle.Critical, "Problemas al Trasladar el tema")
                    End If
                    DT1.Enabled = True
                    sEtapa = "Inactivo"

                    Call Habilita(sEtapa)
                    Call Llena_PNN()
                    Call Limpia_Campos(txtClasificacionPT, txttipoTema, txtf1, txtf2, txtnumerotema, pnldestino, txtnvoNum, txtnvafecha1, txtnvafecha2, txtnvotipo, txtpnndestino)

                End If
            Case 3 'salir
                Me.Dispose()
        End Select
    End Sub
    Private Sub IdentificaEtapa()
        sComite = ObjPrograma.ID_Comite
        sCt = ObjPrograma.ID_CT
        sSc = ObjPrograma.ID_SC
        sGt = ObjPrograma.ID_Grupo
        Select Case ObjPrograma.ID_etapa
            Case 1
                sEtapazok = "PT"
            Case 2
                sEtapazok = "DT"
            Case 3
                sEtapazok = "ANT"
            Case 4
                sEtapazok = "PROY"
            Case "5"
                sEtapazok = "NMX"
        End Select
    End Sub
    Private Function TraspasoSQL() As String
        Referenciar("abandono")

        'srefP Referencia Origen
        'stema TemaOrigen
        'sPlan PlanOrigen
        'txtpnndestino.Text 
        'txtnvoNum.Text

        Dim clsPTraspaso As New ClsTraspasoTemas.P_Traspasos_TemasPNN(0, gUsuario, gPasswordSql)
        clsPTraspaso.id_Plan = sPlan
        clsPTraspaso.Id_tema = stema
        clsPTraspaso.Id_plan_destino = txtpnndestino.Text
        clsPTraspaso.Id_Tema_destino = txtnvoNum.Text
        Dim sRespuesta As String
        sRespuesta = clsPTraspaso.TraspasoTema(srefP, IIf(txtnvafecha1.Text = "", Nothing, txtnvafecha1.Text), IIf(txtnvafecha2.Text = "", Nothing, txtnvafecha2.Text), CboTipoTema.SelectedValue)
        Return sRespuesta

    End Function
    Private Sub traspaso()
        'traspaso de proyecto
        Referenciar("abandono")

        ObjProy.sReferencia = srefP
        ObjProy.Buscar(stema, sPlan, srefP)
        ObjProy.traspasaProy(txtpnndestino.Text, txtnvoNum.Text)

        'traspaso de Ant
        ObjAnt.sReferencia = srefP
        ObjAnt.Buscar(stema, sPlan, srefP)
        ObjAnt.traspasaAnt(txtpnndestino.Text, txtnvoNum.Text)

        'traspaso de DT
        ObjDt.sReferencia = srefP
        ObjDt.Buscar(stema, sPlan, srefP)
        ObjDt.traspasaDT(txtpnndestino.Text, txtnvoNum.Text)

        'traspaso de proc alternativo
        objProcAlter.sReferencia = srefP
        objProcAlter.Buscar(sPlan, stema, srefP)
        objProcAlter.traspasaAlter(txtpnndestino.Text, txtnvoNum.Text)


        'traspaso de proc temas normas
        objTemasnormas.sReferencia = srefP
        objTemasnormas.BuscarXreferencia(stema, sPlan)
        objTemasnormas.traspasaTemasNormas(txtpnndestino.Text, txtnvoNum.Text)


        'traspaso de Documentos
        clsDoctosTemas.sReferencia = srefP
        'clsDoctosTemas.ListaDocumentos()
        clsDoctosTemas.traspasaDoctos(txtpnndestino.Text, txtnvoNum.Text)

        'traspaso de avence fechas
        ObjFechasavance.sReferencia = srefP
        ObjFechasavance.Buscar(stema, sPlan, srefP)
        IdentificaEtapa()
        ObjFechasavance.sEtapa = sEtapazok
        ObjFechasavance.traspasaFavance(txtpnndestino.Text, txtnvoNum.Text)

        'traspaso de programa de trabajo
        'ObjPrograma.sReferencia = srefP
        ObjPrograma.Band = True
        ObjPrograma.sReferencia = srefP
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.traspasaPrograma(txtpnndestino.Text, txtnvoNum.Text, CboTipoTema.SelectedValue, IIf(txtnvafecha1.Text = "", Nothing, txtnvafecha1.Text), IIf(txtnvafecha2.Text = "", Nothing, txtnvafecha2.Text))


    End Sub

#End Region
    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(sPlan, stema)
        srefP = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
    End Sub

#Region " Metodos y Procesos de FrmTraspaso"

#Region " Sub Habilita(sEtapa),Metodos y Procesos de FrmTraspaso"

    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "TRASPASO"
                Call Activos(pnldestino, txtnvoNum, txtnvafecha1, txtnvafecha2, txtnvotipo)
                Call Inactivos(txtClasificacionPT, txttipoTema, txtf1, txtf2, txtnumerotema, txtpnndestino)
                Call Inactivos(tlbBotonera.Buttons.Item(0))
            Case "INACTIVO"
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2))

        End Select
    End Sub

#End Region

#Region " Sub Llena_Temas(splan, stema), Metodos y Procesos de FrmTraspaso"

    Private Sub Llena_Temas(ByVal splan As String, ByVal stema As String)
        Dim Sstatus As String
        ObjPrograma.Buscar(splan, stema)
        Call Inactivos(txtClasificacionPT, txttipoTema, txtf1, txtf2, txtnumerotema, pnldestino, txtnvoNum, txtnvafecha1, txtnvafecha2, txtnvotipo, txtpnndestino)
        txtClasificacionPT.Text = ObjPrograma.Clasificacion
        ObjTiposTema.Buscar(ObjPrograma.Tipo_Tema)
        txttipoTema.Text = ObjTiposTema.Descripcion
        txtf1.Text = ObjPrograma.F_Inicio
        txtf2.Text = ObjPrograma.F_Fin
        txtnumerotema.Text = ObjPrograma.Id_Tema
    End Sub

#End Region

#Region " Sub Valida, Metodos y Procesos de FrmTraspaso"

    Sub Valida()
        errors = False
        If txtpnndestino.Text = "" Then
            MsgBox("Debes de seleccionar un Plan de Trabajo destino para poder traspasar el tema")
            errors = True
            Exit Sub

        End If
        If Not IsNumeric(txtnvoNum.Text) Then
            MsgBox("El n�mero de tema debe ser num�rico")
            errors = True
            Exit Sub
        End If
        If txtnvoNum.Text = "" Then
            MsgBox("El n�mero de tema no puede estar vac�o")
            errors = True
            Exit Sub
        End If
        If txtnvotipo.Text = "" Then
            MsgBox("El tipo de tema no puede ir vac�o")
            errors = True
            Exit Sub
        End If
        If txtnvafecha1.Text = "" And CboTipoTema.Text <> "Proyecto Publicado" Then
            MsgBox("La fecha de Inicio del Tema no puede quedar vac�a")
            errors = True
            Exit Sub
        End If
        If txtnvafecha2.Text = "" Then
            MsgBox("La fecha de Fin de tema no puede quedar vac�a")
            errors = True
            Exit Sub
        End If
    End Sub

#End Region

#End Region

    Private Sub CboTipoTema_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboTipoTema.SelectedIndexChanged
        DT1.Enabled = True
        If CboTipoTema.Text = "Proyecto Publicado" Then
            DT1.Enabled = False
            txtnvafecha1.Text = ObjPrograma.F_Inicio
        End If
        If sEtapa = "TRASPASO" Then
            txtnvotipo.Text = CboTipoTema.Text
        End If
    End Sub

    Private Sub DT1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DT1.ValueChanged
        txtnvafecha1.Text = Format(DT1.Value, "dd/MM/yyyy")
    End Sub

    Private Sub DT2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DT2.ValueChanged
        txtnvafecha2.Text = Format(DT2.Value, "dd/MM/yyyy")
    End Sub
End Class
