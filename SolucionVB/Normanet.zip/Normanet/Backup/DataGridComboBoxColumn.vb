Option Strict Off
Option Explicit On 

Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Collections

Public Class DataGridComboBoxColumn
    Inherits DataGridTextBoxColumn
    Public WithEvents ColumnComboBox As ComboSinKeyUp
    Private WithEvents _Origen As CurrencyManager
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Friend WithEvents CboPlanes As System.Windows.Forms.ComboBox
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Private _ColumnaNumero As Integer
    Private _RenglonNumero As Integer
    Private _EsEdicion As Boolean
    Private _NoEdita As Integer
    Private objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Private grid As DataGrid

    Public Property ColumnaNumero() As Integer
        Get
            Return _ColumnaNumero
        End Get
        Set(ByVal Value As Integer)
            _ColumnaNumero = Value
        End Set
    End Property

    Shared Sub New()
    End Sub

    Public Sub New(ByVal cols As Integer, ByVal obj As Object)
        MyBase.New()
        grid = obj
        _ColumnaNumero = cols
        _Origen = Nothing
        _EsEdicion = False
        ColumnComboBox = New ComboSinKeyUp
        AddHandler ColumnComboBox.Leave, New EventHandler(AddressOf DejarComboBox)
        AddHandler ColumnComboBox.SelectionChangeCommitted, New EventHandler(AddressOf ComboComienzaEdicion)
        AddHandler ColumnComboBox.KeyPress, New System.Windows.Forms.KeyPressEventHandler(AddressOf HandleKeyPress)

    End Sub

    Protected Overloads Overrides Sub Edit(ByVal source As CurrencyManager, ByVal rowNum As Integer, ByVal bounds As Rectangle, ByVal readOnly1 As Boolean, ByVal instantText As String, ByVal cellIsVisible As Boolean)
        MyBase.Edit(source, rowNum, bounds, readOnly1, instantText, cellIsVisible)
        _RenglonNumero = rowNum
        _Origen = source

        ColumnComboBox.Parent = Me.TextBox.Parent
        ColumnComboBox.Location = Me.TextBox.Location
        ColumnComboBox.Size = New Size(Me.TextBox.Size.Width, ColumnComboBox.Size.Height)
        ColumnComboBox.Text = Me.TextBox.Text
        '''''''''''''''              Codigo opcional, depende del fin con que se utilice, evento conocido como getfocus de un combo

        ''If ColumnComboBox.Name = "CboTemas" Then
        ''    ColumnComboBox.DataSource = DTC_Temas
        ''End If

        '''''''''''''''              Fin de Codigo
        '''''''''''''''              Activo el combo

        ''''''''''Me.TextBox.Visible = False                 'solucion original
        ''''''''''ColumnComboBox.Visible = True
        ''''''''''ColumnComboBox.BringToFront()
        ''''''''''ColumnComboBox.Focus()


        Select Case ColumnComboBox.Name
            Case "CboTipos_doctos"
                If iarchv - 1 < _RenglonNumero Then
                    Me.TextBox.Visible = False
                    ColumnComboBox.Visible = True
                    ColumnComboBox.BringToFront()
                    ColumnComboBox.Focus()
                Else
                    Me.TextBox.Visible = False
                    ColumnComboBox.Hide()
                End If
                ''Case "CboTemas", "CboPlanes"
                ''    If itemas - 1 < _RenglonNumero Then
                ''        Me.TextBox.Visible = False
                ''        ColumnComboBox.Visible = True
                ''        ColumnComboBox.BringToFront()
                ''        ColumnComboBox.Focus()
                ''    Else
                ''        Me.TextBox.Visible = False
                ''        ColumnComboBox.Hide()
                ''    End If
            Case Else
                Me.TextBox.Visible = False
                ColumnComboBox.Visible = True
                ColumnComboBox.BringToFront()
                ColumnComboBox.Focus()
        End Select
    End Sub


    Protected Overloads Overrides Function Commit(ByVal dataSource As CurrencyManager, ByVal rowNum As Integer) As Boolean
        If _EsEdicion Then
            _EsEdicion = False
            SetColumnValueAtRow(dataSource, rowNum, ColumnComboBox.Text)
        End If
        Return True
    End Function

    Private Sub ComboComienzaEdicion(ByVal sender As Object, ByVal e As EventArgs)
        _EsEdicion = True
        MyBase.ColumnStartedEditing(sender)
    End Sub

    Private Sub DejarComboBox(ByVal sender As Object, ByVal e As EventArgs)
        Dim objeto As String
        If _EsEdicion Then
            SetColumnValueAtRow(_Origen, _RenglonNumero, ColumnComboBox.Text)
            '''''''''''''''              Codigo opcional, depende del fin con que se utilice, evento conocido como selectchange de un combo

            ''Dim objptrabajo As New ClsProgramaTrabajo.P_Prog_Trab("principal", "admsis", "admynsys")
            Select Case ColumnComboBox.Name
                Case "status"
                    grid.Item(_RenglonNumero, 3) = True

            End Select

            '''''''''''''''              Fin de Codigo
            _EsEdicion = False

            Invalidate()
        End If
        ColumnComboBox.Hide()
    End Sub


    Private Sub HandleKeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        Dim pos As Integer
        If ColumnComboBox.SelectedIndex > -1 Then
            If UCase(e.KeyChar) = Left(ColumnComboBox.SelectedItem.ToString.ToUpper, 1) Then
                pos = busqueda_sig(e.KeyChar)
            Else
                pos = busqueda_primero(e.KeyChar)
            End If
        Else
            pos = busqueda_primero(e.KeyChar)
        End If
        If pos <> -1 Then
            ColumnComboBox.SelectedIndex = pos
            SetColumnValueAtRow(_Origen, _RenglonNumero, ColumnComboBox.Text)
        End If
        e.Handled = True
    End Sub

    Private Function busqueda_primero(ByVal letra As String) As Integer
        Dim i As Integer
        For i = 0 To ColumnComboBox.Items.Count - 1
            If letra.ToUpper() = Left(ColumnComboBox.Items(i).ToString.ToUpper, 1) Then
                Return i
            End If
        Next
        Return -1
    End Function

    Private Function busqueda_sig(ByVal letra As String) As Integer
        If ColumnComboBox.SelectedIndex < ColumnComboBox.Items.Count - 1 Then
            ColumnComboBox.SelectedIndex = ColumnComboBox.SelectedIndex + 1
            If letra.ToUpper() = Left(ColumnComboBox.SelectedItem.ToString.ToUpper, 1) Then
                Return ColumnComboBox.SelectedIndex
            Else
                Return busqueda_primero(letra)
            End If
        Else
            Return busqueda_primero(letra)
        End If
    End Function
End Class

Public Class ComboSinKeyUp
    Inherits ComboBox
    Private WM_KEYUP As Integer = &H101

    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        If m.Msg = WM_KEYUP Then
            'Ignora el keyup para evita problemas de tabulaci�n
            Return
        End If
        MyBase.WndProc(m)
    End Sub
End Class

