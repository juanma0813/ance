
Imports System.IO
Imports Microsoft.Office.Interop

Module General

    Public dsResultado As New DataSet
    Public dsVarios As New DataSet
    Public dsConsulta As New DataSet
    Public dsAviso As New DataSet
    Public dsRefe As New DataSet
    Public dsTramitador As New DataSet
    Public dsGrid_Resultado As New DataSet
    Public gUsuario As String
    Public gPasswordSql As String
    Public sOrden As String
    Public iGrupo As Integer
    Public sSQL As String
    Public gSeleccion As Integer
    Public dsNoticias As DataSet
    Public sUsuario As String
    Public iId_Sistema As Integer
    Public dsmenu As DataSet
    Public DTC_Temas As New DataTable
    Public DTSesiones As New DataTable
    Public DTTemas As New DataTable
    Public DTArchivos As New DataTable
    Public iarchv, itemas As Integer
    Public respuesta As String
    Public FechaDeclaratoria As String
    Public error1 As Boolean = False
    Public bandgrd As Boolean = False

    ''Esta varible nos servira para ke no abra mas ventanas si ya estan abiertas
    Public aCompletaVis, aPlanMens, aPlanMens2, aCriter, aEtapas, aRefClie, aAviso, aResultado, aAtendidasNo, aTraspaso, aCalendario As Integer
    Public aSeleccionMes, aSuspensiones, aBlokeos, aCambioStatus, aHistorial, aFacturacion, aReportePruebas, aReservaciones As Integer
    Public aReprograma, aRevisionCaptura, aConsultRefe, aAdvertencia1, aAdvertencia2, TipoAd As Integer
    Public frmMenu As New FrmPrincipal
    ''Variable para controlar los datos ke contiene el grid despues de agregar clientes al mes
    Public iContador As Integer
    ''Variable para controlas el numero de referencias manejadas en el grid de Resultado de la visita
    Public gReferencias As Integer
    Public gPlanMen As String

    ''Variable apra identificar ke informe Muestraa
    Public gReporte As String
    Public Contar As Integer

    ''Varibales para manejar el calendario a Muestra
    Public sMes As String
    Public sA�o As String
    Public sFecha As String

    ''Varibales para manejar el reporte de suspension de referencia
    Public gRepresentante, gTelefono, gFax, gMail, gVS, gF_Vis, gTramitador, gTel_Tramitador, gFax_Tramitador As String
    Public gFecha_Susp As String

    ''Varible para traer el nombre completo del usuario
    Public stUsuario As String

    ''Variable para saber si la ventana de Completar visita 
    Public Reprograma As Boolean
    Public ReproHora As Boolean
    Public sObservaciones As String
    Public sTipoReprograma As String
    Public sReferenciaRepro As String
    Public sIngeniero As String
    Public sBodega As String
    Public Consecutivo As Boolean

    ''Varibales donde se guardan los datos de las referencias que son reprogramadas 
    Public sTipoVisitaRep As String
    Public sA�oRep As String
    Public sClaveRep As String
    Public sConsecutivoRep As String
    Public gNom_Inge As String
    Public gDelegacion As String
    Public gId_Estado As String
    Public gEstado As String
    Public gColonia As String
    'Public rReprogramada As String
    Public Nvo_Consecutivo As String

    Public iAgregadas As Integer

    ''EEJ: 09/03/06
    ''Variables para extraer los iconos dese donde se encuentra el ejecutable
    Public Icono1, Icono2 As Image

    ''EEJ: 09/03/06
    ''sirve para controlar las ventanas de aviso

    ''MAG 03/07/2006
    ''Sirve para controlar los dataset, vacia la informacion para ke no muera por segunda ocaci�n cuando 
    ''se abre la ventana

    Public iContadorSol As Integer
    Public iContadorMantenimiento As Integer
    ''Sirve para traer el id del sistema

    Public SGralTema As String
    Public SGralPlan As String
    Public sGralTitulo As String
    Public sGralComite As String
    Public sGralClasificacion As String
    Public sGralFecha As String
    Public SGralCargos As String
    Public SCveDirectorio As String
    Public SConsecutivo As String
    Public sSector As String
    Public sRepresentacion As String
    Public sComite As String
    Public SCt As String
    Public SSc As String
    Public sGT As String
    Public Activo As Integer
    Public Activo_Temas As Integer
    Public sSesion As String
    Public sNorma As String
    Public sPaginas As String
    Public sCancela As String
    Public sComiteT As String
    Public sPreConance As String
    Public sPreAnce As String

    Public zComite As String
    Public zCt As String
    Public zSc As String
    Public zGT As String

#Region " SoloNumeros - SoloNumeroskeypress(Object,  e), Metodos y Procesos "

    Public Sub SoloNumeroskeypress(ByVal sender As Object, ByVal e As KeyPressEventArgs)

        'Ignora la tecla presionada si no es d�gito o tecla de control
        If e.KeyChar.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf e.KeyChar.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

        'Ignora la tecla presionada si el valor es mas grande de cuatro d�gitos
        If ((sender.Text.Length >= 4) AndAlso Not (e.KeyChar.IsControl(e.KeyChar)) AndAlso sender.SelectionLength = 0) Then
            e.Handled = True
        End If
        'DGrid_CurrentCellChanged(DGrid, e)

    End Sub

#End Region

    Sub Limpia_Campos(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Text = ""
            If objeto.GetType.Name = "NumericUpDown" Then
                objeto.Text = 0
            End If
        Next objeto
    End Sub

    Function SiVacio(ByVal ParamArray Objetos() As Object) As Boolean
        Dim objeto As Object
        For Each objeto In Objetos
            If objeto.Text = "" Then
                Return False
            End If
        Next objeto
        Return True
    End Function

    Sub Limpia_control(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.TxtText = ""
        Next objeto
    End Sub

    Sub Inactivos(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Enabled = False
        Next objeto
    End Sub
    Sub Activos(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Enabled = True
        Next objeto
    End Sub
    Sub Oculta(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Visible = False
        Next objeto
    End Sub
    Sub Muestra(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Visible = True
        Next objeto
    End Sub
    Sub Bloqueo(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Locked = True
        Next objeto
    End Sub
    Sub DesBloqueo(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Locked = False
        Next objeto
    End Sub
    Public Sub Checador(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.checked = False
        Next objeto
    End Sub

#Region "  Tabla_Color(ts1 As DataGridTableStyle, grid As DataGrid), Metodos y Procesos"

    Public Sub Tabla_Color(ByVal ts1 As DataGridTableStyle, ByVal grid As DataGrid)
        ts1.SelectionForeColor = Color.White
        ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderForeColor = Color.White
        ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
        ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)
        grid.BorderStyle = BorderStyle.Fixed3D
        grid.FlatMode = True
        grid.RowHeaderWidth = 18

    End Sub

#End Region

#Region " ExpotaExcel, Metodos y Procesos"

#Region " ExpotaExcel - DataTableToExcel(pDataTable), Metodos y Procesos"

    Public Sub DataTableToExcel(ByVal pDataTable As DataTable)

        Dim vFileName As String = Path.GetTempFileName()

        FileOpen(1, vFileName, OpenMode.Output)

        Dim sb As String
        Dim dc As DataColumn
        For Each dc In pDataTable.Columns
            sb &= dc.Caption & Microsoft.VisualBasic.ControlChars.Tab
        Next

        PrintLine(1, sb)

        Dim i As Integer = 0
        Dim dr As DataRow
        For Each dr In pDataTable.Rows
            i = 0 : sb = ""
            For Each dc In pDataTable.Columns
                If Not IsDBNull(dr(i)) Then
                    sb &= CStr(dr(i)) & Microsoft.VisualBasic.ControlChars.Tab
                Else
                    sb &= Microsoft.VisualBasic.ControlChars.Tab
                End If
                i += 1
            Next

            PrintLine(1, sb)
        Next

        FileClose(1)
        TextToExcel(vFileName)

    End Sub

#End Region

#Region " ExpotaExcel - TextToExcel(pFileName), Metodos y Procesos"

    Public Sub TextToExcel(ByVal pFileName As String)

        Dim vFormato As Excel.XlRangeAutoFormat

        Dim vCultura As System.Globalization.CultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture

        'Es importante definirle la cultura al sistema
        'ya que podria generar errores
        System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US")

        Dim Exc As Excel.Application = New Excel.Application
        Exc.Workbooks.OpenText(pFileName, , , , Excel.XlTextQualifier.xlTextQualifierNone, , True)

        Dim Wb As Excel.Workbook = Exc.ActiveWorkbook
        Dim Ws As Excel.Worksheet = Wb.ActiveSheet

        Dim valor As Integer = 1


        vFormato = Excel.XlRangeAutoFormat.xlRangeAutoFormatList2

        Ws.Range(Ws.Cells(1, 1), Ws.Cells(Ws.UsedRange.Rows.Count, Ws.UsedRange.Columns.Count)).AutoFormat(vFormato)
        pFileName = Path.GetTempFileName.Replace("tmp", "xls")
        File.Delete(pFileName)
        Exc.ActiveWorkbook.SaveAs(pFileName, _
          Excel.XlTextQualifier.xlTextQualifierNone - 1)

        Exc.Quit()

        Ws = Nothing
        Wb = Nothing
        Exc = Nothing

        GC.Collect()
        If valor > -1 Then


            Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
            p.EnableRaisingEvents = False
            p.Start("Excel.exe", pFileName)
            p.Dispose()

        End If
        System.Threading.Thread.CurrentThread.CurrentCulture = vCultura
    End Sub

#End Region

#End Region



End Module
