Public Class frmusers
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents txtPass As System.Windows.Forms.TextBox
    Friend WithEvents chkmostrar As System.Windows.Forms.CheckBox
    Friend WithEvents cbousuarios As System.Windows.Forms.ComboBox
    Friend WithEvents cboGrupos As System.Windows.Forms.ComboBox
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmusers))
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.cbousuarios = New System.Windows.Forms.ComboBox
        Me.cboGrupos = New System.Windows.Forms.ComboBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.txtPass = New System.Windows.Forms.TextBox
        Me.chkmostrar = New System.Windows.Forms.CheckBox
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Usuarios"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Grupos"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Contrase�a"
        '
        'cbousuarios
        '
        Me.cbousuarios.Location = New System.Drawing.Point(80, 16)
        Me.cbousuarios.Name = "cbousuarios"
        Me.cbousuarios.Size = New System.Drawing.Size(352, 21)
        Me.cbousuarios.TabIndex = 3
        '
        'cboGrupos
        '
        Me.cboGrupos.Location = New System.Drawing.Point(80, 48)
        Me.cboGrupos.Name = "cboGrupos"
        Me.cboGrupos.Size = New System.Drawing.Size(176, 21)
        Me.cboGrupos.TabIndex = 4
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton5, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton4})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 120)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(440, 62)
        Me.tlbBotonera.TabIndex = 5
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.Text = "Agregar"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 2
        Me.ToolBarButton2.Text = "Guardar"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 5
        Me.ToolBarButton3.Text = "Eliminar"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 3
        Me.ToolBarButton4.Text = "Deshacer"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'txtPass
        '
        Me.txtPass.Location = New System.Drawing.Point(80, 80)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Microsoft.VisualBasic.ChrW(35)
        Me.txtPass.Size = New System.Drawing.Size(216, 20)
        Me.txtPass.TabIndex = 6
        Me.txtPass.Text = ""
        '
        'chkmostrar
        '
        Me.chkmostrar.Location = New System.Drawing.Point(312, 80)
        Me.chkmostrar.Name = "chkmostrar"
        Me.chkmostrar.TabIndex = 7
        Me.chkmostrar.Text = "Mostrar Pass"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 1
        Me.ToolBarButton5.Text = "Editar"
        '
        'frmusers
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 182)
        Me.Controls.Add(Me.chkmostrar)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.cboGrupos)
        Me.Controls.Add(Me.cbousuarios)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmusers"
        Me.Text = "Usuarios"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private ObjEmpleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Public objGruposAdmin As New ClsGruposAdmin.ClsGruposAdmin(2, gUsuario, gPasswordSql)

    Private Sub frmusers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        objGruposAdmin.Id_Sistema = 16
        objGruposAdmin.Bandera = 4
        objGruposAdmin.LlenaCombo(cboGrupos)

        ObjEmpleados.Bandera = 6
        ObjEmpleados.ListaCombo(cbousuarios)

    End Sub

    Private Sub cbousuarios_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbousuarios.SelectedIndexChanged
        buscar()
    End Sub
    Private Sub buscar()
        objGruposAdmin.Bandera = 10
        objGruposAdmin.ID_Usuario = cbousuarios.SelectedValue
        objGruposAdmin.Buscar()

        cboGrupos.SelectedValue = objGruposAdmin.Id_Grupo
        txtPass.Text = objGruposAdmin.Pass
    End Sub

    Private Sub chkmostrar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkmostrar.CheckedChanged
        If chkmostrar.Checked Then
            txtPass.PasswordChar = ""
        Else
            txtPass.PasswordChar = "#"
        End If
    End Sub
End Class
