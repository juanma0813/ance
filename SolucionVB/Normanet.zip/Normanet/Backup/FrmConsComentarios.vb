
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections
Imports Microsoft.Office.Interop

Public Class FrmConsComentarios
    Inherits System.Windows.Forms.Form

#Region " Inicializaci�n de   Dll's"

    Dim objComentarios As New clsComentarios.C_Comentarios("Principal", gUsuario, gPasswordSql)
    Private ObjTreeView As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Private ObjTiposTema As New ClsTipos_tema.C_Tipos_Tema(0, gUsuario, gPasswordSql) 'Esta clase habilita el tipo de tema de los catalagos
    Private ObjTiposProceso As New ClsTiposProceso.C_Tipo_Proceso(0, gUsuario, gPasswordSql)
    Private ObjEmpleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private objRevision As New ClsRevision_Normas.C_Revision_Normas(0, gUsuario, gPasswordSql)
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private objEtapas As New ClsEtapas.C_Etapas(0, gUsuario, gPasswordSql)

#End Region

    Dim dTimpresion As DataTable
    Dim Splan As String
    Dim stema As String

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdBuscar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdImprimir As System.Windows.Forms.ToolBarButton
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents tvPNN As System.Windows.Forms.TreeView
    Friend WithEvents Chkflim As System.Windows.Forms.CheckBox
    Friend WithEvents DTPF1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPF2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DGresultados As System.Windows.Forms.DataGrid
    Friend WithEvents ChktipProc As System.Windows.Forms.CheckBox
    Friend WithEvents Cboproceso As System.Windows.Forms.ComboBox
    Friend WithEvents Cbotipocom As System.Windows.Forms.ComboBox
    Friend WithEvents ChktipCom As System.Windows.Forms.CheckBox
    Friend WithEvents LblPlan As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents Chkfcom As System.Windows.Forms.CheckBox
    Friend WithEvents DTPF4 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPF3 As System.Windows.Forms.DateTimePicker
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmConsComentarios))
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdBuscar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdImprimir = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.DTPF1 = New System.Windows.Forms.DateTimePicker
        Me.DTPF2 = New System.Windows.Forms.DateTimePicker
        Me.Chkflim = New System.Windows.Forms.CheckBox
        Me.ChktipProc = New System.Windows.Forms.CheckBox
        Me.Cboproceso = New System.Windows.Forms.ComboBox
        Me.DGresultados = New System.Windows.Forms.DataGrid
        Me.TxtTotal = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.tvPNN = New System.Windows.Forms.TreeView
        Me.Cbotipocom = New System.Windows.Forms.ComboBox
        Me.ChktipCom = New System.Windows.Forms.CheckBox
        Me.LblPlan = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.Chkfcom = New System.Windows.Forms.CheckBox
        Me.DTPF4 = New System.Windows.Forms.DateTimePicker
        Me.DTPF3 = New System.Windows.Forms.DateTimePicker
        CType(Me.DGresultados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdBuscar, Me.CmdDeshacer, Me.CmdImprimir, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 538)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(1058, 62)
        Me.tlbBotonera.TabIndex = 192
        '
        'cmdBuscar
        '
        Me.cmdBuscar.ImageIndex = 6
        Me.cmdBuscar.Text = "Buscar"
        Me.cmdBuscar.ToolTipText = "Realiza Busquedas"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 2
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.ImageIndex = 7
        Me.CmdImprimir.Text = "Imprimir"
        Me.CmdImprimir.ToolTipText = "Imprimir Consulta"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 5
        Me.CmdSalir.Text = "Salir"
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(470, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 16)
        Me.Label1.TabIndex = 193
        Me.Label1.Text = "Fecha Inicial:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(614, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 16)
        Me.Label2.TabIndex = 194
        Me.Label2.Text = "Fecha Final:"
        '
        'DTPF1
        '
        Me.DTPF1.CustomFormat = "dd/MM/yyyy"
        Me.DTPF1.Enabled = False
        Me.DTPF1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPF1.Location = New System.Drawing.Point(460, 30)
        Me.DTPF1.Name = "DTPF1"
        Me.DTPF1.Size = New System.Drawing.Size(105, 20)
        Me.DTPF1.TabIndex = 195
        '
        'DTPF2
        '
        Me.DTPF2.CustomFormat = "dd/MM/yyyy"
        Me.DTPF2.Enabled = False
        Me.DTPF2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPF2.Location = New System.Drawing.Point(600, 30)
        Me.DTPF2.Name = "DTPF2"
        Me.DTPF2.Size = New System.Drawing.Size(106, 20)
        Me.DTPF2.TabIndex = 196
        '
        'Chkflim
        '
        Me.Chkflim.Location = New System.Drawing.Point(269, 26)
        Me.Chkflim.Name = "Chkflim"
        Me.Chkflim.Size = New System.Drawing.Size(182, 28)
        Me.Chkflim.TabIndex = 200
        Me.Chkflim.Text = "Por Fecha L�mite de Comentario"
        '
        'ChktipProc
        '
        Me.ChktipProc.Location = New System.Drawing.Point(10, 477)
        Me.ChktipProc.Name = "ChktipProc"
        Me.ChktipProc.Size = New System.Drawing.Size(192, 24)
        Me.ChktipProc.TabIndex = 201
        Me.ChktipProc.Text = "Por Tipo de Proceso"
        '
        'Cboproceso
        '
        Me.Cboproceso.Enabled = False
        Me.Cboproceso.ItemHeight = 14
        Me.Cboproceso.Items.AddRange(New Object() {"Proceso Normal", "Proceso Alternativo"})
        Me.Cboproceso.Location = New System.Drawing.Point(10, 503)
        Me.Cboproceso.Name = "Cboproceso"
        Me.Cboproceso.Size = New System.Drawing.Size(230, 22)
        Me.Cboproceso.TabIndex = 202
        '
        'DGresultados
        '
        Me.DGresultados.CaptionVisible = False
        Me.DGresultados.DataMember = ""
        Me.DGresultados.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DGresultados.Location = New System.Drawing.Point(269, 156)
        Me.DGresultados.Name = "DGresultados"
        Me.DGresultados.Size = New System.Drawing.Size(777, 338)
        Me.DGresultados.TabIndex = 203
        '
        'TxtTotal
        '
        Me.TxtTotal.Enabled = False
        Me.TxtTotal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TxtTotal.Location = New System.Drawing.Point(902, 503)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(144, 20)
        Me.TxtTotal.TabIndex = 205
        Me.TxtTotal.Text = ""
        Me.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Label3.Location = New System.Drawing.Point(835, 511)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 16)
        Me.Label3.TabIndex = 204
        Me.Label3.Text = "Total:"
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'tvPNN
        '
        Me.tvPNN.ImageIndex = 2
        Me.tvPNN.ImageList = Me.imgListTreeView
        Me.tvPNN.Location = New System.Drawing.Point(10, 52)
        Me.tvPNN.Name = "tvPNN"
        Me.tvPNN.SelectedImageIndex = 2
        Me.tvPNN.Size = New System.Drawing.Size(230, 416)
        Me.tvPNN.TabIndex = 206
        '
        'Cbotipocom
        '
        Me.Cbotipocom.Enabled = False
        Me.Cbotipocom.ItemHeight = 14
        Me.Cbotipocom.Location = New System.Drawing.Point(461, 121)
        Me.Cbotipocom.Name = "Cbotipocom"
        Me.Cbotipocom.Size = New System.Drawing.Size(269, 22)
        Me.Cbotipocom.TabIndex = 208
        '
        'ChktipCom
        '
        Me.ChktipCom.Location = New System.Drawing.Point(269, 121)
        Me.ChktipCom.Name = "ChktipCom"
        Me.ChktipCom.Size = New System.Drawing.Size(192, 24)
        Me.ChktipCom.TabIndex = 207
        Me.ChktipCom.Text = "Por Tipo de comentario"
        '
        'LblPlan
        '
        Me.LblPlan.AutoSize = True
        Me.LblPlan.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPlan.Location = New System.Drawing.Point(10, 9)
        Me.LblPlan.Name = "LblPlan"
        Me.LblPlan.Size = New System.Drawing.Size(117, 16)
        Me.LblPlan.TabIndex = 210
        Me.LblPlan.Text = "Tema Seleccionado: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblTreeView.Location = New System.Drawing.Point(19, 26)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 15)
        Me.LblTreeView.TabIndex = 209
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Chkfcom
        '
        Me.Chkfcom.Location = New System.Drawing.Point(269, 69)
        Me.Chkfcom.Name = "Chkfcom"
        Me.Chkfcom.Size = New System.Drawing.Size(182, 29)
        Me.Chkfcom.TabIndex = 215
        Me.Chkfcom.Text = "Por Fecha de Comentario"
        '
        'DTPF4
        '
        Me.DTPF4.CustomFormat = "dd/MM/yyyy"
        Me.DTPF4.Enabled = False
        Me.DTPF4.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPF4.Location = New System.Drawing.Point(600, 74)
        Me.DTPF4.Name = "DTPF4"
        Me.DTPF4.Size = New System.Drawing.Size(106, 20)
        Me.DTPF4.TabIndex = 214
        '
        'DTPF3
        '
        Me.DTPF3.CustomFormat = "dd/MM/yyyy"
        Me.DTPF3.Enabled = False
        Me.DTPF3.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPF3.Location = New System.Drawing.Point(460, 74)
        Me.DTPF3.Name = "DTPF3"
        Me.DTPF3.Size = New System.Drawing.Size(105, 20)
        Me.DTPF3.TabIndex = 213
        '
        'FrmConsComentarios
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 13)
        Me.ClientSize = New System.Drawing.Size(1058, 600)
        Me.Controls.Add(Me.Chkfcom)
        Me.Controls.Add(Me.DTPF4)
        Me.Controls.Add(Me.DTPF3)
        Me.Controls.Add(Me.LblPlan)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.Cbotipocom)
        Me.Controls.Add(Me.ChktipCom)
        Me.Controls.Add(Me.tvPNN)
        Me.Controls.Add(Me.TxtTotal)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DGresultados)
        Me.Controls.Add(Me.Cboproceso)
        Me.Controls.Add(Me.ChktipProc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Chkflim)
        Me.Controls.Add(Me.DTPF2)
        Me.Controls.Add(Me.DTPF1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Font = New System.Drawing.Font("Arial", 8.259!, System.Drawing.FontStyle.Bold)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmConsComentarios"
        Me.Text = "Consulta de Comentarios"
        CType(Me.DGresultados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " CheckBox, Metodos y Procesos"

#Region " CheckBox - Chkfcom, Metodos y Procesos"

#Region " Chkfcom - Chkfcom_CheckedChanged, Metodos y Procesos"

    Private Sub Chkfcom_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chkfcom.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        Call LimpiaDG()
        If Chkfcom.Checked Then
            Activos(DTPF3, DTPF4)
            Inactivos(Chkflim)
            DTPF3.ResetText() : DTPF4.ResetText()
        Else
            Activos(Chkflim)
            Inactivos(DTPF3, DTPF4)
            DTPF2.ResetText()
            DTPF1.ResetText()
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Chkfcom - Chkfcom_EnabledChanged, Metodos y Procesos"

    Private Sub Chkfcom_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Chkfcom.EnabledChanged
        Chkfcom.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - Chkflim, Metodos y Procesos"

#Region " Chkflim - Chkflim_CheckedChanged, Metodos y Procesos"

    Private Sub Chkflim_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chkflim.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        Call LimpiaDG()
        If Chkflim.Checked Then
            Activos(DTPF1, DTPF2)
            Inactivos(Chkfcom)
            DTPF1.ResetText() : DTPF2.ResetText()
        Else
            Activos(Chkfcom)
            Inactivos(DTPF1, DTPF2)
            DTPF2.ResetText()
            DTPF1.ResetText()
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Chkflim - Chkflim_EnabledChanged, Metodos y Procesos"

    Private Sub Chkflim_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Chkflim.EnabledChanged
        Chkflim.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - Chktipcom, Metodos y Procesos"

#Region " Chktipcom - Chktipcom_CheckedChanged, Metodos y Procesos"

    Private Sub Chktipcom_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChktipCom.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        Call LimpiaDG()
        If ChktipCom.Checked Then
            Activos(Cbotipocom)
        Else
            Inactivos(Cbotipocom)
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Chktipcom - Chktipcom_EnabledChanged, Metodos y Procesos"

    Private Sub Chktipcom_EnabledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChktipCom.EnabledChanged
        ChktipCom.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - ChktipProc, Metodos y Procesos"

#Region " ChktipProc - ChktipProc_CheckedChanged, Metodos y Procesos"

    Private Sub ChktipProc_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChktipProc.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        Call LimpiaDG()
        If ChktipProc.Checked Then
            Activos(Cboproceso)
        Else
            Inactivos(Cboproceso)
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " ChktipProc - ChktipProc_EnabledChanged, Metodos y Procesos"

    Private Sub ChktipProc_EnabledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChktipProc.EnabledChanged
        ChktipProc.Checked = False
    End Sub

#End Region

#End Region

#End Region

#Region " Datagrid - DGResultados, Metodos y Procesos"

#Region " DGResultados - LimpiaDG, Metodos y Procesos"

    Private Sub LimpiaDG()
        Try
            Dim dtresultados As DataTable
            dtresultados = DGresultados.DataSource
            dtresultados.Rows.Clear()
            DGresultados.DataSource = dtresultados
            dTimpresion = dtresultados
            Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2))
        Catch ex As Exception

        End Try
    End Sub

#End Region

#Region " DGResultados - DGReStyle, Metodos y Procesos"

    Private Sub DGReStyle()
        Dim dtcol As DataColumn = Nothing
        Try
            DGresultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGresultados)

            ts1.MappingName = "PNN"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Comentario"
            TextCol.HeaderText = "Comentario"
            TextCol.Width = 60
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Fecha_Comentario"
            TextCol1.HeaderText = "Fecha"
            TextCol1.Width = 65
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Tema"
            TextCol2.HeaderText = "Temas"
            TextCol2.Width = 130
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Nombre"
            TextCol3.HeaderText = "Participante"
            TextCol3.Width = 140
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Empresa"
            TextCol4.HeaderText = "Empresa"
            TextCol4.Width = 100
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "Comentarios"
            TextCol5.HeaderText = "Comentario"
            TextCol5.TextBox.Multiline = True
            TextCol5.Width = 130
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "Parrafotablafigura"
            TextCol6.HeaderText = "Referencia"
            TextCol6.Width = 60
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "Propuesta_cambios"
            TextCol7.HeaderText = "Cambios Propuestos"
            TextCol7.TextBox.Multiline = True
            TextCol7.Width = 130
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol9 As New DataGridTextBoxColumn
            TextCol9.MappingName = "Respuesta"
            TextCol9.HeaderText = "Fecha Respuesta"
            TextCol9.TextBox.Multiline = True
            TextCol9.Width = 100
            TextCol9.TextBox.Enabled = False
            'ts1.GridColumnStyles.Add(TextCol9)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "F_Aprobacion_Resolucion_ComentarioPublico"
            TextCol8.HeaderText = "Fecha Resoluci�n"
            TextCol8.Width = 100
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)

            Dim TextCol10 As New DataGridTextBoxColumn
            TextCol10.MappingName = "Resolucion"
            TextCol10.HeaderText = "Resoluci�n"
            TextCol10.Width = 120
            TextCol10.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol10)

            Dim TextCol11 As New DataGridTextBoxColumn
            TextCol11.MappingName = "tipo_comentario"
            TextCol11.HeaderText = "Tipo Comentarios"
            TextCol11.Width = 120
            TextCol11.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol11)

            ts1.PreferredRowHeight = TextCol1.TextBox.Height * 2

            DGresultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#End Region

#Region " DateTimePicker, Metodos y Procesos"

#Region " DateTimePicker - DTPF1, Metodos y Procesos"

    Private Sub DTPF1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPF1.ValueChanged
        ErrorProvider1.SetError(Chkflim, "")
    End Sub

#End Region

#Region " DateTimePicker - DTPF2, Metodos y Procesos"

    Private Sub DTPF2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPF2.ValueChanged
        ErrorProvider1.SetError(Chkflim, "")
    End Sub

#End Region

#Region " DateTimePicker - DTPF3, Metodos y Procesos"

    Private Sub DTPF3_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPF3.ValueChanged
        ErrorProvider1.SetError(Chkfcom, "")
    End Sub

#End Region

#Region " DateTimePicker - DTPF4, Metodos y Procesos"

    Private Sub DTPF4_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPF4.ValueChanged
        ErrorProvider1.SetError(Chkfcom, "")
    End Sub

#End Region

#End Region

#Region " Forms - FrmConsComentarios, Metodos y Procesos"

    Private Sub FrmConsComentarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Llena_Plan()
        Call Llena_Cbotipocom()
        Call buscar()
        Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2))
    End Sub

#End Region

#Region " -i- Metodos y Procesos -i- "

#Region " Sub - buscar(), Metodos y Procesos"

    Private Sub buscar()
        Dim dtresultados As DataTable
        Dim spro As Integer = 4
        Dim sf1, sf2 As String
        Dim stipcom As String = Nothing
        If ChktipProc.Checked Then If Cboproceso.Text = "Proceso Alternativo" Then spro = 2
        If ChktipCom.Checked Then If Cbotipocom.SelectedValue <> Nothing Then stipcom = Cbotipocom.SelectedValue
        If Splan <> "" Then
            objComentarios.Bandera = 40
            objComentarios.Id_Plan = Splan
            objComentarios.Id_Tema = stema
            objComentarios.Id_Etapa = spro
            objComentarios.Tipo_comentario = stipcom
            If Chkflim.Checked Then
                If DTPF1.Value < DTPF2.Value Then
                    objComentarios.Fecha_inicio = DTPF1.Text
                    objComentarios.Fecha_Fin = DTPF2.Text
                    objComentarios.Tipo_Fecha = 1
                Else
                    MessageBox.Show("El rango de fechas en el criterio de Fecha de Limite de Publicaci�n de Comentarios")
                    ErrorProvider1.SetError(Chkflim, "El rango de fechas en el criterio de Fecha de Limite de Publicaci�n de Comentarios")
                End If
            Else
                objComentarios.Tipo_Fecha = Nothing
                objComentarios.Fecha_inicio = Nothing
                objComentarios.Fecha_Fin = Nothing

                If Chkfcom.Checked Then
                    If DTPF3.Value < DTPF4.Value Then
                        objComentarios.Fecha_inicio = DTPF3.Text
                        objComentarios.Fecha_Fin = DTPF4.Text
                        objComentarios.Tipo_Fecha = 2
                    Else
                        MessageBox.Show("El rango de fechas en el criterio de Fecha de Comentarios")
                        ErrorProvider1.SetError(Chkfcom, "El rango de fechas en el criterio de Fecha de Comentarios")
                    End If
                Else
                    objComentarios.Tipo_Fecha = Nothing
                    objComentarios.Fecha_inicio = Nothing
                    objComentarios.Fecha_Fin = Nothing
                End If
            End If

            dtresultados = objComentarios.Buscar_PNN
            If dtresultados.Rows.Count > 0 Then
                Dim dr As DataRow
                For Each dr In dtresultados.Rows
                    dr(0) = "Com" + Format(CInt(dr(0)), "0000")
                Next
                Dim cm As CurrencyManager
                cm = CType(BindingContext(dtresultados), CurrencyManager)
                Dim Dv As DataView = CType(cm.List, DataView)
                Dv.AllowNew = False
                Dv.AllowEdit = False
                Dv.AllowDelete = False
                Call DGReStyle()
                DGresultados.DataSource = dtresultados
                dTimpresion = dtresultados
                Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2))
            Else
                Call LimpiaDG()
            End If
            TxtTotal.Text = dtresultados.Rows.Count
        End If
    End Sub

#End Region

#Region " Sub - Llena_Cbotipocom(), Metodos y Procesos"

    Private Sub Llena_Cbotipocom()
        objComentarios.Bandera = 6
        objComentarios.ListaCombo(Cbotipocom)
    End Sub

#End Region

#End Region

#Region " tlbBotonera - tlbBotonera_ButtonClick, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        ErrorProvider1.SetError(Chkflim, "")
        ErrorProvider1.SetError(Chkfcom, "")
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0
                Call buscar()
            Case 1
                tvPNN.Refresh()
                Call LimpiaDG()
            Case 2
                DataTableToExcel(CType(dTimpresion, DataTable))
            Case 4
                Me.Dispose()
        End Select

    End Sub

#End Region

#Region " TreeView - TVPNN, Metodos y Procesos"

#Region " TVPNN - TVPNN_AfterSelect, Metodos y Procesos"

    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvPNN.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        Dim svariable As String
        Dim array_texto As Array
        svariable = e.Node.FullPath
        array_texto = Split(svariable, "\")
        Select Case array_texto.Length
            Case 2
                stema = Nothing
                Splan = array_texto(1)
                LblTreeView.Text = Splan
            Case 3
                Splan = array_texto(1)
                stema = array_texto(2)
                LblTreeView.Text = Splan & " - " & stema
            Case Else
                LblTreeView.Text = Nothing
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " TVPNN - Llena_Plan, Metodos y Procesos"

    Sub Llena_Plan()
        Cursor.Current = Cursors.WaitCursor
        Dim nodo As New TreeNode
        Dim nodo1 As New TreeNode
        Dim oTablaPNN As DataTable
        Dim oTablaDPy As DataTable
        Dim RegPNN As DataRow
        Dim RegDPy As DataRow
        oTablaPNN = ObjTreeView.ListaPNN("")
        tvPNN.BeginUpdate()
        nodo = tvPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = ObjTreeView.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.SelectedImageIndex = 5
                nodo1.ImageIndex = 5
            Next
        Next
        tvPNN.EndUpdate()
        tvPNN.AllowDrop = False
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

End Class
