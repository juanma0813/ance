Public Class Frm_inspeccion_Pruebas
    Inherits System.Windows.Forms.Form

    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Private objInspeccionPrueba As New ClsInspeccionPruebas.ClsInspeccionPruebas(0, gUsuario, gPasswordSql)
    Dim oTablaPNN As DataTable
    Dim nodo As New TreeNode
    Dim RegPNN As DataRow
    Dim oTablaDPy As DataTable
    Dim RegDPy As DataRow
    Dim nodo1 As New TreeNode
    Dim Matriz As Array
    Dim svariable As String
    Dim sPlan As String
    Dim stema As String
    Dim sraiz As String

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Grdinspeccion As System.Windows.Forms.DataGrid
    Friend WithEvents TlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents TvInspeccion As System.Windows.Forms.TreeView
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImListTV As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Frm_inspeccion_Pruebas))
        Me.TvInspeccion = New System.Windows.Forms.TreeView
        Me.ImListTV = New System.Windows.Forms.ImageList(Me.components)
        Me.Grdinspeccion = New System.Windows.Forms.DataGrid
        Me.TlbBotonera = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.Grdinspeccion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TvInspeccion
        '
        Me.TvInspeccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TvInspeccion.ImageIndex = 2
        Me.TvInspeccion.ImageList = Me.ImListTV
        Me.TvInspeccion.Location = New System.Drawing.Point(8, 8)
        Me.TvInspeccion.Name = "TvInspeccion"
        Me.TvInspeccion.SelectedImageIndex = 2
        Me.TvInspeccion.Size = New System.Drawing.Size(168, 168)
        Me.TvInspeccion.TabIndex = 0
        '
        'ImListTV
        '
        Me.ImListTV.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImListTV.ImageSize = New System.Drawing.Size(17, 17)
        Me.ImListTV.ImageStream = CType(resources.GetObject("ImListTV.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImListTV.TransparentColor = System.Drawing.Color.Transparent
        '
        'Grdinspeccion
        '
        Me.Grdinspeccion.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Grdinspeccion.DataMember = ""
        Me.Grdinspeccion.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.Grdinspeccion.Location = New System.Drawing.Point(184, 8)
        Me.Grdinspeccion.Name = "Grdinspeccion"
        Me.Grdinspeccion.ReadOnly = True
        Me.Grdinspeccion.Size = New System.Drawing.Size(512, 168)
        Me.Grdinspeccion.TabIndex = 1
        '
        'TlbBotonera
        '
        Me.TlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2})
        Me.TlbBotonera.ButtonSize = New System.Drawing.Size(56, 56)
        Me.TlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TlbBotonera.DropDownArrows = True
        Me.TlbBotonera.ImageList = Me.ImageList1
        Me.TlbBotonera.Location = New System.Drawing.Point(0, 192)
        Me.TlbBotonera.Name = "TlbBotonera"
        Me.TlbBotonera.ShowToolTips = True
        Me.TlbBotonera.Size = New System.Drawing.Size(704, 62)
        Me.TlbBotonera.TabIndex = 2
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 1
        Me.ToolBarButton1.Text = "Exportar"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 0
        Me.ToolBarButton2.Text = "Salir"
        '
        'ImageList1
        '
        Me.ImageList1.ImageSize = New System.Drawing.Size(36, 36)
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'Frm_inspeccion_Pruebas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(704, 254)
        Me.Controls.Add(Me.TlbBotonera)
        Me.Controls.Add(Me.Grdinspeccion)
        Me.Controls.Add(Me.TvInspeccion)
        Me.Name = "Frm_inspeccion_Pruebas"
        Me.Text = "Inspeccion y pruebas"
        CType(Me.Grdinspeccion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Frm_inspeccion_Pruebas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LlenaTV()
    End Sub
    Private Sub LlenaTV()
        oTablaPNN = x.ListaPNN("")
        TvInspeccion.BeginUpdate()
        nodo = TvInspeccion.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = TvInspeccion.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = x.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.SelectedImageIndex = 5
                nodo1.ImageIndex = 5
            Next
        Next
        TvInspeccion.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TvInspeccion.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TvInspeccion.Sorted = True
        'PnlLectura.Visible = True
        'PnlAgrega.Visible = False
    End Sub
    Private Sub DGReStyle()
        Dim dtcol As DataColumn = Nothing
        Try
            Grdinspeccion.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, Grdinspeccion)

            ts1.MappingName = "ClsInspeccionPruebas"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Tema"
            TextCol.HeaderText = "Tema"
            TextCol.Width = 50
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Titulo"
            TextCol1.HeaderText = "Titulo"
            TextCol1.Width = 350
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "E1_1"
            TextCol2.HeaderText = "E1 1 (GN)"
            TextCol2.Width = 80
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "E1_2"
            TextCol3.HeaderText = "E1 2 (GN)"
            TextCol3.Width = 80
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "E2_1"
            TextCol4.HeaderText = "E2 1 (RD)"
            TextCol4.Width = 80
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "E2_2"
            TextCol5.HeaderText = "E2 2 (RD)"
            TextCol5.TextBox.Multiline = True
            TextCol5.Width = 80
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "E2_3"
            TextCol6.HeaderText = "E2 3 (RD)"
            TextCol6.Width = 80
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "E2_4"
            TextCol7.HeaderText = "E2 4 (RD)"
            TextCol7.TextBox.Multiline = True
            TextCol7.Width = 80
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "E2_5"
            TextCol8.HeaderText = "E2 5 (RD)"
            TextCol8.TextBox.Multiline = True
            TextCol8.Width = 80
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)

            'e3
            Dim TextCol9 As New DataGridTextBoxColumn
            TextCol9.MappingName = "E3_1"
            TextCol9.HeaderText = "E3 1 (GN)"
            TextCol9.TextBox.Multiline = True
            TextCol9.Width = 80
            TextCol9.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol9)

            Dim TextCol10 As New DataGridTextBoxColumn
            TextCol10.MappingName = "E3_2"
            TextCol10.HeaderText = "E3 2 (GN)"
            TextCol10.TextBox.Multiline = True
            TextCol10.Width = 80
            TextCol10.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol10)

            Dim TextCol11 As New DataGridTextBoxColumn
            TextCol11.MappingName = "E3_3"
            TextCol11.HeaderText = "E3 3 (GN)"
            TextCol11.TextBox.Multiline = True
            TextCol11.Width = 80
            TextCol11.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol11)

            'E4
            Dim TextCol12 As New DataGridTextBoxColumn
            TextCol12.MappingName = "E4_1"
            TextCol12.HeaderText = "E4 1 (RD)"
            TextCol12.TextBox.Multiline = True
            TextCol12.Width = 80
            TextCol12.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol12)

            Dim TextCol13 As New DataGridTextBoxColumn
            TextCol13.MappingName = "E4_2"
            TextCol13.HeaderText = "E4 2 (ATL)"
            TextCol13.TextBox.Multiline = True
            TextCol13.Width = 80
            TextCol13.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol13)

            Dim TextCol14 As New DataGridTextBoxColumn
            TextCol14.MappingName = "E4_3"
            TextCol14.HeaderText = "E4 3 (ATL)"
            TextCol14.TextBox.Multiline = True
            TextCol14.Width = 80
            TextCol14.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol14)

            Dim TextCol15 As New DataGridTextBoxColumn
            TextCol15.MappingName = "E4_4"
            TextCol15.HeaderText = "E4 4 (GN)"
            TextCol15.TextBox.Multiline = True
            TextCol15.Width = 80
            TextCol15.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol15)

            'E5
            Dim TextCol16 As New DataGridTextBoxColumn
            TextCol16.MappingName = "E5_1"
            TextCol16.HeaderText = "E5 1 (GN)"
            TextCol16.TextBox.Multiline = True
            TextCol16.Width = 80
            TextCol16.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol16)

            'E6
            Dim TextCol17 As New DataGridTextBoxColumn
            TextCol17.MappingName = "E6_1"
            TextCol17.HeaderText = "E6 1 (RD)"
            TextCol17.TextBox.Multiline = True
            TextCol17.Width = 80
            TextCol17.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol17)

            Dim TextCol18 As New DataGridTextBoxColumn
            TextCol18.MappingName = "E6_2"
            TextCol18.HeaderText = "E6 2 (RD)"
            TextCol18.TextBox.Multiline = True
            TextCol18.Width = 80
            TextCol18.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol18)

            Dim TextCol19 As New DataGridTextBoxColumn
            TextCol19.MappingName = "E6_3"
            TextCol19.HeaderText = "E6 3 (RD)"
            TextCol19.TextBox.Multiline = True
            TextCol19.Width = 80
            TextCol19.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol19)

            Dim TextCol20 As New DataGridTextBoxColumn
            TextCol20.MappingName = "E6_4"
            TextCol20.HeaderText = "E6 4 (RD)"
            TextCol20.TextBox.Multiline = True
            TextCol20.Width = 80
            TextCol20.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol20)

            Dim TextCol21 As New DataGridTextBoxColumn
            TextCol21.MappingName = "E6_5"
            TextCol21.HeaderText = "E6 5 (RD)"
            TextCol21.TextBox.Multiline = True
            TextCol21.Width = 80
            TextCol21.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol21)

            Dim TextCol22 As New DataGridTextBoxColumn
            TextCol22.MappingName = "E6_6"
            TextCol22.HeaderText = "E6 6 (RD)"
            TextCol22.TextBox.Multiline = True
            TextCol22.Width = 80
            TextCol22.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol22)

            'E7
            Dim TextCol23 As New DataGridTextBoxColumn
            TextCol23.MappingName = "E7_1"
            TextCol23.HeaderText = "E7 1 (RD)"
            TextCol23.TextBox.Multiline = True
            TextCol23.Width = 80
            TextCol23.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol23)

            Dim TextCol24 As New DataGridTextBoxColumn
            TextCol24.MappingName = "E7_2"
            TextCol24.HeaderText = "E7 2 (GN)"
            TextCol24.TextBox.Multiline = True
            TextCol24.Width = 80
            TextCol24.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol24)

            Dim TextCol25 As New DataGridTextBoxColumn
            TextCol25.MappingName = "E7_3"
            TextCol25.HeaderText = "E7 3 (GN)"
            TextCol25.TextBox.Multiline = True
            TextCol25.Width = 80
            TextCol25.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol25)

            Dim TextCol26 As New DataGridTextBoxColumn
            TextCol26.MappingName = "E7_4"
            TextCol26.HeaderText = "E7 4 (GN)"
            TextCol26.TextBox.Multiline = True
            TextCol26.Width = 80
            TextCol26.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol26)

            Dim TextCol27 As New DataGridTextBoxColumn
            TextCol27.MappingName = "E7_5"
            TextCol27.HeaderText = "E7 5 (GN)"
            TextCol27.TextBox.Multiline = True
            TextCol27.Width = 80
            TextCol27.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol27)

            'E8

            Dim TextCol28 As New DataGridTextBoxColumn
            TextCol28.MappingName = "E8_1"
            TextCol28.HeaderText = "E8 1 (GN)"
            TextCol28.TextBox.Multiline = True
            TextCol28.Width = 80
            TextCol28.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol28)

            Dim TextCol29 As New DataGridTextBoxColumn
            TextCol29.MappingName = "E8_2"
            TextCol29.HeaderText = "E8 2 (GN)"
            TextCol29.TextBox.Multiline = True
            TextCol29.Width = 80
            TextCol29.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol29)

            'e9
            Dim TextCol30 As New DataGridTextBoxColumn
            TextCol30.MappingName = "E9_1"
            TextCol30.HeaderText = "E9 1 (GN)"
            TextCol30.TextBox.Multiline = True
            TextCol30.Width = 80
            TextCol30.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol30)

            Dim TextCol31 As New DataGridTextBoxColumn
            TextCol31.MappingName = "E9_2"
            TextCol31.HeaderText = "E9 2 (GN)"
            TextCol31.TextBox.Multiline = True
            TextCol31.Width = 80
            TextCol31.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol31)

            'E10
            Dim TextCol32 As New DataGridTextBoxColumn
            TextCol32.MappingName = "E10_1"
            TextCol32.HeaderText = "E10 1 (RD)"
            TextCol32.TextBox.Multiline = True
            TextCol32.Width = 80
            TextCol32.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol32)

            Dim TextCol33 As New DataGridTextBoxColumn
            TextCol33.MappingName = "E10_2"
            TextCol33.HeaderText = "E10 2 (GN)"
            TextCol33.TextBox.Multiline = True
            TextCol33.Width = 80
            TextCol33.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol33)

            Dim TextCol34 As New DataGridTextBoxColumn
            TextCol34.MappingName = "E10_3"
            TextCol34.HeaderText = "E10 3 (GN)"
            TextCol34.TextBox.Multiline = True
            TextCol34.Width = 80
            TextCol34.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol34)

            Dim TextCol35 As New DataGridTextBoxColumn
            TextCol35.MappingName = "E10_4"
            TextCol35.HeaderText = "E10 4 (GN)"
            TextCol35.TextBox.Multiline = True
            TextCol35.Width = 80
            TextCol35.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol35)

            'E11

            Dim TextCol36 As New DataGridTextBoxColumn
            TextCol36.MappingName = "E11_1"
            TextCol36.HeaderText = "E11 1 (RD)"
            TextCol36.TextBox.Multiline = True
            TextCol36.Width = 80
            TextCol36.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol36)

            Dim TextCol37 As New DataGridTextBoxColumn
            TextCol37.MappingName = "E11_2"
            TextCol37.HeaderText = "E11 2 (GN)"
            TextCol37.TextBox.Multiline = True
            TextCol37.Width = 80
            TextCol37.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol37)

            Dim TextCol38 As New DataGridTextBoxColumn
            TextCol38.MappingName = "E11_3"
            TextCol38.HeaderText = "E11 3 (GN)"
            TextCol38.TextBox.Multiline = True
            TextCol38.Width = 80
            TextCol38.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol38)

            Dim TextCol39 As New DataGridTextBoxColumn
            TextCol39.MappingName = "E11_4"
            TextCol39.HeaderText = "E11 4 (GN)"
            TextCol39.TextBox.Multiline = True
            TextCol39.Width = 80
            TextCol39.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol39)

            ts1.PreferredRowHeight = TextCol1.TextBox.Height ' para dar el alto a la fila
            Grdinspeccion.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

    Private Sub TlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles TlbBotonera.ButtonClick
        Select Case TlbBotonera.Buttons.IndexOf(e.Button)
            Case 0
                Exportar()
            Case 1
                Me.Dispose()
        End Select
    End Sub
    Private Sub Exportar()
        Dim ObjExportar As New ClsExcel.ClsExcel
        'Dt = Grdinspeccion.DataSource
        If Not Grdinspeccion.DataSource Is Nothing Then
            ObjExportar.DataTableToExcel(Grdinspeccion.DataSource)
            MsgBox("Datos exportados correctamente")
        Else
            MsgBox("Error al exportar datos")
        End If
    End Sub

    Private Sub TvInspeccion_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TvInspeccion.AfterSelect
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                stema = ""
                sPlan = ""
            Case 2
                sPlan = Matriz(1)
                stema = ""
                llenaGrid()
                DGReStyle()
            Case 3
                sPlan = Matriz(1)
                stema = Matriz(2)
                llenaGrid()
                DGReStyle()
        End Select

    End Sub
    Private Sub llenaGrid()
        If stema <> "" Then
            objInspeccionPrueba.Bandera = 5
        Else
            objInspeccionPrueba.Bandera = 6
        End If
        objInspeccionPrueba.ID_tema = stema
        objInspeccionPrueba.ID_Plan = sPlan
        Grdinspeccion.DataSource = objInspeccionPrueba.Lista()
    End Sub
End Class
