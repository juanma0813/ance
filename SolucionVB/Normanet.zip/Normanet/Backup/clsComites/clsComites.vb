Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class clsComites
    Dim cn As New SqlConnection
    Dim cmdAgregar As New SqlCommand
    Dim cmdActualizar As New SqlCommand
    Dim cmdBuscar As New SqlCommand
    Dim cmdBorrar As New SqlCommand
    Dim dsBuscar As New DataSet
    Dim sStatus As String
    'Dim objConexion As New clsConexionArchivo.clsConexionArchivo  '23/10/06
    Dim objconexion As New clsConexion.cIsConexion


    '''''''Declaracion de Variables Privadas
    Private dsC_Comite As New DataSet
    Private _ID_Comite As String
    Private _Descripcion As String
    Private _Responsable As String
    Private sSql As String
    Private _Bandera As System.Int32

    Private _ID_CT As String
    Private _Objetivo As String
    Private _ID_SC As String
    Private _ID_GT As String
    Private _ID_SGT As String
    Private _status As String
    Private _Inactivo As Boolean
    Public _Encontrado As Boolean
    Public _bandError As Boolean
    Dim statusBorrar As SqlParameter
    Private _statusProceso As Boolean


    '''''''Declaracion de Propiedades publicas
   Public Property Bandera()
        Get
            Return _Bandera
        End Get
        Set(ByVal Value)
            _Bandera = Value
        End Set
    End Property

    Public Property ID_Comite()
        Get
            Return _ID_Comite
        End Get
        Set(ByVal Value)
            _ID_Comite = Value
        End Set
    End Property

    Public Property Descripcion()
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value)
            _Descripcion = Value
        End Set
    End Property

    Public Property Objetivo()
        Get
            Return _Objetivo
        End Get
        Set(ByVal Value)
            _Objetivo = Value
        End Set
    End Property

    Public Property Responsable()
        Get
            Return _Responsable
        End Get
        Set(ByVal Value)
            _Responsable = Value
        End Set
    End Property

    Public Property ID_CT()
        Get
            Return _ID_CT
        End Get
        Set(ByVal Value)
            _ID_CT = Value
        End Set
    End Property

    Public Property ID_SC()
        Get
            Return _ID_SC
        End Get
        Set(ByVal Value)
            _ID_SC = Value
        End Set

    End Property

    Public Property ID_GT()
        Get
            Return _ID_GT
        End Get
        Set(ByVal Value)
            _ID_GT = Value
        End Set
    End Property

    Public Property ID_SGT()
        Get
            Return _ID_SGT
        End Get
        Set(ByVal Value)
            _ID_SGT = Value
        End Set
    End Property

    Public Property status()
        Get
            Return _status
        End Get
        Set(ByVal Value)
            _status = Value
        End Set
    End Property

    Public Property statusProceso() As Boolean
        Get
            Return _statusProceso
        End Get
        Set(ByVal Value As Boolean)
            _statusProceso = Value
        End Set
    End Property
    Public Property Inactivo() As Boolean
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Boolean)
            _Inactivo = Value
        End Set
    End Property

    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property

    Public Property BandError() As Boolean
        Get
            Return _bandError
        End Get
        Set(ByVal Value As Boolean)
            _bandError = Value
        End Set
    End Property



    'Function Agregar_uno(ByVal Comite As String, ByVal Descripcion As String)
    Public Sub Agregar_uno()
        If _ID_Comite = "" Or _Descripcion = "" Or _ID_Comite = "NA" Then
            MsgBox("Faltan campos por llenar.", MsgBoxStyle.Exclamation, "Comites")
            BandError = True
            Exit Sub
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdAgregar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Agregar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Responsable", _Responsable)
            .Parameters.Add("@Inactivo", _Inactivo)
            .Parameters.Add("@Objetivo", _Objetivo)
        End With
        Try
            cn.Open()
            Dim ms
            cmdAgregar.ExecuteNonQuery()
            cn.Close()
            cmdAgregar.Parameters.Clear()
            cmdAgregar.Dispose()
            _statusProceso = True
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            _statusProceso = False
        End Try
        Exit Sub
    End Sub

    Public Sub Agregar_dos()
        If _ID_CT = "NA" Or ID_CT = "na" Then
        Else
            If _ID_Comite = "" Or _ID_CT = "" Or _Descripcion = "" Or _Objetivo = "" Then
                MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
                Exit Sub
            End If
        End If

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdAgregar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Agregar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Responsable", _Responsable)
        End With
        Try
            cn.Open()
            cmdAgregar.ExecuteNonQuery()
            cn.Close()
            cmdAgregar.Parameters.Clear()
            cmdAgregar.Dispose()
            _statusProceso = True
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            _statusProceso = False
        End Try
        Exit Sub
    End Sub

    Public Sub Agregar_tres()
        If _ID_CT = "NA" Or _ID_CT = "na" Or _ID_SC = "NA" Or _ID_SC = "na" Then
        Else
            If _ID_Comite = "" Or _ID_CT = "" Or _ID_SC = "" Or _Descripcion = "" Or _Objetivo = "" Then
                MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
                Exit Sub
            End If
        End If

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdAgregar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Agregar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Responsable", _Responsable)
            _statusProceso = True
        End With
        Try
            cn.Open()
            cmdAgregar.ExecuteNonQuery()
            cn.Close()
            cmdAgregar.Parameters.Clear()
            cmdAgregar.Dispose()
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            _statusProceso = False
        End Try
        Exit Sub
    End Sub

    'Function Agregar_cuatro(ByVal Comite As String, ByVal CT As String, ByVal SC As String, ByVal GT As String, ByVal Descripcion As String, ByVal Objetivo As String)
    Public Sub Agregar_cuatro()
        If _ID_CT = "NA" Or _ID_CT = "na" Or _ID_SC = "NA" Or _ID_SC = "na" Or _ID_GT = "NA" Or _ID_GT = "na" Then
        Else
            If _ID_Comite = "" Or _ID_CT = "" Or _ID_SC = "" Or _ID_GT = "" Or _Descripcion = "" Or _Objetivo = "" Or _ID_GT = "NA" Or _ID_GT = "na" Then
                MsgBox("Faltan campos por llenar o nombre no valido", MsgBoxStyle.Exclamation, "Comites")
                Exit Sub
            End If
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdAgregar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Agregar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Responsable", _Responsable)
        End With
        Try
            cn.Open()
            cmdAgregar.ExecuteNonQuery()
            cn.Close()
            cmdAgregar.Parameters.Clear()
            cmdAgregar.Dispose()
            _statusProceso = True
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre - Error: " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
            _statusProceso = False
        End Try
        Exit Sub
    End Sub

    'Function Actualizar_uno(ByVal Comite As String, ByVal Descripcion As String)
    Public Function Actualizar_uno() As String
        If _ID_Comite = "" Or _Descripcion = "" Then
            MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
            sStatus = "Fallo"
            Return sStatus
            Exit Function
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdActualizar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Actualizar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Responsable", _Responsable)
            .Parameters.Add("@Objetivo", _Objetivo)
        End With
        'Try
        cn.Open()
        cmdActualizar.ExecuteNonQuery()
        cn.Close()
        cmdActualizar.Parameters.Clear()
        cmdActualizar.Dispose()
        'Catch ex As Exception
        '    MsgBox("Verifica que no exista ya este nombre  " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
        'End Try
    End Function

    'Function Actualizar_dos(ByVal Comite As String, ByVal CT As String, ByVal Descripcion As String, ByVal Objetivo As String)
    Public Function Actualizar_dos() As String
        If _ID_Comite = "" Or _ID_CT = "" Or _Descripcion = "" Or _Objetivo = "" Then
            MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
            sStatus = "Fallo"
            Return sStatus
            Exit Function
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdActualizar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Actualizar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Responsable", _Responsable)
        End With
        Try
            cn.Open()
            cmdActualizar.ExecuteNonQuery()
            cn.Close()
            cmdActualizar.Parameters.Clear()
            cmdActualizar.Dispose()
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre  " & ex.Message, MsgBoxStyle.Exclamation, "Campo Existente")
        End Try
    End Function

    'Function Actualizar_tres(ByVal Comite As String, ByVal CT As String, ByVal SC As String, ByVal Descripcion As String, ByVal Objetivo As String)
    Public Function Actualizar_tres() As String
        If _ID_Comite = "" Or _ID_CT = "" Or _ID_SC = "" Or _Descripcion = "" Or _Objetivo = "" Then
            MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
            sStatus = "Fallo"
            Return sStatus
            Exit Function
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdActualizar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Actualizar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Responsable", _Responsable)
        End With
        Try
            cn.Open()
            cmdActualizar.ExecuteNonQuery()
            cn.Close()
            cmdActualizar.Parameters.Clear()
            cmdActualizar.Dispose()
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre", MsgBoxStyle.Exclamation, "Campo Existente")
        End Try
    End Function

    'Function Actualizar_cuatro(ByVal Comite As String, ByVal CT As String, ByVal SC As String, ByVal GT As String, ByVal Descripcion As String, ByVal Objetivo As String)
    Public Function Actualizar_cuatro() As String
        If _ID_Comite = "" Or _ID_CT = "" Or _ID_SC = "" Or _ID_GT = "" Or _Descripcion = "" Or _Objetivo = "" Then
            MsgBox("Faltan campos por llenar", MsgBoxStyle.Exclamation, "Comites")
            sStatus = "Fallo"
            Return sStatus
            Exit Function
        End If
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        With cmdActualizar
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Actualizar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Objetivo", _Objetivo)
            .Parameters.Add("@Responsable", _Responsable)
        End With
        Try
            cn.Open()
            cmdActualizar.ExecuteNonQuery()
            cn.Close()
            cmdActualizar.Parameters.Clear()
            cmdActualizar.Dispose()
        Catch ex As Exception
            MsgBox("Verifica que no exista ya este nombre", MsgBoxStyle.Exclamation, "Campo Existente")
        End Try
    End Function

    Function Busca_uno()

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBuscar1 As New SqlCommand
        With cmdBuscar1
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Descripcion"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)
        End With
        Dim dr As SqlDataReader
        Try
            cn.Open()
            dr = cmdBuscar1.ExecuteReader()
            If dr.Read Then
                _ID_Comite = dr("ID_Comite")
                _Descripcion = dr("Descripcion")
                _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
                _Objetivo = IIf((IsDBNull(dr("Objetivo"))), Nothing, dr("Objetivo"))
                _ID_CT = Nothing
                _ID_SC = Nothing
                _ID_GT = Nothing
                _ID_SGT = Nothing
                _Inactivo = dr("Inactivo")
                _Encontrado = True
            Else
                _ID_Comite = Nothing
                _Descripcion = Nothing
                _Objetivo = Nothing
                _ID_CT = Nothing
                _ID_SC = Nothing
                _ID_GT = Nothing
                _ID_SGT = Nothing
                _Inactivo = Nothing
                _Encontrado = False
            End If
            cn.Close()
            cmdBuscar1.Parameters.Clear()
            cmdBuscar1.Dispose()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    'Function Busca_dos(ByVal Comite As String, ByVal CT As String)
    Public Sub Busca_dos()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBuscar2 As New SqlCommand
        With cmdBuscar2
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Descripcion"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)
        End With
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmdBuscar2.ExecuteReader
            If dr.Read Then
                _ID_Comite = dr("ID_Comite")
                _Descripcion = dr("Descripcion")
                _Objetivo = IIf((IsDBNull(dr("Objetivo"))), "NA", dr("Objetivo"))
                _ID_CT = IIf((IsDBNull(dr("ID_CT"))), "NA", dr("ID_CT")) 'ID_
                _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
                _ID_SC = ""
                _ID_GT = ""
                _ID_SGT = ""
                _Inactivo = dr("Inactivo")
            Else
                _ID_Comite = ""
                _Descripcion = ""
                _Objetivo = ""
                _ID_CT = ""
                _ID_SC = ""
                _ID_GT = ""
                _ID_SGT = ""
                _Inactivo = ""
            End If
            cn.Close()
            cmdBuscar2.Parameters.Clear()
            cmdBuscar2.Dispose()
        Catch ex As Exception
            Return
        End Try
    End Sub

    Public Sub Busca_tres()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBuscar3 As New SqlCommand
        With cmdBuscar3
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Descripcion"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)

        End With
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmdBuscar3.ExecuteReader
            If dr.Read Then
                _ID_Comite = dr("ID_Comite")
                _Descripcion = dr("Descripcion")
                _Objetivo = IIf((IsNothing(dr("Objetivo"))), "", dr("Objetivo"))
                _ID_CT = IIf((IsNothing(dr("ID_CT"))), "NA", dr("ID_CT"))
                _ID_SC = IIf((IsNothing(dr("ID_SC"))), "NA", dr("ID_SC"))
                _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
                '''_ID_GT = IIf((IsNothing(dr("GT"))), "", dr("GT"))
                _ID_GT = ""
                _ID_SGT = ""
                _Inactivo = dr("Inactivo")
            Else
                _ID_Comite = ""
                _Descripcion = ""
                _Objetivo = ""
                _ID_CT = ""
                _ID_SC = ""
                _ID_GT = ""
                _ID_SGT = ""
                _Inactivo = ""
            End If
            cn.Close()
            cmdBuscar3.Parameters.Clear()
            cmdBuscar3.Dispose()
        Catch ex As Exception
            Return
        End Try
    End Sub

    Public Sub Busca_cuatro()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBuscar4 As New SqlCommand
        With cmdBuscar4
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Descripcion"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)
        End With
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmdBuscar4.ExecuteReader
            If dr.Read Then
                _ID_Comite = dr("ID_Comite")
                _Descripcion = dr("Descripcion")
                _Objetivo = IIf((IsNothing(dr("Objetivo"))), "", dr("Objetivo"))
                _ID_CT = IIf((IsNothing(dr("ID_CT"))), "NA", dr("ID_CT"))
                _ID_SC = IIf((IsNothing(dr("ID_SC"))), "NA", dr("ID_SC"))
                _ID_GT = IIf((IsNothing(dr("ID_Grupo"))), "NA", dr("ID_Grupo"))
                _ID_SGT = ""
                _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
                _Inactivo = dr("Inactivo")
            Else
                _ID_Comite = ""
                _Descripcion = ""
                _Objetivo = ""
                _ID_CT = ""
                _ID_SC = ""
                _ID_GT = ""
                _ID_SGT = ""
                _Inactivo = Nothing
            End If
            cn.Close()
            cmdBuscar4.Parameters.Clear()
            cmdBuscar4.Dispose()
        Catch ex As Exception
            Dim ms
            ms = ex.Message
            Return
        End Try
    End Sub


    ''''se deshabilita el SGT
    '''Public Sub Busca_cinco()
    '''    If cn.State = ConnectionState.Open Then
    '''        cn.Close()
    '''    End If
    '''    Dim cmdBuscar5 As New SqlCommand
    '''    With cmdBuscar5
    '''        .CommandType = CommandType.StoredProcedure
    '''        .CommandText = "sp_P_Comites_Descripcion"
    '''        .Connection = cn
    '''        .Parameters.Add("@Bandera", _Bandera)
    '''        .Parameters.Add("@Comite", _ID_Comite)
    '''        .Parameters.Add("@CT", _ID_CT)
    '''        .Parameters.Add("@SC", _ID_SC)
    '''        .Parameters.Add("@GT", _ID_GT)
    '''        .Parameters.Add("@SGT", _ID_SGT)
    '''    End With
    '''    Try
    '''        cn.Open()
    '''        Dim dr As SqlDataReader
    '''        dr = cmdBuscar5.ExecuteReader
    '''        If dr.Read Then
    '''            _ID_Comite = dr("ID_Comite")
    '''            _Descripcion = dr("Descripcion")
    '''            _Objetivo = IIf((IsNothing(dr("Objetivo"))), "", dr("Objetivo"))
    '''            _ID_CT = IIf((IsNothing(dr("ID_CT"))), "", dr("ID_CT"))
    '''            _ID_SC = IIf((IsNothing(dr("ID_SC"))), "", dr("ID_SC"))
    '''            _ID_GT = IIf((IsNothing(dr("ID_GT"))), "", dr("ID_GT"))
    '''            _ID_SGT = IIf((IsNothing(dr("ID_SGT"))), "", dr("ID_SGT"))
    '''            _Responsable = IIf((IsDBNull(dr("Responsable"))), "", dr("Responsable"))
    '''        Else
    '''            _ID_Comite = ""
    '''            _Descripcion = ""
    '''            _Objetivo = ""
    '''            _ID_CT = ""
    '''            _ID_SC = ""
    '''            _ID_GT = ""
    '''            _ID_SGT = ""
    '''        End If
    '''        cn.Close()
    '''        cmdBuscar5.Parameters.Clear()
    '''        cmdBuscar5.Dispose()
    '''    Catch ex As Exception
    '''        Return
    '''    End Try
    '''End Sub


    'Function Borrar_uno(ByVal Comite As String)
    '    Public Sub Borrar_uno()
    Public Function Borrar_uno() As String

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBorrar1 As New SqlCommand
        'On Error GoTo er
        With cmdBorrar1
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Borrar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@Inactivo", _Inactivo)
        End With
        Try
            cn.Open()
            cmdBorrar1.ExecuteNonQuery()

            '''statusBorrar = New SqlParameter("@RC", SqlDbType.Int)
            '''statusBorrar.Direction = ParameterDirection.Output
            '''cmdBorrar1.Parameters.Add(statusBorrar)
            '''statusBorrar = cmdBorrar1.Parameters("@RC").Value
            '''If IsDBNull(cmdBorrar1.Parameters("@RC").Value) = False Then
            '''    'If IsNothing(cmdBorrar1.Parameters("@RC").Value) Then
            '''    MsgBox("Verifica que este Comite no tenga Comites T�cnicos", MsgBoxStyle.Exclamation, "Campo con Comites")
            '''    cmdBorrar1.Parameters.Clear()
            '''    cmdBorrar1.Dispose()
            '''    Exit Function
            '''End If

            cn.Close()
            cmdBorrar1.Parameters.Clear()
            cmdBorrar1.Dispose()
            _statusProceso = True
            '''Return sStatus
        Catch ex As Exception
            '''If Err.Number = 0 Then
            MsgBox("Verifica que no existan nodos hijos - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Campo Existente")
            sStatus = "Fallo"
            _statusProceso = False
            Return sStatus
        End Try
        ''''    Exit Function
        '''End If

        '''Catch ex As Exception
        '''    Return "ERROR: " & ex.Message
        '''End Try
    End Function

    'Public Function Borrar_dos(ByVal Comite As String, ByVal CT As String)
    Public Function Borrar_dos() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmdBorrar2 As New SqlCommand

        With cmdBorrar2
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Borrar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@GT", _ID_GT)
            .Parameters.Add("@Inactivo", _Inactivo)
        End With
        Try
            cn.Open()
            cmdBorrar2.ExecuteNonQuery()

            '''statusBorrar = New SqlParameter("@RC", SqlDbType.Int)
            '''statusBorrar.Direction = ParameterDirection.Output
            '''cmdBorrar2.Parameters.Add(statusBorrar)
            '''statusBorrar = cmdBorrar2.Parameters("@RC").Value
            '''If IsNothing(cmdBorrar2.Parameters("@RC").Value) Then
            '''    MsgBox("Verifica que este Comite T�cnico no tenga Sub Comites", MsgBoxStyle.Exclamation, "Campo con Comites")
            '''    cmdBorrar2.Parameters.Clear()
            '''    cmdBorrar2.Dispose()
            '''    Exit Function
            '''End If

            cn.Close()
            cmdBorrar2.Parameters.Clear()
            cmdBorrar2.Dispose()
            _statusProceso = True

            'Return sStatus

            '''If Err.Number = 0 Then
        Catch ex As Exception
            MsgBox("Verifica que no existan nodos hijos - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Campo Existente")
            sStatus = "Fallo"
            _statusProceso = False
            Return sStatus
            '    Exit Function
            '''End If
        End Try

    End Function

    'Function Borrar_tres(ByVal Comite As String, ByVal CT As String, ByVal SC As String)
    'Public Sub Borrar_tres()
    Public Function Borrar_tres()
        Dim cmdBorrar3 As New SqlCommand
        Dim Valor As SqlParameter
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        'On Error GoTo er
        With cmdBorrar3
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Borrar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@Inactivo", _Inactivo)
        End With
        Try
            cn.Open()
            cmdBorrar3.ExecuteNonQuery()

            '''statusBorrar = New SqlParameter("@RC", SqlDbType.Int)
            '''statusBorrar.Direction = ParameterDirection.Output
            '''cmdBorrar3.Parameters.Add(statusBorrar)
            '''statusBorrar = cmdBorrar3.Parameters("@RC").Value
            '''If IsNothing(cmdBorrar3.Parameters("@RC").Value) Then
            '''    MsgBox("Verifica que este Sub Comites no tenga Grupos de Trabajos", MsgBoxStyle.Exclamation, "Campo con Comites")
            '''    cmdBorrar3.Parameters.Clear()
            '''    cmdBorrar3.Dispose()
            '''    Exit Function
            '''End If

            cn.Close()
            'cmdBorrar3.Parameters.Clear()
            cmdBorrar3.Dispose()
            _statusProceso = True
        Catch ex As Exception
            'Return sStatus
            'er:
            If Err.Number = 0 Then
                MsgBox("Verifica que no existan nodos hijos - Error: " & Err.Description, MsgBoxStyle.Exclamation, "Campo Existente")
                sStatus = "Fallo"
                Return sStatus
                _statusProceso = False
                Exit Function
            End If
            MsgBox("Verifica que no existan nodos hijos - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Campo Existente")
            _statusProceso = False
        End Try

    End Function

    'Function Borrar_cuatro(ByVal Comite As String, ByVal CT As String, ByVal SC As String, ByVal GT As String)
    'Public Sub Borrar_cuatro()
    Public Function Borrar_cuatro()
        Dim cmdBorrar4 As New SqlCommand
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        'On Error GoTo er
        With cmdBorrar4
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_P_Comites_Borrar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Comite", _ID_Comite)
            .Parameters.Add("@CT", _ID_CT)
            .Parameters.Add("@SC", _ID_SC)
            .Parameters.Add("@GT", _ID_GT)
            .Parameters.Add("@Inactivo", _Inactivo)
        End With
        Try
            cn.Open()
            cmdBorrar4.ExecuteNonQuery()
            cn.Close()
            'cmdBorrar4.Parameters.Clear()
            cmdBorrar4.Dispose()
            _statusProceso = True
        Catch ex As Exception
            'Return sStatus
            'er:
            If Err.Number = 0 Then
                MsgBox("Error: " & Err.Description, MsgBoxStyle.Exclamation, "Campo Existente")
                sStatus = "Fallo"
                Return sStatus
                _statusProceso = False
                Exit Function
            End If
            MsgBox("Error al tratar de borrar el Grupo de Trabajo - Error: " & Err.Description & " - " & Err.Number, MsgBoxStyle.Exclamation, "Campo Existente")
            _statusProceso = False
        End Try

    End Function

    ''''se deshabilita el SGT
    '''    Public Function Borrar_cinco()
    '''        Dim cmdBorrar5 As New SqlCommand
    '''        If cn.State = ConnectionState.Open Then
    '''            cn.Close()
    '''        End If
    '''        On Error GoTo er
    '''        With cmdBorrar5
    '''            .CommandType = CommandType.StoredProcedure
    '''            .CommandText = "sp_P_Comites_Borrar"
    '''            .Connection = cn
    '''            .Parameters.Add("@Bandera", _Bandera)
    '''            .Parameters.Add("@Comite", _ID_Comite)
    '''            .Parameters.Add("@CT", _ID_CT)
    '''            .Parameters.Add("@SC", _ID_SC)
    '''            .Parameters.Add("@GT", _ID_GT)
    '''            .Parameters.Add("@SGT", _ID_SGT)
    '''        End With
    '''        ''''Try
    '''        cn.Open()
    '''        cmdBorrar5.ExecuteNonQuery()
    '''        cn.Close()
    '''        cmdBorrar5.Dispose()
    '''        Return sStatus
    '''er:
    '''        If Err.Number = 0 Then
    '''            MsgBox("Error: " & Err.Description, MsgBoxStyle.Exclamation, "Campo Existente")
    '''            sStatus = "Fallo"
    '''            Return sStatus
    '''            Exit Function
    '''        End If
    '''        ''''End Try
    '''    End Function

    'Public Sub New()
    Public Sub New(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)

        ''objConexion.Conexion(0, "admsis", "admynsys")
        ''cn.ConnectionString = ("Data source=" + objConexion.SserverC + "; initial catalog=" + objConexion.SBaseD + "; user id = admsis; pwd=admynsys")
        sStatus = "OK"
    End Sub
End Class
