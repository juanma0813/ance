Public Class FrmRemitentes
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents grdRemitentes As System.Windows.Forms.DataGrid
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEliminar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtIdRemitente As System.Windows.Forms.TextBox
    Friend WithEvents txtMailAlternativo As System.Windows.Forms.TextBox
    Friend WithEvents txtMail As System.Windows.Forms.TextBox
    Friend WithEvents txtPuesto As System.Windows.Forms.TextBox
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents cmdResumen As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmRemitentes))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtIdRemitente = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtMailAlternativo = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMail = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtPuesto = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtEmpresa = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtNombre = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.grdRemitentes = New System.Windows.Forms.DataGrid
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.cmdEliminar = New System.Windows.Forms.ToolBarButton
        Me.cmdResumen = New System.Windows.Forms.ToolBarButton
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdRemitentes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.txtIdRemitente)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtMailAlternativo)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtMail)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtPuesto)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtEmpresa)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtNombre)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(704, 96)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'txtIdRemitente
        '
        Me.txtIdRemitente.Location = New System.Drawing.Point(576, 64)
        Me.txtIdRemitente.Name = "txtIdRemitente"
        Me.txtIdRemitente.Size = New System.Drawing.Size(88, 20)
        Me.txtIdRemitente.TabIndex = 21
        Me.txtIdRemitente.Text = ""
        Me.txtIdRemitente.Visible = False
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(576, 32)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 23)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Clave"
        Me.Label6.Visible = False
        '
        'txtMailAlternativo
        '
        Me.txtMailAlternativo.Location = New System.Drawing.Point(352, 64)
        Me.txtMailAlternativo.Name = "txtMailAlternativo"
        Me.txtMailAlternativo.Size = New System.Drawing.Size(208, 20)
        Me.txtMailAlternativo.TabIndex = 9
        Me.txtMailAlternativo.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(296, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Mail Alt:"
        '
        'txtMail
        '
        Me.txtMail.Location = New System.Drawing.Point(80, 64)
        Me.txtMail.Name = "txtMail"
        Me.txtMail.Size = New System.Drawing.Size(200, 20)
        Me.txtMail.TabIndex = 7
        Me.txtMail.Text = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 16)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Mail:"
        '
        'txtPuesto
        '
        Me.txtPuesto.Location = New System.Drawing.Point(352, 40)
        Me.txtPuesto.Name = "txtPuesto"
        Me.txtPuesto.Size = New System.Drawing.Size(208, 20)
        Me.txtPuesto.TabIndex = 5
        Me.txtPuesto.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(296, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Puesto:"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Location = New System.Drawing.Point(80, 40)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(200, 20)
        Me.txtEmpresa.TabIndex = 3
        Me.txtEmpresa.Text = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Empresa:"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(80, 16)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(480, 20)
        Me.txtNombre.TabIndex = 1
        Me.txtNombre.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nombre:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.grdRemitentes)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 104)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(704, 248)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'grdRemitentes
        '
        Me.grdRemitentes.AlternatingBackColor = System.Drawing.Color.Silver
        Me.grdRemitentes.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdRemitentes.BackColor = System.Drawing.Color.White
        Me.grdRemitentes.CaptionBackColor = System.Drawing.Color.YellowGreen
        Me.grdRemitentes.CaptionFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdRemitentes.CaptionForeColor = System.Drawing.Color.White
        Me.grdRemitentes.CaptionText = "Remitentes"
        Me.grdRemitentes.DataMember = ""
        Me.grdRemitentes.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdRemitentes.ForeColor = System.Drawing.Color.Black
        Me.grdRemitentes.GridLineColor = System.Drawing.Color.Silver
        Me.grdRemitentes.HeaderBackColor = System.Drawing.Color.Silver
        Me.grdRemitentes.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdRemitentes.HeaderForeColor = System.Drawing.Color.Black
        Me.grdRemitentes.LinkColor = System.Drawing.Color.Maroon
        Me.grdRemitentes.Location = New System.Drawing.Point(8, 16)
        Me.grdRemitentes.Name = "grdRemitentes"
        Me.grdRemitentes.ParentRowsBackColor = System.Drawing.Color.Silver
        Me.grdRemitentes.ParentRowsForeColor = System.Drawing.Color.Black
        Me.grdRemitentes.ReadOnly = True
        Me.grdRemitentes.SelectionBackColor = System.Drawing.Color.Maroon
        Me.grdRemitentes.SelectionForeColor = System.Drawing.Color.White
        Me.grdRemitentes.Size = New System.Drawing.Size(688, 224)
        Me.grdRemitentes.TabIndex = 37
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.cmdEliminar, Me.cmdResumen})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 363)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(720, 62)
        Me.tlbBotonera.TabIndex = 37
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'cmdEliminar
        '
        Me.cmdEliminar.ImageIndex = 11
        Me.cmdEliminar.Text = "Eliminar"
        Me.cmdEliminar.ToolTipText = "Eliminar Participante"
        '
        'cmdResumen
        '
        Me.cmdResumen.ImageIndex = 15
        Me.cmdResumen.Text = "Resumen"
        Me.cmdResumen.ToolTipText = "Resumen de Nombramientos"
        '
        'FrmRemitentes
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(720, 425)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FrmRemitentes"
        Me.Text = "..:: Remitentes ::.."
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdRemitentes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Inicializacion de variables"
    Dim Tabla As String = "Encontrados"
    Dim dgEstiloColumna As New DataGridTableStyle
    Dim ColEStilo0 As New DataGridTextBoxColumn
    Dim ColEStilo1 As New DataGridTextBoxColumn
    Dim ColEStilo2 As New DataGridTextBoxColumn
    Dim ColEStilo3 As New DataGridTextBoxColumn
    Dim ColEStilo4 As New DataGridTextBoxColumn
    Dim ColEStilo5 As New DataGridTextBoxColumn


#End Region

    Private _IdAccion As eAccionGuardado

    Private Property IdAccion() As eAccionGuardado
        Get
            Return _IdAccion
        End Get
        Set(ByVal Value As eAccionGuardado)
            _IdAccion = Value
        End Set
    End Property

    Private Enum eBtnRemitentes As Integer
        Agregar = 0
        Editar = 1
        Deshacer = 2
        Salvar = 3
        Eliminar = 4
        Resumen = 5
    End Enum

    Private Enum eAccionGuardado As Integer
        Ninguna = 0
        Nuevo = 1
        Edicion = 2
    End Enum

    Private Sub FrmRemitentes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        BotonesInicio()
        CargarDatos()
        FormaGrid(grdRemitentes)
    End Sub

    Private Sub BotonesInicio()
        IdAccion = eAccionGuardado.Ninguna
        inactivar(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
        Activar(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
        Limpiar(txtNombre, txtEmpresa, txtPuesto, txtMail, txtMailAlternativo, txtIdRemitente)
        inactivar(txtNombre, txtEmpresa, txtPuesto, txtMail, txtMailAlternativo, txtIdRemitente)
        Activar(grdRemitentes)
    End Sub

    Private Sub BotonesNuevo()
        IdAccion = eAccionGuardado.Nuevo
        Activar(txtNombre, txtEmpresa, txtPuesto, txtMail, txtMailAlternativo, txtIdRemitente)
        Limpiar(txtNombre, txtEmpresa, txtPuesto, txtMail, txtMailAlternativo, txtIdRemitente)

        Activar(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
        inactivar(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
        inactivar(grdRemitentes)
    End Sub

    Private Sub BotonesEdicion()
        IdAccion = eAccionGuardado.Edicion
        Activar(txtNombre, txtEmpresa, txtPuesto, txtMail, txtMailAlternativo, txtIdRemitente)

        Activar(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
        inactivar(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
        inactivar(grdRemitentes)
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case eBtnRemitentes.Agregar
                BotonesNuevo()
            Case eBtnRemitentes.Editar
                If txtIdRemitente.Text <> "" Then
                    BotonesEdicion()
                Else
                    MsgBox("Es necesario seleccionar un registro", MsgBoxStyle.Critical)
                End If
            Case eBtnRemitentes.Deshacer
                BotonesInicio()
            Case eBtnRemitentes.Salvar
                If ValidarDatos() = False Then
                    Select Case IdAccion
                        Case eAccionGuardado.Nuevo
                            GuardarNuevo()
                        Case eAccionGuardado.Edicion
                            GuardarEdicion()
                    End Select
                End If
            Case eBtnRemitentes.Eliminar
                If txtIdRemitente.Text <> "" Then
                    If MsgBox("�Estas seguro de eliminar el registro?", MsgBoxStyle.Information Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        Eliminar(txtIdRemitente.Text)
                    End If
                Else
                    MsgBox("Es necesario seleccionar un registro", MsgBoxStyle.Critical)
                End If
            Case eBtnRemitentes.Resumen
                If txtIdRemitente.Text <> "" Then
                    Dim ResumenNombramientos As New frmResumenNombramientos
                    ResumenNombramientos.IdRemitente = txtIdRemitente.Text
                    ResumenNombramientos.EmaiRemitente = txtMail.Text
                    ResumenNombramientos.MdiParent = Me.MdiParent
                    ResumenNombramientos.Show()
                Else
                    MsgBox("Es necesario seleccionar un registro", MsgBoxStyle.Critical)
                End If
        End Select
    End Sub

    Private Sub CargarDatos()
        Dim dt As DataTable
        Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
        objRemitentes.Bandera = "s3"
        dt = objRemitentes.Listar
        grdRemitentes.DataSource = dt
    End Sub

    Private Function ConsultarEmail(ByVal Mail As String) As DataTable
        Dim dt As DataTable
        Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
        objRemitentes.Bandera = "s3"
        objRemitentes.Email = Trim(Mail)
        dt = objRemitentes.Listar()

        Return dt
    End Function

    Sub FormaGrid(ByVal grd As DataGrid)
        With grd
            .CaptionText = "REMITENTES"
            .CaptionBackColor = Color.RoyalBlue
            .CaptionFont = New Font("Tahoma", 10.0!, FontStyle.Bold)
            .BorderStyle = BorderStyle.None
            .Font = New Font("Tahoma", 8.0!)
            .AllowSorting = False
        End With
        Call Tabla_Color(dgEstiloColumna, grd)

        With dgEstiloColumna
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .MappingName = Tabla
            .PreferredColumnWidth = 125
            .PreferredRowHeight = 15
            .AllowSorting = False
        End With

        With ColEStilo0
            .HeaderText = "IdRemitente"
            .MappingName = "IdRemitente"
            .Width = 0
            .ReadOnly = True
        End With

        With ColEStilo1
            .HeaderText = "Nombre"
            .MappingName = "Nombre"
            .Width = 160
            .ReadOnly = True
        End With

        With ColEStilo2
            .HeaderText = "Empresa"
            .MappingName = "Empresa"
            .Width = 120
            .ReadOnly = True
        End With

        With ColEStilo3
            .HeaderText = "Puesto"
            .MappingName = "Puesto"
            .Width = 120
            .ReadOnly = True
        End With

        With ColEStilo4
            .HeaderText = "E-Mail"
            .MappingName = "Email"
            .Width = 150
            .ReadOnly = True
        End With

        With ColEStilo5
            .HeaderText = "E-Mail Alt"
            .MappingName = "EmailAlterno"
            .Width = 150
            .ReadOnly = True
        End With


        dgEstiloColumna.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEStilo0, ColEStilo1, ColEStilo2, ColEStilo3, ColEStilo4, ColEStilo5})
        grd.TableStyles.Add(dgEstiloColumna)

    End Sub

    Private Sub GuardarNuevo()
        Dim bExiste As Boolean = False


        bExiste = ValidarExistencia(txtMail.Text)
        If bExiste = True Then
            MsgBox("El correo que intenta registrar ya existe. intentalo con uno distinto", MsgBoxStyle.Critical)
        Else
            Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
            objRemitentes.Bandera = "i1"
            objRemitentes.Nombre = txtNombre.Text
            objRemitentes.Empresa = txtEmpresa.Text
            objRemitentes.Puesto = txtPuesto.Text
            objRemitentes.Email = txtMail.Text
            objRemitentes.EmailAlterno = txtMailAlternativo.Text
            objRemitentes.Activo = True
            objRemitentes.FechaAlta = Now()
            objRemitentes.Insertar()

            CargarDatos()
            BotonesInicio()
            MsgBox("Registro Ingresado correctamente", MsgBoxStyle.Information)
        End If

    End Sub

    Private Sub GuardarEdicion()
        Dim bExiste As Boolean = False
        Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes

        objRemitentes.Bandera = "s1"
        objRemitentes.IdRemitente = txtIdRemitente.Text
        objRemitentes.LlenarDatos()

        If objRemitentes.Email <> txtMail.Text Then
            bExiste = ValidarExistencia(txtMail.Text)
        End If

        If bExiste = True Then
            MsgBox("El correo que intenta registrar ya existe. intentalo con uno distinto", MsgBoxStyle.Critical)
        Else

            objRemitentes.Bandera = "u2"
            objRemitentes.Nombre = txtNombre.Text
            objRemitentes.Empresa = txtEmpresa.Text
            objRemitentes.Puesto = txtPuesto.Text
            objRemitentes.Email = txtMail.Text
            objRemitentes.EmailAlterno = txtMailAlternativo.Text
            objRemitentes.IdRemitente = txtIdRemitente.Text
            objRemitentes.Actualizar()

            CargarDatos()
            BotonesInicio()
            MsgBox("Registro Actualizado correctamente", MsgBoxStyle.Information)
        End If

    End Sub

    Private Function ValidarExistencia(ByVal Email As String) As Boolean
        Dim bExiste As Boolean = False
        Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
        objRemitentes.Bandera = "s2"
        objRemitentes.Email = Trim(Email)

        If objRemitentes.Listar().Rows.Count > 0 Then
            bExiste = True
        Else
            bExiste = False
        End If

        Return bExiste
    End Function

    Private Function ValidarDatos() As Boolean
        Dim bError As Boolean = False
        Dim msg As String = ""

        If Trim(txtNombre.Text) = "" Then msg += "Nombre" & vbCrLf
        If Trim(txtEmpresa.Text) = "" Then msg += "Empresa" & vbCrLf
        If Trim(txtPuesto.Text) = "" Then msg += "Puesto" & vbCrLf
        If Trim(txtMail.Text) = "" Then msg += "E-Mail" & vbCrLf

        If msg <> "" Then
            bError = True
            msg = "El o los siguientes campos son obligatorios:" & vbCrLf & msg
            MsgBox(msg, MsgBoxStyle.Critical)
        End If
        Return bError
    End Function

    Private Sub grdRemitentes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdRemitentes.Click
        Dim index As Integer
        Dim IdRemitente As Integer

        If grdRemitentes.CurrentRowIndex < 0 Then
        Else
            If Not grdRemitentes.DataSource Is Nothing Then
                bandgrd = True
                index = grdRemitentes.CurrentRowIndex
                IdRemitente = grdRemitentes.Item(index, 0)

                LlenarCampos(IdRemitente)
            End If
        End If

    End Sub

    Private Sub LlenarCampos(ByVal IdRemitente)
        Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
        objRemitentes.Bandera = "s1"
        objRemitentes.IdRemitente = IdRemitente
        objRemitentes.LlenarDatos()

        txtNombre.Text = objRemitentes.Nombre
        txtEmpresa.Text = objRemitentes.Empresa
        txtPuesto.Text = objRemitentes.Puesto
        txtMail.Text = objRemitentes.Email
        txtMailAlternativo.Text = objRemitentes.EmailAlterno
        txtIdRemitente.Text = objRemitentes.IdRemitente
    End Sub

    Private Sub Eliminar(ByVal IdRemitente As Integer)
        Dim objRemitentes As New clsRemitentes.AnceSystem.clssRemitentes
        objRemitentes.Bandera = "u3"
        objRemitentes.IdRemitente = IdRemitente
        objRemitentes.Activo = False
        objRemitentes.FechaAlta = Now
        objRemitentes.Actualizar()

        CargarDatos()
        BotonesInicio()
        MsgBox("Registro Eliminado correctamente", MsgBoxStyle.Information)
    End Sub

End Class
