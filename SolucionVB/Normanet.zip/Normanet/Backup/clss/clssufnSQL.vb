Namespace Maple
    Public Class clssufnSQL
        Public Shared Function CrearXmlParamSql(ByVal entXml As ArrayList) As String
            Dim xml As String = "<Propiedades>"
            Dim Item As String = "<Parametro Key=""{0}"" Value=""{1}"" />"

            For Each Parametro As entXml In entXml
                xml += String.Format(Item, Parametro.Key, LimpiarSimbolos(Parametro.Value))
            Next

            xml += "</Propiedades>"

            REM If xml <> "" Then xml = "<?xml version=""1.0"" encoding=""utf-8"" ?>" & xml
            Return xml
        End Function

        Private Shared Function LimpiarSimbolos(ByVal Valor As String) As String
            Valor = Replace(Valor, "&", "&amp;")

            Return Valor
        End Function
    End Class

    Public Class entXml
        Public sKey As String
        Public sValue As String

        Public Property [Key]()
            Get
                [Key] = sKey
            End Get
            Set(ByVal Value)
                sKey = Value
            End Set
        End Property

        Public Property [Value]()
            Get
                [Value] = sValue
            End Get
            Set(ByVal Value)
                sValue = Value
            End Set
        End Property

    End Class
End Namespace

