Option Strict Off
Option Explicit On 

Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class DataGridButtonColumn
    Inherits DataGridTextBoxColumn
    Public Event CellButtonClicked As DataGridCellButtonClickEventHandler

    Private _columnNum As Integer
    Private _buttonFace As Bitmap

    Public Sub New(ByVal colNum As Integer)
        _columnNum = colNum
        Try
            _buttonFace = New Bitmap(Application.StartupPath & "\plus.bmp")

        Catch
        End Try
    End Sub 'New 

    Protected Overloads Overrides Sub Edit(ByVal [source] As System.Windows.Forms.CurrencyManager, ByVal rowNum As Integer, ByVal bounds _
    As System.Drawing.Rectangle, ByVal [readOnly] As Boolean, ByVal instantText _
    As String, ByVal cellIsVisible As Boolean)
    End Sub

    Private Sub DrawButton(ByVal g As Graphics, ByVal bm As Bitmap, ByVal bounds As Rectangle, ByVal row As Integer)

        Dim dg As DataGrid = Me.DataGridTableStyle.DataGrid

        g.DrawImage(bm, bounds, 0, 0, bm.Width, bm.Height, GraphicsUnit.Pixel)

    End Sub

    Public Sub HandleMouseUp(ByVal sender As Object, ByVal e As MouseEventArgs)
        Dim dg As DataGrid = Me.DataGridTableStyle.DataGrid
        Dim hti As DataGrid.HitTestInfo = dg.HitTest(New Point(e.X, e.Y))
        Dim isClickInCell As Boolean = (hti.Column = Me._columnNum And hti.Row > -1)

        If Not isClickInCell Then Return
        Dim rect As New Rectangle(0, 0, 0, 0)

        rect = dg.GetCellBounds(hti.Row, hti.Column)
        Dim g As Graphics = Graphics.FromHwnd(dg.Handle)
        DrawButton(g, Me._buttonFace, rect, hti.Row)
        g.Dispose()
        RaiseEvent CellButtonClicked(Me, New DataGridCellButtonClickEventArgs(hti.Row, hti.Column))
    End Sub 'HandleMouseUp 

    Protected Overloads Overrides Sub Paint(ByVal g As System.Drawing.Graphics, ByVal bounds As System.Drawing.Rectangle, ByVal _
    [source] As System.Windows.Forms.CurrencyManager, ByVal rowNum As Integer, ByVal backBrush As System.Drawing.Brush, ByVal foreBrush As _
    System.Drawing.Brush, ByVal alignToRight As Boolean)

        Dim parent As DataGrid = Me.DataGridTableStyle.DataGrid
        Dim BackColor As Color
        BackColor = parent.AlternatingBackColor

        'clear the cell 
        g.FillRectangle(New SolidBrush(BackColor), bounds)

        'draw the value 
        Dim s As String = Me.GetColumnValueAtRow([source], rowNum).ToString()
        DrawButton(g, _buttonFace, bounds, rowNum)

    End Sub 'Paint 'font.Dispose(); 

End Class 'DataGridButtonColumn 

Public Delegate Sub DataGridCellButtonClickEventHandler(ByVal sender As Object, ByVal e As DataGridCellButtonClickEventArgs)

Public Class DataGridCellButtonClickEventArgs
    Inherits EventArgs
    Private _row As Integer
    Private _col As Integer

    Public Sub New(ByVal row As Integer, ByVal col As Integer)
        _row = row
        _col = col
    End Sub 'New 

    Public ReadOnly Property RowIndex() As Integer
        Get
            Return _row
        End Get
    End Property

    Public ReadOnly Property ColIndex() As Integer
        Get
            Return _col
        End Get
    End Property
End Class





'Option Strict Off
'Option Explicit On 

'Imports Microsoft.VisualBasic
'Imports System
'Imports System.Drawing
'Imports System.Windows.Forms

'Public Class DataGridButtonColumn
'    Inherits DataGridTextBoxColumn
'    Public Event CellButtonClicked As DataGridCellButtonClickEventHandler

'    Private _columnNum As Integer
'    Private _buttonFace As Bitmap

'    Public Sub New(ByVal colNum As Integer)
'        _columnNum = colNum
'        Try
'            _buttonFace = New Bitmap(Application.StartupPath & "\plus.bmp")
'        Catch
'            MsgBox("toy")
'        End Try
'    End Sub 'New

'    Protected Overloads Overrides Sub Edit(ByVal [source] As System.Windows.Forms.CurrencyManager, ByVal rowNum As Integer, ByVal bounds _
'    As System.Drawing.Rectangle, ByVal [readOnly] As Boolean, ByVal instantText _
'    As String, ByVal cellIsVisible As Boolean)
'    End Sub

'    Private Sub DrawButton(ByVal g As Graphics, ByVal bm As Bitmap, ByVal bounds As Rectangle, ByVal row As Integer)

'        Dim dg As DataGrid = Me.DataGridTableStyle.DataGrid
'        g.DrawImage(bm, bounds, 0, 0, bm.Width, bm.Height, GraphicsUnit.Pixel)

'    End Sub

'    Public Sub HandleMouseUp(ByVal sender As Object, ByVal e As MouseEventArgs)
'        Dim dg As DataGrid = Me.DataGridTableStyle.DataGrid
'        Dim hti As DataGrid.HitTestInfo = dg.HitTest(New Point(e.X, e.Y))
'        Dim isClickInCell As Boolean = (hti.Column = Me._columnNum And hti.Row > -1)

'        If Not isClickInCell Then Return
'        Dim rect As New Rectangle(0, 0, 0, 0)

'        rect = dg.GetCellBounds(hti.Row, hti.Column)
'        Dim g As Graphics = Graphics.FromHwnd(dg.Handle)
'        DrawButton(g, Me._buttonFace, rect, hti.Row)
'        g.Dispose()
'        RaiseEvent CellButtonClicked(Me, New DataGridCellButtonClickEventArgs(hti.Row, hti.Column))
'    End Sub 'HandleMouseUp

'    Protected Overloads Overrides Sub Paint(ByVal g As System.Drawing.Graphics, ByVal bounds As System.Drawing.Rectangle, ByVal _
'    [source] As System.Windows.Forms.CurrencyManager, ByVal rowNum As Integer, ByVal backBrush As System.Drawing.Brush, ByVal foreBrush As _
'    System.Drawing.Brush, ByVal alignToRight As Boolean)

'        Dim parent As DataGrid = Me.DataGridTableStyle.DataGrid
'        Dim BackColor As Color
'        BackColor = parent.AlternatingBackColor

'        'clear the cell
'        g.FillRectangle(New SolidBrush(BackColor), bounds)

'        'draw the value
'        Dim s As String = Me.GetColumnValueAtRow([source], rowNum).ToString()
'        DrawButton(g, _buttonFace, bounds, rowNum)

'    End Sub 'Paint 'font.Dispose();

'End Class 'DataGridButtonColumn

'Public Delegate Sub DataGridCellButtonClickEventHandler(ByVal sender As Object, ByVal e As DataGridCellButtonClickEventArgs)

'Public Class DataGridCellButtonClickEventArgs

'    Inherits EventArgs
'    Private _row As Integer
'    Private _col As Integer

'    Public Sub New(ByVal row As Integer, ByVal col As Integer)
'        _row = row
'        _col = col
'    End Sub 'New

'    Public ReadOnly Property RowIndex() As Integer
'        Get
'            Return _row
'        End Get
'    End Property

'    Public ReadOnly Property ColIndex() As Integer
'        Get
'            Return _col
'        End Get
'    End Property

'End Class
