Imports System.Data.SqlClient
Imports System.Windows.Forms
Public Class frmC_Cargos
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents pnlSuperior As System.Windows.Forms.Panel
    Friend WithEvents txtDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents cboDescripcion As System.Windows.Forms.ComboBox
    Friend WithEvents gpbTipoCargo As System.Windows.Forms.GroupBox
    Friend WithEvents chkGT As System.Windows.Forms.CheckBox
    Friend WithEvents lblGT As System.Windows.Forms.Label
    Friend WithEvents chkSC As System.Windows.Forms.CheckBox
    Friend WithEvents chkCT As System.Windows.Forms.CheckBox
    Friend WithEvents chkComite As System.Windows.Forms.CheckBox
    Friend WithEvents lblSC As System.Windows.Forms.Label
    Friend WithEvents lblCT As System.Windows.Forms.Label
    Friend WithEvents lblComite As System.Windows.Forms.Label
    Friend WithEvents txtClave As System.Windows.Forms.TextBox
    Friend WithEvents lblDescripcion As System.Windows.Forms.Label
    Friend WithEvents lblClave As System.Windows.Forms.Label
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdNivel As System.Windows.Forms.ToolBarButton
    Friend WithEvents lblactivo As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmC_Cargos))
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.pnlSuperior = New System.Windows.Forms.Panel
        Me.lblactivo = New System.Windows.Forms.Label
        Me.txtDescripcion = New System.Windows.Forms.TextBox
        Me.cboDescripcion = New System.Windows.Forms.ComboBox
        Me.gpbTipoCargo = New System.Windows.Forms.GroupBox
        Me.chkGT = New System.Windows.Forms.CheckBox
        Me.lblGT = New System.Windows.Forms.Label
        Me.chkSC = New System.Windows.Forms.CheckBox
        Me.chkCT = New System.Windows.Forms.CheckBox
        Me.chkComite = New System.Windows.Forms.CheckBox
        Me.lblSC = New System.Windows.Forms.Label
        Me.lblCT = New System.Windows.Forms.Label
        Me.lblComite = New System.Windows.Forms.Label
        Me.txtClave = New System.Windows.Forms.TextBox
        Me.lblDescripcion = New System.Windows.Forms.Label
        Me.lblClave = New System.Windows.Forms.Label
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.cmdNivel = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.pnlSuperior.SuspendLayout()
        Me.gpbTipoCargo.SuspendLayout()
        Me.SuspendLayout()
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'pnlSuperior
        '
        Me.pnlSuperior.Controls.Add(Me.lblactivo)
        Me.pnlSuperior.Controls.Add(Me.txtDescripcion)
        Me.pnlSuperior.Controls.Add(Me.cboDescripcion)
        Me.pnlSuperior.Controls.Add(Me.gpbTipoCargo)
        Me.pnlSuperior.Controls.Add(Me.txtClave)
        Me.pnlSuperior.Controls.Add(Me.lblDescripcion)
        Me.pnlSuperior.Controls.Add(Me.lblClave)
        Me.pnlSuperior.Cursor = System.Windows.Forms.Cursors.Default
        Me.pnlSuperior.Location = New System.Drawing.Point(8, 3)
        Me.pnlSuperior.Name = "pnlSuperior"
        Me.pnlSuperior.Size = New System.Drawing.Size(564, 196)
        Me.pnlSuperior.TabIndex = 50
        '
        'lblactivo
        '
        Me.lblactivo.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblactivo.Location = New System.Drawing.Point(272, 144)
        Me.lblactivo.Name = "lblactivo"
        Me.lblactivo.Size = New System.Drawing.Size(264, 40)
        Me.lblactivo.TabIndex = 55
        '
        'txtDescripcion
        '
        Me.txtDescripcion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescripcion.Location = New System.Drawing.Point(105, 33)
        Me.txtDescripcion.Name = "txtDescripcion"
        Me.txtDescripcion.Size = New System.Drawing.Size(407, 20)
        Me.txtDescripcion.TabIndex = 54
        Me.txtDescripcion.Text = ""
        '
        'cboDescripcion
        '
        Me.cboDescripcion.Location = New System.Drawing.Point(104, 32)
        Me.cboDescripcion.Name = "cboDescripcion"
        Me.cboDescripcion.Size = New System.Drawing.Size(428, 21)
        Me.cboDescripcion.TabIndex = 53
        '
        'gpbTipoCargo
        '
        Me.gpbTipoCargo.Controls.Add(Me.chkGT)
        Me.gpbTipoCargo.Controls.Add(Me.lblGT)
        Me.gpbTipoCargo.Controls.Add(Me.chkSC)
        Me.gpbTipoCargo.Controls.Add(Me.chkCT)
        Me.gpbTipoCargo.Controls.Add(Me.chkComite)
        Me.gpbTipoCargo.Controls.Add(Me.lblSC)
        Me.gpbTipoCargo.Controls.Add(Me.lblCT)
        Me.gpbTipoCargo.Controls.Add(Me.lblComite)
        Me.gpbTipoCargo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gpbTipoCargo.Location = New System.Drawing.Point(104, 66)
        Me.gpbTipoCargo.Name = "gpbTipoCargo"
        Me.gpbTipoCargo.Size = New System.Drawing.Size(152, 121)
        Me.gpbTipoCargo.TabIndex = 52
        Me.gpbTipoCargo.TabStop = False
        Me.gpbTipoCargo.Text = "TIPO DE CARGO"
        '
        'chkGT
        '
        Me.chkGT.Location = New System.Drawing.Point(128, 98)
        Me.chkGT.Name = "chkGT"
        Me.chkGT.Size = New System.Drawing.Size(16, 16)
        Me.chkGT.TabIndex = 16
        Me.chkGT.Visible = False
        '
        'lblGT
        '
        Me.lblGT.AutoSize = True
        Me.lblGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGT.Location = New System.Drawing.Point(16, 98)
        Me.lblGT.Name = "lblGT"
        Me.lblGT.Size = New System.Drawing.Size(20, 16)
        Me.lblGT.TabIndex = 15
        Me.lblGT.Text = "GT"
        Me.lblGT.Visible = False
        '
        'chkSC
        '
        Me.chkSC.Location = New System.Drawing.Point(128, 74)
        Me.chkSC.Name = "chkSC"
        Me.chkSC.Size = New System.Drawing.Size(16, 16)
        Me.chkSC.TabIndex = 14
        '
        'chkCT
        '
        Me.chkCT.Location = New System.Drawing.Point(128, 50)
        Me.chkCT.Name = "chkCT"
        Me.chkCT.Size = New System.Drawing.Size(16, 16)
        Me.chkCT.TabIndex = 13
        '
        'chkComite
        '
        Me.chkComite.Location = New System.Drawing.Point(128, 26)
        Me.chkComite.Name = "chkComite"
        Me.chkComite.Size = New System.Drawing.Size(16, 16)
        Me.chkComite.TabIndex = 12
        '
        'lblSC
        '
        Me.lblSC.AutoSize = True
        Me.lblSC.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSC.Location = New System.Drawing.Point(16, 74)
        Me.lblSC.Name = "lblSC"
        Me.lblSC.Size = New System.Drawing.Size(39, 16)
        Me.lblSC.TabIndex = 8
        Me.lblSC.Text = "SC/GT"
        '
        'lblCT
        '
        Me.lblCT.AutoSize = True
        Me.lblCT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCT.Location = New System.Drawing.Point(16, 50)
        Me.lblCT.Name = "lblCT"
        Me.lblCT.Size = New System.Drawing.Size(89, 16)
        Me.lblCT.TabIndex = 7
        Me.lblCT.Text = "Comit� T�cnico"
        '
        'lblComite
        '
        Me.lblComite.AutoSize = True
        Me.lblComite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComite.Location = New System.Drawing.Point(16, 26)
        Me.lblComite.Name = "lblComite"
        Me.lblComite.Size = New System.Drawing.Size(46, 16)
        Me.lblComite.TabIndex = 6
        Me.lblComite.Text = "Comit�:"
        '
        'txtClave
        '
        Me.txtClave.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClave.Location = New System.Drawing.Point(104, 8)
        Me.txtClave.Name = "txtClave"
        Me.txtClave.Size = New System.Drawing.Size(304, 20)
        Me.txtClave.TabIndex = 51
        Me.txtClave.Text = ""
        '
        'lblDescripcion
        '
        Me.lblDescripcion.AutoSize = True
        Me.lblDescripcion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescripcion.Location = New System.Drawing.Point(8, 40)
        Me.lblDescripcion.Name = "lblDescripcion"
        Me.lblDescripcion.Size = New System.Drawing.Size(73, 16)
        Me.lblDescripcion.TabIndex = 49
        Me.lblDescripcion.Text = "Descripci�n:"
        '
        'lblClave
        '
        Me.lblClave.AutoSize = True
        Me.lblClave.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClave.Location = New System.Drawing.Point(8, 8)
        Me.lblClave.Name = "lblClave"
        Me.lblClave.Size = New System.Drawing.Size(41, 16)
        Me.lblClave.TabIndex = 48
        Me.lblClave.Text = "Clave: "
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.cmdNivel, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 208)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(576, 62)
        Me.tlbBotonera.TabIndex = 56
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Inactivar"
        '
        'cmdNivel
        '
        Me.cmdNivel.ImageIndex = 6
        Me.cmdNivel.Text = "Niveles"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'frmC_Cargos
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(576, 270)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.pnlSuperior)
        Me.Name = "frmC_Cargos"
        Me.Text = "Cat�logos de Cargos"
        Me.pnlSuperior.ResumeLayout(False)
        Me.gpbTipoCargo.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim objCargos As New clsCargos.C_Cargos("Principal", gUsuario, gPasswordSql)
    Dim cn As New SqlConnection
    'Dim objConexion As New clsConexionArchivo.clsConexionArchivo
    Dim objConexion As New clsConexion.cIsConexion

    Dim sTipoProceso As String 'para determinar si se agrega o edita
    Dim status As String
    Dim bandInactivo As Boolean

    Private Sub frmCatCar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Call Limpia_Campos(txtClave, cboDescripcion)

        Inactivos(txtClave)
        Call Carga_Combo()
    End Sub

    Sub Carga_Combo()
        Limpia_Campos(txtClave, txtDescripcion)
        Activos(cmdAgregar, cmdEditar)
        Oculta(txtDescripcion)
        Muestra(cboDescripcion)
        Inactivos(cmdGuardar, cmdDeshacer, chkComite, chkCT, chkSC, chkGT)
        'Inactivos(txtClave, chkComite, chkCT, chkSC, chkGT)

        'Oculta(txtDescripcion)
        'Muestra(cboDescripcion)

        'cboDescripcion.Items.Clear()
        ''Dim dt As New DataTable
        ''Dim i As Integer
        objCargos.Bandera = 2

        objCargos.ListaCombo(cboDescripcion) 'funfiona
        If objCargos Is Nothing Then
            cboDescripcion.Items.Add("Lista vacia")
            txtDescripcion.Text = "Lista vacia"
            Exit Sub
        End If

        'txtDescripcion.Text = cboDescripcion.SelectedText 'funciona
        ''i = cboDescripcion.SelectedValue
        ''txtClave.Text = i

        '''objCargos.Bandera = 2
        '''objCargos.ListaCombo()
        ''''If dt Is Nothing Then
        '''If objCargos Is Nothing Then
        '''    cboDescripcion.Items.Add("Lista vacia")
        '''    txtDescripcion.Text = "Lista vacia"
        '''    'cboDescripcion.DisplayMember = ("Lista vacia")
        '''    Exit Sub
        '''End If
        '''''cboDescripcion.DataSource = dt
        '''''cboDescripcion.DisplayMember = dt.Columns(0).ColumnName
        '''''cboDescripcion.ValueMember = dt.Columns(0).ColumnName
        ''''''txtDescripcion.Text = dt.Columns(0).ColumnName
        '''txtDescripcion.Text = cboDescripcion.SelectedText
        '''i = cboDescripcion.SelectedValue
        '''txtClave.Text = i
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs)
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                sTipoProceso = "Agregar"
                Call Agregar()

            Case 2 'EDITAR
                sTipoProceso = "Editar"
                Call Editar()
                Activos(cmdDeshacer, cmdGuardar)

            Case 3 'DESHACER
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                If sTipoProceso = "Agregar" Then
                    Call Carga_Combo()
                ElseIf sTipoProceso = "Editar" Then
                    Activos(cmdAgregar, cmdEditar)
                    Oculta(txtDescripcion)
                    Muestra(cboDescripcion)
                    Inactivos(cmdDeshacer, cmdGuardar, chkComite, chkCT, chkSC, chkGT)
                End If
                sTipoProceso = ""
            Case 4 'GUARDAR
                Call Guardar()

            Case 5 'BORRAR
                'Call Borrar()
                Inactivos(cmdAgregar, cmdEditar, cmdSalir)
                If MsgBox("�Estas seguro que deseas eliminar esta Descripci�n?", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    'Habilita("Nulo")

                    Call Borrar()
                    'Oculta(GpBoxAgrega)
                    'Muestra(GpBoxLectura)
                    'iEditar = 0
                    'txtDescripcion.Text = ""
                    Call Carga_Combo()
                End If
                Activos(cmdAgregar, cmdEditar, cmdSalir)

            Case 7 'SALIR
                Me.Close()
        End Select
    End Sub

    Private Sub cboDescripcion_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDescripcion.SelectedIndexChanged
        txtClave.Text = cboDescripcion.SelectedValue
        'txtDescripcion.Text = cboDescripcion.Text
        Call Clave()
        If lblactivo.Text = "Activo" Then
            tlbBotonera.Buttons.Item(5).Text = "Inactivar"
        Else
            tlbBotonera.Buttons.Item(5).Text = "Activar"
        End If
    End Sub

    Private Sub Agregar()
        
        Oculta(cboDescripcion)
        txtDescripcion.Text = ""
        txtClave.Text = ""
        Muestra(txtDescripcion)
        Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
        Activos(cmdGuardar, cmdDeshacer, cmdSalir, chkComite, chkCT, chkSC, chkGT)
    End Sub

    Private Sub Editar()
        Oculta(cboDescripcion)
        txtDescripcion.Text = cboDescripcion.Text
        Muestra(txtDescripcion)
        Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
        Activos(chkComite, chkCT, chkSC, chkGT)
    End Sub

    Private Sub Guardar()
        If txtDescripcion.Text = "" Then
            MsgBox("Descripci�n vac�a", MsgBoxStyle.Exclamation, "Cat�logos de Cargos")
            Exit Sub
        End If

        If sTipoProceso = "Agregar" Then '******************************AGREGAR
            objCargos.Bandera = 1
            objCargos.Descripcion = txtDescripcion.Text
            If chkComite.CheckState = CheckState.Checked Then objCargos.Comite = 1 Else objCargos.Comite = 0
            If chkCT.CheckState = CheckState.Checked Then objCargos.CT = 1 Else objCargos.CT = 0
            If chkSC.CheckState = CheckState.Checked Then objCargos.SC = 1 Else objCargos.SC = 0
            If chkSC.CheckState = CheckState.Checked Then objCargos.GT = 1 Else objCargos.GT = 0 'debe de ir GC
            objCargos.Insertar()
            Call Carga_Combo()

        ElseIf sTipoProceso = "Editar" Then '***************************EDITAR

            objCargos.Bandera = 2
            objCargos.Descripcion = txtDescripcion.Text
            objCargos.ID_Cargo = txtClave.Text
            If chkComite.CheckState = CheckState.Checked Then objCargos.Comite = 1 Else objCargos.Comite = 0
            If chkCT.CheckState = CheckState.Checked Then objCargos.CT = 1 Else objCargos.CT = 0
            If chkSC.CheckState = CheckState.Checked Then objCargos.SC = 1 Else objCargos.SC = 0
            If chkSC.CheckState = CheckState.Checked Then objCargos.GT = 1 Else objCargos.GT = 0 'debe de ir GC
            objCargos.Actualizar()
            Call Carga_Combo()
        End If
    End Sub

    Private Sub Clave()
        objCargos.Bandera = 1
        'objCargos.ID_Cargo = txtClave.Text
        'objCargos.ID_Cargo = cboDescripcion.SelectedValue
        objCargos.Descripcion = cboDescripcion.Text
        objCargos.Buscar()
        If objCargos.Comite = True Then chkComite.Checked = True Else chkComite.Checked = False
        If objCargos.CT = True Then chkCT.Checked = True Else chkCT.Checked = False
        If objCargos.SC = True Then chkSC.Checked = True Else chkSC.Checked = False
        If objCargos.SC = True Then chkGT.Checked = True Else chkGT.Checked = False 'objCargos.GT

        'Inactivo/Activo
        Select Case objCargos.Inactivo
            Case True
                lblactivo.Text = "Inactivo"
            Case False
                lblactivo.Text = "Activo"
        End Select

    End Sub

    Private Sub Borrar()
        objCargos.ID_Cargo = txtClave.Text
        objCargos.Bandera = 3
        objCargos.Inactivo = bandInactivo
        objCargos.Eliminar()
        Call Carga_Combo()
    End Sub

    Private Sub tlbBotonera_ButtonClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                sTipoProceso = "Agregar"
                Call Agregar()
                LimpiarChk(chkComite, chkCT, chkSC, chkGT)
            Case 2 'EDITAR
                sTipoProceso = "Editar"
                Call Editar()
                Activos(cmdDeshacer, cmdGuardar)

            Case 3 'DESHACER
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                If sTipoProceso = "Agregar" Then
                    Call Carga_Combo()
                ElseIf sTipoProceso = "Editar" Then
                    Activos(cmdAgregar, cmdEditar, cmdBorrar)
                    Oculta(txtDescripcion)
                    Muestra(cboDescripcion)
                    Inactivos(cmdDeshacer, cmdGuardar, chkComite, chkCT, chkSC, chkGT)
                End If
                sTipoProceso = ""
            Case 4 'GUARDAR
                Call Guardar()
                tlbBotonera.Buttons.Item(5).Enabled = True
            Case 5 'BORRAR
                'Call Borrar()
                Inactivos(cmdAgregar, cmdEditar, cmdSalir)
                If lblactivo.Text = "Activo" Then
                    If MsgBox("�Estas seguro que deseas Inactivarlo?", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        bandInactivo = True
                    Else
                        Exit Sub
                    End If
                Else
                    If MsgBox("�Estas seguro que deseas Activarlo?", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        bandInactivo = False
                    Else
                        Exit Sub
                    End If
                End If

                Call Borrar()
                'Oculta(GpBoxAgrega)
                'Muestra(GpBoxLectura)
                'iEditar = 0
                'txtDescripcion.Text = ""
                Call Carga_Combo()
                Activos(cmdAgregar, cmdEditar, cmdSalir)
            Case 6
                    Dim frmnivel As New Frmc_cargosnivel
                    frmnivel.MdiParent = Me.MdiParent
                    frmnivel.Show()
            Case 8 'SALIR
                    Me.Close()
        End Select
    End Sub
    Private Sub LimpiarChk(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Checked = False
        Next objeto
    End Sub
End Class
