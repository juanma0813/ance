Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections


Public Class FrmCateRevEdt
    Inherits System.Windows.Forms.Form

    Dim ValEditar, iEditar As Integer
    Dim objclscategoria As New Cls_Tipos_RevEdit.Cls_tipos_RE("principal", gUsuario, gPasswordSql)   'Identif, Usuario, Password

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()
        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TxtDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CmbCategorias As System.Windows.Forms.ComboBox
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmCateRevEdt))
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.TxtDescripcion = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.CmbCategorias = New System.Windows.Forms.ComboBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.SuspendLayout()
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.BlinkRate = 1000
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'TxtDescripcion
        '
        Me.TxtDescripcion.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDescripcion.Location = New System.Drawing.Point(104, 56)
        Me.TxtDescripcion.MaxLength = 50
        Me.TxtDescripcion.Name = "TxtDescripcion"
        Me.TxtDescripcion.Size = New System.Drawing.Size(248, 19)
        Me.TxtDescripcion.TabIndex = 50
        Me.TxtDescripcion.Text = ""
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(32, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 51
        Me.Label2.Text = "Descripci�n:"
        '
        'CmbCategorias
        '
        Me.CmbCategorias.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbCategorias.Location = New System.Drawing.Point(104, 56)
        Me.CmbCategorias.Name = "CmbCategorias"
        Me.CmbCategorias.Size = New System.Drawing.Size(248, 21)
        Me.CmbCategorias.TabIndex = 52
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.CmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 125)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(402, 62)
        Me.tlbBotonera.TabIndex = 53
        Me.tlbBotonera.TabStop = True
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 3
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 2
        Me.cmdGuardar.Text = "Guardar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Eliminar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 4
        Me.cmdSalir.Text = "Salir"
        '
        'FrmCateRevEdt
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 12)
        Me.ClientSize = New System.Drawing.Size(402, 187)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.CmbCategorias)
        Me.Controls.Add(Me.TxtDescripcion)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Arial", 8.372093!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmCateRevEdt"
        Me.Text = "Categor�as de Revisi�n Editorial"
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

#Region " Funci�n - Eliminar, Metodos y Procesos"

    Private Function Eliminar() As Boolean
        Dim iregistros As Integer()
        Try
            If Len(ValEditar) > 0 Then
                objclscategoria.Bandera = 5
                objclscategoria.Id_tipo_Rev = ValEditar
                objclscategoria.Inactivo = 1
                objclscategoria.borrar()
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
#End Region

#Region " Funci�n - Guardar, Metodos y Procesos"

    Private Function Guardar() As Boolean
        Try
            Dim iregistros As Integer
            If iEditar = 1 Then
                If Len(ValEditar) > 0 Then
                    objclscategoria.Id_tipo_Rev = ValEditar
                    objclscategoria.Bandera = 3
                    objclscategoria.Nombre_Revision = (TxtDescripcion.Text)
                    objclscategoria.Actualizar()
                End If
            Else
                objclscategoria.Bandera = 1
                objclscategoria.Nombre_Revision = TxtDescripcion.Text
                objclscategoria.Insertar()
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

#Region " Funci�n - valida(Casos), Metodos y Procesos"

    Private Function valida(ByVal casos As String) As Boolean
        Select Case casos
            Case "desc"
                If TxtDescripcion.Text = "" Then
                    ErrorProvider1.SetError(TxtDescripcion, "Debes escribir la Categoria")
                    Return False
                Else
                    ErrorProvider1.SetError(TxtDescripcion, "")
                    Activos(tlbBotonera.Buttons(4))
                    Return True
                End If
        End Select
    End Function

#End Region

#End Region

#Region " ComboBox - CmbCategorias_SelectedIndexChanged, Metodos y Procesos"

    Private Sub CmbCategorias_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbCategorias.SelectedIndexChanged
        ErrorProvider1.SetError(Me.CmbCategorias, "")
    End Sub

#End Region

#Region "Forms - FrmCateRevEdt_Load, Metodos y Procesos"

    Private Sub FrmCateRevEdt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Oculta(TxtDescripcion)
        Muestra(CmbCategorias)
        objclscategoria.Bandera = 1
        objclscategoria.ListaCombo(CmbCategorias)
        Inactivos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
    End Sub

#End Region

#Region "ToolBar - tlbBotonera_ButtonClick, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1
                iEditar = 0
                TxtDescripcion.Text = ""
                Muestra(TxtDescripcion)
                Oculta(CmbCategorias)
                Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5))
                Activos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
            Case 2
                If CmbCategorias.SelectedValue <> 0 Then
                    ValEditar = CmbCategorias.SelectedValue
                    TxtDescripcion.Text = CmbCategorias.Text
                    iEditar = 1
                    Muestra(TxtDescripcion)
                    Oculta(CmbCategorias)
                    Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5))
                    Activos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
                End If
            Case 3
                Oculta(TxtDescripcion)
                Muestra(CmbCategorias)
                iEditar = 0
                TxtDescripcion.Text = ""
                Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5))
                Inactivos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
            Case 4
                Inactivos(tlbBotonera)
                If valida("desc") Then
                    Call Guardar()
                    iEditar = 0
                    TxtDescripcion.Text = ""
                    objclscategoria.Bandera = 1
                    objclscategoria.ListaCombo(CmbCategorias)
                End If
                Oculta(TxtDescripcion)
                Muestra(CmbCategorias)
                Activos(tlbBotonera, tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5))
                Inactivos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
            Case 5
                If iEditar = 0 Then ValEditar = CmbCategorias.SelectedValue
                ErrorProvider1.SetError(Me.CmbCategorias, "Estas a punto de eliminar esta Categoria")
                If MsgBox("�Estas seguro que deseas eliminar esta Categoria?", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    Call Eliminar()
                    iEditar = 0
                    TxtDescripcion.Text = ""
                    objclscategoria.Bandera = 1
                    objclscategoria.ListaCombo(CmbCategorias)
                Else
                    ErrorProvider1.SetError(Me.CmbCategorias, "Estabas a punto de eliminar esta Categoria")
                End If
                Activos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(2), tlbBotonera.Buttons(5))
                Inactivos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4))
            Case 7
                iEditar = 0
                Me.Dispose()
        End Select
    End Sub

#End Region

End Class
