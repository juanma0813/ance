Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class Cls_P_Rev_edit
    Private _Id_Rev_Edit As Integer
    Private _Id_Plan As String
    Private _Id_Tema As Integer
    Private _F_Entrega_Revisor As String
    Private _F_Compromiso_Revisor As String
    Private _F_Fin_Revisor As String
    Private _Id_Usuario_Revisor As String
    Private _Documento As String
    Private _Num_Pag_Rev_Edit As Integer
    Private _Fecha_Revision As String
    Private _Aprobado As Integer
    Private _Comentario As String
    Private _Total_Errores As Integer
    Private _Bandera As Integer
    Private _Error As String
    ' Conexion 

    Private cn As New SqlConnection
    Private dr As SqlDataReader
    Dim objConexion As New clsConexion.cIsConexion

#Region " C�digo generado por Lic. Mariano Ascencio, para el Constructor "
    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
    End Sub
#End Region

#Region " C�digo generado por Lic. Mariano Ascencio, para las Propiedades"

    Public Property Total_Errores() As Integer
        Get
            Return _Total_Errores
        End Get
        Set(ByVal Value As Integer)
            _Total_Errores = Value
        End Set
    End Property

    Public Property Id_Rev_Edit() As Integer
        Get
            Return _Id_Rev_Edit
        End Get
        Set(ByVal Value As Integer)
            _Id_Rev_Edit = Value
        End Set
    End Property

    Public Property Id_Tema() As Integer
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value As Integer)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Aprobado() As Integer
        Get
            Return _Aprobado
        End Get
        Set(ByVal Value As Integer)
            _Aprobado = Value
        End Set
    End Property

    Public Property Num_Pag_Rev_Edit() As Integer
        Get
            Return _Num_Pag_Rev_Edit
        End Get
        Set(ByVal Value As Integer)
            _Num_Pag_Rev_Edit = Value
        End Set
    End Property

    Public Property Comentario() As String
        Get
            Return _Comentario
        End Get
        Set(ByVal Value As String)
            _Comentario = Value
        End Set
    End Property

    Public Property Fecha_Revision() As String
        Get
            Return _Fecha_Revision
        End Get
        Set(ByVal Value As String)
            _Fecha_Revision = Value
        End Set
    End Property

    Public Property Documento() As String
        Get
            Return _Documento
        End Get
        Set(ByVal Value As String)
            _Documento = Value
        End Set
    End Property

    Public Property Id_Usuario_Revisor() As String
        Get
            Return _Id_Usuario_Revisor
        End Get
        Set(ByVal Value As String)
            _Id_Usuario_Revisor = Value
        End Set
    End Property

    Public Property F_Fin_Revisor() As String
        Get
            Return _F_Fin_Revisor
        End Get
        Set(ByVal Value As String)
            _F_Fin_Revisor = Value
        End Set
    End Property

    Public Property F_Compromiso_Revisor() As String
        Get
            Return _F_Compromiso_Revisor
        End Get
        Set(ByVal Value As String)
            _F_Compromiso_Revisor = Value
        End Set
    End Property

    Public Property F_Entrega_Revisor() As String
        Get
            Return _F_Entrega_Revisor
        End Get
        Set(ByVal Value As String)
            _F_Entrega_Revisor = Value
        End Set
    End Property

    Public Property Id_Plan() As String
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value As String)
            _Id_Plan = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property
#End Region

#Region "Metodos"

#Region " Funci�n -  Llena_parametros(cmd), Metodos"

    Private Function Llena_parametros(ByVal cmd As SqlCommand)
        With cmd
        If _Bandera = 1 Then
            .Parameters.Add("@Id_Rev_Edit2", SqlDbType.Int)
            .Parameters("@Id_Rev_Edit2").Direction = ParameterDirection.InputOutput
        End If
        .Parameters.Add("@Id_Rev_Edit", _Id_Rev_Edit)
        .Parameters.Add("@Id_Plan", _Id_Plan)
        .Parameters.Add("@Id_Tema", _Id_Tema)
        .Parameters.Add("@F_Entrega_Revisor", _F_Entrega_Revisor)
        .Parameters.Add("@F_Compromiso_Revisor", _F_Compromiso_Revisor)
        .Parameters.Add("@F_Fin_Revisor", _F_Fin_Revisor)
        .Parameters.Add("@Id_Usuario_Revisor", _Id_Usuario_Revisor)
        .Parameters.Add("@Documento", _Documento)
        .Parameters.Add("@Num_Pag_Rev_Edit", _Num_Pag_Rev_Edit)
        .Parameters.Add("@Fecha_Revision", _Fecha_Revision)
        .Parameters.Add("@Aprobado", _Aprobado)
        .Parameters.Add("@Total_Errores", _Total_Errores)
        .Parameters.Add("@Comentario", _Comentario)
            .Parameters.Add("@Bandera", _Bandera)
        End With
    End Function

#End Region

#Region " Sub - ListaCombo(Object), Metodos"

    Public Sub ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_p_Rev_Edit_buscar"
        cmd.Connection = cn
        Llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_RE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return
        End Try
    End Sub

#End Region

#Region " Funcion - Listar,  Metodos "

    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_p_Rev_Edit_buscar"
        cmd.Connection = cn
        Llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Cls_RE")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

#End Region

#Region " Sub - Buscar,  Metodos "

    Public Sub Buscar()

        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_p_Rev_Edit_buscar "
        cmd.Connection = cn
        Llena_parametros(cmd)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Rev_Edit = (IIf((IsDBNull(dr("Id_Rev_Edit"))), 0, dr("Id_Rev_Edit")))
                _Id_Plan = IIf((IsDBNull(dr("Id_Plan"))), "", dr("Id_Plan"))
                _Id_Tema = (IIf((IsDBNull(dr("Id_Tema"))), 0, dr("Id_Tema")))
                _F_Entrega_Revisor = IIf((IsDBNull(dr("F_Entrega_Revisor"))), "", dr("F_Entrega_Revisor"))
                _F_Compromiso_Revisor = IIf((IsDBNull(dr("F_Compromiso_Revisor"))), "", dr("F_Compromiso_Revisor"))
                _F_Fin_Revisor = IIf((IsDBNull(dr("F_Fin_Revisor"))), "", dr("F_Fin_Revisor"))
                _Id_Usuario_Revisor = IIf((IsDBNull(dr("Id_Usuario_Revisor"))), "", dr("Id_Usuario_Revisor"))
                _Documento = (IIf((IsDBNull(dr("Documento"))), "", dr("Documento")))
                _Num_Pag_Rev_Edit = (IIf((IsDBNull(dr("Num_Pag_Rev_Edit"))), 0, dr("Num_Pag_Rev_Edit")))
                _Fecha_Revision = (IIf((IsDBNull(dr("Fecha_Revision"))), "", dr("Fecha_Revision")))
                _Aprobado = (IIf((IsDBNull(dr("Aprobado"))), 0, dr("Aprobado")))
                _Total_Errores = (IIf((IsDBNull(dr("Total_Errores"))), 0, dr("Total_Errores")))
                _Comentario = (IIf((IsDBNull(dr("Descripcion"))), "", dr("Descripcion")))

            Else
                _Id_Rev_Edit = 0
                _Id_Plan = ""
                _Id_Tema = 0
                _F_Entrega_Revisor = ""
                _F_Compromiso_Revisor = ""
                _F_Fin_Revisor = ""
                _Id_Usuario_Revisor = ""
                _Documento = ""
                _Num_Pag_Rev_Edit = 0
                _Fecha_Revision = ""
                _Aprobado = 0
                _Total_Errores = 0
                _Comentario = ""
            End If
            cn.Close()
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Sub

#End Region

#Region " Funcion - Insertar, Metodos "

    Public Function Insertar() As Boolean
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_P_Rev_Edit"
        cmd.Connection = cn
        Llena_parametros(cmd)
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            If _Bandera = 1 Then
                _Id_Rev_Edit = IIf(IsDBNull(cmd.Parameters("@Id_Rev_Edit2").Value), -1, cmd.Parameters("@Id_Rev_Edit2").Value)
            End If
            cn.Close()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

#Region " Funcion - Actualizar, Metodos "

    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_p_Rev_Edit"
        cmd.Connection = cn
        Call Llena_parametros(cmd)
        Try
            cmd.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            _Error = "ERROR - Bandera " + _Bandera + " " + ex.Message
            Return False
        End Try
    End Function

#End Region

#End Region

End Class
