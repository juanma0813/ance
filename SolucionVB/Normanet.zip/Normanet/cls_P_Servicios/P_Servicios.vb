'*************************************************************************************
'  ESTOS SON LOS CAMPOS LLAVE QUE TIENE LA TABLA
'              Consecutivo
'*************************************************************************************
'Clase P_OpInternacionales Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 26/06/2006 05:00:06 p.m.
'*************************************************************************************

Option Explicit On 
Imports System
Imports System.Data.SqlClient
Imports System.Windows.Forms
Public Class P_Servicios

    '''''''Declaracion de Variables Privadas
    Private dsP_OpInternacionales As New DataSet
    Private _Ref_Clave As String
    Private _Ref_Consecutivo As String
    Private _Ref_Anio As String
    Private _Id_Cliente As Integer
    Private _Id_TPago As String
    Private _Id_Subservicio As String
    Private _Subtotal As Double
    Private _IVA As Double
    Private _Total As Double
    Private _TipoCambio As Double
    Private _F_Emision As Date
    Private _F_Envio As Date
    Private _Fec_Inicio As String
    Private _Fec_Termino As String
    Private _Fec_EntPais As String
    Private _Fec_SalPais As String
    Private _Ingreso_Letter As Byte
    Private _F_Ingreso_Letter As String
    Private _Contrato2 As Byte
    Private _F_Contrato2 As String
    Private _Precio_S_IVA As Double
    Private _Factura As Byte
    Private _F_Factura As String
    Private _Expediente_Legal As Byte
    Private _F_Expediente_Legal As String
    Private _Inspeccion_Proceso As String
    Private _Id_Ingeniero As String
    Private _Id_Status As Integer
    Private sSql As String
    '''Nuevo
    Private cn As New SqlClient.SqlConnection
    Private dr As SqlDataReader
    Private objconexion1 As New clsConexionArchivo.clsConexionArchivo
    Private iContador As Integer
    Private iEncontrados As Integer

    '''Declaracion de variables publicas
    Public Property Ref_Consecutivo()
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value)
            _Ref_Consecutivo = Value
        End Set
    End Property

    Public Property Ref_Clave()
        Get
            Return _Ref_Clave
        End Get
        Set(ByVal Value)
            _Ref_Clave = Value
        End Set
    End Property

    Public Property Ref_Anio()
        Get
            Return _Ref_Anio
        End Get
        Set(ByVal Value)
            _Ref_Anio = Value
        End Set
    End Property

    Public Property Id_Cliente()
        Get
            Return _Id_Cliente
        End Get
        Set(ByVal Value)
            _Id_Cliente = Value
        End Set
    End Property

    Public Property Id_TPago()
        Get
            Return _Id_TPago
        End Get
        Set(ByVal Value)
            _Id_TPago = Value
        End Set
    End Property

    Public Property Id_Subservicio()
        Get
            Return _Id_Subservicio
        End Get
        Set(ByVal Value)
            _Id_Subservicio = Value
        End Set
    End Property

    Public Property Subtotal()
        Get
            Return _Subtotal
        End Get
        Set(ByVal Value)
            _Subtotal = Value
        End Set
    End Property

    Public Property IVA()
        Get
            Return _IVA
        End Get
        Set(ByVal Value)
            _IVA = Value
        End Set
    End Property

    Public Property Total()
        Get
            Return _Total
        End Get
        Set(ByVal Value)
            _Total = Value
        End Set
    End Property

    Public Property TipoCambio()
        Get
            Return _TipoCambio
        End Get
        Set(ByVal Value)
            _TipoCambio = Value
        End Set
    End Property

    Public Property F_Emision()
        Get
            Return _F_Emision
        End Get
        Set(ByVal Value)
            _F_Emision = Value
        End Set
    End Property


    Public Property F_Envio()
        Get
            Return _F_Envio
        End Get
        Set(ByVal Value)
            _F_Envio = Value
        End Set
    End Property

    Public Property Fec_Inicio()
        Get
            Return _Fec_Inicio
        End Get
        Set(ByVal Value)
            _Fec_Inicio = Value
        End Set
    End Property

    Public Property Fec_Termino()
        Get
            Return _Fec_Termino
        End Get
        Set(ByVal Value)
            _Fec_Termino = Value
        End Set
    End Property

    Public Property Fec_EntPais()
        Get
            Return _Fec_EntPais
        End Get
        Set(ByVal Value)
            _Fec_EntPais = Value
        End Set
    End Property

    Public Property Fec_SalPais()
        Get
            Return _Fec_SalPais
        End Get
        Set(ByVal Value)
            _Fec_SalPais = Value
        End Set
    End Property

    Public Property Ingreso_Letter()
        Get
            Return _Ingreso_Letter
        End Get
        Set(ByVal Value)
            _Ingreso_Letter = Value
        End Set
    End Property

    Public Property F_Ingreso_Letter()
        Get
            Return _F_Ingreso_Letter
        End Get
        Set(ByVal Value)
            _F_Ingreso_Letter = Value
        End Set
    End Property

    Public Property Contrato2()
        Get
            Return _Contrato2
        End Get
        Set(ByVal Value)
            _Contrato2 = Value
        End Set
    End Property

    Public Property F_Contrato2()
        Get
            Return _F_Contrato2
        End Get
        Set(ByVal Value)
            _F_Contrato2 = Value
        End Set
    End Property

    Public Property Precio_S_IVA()
        Get
            Return _Precio_S_IVA
        End Get
        Set(ByVal Value)
            _Precio_S_IVA = Value
        End Set
    End Property

    Public Property Factura()
        Get
            Return _Factura
        End Get
        Set(ByVal Value)
            _Factura = Value
        End Set
    End Property

    Public Property F_Factura()
        Get
            Return _F_Factura
        End Get
        Set(ByVal Value)
            _F_Factura = Value
        End Set
    End Property

    Public Property Expediente_Legal()
        Get
            Return _Expediente_Legal
        End Get
        Set(ByVal Value)
            _Expediente_Legal = Value
        End Set
    End Property

    Public Property F_Expediente_Legal()
        Get
            Return _F_Expediente_Legal
        End Get
        Set(ByVal Value)
            _F_Expediente_Legal = Value
        End Set
    End Property

    Public Property Inspeccion_Proceso()
        Get
            Return _Inspeccion_Proceso
        End Get
        Set(ByVal Value)
            _Inspeccion_Proceso = Value
        End Set
    End Property

    Public Property Id_Ingeniero()
        Get
            Return _Id_Ingeniero
        End Get
        Set(ByVal Value)
            _Id_Ingeniero = Value
        End Set
    End Property

    Public Property Id_Status()
        Get
            Return _Id_Status
        End Get
        Set(ByVal Value)
            _Id_Status = Value
        End Set
    End Property

    '''''Genera una lista de los campos de la tabla P_OpInternacionales
    Public Function ListaCombo() As DataTable
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_OI_Buscar2"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 2)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_OpInternacionales")
        Try
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    Public Function ListaComboCot() As DataTable
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_OI_Buscar2"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 3)
        cmd.Parameters.Add("@Ref_Clave", _Ref_Clave)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Ref_A�o", _Ref_Anio)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_OpInternacionales")
        Try
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    'Public sub ListaCombo2(ByVal Clave As String, ByVal Consecutivo As String, ByVal A�o As String) As DataTable
    '    Dim cmd As New SqlCommand

    '    cmd.CommandType = CommandType.StoredProcedure
    '    cmd.CommandText = "sp_P_OI_Buscar2"
    '    cmd.Connection = cn
    '    cmd.Parameters.Add("@Ref_Clave", Clave)
    '    cmd.Parameters.Add("@Ref_Consecutivo", Consecutivo)
    '    cmd.Parameters.Add("@Ref_A�o", A�o)
    '    cmd.Parameters.Add("@Bandera", 2)
    '    Dim da As SqlDataAdapter
    '    Dim dt As New DataTable("P_OpInternacionales")
    '    Try
    '        da = New SqlDataAdapter(cmd)
    '        da.Fill(dt)
    '    Catch
    '    End Try
    'End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar()

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_OI_Buscar2"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 1)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Ref_Clave", _Ref_Clave)
        cmd.Parameters.Add("@Ref_A�o", _Ref_Anio)

        Dim dr As SqlDataReader
        cn.Open()
        dr = cmd.ExecuteReader
        If dr.Read Then

            _Ref_Clave = IIf((IsDBNull(dr("Ref_Clave"))), " ", dr("Ref_Clave"))
            _Ref_Consecutivo = IIf((IsDBNull(dr("Ref_Consecutivo"))), " ", dr("Ref_Consecutivo"))
            _Ref_Anio = IIf((IsDBNull(dr("Ref_A�o"))), " ", dr("Ref_A�o"))
            _Id_Cliente = IIf((IsDBNull(dr("Id_Cliente"))), " ", dr("Id_Cliente"))
            _Id_Subservicio = IIf((IsDBNull(dr("Id_Subservicio"))), " ", dr("Id_Subservicio"))
            _Subtotal = IIf((IsDBNull(dr("Subtotal"))), 0, dr("Subtotal"))
            _IVA = IIf((IsDBNull(dr("IVA"))), 0.15, dr("IVA"))
            _Total = IIf((IsDBNull(dr("Total"))), " ", dr("Total"))
            _TipoCambio = IIf((IsDBNull(dr("TipoCambio"))), " ", dr("TipoCambio"))
            _Id_Ingeniero = IIf((IsDBNull(dr("Id_Ingeniero"))), " ", dr("Id_Ingeniero"))
            _F_Emision = IIf((IsDBNull(dr("F_Emision"))), " ", dr("F_Emision"))
            _F_Envio = IIf((IsDBNull(dr("F_Envio"))), " ", dr("F_Envio"))
        Else

            _Ref_Clave = "OIC"
            _Ref_Consecutivo = "0"
            _Ref_Anio = ""
            _Id_Cliente = 0
            _Id_Subservicio = 0
            _Subtotal = 0
            _IVA = 0
            _Total = 0
            _TipoCambio = 0
            _Id_Ingeniero = 0
            _F_Emision = ""
            _F_Envio = ""
        End If
        cn.Close()
        cmd.Dispose()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_OI"
        cmd.Connection = cn

        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Ref_Clave", _Ref_Clave)
        cmd.Parameters.Add("@Id_Cliente", _Id_Cliente)
        cmd.Parameters.Add("@Id_TPago", _Id_TPago)
        cmd.Parameters.Add("@Subtotal", _Subtotal)
        cmd.Parameters.Add("@IVA", _IVA)
        cmd.Parameters.Add("@Total", _Total)
        cmd.Parameters.Add("@Fec_Inicio", _Fec_Inicio)
        cmd.Parameters.Add("@Fec_Termino", _Fec_Termino)
        cmd.Parameters.Add("@Fec_EntPais", _Fec_EntPais)
        cmd.Parameters.Add("@Fec_SalPais", _Fec_SalPais)
        cmd.Parameters.Add("@Ingreso_Letter", _Ingreso_Letter)
        cmd.Parameters.Add("@F_Ingreso_Letter", _F_Ingreso_Letter)
        cmd.Parameters.Add("@Contrato2", _Contrato2)
        cmd.Parameters.Add("@F_Contrato2", _F_Contrato2)
        cmd.Parameters.Add("@Precio_S_IVA", _Precio_S_IVA)
        cmd.Parameters.Add("@Factura", _Factura)
        cmd.Parameters.Add("@F_Factura", _F_Factura)
        cmd.Parameters.Add("@Expediente_Legal", _Expediente_Legal)
        cmd.Parameters.Add("@F_Expediente_Legal", _F_Expediente_Legal)
        cmd.Parameters.Add("@Inspeccion_Proceso", _Inspeccion_Proceso)
        cmd.Parameters.Add("@Id_Ingeniero", _Id_Ingeniero)
        cmd.Parameters.Add("@Id_Status", _Id_Status)
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        cn.Close()
        cmd.Dispose()
    End Function
    Public Function ActualizarDetalle(ByVal dt As DataTable, ByVal iTipoServicio As Integer) As String
        Dim Reg As DataRow
        For Each Reg In dt.Rows
            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_P_Cotizacion_Detalle"
            cmd.Connection = cn
            cmd.Parameters.Add("@Ref_Clave", _Ref_Clave)
            cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
            cmd.Parameters.Add("@ID_DETALLECOTIZACION", Reg(0))
            cmd.Parameters.Add("@ID_TIPOSERVICIO", iTipoServicio)
            cmd.Parameters.Add("@ID_SUBTIPOSERVICIO", Reg(1))
            cmd.Parameters.Add("@ID_NORMA", Reg(3))
            cmd.Parameters.Add("@PRECIO", Reg(4))
            cmd.Parameters.Add("@NOFAMILIASERVICIO", Reg(5))

            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            cmd.Dispose()
        Next
    End Function

    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_OpInternacionales"
        cmd.Connection = cn
        cmd.Parameters.Add("@Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Consecutivo", _Ref_Clave)
        cmd.Parameters.Add("@Id_Cliente", _Id_Cliente)
        cmd.Parameters.Add("@Id_TPago", _Id_TPago)
        cmd.Parameters.Add("@Subtotal", _Subtotal)
        cmd.Parameters.Add("@IVA", _IVA)
        cmd.Parameters.Add("@Total", _Total)
        cmd.Parameters.Add("@Fec_Inicio", _Fec_Inicio)
        cmd.Parameters.Add("@Fec_Termino", _Fec_Termino)
        cmd.Parameters.Add("@Fec_EntPais", _Fec_EntPais)
        cmd.Parameters.Add("@Fec_SalPais", _Fec_SalPais)
        cmd.Parameters.Add("@Ingreso_Letter", _Ingreso_Letter)
        cmd.Parameters.Add("@F_Ingreso_Letter", _F_Ingreso_Letter)
        cmd.Parameters.Add("@Contrato2", _Contrato2)
        cmd.Parameters.Add("@F_Contrato2", _F_Contrato2)
        cmd.Parameters.Add("@Precio_S_IVA", _Precio_S_IVA)
        cmd.Parameters.Add("@Factura", _Factura)
        cmd.Parameters.Add("@F_Factura", _F_Factura)
        cmd.Parameters.Add("@Expediente_Legal", _Expediente_Legal)
        cmd.Parameters.Add("@F_Expediente_Legal", _F_Expediente_Legal)
        cmd.Parameters.Add("@Inspeccion_Proceso", _Inspeccion_Proceso)
        cmd.Parameters.Add("@Id_Ingeniero", _Id_Ingeniero)
        cmd.Parameters.Add("@Id_Status", _Id_Status)
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cmd.Dispose()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        cmd.Dispose()
    End Function
    Public Sub inicia(ByVal Identificador As Integer, ByVal Usuario As String, ByVal Password As String)

        objconexion1.LeerIni(Application.StartupPath + "\Principal.INI", "Principal")
        cn.ConnectionString = "Data source = " + objconexion1.Server + "; Initial Catalog = " + objconexion1.Base + "; User Id = " + Usuario + "; Pwd =  " + Password

    End Sub

    Public Function LlenaGrid(ByVal sTipo As String) As DataTable
        '''Pone los encabezados del grid sin datos.
        Dim cmd As New SqlCommand
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_P_OI_Buscar2"
        cmd.Parameters.Add("@Ref_Clave", _Ref_Clave)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Ref_A�o", _Ref_Anio)
        cn.Open()
        Select Case sTipo
            Case "LAB"
                If dsP_OpInternacionales.Tables.Contains("P_GridLab") Then
                    dsP_OpInternacionales.Tables.Remove("P_GridLab")
                End If
                cmd.Parameters.Add("@Bandera", 10)
                da.Fill(dsP_OpInternacionales, "P_GridLab")
            Case "OCP"
                If dsP_OpInternacionales.Tables.Contains("P_GridOCP") Then
                    dsP_OpInternacionales.Tables.Remove("P_GridOCP")
                End If
                cmd.Parameters.Add("@Bandera", 11)
                da.Fill(dsP_OpInternacionales, "P_GridOCP")
            Case "UVA"
                If dsP_OpInternacionales.Tables.Contains("P_GridUVA") Then
                    dsP_OpInternacionales.Tables.Remove("P_GridUVA")
                End If
                cmd.Parameters.Add("@Bandera", 12)
                da.Fill(dsP_OpInternacionales, "P_GridUVA")

            Case "COMPLAB"
                If dsP_OpInternacionales.Tables.Contains("P_GridCompLAB") Then
                    dsP_OpInternacionales.Tables.Remove("P_GridCompLAB")
                End If
                cmd.Parameters.Add("@Bandera", 13)
                da.Fill(dsP_OpInternacionales, "P_GridCompLAB")

            Case "COMPOCP"
                If dsP_OpInternacionales.Tables.Contains("P_GridCompOCP") Then
                    dsP_OpInternacionales.Tables.Remove("P_GridCompOCP")
                End If
                cmd.Parameters.Add("@Bandera", 14)
                da.Fill(dsP_OpInternacionales, "P_GridCompOCP")

            Case "COMPUVA"
                If dsP_OpInternacionales.Tables.Contains("P_GridCompUVA") Then
                    dsP_OpInternacionales.Tables.Remove("P_GridCompUVA")
                End If
                cmd.Parameters.Add("@Bandera", 15)
                da.Fill(dsP_OpInternacionales, "P_GridCompUVA")

        End Select

        cn.Close()
        cmd.Dispose()
        da.Dispose()

        Select Case sTipo
            Case "LAB"
                Return dsP_OpInternacionales.Tables("P_GridLab")
            Case "OCP"
                Return dsP_OpInternacionales.Tables("P_GridOCP")
            Case "UVA"
                Return dsP_OpInternacionales.Tables("P_GridUVA")
            Case "COMPLAB"
                Return dsP_OpInternacionales.Tables("P_GridCompLAB")
            Case "COMPOCP"
                Return dsP_OpInternacionales.Tables("P_GridCompOCP")
            Case "COMPUVA"
                Return dsP_OpInternacionales.Tables("P_GridCompUVA")

        End Select

    End Function

    ''Funci�n para llenar el grid de detalle con las datos del tipo de servicio
    Public Function DetalleGrid(ByVal Id_Tipo As String, ByVal Ref_Consecutivo As String, ByRef ds As DataSet) As DataSet
        Dim cmd As New SqlCommand
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_Cotizacion_Detalle"
        cmd.Parameters.Add("@Id_Tipo", Id_Tipo)
        cmd.Parameters.Add("@Ref_Consecutivo", Ref_Consecutivo)
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(ds, "P_CotizacionDetalle")
        cmd.ExecuteNonQuery()
        cn.Close()
        cmd.Dispose()
        iEncontrados = ds.Tables("P_CotizacionDetalle").Rows.Count
        Return ds

    End Function
End Class
