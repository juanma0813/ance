Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports System.IO
Imports System.Math


Public Class frmC_Normas
    Inherits System.Windows.Forms.Form
    Dim sTipoProceso As String
    Dim objNormas As New clsCatalogoNormas.C_Normas(0, gUsuario, gPasswordSql) 'yhujiyiy
    Shared NormaClasificacion As String
    Public gbArchivos As Boolean = False

    '''Dim dtAgrega As New DataTable
    '''Dim drAgrega As DataRow

    Dim sEtapaGrid As String
    Dim dvComite As DataView
    Dim objComites As New clsComites.clsComites(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim clsDoctosTemas As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)
    Private objInspeccionPrueba As New ClsInspeccionPruebas.ClsInspeccionPruebas(0, gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray
    Public RutaNormaFinal As String
    Public adjunta As Boolean

    Dim clsCopia As New ClsCopiaArchivos.ClsCopiaArchivos
    Dim iCaso As Integer
    Dim cn As New SqlConnection
    Dim RutaUno As String
    Dim RutaDos As String

    Dim srefP As String
    Dim ID_Plan As String
    Dim ID_Tema As String
    Dim objConexion As New clsConexion.cIsConexion

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents cboClasificacion As System.Windows.Forms.ComboBox
    Friend WithEvents cboCancelada As System.Windows.Forms.ComboBox
    Friend WithEvents lblClasificacion As System.Windows.Forms.Label
    Friend WithEvents lblCancelada As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtTIE As System.Windows.Forms.TextBox
    Friend WithEvents txtTII As System.Windows.Forms.TextBox
    Friend WithEvents lblPaginas As System.Windows.Forms.Label
    Friend WithEvents txtPaginas As System.Windows.Forms.TextBox
    Friend WithEvents lblConcordancia As System.Windows.Forms.Label
    Friend WithEvents lblResponsable As System.Windows.Forms.Label
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents grdCanceladas As System.Windows.Forms.DataGrid
    Friend WithEvents grdConcordancia As System.Windows.Forms.DataGrid
    Friend WithEvents lblVigencia As System.Windows.Forms.Label
    Friend WithEvents txtObjetivo As System.Windows.Forms.TextBox
    Friend WithEvents lblObjetivo As System.Windows.Forms.Label
    Friend WithEvents cboConcordancia As System.Windows.Forms.ComboBox
    Friend WithEvents lblFechaEntradaVigor As System.Windows.Forms.Label
    Friend WithEvents txtDeclaratoria As System.Windows.Forms.TextBox
    Friend WithEvents lblBibliografia As System.Windows.Forms.Label
    Friend WithEvents txtEntradaVigor As System.Windows.Forms.TextBox
    Friend WithEvents txtBibliografia As System.Windows.Forms.TextBox
    Friend WithEvents lblComite As System.Windows.Forms.Label
    Friend WithEvents lblCT As System.Windows.Forms.Label
    Friend WithEvents lblSC As System.Windows.Forms.Label
    Friend WithEvents lblGT As System.Windows.Forms.Label
    Friend WithEvents txtComite As System.Windows.Forms.TextBox
    Friend WithEvents txtCT As System.Windows.Forms.TextBox
    Friend WithEvents txtSC As System.Windows.Forms.TextBox
    Friend WithEvents txtGT As System.Windows.Forms.TextBox
    Friend WithEvents cmdConcordancia As System.Windows.Forms.Button
    Friend WithEvents cmdComites As System.Windows.Forms.Button
    Friend WithEvents gpbInternacional As System.Windows.Forms.GroupBox
    Friend WithEvents lblAdoptada As System.Windows.Forms.Label
    Friend WithEvents cmdAdoptada As System.Windows.Forms.Button
    Friend WithEvents chkAdoptada As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblArmonizada As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents lblNMX As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents lblNRF As System.Windows.Forms.Label
    Friend WithEvents txtClasificacionCSA As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionUL As System.Windows.Forms.TextBox
    Friend WithEvents txtTituloUL As System.Windows.Forms.TextBox
    Friend WithEvents txtTituloCSA As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionNOM As System.Windows.Forms.TextBox
    Friend WithEvents txtTituloNMX As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionNMX As System.Windows.Forms.TextBox
    Friend WithEvents txtTituloNRF As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionNRF As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents txtFecEnvioDGN As System.Windows.Forms.TextBox
    Friend WithEvents txtFecResolucionComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecAprobacionCONANCE As System.Windows.Forms.TextBox
    Friend WithEvents txtFecAprobacionCTGT As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTituloAdoptado As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionAdoptada As System.Windows.Forms.TextBox
    Friend WithEvents chkArmonizada As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents lblClasificacionAdoptada As System.Windows.Forms.Label
    Friend WithEvents lblTituloAdoptado As System.Windows.Forms.Label
    Friend WithEvents lblClasificacionUL As System.Windows.Forms.Label
    Friend WithEvents lblTituloUL As System.Windows.Forms.Label
    Friend WithEvents lblClasificacionCSA As System.Windows.Forms.Label
    Friend WithEvents lblTituloCSA As System.Windows.Forms.Label
    Friend WithEvents lblClasificacionNOM As System.Windows.Forms.Label
    Friend WithEvents lblClasificaionNOM As System.Windows.Forms.Label
    Friend WithEvents lblClasificacionNMX As System.Windows.Forms.Label
    Friend WithEvents lblTituloNMX As System.Windows.Forms.Label
    Friend WithEvents lbltClasificacionNRF As System.Windows.Forms.Label
    Friend WithEvents lblTituloNRF As System.Windows.Forms.Label
    Friend WithEvents lblFecIinicioDesarrollo As System.Windows.Forms.Label
    Friend WithEvents lbltFecAprobacionCTGT As System.Windows.Forms.Label
    Friend WithEvents lblFecAprobacionCONANCE As System.Windows.Forms.Label
    Friend WithEvents lblFecResolucionComentarios As System.Windows.Forms.Label
    Friend WithEvents lblFecEnvioDGN As System.Windows.Forms.Label
    Friend WithEvents txtRevisionQuinquenal As System.Windows.Forms.TextBox
    Friend WithEvents lblRevisionQuinquenal As System.Windows.Forms.Label
    Friend WithEvents lblPublicacionConsulta As System.Windows.Forms.Label
    Friend WithEvents txtPublicacionConsulta As System.Windows.Forms.TextBox
    Friend WithEvents txtDeclaratoriaVigencia As System.Windows.Forms.TextBox
    Friend WithEvents txtFechaLimite As System.Windows.Forms.TextBox
    Friend WithEvents lblDeclaratoriaVigencia As System.Windows.Forms.Label
    Friend WithEvents lblFechaLimite As System.Windows.Forms.Label
    Friend WithEvents txtNotificacionModificacion As System.Windows.Forms.TextBox
    Friend WithEvents lblNotificacionRatificacion As System.Windows.Forms.Label
    Friend WithEvents lblNotificacionModificacion As System.Windows.Forms.Label
    Friend WithEvents txtNotificacionRatificacion As System.Windows.Forms.TextBox
    Friend WithEvents cmdArmonizada As System.Windows.Forms.Button
    Friend WithEvents chkNOM As System.Windows.Forms.CheckBox
    Friend WithEvents cmdNOM As System.Windows.Forms.Button
    Friend WithEvents chkNMX As System.Windows.Forms.CheckBox
    Friend WithEvents cmdNMX As System.Windows.Forms.Button
    Friend WithEvents chkNRF As System.Windows.Forms.CheckBox
    Friend WithEvents cmdNRF As System.Windows.Forms.Button
    Friend WithEvents grdAdoptada As System.Windows.Forms.DataGrid
    Friend WithEvents grdArmonizada As System.Windows.Forms.DataGrid
    Friend WithEvents grdNOM As System.Windows.Forms.DataGrid
    Friend WithEvents grdNMX As System.Windows.Forms.DataGrid
    Friend WithEvents grdNRF As System.Windows.Forms.DataGrid
    Friend WithEvents txtDoctoNorma As System.Windows.Forms.TextBox
    Friend WithEvents lblDoctoNorma As System.Windows.Forms.Label
    Friend WithEvents txtFecUno As System.Windows.Forms.TextBox
    Friend WithEvents lblFecUno As System.Windows.Forms.Label
    Friend WithEvents txtDoctoUno As System.Windows.Forms.TextBox
    Friend WithEvents lblDoctoUno As System.Windows.Forms.Label
    Friend WithEvents lblDocDos As System.Windows.Forms.Label
    Friend WithEvents txtFecDos As System.Windows.Forms.TextBox
    Friend WithEvents lblFecDos As System.Windows.Forms.Label
    Friend WithEvents txtFecInicioDesarrollo As System.Windows.Forms.TextBox
    Friend WithEvents cmdCanceladas As System.Windows.Forms.Button
    Friend WithEvents txtTituloNOM As System.Windows.Forms.TextBox
    Friend WithEvents txtDoctoDos As System.Windows.Forms.TextBox
    Friend WithEvents lblNomClasificacion As System.Windows.Forms.Label
    Friend WithEvents txtOrganismo As System.Windows.Forms.TextBox
    Friend WithEvents txtConsecutivo As System.Windows.Forms.TextBox
    Friend WithEvents txtRamaIndustrial As System.Windows.Forms.TextBox
    Friend WithEvents txtA�o As System.Windows.Forms.TextBox
    Friend WithEvents gpbx As System.Windows.Forms.GroupBox
    Friend WithEvents dtkDeclaratoria As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkEntradaVigor As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkNotificacionRatificacion As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkNotificacionModificacion As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkFecUno As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkFecDos As System.Windows.Forms.DateTimePicker
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents cmdComitesGuardar As System.Windows.Forms.Button
    Friend WithEvents lblSB As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents lblSubirDoctoUno As System.Windows.Forms.Label
    Friend WithEvents lblSubirDoctoDos As System.Windows.Forms.Label
    Friend WithEvents txtId_Tema As System.Windows.Forms.TextBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents txtId_Plan As System.Windows.Forms.TextBox
    Friend WithEvents txtPertenece As System.Windows.Forms.TextBox
    Friend WithEvents txtFecAviCancelacion As System.Windows.Forms.TextBox
    Friend WithEvents lblFecAviCancelacion As System.Windows.Forms.Label
    Friend WithEvents txtTituloConcordancia As System.Windows.Forms.TextBox
    Friend WithEvents txtClasificacionConcordancia As System.Windows.Forms.TextBox
    Friend WithEvents lblConcordanciaClasificacion As System.Windows.Forms.Label
    Friend WithEvents lblConcordanciaTitulo As System.Windows.Forms.Label
    Friend WithEvents chkConcordancia As System.Windows.Forms.CheckBox
    Friend WithEvents txtresponsable As System.Windows.Forms.TextBox
    Friend WithEvents dtkFecAviCancelacion As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblPertenece As System.Windows.Forms.Label
    Friend WithEvents lblObservaciones As System.Windows.Forms.Label
    Friend WithEvents txtObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents chkObservaciones As System.Windows.Forms.CheckBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents chkNormasCan As System.Windows.Forms.CheckBox
    Friend WithEvents cmdDocFinal As System.Windows.Forms.Button
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtImpresa As System.Windows.Forms.TextBox
    Friend WithEvents txtCorporativa As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPersonal As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtNorma As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmC_Normas))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.txtNorma = New System.Windows.Forms.TextBox
        Me.cboClasificacion = New System.Windows.Forms.ComboBox
        Me.chkNormasCan = New System.Windows.Forms.CheckBox
        Me.chkObservaciones = New System.Windows.Forms.CheckBox
        Me.txtObservaciones = New System.Windows.Forms.TextBox
        Me.lblObservaciones = New System.Windows.Forms.Label
        Me.txtresponsable = New System.Windows.Forms.TextBox
        Me.chkConcordancia = New System.Windows.Forms.CheckBox
        Me.txtTituloConcordancia = New System.Windows.Forms.TextBox
        Me.txtClasificacionConcordancia = New System.Windows.Forms.TextBox
        Me.lblConcordanciaClasificacion = New System.Windows.Forms.Label
        Me.lblConcordanciaTitulo = New System.Windows.Forms.Label
        Me.lblPertenece = New System.Windows.Forms.Label
        Me.txtPertenece = New System.Windows.Forms.TextBox
        Me.txtId_Tema = New System.Windows.Forms.TextBox
        Me.txtId_Plan = New System.Windows.Forms.TextBox
        Me.lblSB = New System.Windows.Forms.Label
        Me.cmdComitesGuardar = New System.Windows.Forms.Button
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.txtA�o = New System.Windows.Forms.TextBox
        Me.txtOrganismo = New System.Windows.Forms.TextBox
        Me.txtConsecutivo = New System.Windows.Forms.TextBox
        Me.txtRamaIndustrial = New System.Windows.Forms.TextBox
        Me.lblNomClasificacion = New System.Windows.Forms.Label
        Me.txtGT = New System.Windows.Forms.TextBox
        Me.txtSC = New System.Windows.Forms.TextBox
        Me.txtCT = New System.Windows.Forms.TextBox
        Me.txtComite = New System.Windows.Forms.TextBox
        Me.txtBibliografia = New System.Windows.Forms.TextBox
        Me.txtEntradaVigor = New System.Windows.Forms.TextBox
        Me.txtDeclaratoria = New System.Windows.Forms.TextBox
        Me.grdConcordancia = New System.Windows.Forms.DataGrid
        Me.cboConcordancia = New System.Windows.Forms.ComboBox
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.lblConcordancia = New System.Windows.Forms.Label
        Me.txtPaginas = New System.Windows.Forms.TextBox
        Me.lblPaginas = New System.Windows.Forms.Label
        Me.txtTII = New System.Windows.Forms.TextBox
        Me.txtTIE = New System.Windows.Forms.TextBox
        Me.grdCanceladas = New System.Windows.Forms.DataGrid
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblCancelada = New System.Windows.Forms.Label
        Me.lblClasificacion = New System.Windows.Forms.Label
        Me.cboCancelada = New System.Windows.Forms.ComboBox
        Me.lblResponsable = New System.Windows.Forms.Label
        Me.txtObjetivo = New System.Windows.Forms.TextBox
        Me.lblVigencia = New System.Windows.Forms.Label
        Me.lblObjetivo = New System.Windows.Forms.Label
        Me.lblFechaEntradaVigor = New System.Windows.Forms.Label
        Me.lblBibliografia = New System.Windows.Forms.Label
        Me.lblComite = New System.Windows.Forms.Label
        Me.lblCT = New System.Windows.Forms.Label
        Me.lblSC = New System.Windows.Forms.Label
        Me.lblGT = New System.Windows.Forms.Label
        Me.cmdConcordancia = New System.Windows.Forms.Button
        Me.cmdComites = New System.Windows.Forms.Button
        Me.dtkDeclaratoria = New System.Windows.Forms.DateTimePicker
        Me.dtkEntradaVigor = New System.Windows.Forms.DateTimePicker
        Me.txtFecAviCancelacion = New System.Windows.Forms.TextBox
        Me.lblFecAviCancelacion = New System.Windows.Forms.Label
        Me.dtkFecAviCancelacion = New System.Windows.Forms.DateTimePicker
        Me.cmdCanceladas = New System.Windows.Forms.Button
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.txtPublicacionConsulta = New System.Windows.Forms.TextBox
        Me.txtRevisionQuinquenal = New System.Windows.Forms.TextBox
        Me.lblRevisionQuinquenal = New System.Windows.Forms.Label
        Me.lblPublicacionConsulta = New System.Windows.Forms.Label
        Me.txtDeclaratoriaVigencia = New System.Windows.Forms.TextBox
        Me.txtFechaLimite = New System.Windows.Forms.TextBox
        Me.lblDeclaratoriaVigencia = New System.Windows.Forms.Label
        Me.lblFechaLimite = New System.Windows.Forms.Label
        Me.txtNotificacionModificacion = New System.Windows.Forms.TextBox
        Me.lblNotificacionRatificacion = New System.Windows.Forms.Label
        Me.lblNotificacionModificacion = New System.Windows.Forms.Label
        Me.txtNotificacionRatificacion = New System.Windows.Forms.TextBox
        Me.dtkNotificacionRatificacion = New System.Windows.Forms.DateTimePicker
        Me.dtkNotificacionModificacion = New System.Windows.Forms.DateTimePicker
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.txtPersonal = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtCorporativa = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtImpresa = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.txtFecEnvioDGN = New System.Windows.Forms.TextBox
        Me.txtFecResolucionComentarios = New System.Windows.Forms.TextBox
        Me.txtFecAprobacionCONANCE = New System.Windows.Forms.TextBox
        Me.txtFecAprobacionCTGT = New System.Windows.Forms.TextBox
        Me.txtFecInicioDesarrollo = New System.Windows.Forms.TextBox
        Me.lblFecIinicioDesarrollo = New System.Windows.Forms.Label
        Me.lbltFecAprobacionCTGT = New System.Windows.Forms.Label
        Me.lblFecAprobacionCONANCE = New System.Windows.Forms.Label
        Me.lblFecResolucionComentarios = New System.Windows.Forms.Label
        Me.lblFecEnvioDGN = New System.Windows.Forms.Label
        Me.gpbInternacional = New System.Windows.Forms.GroupBox
        Me.chkAdoptada = New System.Windows.Forms.CheckBox
        Me.cmdAdoptada = New System.Windows.Forms.Button
        Me.grdAdoptada = New System.Windows.Forms.DataGrid
        Me.txtTituloAdoptado = New System.Windows.Forms.TextBox
        Me.txtClasificacionAdoptada = New System.Windows.Forms.TextBox
        Me.lblAdoptada = New System.Windows.Forms.Label
        Me.lblClasificacionAdoptada = New System.Windows.Forms.Label
        Me.lblTituloAdoptado = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chkArmonizada = New System.Windows.Forms.CheckBox
        Me.cmdArmonizada = New System.Windows.Forms.Button
        Me.grdArmonizada = New System.Windows.Forms.DataGrid
        Me.txtClasificacionCSA = New System.Windows.Forms.TextBox
        Me.txtClasificacionUL = New System.Windows.Forms.TextBox
        Me.lblArmonizada = New System.Windows.Forms.Label
        Me.lblClasificacionUL = New System.Windows.Forms.Label
        Me.lblTituloUL = New System.Windows.Forms.Label
        Me.lblClasificacionCSA = New System.Windows.Forms.Label
        Me.txtTituloUL = New System.Windows.Forms.TextBox
        Me.lblTituloCSA = New System.Windows.Forms.Label
        Me.txtTituloCSA = New System.Windows.Forms.TextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.chkNOM = New System.Windows.Forms.CheckBox
        Me.cmdNOM = New System.Windows.Forms.Button
        Me.grdNOM = New System.Windows.Forms.DataGrid
        Me.txtTituloNOM = New System.Windows.Forms.TextBox
        Me.txtClasificacionNOM = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblClasificacionNOM = New System.Windows.Forms.Label
        Me.lblClasificaionNOM = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.chkNMX = New System.Windows.Forms.CheckBox
        Me.cmdNMX = New System.Windows.Forms.Button
        Me.grdNMX = New System.Windows.Forms.DataGrid
        Me.txtTituloNMX = New System.Windows.Forms.TextBox
        Me.txtClasificacionNMX = New System.Windows.Forms.TextBox
        Me.lblNMX = New System.Windows.Forms.Label
        Me.lblClasificacionNMX = New System.Windows.Forms.Label
        Me.lblTituloNMX = New System.Windows.Forms.Label
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.chkNRF = New System.Windows.Forms.CheckBox
        Me.cmdNRF = New System.Windows.Forms.Button
        Me.grdNRF = New System.Windows.Forms.DataGrid
        Me.txtTituloNRF = New System.Windows.Forms.TextBox
        Me.txtClasificacionNRF = New System.Windows.Forms.TextBox
        Me.lblNRF = New System.Windows.Forms.Label
        Me.lbltClasificacionNRF = New System.Windows.Forms.Label
        Me.lblTituloNRF = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.gpbx = New System.Windows.Forms.GroupBox
        Me.lblSubirDoctoUno = New System.Windows.Forms.Label
        Me.txtDoctoUno = New System.Windows.Forms.TextBox
        Me.lblDoctoUno = New System.Windows.Forms.Label
        Me.txtFecUno = New System.Windows.Forms.TextBox
        Me.lblFecUno = New System.Windows.Forms.Label
        Me.dtkFecUno = New System.Windows.Forms.DateTimePicker
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.cmdDocFinal = New System.Windows.Forms.Button
        Me.txtDoctoNorma = New System.Windows.Forms.TextBox
        Me.lblDoctoNorma = New System.Windows.Forms.Label
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.lblSubirDoctoDos = New System.Windows.Forms.Label
        Me.txtDoctoDos = New System.Windows.Forms.TextBox
        Me.lblDocDos = New System.Windows.Forms.Label
        Me.txtFecDos = New System.Windows.Forms.TextBox
        Me.lblFecDos = New System.Windows.Forms.Label
        Me.dtkFecDos = New System.Windows.Forms.DateTimePicker
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.grdConcordancia, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdCanceladas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.gpbInternacional.SuspendLayout()
        CType(Me.grdAdoptada, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdArmonizada, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.grdNOM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.grdNMX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.grdNRF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.gpbx.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TabControl1)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(774, 648)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(8, 16)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(760, 640)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txtNorma)
        Me.TabPage1.Controls.Add(Me.cboClasificacion)
        Me.TabPage1.Controls.Add(Me.chkNormasCan)
        Me.TabPage1.Controls.Add(Me.chkObservaciones)
        Me.TabPage1.Controls.Add(Me.txtObservaciones)
        Me.TabPage1.Controls.Add(Me.lblObservaciones)
        Me.TabPage1.Controls.Add(Me.txtresponsable)
        Me.TabPage1.Controls.Add(Me.chkConcordancia)
        Me.TabPage1.Controls.Add(Me.txtTituloConcordancia)
        Me.TabPage1.Controls.Add(Me.txtClasificacionConcordancia)
        Me.TabPage1.Controls.Add(Me.lblConcordanciaClasificacion)
        Me.TabPage1.Controls.Add(Me.lblConcordanciaTitulo)
        Me.TabPage1.Controls.Add(Me.lblPertenece)
        Me.TabPage1.Controls.Add(Me.txtPertenece)
        Me.TabPage1.Controls.Add(Me.txtId_Tema)
        Me.TabPage1.Controls.Add(Me.txtId_Plan)
        Me.TabPage1.Controls.Add(Me.lblSB)
        Me.TabPage1.Controls.Add(Me.cmdComitesGuardar)
        Me.TabPage1.Controls.Add(Me.tvComites)
        Me.TabPage1.Controls.Add(Me.txtA�o)
        Me.TabPage1.Controls.Add(Me.txtOrganismo)
        Me.TabPage1.Controls.Add(Me.txtConsecutivo)
        Me.TabPage1.Controls.Add(Me.txtRamaIndustrial)
        Me.TabPage1.Controls.Add(Me.lblNomClasificacion)
        Me.TabPage1.Controls.Add(Me.txtGT)
        Me.TabPage1.Controls.Add(Me.txtSC)
        Me.TabPage1.Controls.Add(Me.txtCT)
        Me.TabPage1.Controls.Add(Me.txtComite)
        Me.TabPage1.Controls.Add(Me.txtBibliografia)
        Me.TabPage1.Controls.Add(Me.txtEntradaVigor)
        Me.TabPage1.Controls.Add(Me.txtDeclaratoria)
        Me.TabPage1.Controls.Add(Me.grdConcordancia)
        Me.TabPage1.Controls.Add(Me.cboConcordancia)
        Me.TabPage1.Controls.Add(Me.cboResponsable)
        Me.TabPage1.Controls.Add(Me.lblConcordancia)
        Me.TabPage1.Controls.Add(Me.txtPaginas)
        Me.TabPage1.Controls.Add(Me.lblPaginas)
        Me.TabPage1.Controls.Add(Me.txtTII)
        Me.TabPage1.Controls.Add(Me.txtTIE)
        Me.TabPage1.Controls.Add(Me.grdCanceladas)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.lblCancelada)
        Me.TabPage1.Controls.Add(Me.lblClasificacion)
        Me.TabPage1.Controls.Add(Me.cboCancelada)
        Me.TabPage1.Controls.Add(Me.lblResponsable)
        Me.TabPage1.Controls.Add(Me.txtObjetivo)
        Me.TabPage1.Controls.Add(Me.lblVigencia)
        Me.TabPage1.Controls.Add(Me.lblObjetivo)
        Me.TabPage1.Controls.Add(Me.lblFechaEntradaVigor)
        Me.TabPage1.Controls.Add(Me.lblBibliografia)
        Me.TabPage1.Controls.Add(Me.lblComite)
        Me.TabPage1.Controls.Add(Me.lblCT)
        Me.TabPage1.Controls.Add(Me.lblSC)
        Me.TabPage1.Controls.Add(Me.lblGT)
        Me.TabPage1.Controls.Add(Me.cmdConcordancia)
        Me.TabPage1.Controls.Add(Me.cmdComites)
        Me.TabPage1.Controls.Add(Me.dtkDeclaratoria)
        Me.TabPage1.Controls.Add(Me.dtkEntradaVigor)
        Me.TabPage1.Controls.Add(Me.txtFecAviCancelacion)
        Me.TabPage1.Controls.Add(Me.lblFecAviCancelacion)
        Me.TabPage1.Controls.Add(Me.dtkFecAviCancelacion)
        Me.TabPage1.Controls.Add(Me.cmdCanceladas)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(752, 614)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "NMX-ANCE            "
        '
        'txtNorma
        '
        Me.txtNorma.Location = New System.Drawing.Point(104, 16)
        Me.txtNorma.Name = "txtNorma"
        Me.txtNorma.Size = New System.Drawing.Size(272, 20)
        Me.txtNorma.TabIndex = 48
        Me.txtNorma.Text = ""
        Me.txtNorma.Visible = False
        '
        'cboClasificacion
        '
        Me.cboClasificacion.Location = New System.Drawing.Point(104, 16)
        Me.cboClasificacion.Name = "cboClasificacion"
        Me.cboClasificacion.Size = New System.Drawing.Size(272, 21)
        Me.cboClasificacion.TabIndex = 0
        '
        'chkNormasCan
        '
        Me.chkNormasCan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNormasCan.Location = New System.Drawing.Point(104, 48)
        Me.chkNormasCan.Name = "chkNormasCan"
        Me.chkNormasCan.Size = New System.Drawing.Size(144, 24)
        Me.chkNormasCan.TabIndex = 47
        Me.chkNormasCan.Text = "Normas Canceladas"
        '
        'chkObservaciones
        '
        Me.chkObservaciones.Location = New System.Drawing.Point(384, 312)
        Me.chkObservaciones.Name = "chkObservaciones"
        Me.chkObservaciones.Size = New System.Drawing.Size(14, 13)
        Me.chkObservaciones.TabIndex = 46
        '
        'txtObservaciones
        '
        Me.txtObservaciones.Location = New System.Drawing.Point(504, 307)
        Me.txtObservaciones.Multiline = True
        Me.txtObservaciones.Name = "txtObservaciones"
        Me.txtObservaciones.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtObservaciones.Size = New System.Drawing.Size(230, 42)
        Me.txtObservaciones.TabIndex = 45
        Me.txtObservaciones.Text = ""
        '
        'lblObservaciones
        '
        Me.lblObservaciones.AutoSize = True
        Me.lblObservaciones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblObservaciones.Location = New System.Drawing.Point(405, 312)
        Me.lblObservaciones.Name = "lblObservaciones"
        Me.lblObservaciones.Size = New System.Drawing.Size(89, 16)
        Me.lblObservaciones.TabIndex = 44
        Me.lblObservaciones.Text = "Observaciones:"
        '
        'txtresponsable
        '
        Me.txtresponsable.Location = New System.Drawing.Point(104, 232)
        Me.txtresponsable.Name = "txtresponsable"
        Me.txtresponsable.Size = New System.Drawing.Size(245, 20)
        Me.txtresponsable.TabIndex = 43
        Me.txtresponsable.Text = ""
        '
        'chkConcordancia
        '
        Me.chkConcordancia.Location = New System.Drawing.Point(389, 56)
        Me.chkConcordancia.Name = "chkConcordancia"
        Me.chkConcordancia.Size = New System.Drawing.Size(16, 13)
        Me.chkConcordancia.TabIndex = 42
        '
        'txtTituloConcordancia
        '
        Me.txtTituloConcordancia.Location = New System.Drawing.Point(534, 47)
        Me.txtTituloConcordancia.Name = "txtTituloConcordancia"
        Me.txtTituloConcordancia.Size = New System.Drawing.Size(159, 20)
        Me.txtTituloConcordancia.TabIndex = 40
        Me.txtTituloConcordancia.Text = ""
        '
        'txtClasificacionConcordancia
        '
        Me.txtClasificacionConcordancia.Location = New System.Drawing.Point(536, 16)
        Me.txtClasificacionConcordancia.Name = "txtClasificacionConcordancia"
        Me.txtClasificacionConcordancia.Size = New System.Drawing.Size(159, 20)
        Me.txtClasificacionConcordancia.TabIndex = 39
        Me.txtClasificacionConcordancia.Text = ""
        '
        'lblConcordanciaClasificacion
        '
        Me.lblConcordanciaClasificacion.AutoSize = True
        Me.lblConcordanciaClasificacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConcordanciaClasificacion.Location = New System.Drawing.Point(469, 17)
        Me.lblConcordanciaClasificacion.Name = "lblConcordanciaClasificacion"
        Me.lblConcordanciaClasificacion.Size = New System.Drawing.Size(68, 16)
        Me.lblConcordanciaClasificacion.TabIndex = 37
        Me.lblConcordanciaClasificacion.Text = "Clasificaci�n"
        '
        'lblConcordanciaTitulo
        '
        Me.lblConcordanciaTitulo.AutoSize = True
        Me.lblConcordanciaTitulo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConcordanciaTitulo.Location = New System.Drawing.Point(503, 50)
        Me.lblConcordanciaTitulo.Name = "lblConcordanciaTitulo"
        Me.lblConcordanciaTitulo.Size = New System.Drawing.Size(33, 16)
        Me.lblConcordanciaTitulo.TabIndex = 38
        Me.lblConcordanciaTitulo.Text = "T�tulo"
        '
        'lblPertenece
        '
        Me.lblPertenece.AutoSize = True
        Me.lblPertenece.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPertenece.Location = New System.Drawing.Point(384, 347)
        Me.lblPertenece.Name = "lblPertenece"
        Me.lblPertenece.Size = New System.Drawing.Size(72, 16)
        Me.lblPertenece.TabIndex = 36
        Me.lblPertenece.Text = "Pertenece a:"
        '
        'txtPertenece
        '
        Me.txtPertenece.Location = New System.Drawing.Point(384, 371)
        Me.txtPertenece.Name = "txtPertenece"
        Me.txtPertenece.Size = New System.Drawing.Size(128, 20)
        Me.txtPertenece.TabIndex = 35
        Me.txtPertenece.Text = ""
        '
        'txtId_Tema
        '
        Me.txtId_Tema.Location = New System.Drawing.Point(80, 528)
        Me.txtId_Tema.Name = "txtId_Tema"
        Me.txtId_Tema.Size = New System.Drawing.Size(64, 20)
        Me.txtId_Tema.TabIndex = 34
        Me.txtId_Tema.Text = ""
        Me.txtId_Tema.Visible = False
        '
        'txtId_Plan
        '
        Me.txtId_Plan.Location = New System.Drawing.Point(8, 528)
        Me.txtId_Plan.Name = "txtId_Plan"
        Me.txtId_Plan.Size = New System.Drawing.Size(64, 20)
        Me.txtId_Plan.TabIndex = 33
        Me.txtId_Plan.Text = ""
        Me.txtId_Plan.Visible = False
        '
        'lblSB
        '
        Me.lblSB.Location = New System.Drawing.Point(504, 532)
        Me.lblSB.Name = "lblSB"
        Me.lblSB.Size = New System.Drawing.Size(88, 16)
        Me.lblSB.TabIndex = 32
        Me.lblSB.Visible = False
        '
        'cmdComitesGuardar
        '
        Me.cmdComitesGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdComitesGuardar.ImageIndex = 0
        Me.cmdComitesGuardar.ImageList = Me.imgListBotonera
        Me.cmdComitesGuardar.Location = New System.Drawing.Point(664, 528)
        Me.cmdComitesGuardar.Name = "cmdComitesGuardar"
        Me.cmdComitesGuardar.Size = New System.Drawing.Size(56, 24)
        Me.cmdComitesGuardar.TabIndex = 31
        Me.cmdComitesGuardar.Text = "Aceptar"
        Me.cmdComitesGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdComitesGuardar.Visible = False
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tvComites
        '
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(520, 357)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.Size = New System.Drawing.Size(216, 88)
        Me.tvComites.TabIndex = 30
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'txtA�o
        '
        Me.txtA�o.Location = New System.Drawing.Point(306, 16)
        Me.txtA�o.Name = "txtA�o"
        Me.txtA�o.Size = New System.Drawing.Size(62, 20)
        Me.txtA�o.TabIndex = 27
        Me.txtA�o.Text = ""
        '
        'txtOrganismo
        '
        Me.txtOrganismo.Location = New System.Drawing.Point(239, 17)
        Me.txtOrganismo.Name = "txtOrganismo"
        Me.txtOrganismo.Size = New System.Drawing.Size(56, 20)
        Me.txtOrganismo.TabIndex = 26
        Me.txtOrganismo.Text = ""
        '
        'txtConsecutivo
        '
        Me.txtConsecutivo.Location = New System.Drawing.Point(176, 17)
        Me.txtConsecutivo.Name = "txtConsecutivo"
        Me.txtConsecutivo.Size = New System.Drawing.Size(48, 20)
        Me.txtConsecutivo.TabIndex = 25
        Me.txtConsecutivo.Text = ""
        '
        'txtRamaIndustrial
        '
        Me.txtRamaIndustrial.Location = New System.Drawing.Point(137, 17)
        Me.txtRamaIndustrial.Name = "txtRamaIndustrial"
        Me.txtRamaIndustrial.Size = New System.Drawing.Size(28, 20)
        Me.txtRamaIndustrial.TabIndex = 24
        Me.txtRamaIndustrial.Text = ""
        '
        'lblNomClasificacion
        '
        Me.lblNomClasificacion.AutoSize = True
        Me.lblNomClasificacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNomClasificacion.Location = New System.Drawing.Point(104, 24)
        Me.lblNomClasificacion.Name = "lblNomClasificacion"
        Me.lblNomClasificacion.Size = New System.Drawing.Size(263, 16)
        Me.lblNomClasificacion.TabIndex = 23
        Me.lblNomClasificacion.Text = "NMX-         -                 -                    -                     "
        '
        'txtGT
        '
        Me.txtGT.Location = New System.Drawing.Point(432, 522)
        Me.txtGT.Name = "txtGT"
        Me.txtGT.Size = New System.Drawing.Size(48, 20)
        Me.txtGT.TabIndex = 21
        Me.txtGT.Text = ""
        Me.txtGT.Visible = False
        Me.txtGT.WordWrap = False
        '
        'txtSC
        '
        Me.txtSC.Location = New System.Drawing.Point(384, 522)
        Me.txtSC.Name = "txtSC"
        Me.txtSC.Size = New System.Drawing.Size(40, 20)
        Me.txtSC.TabIndex = 20
        Me.txtSC.Text = ""
        Me.txtSC.Visible = False
        Me.txtSC.WordWrap = False
        '
        'txtCT
        '
        Me.txtCT.Location = New System.Drawing.Point(328, 523)
        Me.txtCT.Name = "txtCT"
        Me.txtCT.Size = New System.Drawing.Size(48, 20)
        Me.txtCT.TabIndex = 19
        Me.txtCT.Text = ""
        Me.txtCT.Visible = False
        Me.txtCT.WordWrap = False
        '
        'txtComite
        '
        Me.txtComite.Location = New System.Drawing.Point(272, 523)
        Me.txtComite.Name = "txtComite"
        Me.txtComite.Size = New System.Drawing.Size(48, 20)
        Me.txtComite.TabIndex = 18
        Me.txtComite.Text = ""
        Me.txtComite.Visible = False
        Me.txtComite.WordWrap = False
        '
        'txtBibliografia
        '
        Me.txtBibliografia.Location = New System.Drawing.Point(472, 260)
        Me.txtBibliografia.Multiline = True
        Me.txtBibliografia.Name = "txtBibliografia"
        Me.txtBibliografia.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtBibliografia.Size = New System.Drawing.Size(264, 37)
        Me.txtBibliografia.TabIndex = 17
        Me.txtBibliografia.Text = ""
        '
        'txtEntradaVigor
        '
        Me.txtEntradaVigor.Location = New System.Drawing.Point(475, 226)
        Me.txtEntradaVigor.Name = "txtEntradaVigor"
        Me.txtEntradaVigor.Size = New System.Drawing.Size(80, 20)
        Me.txtEntradaVigor.TabIndex = 16
        Me.txtEntradaVigor.Text = ""
        '
        'txtDeclaratoria
        '
        Me.txtDeclaratoria.Location = New System.Drawing.Point(475, 190)
        Me.txtDeclaratoria.Name = "txtDeclaratoria"
        Me.txtDeclaratoria.Size = New System.Drawing.Size(80, 20)
        Me.txtDeclaratoria.TabIndex = 15
        Me.txtDeclaratoria.Text = ""
        '
        'grdConcordancia
        '
        Me.grdConcordancia.CaptionVisible = False
        Me.grdConcordancia.DataMember = ""
        Me.grdConcordancia.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdConcordancia.Location = New System.Drawing.Point(386, 78)
        Me.grdConcordancia.Name = "grdConcordancia"
        Me.grdConcordancia.Size = New System.Drawing.Size(350, 102)
        Me.grdConcordancia.TabIndex = 14
        '
        'cboConcordancia
        '
        Me.cboConcordancia.Location = New System.Drawing.Point(472, -20)
        Me.cboConcordancia.Name = "cboConcordancia"
        Me.cboConcordancia.Size = New System.Drawing.Size(264, 21)
        Me.cboConcordancia.TabIndex = 13
        '
        'cboResponsable
        '
        Me.cboResponsable.Location = New System.Drawing.Point(104, 232)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(264, 21)
        Me.cboResponsable.TabIndex = 12
        '
        'lblConcordancia
        '
        Me.lblConcordancia.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConcordancia.Location = New System.Drawing.Point(384, 13)
        Me.lblConcordancia.Name = "lblConcordancia"
        Me.lblConcordancia.Size = New System.Drawing.Size(80, 38)
        Me.lblConcordancia.TabIndex = 11
        Me.lblConcordancia.Text = "Concordancia con Normas Internacionales:"
        '
        'txtPaginas
        '
        Me.txtPaginas.Location = New System.Drawing.Point(104, 424)
        Me.txtPaginas.Name = "txtPaginas"
        Me.txtPaginas.Size = New System.Drawing.Size(264, 20)
        Me.txtPaginas.TabIndex = 10
        Me.txtPaginas.Text = ""
        '
        'lblPaginas
        '
        Me.lblPaginas.AutoSize = True
        Me.lblPaginas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaginas.Location = New System.Drawing.Point(16, 427)
        Me.lblPaginas.Name = "lblPaginas"
        Me.lblPaginas.Size = New System.Drawing.Size(51, 16)
        Me.lblPaginas.TabIndex = 9
        Me.lblPaginas.Text = "P�ginas:"
        '
        'txtTII
        '
        Me.txtTII.Location = New System.Drawing.Point(104, 328)
        Me.txtTII.Multiline = True
        Me.txtTII.Name = "txtTII"
        Me.txtTII.Size = New System.Drawing.Size(264, 64)
        Me.txtTII.TabIndex = 8
        Me.txtTII.Text = ""
        '
        'txtTIE
        '
        Me.txtTIE.Location = New System.Drawing.Point(104, 256)
        Me.txtTIE.Multiline = True
        Me.txtTIE.Name = "txtTIE"
        Me.txtTIE.Size = New System.Drawing.Size(264, 64)
        Me.txtTIE.TabIndex = 7
        Me.txtTIE.Text = ""
        '
        'grdCanceladas
        '
        Me.grdCanceladas.CaptionVisible = False
        Me.grdCanceladas.DataMember = ""
        Me.grdCanceladas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdCanceladas.Location = New System.Drawing.Point(104, 80)
        Me.grdCanceladas.Name = "grdCanceladas"
        Me.grdCanceladas.RowHeaderWidth = 20
        Me.grdCanceladas.Size = New System.Drawing.Size(264, 140)
        Me.grdCanceladas.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 336)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "TII:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(15, 264)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "TIE:"
        '
        'lblCancelada
        '
        Me.lblCancelada.AutoSize = True
        Me.lblCancelada.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCancelada.Location = New System.Drawing.Point(16, 96)
        Me.lblCancelada.Name = "lblCancelada"
        Me.lblCancelada.Size = New System.Drawing.Size(73, 16)
        Me.lblCancelada.TabIndex = 3
        Me.lblCancelada.Text = "Cancela a la:"
        '
        'lblClasificacion
        '
        Me.lblClasificacion.AutoSize = True
        Me.lblClasificacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacion.Location = New System.Drawing.Point(16, 20)
        Me.lblClasificacion.Name = "lblClasificacion"
        Me.lblClasificacion.Size = New System.Drawing.Size(78, 16)
        Me.lblClasificacion.TabIndex = 2
        Me.lblClasificacion.Text = "Clasificaci�n:"
        '
        'cboCancelada
        '
        Me.cboCancelada.Location = New System.Drawing.Point(112, 96)
        Me.cboCancelada.Name = "cboCancelada"
        Me.cboCancelada.Size = New System.Drawing.Size(264, 21)
        Me.cboCancelada.TabIndex = 1
        Me.cboCancelada.Visible = False
        '
        'lblResponsable
        '
        Me.lblResponsable.AutoSize = True
        Me.lblResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResponsable.Location = New System.Drawing.Point(16, 232)
        Me.lblResponsable.Name = "lblResponsable"
        Me.lblResponsable.Size = New System.Drawing.Size(78, 16)
        Me.lblResponsable.TabIndex = 4
        Me.lblResponsable.Text = "Responsable:"
        '
        'txtObjetivo
        '
        Me.txtObjetivo.Location = New System.Drawing.Point(104, 456)
        Me.txtObjetivo.Multiline = True
        Me.txtObjetivo.Name = "txtObjetivo"
        Me.txtObjetivo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtObjetivo.Size = New System.Drawing.Size(635, 64)
        Me.txtObjetivo.TabIndex = 10
        Me.txtObjetivo.Text = ""
        '
        'lblVigencia
        '
        Me.lblVigencia.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVigencia.Location = New System.Drawing.Point(384, 187)
        Me.lblVigencia.Name = "lblVigencia"
        Me.lblVigencia.Size = New System.Drawing.Size(80, 31)
        Me.lblVigencia.TabIndex = 9
        Me.lblVigencia.Text = "Declaratoria de Vigencia:"
        '
        'lblObjetivo
        '
        Me.lblObjetivo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblObjetivo.Location = New System.Drawing.Point(16, 456)
        Me.lblObjetivo.Name = "lblObjetivo"
        Me.lblObjetivo.Size = New System.Drawing.Size(72, 40)
        Me.lblObjetivo.TabIndex = 9
        Me.lblObjetivo.Text = "Objetivo y Campo de Aplicaci�n:"
        '
        'lblFechaEntradaVigor
        '
        Me.lblFechaEntradaVigor.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFechaEntradaVigor.Location = New System.Drawing.Point(387, 218)
        Me.lblFechaEntradaVigor.Name = "lblFechaEntradaVigor"
        Me.lblFechaEntradaVigor.Size = New System.Drawing.Size(69, 39)
        Me.lblFechaEntradaVigor.TabIndex = 4
        Me.lblFechaEntradaVigor.Text = "Fecha de entrada en vigor:"
        '
        'lblBibliografia
        '
        Me.lblBibliografia.AutoSize = True
        Me.lblBibliografia.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBibliografia.Location = New System.Drawing.Point(387, 265)
        Me.lblBibliografia.Name = "lblBibliografia"
        Me.lblBibliografia.Size = New System.Drawing.Size(70, 16)
        Me.lblBibliografia.TabIndex = 4
        Me.lblBibliografia.Text = "Bibliograf�a:"
        '
        'lblComite
        '
        Me.lblComite.AutoSize = True
        Me.lblComite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComite.Location = New System.Drawing.Point(272, 544)
        Me.lblComite.Name = "lblComite"
        Me.lblComite.Size = New System.Drawing.Size(46, 16)
        Me.lblComite.TabIndex = 4
        Me.lblComite.Text = "Comit�:"
        Me.lblComite.Visible = False
        '
        'lblCT
        '
        Me.lblCT.AutoSize = True
        Me.lblCT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCT.Location = New System.Drawing.Point(312, 544)
        Me.lblCT.Name = "lblCT"
        Me.lblCT.Size = New System.Drawing.Size(69, 16)
        Me.lblCT.TabIndex = 4
        Me.lblCT.Text = "Comit� T�c:"
        Me.lblCT.Visible = False
        '
        'lblSC
        '
        Me.lblSC.AutoSize = True
        Me.lblSC.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSC.Location = New System.Drawing.Point(352, 544)
        Me.lblSC.Name = "lblSC"
        Me.lblSC.Size = New System.Drawing.Size(71, 16)
        Me.lblSC.TabIndex = 4
        Me.lblSC.Text = "Sub Comit�:"
        Me.lblSC.Visible = False
        '
        'lblGT
        '
        Me.lblGT.AutoSize = True
        Me.lblGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGT.Location = New System.Drawing.Point(416, 544)
        Me.lblGT.Name = "lblGT"
        Me.lblGT.Size = New System.Drawing.Size(78, 16)
        Me.lblGT.TabIndex = 4
        Me.lblGT.Text = "Gpo. Trabajo:"
        Me.lblGT.Visible = False
        '
        'cmdConcordancia
        '
        Me.cmdConcordancia.Location = New System.Drawing.Point(696, 14)
        Me.cmdConcordancia.Name = "cmdConcordancia"
        Me.cmdConcordancia.Size = New System.Drawing.Size(52, 23)
        Me.cmdConcordancia.TabIndex = 22
        Me.cmdConcordancia.Text = "Agregar"
        '
        'cmdComites
        '
        Me.cmdComites.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdComites.ImageIndex = 0
        Me.cmdComites.ImageList = Me.imgListBotonera
        Me.cmdComites.Location = New System.Drawing.Point(600, 528)
        Me.cmdComites.Name = "cmdComites"
        Me.cmdComites.Size = New System.Drawing.Size(56, 24)
        Me.cmdComites.TabIndex = 22
        Me.cmdComites.Text = "Agregar"
        Me.cmdComites.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdComites.Visible = False
        '
        'dtkDeclaratoria
        '
        Me.dtkDeclaratoria.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDeclaratoria.Location = New System.Drawing.Point(475, 190)
        Me.dtkDeclaratoria.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.dtkDeclaratoria.Name = "dtkDeclaratoria"
        Me.dtkDeclaratoria.Size = New System.Drawing.Size(100, 20)
        Me.dtkDeclaratoria.TabIndex = 28
        Me.dtkDeclaratoria.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'dtkEntradaVigor
        '
        Me.dtkEntradaVigor.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkEntradaVigor.Location = New System.Drawing.Point(475, 226)
        Me.dtkEntradaVigor.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.dtkEntradaVigor.Name = "dtkEntradaVigor"
        Me.dtkEntradaVigor.Size = New System.Drawing.Size(100, 20)
        Me.dtkEntradaVigor.TabIndex = 29
        Me.dtkEntradaVigor.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtFecAviCancelacion
        '
        Me.txtFecAviCancelacion.Location = New System.Drawing.Point(624, 225)
        Me.txtFecAviCancelacion.Name = "txtFecAviCancelacion"
        Me.txtFecAviCancelacion.Size = New System.Drawing.Size(80, 20)
        Me.txtFecAviCancelacion.TabIndex = 16
        Me.txtFecAviCancelacion.Text = ""
        '
        'lblFecAviCancelacion
        '
        Me.lblFecAviCancelacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecAviCancelacion.Location = New System.Drawing.Point(624, 193)
        Me.lblFecAviCancelacion.Name = "lblFecAviCancelacion"
        Me.lblFecAviCancelacion.Size = New System.Drawing.Size(104, 24)
        Me.lblFecAviCancelacion.TabIndex = 4
        Me.lblFecAviCancelacion.Text = "Declaratoria de Cancelaci�n:"
        '
        'dtkFecAviCancelacion
        '
        Me.dtkFecAviCancelacion.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecAviCancelacion.Location = New System.Drawing.Point(624, 225)
        Me.dtkFecAviCancelacion.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.dtkFecAviCancelacion.Name = "dtkFecAviCancelacion"
        Me.dtkFecAviCancelacion.Size = New System.Drawing.Size(100, 20)
        Me.dtkFecAviCancelacion.TabIndex = 29
        Me.dtkFecAviCancelacion.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'cmdCanceladas
        '
        Me.cmdCanceladas.Location = New System.Drawing.Point(320, 120)
        Me.cmdCanceladas.Name = "cmdCanceladas"
        Me.cmdCanceladas.Size = New System.Drawing.Size(56, 23)
        Me.cmdCanceladas.TabIndex = 22
        Me.cmdCanceladas.Text = "Agregar"
        Me.cmdCanceladas.Visible = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox7)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(752, 614)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Quinquenal/Cancelacion"
        Me.TabPage3.Visible = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.txtPublicacionConsulta)
        Me.GroupBox7.Controls.Add(Me.txtRevisionQuinquenal)
        Me.GroupBox7.Controls.Add(Me.lblRevisionQuinquenal)
        Me.GroupBox7.Controls.Add(Me.lblPublicacionConsulta)
        Me.GroupBox7.Controls.Add(Me.txtDeclaratoriaVigencia)
        Me.GroupBox7.Controls.Add(Me.txtFechaLimite)
        Me.GroupBox7.Controls.Add(Me.lblDeclaratoriaVigencia)
        Me.GroupBox7.Controls.Add(Me.lblFechaLimite)
        Me.GroupBox7.Controls.Add(Me.txtNotificacionModificacion)
        Me.GroupBox7.Controls.Add(Me.lblNotificacionRatificacion)
        Me.GroupBox7.Controls.Add(Me.lblNotificacionModificacion)
        Me.GroupBox7.Controls.Add(Me.txtNotificacionRatificacion)
        Me.GroupBox7.Controls.Add(Me.dtkNotificacionRatificacion)
        Me.GroupBox7.Controls.Add(Me.dtkNotificacionModificacion)
        Me.GroupBox7.Location = New System.Drawing.Point(2, -1)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(748, 185)
        Me.GroupBox7.TabIndex = 0
        Me.GroupBox7.TabStop = False
        '
        'txtPublicacionConsulta
        '
        Me.txtPublicacionConsulta.Location = New System.Drawing.Point(504, 32)
        Me.txtPublicacionConsulta.Name = "txtPublicacionConsulta"
        Me.txtPublicacionConsulta.Size = New System.Drawing.Size(80, 20)
        Me.txtPublicacionConsulta.TabIndex = 20
        Me.txtPublicacionConsulta.Text = ""
        '
        'txtRevisionQuinquenal
        '
        Me.txtRevisionQuinquenal.Location = New System.Drawing.Point(120, 30)
        Me.txtRevisionQuinquenal.Name = "txtRevisionQuinquenal"
        Me.txtRevisionQuinquenal.Size = New System.Drawing.Size(80, 20)
        Me.txtRevisionQuinquenal.TabIndex = 19
        Me.txtRevisionQuinquenal.Text = ""
        '
        'lblRevisionQuinquenal
        '
        Me.lblRevisionQuinquenal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRevisionQuinquenal.Location = New System.Drawing.Point(10, 22)
        Me.lblRevisionQuinquenal.Name = "lblRevisionQuinquenal"
        Me.lblRevisionQuinquenal.Size = New System.Drawing.Size(78, 32)
        Me.lblRevisionQuinquenal.TabIndex = 17
        Me.lblRevisionQuinquenal.Text = "Revisi�n Quinquenal :"
        '
        'lblPublicacionConsulta
        '
        Me.lblPublicacionConsulta.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPublicacionConsulta.Location = New System.Drawing.Point(388, 22)
        Me.lblPublicacionConsulta.Name = "lblPublicacionConsulta"
        Me.lblPublicacionConsulta.Size = New System.Drawing.Size(91, 39)
        Me.lblPublicacionConsulta.TabIndex = 18
        Me.lblPublicacionConsulta.Text = "Publicaci�n a Consulta para su Cancelaci�n:"
        '
        'txtDeclaratoriaVigencia
        '
        Me.txtDeclaratoriaVigencia.Location = New System.Drawing.Point(120, 86)
        Me.txtDeclaratoriaVigencia.Name = "txtDeclaratoriaVigencia"
        Me.txtDeclaratoriaVigencia.Size = New System.Drawing.Size(80, 20)
        Me.txtDeclaratoriaVigencia.TabIndex = 19
        Me.txtDeclaratoriaVigencia.Text = ""
        '
        'txtFechaLimite
        '
        Me.txtFechaLimite.Location = New System.Drawing.Point(504, 86)
        Me.txtFechaLimite.Name = "txtFechaLimite"
        Me.txtFechaLimite.Size = New System.Drawing.Size(80, 20)
        Me.txtFechaLimite.TabIndex = 20
        Me.txtFechaLimite.Text = ""
        '
        'lblDeclaratoriaVigencia
        '
        Me.lblDeclaratoriaVigencia.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDeclaratoriaVigencia.Location = New System.Drawing.Point(8, 78)
        Me.lblDeclaratoriaVigencia.Name = "lblDeclaratoriaVigencia"
        Me.lblDeclaratoriaVigencia.Size = New System.Drawing.Size(88, 40)
        Me.lblDeclaratoriaVigencia.TabIndex = 17
        Me.lblDeclaratoriaVigencia.Text = "Declaratoria de Cancelaci�n:"
        '
        'lblFechaLimite
        '
        Me.lblFechaLimite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFechaLimite.Location = New System.Drawing.Point(389, 78)
        Me.lblFechaLimite.Name = "lblFechaLimite"
        Me.lblFechaLimite.Size = New System.Drawing.Size(90, 39)
        Me.lblFechaLimite.TabIndex = 18
        Me.lblFechaLimite.Text = "Fecha L�mite en Consulta para Cancelaci�n:"
        '
        'txtNotificacionModificacion
        '
        Me.txtNotificacionModificacion.Location = New System.Drawing.Point(503, 152)
        Me.txtNotificacionModificacion.Name = "txtNotificacionModificacion"
        Me.txtNotificacionModificacion.Size = New System.Drawing.Size(80, 20)
        Me.txtNotificacionModificacion.TabIndex = 20
        Me.txtNotificacionModificacion.Text = ""
        '
        'lblNotificacionRatificacion
        '
        Me.lblNotificacionRatificacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotificacionRatificacion.Location = New System.Drawing.Point(10, 145)
        Me.lblNotificacionRatificacion.Name = "lblNotificacionRatificacion"
        Me.lblNotificacionRatificacion.Size = New System.Drawing.Size(88, 30)
        Me.lblNotificacionRatificacion.TabIndex = 17
        Me.lblNotificacionRatificacion.Text = "Notificaci�n de Ratificaci�n:"
        '
        'lblNotificacionModificacion
        '
        Me.lblNotificacionModificacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotificacionModificacion.Location = New System.Drawing.Point(392, 148)
        Me.lblNotificacionModificacion.Name = "lblNotificacionModificacion"
        Me.lblNotificacionModificacion.Size = New System.Drawing.Size(90, 30)
        Me.lblNotificacionModificacion.TabIndex = 18
        Me.lblNotificacionModificacion.Text = "Notificaci�n de Modificaci�n:"
        '
        'txtNotificacionRatificacion
        '
        Me.txtNotificacionRatificacion.Location = New System.Drawing.Point(119, 152)
        Me.txtNotificacionRatificacion.Name = "txtNotificacionRatificacion"
        Me.txtNotificacionRatificacion.Size = New System.Drawing.Size(80, 20)
        Me.txtNotificacionRatificacion.TabIndex = 19
        Me.txtNotificacionRatificacion.Text = ""
        '
        'dtkNotificacionRatificacion
        '
        Me.dtkNotificacionRatificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkNotificacionRatificacion.Location = New System.Drawing.Point(119, 152)
        Me.dtkNotificacionRatificacion.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.dtkNotificacionRatificacion.Name = "dtkNotificacionRatificacion"
        Me.dtkNotificacionRatificacion.Size = New System.Drawing.Size(100, 20)
        Me.dtkNotificacionRatificacion.TabIndex = 22
        Me.dtkNotificacionRatificacion.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'dtkNotificacionModificacion
        '
        Me.dtkNotificacionModificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkNotificacionModificacion.Location = New System.Drawing.Point(502, 152)
        Me.dtkNotificacionModificacion.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.dtkNotificacionModificacion.Name = "dtkNotificacionModificacion"
        Me.dtkNotificacionModificacion.Size = New System.Drawing.Size(100, 20)
        Me.dtkNotificacionModificacion.TabIndex = 22
        Me.dtkNotificacionModificacion.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'TabPage2
        '
        Me.TabPage2.AccessibleDescription = ""
        Me.TabPage2.Controls.Add(Me.GroupBox9)
        Me.TabPage2.Controls.Add(Me.GroupBox6)
        Me.TabPage2.Controls.Add(Me.gpbInternacional)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.GroupBox5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(752, 614)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Caracter�sticas     "
        Me.TabPage2.Visible = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.txtPersonal)
        Me.GroupBox9.Controls.Add(Me.Label6)
        Me.GroupBox9.Controls.Add(Me.txtCorporativa)
        Me.GroupBox9.Controls.Add(Me.Label5)
        Me.GroupBox9.Controls.Add(Me.txtImpresa)
        Me.GroupBox9.Controls.Add(Me.Label4)
        Me.GroupBox9.Location = New System.Drawing.Point(8, 560)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(744, 48)
        Me.GroupBox9.TabIndex = 19
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Costos"
        '
        'txtPersonal
        '
        Me.txtPersonal.Location = New System.Drawing.Point(496, 16)
        Me.txtPersonal.Name = "txtPersonal"
        Me.txtPersonal.Size = New System.Drawing.Size(144, 20)
        Me.txtPersonal.TabIndex = 5
        Me.txtPersonal.Text = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(448, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 16)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Personal:"
        '
        'txtCorporativa
        '
        Me.txtCorporativa.Location = New System.Drawing.Point(288, 16)
        Me.txtCorporativa.Name = "txtCorporativa"
        Me.txtCorporativa.Size = New System.Drawing.Size(144, 20)
        Me.txtCorporativa.TabIndex = 3
        Me.txtCorporativa.Text = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(216, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 16)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Corporativa:"
        '
        'txtImpresa
        '
        Me.txtImpresa.Location = New System.Drawing.Point(64, 16)
        Me.txtImpresa.Name = "txtImpresa"
        Me.txtImpresa.Size = New System.Drawing.Size(144, 20)
        Me.txtImpresa.TabIndex = 1
        Me.txtImpresa.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 16)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Impresa:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txtFecEnvioDGN)
        Me.GroupBox6.Controls.Add(Me.txtFecResolucionComentarios)
        Me.GroupBox6.Controls.Add(Me.txtFecAprobacionCONANCE)
        Me.GroupBox6.Controls.Add(Me.txtFecAprobacionCTGT)
        Me.GroupBox6.Controls.Add(Me.txtFecInicioDesarrollo)
        Me.GroupBox6.Controls.Add(Me.lblFecIinicioDesarrollo)
        Me.GroupBox6.Controls.Add(Me.lbltFecAprobacionCTGT)
        Me.GroupBox6.Controls.Add(Me.lblFecAprobacionCONANCE)
        Me.GroupBox6.Controls.Add(Me.lblFecResolucionComentarios)
        Me.GroupBox6.Controls.Add(Me.lblFecEnvioDGN)
        Me.GroupBox6.Location = New System.Drawing.Point(3, 483)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(749, 77)
        Me.GroupBox6.TabIndex = 18
        Me.GroupBox6.TabStop = False
        '
        'txtFecEnvioDGN
        '
        Me.txtFecEnvioDGN.Location = New System.Drawing.Point(623, 18)
        Me.txtFecEnvioDGN.Name = "txtFecEnvioDGN"
        Me.txtFecEnvioDGN.Size = New System.Drawing.Size(80, 20)
        Me.txtFecEnvioDGN.TabIndex = 27
        Me.txtFecEnvioDGN.Text = ""
        '
        'txtFecResolucionComentarios
        '
        Me.txtFecResolucionComentarios.Location = New System.Drawing.Point(404, 47)
        Me.txtFecResolucionComentarios.Name = "txtFecResolucionComentarios"
        Me.txtFecResolucionComentarios.Size = New System.Drawing.Size(80, 20)
        Me.txtFecResolucionComentarios.TabIndex = 26
        Me.txtFecResolucionComentarios.Text = ""
        '
        'txtFecAprobacionCONANCE
        '
        Me.txtFecAprobacionCONANCE.Location = New System.Drawing.Point(404, 15)
        Me.txtFecAprobacionCONANCE.Name = "txtFecAprobacionCONANCE"
        Me.txtFecAprobacionCONANCE.Size = New System.Drawing.Size(80, 20)
        Me.txtFecAprobacionCONANCE.TabIndex = 25
        Me.txtFecAprobacionCONANCE.Text = ""
        '
        'txtFecAprobacionCTGT
        '
        Me.txtFecAprobacionCTGT.Location = New System.Drawing.Point(131, 44)
        Me.txtFecAprobacionCTGT.Name = "txtFecAprobacionCTGT"
        Me.txtFecAprobacionCTGT.Size = New System.Drawing.Size(80, 20)
        Me.txtFecAprobacionCTGT.TabIndex = 24
        Me.txtFecAprobacionCTGT.Text = ""
        '
        'txtFecInicioDesarrollo
        '
        Me.txtFecInicioDesarrollo.Location = New System.Drawing.Point(131, 13)
        Me.txtFecInicioDesarrollo.Name = "txtFecInicioDesarrollo"
        Me.txtFecInicioDesarrollo.Size = New System.Drawing.Size(80, 20)
        Me.txtFecInicioDesarrollo.TabIndex = 23
        Me.txtFecInicioDesarrollo.Text = ""
        '
        'lblFecIinicioDesarrollo
        '
        Me.lblFecIinicioDesarrollo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecIinicioDesarrollo.Location = New System.Drawing.Point(5, 11)
        Me.lblFecIinicioDesarrollo.Name = "lblFecIinicioDesarrollo"
        Me.lblFecIinicioDesarrollo.Size = New System.Drawing.Size(120, 29)
        Me.lblFecIinicioDesarrollo.TabIndex = 19
        Me.lblFecIinicioDesarrollo.Text = "Fecha de Inicio de Desarrollo:"
        '
        'lbltFecAprobacionCTGT
        '
        Me.lbltFecAprobacionCTGT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltFecAprobacionCTGT.Location = New System.Drawing.Point(5, 43)
        Me.lbltFecAprobacionCTGT.Name = "lbltFecAprobacionCTGT"
        Me.lbltFecAprobacionCTGT.Size = New System.Drawing.Size(120, 29)
        Me.lbltFecAprobacionCTGT.TabIndex = 18
        Me.lbltFecAprobacionCTGT.Text = "Fecha de Aprobaci�n (CT, GT):"
        '
        'lblFecAprobacionCONANCE
        '
        Me.lblFecAprobacionCONANCE.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecAprobacionCONANCE.Location = New System.Drawing.Point(272, 12)
        Me.lblFecAprobacionCONANCE.Name = "lblFecAprobacionCONANCE"
        Me.lblFecAprobacionCONANCE.Size = New System.Drawing.Size(120, 29)
        Me.lblFecAprobacionCONANCE.TabIndex = 20
        Me.lblFecAprobacionCONANCE.Text = "Fecha de Aprobaci�n (CONANCE):"
        '
        'lblFecResolucionComentarios
        '
        Me.lblFecResolucionComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecResolucionComentarios.Location = New System.Drawing.Point(272, 43)
        Me.lblFecResolucionComentarios.Name = "lblFecResolucionComentarios"
        Me.lblFecResolucionComentarios.Size = New System.Drawing.Size(120, 29)
        Me.lblFecResolucionComentarios.TabIndex = 22
        Me.lblFecResolucionComentarios.Text = "Fecha a Resoluci�n de Comentarios:"
        '
        'lblFecEnvioDGN
        '
        Me.lblFecEnvioDGN.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecEnvioDGN.Location = New System.Drawing.Point(536, 14)
        Me.lblFecEnvioDGN.Name = "lblFecEnvioDGN"
        Me.lblFecEnvioDGN.Size = New System.Drawing.Size(88, 29)
        Me.lblFecEnvioDGN.TabIndex = 21
        Me.lblFecEnvioDGN.Text = "Fecha de Envio a DGN:"
        '
        'gpbInternacional
        '
        Me.gpbInternacional.Controls.Add(Me.chkAdoptada)
        Me.gpbInternacional.Controls.Add(Me.cmdAdoptada)
        Me.gpbInternacional.Controls.Add(Me.grdAdoptada)
        Me.gpbInternacional.Controls.Add(Me.txtTituloAdoptado)
        Me.gpbInternacional.Controls.Add(Me.txtClasificacionAdoptada)
        Me.gpbInternacional.Controls.Add(Me.lblAdoptada)
        Me.gpbInternacional.Controls.Add(Me.lblClasificacionAdoptada)
        Me.gpbInternacional.Controls.Add(Me.lblTituloAdoptado)
        Me.gpbInternacional.Location = New System.Drawing.Point(3, -2)
        Me.gpbInternacional.Name = "gpbInternacional"
        Me.gpbInternacional.Size = New System.Drawing.Size(749, 88)
        Me.gpbInternacional.TabIndex = 0
        Me.gpbInternacional.TabStop = False
        '
        'chkAdoptada
        '
        Me.chkAdoptada.Location = New System.Drawing.Point(10, 51)
        Me.chkAdoptada.Name = "chkAdoptada"
        Me.chkAdoptada.Size = New System.Drawing.Size(16, 13)
        Me.chkAdoptada.TabIndex = 16
        '
        'cmdAdoptada
        '
        Me.cmdAdoptada.Location = New System.Drawing.Point(360, 16)
        Me.cmdAdoptada.Name = "cmdAdoptada"
        Me.cmdAdoptada.Size = New System.Drawing.Size(56, 23)
        Me.cmdAdoptada.TabIndex = 15
        Me.cmdAdoptada.Text = "Agregar"
        '
        'grdAdoptada
        '
        Me.grdAdoptada.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdAdoptada.CaptionVisible = False
        Me.grdAdoptada.DataMember = ""
        Me.grdAdoptada.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdAdoptada.Location = New System.Drawing.Point(424, 10)
        Me.grdAdoptada.Name = "grdAdoptada"
        Me.grdAdoptada.ReadOnly = True
        Me.grdAdoptada.Size = New System.Drawing.Size(320, 74)
        Me.grdAdoptada.TabIndex = 14
        '
        'txtTituloAdoptado
        '
        Me.txtTituloAdoptado.Location = New System.Drawing.Point(168, 48)
        Me.txtTituloAdoptado.Name = "txtTituloAdoptado"
        Me.txtTituloAdoptado.Size = New System.Drawing.Size(184, 20)
        Me.txtTituloAdoptado.TabIndex = 13
        Me.txtTituloAdoptado.Text = ""
        '
        'txtClasificacionAdoptada
        '
        Me.txtClasificacionAdoptada.Location = New System.Drawing.Point(168, 16)
        Me.txtClasificacionAdoptada.Name = "txtClasificacionAdoptada"
        Me.txtClasificacionAdoptada.Size = New System.Drawing.Size(184, 20)
        Me.txtClasificacionAdoptada.TabIndex = 12
        Me.txtClasificacionAdoptada.Text = ""
        '
        'lblAdoptada
        '
        Me.lblAdoptada.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdoptada.Location = New System.Drawing.Point(8, 19)
        Me.lblAdoptada.Name = "lblAdoptada"
        Me.lblAdoptada.Size = New System.Drawing.Size(64, 29)
        Me.lblAdoptada.TabIndex = 11
        Me.lblAdoptada.Text = "Norma Adoptada:"
        '
        'lblClasificacionAdoptada
        '
        Me.lblClasificacionAdoptada.AutoSize = True
        Me.lblClasificacionAdoptada.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacionAdoptada.Location = New System.Drawing.Point(100, 20)
        Me.lblClasificacionAdoptada.Name = "lblClasificacionAdoptada"
        Me.lblClasificacionAdoptada.Size = New System.Drawing.Size(68, 16)
        Me.lblClasificacionAdoptada.TabIndex = 11
        Me.lblClasificacionAdoptada.Text = "Clasificaci�n"
        '
        'lblTituloAdoptado
        '
        Me.lblTituloAdoptado.AutoSize = True
        Me.lblTituloAdoptado.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTituloAdoptado.Location = New System.Drawing.Point(132, 52)
        Me.lblTituloAdoptado.Name = "lblTituloAdoptado"
        Me.lblTituloAdoptado.Size = New System.Drawing.Size(33, 16)
        Me.lblTituloAdoptado.TabIndex = 11
        Me.lblTituloAdoptado.Text = "T�tulo"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkArmonizada)
        Me.GroupBox2.Controls.Add(Me.cmdArmonizada)
        Me.GroupBox2.Controls.Add(Me.grdArmonizada)
        Me.GroupBox2.Controls.Add(Me.txtClasificacionCSA)
        Me.GroupBox2.Controls.Add(Me.txtClasificacionUL)
        Me.GroupBox2.Controls.Add(Me.lblArmonizada)
        Me.GroupBox2.Controls.Add(Me.lblClasificacionUL)
        Me.GroupBox2.Controls.Add(Me.lblTituloUL)
        Me.GroupBox2.Controls.Add(Me.lblClasificacionCSA)
        Me.GroupBox2.Controls.Add(Me.txtTituloUL)
        Me.GroupBox2.Controls.Add(Me.lblTituloCSA)
        Me.GroupBox2.Controls.Add(Me.txtTituloCSA)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 86)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(749, 134)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        '
        'chkArmonizada
        '
        Me.chkArmonizada.Location = New System.Drawing.Point(10, 51)
        Me.chkArmonizada.Name = "chkArmonizada"
        Me.chkArmonizada.Size = New System.Drawing.Size(16, 13)
        Me.chkArmonizada.TabIndex = 16
        '
        'cmdArmonizada
        '
        Me.cmdArmonizada.Location = New System.Drawing.Point(360, 16)
        Me.cmdArmonizada.Name = "cmdArmonizada"
        Me.cmdArmonizada.Size = New System.Drawing.Size(56, 23)
        Me.cmdArmonizada.TabIndex = 15
        Me.cmdArmonizada.Text = "Agregar"
        '
        'grdArmonizada
        '
        Me.grdArmonizada.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdArmonizada.CaptionVisible = False
        Me.grdArmonizada.DataMember = ""
        Me.grdArmonizada.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdArmonizada.Location = New System.Drawing.Point(424, 11)
        Me.grdArmonizada.Name = "grdArmonizada"
        Me.grdArmonizada.ReadOnly = True
        Me.grdArmonizada.Size = New System.Drawing.Size(320, 114)
        Me.grdArmonizada.TabIndex = 14
        '
        'txtClasificacionCSA
        '
        Me.txtClasificacionCSA.Location = New System.Drawing.Point(168, 72)
        Me.txtClasificacionCSA.Name = "txtClasificacionCSA"
        Me.txtClasificacionCSA.Size = New System.Drawing.Size(184, 20)
        Me.txtClasificacionCSA.TabIndex = 13
        Me.txtClasificacionCSA.Text = ""
        '
        'txtClasificacionUL
        '
        Me.txtClasificacionUL.Location = New System.Drawing.Point(168, 16)
        Me.txtClasificacionUL.Name = "txtClasificacionUL"
        Me.txtClasificacionUL.Size = New System.Drawing.Size(184, 20)
        Me.txtClasificacionUL.TabIndex = 12
        Me.txtClasificacionUL.Text = ""
        '
        'lblArmonizada
        '
        Me.lblArmonizada.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblArmonizada.Location = New System.Drawing.Point(8, 19)
        Me.lblArmonizada.Name = "lblArmonizada"
        Me.lblArmonizada.Size = New System.Drawing.Size(72, 29)
        Me.lblArmonizada.TabIndex = 11
        Me.lblArmonizada.Text = "Norma Armonizada:"
        '
        'lblClasificacionUL
        '
        Me.lblClasificacionUL.AutoSize = True
        Me.lblClasificacionUL.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacionUL.Location = New System.Drawing.Point(87, 20)
        Me.lblClasificacionUL.Name = "lblClasificacionUL"
        Me.lblClasificacionUL.Size = New System.Drawing.Size(85, 16)
        Me.lblClasificacionUL.TabIndex = 11
        Me.lblClasificacionUL.Text = "Clasificaci�n UL"
        '
        'lblTituloUL
        '
        Me.lblTituloUL.AutoSize = True
        Me.lblTituloUL.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTituloUL.Location = New System.Drawing.Point(118, 49)
        Me.lblTituloUL.Name = "lblTituloUL"
        Me.lblTituloUL.Size = New System.Drawing.Size(50, 16)
        Me.lblTituloUL.TabIndex = 11
        Me.lblTituloUL.Text = "T�tulo UL"
        '
        'lblClasificacionCSA
        '
        Me.lblClasificacionCSA.AutoSize = True
        Me.lblClasificacionCSA.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacionCSA.Location = New System.Drawing.Point(73, 78)
        Me.lblClasificacionCSA.Name = "lblClasificacionCSA"
        Me.lblClasificacionCSA.Size = New System.Drawing.Size(94, 16)
        Me.lblClasificacionCSA.TabIndex = 11
        Me.lblClasificacionCSA.Text = "Clasificaci�n CSA"
        '
        'txtTituloUL
        '
        Me.txtTituloUL.Location = New System.Drawing.Point(168, 42)
        Me.txtTituloUL.Name = "txtTituloUL"
        Me.txtTituloUL.Size = New System.Drawing.Size(184, 20)
        Me.txtTituloUL.TabIndex = 12
        Me.txtTituloUL.Text = ""
        '
        'lblTituloCSA
        '
        Me.lblTituloCSA.AutoSize = True
        Me.lblTituloCSA.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTituloCSA.Location = New System.Drawing.Point(109, 107)
        Me.lblTituloCSA.Name = "lblTituloCSA"
        Me.lblTituloCSA.Size = New System.Drawing.Size(59, 16)
        Me.lblTituloCSA.TabIndex = 11
        Me.lblTituloCSA.Text = "T�tulo CSA"
        '
        'txtTituloCSA
        '
        Me.txtTituloCSA.Location = New System.Drawing.Point(168, 104)
        Me.txtTituloCSA.Name = "txtTituloCSA"
        Me.txtTituloCSA.Size = New System.Drawing.Size(184, 20)
        Me.txtTituloCSA.TabIndex = 13
        Me.txtTituloCSA.Text = ""
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkNOM)
        Me.GroupBox3.Controls.Add(Me.cmdNOM)
        Me.GroupBox3.Controls.Add(Me.grdNOM)
        Me.GroupBox3.Controls.Add(Me.txtTituloNOM)
        Me.GroupBox3.Controls.Add(Me.txtClasificacionNOM)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.lblClasificacionNOM)
        Me.GroupBox3.Controls.Add(Me.lblClasificaionNOM)
        Me.GroupBox3.Location = New System.Drawing.Point(3, 218)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(749, 86)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        '
        'chkNOM
        '
        Me.chkNOM.Location = New System.Drawing.Point(10, 62)
        Me.chkNOM.Name = "chkNOM"
        Me.chkNOM.Size = New System.Drawing.Size(16, 12)
        Me.chkNOM.TabIndex = 16
        '
        'cmdNOM
        '
        Me.cmdNOM.Location = New System.Drawing.Point(360, 16)
        Me.cmdNOM.Name = "cmdNOM"
        Me.cmdNOM.Size = New System.Drawing.Size(56, 23)
        Me.cmdNOM.TabIndex = 15
        Me.cmdNOM.Text = "Agregar"
        '
        'grdNOM
        '
        Me.grdNOM.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdNOM.CaptionVisible = False
        Me.grdNOM.DataMember = ""
        Me.grdNOM.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdNOM.Location = New System.Drawing.Point(424, 0)
        Me.grdNOM.Name = "grdNOM"
        Me.grdNOM.ReadOnly = True
        Me.grdNOM.Size = New System.Drawing.Size(320, 72)
        Me.grdNOM.TabIndex = 14
        '
        'txtTituloNOM
        '
        Me.txtTituloNOM.Location = New System.Drawing.Point(168, 48)
        Me.txtTituloNOM.Name = "txtTituloNOM"
        Me.txtTituloNOM.Size = New System.Drawing.Size(184, 20)
        Me.txtTituloNOM.TabIndex = 13
        Me.txtTituloNOM.Text = ""
        '
        'txtClasificacionNOM
        '
        Me.txtClasificacionNOM.Location = New System.Drawing.Point(168, 16)
        Me.txtClasificacionNOM.Name = "txtClasificacionNOM"
        Me.txtClasificacionNOM.Size = New System.Drawing.Size(184, 20)
        Me.txtClasificacionNOM.TabIndex = 12
        Me.txtClasificacionNOM.Text = ""
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 37)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Norma Referenciada en una NOM:"
        '
        'lblClasificacionNOM
        '
        Me.lblClasificacionNOM.AutoSize = True
        Me.lblClasificacionNOM.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacionNOM.Location = New System.Drawing.Point(98, 20)
        Me.lblClasificacionNOM.Name = "lblClasificacionNOM"
        Me.lblClasificacionNOM.Size = New System.Drawing.Size(68, 16)
        Me.lblClasificacionNOM.TabIndex = 11
        Me.lblClasificacionNOM.Text = "Clasificaci�n"
        '
        'lblClasificaionNOM
        '
        Me.lblClasificaionNOM.AutoSize = True
        Me.lblClasificaionNOM.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificaionNOM.Location = New System.Drawing.Point(130, 48)
        Me.lblClasificaionNOM.Name = "lblClasificaionNOM"
        Me.lblClasificaionNOM.Size = New System.Drawing.Size(33, 16)
        Me.lblClasificaionNOM.TabIndex = 11
        Me.lblClasificaionNOM.Text = "T�tulo"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.chkNMX)
        Me.GroupBox4.Controls.Add(Me.cmdNMX)
        Me.GroupBox4.Controls.Add(Me.grdNMX)
        Me.GroupBox4.Controls.Add(Me.txtTituloNMX)
        Me.GroupBox4.Controls.Add(Me.txtClasificacionNMX)
        Me.GroupBox4.Controls.Add(Me.lblNMX)
        Me.GroupBox4.Controls.Add(Me.lblClasificacionNMX)
        Me.GroupBox4.Controls.Add(Me.lblTituloNMX)
        Me.GroupBox4.Location = New System.Drawing.Point(3, 306)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(749, 88)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        '
        'chkNMX
        '
        Me.chkNMX.Location = New System.Drawing.Point(10, 62)
        Me.chkNMX.Name = "chkNMX"
        Me.chkNMX.Size = New System.Drawing.Size(16, 12)
        Me.chkNMX.TabIndex = 16
        '
        'cmdNMX
        '
        Me.cmdNMX.Location = New System.Drawing.Point(360, 16)
        Me.cmdNMX.Name = "cmdNMX"
        Me.cmdNMX.Size = New System.Drawing.Size(56, 23)
        Me.cmdNMX.TabIndex = 15
        Me.cmdNMX.Text = "Agregar"
        '
        'grdNMX
        '
        Me.grdNMX.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdNMX.CaptionVisible = False
        Me.grdNMX.DataMember = ""
        Me.grdNMX.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdNMX.Location = New System.Drawing.Point(424, 8)
        Me.grdNMX.Name = "grdNMX"
        Me.grdNMX.ReadOnly = True
        Me.grdNMX.Size = New System.Drawing.Size(320, 74)
        Me.grdNMX.TabIndex = 14
        '
        'txtTituloNMX
        '
        Me.txtTituloNMX.Location = New System.Drawing.Point(168, 48)
        Me.txtTituloNMX.Name = "txtTituloNMX"
        Me.txtTituloNMX.Size = New System.Drawing.Size(184, 20)
        Me.txtTituloNMX.TabIndex = 13
        Me.txtTituloNMX.Text = ""
        '
        'txtClasificacionNMX
        '
        Me.txtClasificacionNMX.Location = New System.Drawing.Point(168, 16)
        Me.txtClasificacionNMX.Name = "txtClasificacionNMX"
        Me.txtClasificacionNMX.Size = New System.Drawing.Size(184, 20)
        Me.txtClasificacionNMX.TabIndex = 12
        Me.txtClasificacionNMX.Text = ""
        '
        'lblNMX
        '
        Me.lblNMX.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNMX.Location = New System.Drawing.Point(8, 19)
        Me.lblNMX.Name = "lblNMX"
        Me.lblNMX.Size = New System.Drawing.Size(80, 37)
        Me.lblNMX.TabIndex = 11
        Me.lblNMX.Text = "Norma Referenciada en una NMX:"
        '
        'lblClasificacionNMX
        '
        Me.lblClasificacionNMX.AutoSize = True
        Me.lblClasificacionNMX.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacionNMX.Location = New System.Drawing.Point(98, 20)
        Me.lblClasificacionNMX.Name = "lblClasificacionNMX"
        Me.lblClasificacionNMX.Size = New System.Drawing.Size(68, 16)
        Me.lblClasificacionNMX.TabIndex = 11
        Me.lblClasificacionNMX.Text = "Clasificaci�n"
        '
        'lblTituloNMX
        '
        Me.lblTituloNMX.AutoSize = True
        Me.lblTituloNMX.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTituloNMX.Location = New System.Drawing.Point(130, 48)
        Me.lblTituloNMX.Name = "lblTituloNMX"
        Me.lblTituloNMX.Size = New System.Drawing.Size(33, 16)
        Me.lblTituloNMX.TabIndex = 11
        Me.lblTituloNMX.Text = "T�tulo"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.chkNRF)
        Me.GroupBox5.Controls.Add(Me.cmdNRF)
        Me.GroupBox5.Controls.Add(Me.grdNRF)
        Me.GroupBox5.Controls.Add(Me.txtTituloNRF)
        Me.GroupBox5.Controls.Add(Me.txtClasificacionNRF)
        Me.GroupBox5.Controls.Add(Me.lblNRF)
        Me.GroupBox5.Controls.Add(Me.lbltClasificacionNRF)
        Me.GroupBox5.Controls.Add(Me.lblTituloNRF)
        Me.GroupBox5.Location = New System.Drawing.Point(3, 394)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(749, 88)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        '
        'chkNRF
        '
        Me.chkNRF.Location = New System.Drawing.Point(10, 61)
        Me.chkNRF.Name = "chkNRF"
        Me.chkNRF.Size = New System.Drawing.Size(16, 13)
        Me.chkNRF.TabIndex = 16
        '
        'cmdNRF
        '
        Me.cmdNRF.Location = New System.Drawing.Point(360, 16)
        Me.cmdNRF.Name = "cmdNRF"
        Me.cmdNRF.Size = New System.Drawing.Size(56, 23)
        Me.cmdNRF.TabIndex = 15
        Me.cmdNRF.Text = "Agregar"
        '
        'grdNRF
        '
        Me.grdNRF.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdNRF.CaptionVisible = False
        Me.grdNRF.DataMember = ""
        Me.grdNRF.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdNRF.Location = New System.Drawing.Point(424, 8)
        Me.grdNRF.Name = "grdNRF"
        Me.grdNRF.ReadOnly = True
        Me.grdNRF.Size = New System.Drawing.Size(320, 74)
        Me.grdNRF.TabIndex = 14
        '
        'txtTituloNRF
        '
        Me.txtTituloNRF.Location = New System.Drawing.Point(168, 48)
        Me.txtTituloNRF.Name = "txtTituloNRF"
        Me.txtTituloNRF.Size = New System.Drawing.Size(184, 20)
        Me.txtTituloNRF.TabIndex = 13
        Me.txtTituloNRF.Text = ""
        '
        'txtClasificacionNRF
        '
        Me.txtClasificacionNRF.Location = New System.Drawing.Point(168, 16)
        Me.txtClasificacionNRF.Name = "txtClasificacionNRF"
        Me.txtClasificacionNRF.Size = New System.Drawing.Size(184, 20)
        Me.txtClasificacionNRF.TabIndex = 12
        Me.txtClasificacionNRF.Text = ""
        '
        'lblNRF
        '
        Me.lblNRF.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNRF.Location = New System.Drawing.Point(8, 19)
        Me.lblNRF.Name = "lblNRF"
        Me.lblNRF.Size = New System.Drawing.Size(80, 37)
        Me.lblNRF.TabIndex = 11
        Me.lblNRF.Text = "Norma Referenciada en NRF:"
        '
        'lbltClasificacionNRF
        '
        Me.lbltClasificacionNRF.AutoSize = True
        Me.lbltClasificacionNRF.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltClasificacionNRF.Location = New System.Drawing.Point(98, 20)
        Me.lbltClasificacionNRF.Name = "lbltClasificacionNRF"
        Me.lbltClasificacionNRF.Size = New System.Drawing.Size(68, 16)
        Me.lbltClasificacionNRF.TabIndex = 11
        Me.lbltClasificacionNRF.Text = "Clasificaci�n"
        '
        'lblTituloNRF
        '
        Me.lblTituloNRF.AutoSize = True
        Me.lblTituloNRF.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTituloNRF.Location = New System.Drawing.Point(130, 48)
        Me.lblTituloNRF.Name = "lblTituloNRF"
        Me.lblTituloNRF.Size = New System.Drawing.Size(33, 16)
        Me.lblTituloNRF.TabIndex = 11
        Me.lblTituloNRF.Text = "T�tulo"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.gpbx)
        Me.TabPage4.Controls.Add(Me.GroupBox8)
        Me.TabPage4.Controls.Add(Me.GroupBox10)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(752, 614)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Aclaraciones       "
        Me.TabPage4.Visible = False
        '
        'gpbx
        '
        Me.gpbx.Controls.Add(Me.lblSubirDoctoUno)
        Me.gpbx.Controls.Add(Me.txtDoctoUno)
        Me.gpbx.Controls.Add(Me.lblDoctoUno)
        Me.gpbx.Controls.Add(Me.txtFecUno)
        Me.gpbx.Controls.Add(Me.lblFecUno)
        Me.gpbx.Controls.Add(Me.dtkFecUno)
        Me.gpbx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gpbx.Location = New System.Drawing.Point(7, 8)
        Me.gpbx.Name = "gpbx"
        Me.gpbx.Size = New System.Drawing.Size(741, 80)
        Me.gpbx.TabIndex = 1
        Me.gpbx.TabStop = False
        Me.gpbx.Text = "Aclaraci�n Uno"
        '
        'lblSubirDoctoUno
        '
        Me.lblSubirDoctoUno.AutoSize = True
        Me.lblSubirDoctoUno.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSubirDoctoUno.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubirDoctoUno.ForeColor = System.Drawing.Color.Blue
        Me.lblSubirDoctoUno.Location = New System.Drawing.Point(616, 32)
        Me.lblSubirDoctoUno.Name = "lblSubirDoctoUno"
        Me.lblSubirDoctoUno.Size = New System.Drawing.Size(93, 18)
        Me.lblSubirDoctoUno.TabIndex = 27
        Me.lblSubirDoctoUno.Text = "Adjuntar Docto"
        '
        'txtDoctoUno
        '
        Me.txtDoctoUno.Location = New System.Drawing.Point(256, 32)
        Me.txtDoctoUno.Name = "txtDoctoUno"
        Me.txtDoctoUno.Size = New System.Drawing.Size(350, 20)
        Me.txtDoctoUno.TabIndex = 25
        Me.txtDoctoUno.Text = ""
        '
        'lblDoctoUno
        '
        Me.lblDoctoUno.AutoSize = True
        Me.lblDoctoUno.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDoctoUno.Location = New System.Drawing.Point(176, 32)
        Me.lblDoctoUno.Name = "lblDoctoUno"
        Me.lblDoctoUno.Size = New System.Drawing.Size(70, 16)
        Me.lblDoctoUno.TabIndex = 24
        Me.lblDoctoUno.Text = "Documento:"
        '
        'txtFecUno
        '
        Me.txtFecUno.Location = New System.Drawing.Point(72, 34)
        Me.txtFecUno.Name = "txtFecUno"
        Me.txtFecUno.Size = New System.Drawing.Size(80, 20)
        Me.txtFecUno.TabIndex = 23
        Me.txtFecUno.Text = ""
        '
        'lblFecUno
        '
        Me.lblFecUno.AutoSize = True
        Me.lblFecUno.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecUno.Location = New System.Drawing.Point(20, 34)
        Me.lblFecUno.Name = "lblFecUno"
        Me.lblFecUno.Size = New System.Drawing.Size(41, 16)
        Me.lblFecUno.TabIndex = 22
        Me.lblFecUno.Text = "Fecha:"
        '
        'dtkFecUno
        '
        Me.dtkFecUno.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecUno.Location = New System.Drawing.Point(71, 34)
        Me.dtkFecUno.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkFecUno.Name = "dtkFecUno"
        Me.dtkFecUno.Size = New System.Drawing.Size(100, 20)
        Me.dtkFecUno.TabIndex = 26
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.cmdDocFinal)
        Me.GroupBox8.Controls.Add(Me.txtDoctoNorma)
        Me.GroupBox8.Controls.Add(Me.lblDoctoNorma)
        Me.GroupBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(7, 208)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(740, 72)
        Me.GroupBox8.TabIndex = 0
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Documento de la Norma"
        '
        'cmdDocFinal
        '
        Me.cmdDocFinal.Enabled = False
        Me.cmdDocFinal.Location = New System.Drawing.Point(536, 32)
        Me.cmdDocFinal.Name = "cmdDocFinal"
        Me.cmdDocFinal.TabIndex = 23
        Me.cmdDocFinal.Text = "Adjuntar"
        '
        'txtDoctoNorma
        '
        Me.txtDoctoNorma.Enabled = False
        Me.txtDoctoNorma.Location = New System.Drawing.Point(200, 30)
        Me.txtDoctoNorma.Name = "txtDoctoNorma"
        Me.txtDoctoNorma.Size = New System.Drawing.Size(336, 20)
        Me.txtDoctoNorma.TabIndex = 21
        Me.txtDoctoNorma.Text = ""
        '
        'lblDoctoNorma
        '
        Me.lblDoctoNorma.AutoSize = True
        Me.lblDoctoNorma.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDoctoNorma.Location = New System.Drawing.Point(16, 32)
        Me.lblDoctoNorma.Name = "lblDoctoNorma"
        Me.lblDoctoNorma.Size = New System.Drawing.Size(138, 16)
        Me.lblDoctoNorma.TabIndex = 20
        Me.lblDoctoNorma.Text = "Documento de la Norma:"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.lblSubirDoctoDos)
        Me.GroupBox10.Controls.Add(Me.txtDoctoDos)
        Me.GroupBox10.Controls.Add(Me.lblDocDos)
        Me.GroupBox10.Controls.Add(Me.txtFecDos)
        Me.GroupBox10.Controls.Add(Me.lblFecDos)
        Me.GroupBox10.Controls.Add(Me.dtkFecDos)
        Me.GroupBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(6, 104)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(742, 80)
        Me.GroupBox10.TabIndex = 1
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Aclaraci�n Dos"
        '
        'lblSubirDoctoDos
        '
        Me.lblSubirDoctoDos.AutoSize = True
        Me.lblSubirDoctoDos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSubirDoctoDos.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubirDoctoDos.ForeColor = System.Drawing.Color.Blue
        Me.lblSubirDoctoDos.Location = New System.Drawing.Point(618, 32)
        Me.lblSubirDoctoDos.Name = "lblSubirDoctoDos"
        Me.lblSubirDoctoDos.Size = New System.Drawing.Size(93, 18)
        Me.lblSubirDoctoDos.TabIndex = 28
        Me.lblSubirDoctoDos.Text = "Adjuntar Docto"
        '
        'txtDoctoDos
        '
        Me.txtDoctoDos.Location = New System.Drawing.Point(256, 31)
        Me.txtDoctoDos.Name = "txtDoctoDos"
        Me.txtDoctoDos.Size = New System.Drawing.Size(350, 20)
        Me.txtDoctoDos.TabIndex = 25
        Me.txtDoctoDos.Text = ""
        '
        'lblDocDos
        '
        Me.lblDocDos.AutoSize = True
        Me.lblDocDos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDocDos.Location = New System.Drawing.Point(176, 34)
        Me.lblDocDos.Name = "lblDocDos"
        Me.lblDocDos.Size = New System.Drawing.Size(70, 16)
        Me.lblDocDos.TabIndex = 24
        Me.lblDocDos.Text = "Documento:"
        '
        'txtFecDos
        '
        Me.txtFecDos.Location = New System.Drawing.Point(72, 34)
        Me.txtFecDos.Name = "txtFecDos"
        Me.txtFecDos.Size = New System.Drawing.Size(80, 20)
        Me.txtFecDos.TabIndex = 23
        Me.txtFecDos.Text = ""
        '
        'lblFecDos
        '
        Me.lblFecDos.AutoSize = True
        Me.lblFecDos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecDos.Location = New System.Drawing.Point(20, 34)
        Me.lblFecDos.Name = "lblFecDos"
        Me.lblFecDos.Size = New System.Drawing.Size(41, 16)
        Me.lblFecDos.TabIndex = 22
        Me.lblFecDos.Text = "Fecha:"
        '
        'dtkFecDos
        '
        Me.dtkFecDos.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecDos.Location = New System.Drawing.Point(71, 33)
        Me.dtkFecDos.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkFecDos.Name = "dtkFecDos"
        Me.dtkFecDos.Size = New System.Drawing.Size(100, 20)
        Me.dtkFecDos.TabIndex = 27
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 658)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(776, 62)
        Me.tlbBotonera.TabIndex = 48
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'frmC_Normas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(776, 720)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Menu = Me.MainMenu1
        Me.Name = "frmC_Normas"
        Me.Text = "Cat�logo de Normas"
        Me.GroupBox1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.grdConcordancia, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdCanceladas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.gpbInternacional.ResumeLayout(False)
        CType(Me.grdAdoptada, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdArmonizada, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.grdNOM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.grdNMX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.grdNRF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.gpbx.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmC_Normas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Inactivos(cmdDeshacer, cmdGuardar)
        lblNomClasificacion.Visible = False
        tvComites.Visible = False
        cmdComitesGuardar.Enabled = False

        Call Inicializa_Inactivos()
        Call Carga_Combo_Clasificacion()
        Call Formato_Grid(grdCanceladas)
        Call Formato_GridDetalle(grdConcordancia)

        Call Formato_GridDetalle(grdAdoptada)
        Call Formato_GridDetalle(grdArmonizada)
        Call Formato_GridDetalle(grdNOM)
        Call Formato_GridDetalle(grdNMX)
        Call Formato_GridDetalle(grdNRF)


    End Sub

#Region "  Inicializa Inactivos"
    Sub Inicializa_Inactivos()
        'Pesta�a NMX
        Inactivos(grdCanceladas, cboResponsable, txtTIE, txtTII, txtPaginas, txtObjetivo, txtDeclaratoria, cboConcordancia, txtEntradaVigor, txtBibliografia, txtComite, txtCT, txtSC, txtGT, cmdCanceladas, cmdComites)
        Inactivos(dtkDeclaratoria, dtkEntradaVigor)
        Inactivos(chkAdoptada, chkArmonizada, chkNOM, chkNMX, chkNRF, chkConcordancia)
        Inactivos(txtPertenece, txtresponsable, cmdConcordancia)
        Inactivos(txtFecAviCancelacion, dtkFecAviCancelacion)
        Inactivos(chkObservaciones, txtObservaciones)
        Inactivos(txtTituloConcordancia, txtClasificacionConcordancia, grdConcordancia)
        chkConcordancia.Checked = False

        Inactivos(txtCorporativa, txtPersonal, txtImpresa)

        txtRamaIndustrial.Visible = False
        txtConsecutivo.Visible = False
        txtOrganismo.Visible = False
        txtA�o.Visible = False
        lblNomClasificacion.Enabled = False

        'Pesta�a Caracter�sticas
        Inactivos(chkAdoptada, txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada, grdAdoptada)
        Inactivos(chkArmonizada, txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, cmdArmonizada, grdArmonizada)
        Inactivos(chkNOM, txtClasificacionNOM, txtTituloNOM, cmdNOM, grdNOM)
        Inactivos(chkNMX, txtClasificacionNMX, txtTituloNMX, cmdNMX, grdNMX)
        Inactivos(chkNRF, txtClasificacionNRF, txtTituloNRF, cmdNRF, grdNRF)

        chkAdoptada.Checked = False
        chkArmonizada.Checked = False
        chkNOM.Checked = False
        chkNMX.Checked = False
        chkNRF.Checked = False


        Inactivos(txtFecInicioDesarrollo, txtFecAprobacionCTGT, txtFecAprobacionCONANCE, txtFecResolucionComentarios, txtFecEnvioDGN)
        'Inactivos(dtkFecInicioDesarrollo, dtkFecAprobacionCTGT, dtkFecAprobacionCONANCE, dtkFecResolucionComentarios, dtkFecEnvioDGN)

        'Pesta�a Revision quinquenal
        Inactivos(txtRevisionQuinquenal, txtDeclaratoriaVigencia, txtNotificacionRatificacion, txtPublicacionConsulta, txtFechaLimite, txtNotificacionModificacion)
        Inactivos(dtkNotificacionRatificacion, dtkNotificacionModificacion)

        'Pesta�a Documentos
        Inactivos(txtDoctoNorma, txtFecUno, txtDoctoUno, txtFecDos, txtDoctoDos)
        Inactivos(lblSubirDoctoUno, lblSubirDoctoDos)
        Inactivos(dtkFecUno, dtkFecDos)
    End Sub
#End Region

#Region "  Inicializa Activos"
    Sub Inicializa_Activos()
        'Pesta�a NMX
        Activos(grdCanceladas, cboResponsable, txtTIE, txtTII, txtPaginas, txtObjetivo, txtBibliografia, txtComite, txtCT, txtSC, txtGT, cmdCanceladas)
        Activos(txtNorma, dtkDeclaratoria, dtkEntradaVigor)
        Inactivos(chkAdoptada, chkArmonizada, chkNOM, chkNMX, chkNRF)
        Inactivos(chkConcordancia)

        Activos(dtkFecAviCancelacion, cboConcordancia)
        Activos(txtImpresa, txtPersonal, txtCorporativa)
        'Activos(txtresponsable)

        ''''Pesta�a Caracter�sticas
        '''Activos(chkAdoptada, txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada, grdAdoptada)
        '''Activos(chkArmonizada, txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, cmdArmonizada, grdArmonizada)
        '''Activos(chkNOM, txtClasificacionNOM, txtTituloNOM, cmdNOM, grdNOM)
        '''Activos(chkNMX, txtClasificacionNMX, txtTituloNMX, cmdNMX, grdNMX)
        '''Activos(chkNRF, txtClasificacionNRF, txtTituloNRF, cmdNRF, grdNRF)

        'Activos(txtFecInicioDesarrollo, txtFecAprobacionCTGT, txtFecAprobacionCONANCE, txtFecResolucionComentarios, txtFecEnvioDGN)
        ' Activos(dtkFecInicioDesarrollo, dtkFecAprobacionCTGT, dtkFecAprobacionCONANCE, dtkFecResolucionComentarios, dtkFecEnvioDGN)

        'Pesta�a Revision quinquenal
        'Activos(txtRevisionQuinquenal, txtDeclaratoriaVigencia, txtNotificacionRatificacion, txtPublicacionConsulta, txtFechaLimite, txtNotificacionModificacion)
        Activos(dtkNotificacionRatificacion, dtkNotificacionModificacion)

        'Pesta�a Documentos
        'Activos(txtDoctoNorma, txtDoctoUno, txtDoctoDos)
        Activos(lblSubirDoctoUno, lblSubirDoctoDos)
        'Activos(dtkFecUno, dtkFecDos)
    End Sub
#End Region

    Sub Inicializa_Activos_Modificar()
        Activos(chkAdoptada, chkArmonizada, chkNOM, chkNMX, chkNRF)
        Activos(chkConcordancia)
    End Sub

#Region "  Limpia Inactivos"
    Sub Limpia_Inactivos()
        ''Pesta�a NMX
        Limpia_Campos(grdCanceladas, cboResponsable, txtTIE, txtTII, txtPaginas, txtObjetivo, txtDeclaratoria, cboConcordancia, grdConcordancia, txtEntradaVigor, txtBibliografia, txtComite, txtCT, txtSC, txtGT, cmdCanceladas, cmdComites, txtNorma)
        Limpia_Campos(txtFecAviCancelacion)
        ''Pesta�a Caracter�sticas
        Limpia_Campos(chkAdoptada, txtClasificacionAdoptada, txtTituloAdoptado, grdAdoptada)
        Limpia_Campos(chkArmonizada, txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, grdArmonizada)
        Limpia_Campos(chkNOM, txtClasificacionNOM, txtTituloNOM, grdNOM)
        Limpia_Campos(chkNMX, txtClasificacionNMX, txtTituloNMX, grdNMX)
        Limpia_Campos(chkNRF, txtClasificacionNRF, txtTituloNRF, grdNRF)
        Limpia_Campos(txtFecInicioDesarrollo, txtFecAprobacionCTGT, txtFecAprobacionCONANCE, txtFecResolucionComentarios, txtFecEnvioDGN)
        ''Pesta�a Revision quinquenal
        Limpia_Campos(txtRevisionQuinquenal, txtDeclaratoriaVigencia, txtNotificacionRatificacion, txtPublicacionConsulta, txtFechaLimite, txtNotificacionModificacion)
        ''Pesta�a Documentos
        Limpia_Campos(txtDoctoNorma, txtFecUno, txtDoctoUno, txtFecDos, txtDoctoDos)
        Limpia_Campos(txtRamaIndustrial, txtConsecutivo, txtOrganismo, txtA�o)
    End Sub
#End Region

#Region " Carga Combos Clasificacion/Cancelada"
    Sub Carga_Combo_Clasificacion()
        objNormas.Bandera = 1
        If chkNormasCan.Checked = False Then
            objNormas.Inactivo = 0
        Else
            objNormas.Inactivo = 1 'es para validar en el store que no tome este parametro en el where
        End If
        objNormas.ListaCombo(cboClasificacion)  'funfiona
        'If objNormas Is Nothing Then
        If cboClasificacion.Items.Count = 0 Then
            'cboClasificacion.DataSource = Nothing
            ''cboClasificacion.Items.Add("Lista vacia")
            cboClasificacion.Text = "Lista Vacia"
            Inactivos(cmdEditar)
            ''''txtDescripcion.Text = "Lista vacia"
            Exit Sub
        End If
        'NormaClasificacion = cboClasificacion.SelectedValue
        'NormaClasificacion = cboClasificacion.SelectedText
        sEtapaGrid = "Canceladas"
        'Call Llena_Variables(NormaClasificacion)
        'Call Carga_Combo_Cancelada()
    End Sub


    Sub Carga_Combo_Cancelada()
        objNormas.Bandera = 2
        objNormas.Clasificacion = NormaClasificacion
        objNormas.ListaCombo(cboCancelada)  'funciona
        If objNormas Is Nothing Then
            cboClasificacion.Items.Add("Lista vacia")
            'txtDescripcion.Text = "Lista vacia"
            Exit Sub
        End If
    End Sub

#End Region

#Region "  Botonera"
    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                sTipoProceso = "Agregar"
                Call Agregar()

                'para mostrar el treeview
                cmdComites.Enabled = False
                cmdComitesGuardar.Enabled = True
                Call llena_TreeView()


            Case 2 'EDITAR
                sTipoProceso = "Editar"
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas, cmdDocFinal)
                Inactivos(cmdAgregar)
                Call Editar()

                'para mostrar el treeview
                cmdComites.Enabled = False
                cmdComitesGuardar.Enabled = True
                Call llena_TreeView()
                If txtDoctoNorma.Text <> "" Then
                    cmdDocFinal.Enabled = False
                End If

                If txtDoctoUno.Text <> "" Then lblSubirDoctoUno.Enabled = False
                If txtDoctoDos.Text <> "" Then lblSubirDoctoDos.Enabled = False
                If txtDoctoUno.Text = "" Then lblSubirDoctoDos.Enabled = False

                If txtDoctoUno.Text <> "" And txtDoctoDos.Text <> "" Then
                    adjunta = False
                Else
                    adjunta = True
                End If

            Case 3 'DESHACER
                Call Deshacer()

                'para ocultar el treeview
                tvComites.Nodes.Clear()
                Call llena_TreeView()
                tvComites.Visible = False
                cmdComites.Enabled = True
                cmdComitesGuardar.Enabled = False
                txtNorma.Visible = False
                cboClasificacion.Visible = True
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                'Activos(tvComites, cmdAgregar, cmdEditar, cmdBorrar)

            Case 4 'GUARDAR
                Inactivos(cmdDeshacer, cmdGuardar, grdCanceladas, cmdDocFinal, txtDoctoNorma)
                Activos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Call Guardar()

            Case 5 'BORRAR
                Call borrar()

            Case 7 'SALIR
                Me.Close()
        End Select
    End Sub
#End Region

    Private Sub EtapasInspeccion()
        ObjPrograma.Buscar(txtId_Plan.Text, txtId_Tema.Text)
        llenaPrevio()
        ValidaEtapa7()
        ValidaEtapa8()
        ValidaEtapa9()
        ValidaEtapa10()
        ValidaEtapa11()
    End Sub
    Private Sub llenaPrevio()
        objInspeccionPrueba.ref_a�o = ObjPrograma.RefA�o
        objInspeccionPrueba.ref_comite = ObjPrograma.RefComite
        objInspeccionPrueba.ref_consecutivo = ObjPrograma.RefConsecutivo
        objInspeccionPrueba.ref_regreso = ObjPrograma.RefRegreso
        objInspeccionPrueba.ref_traspaso = ObjPrograma.RefTraspaso
    End Sub
    Private Sub ValidaEtapa7()
        'si tengo fecha de acuse de dgn proyf 
        '''''IA en la 1 y 2 y 3,4,5 IE
        'de lo contrario
        '''''blanco en todas las inspecciones

        'si tengo la fecha declaratoria de vigencia 
        '''''IA 3,4,5

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.sReferencia = srefP
        objInspeccionPrueba.Buscar()
        ObjFechasavance.Buscar(txtId_Tema.Text, txtId_Plan.Text, srefP)

        If ObjFechasavance.F_ACUSE_DGN_PROYF <> "" Then
            objInspeccionPrueba.E7_1 = "IA"
            objInspeccionPrueba.E7_2 = "IA"
            objInspeccionPrueba.E7_3 = "IE"
            objInspeccionPrueba.E7_4 = "IE"
            objInspeccionPrueba.E7_5 = "IE"
        End If
        If txtDeclaratoria.Text <> "" Then
            objInspeccionPrueba.E7_3 = "IA"
            objInspeccionPrueba.E7_4 = "IA"
            objInspeccionPrueba.E7_5 = "IA"
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub
    Private Sub ValidaEtapa8()

        'si hay fecha declaratoria de vigencia 
        '''IA
        'De lo contrario
        '''si tengo fecha acuse DGN 
        ''''''IE
        '''de lo contrario
        ''''''nada

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtDeclaratoria.Text <> "" Then
            objInspeccionPrueba.E8_1 = "IA"
            objInspeccionPrueba.E8_2 = "IA"
        Else
            ObjFechasavance.Buscar(txtId_Tema.Text, txtId_Plan.Text, srefP)
            If ObjFechasavance.F_ACUSE_DGN_PROYF <> "" Then
                objInspeccionPrueba.E8_1 = "IE"
                objInspeccionPrueba.E8_2 = "IE"
            Else
                objInspeccionPrueba.E8_1 = ""
                objInspeccionPrueba.E8_2 = ""
            End If
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub
    Private Sub ValidaEtapa9()

        'si tengo fecha revision quinquenal
        ''''IA
        'de lo contrario
        ''''NA

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtRevisionQuinquenal.Text <> "" Then
            objInspeccionPrueba.E9_1 = "IA"
            objInspeccionPrueba.E9_2 = "IA"
        Else
            objInspeccionPrueba.E9_1 = "NA"
            objInspeccionPrueba.E9_2 = "NA"
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub

    Private Sub ValidaEtapa10()

        'si tengo alguna fecha de aclaracion
        ''''IA
        'de lo contrario
        ''''NA

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtFecUno.Text <> "" Or txtFecDos.Text <> "" Then
            objInspeccionPrueba.E10_1 = "IA"
            objInspeccionPrueba.E10_2 = "IA"
            objInspeccionPrueba.E10_3 = "IA"
            objInspeccionPrueba.E10_4 = "IA"
        Else
            objInspeccionPrueba.E10_1 = "NA"
            objInspeccionPrueba.E10_2 = "NA"
            objInspeccionPrueba.E10_3 = "NA"
            objInspeccionPrueba.E10_4 = "NA"
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub

    Private Sub ValidaEtapa11()

        'si es modificacion tecnica
        ''''IA en 1 y 3
        'de lo contrario
        ''''NA en todo
        'si hay fecha de aprobacion comite proy y es modificaion tecnica
        ''''IA en la 2
        'de lo contrario
        ''''si no tiene fecha y es modificacion tecnica 
        '''''''IE en la 2
        'si tengo fecha de acuse dgn y es modificacion tecnica 
        ''''IA en la 4
        'de lo contrario
        ''''IE

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        ObjPrograma.Buscar(txtId_Tema.Text, txtId_Plan.Text)
        ObjFechasavance.Buscar(txtId_Tema.Text, txtId_Plan.Text, srefP)

        If ObjPrograma.Tipo_Pro = "3" Then
            objInspeccionPrueba.E11_1 = "IA"
            objInspeccionPrueba.E11_3 = "IA"
        Else
            objInspeccionPrueba.E11_1 = "NA"
            objInspeccionPrueba.E11_2 = "NA"
            objInspeccionPrueba.E11_3 = "NA"
            objInspeccionPrueba.E11_4 = "NA"
        End If

        If ObjFechasavance.F_Aprobacion_Comite_PROY <> "" And ObjPrograma.Tipo_Pro = "3" Then
            objInspeccionPrueba.E11_2 = "IA"
        Else
            If ObjFechasavance.F_Aprobacion_Comite_PROY = "" And ObjPrograma.Tipo_Pro = "3" Then
                objInspeccionPrueba.E11_2 = "IE"
            End If
        End If

        If ObjFechasavance.F_ACUSE_DGN_PROYF <> "" And ObjPrograma.Tipo_Pro = "3" Then
            objInspeccionPrueba.E11_4 = "IA"
        Else
            If ObjPrograma.Tipo_Pro = "3" Then
                objInspeccionPrueba.E11_4 = "IE"
            Else
                objInspeccionPrueba.E11_4 = ""
            End If
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub

#Region "  Borrar"
    Sub borrar()
        If MsgBox("�Estas seguro que deseas eliminar esta Norma: " & NormaClasificacion, MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
            objNormas.Bandera = 1
            objNormas.Clasificacion = NormaClasificacion
            objNormas.Borrar_Norma() ' aqui va la opci�n de borrar
            Call Inicializa_Inactivos()
            Call Carga_Combo_Clasificacion()
            MsgBox("Norma Borrada", MsgBoxStyle.Information, "Cat�logo de Normas")
        Else
            Exit Sub
        End If
    End Sub
#End Region

#Region "  cboClasificacion_SelectedIndexChanged"
    Private Sub cboClasificacion_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClasificacion.SelectedIndexChanged
        'NormaClasificacion = cboClasificacion.SelectedValue
        'NormaClasificacion = cboClasificacion.Text
        NormaClasificacion = cboClasificacion.SelectedValue
        cboClasificacion.Text = cboClasificacion.SelectedValue
        objNormas.Clasificacion = cboClasificacion.SelectedValue

        txtNorma.Text = cboClasificacion.SelectedValue

        'apenas lo comentarice 27/12/06
        'Call Carga_Combo_Cancelada()


        '**********************************
        objNormas.Bandera = 7
        '*********************************
        objNormas.Tipo_Norma = 1
        objNormas.Tipo_Norma_Dos = 0 'este es solo para que no encuentre nada en la busqueda del sp
        Call Llena_GridDetalle(grdAdoptada)

        objNormas.Tipo_Norma = 2
        objNormas.Tipo_Norma_Dos = 3
        Call Llena_GridDetalle(grdArmonizada)

        objNormas.Tipo_Norma = 4
        objNormas.Tipo_Norma_Dos = 0 'este es solo para que no encuentre nada en la busqueda del sp
        Call Llena_GridDetalle(grdNOM)

        objNormas.Tipo_Norma = 5
        objNormas.Tipo_Norma_Dos = 0 'este es solo para que no encuentre nada en la busqueda del sp
        Call Llena_GridDetalle(grdNMX)

        objNormas.Tipo_Norma = 6
        objNormas.Tipo_Norma_Dos = 0 'este es solo para que no encuentre nada en la busqueda del sp
        Call Llena_GridDetalle(grdNRF)

        objNormas.Tipo_Norma = 7
        objNormas.Tipo_Norma_Dos = 0 'este es solo para que no encuentre nada en la busqueda del sp
        Call Llena_GridDetalle(grdConcordancia)

        Call Llena_Variables(NormaClasificacion)
        'busco el tipo de norma
        objNormas.Bandera = 12
        objNormas.Clasificacion = cboClasificacion.Text
        objNormas.BuscaCaracteristicas()

        LlenaCostos()

        If objNormas.Basada_Norma = True Then
            txtClasificacionAdoptada.Text = objNormas.Id_Norma
            txtClasificacionUL.Text = ""
            txtClasificacionCSA.Text = ""
        Else
            txtClasificacionUL.Text = objNormas.Id_Norma
            txtClasificacionCSA.Text = objNormas.Id_Norma
            txtClasificacionAdoptada.Text = ""
        End If

        txtPublicacionConsulta.Text = objNormas.F_Publicacion_ComentarioPublico
        txtFechaLimite.Text = objNormas.F_Limite_ComentarioPublico

        If txtDeclaratoria.Text <> "" Then
            dtkDeclaratoria.Value = txtDeclaratoria.Text
            txtRevisionQuinquenal.Text = dtkDeclaratoria.Value.AddYears(5)
        End If
        txtDeclaratoriaVigencia.Text = txtFecAviCancelacion.Text

        objNormas.Clasificacion = cboClasificacion.Text
        objNormas.Bandera = 3
        objNormas.Llena_Campos()
        txtFecUno.Text = IIf(IsDBNull(objNormas.F_Aclaracion_Uno) = True, Nothing, objNormas.F_Aclaracion_Uno)
        txtFecDos.Text = IIf(IsDBNull(objNormas.F_Aclaracion_Dos) = True, Nothing, objNormas.F_Aclaracion_Dos)
        If objNormas.F_Avi_Cancelacion <> "" Then
            dtkFecAviCancelacion.Value = Format(CDate(objNormas.F_Avi_Cancelacion), "dd/MM/yyyy")
            txtFecAviCancelacion.Text = Format(CDate(objNormas.F_Avi_Cancelacion), "dd/MM/yyyy")
        Else
            txtFecAviCancelacion.Text = ""
        End If
        objNormas.Bandera = 12
        objNormas.Clasificacion = cboClasificacion.SelectedValue
        objNormas.BuscaCaracteristicas()
        txtId_Plan.Text = objNormas.Id_Plan
        txtId_Tema.Text = objNormas.Id_Tema

        txtDoctoUno.Text = clsDoctosTemas.buscadocto(cboClasificacion.SelectedValue, 10, 12)
        txtDoctoDos.Text = clsDoctosTemas.buscadocto(cboClasificacion.SelectedValue, 11, 12)
        txtDoctoNorma.Text = clsDoctosTemas.buscadocto(cboClasificacion.SelectedValue, 13, 12)

    End Sub
#End Region

    Private Sub LlenaCostos()
        Dim objCostosNormas As New clsCostosNormas.Maple.clsCostosNormas

        Try
            objCostosNormas.Bandera = "s2"
            objCostosNormas.Norma = cboClasificacion.SelectedValue
            objCostosNormas.LlenarDatos()


            txtCorporativa.Text = objCostosNormas.CostoCorporativa
            txtImpresa.Text = objCostosNormas.CostoImpresa
            txtPersonal.Text = objCostosNormas.CostoPersonal

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objCostosNormas = Nothing
        End Try
    End Sub

#Region "  Llena Variables"
    Sub Llena_Variables(ByVal sClasificacion As String)
        objNormas.Bandera = 3
        objNormas.Clasificacion = sClasificacion
        objNormas.Llena_Campos()
        If objNormas.ID_Grupo = "" Then objNormas.ID_Grupo = "NA"
        If objNormas.Encontrado = True Then
            If objNormas.ID_Grupo <> "NA" Then
                txtPertenece.Text = objNormas.ID_Grupo
            End If

            'SI ES SUBCOMITE
            If objNormas.ID_SC <> "NA" And objNormas.ID_Grupo = "NA" Then
                txtPertenece.Text = objNormas.ID_SC
            End If
            'SI ES COMITE TECNICO
            If objNormas.ID_CT <> "NA" And objNormas.ID_SC = "NA" And objNormas.ID_Grupo = "NA" Then
                txtPertenece.Text = objNormas.ID_CT
            End If
            'SI ES DIRECTO DE COMITE
            If objNormas.ID_Comite <> "NA" And objNormas.ID_CT = "NA" And objNormas.ID_SC = "NA" And objNormas.ID_Grupo = "NA" Then
                txtPertenece.Text = objNormas.ID_Comite
            End If


            txtComite.Text = objNormas.ID_Comite '''fmr 28/11/06 funionan 
            txtCT.Text = objNormas.ID_CT
            txtSC.Text = objNormas.ID_SC
            txtGT.Text = objNormas.ID_Grupo
            txtDeclaratoria.Text = objNormas.F_Decla_Vigencia
            'objNormas.Norma_Cancela = ""
            txtTIE.Text = objNormas.TIE
            txtTII.Text = objNormas.TII
            txtPaginas.Text = objNormas.No_Paginas
            txtObjetivo.Text = objNormas.Objetivo
            txtBibliografia.Text = objNormas.Bilbiografia

            objempleados.Bandera = 3
            objempleados.Id_usuario = objNormas.Resp_Publicacion
            objempleados.Buscar()
            txtresponsable.Text = objempleados.NOMBRE_COMPLETO

            objempleados.Bandera = 6
            objempleados.ListaCombo(cboResponsable)
            cboResponsable.SelectedValue = objNormas.Resp_Publicacion
            txtFecAviCancelacion.Text = objNormas.F_Avi_Cancelacion

            txtEntradaVigor.Text = CStr(objNormas.F_Ent_Vigor)
            'txtfeciniciodesarrollo.Text = 'temas_normas
            'txtfecaprobacionconance.Text= 'temas_normas
            'txtfecresolucioncomentarios.Text= 'temas_normas
            txtRevisionQuinquenal.Text = CStr(objNormas.F_Revi_Quinquenal)

            txtDeclaratoriaVigencia.Text = objNormas.F_Decla_Vigencia
            txtNotificacionRatificacion.Text = objNormas.F_Noti_Ratificacion
            txtNotificacionModificacion.Text = objNormas.F_Noti_Modificacion

            txtPublicacionConsulta.Text = objNormas.F_Publi_Cancelacion
            txtFechaLimite.Text = objNormas.F_Limite

            txtDeclaratoriaVigencia.Text = objNormas.F_Decl_Vige_Can
            txtNotificacionRatificacion.Text = objNormas.F_Noti_Ratificacion
            txtNotificacionModificacion.Text = objNormas.F_Noti_Ratificacion


            '---------------------------------------------------------
            objNormas.Clasificacion = sClasificacion
            objNormas.Bandera = 10
            objNormas.Temas_Normas()
            'Empieza a buscar el historial de fechas de etapa anteriores
            txtFecAprobacionCONANCE.Text = IIf(IsDBNull(objNormas.F_Apro_CONANCE) = True, "", objNormas.F_Apro_CONANCE)
            txtFecInicioDesarrollo.Text = IIf(IsDBNull(objNormas.F_Ini_Desarrollo) = True, "", objNormas.F_Ini_Desarrollo)
            txtFecAprobacionCTGT.Text = IIf(IsDBNull(objNormas.F_Apro_CT_GT) = True, "", objNormas.F_Apro_CT_GT) 'objNormas.F_Apro_CT_GT 
            txtFecResolucionComentarios.Text = IIf(IsDBNull(objNormas.F_Apro_Coment_Pub) = True, "", objNormas.F_Apro_Coment_Pub)

            txtFecEnvioDGN.Text = IIf(IsDBNull(objNormas.F_Env_DGN) = True, "", objNormas.F_Env_DGN)
            txtFecResolucionComentarios.Text = IIf(IsDBNull(objNormas.F_Resol_Comentarios) = True, "", objNormas.F_Resol_Comentarios)
            'txtId_Plan.Text = objNormas.Id_Plan
            'txtId_Tema.Text = objNormas.Id_Tema
            txtObservaciones.Text = objNormas.Observaciones

            'Para llenar el Grid con las normas que cancela la norma seleccionada
            objNormas.Bandera = 4
            Call Llena_Grid(grdCanceladas)


        Else
            grdCanceladas.Enabled = False
        End If




    End Sub
#End Region

#Region "  EDITAR"
    Public Sub Editar()
        Inactivos(cmdEditar, cmdBorrar, cboClasificacion)
        Call Inicializa_Activos()
        Call Inicializa_Activos_Modificar()

        Inactivos(txtComite, txtCT, txtSC, txtGT, cmdComites)
        cboClasificacion.Visible = False
        txtNorma.Visible = True

        objNormas.Bandera = 6 'corregirlo en el sp
        objNormas.Cancelada = NormaClasificacion

        Call Llena_Grid(grdCanceladas)
        Call llena_responsable("editar")

        '''Call Formato_Grid(grdCanceladas)
    End Sub
#End Region

#Region " AGREGAR"
    Public Sub Agregar()
        Inactivos(cmdAgregar, cmdBorrar, cmdEditar)
        Call Inicializa_Activos()
        Call Inicializa_Activos_Modificar()

        Inactivos(txtComite, txtCT, txtSC, txtGT)
        Activos(chkObservaciones)
        chkObservaciones.Checked = False 'para que aparesca deshabilitado el chk

        Activos(cmdDeshacer, cmdGuardar)
        'Inactivos(dtkRevisionQuinquenal)
        lblNomClasificacion.Visible = True
        txtRamaIndustrial.Visible = True
        txtConsecutivo.Visible = True
        txtOrganismo.Visible = True
        txtA�o.Visible = True
        cboClasificacion.Visible = False

        'Pesta�a NMX
        Limpia_Campos(txtTIE, txtTII, txtPaginas, txtObjetivo, txtDeclaratoria, txtEntradaVigor, txtBibliografia, txtComite, txtCT, txtSC, txtGT)
        Limpia_Campos(txtObservaciones)
        Limpia_Campos(txtresponsable)
        'Pesta�a Caracter�sticas
        Limpia_Campos(txtClasificacionAdoptada, txtTituloAdoptado)
        Limpia_Campos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA)
        Limpia_Campos(txtClasificacionNOM, txtTituloNOM)
        Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
        Limpia_Campos(txtClasificacionNRF, txtTituloNRF)
        Limpia_Campos(txtFecInicioDesarrollo, txtFecAprobacionCTGT, txtFecAprobacionCONANCE, txtFecResolucionComentarios, txtFecEnvioDGN)
        'Pesta�a Revision quinquenal
        Limpia_Campos(txtRevisionQuinquenal, txtDeclaratoriaVigencia, txtNotificacionRatificacion, txtPublicacionConsulta, txtFechaLimite, txtNotificacionModificacion)
        'Pesta�a Documentos
        Limpia_Campos(txtDoctoNorma, txtFecUno, txtDoctoUno, txtFecDos, txtDoctoDos)

        'limpia_grid
        objNormas.Bandera = 9

        objNormas.Tipo_Norma = 1
        objNormas.Tipo_Norma_Dos = 0 'manda vacio
        Call Llena_GridDetalle(grdAdoptada)

        objNormas.Tipo_Norma = 2
        objNormas.Tipo_Norma_Dos = 3
        Call Llena_GridDetalle(grdArmonizada)

        objNormas.Tipo_Norma = 4
        objNormas.Tipo_Norma_Dos = 0 'manda vacio
        Call Llena_GridDetalle(grdNOM)

        objNormas.Tipo_Norma = 5
        objNormas.Tipo_Norma_Dos = 0 'manda vacio
        Call Llena_GridDetalle(grdNMX)

        objNormas.Tipo_Norma = 6
        objNormas.Tipo_Norma_Dos = 0 'manda vacio
        Call Llena_GridDetalle(grdNRF)

        objNormas.Tipo_Norma = 7
        objNormas.Tipo_Norma_Dos = 0 'manda vacio
        Call Llena_GridDetalle(grdConcordancia)

        objNormas.Bandera = 5
        'Call Llena_Grid()
        Call Llena_Grid(grdCanceladas)

        Call llena_responsable("agregar")
    End Sub

#End Region

#Region " DESHACER"
    Public Sub Deshacer()
        cboClasificacion.Visible = True
        lblNomClasificacion.Visible = False
        txtRamaIndustrial.Visible = False
        txtConsecutivo.Visible = False
        txtOrganismo.Visible = False
        txtA�o.Visible = False
        Inactivos(cmdDeshacer, cmdGuardar, cmdDocFinal)
        Activos(cmdBorrar, cmdAgregar, cmdEditar, cboClasificacion, cmdSalir, cmdDocFinal)
        chkConcordancia.Checked = False
        chkAdoptada.Checked = False
        chkArmonizada.Checked = False
        chkNOM.Checked = False
        chkNMX.Checked = False
        chkNRF.Checked = False

        Call Limpia_Inactivos()
        Call Inicializa_Inactivos()
        Call Carga_Combo_Clasificacion()
    End Sub

#End Region


    Sub Llena_Grid(ByVal grd As Object)

        objNormas.ListaGrid()
        If objNormas.ListaGrid.Rows.Count <> 0 Then
            grd.DataSource = objNormas.ListaGrid
        Else
            grdCanceladas.Enabled = False
            grdCanceladas.DataSource = Nothing
        End If

    End Sub

    Sub Llena_GridDetalle(ByVal grd As Object)
        If objNormas.ListaGridDetalle Is Nothing Then
            ''mensaje 
            Exit Sub
        End If

        '''If objNormas.ListaGridDetalle.Rows.Count = 0 Then
        '''    Exit Sub
        '''End If

        grd.DataSource = objNormas.ListaGridDetalle
        grd.readonly = False
        'grd.DataSource = objNormas.ListaGridDetalle.Columns("0")
        '''DTDetalle = objNormas.ListaGridDetalle
    End Sub

#Region " Formato Grid clasificacion"
    Sub Formato_Grid(ByVal grd As Object)
        Dim dgEstiloGrid As New DataGridTableStyle
        With dgEstiloGrid
            .AlternatingBackColor = Color.GhostWhite
            .BackColor = Color.GhostWhite
            .ForeColor = Color.MidnightBlue
            .GridLineColor = Color.RoyalBlue
            .HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .HeaderForeColor = Color.Lavender
            .SelectionBackColor = Color.Teal
            .SelectionForeColor = Color.PaleGreen
            .RowHeaderWidth = 20 'ajusta el tama�o de la columna de la izquierda que trae el grid
            .RowHeadersVisible = False
            .ColumnHeadersVisible = False '
            .MappingName = "C_Normas" 'el nombre que regresa el dataset
        End With

        Dim ColEStilo1 As New DataGridTextBoxColumn
        Dim ColEStilo2 As New DataGridBoolColumn

        '''If sEtapaGrid = "Clasificacion" Then
        With ColEStilo1
            .MappingName = "Norma"
            .HeaderText = "Norma"
            .Width = 170
            '.ReadOnly = True
        End With

        With ColEStilo2
            .MappingName = "Inactivo"
            .HeaderText = "Desactivar"
            .Width = 70
            .FalseValue = False
            .TrueValue = True
            '.NullValue = False 'fmr 06/12/06
            .NullValue = True 'fmr 06/12/06
            ''''.ReadOnly = True
        End With

        '''ElseIf sEtapaGrid = "Canceladas" Then
        '''With ColEStilo1
        '''    .MappingName = "Norma_Cancelada"
        '''    .HeaderText = "Norma Cancelada"
        '''    .Width = 170
        '''    '.ReadOnly = True
        '''End With

        '''With ColEStilo2
        '''    .MappingName = "Inactivo"
        '''    .HeaderText = "Activar"
        '''    .Width = 50
        '''    '''.FalseValue = 1
        '''    '''.TrueValue = 0
        '''    '''.NullValue = 0
        '''    ''''.ReadOnly = True
        '''End With
        '''End If

        dgEstiloGrid.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEStilo1, ColEStilo2})
        'grdCanceladas.TableStyles.Add(dgEstiloGrid)
        grd.TableStyles.Add(dgEstiloGrid)
    End Sub

#End Region

#Region " Formato Grid detalle"
    Sub Formato_GridDetalle(ByVal grd As Object)
        Dim dgEstiloGrid As New DataGridTableStyle
        With dgEstiloGrid
            .AlternatingBackColor = Color.GhostWhite
            .BackColor = Color.GhostWhite
            .ForeColor = Color.MidnightBlue
            .GridLineColor = Color.RoyalBlue
            .HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .HeaderForeColor = Color.Lavender
            .SelectionBackColor = Color.Teal
            .SelectionForeColor = Color.PaleGreen
            .RowHeaderWidth = 15 'ajusta el tama�o de la columna de la izquierda que trae el grid
            .RowHeadersVisible = False
            .ColumnHeadersVisible = False
            .MappingName = "C_Normas" 'el nombre que regresa el dataset
            '.ReadOnly = True
        End With

        Dim ColEstilo0 As New DataGridTextBoxColumn 'clasificacion
        Dim ColEstilo1 As New DataGridTextBoxColumn 'id_detalle
        Dim ColEstilo2 As New DataGridTextBoxColumn 'id_tipo_norma
        Dim ColEstilo3 As New DataGridTextBoxColumn 'clasificacion_norma
        Dim ColEstilo4 As New DataGridTextBoxColumn 'titulo_norma
        Dim ColEstilo5 As New DataGridBoolColumn 'selccionar

        With ColEstilo0 'clasificacion
            .MappingName = "Clasificacion"
            .HeaderText = "Clasificacion"
            .Width = 0
            '.ReadOnly = True
        End With

        With ColEstilo1 'id_detalle
            .MappingName = "id_detalle"
            .HeaderText = "id_detalle"
            .Width = 0
            '.ReadOnly = True
        End With

        With ColEstilo2 'id_tipo_norma
            .MappingName = "id_tipo_norma"
            .HeaderText = "id_tipo_norma"
            .Width = 0
            '.ReadOnly = True
        End With

        With ColEstilo3 'clasificacion_norma
            .MappingName = "clasificacion_norma"
            .HeaderText = "Clasificacion"
            .Width = 120
            '.ReadOnly = True 'este se muestra en el grid
        End With

        With ColEstilo4 'titulo_norma
            .MappingName = "titulo_norma"
            .HeaderText = "Titulo"
            .Width = 120
            '.ReadOnly = True 'este se muestra en el grid
        End With

        With ColEstilo5 'selccionar
            .MappingName = "Inactivo"
            .HeaderText = "Seleccionar"
            .Width = 70
            .FalseValue = False
            '.NullValue = False  'fmr 06/12/06
            .NullValue = True 'fmr 06/12/06
            .TrueValue = True
            '.ReadOnly = True 'este se muestra en el grid
        End With
        ''''.ReadOnly = True


        dgEstiloGrid.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEstilo0, ColEstilo1, ColEstilo2, ColEstilo3, ColEstilo4, ColEstilo5})
        grd.TableStyles.Add(dgEstiloGrid)
    End Sub
#End Region

#Region " GUARDAR"
    Private Sub Guardar()
        Dim Accion As Boolean
        Dim sSqlAgregar As String
        Dim dt As New DataTable
        Dim dr As DataRow
        Dim bInactivo As Boolean
        Dim comitepath As String
        Dim ID_Detalle_Busca As String
        Dim RutaServer As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\")
        Dim RutaDoctoFinal As String = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutasDoctosFinales")) + "\")
        objNormas.Bandera = 8
        'ID_Detalle = objNormas.Buscar_ID_Detalle
        objNormas.Buscar_ID_Detalle()

        ID_Detalle_Busca = objNormas.ID_Detalle
        objNormas.ID_Detalle = ID_Detalle_Busca

        objNormas.ID_Comite = IIf(txtComite.Text = "NA" = True, "", txtComite.Text)
        objNormas.ID_CT = IIf(txtCT.Text = "" = True, "NA", txtCT.Text)
        objNormas.ID_SC = IIf(txtSC.Text = "" = True, "NA", txtSC.Text)
        objNormas.ID_Grupo = IIf(txtGT.Text = "NA" = True, "", txtGT.Text)
        objNormas.TIE = IIf(txtTIE.Text = "" = True, "", txtTIE.Text)
        objNormas.TII = IIf(txtTII.Text = "" = True, "", txtTII.Text)
        If Not IsNumeric(txtPaginas.Text.Trim) Then
            MsgBox("Valor no v�lido para el No de p�ginas", MsgBoxStyle.Information, "Cat�logo de Normas")
            Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
            Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
            txtPaginas.Text = ""
            Exit Sub
        Else
            objNormas.No_Paginas = CInt(txtPaginas.Text)
        End If

        objNormas.Objetivo = txtObjetivo.Text
        objNormas.Bilbiografia = txtBibliografia.Text

        objNormas.Resp_Publicacion = cboResponsable.SelectedValue

        objNormas.F_Ent_Vigor = IIf(txtEntradaVigor.Text = "", Nothing, txtEntradaVigor.Text)
        objNormas.F_Ini_Desarrollo = IIf(txtFecInicioDesarrollo.Text = "", Nothing, txtFecInicioDesarrollo.Text)
        objNormas.F_Apro_CONANCE = IIf(txtFecAprobacionCONANCE.Text = "", Nothing, txtFecAprobacionCONANCE.Text)
        objNormas.F_Apro_Coment_Pub = IIf(txtPublicacionConsulta.Text = "", Nothing, txtPublicacionConsulta.Text)
        objNormas.F_Revi_Quinquenal = IIf(txtRevisionQuinquenal.Text = "", Nothing, txtRevisionQuinquenal.Text)
        objNormas.F_Avi_Cancelacion = IIf(txtFecAviCancelacion.Text = "", Nothing, txtFecAviCancelacion.Text)
        objNormas.F_Decl_Vige_Can = IIf(txtDeclaratoriaVigencia.Text = "", Nothing, txtDeclaratoriaVigencia.Text)
        objNormas.F_Decla_Vigencia = IIf(txtDeclaratoria.Text = "", Nothing, txtDeclaratoria.Text)
        objNormas.F_Noti_Ratificacion = IIf(txtNotificacionRatificacion.Text = "", Nothing, txtNotificacionRatificacion.Text)
        objNormas.F_Noti_Modificacion = IIf(txtNotificacionModificacion.Text = "", Nothing, txtNotificacionModificacion.Text)
        objNormas.F_Resol_Comentarios = IIf(txtFecResolucionComentarios.Text = "", Nothing, txtFecResolucionComentarios.Text)
        objNormas.F_Env_DGN = IIf(txtFecEnvioDGN.Text = "", Nothing, txtFecEnvioDGN.Text)
        objNormas.F_Publi_Cancelacion = IIf(txtPublicacionConsulta.Text = "", Nothing, txtPublicacionConsulta.Text)
        objNormas.F_Limite = IIf(txtFechaLimite.Text = "", Nothing, txtFechaLimite.Text)

        If chkObservaciones.Checked = True Then
            If (txtObservaciones.Text.Trim) = "" Then
                MsgBox("Sin Comit� o Comit� no valido", MsgBoxStyle.Information, "Cat�logo de Normas")
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Exit Sub
            Else
                objNormas.Observaciones = txtObservaciones.Text
            End If
        Else
            objNormas.Observaciones = Nothing
        End If

        If sTipoProceso = "Agregar" Then '*****************IF*************AGREGAR
            '*********************************************************************************
            If Not IsNumeric(txtA�o.Text.Trim) Then
                MsgBox("Valor no v�lido para el a�o", MsgBoxStyle.Information, "Cat�logo de Normas")
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                txtA�o.Text = ""
                Exit Sub
            End If

            If txtRamaIndustrial.Text = "" Or txtConsecutivo.Text = "" Or txtOrganismo.Text = "" Then
                MsgBox("No dejes ningun campo vac�o para la Clasificaci�n de la Norma", MsgBoxStyle.Information, "Cat�logo de Normas")
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                'Call proceso_guardar()
                Exit Sub
            End If

            If txtPertenece.Text = "" Or txtPertenece.Text = "NA" Or txtPertenece.Text = "na" Then
                MsgBox("Sin Comit� o Comit� no valido", MsgBoxStyle.Information, "Cat�logo de Normas")
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Exit Sub
            End If

            objNormas.Bandera = 1 'Agrega los datos en C_Normas
            'objNormas.Clasificacion = NormaClasificacion
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text

            Try
                Accion = objNormas.Agregar
            Catch ex As Exception When Accion = False
                MsgBox("Error al intentar guardar o leer el Registro..." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                Exit Sub
            End Try

            objNormas.Bandera = 2 'Agrega los datos en C_Normas_Canceladas
            dt = grdCanceladas.DataSource()
            If Not dt Is Nothing Then
                For Each dr In dt.Rows
                    objNormas.Cancelada = dr(0)

                    If dr(0) <> "" Or dr(1) = False Or dr(1) Is System.DBNull.Value Then
                        objNormas.Inactivo = 0
                        'Else
                    ElseIf dr(1) = True Or dr(1) = -1 Then
                        objNormas.Inactivo = 1
                        Try
                            Accion = objNormas.Agregar
                        Catch ex As Exception When Accion = False
                            MsgBox("Error al intentar guardar o leer el Registro..." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                            Exit Sub
                        End Try
                    End If
                Next
            End If

            '--------------------------------PARA INSERTAR LOS DEMAS GRID, C_NORMAS_DETALLE de la pesta�a Caracter�sticas
            objNormas.Bandera = 3

            If chkConcordancia.Checked = True Then
                'If dt.Rows.Count <> 0 Then
                Call guarda_grid(grdConcordancia)
                'End If
            End If

            If chkAdoptada.Checked = True Then
                'If dt.Rows.Count <> 0 Then
                Call guarda_grid(grdAdoptada)
                'End If
            End If

            If chkArmonizada.Checked = True Then
                'If dt.Rows.Count <> 0 Then
                Call guarda_grid(grdArmonizada)
                'End If
            End If

            If chkNOM.Checked = True Then
                'If dt.Rows.Count <> 0 Then
                Call guarda_grid(grdNOM)
                'End If
            End If

            If chkNMX.Checked = True Then
                'If dt.Rows.Count <> 0 Then
                Call guarda_grid(grdNMX)
                'End If
            End If

            If chkNRF.Checked = True Then
                'If dt.Rows.Count <> 0 Then
                Call guarda_grid(grdNRF)
                'End If
            End If
            ''comitepath = IIf(txtComite.Text = "NA" = True, "", txtComite.Text) + "\"
            ''comitepath = comitepath + IIf(txtCT.Text = "" = True, "NA", txtCT.Text) + "\"
            ''comitepath = comitepath + IIf(txtSC.Text = "" = True, "NA", txtSC.Text) + "\"
            ''comitepath = comitepath + IIf(txtGT.Text = "NA" = True, "", txtGT.Text) '+ "\"

            Dim ruta As String
            ObjPrograma.Buscar(txtId_Plan.Text, txtId_Tema.Text)
            If txtId_Plan.Text = "" And txtId_Tema.Text = "" Then
                comitepath = RutaDoctoFinal
            Else
                If ObjPrograma.ID_Grupo <> "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
                End If
                'SI ES SUBCOMITE
                If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
                End If
                'SI ES COMITE TECNICO
                If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
                End If
                'SI ES DIRECTO DE COMITE
                If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    comitepath = ObjPrograma.ID_Comite
                End If
            End If



            If txtDoctoUno.Text <> "" And adjunta = True And RutaUno <> "" Then
                Try
                    '********************************************************COPIA LOS ARCHIVOS
                    If File.Exists(RutaServer + comitepath + txtDoctoUno.Text) Then
                        If MsgBox("Este archivo ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                            File.Delete(RutaServer + comitepath + txtDoctoUno.Text)
                            File.Copy(RutaUno, RutaServer + comitepath + txtDoctoUno.Text, True)
                            llenaDatosADD(txtDoctoDos.Text, 10, True, cboClasificacion.SelectedValue, 11)
                        End If
                    Else
                        If Not Directory.Exists(RutaServer + comitepath) Then
                            Directory.CreateDirectory(RutaServer + comitepath)
                        End If
                        File.Copy(RutaUno, RutaServer + comitepath + txtDoctoUno.Text, True)
                        llenaDatosADD(txtDoctoDos.Text, 10, True, cboClasificacion.SelectedValue, 11)
                    End If

                Catch ex As Exception

                End Try

            End If

            If txtDoctoDos.Text <> "" And adjunta = True And RutaUno <> "" Then
                Try
                    If File.Exists(RutaServer + comitepath + txtDoctoDos.Text) Then
                        If MsgBox("Este archivo ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                            File.Delete(RutaServer + comitepath + txtDoctoDos.Text)
                            File.Copy(RutaDos, RutaServer + comitepath + txtDoctoDos.Text, True)
                            llenaDatosADD(txtDoctoDos.Text, 10, True, cboClasificacion.SelectedValue, 11)
                        End If
                    Else
                        If Not Directory.Exists(RutaServer + comitepath) Then
                            Directory.CreateDirectory(RutaServer + comitepath)
                        End If
                        File.Copy(RutaDos, RutaServer + comitepath + txtDoctoDos.Text, True)
                        llenaDatosADD(txtDoctoDos.Text, 10, True, cboClasificacion.SelectedValue, 11)
                    End If

                Catch ex As Exception

                End Try

            End If

            Call proceso_guardar()
            cboClasificacion.Visible = True
            cboClasificacion.Enabled = True



        ElseIf sTipoProceso = "Editar" Then '****************ELSE**************EDITAR
            '*************************************************************************************
            If Len(txtNorma.Text) = 0 Or txtNorma.Text = "" Then
                MsgBox("Debe ingresar la clasificaci�n de la norma.", MsgBoxStyle.Information, "Cat�logo de Normas")
                sTipoProceso = "Editar"
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas, cmdDocFinal)
                Inactivos(cmdAgregar)
                Call Editar()

                'para mostrar el treeview
                cmdComites.Enabled = False
                cmdComitesGuardar.Enabled = True
                Call llena_TreeView()
                If txtDoctoNorma.Text <> "" Then
                    cmdDocFinal.Enabled = False
                End If

                If txtDoctoUno.Text <> "" Then lblSubirDoctoUno.Enabled = False
                If txtDoctoDos.Text <> "" Then lblSubirDoctoDos.Enabled = False
                If txtDoctoUno.Text = "" Then lblSubirDoctoDos.Enabled = False

                If txtDoctoUno.Text <> "" And txtDoctoDos.Text <> "" Then
                    adjunta = False
                Else
                    adjunta = True
                End If
                txtNorma.Focus()
                Exit Sub
            End If

            If txtPertenece.Text = "NA" Or txtPertenece.Text = "na" Then
                MsgBox("Sin Comit� o Comit� no valido", MsgBoxStyle.Information, "Cat�logo de Normas")
                Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Exit Sub
            End If

            objNormas.Bandera = 4 'PARA GUARDAR LOS DATOS EN C_NORMAS
            objNormas.Clasificacion_Norma = txtNorma.Text
            objNormas.Clasificacion = NormaClasificacion
            Try
                objNormas.F_Aclaracion_Uno = txtFecUno.Text
                objNormas.F_Aclaracion_Dos = txtFecDos.Text
                Accion = objNormas.Actualizar()
                If Accion = False Then
                    MsgBox("Error al intentar guardar o leer el Registro", MsgBoxStyle.Critical)
                    Exit Sub
                End If
                'Accion = objNormas.Actualizar
            Catch ex As Exception When Accion = False
                MsgBox("Error al intentar guardar o leer el Registro..." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                Exit Sub
            End Try

            objNormas.Bandera = 5 'PARA GUARDAR LAS NORMAS QUE SE CANCELAN, C_NORMAS_CANCELADAS
            dt = grdCanceladas.DataSource()
            If Not dt Is Nothing Then
                For Each dr In dt.Rows
                    objNormas.Cancelada = dr(0)
                    objNormas.Clasificacion = NormaClasificacion
                    If dr(1) = False Or dr(1) Is System.DBNull.Value Then
                        objNormas.Inactivo = 0
                    ElseIf dr(1) = True Or dr(1) = -1 Then
                        objNormas.Inactivo = 1
                        Try
                            Accion = objNormas.Actualizar
                        Catch ex As Exception When Accion = False
                            MsgBox("Error al intentar guardar o leer el Registro..." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                            'Exit Sub
                        End Try
                    End If
                Next
            End If
            '--------------------------------PARA GUARDAR LOS TEMAS GRID, C_NORMAS_DETALLE
            objNormas.Bandera = 6

            If chkConcordancia.Checked = True Then
                'zokIf dt.Rows.Count <> 0 Then
                Call guarda_grid(grdConcordancia)
                'zokEnd If
            End If

            If chkAdoptada.Checked = True Then
                'objNormas.Tipo_Norma = 1
                'dt = grdAdoptada.DataSource
                'zokIf dt.Rows.Count <> 0 Then
                Call guarda_grid(grdAdoptada)
                'zokEnd If
            End If

            If chkArmonizada.Checked = True Then
                'zokIf dt.Rows.Count <> 0 Then
                Call guarda_grid(grdArmonizada)
                'zokEnd If
            End If

            If chkNOM.Checked = True Then
                'zokIf dt.Rows.Count <> 0 Then
                Call guarda_grid(grdNOM)
                'zokEnd If
            End If

            If chkNMX.Checked = True Then
                'zokIf dt.Rows.Count <> 0 Then
                Call guarda_grid(grdNMX)
                'zokEnd If
            End If

            If chkNRF.Checked = True Then
                'zokIf dt.Rows.Count <> 0 Then
                Call guarda_grid(grdNRF)
                'zokEnd If
            End If
            ''Dim tempDocto1 As String = txtDoctoUno.Text
            ''Dim tempDocto2 As String = txtDoctoDos.Text
            ''Dim tempDocto3 As String = txtDoctoNorma.Text
            ''Dim splan As String = txtId_Plan.Text
            ''Dim stema As String = txtId_Tema.Text
            EtapasInspeccion()
            ''Call proceso_guardar()
            'txtDoctoUno.Text = tempDocto1
            'txtDoctoDos.Text = tempDocto2
            'txtDoctoNorma.Text = tempDocto3
            'txtId_Plan.Text = splan
            'txtId_Tema.Text = stema

            ''comitepath = IIf(txtComite.Text = "NA" = True, "", txtComite.Text) + "\"
            ''comitepath = comitepath + IIf(txtCT.Text = "" = True, "NA", txtCT.Text) + "\"
            ''comitepath = comitepath + IIf(txtSC.Text = "" = True, "NA", txtSC.Text) + "\"
            ''comitepath = comitepath + IIf(txtGT.Text = "NA" = True, "", txtGT.Text) '+ "\"

            ObjPrograma.Buscar(txtId_Plan.Text, txtId_Tema.Text)
            If txtId_Plan.Text = "" And txtId_Tema.Text = "" Then
                comitepath = RutaDoctoFinal
            Else

                If ObjPrograma.ID_Grupo <> "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo + "\"
                End If
                'SI ES SUBCOMITE
                If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\"
                End If
                'SI ES COMITE TECNICO
                If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\"
                End If
                'SI ES DIRECTO DE COMITE
                If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    comitepath = ObjPrograma.ID_Comite + "\"
                End If
            End If

            Try
                If txtDoctoUno.Text <> "" And adjunta = True And RutaUno <> "" Then
                    If File.Exists(RutaServer + comitepath + txtDoctoUno.Text) Then
                        If MsgBox("Este archivo ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                            File.Delete(RutaServer + comitepath + txtDoctoUno.Text)
                            File.Copy(RutaUno, RutaServer + comitepath + txtDoctoUno.Text, True)
                            llenaDatosADD(txtDoctoUno.Text, 10, True, cboClasificacion.SelectedValue, 11)
                        End If
                    Else
                        If Not Directory.Exists(RutaServer + comitepath) Then
                            Directory.CreateDirectory(RutaServer + comitepath)
                        End If
                        File.Copy(RutaUno, RutaServer + comitepath + txtDoctoUno.Text, True)
                        llenaDatosADD(txtDoctoUno.Text, 10, True, cboClasificacion.SelectedValue, 11)
                    End If
                End If
            Catch ex As Exception
                MsgBox("Error: " + ex.Message)
            End Try
            '********************************************************COPIA LOS ARCHIVOS
            Try
                If txtDoctoDos.Text <> "" And adjunta = True And RutaDos <> "" Then
                    If File.Exists(RutaServer + comitepath + txtDoctoDos.Text) Then
                        If MsgBox("Este archivo ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                            File.Delete(RutaServer + comitepath + txtDoctoDos.Text)
                            File.Copy(RutaDos, RutaServer + comitepath + txtDoctoDos.Text, True)
                            llenaDatosADD(txtDoctoDos.Text, 11, True, cboClasificacion.SelectedValue, 11)
                        End If
                    Else
                        If Not Directory.Exists(RutaServer + comitepath) Then
                            Directory.CreateDirectory(RutaServer + comitepath)
                        End If
                        File.Copy(RutaDos, RutaServer + comitepath + txtDoctoDos.Text, True)
                        llenaDatosADD(txtDoctoDos.Text, 11, True, cboClasificacion.SelectedValue, 11)
                    End If
                End If
            Catch ex As Exception
                MsgBox("Error: " + ex.Message)
            End Try

            ''Call proceso_guardar()
            'txtId_Plan.Text = splan
            'txtId_Tema.Text = stema
            'txtDoctoNorma.Text = tempDocto3
            cboClasificacion.Visible = True
            cboClasificacion.Enabled = True
        End If
        'inserto la fecha de adjuntar docto en C_Normas
        ''If txtDoctoUno.Text <> "" Or txtDoctoDos.Text <> "" Then
        ''    objNormas.Clasificacion = cboClasificacion.SelectedValue
        ''    objNormas.Bandera = 10
        ''    objNormas.F_Aclaracion_Uno = txtFecUno.Text
        ''    objNormas.F_Aclaracion_Dos = txtFecDos.Text
        ''    objNormas.Agregar()
        ''End If
        Try
            Dim iBande As String
            If txtDoctoNorma.Text <> "" Then
                If gbArchivos = True Then
                    iBande = 11
                    If File.Exists(RutaServer + comitepath + txtDoctoNorma.Text) Then
                        If MsgBox("Este archivo ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                            File.Delete(RutaServer + RutaDoctoFinal + txtDoctoNorma.Text)
                            File.Copy(RutaNormaFinal, RutaServer + RutaDoctoFinal + txtDoctoNorma.Text)
                        End If
                    Else
                        If Not Directory.Exists(RutaServer + comitepath) Then
                            Directory.CreateDirectory(RutaServer + comitepath)
                        End If
                        File.Copy(RutaNormaFinal, RutaServer + comitepath + txtDoctoNorma.Text)
                    End If
                Else
                    iBande = 14
                End If
                'doy de alta en la base de datos
                llenaDatosADD(txtDoctoNorma.Text, 13, True, cboClasificacion.SelectedValue, iBande)
            End If
        Catch ex As Exception
            MsgBox("Error:" + ex.Message)
        End Try

        RutaUno = ""
        RutaDos = ""
        RutaDoctoFinal = ""
        guardarCostos(cboClasificacion.SelectedValue)
        Call proceso_guardar()
        gbArchivos = False
    End Sub
#End Region

    Private Sub guardarCostos(ByVal Clasificacion As String)
        Dim objCostosNormas As New clsCostosNormas.Maple.clsCostosNormas

        Try
            objCostosNormas.Bandera = "s2"
            objCostosNormas.Norma = Clasificacion
            objCostosNormas.LlenarDatos()

            objCostosNormas.CostoCorporativa = txtCorporativa.Text
            objCostosNormas.CostoImpresa = txtImpresa.Text
            objCostosNormas.CostoPersonal = txtPersonal.Text

            If objCostosNormas.Norma = "" Then
                REM inserto
                objCostosNormas.Bandera = "i1"
                objCostosNormas.Norma = Clasificacion
                objCostosNormas.Insertar()
            Else
                REM actualizo
                objCostosNormas.Bandera = "u1"
                objCostosNormas.Norma = Clasificacion
                objCostosNormas.Actualizar()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objCostosNormas = Nothing
        End Try
    End Sub

    Private Sub llenaDatosADD(ByVal doc As String, ByVal idDocto As Integer, ByVal activo As Boolean, ByVal Clasificacion As String, ByVal band As Integer)
        Referenciar("abandono")
        'inserta en p_prog_trab_doc
        With objNormas
            'if .Id_Plan and .Id_Tema  and 
            .Bandera = band '8
            .Id_tipo_doc = idDocto
            .Documento = doc
            .Activo = activo
            .Clasificacion = Clasificacion
            .Actualizar_Documentos()
        End With
    End Sub

    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(txtId_Plan.Text, txtId_Tema.Text)
        srefP = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
    End Sub
#Region "  proceso_guardar"
    Sub proceso_guardar()
        Call Limpia_Inactivos()
        Call Inicializa_Inactivos()
        Call Limpia_Campos()
        Call Carga_Combo_Clasificacion()
        tvComites.Nodes.Clear()
        tvComites.Refresh()
        tvComites.Enabled = True
        txtNorma.Visible = False
        cboClasificacion.Visible = True
    End Sub
#End Region

#Region "  Guarda Grid"
    Sub guarda_grid(ByVal grd As DataGrid)
        Dim dt As New DataTable
        Dim dr As DataRow
        Dim bInactivo As Boolean
        Dim accion As Boolean

        dt = grd.DataSource()

        For Each dr In dt.Rows
            objNormas.Clasificacion = dr(0)
            If sTipoProceso = "Editar" Then
                If dr(1) Is System.DBNull.Value Then
                    objNormas.Bandera = 3
                Else
                    objNormas.ID_Detalle = dr(1)
                End If

            End If
            objNormas.ID_Tipo_Norma = dr(2)
            objNormas.Clasificacion_Norma = dr(3)
            objNormas.Titulo_Norma = dr(4)
            'If dr(5) = False Or dr(5) Is System.DBNull.Value Then
            If dr(5) = False Or dr(5) Is System.DBNull.Value Then
                objNormas.Inactivo = 0
            ElseIf dr(5) = True Or dr(5) = 1 Then 'fmr*********************
                objNormas.Inactivo = 1
                Try
                    accion = objNormas.Actualizar_Detalle
                Catch ex As Exception When accion = False
                    MsgBox("Error al intentar guardar o leer el Registro..." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    'Exit Sub
                End Try
            End If
        Next
    End Sub
#End Region

#Region "  cmdConcordancia"
    Private Sub cmdConcorda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConcordancia.Click
        If sTipoProceso = "Agregar" Then 'fmr 29/11/06
            If Trim(txtRamaIndustrial.Text) = "" Or Trim(txtConsecutivo.Text) = "" Or Trim(txtOrganismo.Text) = "" Or Trim(txtA�o.Text) = "" Then
                MsgBox("Debes de llenar todos los campos de la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            If objNormas.Clasificacion = "NMX----" Then
                MsgBox("Debes de llenar la norma Clasificaci�n antes de agregar una referencia", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
        End If

        If txtClasificacionConcordancia.Text = "" Or txtTituloConcordancia.Text = "" Then
            MsgBox("No dejes campos vacios", MsgBoxStyle.Exclamation, "Concordancia Normas Internacionales")
            Exit Sub
        Else
            Dim dtAgrega As New DataTable 'comentarizada
            Dim drAgrega As DataRow
            'Dim dvAgrega As DataView
            dtAgrega = grdConcordancia.DataSource
            drAgrega = dtAgrega.NewRow
            drAgrega("Clasificacion") = objNormas.Clasificacion
            drAgrega("ID_Tipo_Norma") = 7
            drAgrega("Clasificacion_Norma") = txtClasificacionConcordancia.Text
            drAgrega("Titulo_Norma") = txtTituloConcordancia.Text
            drAgrega("Inactivo") = 1
            dtAgrega.Rows.Add(drAgrega)
            'dvAgrega = New DataView(dtAgrega)
            grdConcordancia.DataSource = dtAgrega
            grdConcordancia.Refresh()

            txtClasificacionConcordancia.Text = ""
            txtTituloConcordancia.Text = ""
        End If
    End Sub
#End Region

#Region "  cmdAdoptada"
    Private Sub cmdAdoptada_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdoptada.Click
        If sTipoProceso = "Agregar" Then 'fmr 29/11/06
            If Trim(txtRamaIndustrial.Text) = "" Or Trim(txtConsecutivo.Text) = "" Or Trim(txtOrganismo.Text) = "" Or Trim(txtA�o.Text) = "" Then
                MsgBox("Debes de llenar todos los campos de la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            If objNormas.Clasificacion = "NMX----" Then
                MsgBox("Debes de llenar la norma Clasificaci�n antes de agregar una referencia", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
        End If


        If txtClasificacionAdoptada.Text = "" Or txtTituloAdoptado.Text = "" Then
            MsgBox("No dejes campos vacios", MsgBoxStyle.Exclamation, "Norma Adoptada")
            Exit Sub
        Else
            Dim dtAgrega As New DataTable 'comentarizada
            Dim drAgrega As DataRow
            'Dim dvAgrega As DataView
            dtAgrega = grdAdoptada.DataSource
            drAgrega = dtAgrega.NewRow
            drAgrega("Clasificacion") = objNormas.Clasificacion 'NormaClasificacion 'cboClasificacion.SelectedValue
            drAgrega("ID_Tipo_Norma") = 1
            drAgrega("Clasificacion_Norma") = txtClasificacionAdoptada.Text
            drAgrega("Titulo_Norma") = txtTituloAdoptado.Text
            drAgrega("Inactivo") = 1
            dtAgrega.Rows.Add(drAgrega)
            'dvAgrega = New DataView(dtAgrega)
            grdAdoptada.DataSource = dtAgrega
            grdAdoptada.Refresh()

            txtClasificacionAdoptada.Text = ""
            txtTituloAdoptado.Text = ""
        End If
    End Sub
#End Region

#Region "  cmdArmonizada"
    Private Sub cmdArmonizada_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdArmonizada.Click
        If sTipoProceso = "Agregar" Then 'fmr 29/11/06
            If Trim(txtRamaIndustrial.Text) = "" Or Trim(txtConsecutivo.Text) = "" Or Trim(txtOrganismo.Text) = "" Or Trim(txtA�o.Text) = "" Then
                MsgBox("Debes de llenar todos los campos de la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            If objNormas.Clasificacion = "NMX----" Then
                MsgBox("Debes de llenar la norma Clasificaci�n antes de agregar una referencia", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
        End If

        If txtClasificacionUL.Text = "" Or txtTituloUL.Text = "" Or txtClasificacionCSA.Text = "" Or txtTituloCSA.Text = "" Then
            MsgBox("No dejes campos vacios", MsgBoxStyle.Exclamation, "Norma Armonizada")
            Exit Sub
        Else
            Dim dtAgrega As New DataTable
            Dim drAgregaUL As DataRow
            Dim drAgregaCSA As DataRow
            Dim dvAgrega As DataView
            dtAgrega = grdArmonizada.DataSource
            drAgregaUL = dtAgrega.NewRow
            drAgregaCSA = dtAgrega.NewRow

            drAgregaUL("Clasificacion") = objNormas.Clasificacion 'NormaClasificacion  'cboClasificacion.Text
            drAgregaUL("ID_Tipo_Norma") = 2 'armonizada UL
            drAgregaUL("Clasificacion_Norma") = txtClasificacionUL.Text
            drAgregaUL("Titulo_Norma") = txtTituloUL.Text
            drAgregaUL("Inactivo") = 1
            dtAgrega.Rows.Add(drAgregaUL)

            drAgregaCSA("Clasificacion") = objNormas.Clasificacion 'NormaClasificacion 'cboClasificacion.SelectedValue
            drAgregaCSA("ID_Tipo_Norma") = 3 'armonizada CSA
            drAgregaCSA("Clasificacion_Norma") = txtClasificacionCSA.Text
            drAgregaCSA("Titulo_Norma") = txtTituloCSA.Text
            drAgregaCSA("Inactivo") = 1
            dtAgrega.Rows.Add(drAgregaCSA)

            'dvAgrega = New DataView(dtAgrega)
            grdArmonizada.DataSource = dtAgrega

            txtClasificacionUL.Text = ""
            txtTituloUL.Text = ""
            txtClasificacionCSA.Text = ""
            txtTituloCSA.Text = ""
        End If
    End Sub
#End Region

#Region "  cmdNOM"
    Private Sub cmdNOM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNOM.Click
        If sTipoProceso = "Agregar" Then 'fmr 29/11/06
            If Trim(txtRamaIndustrial.Text) = "" Or Trim(txtConsecutivo.Text) = "" Or Trim(txtOrganismo.Text) = "" Or Trim(txtA�o.Text) = "" Then
                MsgBox("Debes de llenar todos los campos de la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            If objNormas.Clasificacion = "NMX----" Then
                MsgBox("Debes de llenar la norma Clasificaci�n antes de agregar una referencia", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
        End If

        If txtClasificacionNOM.Text = "" Or txtTituloNOM.Text = "" Then
            MsgBox("No dejes campos vacios", MsgBoxStyle.Exclamation, "Norma NOM")
            Exit Sub
        Else
            Dim dtAgrega As New DataTable
            Dim drAgrega As DataRow
            Dim dvAgrega As DataView
            dtAgrega = grdNOM.DataSource
            drAgrega = dtAgrega.NewRow

            drAgrega("Clasificacion") = objNormas.Clasificacion 'NormaClasificacion 'cboClasificacion.SelectedValue
            drAgrega("ID_Tipo_Norma") = 4 'NOM
            drAgrega("Clasificacion_Norma") = txtClasificacionNOM.Text
            drAgrega("Titulo_Norma") = txtTituloNOM.Text
            drAgrega("Inactivo") = 1
            dtAgrega.Rows.Add(drAgrega)
            'dvAgrega = New DataView(dtAgrega)
            grdNOM.DataSource = dtAgrega

            txtClasificacionNOM.Text = ""
            txtTituloNOM.Text = ""

        End If
    End Sub
#End Region

#Region "  cmdNMX"
    Private Sub cmdNMX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNMX.Click
        If sTipoProceso = "Agregar" Then 'fmr 29/11/06
            If Trim(txtRamaIndustrial.Text) = "" Or Trim(txtConsecutivo.Text) = "" Or Trim(txtOrganismo.Text) = "" Or Trim(txtA�o.Text) = "" Then
                MsgBox("Debes de llenar todos los campos de la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            If objNormas.Clasificacion = "NMX----" Then
                MsgBox("Debes de llenar la norma Clasificaci�n antes de agregar una referencia", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
        End If


        If txtClasificacionNMX.Text = "" Or txtTituloNMX.Text = "" Then
            MsgBox("No dejes campos vacios", MsgBoxStyle.Exclamation, "Norma NMX")
            Exit Sub
        Else
            Dim dtAgrega As New DataTable
            Dim drAgrega As DataRow
            Dim dvAgrega As DataView
            dtAgrega = grdNMX.DataSource
            drAgrega = dtAgrega.NewRow

            drAgrega("Clasificacion") = objNormas.Clasificacion 'NormaClasificacion 'cboClasificacion.SelectedValue
            drAgrega("ID_Tipo_Norma") = 5 'NMX
            drAgrega("Clasificacion_Norma") = txtClasificacionNMX.Text
            drAgrega("Titulo_Norma") = txtTituloNMX.Text
            drAgrega("Inactivo") = 1
            dtAgrega.Rows.Add(drAgrega)
            'dvAgrega = New DataView(dtAgrega)
            grdNMX.DataSource = dtAgrega

            txtClasificacionNMX.Text = ""
            txtTituloNMX.Text = ""
        End If
    End Sub
#End Region

#Region "  cmdNRF"
    Private Sub cmdNRF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNRF.Click
        If sTipoProceso = "Agregar" Then 'fmr 29/11/06
            If Trim(txtRamaIndustrial.Text) = "" Or Trim(txtConsecutivo.Text) = "" Or Trim(txtOrganismo.Text) = "" Or Trim(txtA�o.Text) = "" Then
                MsgBox("Debes de llenar todos los campos de la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
            objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            If objNormas.Clasificacion = "NMX----" Then
                MsgBox("Debes de llenar la norma Clasificaci�n antes de agregar una referencia", MsgBoxStyle.Exclamation, "Norma Clasificacion")
                Exit Sub
            End If
        End If

        If txtClasificacionNRF.Text = "" Or txtTituloNRF.Text = "" Then
            MsgBox("No dejes campos vacios", MsgBoxStyle.Exclamation, "Norma NRF")
            Exit Sub
        Else
            Dim dtAgrega As New DataTable
            Dim drAgrega As DataRow
            Dim dvAgrega As DataView
            dtAgrega = grdNRF.DataSource
            drAgrega = dtAgrega.NewRow

            drAgrega("Clasificacion") = objNormas.Clasificacion 'NormaClasificacion 'cboClasificacion.SelectedValue
            drAgrega("ID_Tipo_Norma") = 6 'NRF
            drAgrega("Clasificacion_Norma") = txtClasificacionNRF.Text
            drAgrega("Titulo_Norma") = txtTituloNRF.Text
            drAgrega("Inactivo") = 1
            dtAgrega.Rows.Add(drAgrega)
            'dvAgrega = New DataView(dtAgrega)
            grdNRF.DataSource = dtAgrega

            txtClasificacionNRF.Text = ""
            txtTituloNRF.Text = ""
        End If
    End Sub
#End Region

#Region "  chkConcordancia"
    Private Sub chkConcordancia_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkConcordancia.CheckedChanged
        If sTipoProceso = "Agregar" Then
            If chkConcordancia.Checked = True Then
                Limpia_Campos(txtClasificacionConcordancia, txtTituloConcordancia)
                Activos(txtClasificacionConcordancia, txtTituloConcordancia, cmdConcordancia)
                grdConcordancia.ReadOnly = False
            ElseIf chkConcordancia.Checked = False Then
                Limpia_Campos(txtClasificacionConcordancia, txtTituloConcordancia)
                Inactivos(txtClasificacionConcordancia, txtTituloConcordancia, cmdConcordancia, grdConcordancia)
                grdConcordancia.ReadOnly = True

                Dim dtLimpia As DataTable
                dtLimpia = grdConcordancia.DataSource
                dtLimpia.Rows.Clear()
            End If

        ElseIf sTipoProceso = "Editar" Then
            If chkConcordancia.Checked = True Then
                Limpia_Campos(txtClasificacionConcordancia, txtTituloConcordancia)
                Activos(txtClasificacionConcordancia, txtTituloConcordancia, cmdConcordancia)

                grdConcordancia.ReadOnly = False
                Activos(grdAdoptada)
            ElseIf chkConcordancia.Checked = False Then
                Limpia_Campos(txtClasificacionConcordancia, txtTituloConcordancia)
                Inactivos(txtClasificacionConcordancia, txtTituloConcordancia, cmdConcordancia)
                objNormas.Bandera = 7
                objNormas.Tipo_Norma = 7
                objNormas.Clasificacion = NormaClasificacion
                Call Llena_GridDetalle(grdConcordancia)

                Inactivos(grdConcordancia, cmdConcordancia)
                grdConcordancia.ReadOnly = True
            End If
        End If
    End Sub
#End Region

#Region "  chkAdoptada"
    Private Sub chkAdoptada_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAdoptada.CheckedChanged
        If sTipoProceso = "Agregar" Then
            If chkAdoptada.Checked = True Then
                Limpia_Campos(txtClasificacionAdoptada, txtTituloAdoptado)
                Activos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada) ', grdAdoptada)
                'grdAdoptada.ReadOnly = False
            ElseIf chkAdoptada.Checked = False Then
                Limpia_Campos(txtClasificacionAdoptada, txtTituloAdoptado)
                Inactivos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada) ', grdAdoptada)
                'grdAdoptada.ReadOnly = True

                Dim dtLimpia As DataTable
                dtLimpia = grdAdoptada.DataSource
                dtLimpia.Rows.Clear()
            End If

        ElseIf sTipoProceso = "Editar" Then
            If chkAdoptada.Checked = True Then
                Limpia_Campos(txtClasificacionAdoptada, txtTituloAdoptado)
                Activos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada) 'fmr 29/11/06

                'grdAdoptada.ReadOnly = False
                Activos(grdAdoptada)
            ElseIf chkAdoptada.Checked = False Then
                Limpia_Campos(txtClasificacionAdoptada, txtTituloAdoptado)
                Inactivos(txtClasificacionAdoptada, txtTituloAdoptado, cmdAdoptada) 'fmr 29/11/06
                objNormas.Bandera = 7
                objNormas.Tipo_Norma = 1
                objNormas.Tipo_Norma_Dos = 0 'manda vacio
                objNormas.Clasificacion = NormaClasificacion
                Call Llena_GridDetalle(grdAdoptada)

                'Inactivos(grdAdoptada)
                'grdAdoptada.ReadOnly = True
            End If
        End If
    End Sub
#End Region

#Region "  chkArmonizada"
    Private Sub chkArmonizada_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkArmonizada.CheckedChanged
        If sTipoProceso = "Agregar" Then
            If chkArmonizada.Checked = True Then
                Limpia_Campos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA)
                Activos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, cmdArmonizada) ', grdArmonizada)
                'grdArmonizada.ReadOnly = False
            ElseIf chkArmonizada.Checked = False Then
                Limpia_Campos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA)
                Inactivos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, cmdArmonizada) ', grdArmonizada)
                'grdArmonizada.ReadOnly = True

                Dim dtLimpia As DataTable
                dtLimpia = grdArmonizada.DataSource
                dtLimpia.Rows.Clear()
            End If

        ElseIf sTipoProceso = "Editar" Then
            If chkArmonizada.Checked = True Then
                Limpia_Campos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA)
                Activos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, cmdArmonizada) 'fmr 29/11/06

                'grdArmonizada.ReadOnly = False
                Activos(grdArmonizada)
            ElseIf chkArmonizada.Checked = False Then
                Limpia_Campos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA)
                Inactivos(txtClasificacionUL, txtTituloUL, txtClasificacionCSA, txtTituloCSA, cmdArmonizada) 'fmr 29/11/06
                objNormas.Bandera = 7
                objNormas.Tipo_Norma = 2
                objNormas.Tipo_Norma_Dos = 3
                objNormas.Clasificacion = NormaClasificacion
                Call Llena_GridDetalle(grdArmonizada)


                'grdArmonizada.ReadOnly = True
                'Inactivos(grdArmonizada)
            End If
        End If
    End Sub
#End Region

#Region "  chkNOM"
    Private Sub chkNOM_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNOM.CheckedChanged
        If sTipoProceso = "Agregar" Then
            If chkNOM.Checked = True Then
                Limpia_Campos(txtClasificacionNOM, txtTituloNOM)
                Activos(txtClasificacionNOM, txtTituloNOM, cmdNOM) ', grdNOM)
                'grdNOM.ReadOnly = False
            ElseIf chkNOM.Checked = False Then
                Limpia_Campos(txtClasificacionNOM, txtTituloNOM)
                Inactivos(txtClasificacionNOM, txtTituloNOM, cmdNOM) ', grdNOM)
                grdNOM.ReadOnly = True

                Dim dtLimpia As DataTable
                dtLimpia = grdNOM.DataSource
                dtLimpia.Rows.Clear()
            End If

        ElseIf sTipoProceso = "Editar" Then
            If chkNOM.Checked = True Then
                Limpia_Campos(txtClasificacionNOM, txtTituloNOM)
                Activos(txtClasificacionNOM, txtTituloNOM, cmdNOM) 'fmr 29/11/06

                'grdNOM.ReadOnly = False
                Activos(grdNOM)
            ElseIf chkNOM.Checked = False Then
                Limpia_Campos(txtClasificacionNOM, txtTituloNOM)
                Activos(txtClasificacionNOM, txtTituloNOM, cmdNOM)
                objNormas.Bandera = 7
                objNormas.Tipo_Norma = 4
                objNormas.Tipo_Norma_Dos = 0 'manda vacio
                objNormas.Clasificacion = NormaClasificacion
                Call Llena_GridDetalle(grdNOM)
                grdNOM.ReadOnly = True
                'Inactivos(grdNOM)
            End If
        End If
    End Sub
#End Region

#Region "  chkNMX"
    Private Sub chkNMX_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNMX.CheckedChanged
        If sTipoProceso = "Agregar" Then
            If chkNMX.Checked = True Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Activos(txtClasificacionNMX, txtTituloNMX, cmdNMX) ', grdNMX)
                'grdNMX.ReadOnly = False
            ElseIf chkNMX.Checked = False Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Inactivos(txtClasificacionNMX, txtTituloNMX, cmdNMX) ', grdNMX)
                grdNMX.ReadOnly = True

                Dim dtLimpia As DataTable
                dtLimpia = grdNMX.DataSource
                dtLimpia.Rows.Clear()
            End If

        ElseIf sTipoProceso = "Editar" Then
            If chkNMX.Checked = True Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Activos(txtClasificacionNMX, txtTituloNMX, cmdNMX) 'fmr 29/11/06

                'grdNMX.ReadOnly = False
                Activos(grdNMX)
            ElseIf chkNMX.Checked = False Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Activos(txtClasificacionNMX, txtTituloNMX, cmdNMX)
                objNormas.Bandera = 7
                objNormas.Tipo_Norma = 5
                objNormas.Tipo_Norma_Dos = 0 'manda vacio
                objNormas.Clasificacion = NormaClasificacion

                Call Llena_GridDetalle(grdNMX)
                grdNMX.ReadOnly = True
                'Inactivos(grdNMX)
            End If
        End If
    End Sub
#End Region

#Region "  chkNRF"
    Private Sub chkNRF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNRF.CheckedChanged
        If sTipoProceso = "Agregar" Then
            If chkNRF.Checked = True Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Activos(txtClasificacionNRF, txtTituloNRF, cmdNRF) ', grdNRF)
                'grdNRF.ReadOnly = False
            ElseIf chkNRF.Checked = False Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Inactivos(txtClasificacionNRF, txtTituloNRF, cmdNRF) ', grdNRF)
                'grdNRF.ReadOnly = True

                Dim dtLimpia As DataTable
                dtLimpia = grdNRF.DataSource
                dtLimpia.Rows.Clear()
            End If

        ElseIf sTipoProceso = "Editar" Then
            If chkNRF.Checked = True Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Activos(txtClasificacionNRF, txtTituloNRF, cmdNRF) 'fmr 29/11/06
                'grdNRF.ReadOnly = False
                Activos(grdNRF)
            ElseIf chkNRF.Checked = False Then
                Limpia_Campos(txtClasificacionNMX, txtTituloNMX)
                Activos(txtClasificacionNRF, txtTituloNRF, cmdNRF)
                objNormas.Bandera = 7
                objNormas.Tipo_Norma = 6
                objNormas.Tipo_Norma_Dos = 0 'manda vacio
                objNormas.Clasificacion = NormaClasificacion

                Call Llena_GridDetalle(grdNRF)
                grdNRF.ReadOnly = True
                'Inactivos(grdNRF)
            End If
        End If
    End Sub
#End Region


#Region "  dtkDeclaratoria"
    Private Sub dtkDeclaratoria_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkDeclaratoria.TextChanged
        txtDeclaratoria.Text = dtkDeclaratoria.Value
        Dim sDeclaratoria As String
        sDeclaratoria = DateAdd(DateInterval.DayOfYear, 60, dtkDeclaratoria.Value)
        dtkEntradaVigor.Value = sDeclaratoria

        Dim sRevisionQuinquenal As String
        'txtRevisionQuinquenal.Text = dtkDeclaratoria.Value + sA�o = Left(cboReferencia.Text, 4)
        sRevisionQuinquenal = Year(CDate(dtkDeclaratoria.Value)) + 5
        sRevisionQuinquenal = Mid(dtkDeclaratoria.Value, 1, 6) + sRevisionQuinquenal
        txtRevisionQuinquenal.Text = sRevisionQuinquenal
    End Sub
#End Region


    Private Sub dtkEntradaVigor_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkEntradaVigor.TextChanged
        txtEntradaVigor.Text = dtkEntradaVigor.Value
    End Sub

    Private Sub dtkRevisionQuinquenal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'txtRevisionQuinquenal.Text = dtkRevisionQuinquenal.Value
    End Sub

    'Private Sub dtkDeclaratoriaVigencia_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    txtDeclaratoriaVigencia.Text = dtkDeclaratoriaVigencia.Value
    'End Sub

    Private Sub dtkNotificacionRatificacion_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkNotificacionRatificacion.TextChanged
        txtNotificacionRatificacion.Text = dtkNotificacionRatificacion.Value
    End Sub

    'Private Sub dtkPublicacionConsulta_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    txtPublicacionConsulta.Text = dtkPublicacionConsulta.Value
    'End Sub

    'Private Sub dtkFechaLimite_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    txtFechaLimite.Text = dtkFechaLimite.Value
    'End Sub

    Private Sub dtkNotificacionModificacion_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkNotificacionModificacion.TextChanged
        txtNotificacionModificacion.Text = dtkNotificacionModificacion.Value
    End Sub

    Private Sub dtkFecUno_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkFecUno.TextChanged
        'txtFecUno.Text = dtkFecUno.Value
    End Sub

    Private Sub dtkFecDos_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkFecDos.TextChanged
        'txtFecDos.Text = dtkFecDos.Value
    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        If sTipoProceso = "Agregar" Then
            '''If txtRamaIndustrial.Text = "" Or txtConsecutivo.Text = "" Or txtOrganismo.Text = "" Then
            '''    MsgBox("No dejes ningun campo vac�o para la Clasificaci�n de la Norma", MsgBoxStyle.Information, "Cat�logo de Normas")
            '''    Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
            '''    Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
            '''    Call proceso_guardar()
            '''    Exit Sub
            '''End If
            '''objNormas.Clasificacion = "NMX-" + txtRamaIndustrial.Text + "-" + txtConsecutivo.Text + "-" + txtOrganismo.Text + "-" + txtA�o.Text
            '''If objNormas.Clasificacion = "" Or Len(objNormas.Clasificacion) <= 19 Then
            '''    MsgBox("Debes de agregar la norma Clasificaci�n", MsgBoxStyle.Exclamation, "Norma Clasificacion")
            '''    Exit Sub
            '''End If
        End If
    End Sub

    Private Sub cmdComites_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdComites.Click
        cmdComites.Enabled = False
        cmdComitesGuardar.Enabled = True
        Call llena_TreeView()
    End Sub

#Region "  llena_TreeView"
    Private Sub llena_TreeView()
        tvComites.Nodes.Clear()
        tvComites.Visible = True

        Cursor.Current = Cursors.WaitCursor
        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione un Comit�")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione un Comit�")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        tvComites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        'tvComites.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvComites.ResetText()

        Cursor.Current = Cursors.Default



        '*****************************fmr
        '''        tvComites.Nodes.Clear()
        '''        tvComites.Visible = True
        '''        Dim Comite As TreeNode
        '''        Dim CT As TreeNode
        '''        Dim SC As TreeNode
        '''        Dim GT As TreeNode
        '''        Dim SGT As TreeNode

        '''        Dim oTablaComite As DataTable
        '''        Dim oTablaCT As DataTable
        '''        Dim oTablaSC As DataTable
        '''        Dim oTablaGT As DataTable
        '''        Dim oTablaSGT As DataTable 'fmr octubre
        '''        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)

        '''        oTablaComite = objNodos.ListaComite
        '''        If objNodos.ListaComite Is Nothing Then
        '''            Comite = tvComites.Nodes.Add("Ra�z")
        '''            Exit Sub
        '''        End If

        '''        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        '''        tvComites.BeginUpdate()

        '''        ' defino variable del tipo DataRow
        '''        Dim RegComite As DataRow
        '''        Dim RegCT As DataRow
        '''        Dim RegSC As DataRow
        '''        Dim RegGT As DataRow
        '''        Dim RegSGT As DataRow

        '''        dvComite = oTablaComite.DefaultView
        '''        Comite = tvComites.Nodes.Add("Seleccione un Comit�")

        '''        For Each RegComite In oTablaComite.Rows '******COMITES
        '''            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
        '''            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
        '''                GoTo sinComite
        '''            End If
        '''            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

        '''            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
        '''                CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
        '''                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
        '''                    'Exit For
        '''                    GoTo sinCT
        '''                End If
        '''                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

        '''                For Each RegSC In oTablaSC.Rows '******SUB COMITE
        '''                    SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
        '''                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
        '''                        GoTo sinSC
        '''                    End If
        '''                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

        '''                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
        '''                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))

        '''                        '''                        If objNodos.ListaSGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo")) Is Nothing Then  'Valida si no existen nodos hijos
        '''                        '''                            GoTo sinGT
        '''                        '''                        End If
        '''                        '''                        oTablaSGT = objNodos.ListaSGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"))  '***OK

        '''                        '''                        For Each RegSGT In oTablaSGT.Rows '******SUB GRUPOS DE TRABAJO
        '''                        '''                            SGT = GT.Nodes.Add(Trim(RegSGT("ID_SGT")))

        '''                        '''                        Next 'SGT
        '''                        '''sinGT:
        '''                    Next 'GT
        '''sinSC:
        '''                Next 'SC
        '''sinCT:
        '''            Next 'CT
        '''sinComite:
        '''        Next 'Comites
        '''        tvComites.EndUpdate()
        '''        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        '''        tvComites.AllowDrop = True
        '''        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        '''        tvComites.Sorted = True
    End Sub
#End Region

#Region "  tvComites_AfterSelect"
    Private Sub tvComites_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect

        ' recupero el Path donde est� la selecci�n y lo pongo en la barra de estado
        lblSB.Text = e.Node.FullPath
        iCaso = 0

        objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)  'fmr 07/12/06
        Dim array_texto As Array
        Dim cmdBusca As New SqlCommand
        Dim cmdBusca2 As New SqlCommand
        Dim cmdBusca3 As New SqlCommand
        Dim cmdBusca4 As New SqlCommand

        Dim da As New SqlDataAdapter(cmdBusca)
        Dim da2 As New SqlDataAdapter(cmdBusca2)
        Dim da3 As New SqlDataAdapter(cmdBusca3)
        Dim da4 As New SqlDataAdapter(cmdBusca4)

        Dim dsP_Normalizacion As New DataSet
        Dim dsP_Normalizacion2 As New DataSet
        Dim dsP_Normalizacion3 As New DataSet
        Dim dsP_Normalizacion4 As New DataSet

        If lblSB.Text = "" Or lblSB.Text = "Seleccione un Comit�" Then
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT)
            Inactivos(cmdBorrar)
            iCaso = 1
            Exit Sub
        End If
        Activos(cmdBorrar)
        array_texto = Split(lblSB.Text, "\")

        If array_texto.Length <= 1 Then
            Limpia_Campos(txtComite)
        Else
            objComites.Bandera = 1

            objComites.ID_Comite = array_texto(1)
            objComites.Busca_uno()
            '''aqui
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            iCaso = 2
        End If

        If array_texto.Length <= 2 Then
            'txtPertenece.Text = array_texto(1)
            txtCT.Text = ""
        Else
            objComites.Bandera = 2
            objComites.ID_Comite = array_texto(1)

            If Microsoft.VisualBasic.Left(array_texto(2), 2) = "GT" Then
                objComites.Bandera = 4
                objComites.ID_CT = "NA"
                objComites.ID_SC = "NA"
                objComites.ID_GT = array_texto(2)
                GoTo GT
            End If

            objComites.ID_CT = array_texto(2)
            objComites.Busca_dos()
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            iCaso = 3

        End If


        If array_texto.Length <= 3 Then
            txtSC.Text = ""
            'txtPertenece.Text = array_texto(2)
        Else
            objComites.Bandera = 3
            objComites.ID_Comite = array_texto(1)
            objComites.ID_CT = array_texto(2)

            If Microsoft.VisualBasic.Left(array_texto(3), 2) = "GT" Then
                objComites.Bandera = 4
                objComites.ID_SC = "NA"
                objComites.ID_GT = array_texto(3)
                GoTo GT
            End If

            objComites.ID_SC = array_texto(3)
            objComites.Busca_tres()
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT
            iCaso = 4
        End If


        If array_texto.Length <= 4 Then
            txtGT.Text = ""
        Else
            objComites.Bandera = 4
            objComites.ID_Comite = array_texto(1)
            objComites.ID_CT = array_texto(2)
            objComites.ID_SC = array_texto(3)
            objComites.ID_GT = array_texto(4)

GT:         'esta salto de l�nea es para cuando un Comite o CT tiene un GT directo

            objComites.Busca_cuatro()
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT
            iCaso = 5
            'cmdBusca4.Dispose()
        End If

        If array_texto.Length > 5 Then
            iCaso = 6
        End If


        '''''***************fmr
        '''' recupero el Path donde est� la selecci�n y lo pongo en la barra de estado
        ''''SB1.Text = e.Node.FullPath
        '''lblSB.Text = e.Node.FullPath
        '''iCaso = 0
        ''''cn.ConnectionString = ("Data source= ance02; initial catalog= dbNormaNet; user id = admsis; pwd=admynsys")
        '''Dim array_texto As Array
        '''Dim cmdBusca As New SqlCommand
        '''Dim cmdBusca2 As New SqlCommand
        '''Dim cmdBusca3 As New SqlCommand
        '''Dim cmdBusca4 As New SqlCommand

        '''Dim da As New SqlDataAdapter(cmdBusca)
        '''Dim da2 As New SqlDataAdapter(cmdBusca2)
        '''Dim da3 As New SqlDataAdapter(cmdBusca3)
        '''Dim da4 As New SqlDataAdapter(cmdBusca4)

        '''Dim dsP_Normalizacion As New DataSet
        '''Dim dsP_Normalizacion2 As New DataSet
        '''Dim dsP_Normalizacion3 As New DataSet
        '''Dim dsP_Normalizacion4 As New DataSet

        '''If lblSB.Text = "" Or lblSB.Text = "Seleccione un Comit�" Then
        '''    Limpia_Campos(txtComite, txtCT, txtSC, txtGT)
        '''    Limpia_Campos(txtresponsable, txtPertenece)
        '''    Inactivos(cmdBorrar)
        '''    iCaso = 1
        '''    Exit Sub
        '''End If
        '''Activos(cmdBorrar)
        '''array_texto = Split(lblSB.Text, "\")

        '''If array_texto.Length <= 1 Then 'COMITE
        '''    Limpia_Campos(txtComite)
        '''Else
        '''    Inactivos(cmdBorrar)
        '''    objComites.Bandera = 1
        '''    objComites.ID_Comite = array_texto(1)
        '''    objComites.Busca_uno()
        '''    txtComite.Text = array_texto(1)
        '''    txtPertenece.Text = array_texto(1)
        '''    objempleados.Bandera = 3
        '''    txtCT.Text = "NA"
        '''    txtSC.Text = "NA"
        '''    txtGT.Text = "NA"
        '''    iCaso = 2
        '''End If

        '''If array_texto.Length <= 2 Then 'CT
        '''    txtCT.Text = ""
        '''Else
        '''    Inactivos(cmdBorrar)
        '''    objComites.Bandera = 2
        '''    objComites.ID_Comite = array_texto(1)
        '''    objComites.ID_CT = array_texto(2)
        '''    txtSC.Text = "NA"
        '''    txtGT.Text = "NA"
        '''    txtPertenece.Text = array_texto(2)
        '''    objComites.Busca_dos()
        '''    objempleados.Bandera = 3
        '''    txtCT.Text = array_texto(2)
        '''    iCaso = 3
        '''End If

        '''If array_texto.Length <= 3 Then 'SC
        '''    txtSC.Text = ""
        '''Else
        '''    Inactivos(cmdBorrar)
        '''    objComites.Bandera = 3
        '''    objComites.ID_Comite = array_texto(1)
        '''    objComites.ID_CT = array_texto(2)
        '''    objComites.ID_SC = array_texto(3)
        '''    txtGT.Text = "NA"
        '''    txtPertenece.Text = array_texto(3)
        '''    objComites.Busca_tres()
        '''    objempleados.Bandera = 3
        '''    txtSC.Text = array_texto(3)
        '''    iCaso = 4
        '''End If

        '''If array_texto.Length <= 4 Then 'GT
        '''    txtGT.Text = ""
        '''Else
        '''    Inactivos(cmdBorrar)
        '''    objComites.Bandera = 4
        '''    objComites.ID_Comite = array_texto(1)
        '''    objComites.ID_CT = array_texto(2)
        '''    objComites.ID_SC = array_texto(3)
        '''    objComites.ID_GT = array_texto(4)
        '''    txtPertenece.Text = array_texto(4)
        '''    objComites.Busca_cuatro()
        '''    objempleados.Bandera = 3
        '''    txtGT.Text = array_texto(4)
        '''    iCaso = 5
        '''End If

        '''If array_texto.Length > 5 Then
        '''    Inactivos(cmdBorrar)
        '''    iCaso = 6
        '''End If
        Select Case array_texto.Length
            Case 2
                txtPertenece.Text = array_texto(1)
            Case 3
                txtPertenece.Text = array_texto(2)
            Case 4
                txtPertenece.Text = array_texto(3)
            Case 5
                txtPertenece.Text = array_texto(4)
        End Select
    End Sub
#End Region


    Private Sub cmdComitesGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdComitesGuardar.Click
        tvComites.Visible = False
        cmdComites.Enabled = True
        cmdComitesGuardar.Enabled = False
    End Sub

#Region "  lblSubirDoctoUno"
    Private Sub lblSubirDoctoUno_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblSubirDoctoUno.Click
        Dim archivo, indice As Array
        'OpenFileDialog1.Filter = "Archivos PDF (*.pdf)|Archivos Word (*.doc)|Archivos Excel (*.xls)|Archivos Power Point (*.ppt)| Todos los archivos (*.*)|*.*"
        OpenFileDialog1.Filter = "Todos los archivos (*.*)|*.*"

        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.ShowDialog()
        RutaUno = OpenFileDialog1.FileName
        If RutaUno = "" Then Exit Sub

        If RutaUno <> "" Then
            archivo = Split(RutaUno, "\")
            indice = Split((archivo(archivo.Length - 1)), ".")
            ''If txtId_Plan.Text = "" Then
            ''    txtDoctoUno.Text = "NORAC1_" + "Z5" + Format(Abs(100 * Rnd() + 1), "000") + "OK" + Format(Abs(1000 * Rnd() + 1), "0000") + "." + indice(1)
            ''Else
            ''    txtDoctoUno.Text = "NORAC1_" + Mid(txtId_Plan.Text, txtId_Plan.TextLength - 4) + Format(CInt(txtId_Tema.Text), "0000") + "." + indice(1)
            ''End If
            Dim iRandom As Integer = CInt(Int(Now.TimeOfDay.Seconds / 4 + 1))
            Dim sTemp As String
            sTemp = Replace(cboClasificacion.Text, "/", "")
            sTemp = Replace(sTemp, "\", "")
            txtDoctoUno.Text = "NORAC1_" & sTemp & iRandom & "." & indice(1)

            If txtDoctoUno.Text <> "" Then
                txtFecUno.Text = Format(Now, "dd/MM/yyyy")
            End If
            lblSubirDoctoDos.Enabled = True
        Else
            txtDoctoUno.Text = ""
        End If
    End Sub
#End Region

#Region "  lblSubirDoctoDos"
    Private Sub lblSubirDoctoDos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblSubirDoctoDos.Click
        Dim archivo, indice As Array
        'OpenFileDialog1.Filter = "Archivos PDF (*.pdf)|Archivos Word (*.doc)|Archivos Excel (*.xls)|Archivos Power Point (*.ppt)| Todos los archivos (*.*)|*.*"
        OpenFileDialog1.Filter = "Todos los archivos (*.*)|*.*"
        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.ShowDialog()
        RutaDos = OpenFileDialog1.FileName

        If RutaDos = "" Then Exit Sub

        If RutaDos <> "" Then
            archivo = Split(RutaDos, "\")
            indice = Split((archivo(archivo.Length - 1)), ".")

            ''If txtId_Plan.Text = "" Then
            ''    txtDoctoDos.Text = "NORAC2_" + "Z3" + Format(Abs(100 * Rnd() + 1), "000") + "OK" + Format(Abs(1000 * Rnd() + 1), "0000") + "." + indice(1)
            ''Else
            ''    txtDoctoDos.Text = "NORAC2_" + Mid(txtId_Plan.Text, txtId_Plan.TextLength - 4) + Format(CInt(txtId_Tema.Text), "0000") + "." + indice(1)
            ''End If

            Dim iRandom As Integer = CInt(Int(Now.TimeOfDay.Seconds / 4 + 1))
            Dim sTemp As String
            sTemp = Replace(cboClasificacion.Text, "/", "")
            sTemp = Replace(sTemp, "\", "")
            txtDoctoDos.Text = "NORAC2_" & sTemp & iRandom & "." & indice(1)

            If txtDoctoDos.Text <> "" Then
                txtFecDos.Text = Format(Now, "dd/MM/yyyy")
            End If
        Else
            txtDoctoDos.Text = ""
        End If
    End Sub
#End Region

    Sub llena_responsable(ByVal responsable As String)
        If sTipoProceso = "Editar" Or sTipoProceso = "Agregar" Then ' Or IsDBNull(objNormas.Resp_Publicacion) Then
            objempleados.Bandera = 6
            objempleados.ListaCombo(cboResponsable)
            If objNormas.Resp_Publicacion <> Nothing Then
                cboResponsable.SelectedValue = objNormas.Resp_Publicacion
            End If
        Else
            objempleados.Bandera = 3
            objempleados.ID_Area = "12"
            objempleados.Id_usuario = responsable
            objempleados.ListaCombo(cboResponsable)
        End If
    End Sub

    Private Sub tvComites_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles tvComites.BeforeExpand
        tvComites.SelectedImageIndex = 1
    End Sub

    Private Sub cboResponsable_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsable.SelectedIndexChanged
        If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
            txtresponsable.Text = cboResponsable.SelectedText
            txtresponsable.Text = cboResponsable.SelectedValue
            If txtresponsable.Text <> "" Then
                objempleados.Bandera = 3
                objempleados.Id_usuario = txtresponsable.Text
                objempleados.Buscar()
                If IsDBNull(objempleados.NOMBRE_COMPLETO) Then
                    txtresponsable.Visible = False
                Else
                    txtresponsable.Text = objempleados.NOMBRE_COMPLETO
                End If
            End If
        End If
    End Sub

    Private Sub chkObservaciones_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkObservaciones.CheckedChanged
        If chkObservaciones.Checked = False Then
            txtObservaciones.Enabled = False
            Limpia_Campos(txtObservaciones)
        ElseIf chkObservaciones.Checked = True Then
            Limpia_Campos(txtObservaciones)
            txtObservaciones.Enabled = True
        End If
    End Sub

    Private Sub dtkFecAviCancelacion_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecAviCancelacion.ValueChanged
        If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
            txtFecAviCancelacion.Text = Format(dtkFecAviCancelacion.Value, "dd/MM/yyyy")
        End If
    End Sub

    'Private Sub dtkDeclaratoriaVigencia_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
    '        txtDeclaratoriaVigencia.Text = Format(dtkDeclaratoriaVigencia.Value, "dd/MM/yyyy")
    '    End If
    'End Sub

    Private Sub dtkDeclaratoria_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDeclaratoria.ValueChanged
        If txtDeclaratoria.Text <> "" Then
            txtRevisionQuinquenal.Text = dtkDeclaratoria.Value.AddYears(5)
        End If
    End Sub

    Private Sub chkNormasCan_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNormasCan.CheckedChanged
        Call Carga_Combo_Clasificacion()
    End Sub

    Private Sub cmdDocFinal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDocFinal.Click
        Dim archivo, indice As Array
        'OpenFileDialog1.Filter = "Archivos PDF (*.pdf)|Archivos Word (*.doc)|Archivos Excel (*.xls)|Archivos Power Point (*.ppt)| Todos los archivos (*.*)|*.*"
        OpenFileDialog1.Filter = "Todos los archivos (*.*)|*.*"
        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.ShowDialog()
        RutaNormaFinal = OpenFileDialog1.FileName
        gbArchivos = False
        If RutaNormaFinal = "" Then
            Exit Sub
        End If
        gbArchivos = True
        archivo = Split(RutaNormaFinal, "\")
        indice = Split((archivo(archivo.Length - 1)), ".")
        Dim iRandom As Integer = CInt(Int(Now.TimeOfDay.Seconds / 4 + 1))

        'If txtId_Plan.Text = "" Then
        'txtDoctoNorma.Text = "NORDOC_" + "D" & iRandom & Format(Abs(100 * Rnd() + 1), "000") & "OK" & Format(Abs(1000 * Rnd() + 1), "0000") & "." & indice(1)
        Dim sTemp As String
        sTemp = Replace(cboClasificacion.Text, "/", "")
        sTemp = Replace(sTemp, "\", "")
        txtDoctoNorma.Text = sTemp & iRandom & "." & indice(1)

        'Else
        'txtDoctoNorma.Text = "NORDOC_" & iRandom & Mid(txtId_Plan.Text, txtId_Plan.TextLength - 4) & Format(CInt(txtId_Tema.Text), "0000") & "." + indice(1)
        'End If

    End Sub
End Class
'txt.Text = dtk.Value
