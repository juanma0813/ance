Imports System.Data.SqlClient


Public Class FrmConexion
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents LblDB As System.Windows.Forms.Label
    Friend WithEvents TxtDB As System.Windows.Forms.TextBox
    Friend WithEvents LblServer As System.Windows.Forms.Label
    Friend WithEvents TxtServer As System.Windows.Forms.TextBox
    Friend WithEvents LblUser As System.Windows.Forms.Label
    Friend WithEvents TxtUser As System.Windows.Forms.TextBox
    Friend WithEvents LblPass As System.Windows.Forms.Label
    Friend WithEvents TxtPass As System.Windows.Forms.TextBox
    Friend WithEvents BtnCon As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.LblDB = New System.Windows.Forms.Label
        Me.TxtDB = New System.Windows.Forms.TextBox
        Me.LblServer = New System.Windows.Forms.Label
        Me.TxtServer = New System.Windows.Forms.TextBox
        Me.LblUser = New System.Windows.Forms.Label
        Me.TxtUser = New System.Windows.Forms.TextBox
        Me.LblPass = New System.Windows.Forms.Label
        Me.TxtPass = New System.Windows.Forms.TextBox
        Me.BtnCon = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LblDB
        '
        Me.LblDB.BackColor = System.Drawing.Color.Transparent
        Me.LblDB.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDB.ForeColor = System.Drawing.Color.Black
        Me.LblDB.Location = New System.Drawing.Point(24, 44)
        Me.LblDB.Name = "LblDB"
        Me.LblDB.Size = New System.Drawing.Size(112, 24)
        Me.LblDB.TabIndex = 3
        Me.LblDB.Text = "Base de Datos"
        '
        'TxtDB
        '
        Me.TxtDB.Location = New System.Drawing.Point(168, 44)
        Me.TxtDB.Name = "TxtDB"
        Me.TxtDB.Size = New System.Drawing.Size(144, 20)
        Me.TxtDB.TabIndex = 2
        Me.TxtDB.Text = ""
        '
        'LblServer
        '
        Me.LblServer.BackColor = System.Drawing.Color.Transparent
        Me.LblServer.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblServer.ForeColor = System.Drawing.Color.Black
        Me.LblServer.Location = New System.Drawing.Point(24, 12)
        Me.LblServer.Name = "LblServer"
        Me.LblServer.Size = New System.Drawing.Size(112, 24)
        Me.LblServer.TabIndex = 5
        Me.LblServer.Text = "Servidor"
        '
        'TxtServer
        '
        Me.TxtServer.Location = New System.Drawing.Point(168, 12)
        Me.TxtServer.Name = "TxtServer"
        Me.TxtServer.Size = New System.Drawing.Size(144, 20)
        Me.TxtServer.TabIndex = 1
        Me.TxtServer.Text = ""
        '
        'LblUser
        '
        Me.LblUser.BackColor = System.Drawing.Color.Transparent
        Me.LblUser.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblUser.ForeColor = System.Drawing.Color.Black
        Me.LblUser.Location = New System.Drawing.Point(24, 80)
        Me.LblUser.Name = "LblUser"
        Me.LblUser.Size = New System.Drawing.Size(112, 24)
        Me.LblUser.TabIndex = 7
        Me.LblUser.Text = "Usuario"
        '
        'TxtUser
        '
        Me.TxtUser.Location = New System.Drawing.Point(168, 80)
        Me.TxtUser.Name = "TxtUser"
        Me.TxtUser.Size = New System.Drawing.Size(144, 20)
        Me.TxtUser.TabIndex = 3
        Me.TxtUser.Text = ""
        '
        'LblPass
        '
        Me.LblPass.BackColor = System.Drawing.Color.Transparent
        Me.LblPass.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPass.ForeColor = System.Drawing.Color.Black
        Me.LblPass.Location = New System.Drawing.Point(24, 124)
        Me.LblPass.Name = "LblPass"
        Me.LblPass.Size = New System.Drawing.Size(112, 24)
        Me.LblPass.TabIndex = 9
        Me.LblPass.Text = "Password"
        '
        'TxtPass
        '
        Me.TxtPass.Location = New System.Drawing.Point(168, 124)
        Me.TxtPass.Name = "TxtPass"
        Me.TxtPass.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.TxtPass.Size = New System.Drawing.Size(144, 20)
        Me.TxtPass.TabIndex = 4
        Me.TxtPass.Text = ""
        '
        'BtnCon
        '
        Me.BtnCon.Location = New System.Drawing.Point(112, 168)
        Me.BtnCon.Name = "BtnCon"
        Me.BtnCon.Size = New System.Drawing.Size(88, 24)
        Me.BtnCon.TabIndex = 10
        Me.BtnCon.Text = "Conectar"
        '
        'FrmConexion
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 202)
        Me.Controls.Add(Me.BtnCon)
        Me.Controls.Add(Me.LblPass)
        Me.Controls.Add(Me.TxtPass)
        Me.Controls.Add(Me.LblUser)
        Me.Controls.Add(Me.TxtUser)
        Me.Controls.Add(Me.LblServer)
        Me.Controls.Add(Me.TxtServer)
        Me.Controls.Add(Me.LblDB)
        Me.Controls.Add(Me.TxtDB)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmConexion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Conexion"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public scon As New Conexion()
    '********************************************************************************
    Private Sub FrmConexion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.TxtServer.Text = scon.Servidor
        Me.TxtDB.Text = scon.BaseDatos
        Me.TxtUser.Text = scon.Usuario
        Me.TxtPass.Text = scon.Password
        Me.Refresh()
    End Sub
    '********************************************************************************
    Private Sub BtnCon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCon.Click
        Dim i As Integer
        scon.Cadenaconexion = ""
        scon.Servidor = Me.TxtServer.Text
        scon.BaseDatos = Me.TxtDB.Text
        scon.Usuario = Me.TxtUser.Text
        scon.Password = Me.TxtPass.Text
        scon.GeneraCadena()
        scon.Conecta(scon.Cadenaconexion)
        Me.Close()
    End Sub


End Class
