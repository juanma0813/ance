
'*************************************************************************************
'Clase C_Sector Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 27/07/2006 02:48:18 p.m.
'*************************************************************************************


Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class ClsSector

    '''''''Declaracion de Variables Privadas
    Private dsC_Sector As New DataSet
    Private cn As New SqlConnection
    Private _ID_Sector As Int32
    Private _Descripcion As String
    Private sSql As String
    Dim objconexion1 As New clsConexionArchivo.clsConexionArchivo

    Public Sub New(ByVal Identificador As Integer, ByVal Usuario As String, ByVal Password As String)
        objconexion1.Conexion(Identificador, Usuario, Password)
        cn.ConnectionString = "Data source = " + objconexion1.SserverC + "; Initial Catalog = " + objconexion1.SBaseD + "; User Id = " + Usuario + "; Pwd =  " + Password

    End Sub

    '''''''Declaracion de Propiedades publicas
    Public Property ID_Sector()
        Get
            Return _ID_Sector
        End Get
        Set(ByVal Value)
            _ID_Sector = Value
        End Set
    End Property

    Public Property Descripcion()
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value)
            _Descripcion = Value
        End Set
    End Property


    Public Sub New()
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Sector")
        Try
            da = New Data.SqlClient.SqlDataAdapter("SELECT * FROM C_Sector ", cn)
            da.Fill(dt)
            Return dt
        Catch
            Return Nothing
        End Try
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar(ByVal sClave As Integer)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM C_Sector WHERE ID_Sector =" & sClave
        Dim cmd As New SqlCommand(sSql, cn)
        Dim dr As SqlDataReader
        'cn.Open()
        dr = cmd.ExecuteReader
        If dr.Read Then
            _ID_Sector = dr("ID_Sector")
            _Descripcion = dr("Descripcion")
        Else
            _ID_Sector = ""
            _Descripcion = ""
        End If
        'cn.Close()
    End Sub
    Public Function maxi() As Integer
        sSql = "SELECT Max(Id_Sector)as contador FROM C_Sector "
        Dim cmd As New SqlCommand(sSql, cn)
        Dim dr As SqlDataReader
        cn.Open()
        dr = cmd.ExecuteReader
        If dr.Read Then
            maxi = dr("contador")
            Return maxi
        End If
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        '''sSql = "UPDATE C_Sector SET Descripcion = @Descripcion, Where (ID_Sector = @ID_Sector)"
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_sector"
            .Parameters.Add("@ID_Sector", _ID_Sector)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", 2)
        End With

        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close() 'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function


    Public Function Insertar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If

        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_sector"
            .Parameters.Add("@ID_Sector", _ID_Sector + 1)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Bandera", 1)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        '
    End Function
End Class


