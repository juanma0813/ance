
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Proy Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 21/09/2006 05:53:34 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Proy

     '''''''Declaracion de Variables Privadas
     Private dsP_Proy AS New DataSet
     Private _Id_Plan as System.String
     Private _Id_Tema as System.Int32
     Private _Clasificacion as System.String
     Private _F_Aprob_Conance as System.DateTime
     Private _Titulo as System.String
     Private _Num_Paginas as System.Int32
     Private _F_Pub_Com_Pub as System.DateTime
     Private _F_Lim_Com_Pub as System.DateTime
     Private _Act_Com as System.String
     Private _Num_Comentarios as System.Int32
     Private _F_Ini_Res_CP as System.DateTime
     Private _F_Lim_Apr_Res_CP as System.DateTime
     Private _F_Aprobacion_CP as System.DateTime
     Private _F_VoBo_Conance as System.DateTime
     Private _F_Ini_Rev_Proy as System.DateTime
     Private _F_Fin_Rev_Proy as System.DateTime
     Private _F_Edi_Pro_Fin as System.DateTime
     Private _F_Env_DGN as System.DateTime
     Private _Act_Apro_Proy_Fin as System.String
    Private _Responsable As System.String
    Private _Bandera As Boolean
    Private _Encontrado As Boolean

    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _status As Integer
    Private _Tipo As String
    Private _Bandera2 As Integer
    Private _sReferencia As String
    Private _sPaginasNorma As String

    Private sSql As String

    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Plan() As System.String
          Get
              Return _Id_Plan
          End Get
          Set(Value as System.String)
              _Id_Plan = Value
          End Set
     End Property

     Public Property Id_Tema() As System.Int32
          Get
              Return _Id_Tema
          End Get
          Set(Value as System.Int32)
              _Id_Tema = Value
          End Set
     End Property

     Public Property Clasificacion() As System.String
          Get
              Return _Clasificacion
          End Get
          Set(Value as System.String)
              _Clasificacion = Value
          End Set
     End Property

     Public Property F_Aprob_Conance() As System.DateTime
          Get
              Return _F_Aprob_Conance
          End Get
          Set(Value as System.DateTime)
              _F_Aprob_Conance = Value
          End Set
     End Property

     Public Property Titulo() As System.String
          Get
              Return _Titulo
          End Get
          Set(Value as System.String)
              _Titulo = Value
          End Set
     End Property

     Public Property Num_Paginas() As System.Int32
          Get
              Return _Num_Paginas
          End Get
          Set(Value as System.Int32)
              _Num_Paginas = Value
          End Set
     End Property

     Public Property F_Pub_Com_Pub() As System.DateTime
          Get
              Return _F_Pub_Com_Pub
          End Get
          Set(Value as System.DateTime)
              _F_Pub_Com_Pub = Value
          End Set
     End Property

     Public Property F_Lim_Com_Pub() As System.DateTime
          Get
              Return _F_Lim_Com_Pub
          End Get
          Set(Value as System.DateTime)
              _F_Lim_Com_Pub = Value
          End Set
     End Property

     Public Property Act_Com() As System.String
          Get
              Return _Act_Com
          End Get
          Set(Value as System.String)
              _Act_Com = Value
          End Set
     End Property

     Public Property Num_Comentarios() As System.Int32
          Get
              Return _Num_Comentarios
          End Get
          Set(Value as System.Int32)
              _Num_Comentarios = Value
          End Set
     End Property

     Public Property F_Ini_Res_CP() As System.DateTime
          Get
              Return _F_Ini_Res_CP
          End Get
          Set(Value as System.DateTime)
              _F_Ini_Res_CP = Value
          End Set
     End Property

     Public Property F_Lim_Apr_Res_CP() As System.DateTime
          Get
              Return _F_Lim_Apr_Res_CP
          End Get
          Set(Value as System.DateTime)
              _F_Lim_Apr_Res_CP = Value
          End Set
     End Property

     Public Property F_Aprobacion_CP() As System.DateTime
          Get
              Return _F_Aprobacion_CP
          End Get
          Set(Value as System.DateTime)
              _F_Aprobacion_CP = Value
          End Set
     End Property

     Public Property F_VoBo_Conance() As System.DateTime
          Get
              Return _F_VoBo_Conance
          End Get
          Set(Value as System.DateTime)
              _F_VoBo_Conance = Value
          End Set
     End Property

     Public Property F_Ini_Rev_Proy() As System.DateTime
          Get
              Return _F_Ini_Rev_Proy
          End Get
          Set(Value as System.DateTime)
              _F_Ini_Rev_Proy = Value
          End Set
     End Property

     Public Property F_Fin_Rev_Proy() As System.DateTime
          Get
              Return _F_Fin_Rev_Proy
          End Get
          Set(Value as System.DateTime)
              _F_Fin_Rev_Proy = Value
          End Set
     End Property

     Public Property F_Edi_Pro_Fin() As System.DateTime
          Get
              Return _F_Edi_Pro_Fin
          End Get
          Set(Value as System.DateTime)
              _F_Edi_Pro_Fin = Value
          End Set
     End Property

     Public Property F_Env_DGN() As System.DateTime
          Get
              Return _F_Env_DGN
          End Get
          Set(Value as System.DateTime)
              _F_Env_DGN = Value
          End Set
     End Property

     Public Property Act_Apro_Proy_Fin() As System.String
          Get
              Return _Act_Apro_Proy_Fin
          End Get
          Set(Value as System.String)
              _Act_Apro_Proy_Fin = Value
          End Set
     End Property

     Public Property Responsable() As System.String
          Get
              Return _Responsable
          End Get
          Set(Value as System.String)
              _Responsable = Value
          End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal value As Boolean)
            _Encontrado = value
        End Set
    End Property
    Public Property Bandera() As Boolean
        Get
            Return _Bandera
        End Get
        Set(ByVal value As Boolean)
            _Bandera = value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Status() As Integer
        Get
            Return _status
        End Get
        Set(ByVal Value As Integer)
            _status = Value
        End Set
    End Property

    Public Property bandera2() As Integer
        Get
            Return _Bandera2
        End Get
        Set(ByVal Value As Integer)
            _Bandera2 = Value
        End Set
    End Property

    Public Property Tipo() As String
        Get
            Return _Tipo
        End Get
        Set(ByVal Value As String)
            _Tipo = Value
        End Set
    End Property
    Public Property sReferencia() As System.String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As System.String)
            _sReferencia = Value
        End Set
    End Property

    Public Property sPaginasNorma() As System.String
        Get
            Return _sPaginasNorma
        End Get
        Set(ByVal Value As System.String)
            _sPaginasNorma = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Proy")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal Stema As String, ByVal splan As String, ByVal sref As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Proy WHERE id_tema='" & Stema & "' and id_plan='" & splan & "' and status <> 10 and status <> 11 "
        sSql = sSql + " and ref_a�o + ref_comite + ref_Consecutivo + ref_regreso + ref_traspaso ='" & sref & "'"
        If _Tipo = "abandono" Then sSql = sSql + "Order by ref_regreso desc"
        If _Tipo = "traspaso" Then sSql = sSql + "Order by ref_regreso desc"

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da.Fill(dsP_Proy, "C_Encontrado")
        cn.Close()
        If dsP_Proy.Tables("C_Encontrado").Rows.Count > 0 Then


            _Ref_A�o = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_A�o"))
            _Ref_Comite = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
            _Ref_Consecutivo = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
            _Ref_Regreso = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
            _Ref_Traspaso = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))
            _status = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Status")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Status"))

            _Id_Plan = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Id_Plan")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Id_Plan"))
            _Id_Tema = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Id_Tema")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Id_Tema"))
            _Clasificacion = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Clasificacion")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Clasificacion"))
            _Titulo = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Titulo")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Titulo"))
            _Num_Paginas = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Num_Paginas")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Num_Paginas"))
            '_Act_Com = dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Act_Com")
            _Num_Comentarios = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Num_Comentarios")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Num_Comentarios"))
            _Responsable = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Responsable")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Responsable"))
            _sPaginasNorma = IIf(IsDBNull(dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Act_Com")) = True, "", dsP_Proy.Tables("C_Encontrado").Rows(0).Item("Act_Com"))
            _Encontrado = True
        Else
            _Id_Plan = ""
            _Id_Tema = 0
            _Clasificacion = ""
            _Titulo = ""
            _Num_Paginas = 0
            _Act_Com = ""
            _Num_Comentarios = 0
            _Responsable = ""
            _sPaginasNorma = 0
            _Encontrado = False
        End If
        dsP_Proy.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String, ByVal sref As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE P_Proy SET Id_Plan = @Id_Plan, Id_Tema = @Id_Tema, Clasificacion = @Clasificacion, F_Aprob_Conance = @F_Aprob_Conance, Titulo = @Titulo, Num_Paginas = @Num_Paginas, F_Pub_Com_Pub = @F_Pub_Com_Pub, F_Lim_Com_Pub = @F_Lim_Com_Pub, Act_Com = @Act_Com, Num_Comentarios = @Num_Comentarios, F_Ini_Res_CP = @F_Ini_Res_CP, F_Lim_Apr_Res_CP = @F_Lim_Apr_Res_CP, F_Aprobacion_CP = @F_Aprobacion_CP, F_VoBo_Conance = @F_VoBo_Conance, F_Ini_Rev_Proy = @F_Ini_Rev_Proy, F_Fin_Rev_Proy = @F_Fin_Rev_Proy, F_Edi_Pro_Fin = @F_Edi_Pro_Fin, F_Env_DGN = @F_Env_DGN, Act_Apro_Proy_Fin = @Act_Apro_Proy_Fin, Responsable = @Responsable, Where ( = @)"
        cmd.Parameters.Add("@Id_Plan", SqlDbType.NVarChar, 20, "_Id_Plan")
        cmd.Parameters.Add("@Id_Tema", SqlDbType.Int, 0, "_Id_Tema")
        cmd.Parameters.Add("@Clasificacion", SqlDbType.NVarChar, 50, "_Clasificacion")
        cmd.Parameters.Add("@F_Aprob_Conance", SqlDbType.DateTime, 0, "_F_Aprob_Conance")
        cmd.Parameters.Add("@Titulo", SqlDbType.NVarChar, 2147483647, "_Titulo")
        cmd.Parameters.Add("@Num_Paginas", SqlDbType.Int, 0, "_Num_Paginas")
        cmd.Parameters.Add("@F_Pub_Com_Pub", SqlDbType.DateTime, 0, "_F_Pub_Com_Pub")
        cmd.Parameters.Add("@F_Lim_Com_Pub", SqlDbType.DateTime, 0, "_F_Lim_Com_Pub")
        cmd.Parameters.Add("@Act_Com", SqlDbType.NVarChar, 50, "_Act_Com")
        cmd.Parameters.Add("@Num_Comentarios", SqlDbType.Int, 0, "_Num_Comentarios")
        cmd.Parameters.Add("@F_Ini_Res_CP", SqlDbType.DateTime, 0, "_F_Ini_Res_CP")
        cmd.Parameters.Add("@F_Lim_Apr_Res_CP", SqlDbType.DateTime, 0, "_F_Lim_Apr_Res_CP")
        cmd.Parameters.Add("@F_Aprobacion_CP", SqlDbType.DateTime, 0, "_F_Aprobacion_CP")
        cmd.Parameters.Add("@F_VoBo_Conance", SqlDbType.DateTime, 0, "_F_VoBo_Conance")
        cmd.Parameters.Add("@F_Ini_Rev_Proy", SqlDbType.DateTime, 0, "_F_Ini_Rev_Proy")
        cmd.Parameters.Add("@F_Fin_Rev_Proy", SqlDbType.DateTime, 0, "_F_Fin_Rev_Proy")
        cmd.Parameters.Add("@F_Edi_Pro_Fin", SqlDbType.DateTime, 0, "_F_Edi_Pro_Fin")
        cmd.Parameters.Add("@F_Env_DGN", SqlDbType.DateTime, 0, "_F_Env_DGN")
        cmd.Parameters.Add("@Act_Apro_Proy_Fin", SqlDbType.NVarChar, 50, "_Act_Apro_Proy_Fin")
        cmd.Parameters.Add("@Responsable", SqlDbType.NVarChar, 15, "_Responsable")
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Actualiza(ByVal Bandera As Integer, ByVal id_plan As String, ByVal id_tema As String, ByVal clasificacion As String, ByVal Stitulo As String, ByVal num_paginas As String, ByVal num_com As Integer, ByVal responsable As String, ByVal Id_etapa As Integer, ByVal sref As String, ByVal sPaginasNorma As String) As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Proy"

        cmd.Parameters.Add("@Id_Plan", id_plan)
        cmd.Parameters.Add("@Id_Tema", id_tema)
        cmd.Parameters.Add("@Clasificacion", clasificacion)
        cmd.Parameters.Add("@Titulo", Stitulo)
        cmd.Parameters.Add("@Num_Paginas", num_paginas)
        cmd.Parameters.Add("@Num_Comentarios", num_com)
        cmd.Parameters.Add("@Responsable", responsable)
        cmd.Parameters.Add("@bandera", Bandera)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        cmd.Parameters.Add("@Act_Com", sPaginasNorma)

        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Status", _status)

        'cmd.Parameters.Add("@Id_Etapa", Id_etapa)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function Insertar(ByVal sref As String)

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_Proy"
        If cn.State = 1 Then cn.Close()
        cn.Open()

        cmd.Connection = cn

        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Clasificacion", _Clasificacion)
        cmd.Parameters.Add("@Titulo", _Titulo)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@Num_Paginas", _Num_Paginas)
        cmd.Parameters.Add("@Act_com", _Act_Com)
        cmd.Parameters.Add("@Num_Comentarios", _Num_Comentarios)
        cmd.Parameters.Add("@Bandera", _Bandera2)
        cmd.Parameters.Add("@Status", _status)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try

    End Function
    Public Sub ActualizaRefAnterior(ByVal sref As String, ByVal band As Integer)
        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "Sp_Proy"
            .CommandType = CommandType.StoredProcedure

            .Parameters.Add("@bandera", band)
            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", (_Ref_Regreso - 1))
            .Parameters.Add("@sReferencia", sref)
            If cn.State = 1 Then cn.Close()
            cn.Open()
            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Dim ms
                ms = ex.Message
            End Try
        End With
    End Sub
    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_proy"
        cmd.Parameters.Add("@Bandera", 5)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Sub traspasaProy(ByVal plan As String, ByVal tema As Integer)
        _status = 1
        _Id_Plan = plan
        _Id_Tema = tema
        _Bandera2 = 6
        _Ref_Traspaso = _Ref_Traspaso + 1
        Insertar(_sReferencia)
    End Sub

End Class
