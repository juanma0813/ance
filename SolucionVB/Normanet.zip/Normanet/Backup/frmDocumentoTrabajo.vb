Public Class frmDocumentoTrabajo


    Inherits System.Windows.Forms.Form
    Dim sEtapa As String
    Dim oTablaPNN As DataTable
    Private clsTree As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim RegGT As DataRow
    Dim oTablaDPy As DataTable
    Dim nodo1 As New TreeNode
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private ObjDt As New ClsDt.P_DT(0, gUsuario, gPasswordSql)
    Dim Matriz As Array
    Dim Matriz_Dt As Array
    Dim svariable As String
    Dim sPlan As String
    Dim stema As String
    Dim sraiz As String
    Dim bandera As Integer
    Dim sComite As String
    Dim sCt As String
    Dim sSc As String
    Dim sGt As String

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents PnlLectura As System.Windows.Forms.Panel
    Friend WithEvents txtcomite As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tvTemasDT As System.Windows.Forms.TreeView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents lbla�o As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxTescribe3 As CtrLabelTextBox.TXTescribe
    Friend WithEvents txtf1 As System.Windows.Forms.TextBox
    Friend WithEvents dt1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents f1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtresponsable As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmdActa As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmDocumentoTrabajo))
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.cmdActa = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.PnlLectura = New System.Windows.Forms.Panel
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtresponsable = New System.Windows.Forms.TextBox
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.txtf1 = New System.Windows.Forms.TextBox
        Me.dt1 = New System.Windows.Forms.DateTimePicker
        Me.f1 = New System.Windows.Forms.Label
        Me.TxTescribe3 = New CtrLabelTextBox.TXTescribe
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.lbla�o = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.txt1 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtcomite = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.tvTemasDT = New System.Windows.Forms.TreeView
        Me.PnlLectura.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.CmdSalir, Me.cmdActa})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 472)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(680, 62)
        Me.tlbBotonera.TabIndex = 16
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'cmdActa
        '
        Me.cmdActa.ImageIndex = 6
        Me.cmdActa.Text = "Acta Aprobaci�n"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'TVPNN
        '
        Me.TVPNN.ImageIndex = -1
        Me.TVPNN.Location = New System.Drawing.Point(8, 4)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = -1
        Me.TVPNN.Size = New System.Drawing.Size(176, 464)
        Me.TVPNN.TabIndex = 15
        '
        'PnlLectura
        '
        Me.PnlLectura.Controls.Add(Me.TextBox2)
        Me.PnlLectura.Controls.Add(Me.DateTimePicker1)
        Me.PnlLectura.Controls.Add(Me.Label7)
        Me.PnlLectura.Controls.Add(Me.Label6)
        Me.PnlLectura.Controls.Add(Me.txtresponsable)
        Me.PnlLectura.Controls.Add(Me.cboResponsable)
        Me.PnlLectura.Controls.Add(Me.txtf1)
        Me.PnlLectura.Controls.Add(Me.dt1)
        Me.PnlLectura.Controls.Add(Me.f1)
        Me.PnlLectura.Controls.Add(Me.TxTescribe3)
        Me.PnlLectura.Controls.Add(Me.Label4)
        Me.PnlLectura.Controls.Add(Me.Label5)
        Me.PnlLectura.Controls.Add(Me.lbla�o)
        Me.PnlLectura.Controls.Add(Me.TextBox1)
        Me.PnlLectura.Controls.Add(Me.txt1)
        Me.PnlLectura.Controls.Add(Me.Label3)
        Me.PnlLectura.Controls.Add(Me.Label2)
        Me.PnlLectura.Controls.Add(Me.Label1)
        Me.PnlLectura.Controls.Add(Me.txtcomite)
        Me.PnlLectura.Controls.Add(Me.Label8)
        Me.PnlLectura.Controls.Add(Me.tvTemasDT)
        Me.PnlLectura.Location = New System.Drawing.Point(192, 8)
        Me.PnlLectura.Name = "PnlLectura"
        Me.PnlLectura.Size = New System.Drawing.Size(472, 456)
        Me.PnlLectura.TabIndex = 17
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(136, 280)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(96, 20)
        Me.TextBox2.TabIndex = 51
        Me.TextBox2.Text = ""
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "dd/mm/yyyy"
        Me.DateTimePicker1.Location = New System.Drawing.Point(136, 280)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(112, 20)
        Me.DateTimePicker1.TabIndex = 49
        Me.DateTimePicker1.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(24, 280)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 24)
        Me.Label7.TabIndex = 50
        Me.Label7.Text = "Fecha de Revisi�n Cruzada"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(24, 248)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 24)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Responsable Tema:"
        '
        'txtresponsable
        '
        Me.txtresponsable.Enabled = False
        Me.txtresponsable.Location = New System.Drawing.Point(112, 248)
        Me.txtresponsable.Name = "txtresponsable"
        Me.txtresponsable.Size = New System.Drawing.Size(328, 20)
        Me.txtresponsable.TabIndex = 47
        Me.txtresponsable.Text = ""
        '
        'cboResponsable
        '
        Me.cboResponsable.ItemHeight = 13
        Me.cboResponsable.Location = New System.Drawing.Point(112, 248)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(344, 21)
        Me.cboResponsable.TabIndex = 48
        '
        'txtf1
        '
        Me.txtf1.Location = New System.Drawing.Point(136, 208)
        Me.txtf1.Name = "txtf1"
        Me.txtf1.Size = New System.Drawing.Size(96, 20)
        Me.txtf1.TabIndex = 45
        Me.txtf1.Text = ""
        '
        'dt1
        '
        Me.dt1.CustomFormat = "dd/mm/yyyy"
        Me.dt1.Location = New System.Drawing.Point(136, 208)
        Me.dt1.Name = "dt1"
        Me.dt1.Size = New System.Drawing.Size(112, 20)
        Me.dt1.TabIndex = 43
        Me.dt1.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'f1
        '
        Me.f1.Location = New System.Drawing.Point(24, 208)
        Me.f1.Name = "f1"
        Me.f1.Size = New System.Drawing.Size(104, 40)
        Me.f1.TabIndex = 44
        Me.f1.Text = "Fecha de Inicio de Desarrollo de NMX"
        '
        'TxTescribe3
        '
        Me.TxTescribe3.Location = New System.Drawing.Point(24, 176)
        Me.TxTescribe3.Name = "TxTescribe3"
        Me.TxTescribe3.Size = New System.Drawing.Size(408, 24)
        Me.TxTescribe3.TabIndex = 42
        Me.TxTescribe3.txtEtiqueta = "Titulo Dt:"
        Me.TxTescribe3.TxtLocation = 96
        Me.TxTescribe3.TxtMaxlength = 32767
        Me.TxTescribe3.TxtMultiLine = True
        Me.TxTescribe3.TxtPassWordChar = Microsoft.VisualBasic.ChrW(0)
        Me.TxTescribe3.TxtReadOnly = False
        Me.TxTescribe3.TxtText = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(264, 152)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(8, 23)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "-"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(24, 152)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 23)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "Clasificaci�n"
        '
        'lbla�o
        '
        Me.lbla�o.Location = New System.Drawing.Point(272, 152)
        Me.lbla�o.Name = "lbla�o"
        Me.lbla�o.Size = New System.Drawing.Size(32, 23)
        Me.lbla�o.TabIndex = 39
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(232, 151)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(32, 20)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Text = "-"
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(194, 151)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(30, 20)
        Me.txt1.TabIndex = 1
        Me.txt1.Text = "-"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(171, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 23)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "J-"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(139, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 23)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "NMX-"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(115, 152)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 23)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "DT-"
        '
        'txtcomite
        '
        Me.txtcomite.Enabled = False
        Me.txtcomite.Location = New System.Drawing.Point(112, 360)
        Me.txtcomite.Name = "txtcomite"
        Me.txtcomite.Size = New System.Drawing.Size(344, 20)
        Me.txtcomite.TabIndex = 32
        Me.txtcomite.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(24, 360)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 23)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Pertenece:"
        '
        'tvTemasDT
        '
        Me.tvTemasDT.ImageIndex = -1
        Me.tvTemasDT.Location = New System.Drawing.Point(88, 16)
        Me.tvTemasDT.Name = "tvTemasDT"
        Me.tvTemasDT.SelectedImageIndex = -1
        Me.tvTemasDT.Size = New System.Drawing.Size(296, 88)
        Me.tvTemasDT.TabIndex = 30
        '
        'frmDocumentoTrabajo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(680, 534)
        Me.Controls.Add(Me.PnlLectura)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TVPNN)
        Me.Name = "frmDocumentoTrabajo"
        Me.Text = "Documento de Trabajo"
        Me.PnlLectura.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                sEtapa = "Agregar"
                Call Habilita(sEtapa)
                Llena_TvDt()
                'Call Carga_Combos()
            Case 1 'Editar
                sEtapa = "Editar"
                Call Habilita(sEtapa)
                'llena_tvcomites()

            Case 2 'Deshacer
                sEtapa = "Nulo"
                Call Habilita(sEtapa)
                Call Limpia_Campos()
            Case 3 'Salvar
                If sEtapa = "Editar" Then
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    '   Call Actualizar()
                Else
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    '  Call Insertar()
                End If
            Case 4
                MsgBox("Esta seguro de Borrar este Tema?", MsgBoxStyle.OKCancel, "Atenci�n")
                If MsgBoxResult.OK Then
                    ' Call Borra()
                End If
            Case 5
                Me.Dispose()
        End Select
    End Sub


    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVPNN.AfterSelect
        If PnlLectura.Visible = True Then

            svariable = e.Node.FullPath
            Matriz = Split(svariable, "\")
            Select Case Matriz.Length
                Case 1
                    sraiz = Matriz(0)
                    sEtapa = "Inactivo"
                    Call Habilita(sEtapa)

                Case (2)
                    sPlan = Matriz(1)
                    sEtapa = "Plan"
                    Call Habilita(sEtapa)
                Case 3
                    sPlan = Matriz(1)
                    stema = Matriz(2)
                    sEtapa = "Tema"
                    Call Habilita(sEtapa)
            End Select
            If sPlan <> "" And stema <> "" Then
                Call Llena_Temas(sPlan, stema)
            End If
            'llena_tvcomites()
        End If
    End Sub
    Private Sub Llena_Temas(ByVal splan As String, ByVal stema As String)
        Dim sref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(splan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        ObjDt.Buscar(splan, stema, sref)
    End Sub

    Private Sub frmDocumentoTrabajo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sEtapa = "Inactivo"
        Call Habilita(sEtapa)
        oTablaPNN = clsTree.ListaPNN("")
        TVPNN.BeginUpdate()
        nodo = TVPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = TVPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = clsTree.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
            Next
        Next
        TVPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TVPNN.Sorted = True
        'PnlLectura.Visible = True
        'PnlAgrega.Visible = False
    End Sub
    Private Sub Llena_TvDt()
        oTablaPNN = clsTree.ListaPNN("")
        tvTemasDT.BeginUpdate()
        nodo = tvTemasDT.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvTemasDT.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = clsTree.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
            Next
        Next
        tvTemasDT.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvTemasDT.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvTemasDT.Sorted = True
        'PnlLectura.Visible = True
        'PnlAgrega.Visible = False
    End Sub

    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"
                Call Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Muestra(PnlLectura)
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
            Case "Agregar"
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Inactivos(TVPNN)
                Call Muestra(PnlLectura)
                'Call Oculta(txttipoTema)
                Call Activos(PnlLectura)
                'Call Limpia_control(TxTescribe1, TxTescribe3, TxTescribe4, TxTescribe5)
                'Call Limpia_Campos(txtf1, txtf2, txtcomite, txttipoTema)
            Case "Editar"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5), tlbBotonera.Buttons.Item(4))
                Call Activos(PnlLectura)
            Case "Inactivo"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4))
            Case "Plan"
                Call Activos(tlbBotonera.Buttons.Item(0))
                Call Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4))
            Case "Tema"
                Call Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(3))

        End Select
    End Sub

    Private Sub PnlLectura_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PnlLectura.Paint

    End Sub

    Private Sub tvTemasDT_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvTemasDT.AfterSelect
        Dim sCadena As String
        sCadena = e.Node.FullPath
        Matriz_Dt = Split(sCadena, "\")
        Select Case Matriz_Dt.Length
            Case 1
                sraiz = Matriz_Dt(0)
                sEtapa = "Inactivo"
                Call Habilita(sEtapa)

            Case 2
                sPlan = Matriz_Dt(1)
                'stema = Matriz_Dt(2)
                'sEtapa = "Plan"

            Case 3
                sPlan = Matriz_Dt(1)
                stema = Matriz_Dt(2)
                sEtapa = "Tema"
                Call Habilita(sEtapa)
        End Select
        If sPlan <> "" And stema <> "" Then
            ObjPrograma.Buscar(sPlan, stema)
            lbla�o.Text = Format(Date.Now, "yyyy")
        End If
    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub
End Class
