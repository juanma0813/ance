
'*****************************************************************************
'*****************************************************************************
'           Actualizada por Efren David Tello ver 1.1 BETA
'                       NO TIENE CAMPO LLAVE CUIDADO
'              Puede Afectar el correcto funcionamiento de las funciones
'          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
'*****************************************************************************
'*****************************************************************************

Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
'agrega la referencia de windows form a la clase
'Imports System.Windows.Forms

Public Class ClsInspeccionPruebas

    '''''''Declaracion de Variables Privadas
    Private dsClsInspeccionPruebas As New DataSet
    Private _ref_a�o As String
    Private _ref_comite As String
    Private _ref_consecutivo As String
    Private _ref_regreso As String
    Private _ref_traspaso As String
    Private _E1_1 As String
    Private _E1_2 As String
    Private _E2_1 As String
    Private _E2_2 As String
    Private _E2_3 As String
    Private _E2_4 As String
    Private _E2_5 As String
    Private _E3_1 As String
    Private _E3_2 As String
    Private _E3_3 As String
    Private _E4_1 As String
    Private _E4_2 As String
    Private _E4_3 As String
    Private _E4_4 As String
    Private _E5_1 As String
    Private _E6_1 As String
    Private _E6_2 As String
    Private _E6_3 As String
    Private _E6_4 As String
    Private _E6_5 As String
    Private _E6_6 As String
    Private _E7_1 As String
    Private _E7_2 As String
    Private _E7_3 As String
    Private _E7_4 As String
    Private _E7_5 As String
    Private _E8_1 As String
    Private _E8_2 As String
    Private _E9_1 As String
    Private _E9_2 As String
    Private _E10_1 As String
    Private _E10_2 As String
    Private _E10_3 As String
    Private _E10_4 As String
    Private _E11_1 As String
    Private _E11_2 As String
    Private _E11_3 As String
    Private _E11_4 As String
    Private _Encontrado As Boolean
    Private _sReferencia As String
    Private _Bandera As Integer
    Private _Id_tema As String
    Private _ID_Plan As String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    'Si utilisas la clase de coneccion qeu todos sabemos descomenta la linea siguiente
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

    '''''''Declaracion de Propiedades publicas
    Public Property ref_a�o() As String
        Get
            Return _ref_a�o
        End Get
        Set(ByVal Value As String)
            _ref_a�o = Value
        End Set
    End Property

    Public Property ref_comite() As String
        Get
            Return _ref_comite
        End Get
        Set(ByVal Value As String)
            _ref_comite = Value
        End Set
    End Property

    Public Property ref_consecutivo() As String
        Get
            Return _ref_consecutivo
        End Get
        Set(ByVal Value As String)
            _ref_consecutivo = Value
        End Set
    End Property

    Public Property ref_regreso() As String
        Get
            Return _ref_regreso
        End Get
        Set(ByVal Value As String)
            _ref_regreso = Value
        End Set
    End Property

    Public Property ref_traspaso() As String
        Get
            Return _ref_traspaso
        End Get
        Set(ByVal Value As String)
            _ref_traspaso = Value
        End Set
    End Property

    Public Property E1_1() As String
        Get
            Return _E1_1
        End Get
        Set(ByVal Value As String)
            _E1_1 = Value
        End Set
    End Property

    Public Property E1_2() As String
        Get
            Return _E1_2
        End Get
        Set(ByVal Value As String)
            _E1_2 = Value
        End Set
    End Property

    Public Property E2_1() As String
        Get
            Return _E2_1
        End Get
        Set(ByVal Value As String)
            _E2_1 = Value
        End Set
    End Property

    Public Property E2_2() As String
        Get
            Return _E2_2
        End Get
        Set(ByVal Value As String)
            _E2_2 = Value
        End Set
    End Property

    Public Property E2_3() As String
        Get
            Return _E2_3
        End Get
        Set(ByVal Value As String)
            _E2_3 = Value
        End Set
    End Property

    Public Property E2_4() As String
        Get
            Return _E2_4
        End Get
        Set(ByVal Value As String)
            _E2_4 = Value
        End Set
    End Property

    Public Property E2_5() As String
        Get
            Return _E2_5
        End Get
        Set(ByVal Value As String)
            _E2_5 = Value
        End Set
    End Property

    Public Property E3_1() As String
        Get
            Return _E3_1
        End Get
        Set(ByVal Value As String)
            _E3_1 = Value
        End Set
    End Property

    Public Property E3_2() As String
        Get
            Return _E3_2
        End Get
        Set(ByVal Value As String)
            _E3_2 = Value
        End Set
    End Property

    Public Property E3_3() As String
        Get
            Return _E3_3
        End Get
        Set(ByVal Value As String)
            _E3_3 = Value
        End Set
    End Property

    Public Property E4_1() As String
        Get
            Return _E4_1
        End Get
        Set(ByVal Value As String)
            _E4_1 = Value
        End Set
    End Property

    Public Property E4_2() As String
        Get
            Return _E4_2
        End Get
        Set(ByVal Value As String)
            _E4_2 = Value
        End Set
    End Property

    Public Property E4_3() As String
        Get
            Return _E4_3
        End Get
        Set(ByVal Value As String)
            _E4_3 = Value
        End Set
    End Property

    Public Property E4_4() As String
        Get
            Return _E4_4
        End Get
        Set(ByVal Value As String)
            _E4_4 = Value
        End Set
    End Property

    Public Property E5_1() As String
        Get
            Return _E5_1
        End Get
        Set(ByVal Value As String)
            _E5_1 = Value
        End Set
    End Property

    Public Property E6_1() As String
        Get
            Return _E6_1
        End Get
        Set(ByVal Value As String)
            _E6_1 = Value
        End Set
    End Property

    Public Property E6_2() As String
        Get
            Return _E6_2
        End Get
        Set(ByVal Value As String)
            _E6_2 = Value
        End Set
    End Property

    Public Property E6_3() As String
        Get
            Return _E6_3
        End Get
        Set(ByVal Value As String)
            _E6_3 = Value
        End Set
    End Property

    Public Property E6_4() As String
        Get
            Return _E6_4
        End Get
        Set(ByVal Value As String)
            _E6_4 = Value
        End Set
    End Property

    Public Property E6_5() As String
        Get
            Return _E6_5
        End Get
        Set(ByVal Value As String)
            _E6_5 = Value
        End Set
    End Property

    Public Property E6_6() As String
        Get
            Return _E6_6
        End Get
        Set(ByVal Value As String)
            _E6_6 = Value
        End Set
    End Property

    Public Property E7_1() As String
        Get
            Return _E7_1
        End Get
        Set(ByVal Value As String)
            _E7_1 = Value
        End Set
    End Property

    Public Property E7_2() As String
        Get
            Return _E7_2
        End Get
        Set(ByVal Value As String)
            _E7_2 = Value
        End Set
    End Property

    Public Property E7_3() As String
        Get
            Return _E7_3
        End Get
        Set(ByVal Value As String)
            _E7_3 = Value
        End Set
    End Property

    Public Property E7_4() As String
        Get
            Return _E7_4
        End Get
        Set(ByVal Value As String)
            _E7_4 = Value
        End Set
    End Property

    Public Property E7_5() As String
        Get
            Return _E7_5
        End Get
        Set(ByVal Value As String)
            _E7_5 = Value
        End Set
    End Property

    Public Property E8_1() As String
        Get
            Return _E8_1
        End Get
        Set(ByVal Value As String)
            _E8_1 = Value
        End Set
    End Property

    Public Property E8_2() As String
        Get
            Return _E8_2
        End Get
        Set(ByVal Value As String)
            _E8_2 = Value
        End Set
    End Property

    Public Property E9_1() As String
        Get
            Return _E9_1
        End Get
        Set(ByVal Value As String)
            _E9_1 = Value
        End Set
    End Property

    Public Property E9_2() As String
        Get
            Return _E9_2
        End Get
        Set(ByVal Value As String)
            _E9_2 = Value
        End Set
    End Property

    Public Property E10_1() As String
        Get
            Return _E10_1
        End Get
        Set(ByVal Value As String)
            _E10_1 = Value
        End Set
    End Property

    Public Property E10_2() As String
        Get
            Return _E10_2
        End Get
        Set(ByVal Value As String)
            _E10_2 = Value
        End Set
    End Property

    Public Property E10_3() As String
        Get
            Return _E10_3
        End Get
        Set(ByVal Value As String)
            _E10_3 = Value
        End Set
    End Property

    Public Property E10_4() As String
        Get
            Return _E10_4
        End Get
        Set(ByVal Value As String)
            _E10_4 = Value
        End Set
    End Property

    Public Property E11_1() As String
        Get
            Return _E11_1
        End Get
        Set(ByVal Value As String)
            _E11_1 = Value
        End Set
    End Property

    Public Property E11_2() As String
        Get
            Return _E11_2
        End Get
        Set(ByVal Value As String)
            _E11_2 = Value
        End Set
    End Property

    Public Property E11_3() As String
        Get
            Return _E11_3
        End Get
        Set(ByVal Value As String)
            _E11_3 = Value
        End Set
    End Property

    Public Property E11_4() As String
        Get
            Return _E11_4
        End Get
        Set(ByVal Value As String)
            _E11_4 = Value
        End Set
    End Property

    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property

    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property ID_tema() As String
        Get
            Return _Id_tema
        End Get
        Set(ByVal Value As String)
            _Id_tema = Value
        End Set
    End Property
    Public Property ID_Plan() As String
        Get
            Return _ID_Plan
        End Get
        Set(ByVal Value As String)
            _ID_Plan = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista() As DataTable
        Dim da As SqlDataAdapter
        Dim cmd As New SqlCommand
        Dim dt As New DataTable("ClsInspeccionPruebas")

        If cn.State = 1 Then cn.Close()
        cn.Open()

        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "Sp_P_Inspeccion_Pruebas"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_tema", _Id_tema)
            .Parameters.Add("@Id_Plan", _ID_Plan)
        End With
        Try
            da = New SqlDataAdapter(cmd)
            da.Fill(dt)
        Catch ex As Exception
            MsgBox(ex.Message)
            'Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar() 'As ClsInspeccionPruebas

        Dim cmd As New SqlCommand
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Encontrado")

        cmd.CommandText = "Sp_P_Inspeccion_Pruebas"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        cmd.Parameters.Add("@Bandera", _Bandera)

        da = New SqlDataAdapter(cmd)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        da.Fill(dt)

        'da.Fill(dsClsInspeccionPruebas, "C_Encontrado")

        If dt.Rows.Count > 0 Then
            _ref_a�o = IIf(IsDBNull(dt.Rows(0).Item("ref_a�o")) = True, Nothing, dt.Rows(0).Item("ref_a�o"))
            _ref_comite = IIf(IsDBNull(dt.Rows(0).Item("ref_comite")) = True, Nothing, dt.Rows(0).Item("ref_comite"))
            _ref_consecutivo = IIf(IsDBNull(dt.Rows(0).Item("ref_consecutivo")) = True, Nothing, dt.Rows(0).Item("ref_consecutivo"))
            _ref_regreso = IIf(IsDBNull(dt.Rows(0).Item("ref_regreso")) = True, Nothing, dt.Rows(0).Item("ref_regreso"))
            _ref_traspaso = IIf(IsDBNull(dt.Rows(0).Item("ref_traspaso")) = True, Nothing, dt.Rows(0).Item("ref_traspaso"))
            _E1_1 = IIf(IsDBNull(dt.Rows(0).Item("E1_1")) = True, Nothing, dt.Rows(0).Item("E1_1"))
            _E1_2 = IIf(IsDBNull(dt.Rows(0).Item("E1_2")) = True, Nothing, dt.Rows(0).Item("E1_2"))
            _E2_1 = IIf(IsDBNull(dt.Rows(0).Item("E2_1")) = True, Nothing, dt.Rows(0).Item("E2_1"))
            _E2_2 = IIf(IsDBNull(dt.Rows(0).Item("E2_2")) = True, Nothing, dt.Rows(0).Item("E2_2"))
            _E2_3 = IIf(IsDBNull(dt.Rows(0).Item("E2_3")) = True, Nothing, dt.Rows(0).Item("E2_3"))
            _E2_4 = IIf(IsDBNull(dt.Rows(0).Item("E2_4")) = True, Nothing, dt.Rows(0).Item("E2_4"))
            _E2_5 = IIf(IsDBNull(dt.Rows(0).Item("E2_5")) = True, Nothing, dt.Rows(0).Item("E2_5"))
            _E3_1 = IIf(IsDBNull(dt.Rows(0).Item("E3_1")) = True, Nothing, dt.Rows(0).Item("E3_1"))
            _E3_2 = IIf(IsDBNull(dt.Rows(0).Item("E3_2")) = True, Nothing, dt.Rows(0).Item("E3_2"))
            _E3_3 = IIf(IsDBNull(dt.Rows(0).Item("E3_3")) = True, Nothing, dt.Rows(0).Item("E3_3"))
            _E4_1 = IIf(IsDBNull(dt.Rows(0).Item("E4_1")) = True, Nothing, dt.Rows(0).Item("E4_1"))
            _E4_2 = IIf(IsDBNull(dt.Rows(0).Item("E4_2")) = True, Nothing, dt.Rows(0).Item("E4_2"))
            _E4_3 = IIf(IsDBNull(dt.Rows(0).Item("E4_3")) = True, Nothing, dt.Rows(0).Item("E4_3"))
            _E4_4 = IIf(IsDBNull(dt.Rows(0).Item("E4_4")) = True, Nothing, dt.Rows(0).Item("E4_4"))
            _E5_1 = IIf(IsDBNull(dt.Rows(0).Item("E5_1")) = True, Nothing, dt.Rows(0).Item("E5_1"))
            _E6_1 = IIf(IsDBNull(dt.Rows(0).Item("E6_1")) = True, Nothing, dt.Rows(0).Item("E6_1"))
            _E6_2 = IIf(IsDBNull(dt.Rows(0).Item("E6_2")) = True, Nothing, dt.Rows(0).Item("E6_2"))
            _E6_3 = IIf(IsDBNull(dt.Rows(0).Item("E6_3")) = True, Nothing, dt.Rows(0).Item("E6_3"))
            _E6_4 = IIf(IsDBNull(dt.Rows(0).Item("E6_4")) = True, Nothing, dt.Rows(0).Item("E6_4"))
            _E6_5 = IIf(IsDBNull(dt.Rows(0).Item("E6_5")) = True, Nothing, dt.Rows(0).Item("E6_5"))
            _E6_6 = IIf(IsDBNull(dt.Rows(0).Item("E6_6")) = True, Nothing, dt.Rows(0).Item("E6_6"))
            _E7_1 = IIf(IsDBNull(dt.Rows(0).Item("E7_1")) = True, Nothing, dt.Rows(0).Item("E7_1"))
            _E7_2 = IIf(IsDBNull(dt.Rows(0).Item("E7_2")) = True, Nothing, dt.Rows(0).Item("E7_2"))
            _E7_3 = IIf(IsDBNull(dt.Rows(0).Item("E7_3")) = True, Nothing, dt.Rows(0).Item("E7_3"))
            _E7_4 = IIf(IsDBNull(dt.Rows(0).Item("E7_4")) = True, Nothing, dt.Rows(0).Item("E7_4"))
            _E7_5 = IIf(IsDBNull(dt.Rows(0).Item("E7_5")) = True, Nothing, dt.Rows(0).Item("E7_5"))
            _E8_1 = IIf(IsDBNull(dt.Rows(0).Item("E8_1")) = True, Nothing, dt.Rows(0).Item("E8_1"))
            _E8_2 = IIf(IsDBNull(dt.Rows(0).Item("E8_2")) = True, Nothing, dt.Rows(0).Item("E8_2"))
            _E9_1 = IIf(IsDBNull(dt.Rows(0).Item("E9_1")) = True, Nothing, dt.Rows(0).Item("E9_1"))
            _E9_2 = IIf(IsDBNull(dt.Rows(0).Item("E9_2")) = True, Nothing, dt.Rows(0).Item("E9_2"))
            _E10_1 = IIf(IsDBNull(dt.Rows(0).Item("E10_1")) = True, Nothing, dt.Rows(0).Item("E10_1"))
            _E10_2 = IIf(IsDBNull(dt.Rows(0).Item("E10_2")) = True, Nothing, dt.Rows(0).Item("E10_2"))
            _E10_3 = IIf(IsDBNull(dt.Rows(0).Item("E10_3")) = True, Nothing, dt.Rows(0).Item("E10_3"))
            _E10_4 = IIf(IsDBNull(dt.Rows(0).Item("E10_4")) = True, Nothing, dt.Rows(0).Item("E10_4"))
            _E11_1 = IIf(IsDBNull(dt.Rows(0).Item("E11_1")) = True, Nothing, dt.Rows(0).Item("E11_1"))
            _E11_2 = IIf(IsDBNull(dt.Rows(0).Item("E11_2")) = True, Nothing, dt.Rows(0).Item("E11_2"))
            _E11_3 = IIf(IsDBNull(dt.Rows(0).Item("E11_3")) = True, Nothing, dt.Rows(0).Item("E11_2"))
            _E11_4 = IIf(IsDBNull(dt.Rows(0).Item("E11_4")) = True, Nothing, dt.Rows(0).Item("E11_4"))
            _Encontrado = True
        Else
            _ref_a�o = Nothing
            _ref_comite = Nothing
            _ref_consecutivo = Nothing
            _ref_regreso = Nothing
            _ref_traspaso = Nothing
            _E1_1 = Nothing
            _E1_2 = Nothing
            _E2_1 = Nothing
            _E2_2 = Nothing
            _E2_3 = Nothing
            _E2_4 = Nothing
            _E2_5 = Nothing
            _E3_1 = Nothing
            _E3_2 = Nothing
            _E3_3 = Nothing
            _E4_1 = Nothing
            _E4_2 = Nothing
            _E4_3 = Nothing
            _E4_4 = Nothing
            _E5_1 = Nothing
            _E6_1 = Nothing
            _E6_2 = Nothing
            _E6_3 = Nothing
            _E6_4 = Nothing
            _E6_5 = Nothing
            _E6_6 = Nothing
            _E7_1 = Nothing
            _E7_2 = Nothing
            _E7_3 = Nothing
            _E7_4 = Nothing
            _E7_5 = Nothing
            _E8_1 = Nothing
            _E8_2 = Nothing
            _E9_1 = Nothing
            _E9_2 = Nothing
            _E10_1 = Nothing
            _E10_2 = Nothing
            _E10_3 = Nothing
            _E10_4 = Nothing
            _E11_1 = Nothing
            _E11_2 = Nothing
            _E11_3 = Nothing
            _E11_4 = Nothing
            _Encontrado = False
        End If
        cn.Close()
        dt.Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE ClsInspeccionPruebas SET ref_a�o = @ref_a�o, ref_comite = @ref_comite, ref_consecutivo = @ref_consecutivo, ref_regreso = @ref_regreso, ref_traspaso = @ref_traspaso, E1_1 = @E1_1, E1_2 = @E1_2, E2_1 = @E2_1, E2_2 = @E2_2, E2_3 = @E2_3, E2_4 = @E2_4, E2_5 = @E2_5, E3_1 = @E3_1, E3_2 = @E3_2, E3_3 = @E3_3, E4_1 = @E4_1, E4_2 = @E4_2, E4_3 = @E4_3, E4_4 = @E4_4, E5_1 = @E5_1, E6_1 = @E6_1, E6_2 = @E6_2, E6_3 = @E6_3, E6_4 = @E6_4, E6_5 = @E6_5, E6_6 = @E6_6, E7_1 = @E7_1, E7_2 = @E7_2, E7_3 = @E7_3, E7_4 = @E7_4, E7_5 = @E7_5, E8_1 = @E8_1, E8_2 = @E8_2, E9_1 = @E9_1, E9_2 = @E9_2, E10_1 = @E10_1, E10_2 = @E10_2, E10_3 = @E10_3, E10_4 = @E10_4, E11_1 = @E11_1, E11_2 = @E11_2, E11_3 = @E11_3, E11_4 = @E11_4, Where ( = @)"
        cmd.Parameters.Add("@ref_a�o", SqlDbType.NVarChar, 4, "_ref_a�o")
        cmd.Parameters.Add("@ref_comite", SqlDbType.NVarChar, 50, "_ref_comite")
        cmd.Parameters.Add("@ref_consecutivo", SqlDbType.NVarChar, 4, "_ref_consecutivo")
        cmd.Parameters.Add("@ref_regreso", "_ref_regreso")
        cmd.Parameters.Add("@ref_traspaso", "_ref_traspaso")
        cmd.Parameters.Add("@E1_1", "_E1_1")
        cmd.Parameters.Add("@E1_2", "_E1_2")
        cmd.Parameters.Add("@E2_1", "_E2_1")
        cmd.Parameters.Add("@E2_2", "_E2_2")
        cmd.Parameters.Add("@E2_3", "_E2_3")
        cmd.Parameters.Add("@E2_4", "_E2_4")
        cmd.Parameters.Add("@E2_5", "_E2_5")
        cmd.Parameters.Add("@E3_1", "_E3_1")
        cmd.Parameters.Add("@E3_2", "_E3_2")
        cmd.Parameters.Add("@E3_3", "_E3_3")
        cmd.Parameters.Add("@E4_1", "_E4_1")
        cmd.Parameters.Add("@E4_2", "_E4_2")
        cmd.Parameters.Add("@E4_3", "_E4_3")
        cmd.Parameters.Add("@E4_4", "_E4_4")
        cmd.Parameters.Add("@E5_1", "_E5_1")
        cmd.Parameters.Add("@E6_1", "_E6_1")
        cmd.Parameters.Add("@E6_2", "_E6_2")
        cmd.Parameters.Add("@E6_3", "_E6_3")
        cmd.Parameters.Add("@E6_4", "_E6_4")
        cmd.Parameters.Add("@E6_5", "_E6_5")
        cmd.Parameters.Add("@E6_6", "_E6_6")
        cmd.Parameters.Add("@E7_1", "_E7_1")
        cmd.Parameters.Add("@E7_2", "_E7_2")
        cmd.Parameters.Add("@E7_3", "_E7_3")
        cmd.Parameters.Add("@E7_4", "_E7_4")
        cmd.Parameters.Add("@E7_5", "_E7_5")
        cmd.Parameters.Add("@E8_1", "_E8_1")
        cmd.Parameters.Add("@E8_2", "_E8_2")
        cmd.Parameters.Add("@E9_1", "_E9_1")
        cmd.Parameters.Add("@E9_2", "_E9_2")
        cmd.Parameters.Add("@E10_1", "_E10_1")
        cmd.Parameters.Add("@E10_2", "_E10_2")
        cmd.Parameters.Add("@E10_3", "_E10_3")
        cmd.Parameters.Add("@E10_4", "_E10_4")
        cmd.Parameters.Add("@E11_1", "_E11_1")
        cmd.Parameters.Add("@E11_2", "_E11_2")
        cmd.Parameters.Add("@E11_3", "_E11_3")
        cmd.Parameters.Add("@E11_4", SqlDbType.NVarChar, 10, "_E11_4")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String

        Dim cmd As New SqlCommand
        cmd.CommandText = "SP_P_Inspeccion_Pruebas"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        If cn.State = 1 Then cn.Close()
        cn.Open()

        cmd.Parameters.Add("@ref_a�o", _ref_a�o)
        cmd.Parameters.Add("@ref_comite", _ref_comite)
        cmd.Parameters.Add("@ref_consecutivo", _ref_consecutivo)
        cmd.Parameters.Add("@ref_regreso", _ref_regreso)
        cmd.Parameters.Add("@ref_traspaso", _ref_traspaso)
        cmd.Parameters.Add("@E1_1", _E1_1)
        cmd.Parameters.Add("@E1_2", _E1_2)
        cmd.Parameters.Add("@E2_1", _E2_1)
        cmd.Parameters.Add("@E2_2", _E2_2)
        cmd.Parameters.Add("@E2_3", _E2_3)
        cmd.Parameters.Add("@E2_4", _E2_4)
        cmd.Parameters.Add("@E2_5", _E2_5)
        cmd.Parameters.Add("@E3_1", _E3_1)
        cmd.Parameters.Add("@E3_2", _E3_2)
        cmd.Parameters.Add("@E3_3", _E3_3)
        cmd.Parameters.Add("@E4_1", _E4_1)
        cmd.Parameters.Add("@E4_2", _E4_2)
        cmd.Parameters.Add("@E4_3", _E4_3)
        cmd.Parameters.Add("@E4_4", _E4_4)
        cmd.Parameters.Add("@E5_1", _E5_1)
        cmd.Parameters.Add("@E6_1", _E6_1)
        cmd.Parameters.Add("@E6_2", _E6_2)
        cmd.Parameters.Add("@E6_3", _E6_3)
        cmd.Parameters.Add("@E6_4", _E6_4)
        cmd.Parameters.Add("@E6_5", _E6_5)
        cmd.Parameters.Add("@E6_6", _E6_6)
        cmd.Parameters.Add("@E7_1", _E7_1)
        cmd.Parameters.Add("@E7_2", _E7_2)
        cmd.Parameters.Add("@E7_3", _E7_3)
        cmd.Parameters.Add("@E7_4", _E7_4)
        cmd.Parameters.Add("@E7_5", _E7_5)
        cmd.Parameters.Add("@E8_1", _E8_1)
        cmd.Parameters.Add("@E8_2", _E8_2)
        cmd.Parameters.Add("@E9_1", _E9_1)
        cmd.Parameters.Add("@E9_2", _E9_2)
        cmd.Parameters.Add("@E10_1", _E10_1)
        cmd.Parameters.Add("@E10_2", _E10_2)
        cmd.Parameters.Add("@E10_3", _E10_3)
        cmd.Parameters.Add("@E10_4", _E10_4)
        cmd.Parameters.Add("@E11_1", _E11_1)
        cmd.Parameters.Add("@E11_2", _E11_2)
        cmd.Parameters.Add("@E11_3", _E11_3)
        cmd.Parameters.Add("@E11_4", _E11_4)
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    '''''''''''''''''Funcion que nos permite llenar un combo
    Public Function LlenaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "nombre del store"
        cmd.Connection = cn
        cmd.Parameters.Add("@parametro", "_parametro")
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("clsempleados")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return ex
        End Try
    End Function
End Class

