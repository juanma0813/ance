Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' La informaci�n general de un ensamblado se controla mediante el siguiente
' conjunto de atributos. Cambie estos atributos para modificar la informaci�n
' asociada con un ensamblado.

' Revisar los valores de los atributos del ensamblado

<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'El siguiente GUID sirve como identificador de la biblioteca de tipos si este proyecto se expone a COM
<Assembly: Guid("9152E065-8186-4B55-A3D5-C2E9FFB29740")> 

' La informaci�n de versi�n de un ensamblado consta de los siguientes cuatro valores:
'
'      Versi�n principal
'      Versi�n secundaria 
'      Versi�n de compilaci�n
'      Revisi�n
'
' Puede especificar todos los valores o usar los valores predeterminados (n�mero de versi�n de compilaci�n y de revisi�n) 
' usando el s�mbolo '*' como se muestra a continuaci�n:

<Assembly: AssemblyVersion("1.0.*")> 
