Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class clsNodos
    Dim cn As New SqlConnection
    Dim objconexion As New clsConexion.cIsConexion

    Function ListaComite() As DataTable
        'PARA LLECAR LOS COMITES
        'Dim sqlComite As String = "SELECT id_Comite, Descripcion FROM C_Comite ORDER BY Cve_Comite ASC"
        Dim sqlComite As String = "SELECT ID_Comite, Descripcion, Responsable FROM C_Comite ORDER BY ID_Comite ASC"
        Dim dsComite As New DataSet
        'Try
        Dim daComite As New SqlDataAdapter(sqlComite, cn)
        daComite.Fill(dsComite, "C_Comite")
        'Catch
        '   Return Nothing
        '  End Try
        Return dsComite.Tables("C_Comite")
    End Function

    Function ListaCT(ByVal sComite As String) As DataTable
        'PARA LLENAR LOS COMITES T�CNICOS
        'se necesita que se env�e por que Comit� se filtra

        'Dim sqlCT As String = "SELECT Cve_Comite, Cve_Comitetec, Descripcion, Objetivo FROM C_Comitetec WHERE Cve_Comite = '" + sComite + "' ORDER BY Cve_ComiteTec ASC"
        Dim sqlCT As String = "SELECT ID_Comite, ID_CT, Descripcion, Objetivo, Responsable FROM c_CT WHERE ID_Comite = '" + sComite + "' ORDER BY ID_CT ASC"
        Dim dsCT As New DataSet
        Try
            Dim daCT As New SqlDataAdapter(sqlCT, cn)
            daCT.Fill(dsCT, "C_ComiteTec")
        Catch
            Return Nothing
        End Try
        Return dsCT.Tables("C_ComiteTec")
    End Function

    Function ListaSC(ByVal sComite As String, ByVal sCT As String) As DataTable
        'PARA LLENAR LOS SUB T�CNICOS
        'se necesita que se env�e por que Comit� y CT se filtra
        'Dim sqlSC As String = "SELECT Cve_Comite, Cve_Comitetec, Cve_Subcomite, Descripcion, Objetivo FROM C_Subcomite WHERE Cve_Comite = '" + sComite + "' and Cve_ComiteTec='" + sCT + "' ORDER BY Cve_SubComite ASC"
        Dim sqlSC As String = "SELECT ID_Comite, ID_CT, ID_SC, Descripcion, Objetivo, Responsable FROM c_SC WHERE ID_Comite = '" + sComite + "' and ID_CT='" + sCT + "' ORDER BY ID_SC ASC"
        Dim dsSC As New DataSet
        Try
            '''Dim daCT As New SqlDataAdapter(sqlSC, cn)
            '''daCT.Fill(dsSC, "C_SubComite")
            Dim daSC As New SqlDataAdapter(sqlSC, cn)
            daSC.Fill(dsSC, "C_SubComite")
        Catch
            Return Nothing
        End Try
        Return dsSC.Tables("C_SubComite")
    End Function

    Function ListaGT(ByVal sComite As String, ByVal sCT As String, ByVal sSC As String) As DataTable
        'PARA LLENAR LOS GRUPOS DE TRABAJO
        'se necesita que se env�e por que Comit�, CT y SC se filtra
        'Dim sqlGT As String = "SELECT Cve_Comite, Cve_Comitetec, Cve_Subcomite, Cve_Grupo, Descripcion, Objetivo FROM C_GruposTrabajo WHERE Cve_Comite = '" + sComite + "' and cve_ComiteTec='" + sCT + "' and cve_SubComite='" + sSC + "' ORDER BY Cve_Grupo ASC"
        Dim sqlGT As String = "SELECT ID_Comite, ID_CT, ID_SC, ID_Grupo, Descripcion, Objetivo, Responsable FROM c_Gpos_Trabajos WHERE ID_Comite = '" + sComite + "' and ID_CT='" + sCT + "' and ID_SC='" + sSC + "' ORDER BY ID_Grupo ASC"
        Dim dsGT As New DataSet
        Try
            '''Dim daCT As New SqlDataAdapter(sqlGT, cn)
            '''daCT.Fill(dsGT, "C_GruposTrabajo")
            Dim daGT As New SqlDataAdapter(sqlGT, cn)
            daGT.Fill(dsGT, "C_GruposTrabajo")
        Catch
            Return Nothing
        End Try
        Return dsGT.Tables("C_GruposTrabajo")
    End Function

    ''''se deshabilita el SGT
    '''Function ListaSGT(ByVal sComite As String, ByVal sCT As String, ByVal sSC As String, ByVal sGT As String) As DataTable
    '''    'PARA LLENAR LOS GRUPOS DE TRABAJO
    '''    'se necesita que se env�e por que Comit�, CT, SC y GT se filtra
    '''    'Dim sqlGT As String = "SELECT Cve_Comite, Cve_Comitetec, Cve_Subcomite, Cve_Grupo, Descripcion, Objetivo FROM C_GruposTrabajo WHERE Cve_Comite = '" + sComite + "' and cve_ComiteTec='" + sCT + "' and cve_SubComite='" + sSC + "' ORDER BY Cve_Grupo ASC"
    '''    Dim sqlSGT As String = "SELECT ID_Comite, ID_CT, ID_SC, ID_Grupo, ID_SGT, Descripcion, Objetivo, Responsable FROM C_SGT WHERE ID_Comite = '" + sComite + "' and ID_CT='" + sCT + "' and ID_SC='" + sSC + "' and ID_Grupo='" + sGT + "' ORDER BY ID_SGT ASC"
    '''    Dim dsSGT As New DataSet
    '''    Try
    '''        Dim daSGT As New SqlDataAdapter(sqlSGT, cn)
    '''        daSGT.Fill(dsSGT, "C_SGT")
    '''    Catch
    '''        Return Nothing
    '''    End Try
    '''    Return dsSGT.Tables("C_SGT")
    '''End Function

    'Public Sub New()
    Public Sub New(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)


        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", Identificador, guser, gpassword)


        '''Dim objconexion1 As New clsConexionArchivo.clsConexionArchivo
        ''''cn.ConnectionString = ("Data source=ance02;initial catalog=dbNormalizacion; user id = admsis; pwd=admynsys")
        '''objconexion1.Conexion(0, "admsis", "admynsys")
        ''''cn.ConnectionString = ("Data source='" + objconexion1.SserverC + "';initial catalog='" + objconexion1.SBaseD + "'; user id = admsis; pwd=admynsys")
        '''cn.ConnectionString = ("Data source= ance02;initial catalog=dbNormaNet; user id = admsis; pwd=admynsys")

    End Sub
End Class
