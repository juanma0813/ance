
     '*****************************************************************************
     '*****************************************************************************
     '                       ESTOS SON LOS CAMPOS LLAVE QUE TIENE LA TABLA
     '              ID_Directorio
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_Directorio Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 24/11/2006 11:16:01 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration


Public Class C_Directorio

     '''''''Declaracion de Variables Privadas
     Private dsC_Directorio AS New DataSet
     Private _ID_Directorio as System.String
     Private _Nombre as System.String
     Private _Empresa as System.String
     Private _Domicilio as System.String
     Private _Telefono as System.String
     Private _Fax as System.String
    Private _Mail As System.String
    Private _Bandera As Integer
    Private _Password As System.String
    Private _Encontrado As Boolean
    Private _PreAnce As Boolean
    Private _PreConance As Boolean
    Private _bError As Boolean
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property ID_Directorio() As System.String
          Get
              Return _ID_Directorio
          End Get
          Set(Value as System.String)
              _ID_Directorio = Value
          End Set
    End Property

    Public Property banderaError() As Boolean
        Get
            Return _bError
        End Get
        Set(ByVal Value As System.Boolean)
            _bError = Value
        End Set
    End Property

    Public Property Nombre() As System.String
        Get
            Return _Nombre
        End Get
        Set(ByVal Value As System.String)
            _Nombre = Value
        End Set
    End Property

    Public Property Empresa() As System.String
        Get
            Return _Empresa
        End Get
        Set(ByVal Value As System.String)
            _Empresa = Value
        End Set
    End Property

    Public Property Domicilio() As System.String
        Get
            Return _Domicilio
        End Get
        Set(ByVal Value As System.String)
            _Domicilio = Value
        End Set
    End Property

    Public Property Telefono() As System.String
        Get
            Return _Telefono
        End Get
        Set(ByVal Value As System.String)
            _Telefono = Value
        End Set
    End Property

    Public Property Fax() As System.String
        Get
            Return _Fax
        End Get
        Set(ByVal Value As System.String)
            _Fax = Value
        End Set
    End Property

    Public Property Mail() As System.String
        Get
            Return _Mail
        End Get
        Set(ByVal Value As System.String)
            _Mail = Value
        End Set
    End Property

    Public Property Password() As System.String
        Get
            Return _Password
        End Get
        Set(ByVal Value As System.String)
            _Password = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property
    Public Property PreAnce() As Boolean
        Get
            Return _PreAnce
        End Get
        Set(ByVal Value As Boolean)
            _PreAnce = Value
        End Set
    End Property
    Public Property PreConance() As Boolean
        Get
            Return _PreConance
        End Get
        Set(ByVal Value As Boolean)
            _PreConance = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        ''Dim Servidor As String
        ''Dim Base As String

        ''sSql = objconexion.Conexion(Identif, Usuario, Password)
        ''cn.ConnectionString = sSql

        ''Servidor = objconexion.SserverC
        ''Base = objconexion.SBaseD
        cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance").ToString)
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal cbo As Object)
        Dim dt As New DataTable("Directorio")
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Directorio"


        cmd.Parameters.Add("@ID_Directorio", _ID_Directorio)
        cmd.Parameters.Add("@Nombre", _Nombre)
        cmd.Parameters.Add("@Empresa", _Empresa)
        cmd.Parameters.Add("@Domicilio", _Domicilio)
        cmd.Parameters.Add("@Telefono", _Telefono)
        cmd.Parameters.Add("@Fax", _Fax)
        cmd.Parameters.Add("@Mail", _Mail)
        cmd.Parameters.Add("@Password", _Password)
        cmd.Parameters.Add("@Bandera", "8")

        If cn.State = 1 Then cn.Close()
        cn.Open()

        Try
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
        Catch ex As Exception
            dt = Nothing
        End Try

        cbo.DisplayMember = "nombre"
        cbo.ValueMember = "id_directorio"
        cbo.DataSource = dt

        Return dt
        ''Dim da As SqlDataAdapter
        ''Dim dt As New DataTable("C_Directorio")
        ''Try

        ''    da = New SqlDataAdapter("Select id_directorio,nombre from c_directorio order by nombre", cn)
        ''    da.Fill(dt)
        ''    cbo.DisplayMember = dt.Columns(1).ColumnName
        ''    cbo.ValueMember = dt.Columns(0).ColumnName
        ''    cbo.DataSource = dt
        ''Catch ex As Exception
        ''    MsgBox(ex.Message)
        ''End Try

        ''Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar()
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM C_Directorio WHERE id_directorio ='" & _ID_Directorio & " '"
        Dim da As New SqlDataAdapter(sSql, cn)

        If cn.State = 1 Then cn.Close()
        cn.Open()

        da.Fill(dsC_Directorio, "C_Encontrado")
        cn.Close()
        If dsC_Directorio.Tables("C_Encontrado").Rows.Count > 0 Then
            _ID_Directorio = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("ID_Directorio")
            _Nombre = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Nombre")
            _Empresa = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Empresa")
            _Domicilio = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Domicilio")
            _Telefono = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Telefono")
            _Fax = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Fax")
            _Mail = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Mail")
            _Password = dsC_Directorio.Tables("C_Encontrado").Rows(0).Item("Password")
            _Encontrado = True
        Else
            _ID_Directorio = ""
            _Nombre = ""
            _Empresa = ""
            _Domicilio = ""
            _Telefono = ""
            _Fax = ""
            _Mail = ""
            _Password = ""
            _Encontrado = False
        End If
        dsC_Directorio.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Directorio"


        cmd.Parameters.Add("@ID_Directorio", _ID_Directorio)
        cmd.Parameters.Add("@Nombre", _Nombre)
        cmd.Parameters.Add("@Empresa", _Empresa)
        cmd.Parameters.Add("@Domicilio", _Domicilio)
        cmd.Parameters.Add("@Telefono", _Telefono)
        cmd.Parameters.Add("@Fax", _Fax)
        cmd.Parameters.Add("@Mail", _Mail)
        cmd.Parameters.Add("@Password", _Password)
        cmd.Parameters.Add("@Bandera", _Bandera)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            banderaError = True
        End Try
    End Function

    Public Function Listar() As DataTable
        Dim dt As New DataTable("Directorio")
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Directorio"


        cmd.Parameters.Add("@ID_Directorio", _ID_Directorio)
        cmd.Parameters.Add("@Nombre", _Nombre)
        cmd.Parameters.Add("@Empresa", _Empresa)
        cmd.Parameters.Add("@Domicilio", _Domicilio)
        cmd.Parameters.Add("@Telefono", _Telefono)
        cmd.Parameters.Add("@Fax", _Fax)
        cmd.Parameters.Add("@Mail", _Mail)
        cmd.Parameters.Add("@Password", _Password)
        cmd.Parameters.Add("@Bandera", _Bandera)

        If cn.State = 1 Then cn.Close()
        cn.Open()

        Try
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
        Catch ex As Exception
            dt = Nothing
        End Try

        Return dt
    End Function

    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "INSERT INTO C_Directorio (Nombre, Empresa, Domicilio, Telefono, Fax, Mail)Password,  VALUES (@Nombre, @Empresa, @Domicilio, @Telefono, @Fax, @Mail)@Password, "
        cmd.Parameters.Add("@ID_Directorio", SqlDbType.NVarChar, 15, "_ID_Directorio")
        cmd.Parameters.Add("@Nombre", SqlDbType.NVarChar, 50, "_Nombre")
        cmd.Parameters.Add("@Empresa", SqlDbType.NVarChar, 100, "_Empresa")
        cmd.Parameters.Add("@Domicilio", SqlDbType.NVarChar, 150, "_Domicilio")
        cmd.Parameters.Add("@Telefono", SqlDbType.NVarChar, 45, "_Telefono")
        cmd.Parameters.Add("@Fax", SqlDbType.NVarChar, 45, "_Fax")
        cmd.Parameters.Add("@Mail", SqlDbType.NVarChar, 60, "_Mail")
        cmd.Parameters.Add("@Password", SqlDbType.NVarChar, 10, "_Password")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function BuscaPresidentes()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        cmd.CommandText = "sp_Directorio"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.Parameters.Add("@preAnce", _PreAnce)
        cmd.Parameters.Add("@preconAnce", _PreConance)
        cmd.Parameters.Add("@bandera", 3)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            dr = cmd.ExecuteReader()
            If dr.Read Then
                Return dr("Nombre")
            End If
        Catch ex As Exception
            Dim ms
            ms = ex.Message()
        End Try
    End Function
End Class
