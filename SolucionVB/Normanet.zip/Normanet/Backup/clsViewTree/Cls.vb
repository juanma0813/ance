Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class cls
    Private cn As New SqlClient.SqlConnection
    Private oConexion As New SqlClient.SqlConnection
    Private objConexion As New clsConexion.cIsConexion
    Private _sReferencia As String

    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)

        oConexion.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\principal.ini", "PRINCIPAL", Usuario, Password)
    End Sub
    Public Property sReferencia()
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value)
            _sReferencia = Value
        End Set
    End Property

    Function ListaComite() As DataTable
        'PARA LLECAR LOS COMITES
        Dim sqlComite As String = "SELECT id_comite, Descripcion FROM C_Comite"
        Dim ds As New DataSet
        Dim adComite As New SqlDataAdapter(sqlComite, oConexion)
        adComite.Fill(ds, "C_Comite")
        Return ds.Tables("C_Comite")
    End Function

    Function ListaCT(ByVal sComite As String) As DataTable
        'PARA LLENAR LOS COMITES T�CNICOS
        'se necesita que se env�e por que Comit� se filtra
        Dim sqlCT As String = "SELECT id_comite, id_ct, Descripcion, Objetivo FROM C_ct WHERE id_comite = '" + sComite + "'"
        Dim ds As New DataSet
        Dim adCT As New SqlDataAdapter(sqlCT, oConexion)
        adCT.Fill(ds, "C_ComiteTec")
        Return ds.Tables("C_ComiteTec")
    End Function

    Function ListaSC(ByVal sComite As String, ByVal sCT As String) As DataTable
        'PARA LLENAR LOS SUB T�CNICOS
        'se necesita que se env�e por que Comit� y SC se filtra
        Dim sqlSC As String = "SELECT id_comite, id_ct, id_sc, Descripcion, Objetivo FROM C_sc WHERE id_comite = '" + sComite + "' and id_ct='" + sCT + "'"
        Dim ds As New DataSet
        Dim adCT As New SqlDataAdapter(sqlSC, oConexion)
        adCT.Fill(ds, "C_SubComite")
        Return ds.Tables("C_SubComite")
    End Function

    Function ListaGT(ByVal sComite As String, ByVal sCT As String, ByVal sSC As String) As DataTable
        'PARA LLENAR LOS GRUPOS DE TRABAJO
        'se necesita que se env�e por que Comit� y SC se filtra
        Dim sqlGT As String = "SELECT id_comite, id_ct, id_sc, id_grupo, Descripcion, Objetivo FROM C_Gpos_Trabajos WHERE id_comite = '" + sComite + "' and id_ct='" + sCT + "' and id_sc='" + sSC + "'"
        Dim ds As New DataSet
        Dim adCT As New SqlDataAdapter(sqlGT, oConexion)
        adCT.Fill(ds, "C_GruposTrabajo")
        Return ds.Tables("C_GruposTrabajo")
    End Function
    Function ListaPNN(ByVal sStatus As String) As DataTable
        'PARA LLECAR LOS Planes Nacionales de Normalizacion
        Try
            Dim sSel As String
            sSel = "SELECT * FROM P_plan order by id_plan "
            If sStatus <> "" Then sSel = sSel + "where status=" + sStatus
            Dim sqlComite As String = sSel
            Dim ds As New DataSet
            Dim adPNN As New SqlDataAdapter(sqlComite, oConexion)
            adPNN.Fill(ds, "P_PNN")
            Return ds.Tables("P_PNN")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Function

    Function ListaDprog(ByVal sClave As String) As DataTable
        'PARA LLENAR LOS Planes Nacionales de Normalizacion
        Dim sSel As String
        sSel = "SELECT id_plan, id_tema, titulo FROM P_Prog_Trab where P_Prog_Trab.id_etapa <> 10 and P_Prog_Trab.id_etapa <> 11 "
        If sClave <> "" Then sSel = sSel + "and P_Prog_Trab.id_plan='" + sClave + "' and P_Prog_Trab.id_etapa <> '0' "
        sSel &= " order by P_Prog_Trab.id_tema"
        Dim cmd As New SqlCommand(sSel, oConexion)
        Dim addpy As SqlDataAdapter
        'Dim sqlComite As String = sSel
        Dim ds As New DataSet
        'Dim addpy As New SqlDataAdapter(sqlComite, oConexion)
        addpy = New SqlDataAdapter(cmd)
        addpy.Fill(ds, "D_Proyecto")
        Return ds.Tables("D_Proyecto")
    End Function
    Function ListaTemasProy(ByVal sClave As String)
        Dim sSel As String

        'Modificaci�n por MMendoza 03/10/2008
        '   -Se agregaron 15 dias a la fecha limite de comentarios para poder agregarlos
        sSel = "SELECT  dbo.P_Prog_Trab.Id_Plan, dbo.P_Prog_Trab.Id_Tema, dbo.P_Prog_Trab.Titulo"
        sSel = sSel + " FROM  dbo.P_Prog_Trab INNER JOIN"
        sSel = sSel + " dbo.P_Avance_Temas_Fechas ON dbo.P_Prog_Trab.Id_Plan = dbo.P_Avance_Temas_Fechas.Id_Plan AND "
        sSel = sSel + "  dbo.P_Prog_Trab.Id_Tema = dbo.P_Avance_Temas_Fechas.Id_Tema"
        sSel = sSel + "  WHERE    dbo.P_Prog_Trab.ID_etapa = '4' AND dbo.P_Prog_Trab.Id_Plan = '" & sClave & "' AND "
        sSel = sSel + " dbo.P_Avance_Temas_Fechas.F_Publicacion_ComentarioPublico <= '" & Format(Now.Today, "dd/MM/yyyy") & "' AND "
        sSel = sSel + " dbo.P_Avance_Temas_Fechas.F_Limite_ComentarioPublico+15 >= '" & Format(Now.Today, "dd/MM/yyyy") & "'"
        sSel = sSel + " and status <> 10 and status <> 11"
        sSel = sSel + " ORDER BY dbo.P_Prog_Trab.Id_Tema ASC"

        Dim sqlComite As String = sSel
        Dim ds As New DataSet
        Dim addpy As New SqlDataAdapter(sqlComite, oConexion)
        addpy.Fill(ds, "D_Temas")
        Return ds.Tables("D_Temas")
    End Function
    Function ListaTemasProcAlter(ByVal sClave As String)
        Dim sSel As String

        sSel = "   SELECT     dbo.P_Prog_Trab.Id_Plan, dbo.P_Prog_Trab.Id_Tema, dbo.P_Prog_Trab.Titulo"
        sSel = sSel + " FROM dbo.P_Prog_Trab INNER JOIN"
        sSel = sSel + " dbo.P_Procedimiento_Alternativo ON dbo.P_Prog_Trab.Id_Plan = dbo.P_Procedimiento_Alternativo.Id_Plan AND "
        sSel = sSel + " dbo.P_Prog_Trab.Id_Tema = dbo.P_Procedimiento_Alternativo.Id_tema"
        sSel = sSel + " WHERE     dbo.P_Prog_Trab.ID_etapa = '2' AND dbo.P_Prog_Trab.Id_Plan = '" & sClave & "' AND "
        sSel = sSel + " dbo.P_Procedimiento_Alternativo.F_Inicio_Comentarios <= '" & Format(Now.Today, "dd/MM/yyyy") & "' AND dbo.P_Procedimiento_Alternativo.F_Fin_Comentarios+15 >='" & Format(Now.Today, "dd/MM/yyyy") & "'"
        sSel = sSel + " and status <> 10 and status <> 11"
        sSel = sSel + " ORDER BY dbo.P_Prog_Trab.Id_Tema ASC"

        Dim sqlComite As String = sSel
        Dim ds As New DataSet
        Dim addpy As New SqlDataAdapter(sqlComite, oConexion)
        addpy.Fill(ds, "D_Temas")
        Return ds.Tables("D_Temas")
    End Function
    Function Temas_Resolucion_Proy(ByVal sClave As String)
        Dim sSel As String

        ''sSel = "SELECT  dbo.P_Prog_Trab.Id_Plan, dbo.P_Prog_Trab.Id_Tema, dbo.P_Prog_Trab.Titulo"
        ''sSel = sSel + " FROM  dbo.P_Prog_Trab INNER JOIN"
        ''sSel = sSel + " dbo.P_Avance_Temas_Fechas ON dbo.P_Prog_Trab.Id_Plan = dbo.P_Avance_Temas_Fechas.Id_Plan AND "
        ''sSel = sSel + "  dbo.P_Prog_Trab.Id_Tema = dbo.P_Avance_Temas_Fechas.Id_Tema"
        ''sSel = sSel + "  WHERE    dbo.P_Prog_Trab.ID_etapa = '2' AND dbo.P_Prog_Trab.Id_Plan = '" & sClave & "' AND "
        ''sSel = sSel + " dbo.P_Avance_Temas_Fechas.F_Publicacion_ComentarioPublico <= '" & Format(Now.Today, "dd/MM/yyyy") & "' AND "
        ''sSel = sSel + " dbo.P_Avance_Temas_Fechas.F_Limite_ComentarioPublico <= '" & Format(Now.Today, "dd/MM/yyyy") & "'"
        sSel = "SELECT     P_Procedimiento_Alternativo.Id_Plan, P_Procedimiento_Alternativo.Id_tema, P_Procedimiento_Alternativo.F_Inicio_Comentarios, "
        sSel = sSel + " P_Procedimiento_Alternativo.F_Fin_Comentarios, P_Procedimiento_Alternativo.Status, P_Prog_Trab.ID_etapa "
        sSel = sSel + " FROM P_Procedimiento_Alternativo INNER JOIN"
        sSel = sSel + " P_Prog_Trab ON P_Procedimiento_Alternativo.Id_tema = P_Prog_Trab.Id_Tema AND P_Procedimiento_Alternativo.Id_Plan = P_Prog_Trab.Id_Plan"
        sSel = sSel + " where Id_etapa = '2' "
        sSel = sSel + " and f_fin_comentarios <= getdate()"
        Dim sqlComite As String = sSel
        Dim ds As New DataSet
        Dim addpy As New SqlDataAdapter(sqlComite, oConexion)
        addpy.Fill(ds, "D_Temas")
        Return ds.Tables("D_Temas")
    End Function

    Public Function ResolucionProy(ByVal sClave As String, ByVal Ban As Integer, ByVal Id_Etapa As Integer) As DataTable
        Dim cmd As New SqlCommand
        Dim dt As New DataTable("Temas")
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = oConexion
        cmd.CommandText = "pawProgTrab"
        cmd.Parameters.Add("@ban", Ban)
        cmd.Parameters.Add("@Etapa", Id_Etapa)
        cmd.Parameters.Add("@Id_Plan", sClave)

        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)

        cmd.Dispose()
        da.Dispose()

        Return dt
    End Function

    Function Temas_Resolucion_Alter(ByVal sClave As String)
        Dim sSel As String

        sSel = " SELECT     dbo.P_Prog_Trab.Id_Plan, dbo.P_Prog_Trab.Id_Tema, dbo.P_Prog_Trab.Titulo"
        sSel = sSel + " FROM dbo.P_Prog_Trab INNER JOIN"
        sSel = sSel + " dbo.P_Procedimiento_Alternativo ON dbo.P_Prog_Trab.Id_Plan = dbo.P_Procedimiento_Alternativo.Id_Plan AND "
        sSel = sSel + " dbo.P_Prog_Trab.Id_Tema = dbo.P_Procedimiento_Alternativo.Id_tema"
        sSel = sSel + " WHERE     dbo.P_Prog_Trab.ID_etapa = '2' AND dbo.P_Prog_Trab.Id_Plan = '" & sClave & "' AND "
        sSel = sSel + " dbo.P_Procedimiento_Alternativo.F_Inicio_Comentarios <= '" & Format(Now.Today, "dd/MM/yyyy") & "' AND dbo.P_Procedimiento_Alternativo.F_Fin_Comentarios <='" & Format(Now.Today, "dd/MM/yyyy") & "'"



        Dim sqlComite As String = sSel
        Dim ds As New DataSet
        Dim addpy As New SqlDataAdapter(sqlComite, oConexion)
        addpy.Fill(ds, "D_Temas")
        Return ds.Tables("D_Temas")

    End Function
End Class

