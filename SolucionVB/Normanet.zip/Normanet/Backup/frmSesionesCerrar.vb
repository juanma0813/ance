Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections


Public Class FrmSesionesCerrar
    Inherits System.Windows.Forms.Form
    Private oVista As DataView
    Dim dvComite As DataView
    Dim dvCT As DataView
    Dim dvC As DataView
    Dim dvGT As DataView
    Dim DTRes As New DataTable ''' datos editables para restaurar
    Dim DTResTem As New DataTable ''' datos editables para restaurar
    Dim DTResArch As New DataTable ''' datos editables para restaurar

    '''''     Otras Variables
    Dim existe, Accion As Boolean
    Dim ValEditar As Integer
    Dim sError, iEditar, sValTreeView, sFechaPk, shoraiPk, shoratPk, sReubica As String
    Dim sesion, i, solicitud, istasol, istasesion As Integer

    '''''     dll's

    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objsalas As New Cls_Salas.Cls_Salas("EXTRA", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents GridSesiones As System.Windows.Forms.DataGrid
    Friend WithEvents lblGridSesiones As System.Windows.Forms.Label
    Friend WithEvents Lblcounttemas As System.Windows.Forms.Label
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmSesionesCerrar))
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.GridSesiones = New System.Windows.Forms.DataGrid
        Me.lblGridSesiones = New System.Windows.Forms.Label
        Me.Lblcounttemas = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        CType(Me.GridSesiones, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblcomite.Location = New System.Drawing.Point(8, 8)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(129, 16)
        Me.Lblcomite.TabIndex = 89
        Me.Lblcomite.Text = "Comite SeleccioNAdo: "
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 386)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(666, 62)
        Me.tlbBotonera.TabIndex = 87
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 24)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 15)
        Me.LblTreeView.TabIndex = 88
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'tvComites
        '
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 48)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = 1
        Me.tvComites.Size = New System.Drawing.Size(232, 336)
        Me.tvComites.TabIndex = 86
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'GridSesiones
        '
        Me.GridSesiones.CaptionVisible = False
        Me.GridSesiones.DataMember = ""
        Me.GridSesiones.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GridSesiones.Location = New System.Drawing.Point(248, 48)
        Me.GridSesiones.Name = "GridSesiones"
        Me.GridSesiones.Size = New System.Drawing.Size(408, 336)
        Me.GridSesiones.TabIndex = 90
        '
        'lblGridSesiones
        '
        Me.lblGridSesiones.AutoSize = True
        Me.lblGridSesiones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGridSesiones.Location = New System.Drawing.Point(248, 24)
        Me.lblGridSesiones.Name = "lblGridSesiones"
        Me.lblGridSesiones.Size = New System.Drawing.Size(61, 16)
        Me.lblGridSesiones.TabIndex = 91
        Me.lblGridSesiones.Text = "Sesiones: "
        '
        'Lblcounttemas
        '
        Me.Lblcounttemas.AutoSize = True
        Me.Lblcounttemas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblcounttemas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Lblcounttemas.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.Lblcounttemas.Location = New System.Drawing.Point(352, 24)
        Me.Lblcounttemas.Name = "Lblcounttemas"
        Me.Lblcounttemas.Size = New System.Drawing.Size(12, 18)
        Me.Lblcounttemas.TabIndex = 92
        Me.Lblcounttemas.Text = "0"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(744, 104)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 93
        Me.TextBox1.Text = "TextBox1"
        '
        'FrmSesionesCerrar
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(666, 448)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Lblcounttemas)
        Me.Controls.Add(Me.lblGridSesiones)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.GridSesiones)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.tvComites)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmSesionesCerrar"
        Me.Text = "Sesiones por Cerrar"
        CType(Me.GridSesiones, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "  Metodos y Procesos"

#Region "Sub  Regresa_path, Metodos y Procesos"

    Public Function Regresa_Path(ByVal lblarray As Array) As String

        Select Case UCase(Mid(lblarray(lblarray.Length - 1), 1, 2))
            Case "CT"
                Return lblarray(0) + " \ " + lblarray(1) + " \ NA \ NA"

            Case "SC"
                Select Case lblarray.Length
                    Case 2
                        Return lblarray(0) + " \ NA \ " + lblarray(1) + " \ NA"
                    Case 3
                        Return lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ NA"
                End Select
            Case "GT"
                Select Case lblarray.Length
                    Case 2
                        Return lblarray(0) + " \ NA \ NA \ " + lblarray(1)
                    Case 3
                        If UCase(Mid(lblarray(1), 1, 2)) = "CT" Then
                            Return lblarray(0) + " \ " + lblarray(1) + " \ NA \ " + lblarray(2)
                        ElseIf UCase(Mid(lblarray(1), 1, 2)) = "SC" Then
                            Return lblarray(0) + " \ NA \ " + lblarray(1) + " \ " + lblarray(2)
                        End If
                    Case 4
                        Return lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ " + lblarray(3)
                End Select
            Case ""
                Return "NA \ NA \ NA \ NA"
            Case Else
                Select Case lblarray.Length
                    Case 0
                        Return "NA \ NA \ NA \ NA"
                    Case 1
                        Return lblarray(0) + " \ NA \ NA \ NA"
                    Case Else
                        Dim regresai As String
                        Dim i As Integer
                        For i = 0 To lblarray.Length - 2
                            If i = 0 Then regresai = lblarray(0) Else regresai = regresai + " \ " + lblarray(i)
                        Next
                        Return Regresa_Path(Split(regresai, " \ "))
                End Select

        End Select
    End Function

#End Region

#Region " Function - Sesiones(comite, CT, SC, grupo),  Metodos y Procesos"

    Public Function Sesiones(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String) As DataTable
        Dim din, din1, din2 As DateTime
        din = CDate(Now)
        If Weekday(din, FirstDayOfWeek.Monday) = 1 Then
            din1 = din.AddDays(-7)
            din2 = din
        ElseIf Weekday(din, FirstDayOfWeek.Tuesday) = 1 Then
            din1 = din.AddDays(-7)
            din2 = din
        ElseIf Weekday(din, FirstDayOfWeek.Wednesday) = 1 Then
            din1 = din.AddDays(-7)
            din2 = din
        ElseIf Weekday(din, FirstDayOfWeek.Thursday) = 1 Then
            din1 = din.AddDays(-7)
            din2 = din
        ElseIf Weekday(din, FirstDayOfWeek.Friday) = 1 Then
            din1 = din.AddDays(-5)
            din2 = din
        ElseIf Weekday(din, FirstDayOfWeek.Saturday) = 1 Then
            din1 = din.AddDays(-6)
            din2 = din
        ElseIf Weekday(din, FirstDayOfWeek.Sunday) = 1 Then
            din1 = din.AddDays(-7)
            din2 = din
        End If
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columNA As DataColumn
        Dim combotable As DataTable
        objsesiones.Id_Comite = comite
        objsesiones.Id_CT = CT
        objsesiones.Id_SC = SC
        objsesiones.Id_Grupo = grupo
        objsesiones.HoraI = din1
        objsesiones.HoraT = din2
        objsesiones.Bandera = 11
        combotable = objsesiones.Listar
        If grupo.Trim <> "NA" Then
            comite = grupo.Trim
        ElseIf SC.Trim <> "NA" Then
            comite = SC.Trim
        ElseIf CT.Trim <> "NA" Then
            comite = CT.Trim
        End If
        combotable.Columns.Add("Numero")
        iNumero = 0
        For Each regs In combotable.Rows
            iNumero = iNumero + 1
            'combotable.Rows(iNumero - 1).Item("Numero") = iNumero.ToString + "/" + Format$(regs("Fecha"), "yy") + " " + comite.Trim 
            combotable.Rows(iNumero - 1).Item("Numero") = Format(combotable.Rows(iNumero - 1).Item(2), "dd/MM/yyyy") & " " & comite.Trim
        Next

        Return combotable

    End Function

#End Region

#Region " Function - validagrid(casos, fila),  Metodos y Procesos"

    Private Function validagrid(ByVal casos As String, ByVal fil As Integer) As Boolean
        Dim acasos As Array = Split(casos, " ")
        Dim i As Integer
        Dim valreturn As Boolean = True
        ErrorProvider1.SetError(lblGridSesiones, "")
        ErrorProvider1.SetError(Lblcomite, "")
        Select Case acasos(0)
            Case "comites"
                If LblTreeView.Text.Length <= 0 Then
                    ErrorProvider1.SetError(Lblcomite, "Debes seleccioNAr un Comite")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblcomite, "")
                End If
            Case "sesiones"
                Dim sReunion = (IIf(IsDBNull(GridSesiones.Item(fil, 1)), "", GridSesiones.Item(fil, 1)))
                Dim sfecha = (IIf(IsDBNull(GridSesiones.Item(fil, 0)), CDate("01/01/1900"), GridSesiones.Item(fil, 0)))
                For i = 1 To acasos.Length - 1
                    Select Case acasos(i)
                        Case "1"
                            If sfecha = CDate("01/01/1900") Then
                                ErrorProvider1.SetError(lblGridSesiones, "Debes seleccioNAr uNA linea con datos")
                                valreturn = False
                            End If
                        Case "2"
                            If sReunion = "" Then
                                ErrorProvider1.SetError(lblGridSesiones, "Debes seleccioNAr uNA linea con datos")
                                valreturn = False
                            End If
                        Case "3"
                            Dim sverifica
                            If GridSesiones.Item(fil, 3) Is System.DBNull.Value Then sverifica = (1) Else sverifica = IIf(GridSesiones.Item(fil, 3), 1, 0)
                            If sverifica = 0 Then
                                ErrorProvider1.SetError(lblGridSesiones, "Debes activar o desactivar la casilla, en la columNA de Activar" + Chr(13) + Chr(13) + "En la linea " + CStr(fil + 1) + ".")
                                valreturn = False
                            End If
                    End Select
                Next
        End Select
        Return valreturn
    End Function

#End Region

#Region "Funci�n - guardar(), Metodos y Procesos"

    Public Function guardar() As Boolean
        Dim slineas As String
        Dim dr As DataRow
        DTTemas = GridSesiones.DataSource()
        If DTTemas.Rows.Count > 0 Then

            Try
                For Each dr In DTTemas.Rows
                    With objsesiones
                        If IIf(IsDBNull(dr(5)), 1, dr(5)) = 1 Then
                            .Descripcion = dr(4)
                            .Id_Sesion = dr(0)
                            .Status = .id_status_sesion
                            .Bandera = 5
                            Try
                                Accion = .Insertar()
                            Catch ex As Exception When Accion = False
                                MsgBox("Error G002 - Al intentar actualizar o leer el  Registro de Sesiones..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                Restaurar("sesiones")
                                Return False
                            End Try
                        End If
                    End With
                Next
            Catch ex As Exception
                MsgBox("Error G003 - Al intentar guardar Registro de Sesiones..." + ex.Message, MsgBoxStyle.Critical)
                Return False
            End Try
            Return True

        End If
    End Function

#End Region

#Region " Funcion - Restaurar(sAccion), Metodos y Procesos"

    Public Function Restaurar(ByVal sAccion As String) As Boolean
        Dim dr As DataRow
        For Each dr In DTResTem.Rows
            existe = False
            With objsesiones
                If Not existe And IIf(IsDBNull(dr(5)), 0, dr(5)) = 1 Then
                    .Descripcion = dr(4)
                    .Bandera = 15
                    .Buscar()
                    .Id_Sesion = dr(0)
                    .Status = .id_status_sesion
                    .Bandera = 5
                    Try
                        Accion = .Insertar()
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 005R - Al intentar restaurar  Registro de Sesiones..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                        Restaurar("sesiones")
                        Return False
                    End Try
                End If
            End With
        Next
        Return True
    End Function

#End Region

#End Region

#Region " Tree View - TvComites, Metodos y Procesos"

    Private Sub lleNA_ComiteTreeView()
        Cursor.Current = Cursors.WaitCursor

        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode


        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"

            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"

                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"

                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                        If GTAnt <> SCAnt And GTAnt <> CTAnt And GTAnt <> ComiteAnt Then
                            oTablaSs = Sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"))  '********Sesiones GRUPOS DE TRABAJO 
                            If oTablaSs.Rows.Count > 0 Then
                                For Each RegSes In oTablaSs.Rows
                                    Ses = GT.Nodes.Add(RegSes("numero"))
                                    Ses.ImageIndex = 5
                                    Ses.SelectedImageIndex = 5
                                Next
                            End If
                        End If
                    Next 'GT

                    If SCAnt <> CTAnt And SCAnt <> ComiteAnt Then
                        oTablaSs = Sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), "NA")  '********Sesiones Sub Comites 
                        If oTablaSs.Rows.Count > 0 Then
                            For Each RegSes In oTablaSs.Rows
                                Ses = SC.Nodes.Add(RegSes("numero"))
                                Ses.ImageIndex = 5
                                Ses.SelectedImageIndex = 5
                            Next
                        End If
                    End If
sinSC:
                Next 'SC
                If CTAnt <> ComiteAnt Then
                    oTablaSs = Sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), "NA", "NA") '********Sesiones Comites Tecnicos
                    If oTablaSs.Rows.Count > 0 Then
                        For Each RegSes In oTablaSs.Rows '******GRUPOS DE TRABAJO
                            Ses = CT.Nodes.Add(RegSes("numero"))
                            Ses.ImageIndex = 5
                            Ses.SelectedImageIndex = 5
                        Next
                    End If
                End If
sinCT:
            Next 'CT

            oTablaSs = Sesiones(RegComite("ID_Comite"), "NA", "NA", "NA") '********Sesiones Comite
            If oTablaSs.Rows.Count > 0 Then
                For Each RegSes In oTablaSs.Rows
                    Ses = Comite.Nodes.Add(RegSes("numero"))
                    Ses.ImageIndex = 5
                    Ses.SelectedImageIndex = 5
                Next
            End If


sinComite:
        Next 'Comites
        tvComites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvComites.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordeNAdos

        Cursor.Current = Cursors.Default
    End Sub

    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblcomite, "")
        Dim valor_nodo, valor As String
        Dim ivalor As Integer
        Dim array_texto, lblarray As Array
        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione el comite" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")
        If iEditar = "Espera" Or iEditar = "Agregar" Or iEditar = "" Then
            Call Llena_grid("NA", "NA", "NA", "NA", "")
        End If

        array_texto = Nothing
        array_texto = Split(Regresa_Path(lblarray), " \ ")
        Inactivos(GridSesiones)
        If ivalor = 5 Then
            Call Llena_grid(array_texto(0), array_texto(1), array_texto(2), array_texto(3), e.Node.Text)
        Else
            Call Llena_grid(array_texto(0), array_texto(1), array_texto(2), array_texto(3), "")
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " DataGrid - DGSesiones, Metodos y Procesos"

    Public Sub LleNA_grid(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String)
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columNA As DataColumn

        DTTemas = Sesiones(comite, CT, SC, grupo)
        'Instanciamos y creamos nuestro manejador

        Dim cm As CurrencyManager
        cm = CType(BindingContext(DTTemas), CurrencyManager)
        'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyMaNAger
        Dim Dv As DataView = CType(cm.List, DataView)
        'AsigNAmos el valor que deseamos para evitar o permitir nuevos registros
        Dv.AllowNew = False
        If compara.Length > 0 Then Dv.RowFilter = "numero = '" & compara & "'"
        GridSesiones.DataSource = DTTemas
        Lblcounttemas.Text = GridSesiones.VisibleRowCount
    End Sub

    Private Sub Crea_DGSesiones()
        Dim dtcol As DataColumn = Nothing
        Try

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            ts1.MappingName = "clsSesiones"

            Call Tabla_Color(ts1, GridSesiones)
            Dim TextCol As DataGridTextBoxColumn
            TextCol = New DataGridTextBoxColumn
            TextCol.MappingName = "Fecha"
            TextCol.HeaderText = "Fecha"
            TextCol.Format = "dd/MM/yyyy"
            TextCol.Width = 75
            TextCol.TextBox.Enabled = False

            Dim TextCol1 As DataGridTextBoxColumn
            TextCol1 = New DataGridTextBoxColumn
            TextCol1.MappingName = "Asunto"
            TextCol1.HeaderText = "Nombre de Sesi�n"
            TextCol1.Width = 160
            TextCol1.TextBox.Enabled = False



            Dim cbostatus As New DataGridComboBoxColumn(2, GridSesiones)
            cbostatus.MappingName = "Descripcion"
            cbostatus.HeaderText = "Estado"
            cbostatus.Width = 90
            cbostatus.ColumnComboBox.Items.Clear()
            cbostatus.ColumnComboBox.Name = "status"
            objsesiones.Bandera = 12
            objsesiones.ListaCombo(cbostatus.ColumnComboBox)
            cbostatus.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList


            Dim chksesiones As New DataGridBoolColumn
            chksesiones.MappingName = "INActivo"
            chksesiones.HeaderText = "Activar"
            chksesiones.Width = 40
            chksesiones.NullValue = False
            chksesiones.TrueValue = 1
            chksesiones.FalseValue = 0

            'ts1.GridColumnStyles.Add(chksesiones)
            ts1.PreferredRowHeight = cbostatus.ColumnComboBox.Height + 4
            ts1.GridColumnStyles.AddRange(New DataGridColumnStyle() {TextCol, TextCol1, cbostatus, chksesiones})
            GridSesiones.TableStyles.Add(ts1)


        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try

    End Sub

    Private Sub GridSesiones_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridSesiones.CurrentCellChanged
        With GridSesiones
            Dim fila = .CurrentCell.RowNumber
            Dim col = .CurrentCell.ColumnNumber
            Dim nombre = .CurrentCell.GetType.ToString
            ErrorProvider1.SetError(lblGridSesiones, "")
            If col = 3 Then
                If GridSesiones.Item(fila, 3) Is System.DBNull.Value Then
                    ErrorProvider1.SetError(lblGridSesiones, "No has seleccioNAdo aplicar ning�n cambio")
                ElseIf GridSesiones.Item(fila, 3) = 0 Then
                    ErrorProvider1.SetError(lblGridSesiones, "No has seleccioNAdo aplicar ning�n cambio")
                Else
                    Activos(tlbBotonera.Buttons(4))
                End If
            End If
            If col = 2 Then
                Activos(tlbBotonera.Buttons(4))
            End If
        End With

    End Sub

#End Region

#Region " Forms - SesionesCerrar,  Metodos y Procesos"

    Private Sub SesionesCerrar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call llena_ComiteTreeView()
        Call Crea_DGSesiones()
        Call Llena_grid("NA", "NA", "NA", "NA", "")
        Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), GridSesiones)

    End Sub

#End Region

#Region " ToolBar - tlbBotonera,  Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1                   '''----------   Agregar     --------

            Case 2                   '''----------   Edita     --------
                If validagrid("comites", 0) Then
                    DTResTem = GridSesiones.DataSource
                    Activos(tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), GridSesiones)
                    Inactivos(tvComites, tlbBotonera.Buttons(2))
                    iEditar = "Editar"
                End If
            Case 3                   '''----------   Deshacer     --------
                Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), tvComites, GridSesiones)
                DTTemas.Rows.Clear()
                LblTreeView.Text = ""
                tvComites.Nodes.Clear()
                Call llena_ComiteTreeView()
                Activos(tvComites, tlbBotonera.Buttons(2))
                iEditar = Nothing
            Case 4                   '''----------   Guardar     --------
                Try
                    Accion = guardar()
                    tlbBotonera.Focus()
                    If Accion Then
                        Inactivos(tlbBotonera.Buttons(1), tlbBotonera.Buttons(3), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5), GridSesiones)
                        Activos(tvComites, tlbBotonera.Buttons(2))
                        DTTemas.Rows.Clear()
                        tvComites.Nodes.Clear()
                        Call llena_ComiteTreeView()
                        LblTreeView.Text = ""
                        iEditar = Nothing
                    End If

                Catch ex As Exception When Accion = False
                    MsgBox("Error C000  " + Chr(13) + Chr(13) + "Faltan datos en el formulario." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                End Try
            Case 5                   '''----------   ElimiNAr     --------

            Case 7                   '''----------   Salir     --------
                iEditar = "Espera"
                Me.Close()
        End Select

        Cursor.Current = Cursors.Default

    End Sub

#End Region
    Private Sub GridSesiones_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridSesiones.Click

        TextBox1.Focus()
    End Sub
End Class
