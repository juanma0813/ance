Imports System.Windows.Forms
Imports System
Imports System.Data.SqlClient

Public Class Cls_empleados

    ''''     descripcion de las variables
    ''''     Variables de la tabla an_emp
    Private dsAN_EMP As New DataSet
    Private _NUM_EMP As String
    Private _NOMBRE_COMPLETO As String
    Private _NOMP_EMP As String
    Private _AP_PATER As String
    Private _AP_MATER As String
    Private _TITULO As String
    Private _SEXO As String
    Private _F_NAC As String
    Private _NUM_SOLIC As String
    Private _RFC As String
    Private _F_ALTA As String
    Private _F_INGRESO As String
    Private _F_PLANTA As String
    Private _F_BAJA As String
    Private _F_BAJA_RESP As String
    Private _F_BAJA_IMSS As String
    Private _PLAZA As String
    Private _PUESTO As String
    Private _CATEGORIA As String

    ''''     Variables de la AN_TAB_PUEST
    Private dsAN_TAB_PUEST As New DataSet
    Private _NOM_PUESTO As String
    Private _DESCRIPCION As String

    ''''     Variables de la c_empleados
    Private dsC_Empleados As New DataSet
    Private _Nom_Emp As String
    Private _Id_usuario As String
    Private _Extension As String
    Private _Nivel As String
    Private _Dias_Ocupados As Integer
    Private _Grupo As Int32
    Private _Id_Div As Int16
    Private _Id_Area As String
    Private _Email As String
    Private _Id_Sucursal As Int16
    Private _Desc_Sucursal As String

    Private _Firma As Byte
    Private _Rubrica As Byte
    Private _Inactivo As Boolean

    ''''     Variables de la C_Areas
    Private dsC_Areas As New DataSet
    Private _Clave_Div As Int16
    Private _Descripcion_Area As String
    Private _Area_Externa As Boolean
    Private _tipo_direccion As String

    ''''     Variables para la clase de C_Normas_Ingenieros solo se ocupa haste este momento para certificaci�n   
    Private _ID_INGENIERO As Integer
    Private _ANALISTA As Boolean
    Private _SUPERVISOR As Boolean
    Private _NOM_CORTO As String
    Private _EXTERNO As Integer

    Private _Error As String
    Private _Bandera As Int32
    Private _sPath As String
    Private _Password As String
    Private _Id_Sistema As Integer
    Private _Id_Grupo As Integer
    Private _Nombre_Sistema As String
    Private _Nombre_Grupo As String

    Private sSql As String
    ' Conexion 

    Private cn As New SqlConnection
    Private sPath_OCP As String
    Private cn_OCP As New SqlConnection
    Private dr As SqlDataReader

    Dim objConexion As New clsConexion.cIsConexion

    '''''''Declaracion de Propiedades publicas

    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property NOMBRE_COMPLETO() As String
        Get
            Return _NOMBRE_COMPLETO
        End Get
        Set(ByVal Value As String)
            _NOMBRE_COMPLETO = Value
        End Set
    End Property

    '''''     Propiedades de la tabla an_emp

    Public Property NUM_EMP() As String
        Get
            Return _NUM_EMP
        End Get
        Set(ByVal Value As String)
            _NUM_EMP = Value
        End Set
    End Property

    Public Property NOMP_EMP() As String
        Get
            Return _NOMP_EMP
        End Get
        Set(ByVal Value As String)
            _NOMP_EMP = Value
        End Set
    End Property

    Public Property AP_PATER() As String
        Get
            Return _AP_PATER
        End Get
        Set(ByVal Value As String)
            _AP_PATER = Value
        End Set
    End Property

    Public Property AP_MATER() As String
        Get
            Return _AP_MATER
        End Get
        Set(ByVal Value As String)
            _AP_MATER = Value
        End Set
    End Property

    Public Property TITULO() As String
        Get
            Return _TITULO
        End Get
        Set(ByVal Value As String)
            _TITULO = Value
        End Set
    End Property

    Public Property SEXO() As String
        Get
            Return _SEXO
        End Get
        Set(ByVal Value As String)
            _SEXO = Value
        End Set
    End Property

    Public Property F_NAC() As String
        Get
            Return _F_NAC
        End Get
        Set(ByVal Value As String)
            _F_NAC = Value
        End Set
    End Property

    Public Property NUM_SOLIC() As String
        Get
            Return _NUM_SOLIC
        End Get
        Set(ByVal Value As String)
            _NUM_SOLIC = Value
        End Set
    End Property

    Public Property RFC() As String
        Get
            Return _RFC
        End Get
        Set(ByVal Value As String)
            _RFC = Value
        End Set
    End Property

    Public Property F_ALTA() As String
        Get
            Return _F_ALTA
        End Get
        Set(ByVal Value As String)
            _F_ALTA = Value
        End Set
    End Property

    Public Property F_PLANTA() As String
        Get
            Return _F_PLANTA
        End Get
        Set(ByVal Value As String)
            _F_PLANTA = Value
        End Set
    End Property

    Public Property F_BAJA() As String
        Get
            Return _F_BAJA
        End Get
        Set(ByVal Value As String)
            _F_BAJA = Value
        End Set
    End Property

    Public Property F_BAJA_RESP() As String
        Get
            Return _F_BAJA_RESP
        End Get
        Set(ByVal Value As String)
            _F_BAJA_RESP = Value
        End Set
    End Property

    Public Property F_BAJA_IMSS() As String
        Get
            Return _F_BAJA_IMSS
        End Get
        Set(ByVal Value As String)
            _F_BAJA_IMSS = Value
        End Set
    End Property

    Public Property PLAZA() As String
        Get
            Return _PLAZA
        End Get
        Set(ByVal Value As String)
            _PLAZA = Value
        End Set
    End Property

    Public Property CATEGORIA() As String
        Get
            Return _CATEGORIA
        End Get
        Set(ByVal Value As String)
            _CATEGORIA = Value
        End Set
    End Property

    '''''     Propiedades de la tabla c_empleados
    Public Property Nom_Emp() As String
        Get
            Return _Nom_Emp
        End Get
        Set(ByVal Value As String)
            _Nom_Emp = Value
        End Set
    End Property

    Public Property Id_usuario() As String
        Get
            Return _Id_usuario
        End Get
        Set(ByVal Value As String)
            _Id_usuario = Value
        End Set
    End Property

    Public Property Extension() As String
        Get
            Return _Extension
        End Get
        Set(ByVal Value As String)
            _Extension = Value
        End Set
    End Property

    Public Property Nivel() As String
        Get
            Return _Nivel
        End Get
        Set(ByVal Value As String)
            _Nivel = Value
        End Set
    End Property

    Public Property Dias_Ocupados() As Integer
        Get
            Return _Dias_Ocupados
        End Get
        Set(ByVal Value As Integer)
            _Dias_Ocupados = Value
        End Set
    End Property

    Public Property Grupo() As Integer
        Get
            Return _Grupo
        End Get
        Set(ByVal Value As Integer)
            _Grupo = Value
        End Set
    End Property

    Public Property Id_Div() As Integer
        Get
            Return _Id_Div
        End Get
        Set(ByVal Value As Integer)
            _Id_Div = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return _Email
        End Get
        Set(ByVal Value As String)
            _Email = Value
        End Set
    End Property

    Public Property Id_Sucursal() As Integer
        Get
            Return _Id_Sucursal
        End Get
        Set(ByVal Value As Integer)
            _Id_Sucursal = Value
        End Set
    End Property

    Public Property Desc_Sucursal() As String
        Get
            Return _Desc_Sucursal
        End Get
        Set(ByVal Value As String)
            _Desc_Sucursal = Value
        End Set
    End Property
    Public Property F_Ingreso() As String
        Get
            Return _F_INGRESO
        End Get
        Set(ByVal Value As String)
            _F_INGRESO = Value
        End Set
    End Property

    Public Property Inactivo() As Boolean
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value As Boolean)
            _Inactivo = Value
        End Set
    End Property

    Public Property Firma() As Byte
        Get
            Return _Firma
        End Get
        Set(ByVal Value As Byte)
            _Firma = Value
        End Set
    End Property

    Public Property Rubrica() As Byte
        Get
            Return _Rubrica
        End Get
        Set(ByVal Value As Byte)
            _Rubrica = Value
        End Set
    End Property

    '''''     Propiedades de la tabla AN_TAB_PUEST
    Public Property PUESTO() As String
        Get
            Return _PUESTO
        End Get
        Set(ByVal Value As String)
            _PUESTO = Value
        End Set
    End Property

    Public Property NOM_PUESTO() As String
        Get
            Return _NOM_PUESTO
        End Get
        Set(ByVal Value As String)
            _NOM_PUESTO = Value
        End Set
    End Property

    Public Property DESCRIPCION_AREA() As String
        Get
            Return _Descripcion_Area
        End Get
        Set(ByVal Value As String)
            _Descripcion_Area = Value
        End Set
    End Property

    '''''     Propiedades de la tabla C_AREAS
    Public Property ID_Area() As String
        Get
            Return _Id_Area
        End Get
        Set(ByVal Value As String)
            _Id_Area = Value
        End Set
    End Property

    Public Property Clave_Div() As Integer
        Get
            Return _Clave_Div
        End Get
        Set(ByVal Value As Integer)
            _Clave_Div = Value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _DESCRIPCION
        End Get
        Set(ByVal Value As String)
            _DESCRIPCION = Value
        End Set
    End Property

    Public Property Area_Externa() As Boolean
        Get
            Return _Area_Externa
        End Get
        Set(ByVal Value As Boolean)
            _Area_Externa = Value
        End Set
    End Property

    Public Property tipo_direccion() As String
        Get
            Return _tipo_direccion
        End Get
        Set(ByVal Value As String)
            _tipo_direccion = Value
        End Set
    End Property

    Public Property ID_INGENIERO() As Integer
        Get
            Return _ID_INGENIERO
        End Get
        Set(ByVal Value As Integer)
            _ID_INGENIERO = Value
        End Set
    End Property
    Public Property ANALISTA() As Boolean
        Get
            Return _ANALISTA
        End Get
        Set(ByVal Value As Boolean)
            _ANALISTA = Value
        End Set
    End Property

    Public Property SUPERVISOR() As Boolean
        Get
            Return _SUPERVISOR
        End Get
        Set(ByVal Value As Boolean)
            _SUPERVISOR = Value
        End Set
    End Property
    Public Property NOM_CORTO() As String
        Get
            Return _NOM_CORTO
        End Get
        Set(ByVal Value As String)
            _NOM_CORTO = Value
        End Set
    End Property

    Public Property EXTERNO() As Boolean
        Get
            Return _EXTERNO
        End Get
        Set(ByVal Value As Boolean)
            _EXTERNO = Value
        End Set
    End Property

    Public Property Erro() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property

    Public Property Password() As String
        Get
            Return _Password
        End Get
        Set(ByVal Value As String)
            _Password = Value
        End Set
    End Property

    Public Property Id_Sistema() As Integer
        Get
            Return _Id_sistema
        End Get
        Set(ByVal Value As Integer)
            _Id_sistema = Value
        End Set
    End Property

    Public Property Id_Grupo() As Integer
        Get
            Return _Id_Grupo
        End Get
        Set(ByVal Value As Integer)
            _Id_Grupo = Value
        End Set
    End Property

    Public Property Nombre_Sistema() As String
        Get
            Return _Nombre_Sistema
        End Get
        Set(ByVal Value As String)
            _Nombre_Sistema = Value
        End Set
    End Property

    Public Property Nombre_Grupo() As String
        Get
            Return _Nombre_Grupo
        End Get
        Set(ByVal Value As String)
            _Nombre_Grupo = Value
        End Set
    End Property




    Public Overloads Sub Inicializa(ByVal sPath As String, ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        cn.ConnectionString = objConexion.ConexionAnce(sPath, Identificador, guser, gpassword)
        sPath_OCP = sPath
    End Sub
    Public Overloads Sub Inicializa(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "COMUN", guser, gpassword)
    End Sub

    Private Sub llena_parametros(ByVal command As SqlCommand)
        With command
            'llave de c_empleado completo
            .Parameters.Add("@Id_usuario", _Id_usuario)
            .Parameters.Add("@Extension", _Extension)
            .Parameters.Add("@Nivel", _Nivel)
            .Parameters.Add("@Dias_Ocupados", _Dias_Ocupados)
            .Parameters.Add("@Grupo", _Grupo)
            .Parameters.Add("@Id_Div", _Id_Div)
            .Parameters.Add("@Id_Area", _Id_Area)
            .Parameters.Add("@Email", _Email)
            .Parameters.Add("@Id_Sucursal", _Id_Sucursal)
            .Parameters.Add("@NUM_EMP", _NUM_EMP)
            .Parameters.Add("@NOMP_EMP", _NOMP_EMP)
            .Parameters.Add("@AP_PATER", _AP_PATER)
            .Parameters.Add("@AP_MATER", _AP_MATER)
            .Parameters.Add("@RFC", _RFC)
            .Parameters.Add("@NOMBRE_COMPLETO", _NOMBRE_COMPLETO)
            .Parameters.Add("@PUESTO", _PUESTO)
            .Parameters.Add("@CATEGORIA", _CATEGORIA)
            .Parameters.Add("@NOM_PUESTO", _NOM_PUESTO)
            .Parameters.Add("@DESCRIPCION", _Desc_Sucursal)
            .Parameters.Add("@Clave_Div", _Clave_Div)
            .Parameters.Add("@Descripcion_Area", _Descripcion_Area)
            .Parameters.Add("@F_INGRESO", _F_INGRESO)
            .Parameters.Add("@F_BAJA", _F_BAJA)
            .Parameters.Add("@ID_INGENIERO", _ID_INGENIERO)
            .Parameters.Add("@INACTIVO", _Inactivo)
            .Parameters.Add("@EXTERNO", _EXTERNO)
            .Parameters.Add("@Bandera", _Bandera)


            .Parameters.Add("@Id_Sistema", _Id_Sistema)
            .Parameters.Add("@Id_grupo", _Id_Grupo) 'as� es como est� en la tabla
            .Parameters.Add("@Password", _Password)

        End With
    End Sub

    Public Sub ListaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@ID_Usuario", _Id_usuario)
        cmd.Parameters.Add("@ID_Area", _Id_Area)
        cmd.Parameters.Add("@Id_Sistema", _Id_Sistema)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("clsempleados")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return
        End Try
    End Sub

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        If cn.State = ConnectionState.Open Then cn.Close()

        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Buscar"
        cmd.Connection = cn
        llena_parametros(cmd)
        Try
            cn.Open()
            dr = cmd.ExecuteReader

            If dr.Read Then
                _Id_usuario = IIf((IsDBNull(dr("Id_usuario"))), "", dr("Id_usuario"))
                _NOMBRE_COMPLETO = IIf((IsDBNull(dr("nombre"))), "", dr("nombre"))
                _Extension = IIf((IsDBNull(dr("Extension"))), "", dr("Extension"))
                _Nivel = IIf((IsDBNull(dr("Nivel"))), "", dr("Nivel"))
                _Dias_Ocupados = IIf((IsDBNull(dr("Dias_Ocupados"))), "", dr("Dias_Ocupados"))
                _Grupo = IIf((IsDBNull(dr("Grupo"))), 0, dr("Grupo"))
                _Id_Div = IIf((IsDBNull(dr("id_Div"))), 0, dr("id_Div"))
                _Id_Area = IIf((IsDBNull(dr("ID_Area"))), "", dr("ID_Area"))
                _Email = IIf((IsDBNull(dr("Email"))), "", dr("Email"))
                '_Firma = IIf((IsDBNull(dr("Firma"))), 0, dr("Firma")) '*
                '_Rubrica = IIf((IsDBNull(dr("Rubrica"))), 0, dr("Rubrica"))'*
                _Id_Sucursal = IIf((IsDBNull(dr("Id_Sucursal"))), 0, dr("Id_Sucursal"))
                _Desc_Sucursal = IIf((IsDBNull(dr("Sucursal"))), "", dr("Sucursal"))
                _NUM_EMP = IIf((IsDBNull(dr("NUM_EMP"))), "", dr("NUM_EMP"))
                _NOMP_EMP = IIf((IsDBNull(dr("NOMP_EMP"))), "", dr("NOMP_EMP"))
                _AP_PATER = IIf((IsDBNull(dr("AP_PATER"))), "", dr("AP_PATER"))
                _AP_MATER = IIf((IsDBNull(dr("AP_MATER"))), "", dr("AP_MATER"))
                _TITULO = IIf((IsDBNull(dr("TITULO"))), "", dr("TITULO"))
                _SEXO = IIf((IsDBNull(dr("SEXO"))), "", dr("SEXO"))
                _F_NAC = IIf((IsDBNull(dr("F_NAC"))), "", dr("F_NAC"))
                _RFC = IIf((IsDBNull(dr("RFC"))), "", dr("RFC"))
                _F_INGRESO = IIf((IsDBNull(dr("F_INGRESO"))), "", dr("F_INGRESO"))
                _F_BAJA = IIf((IsDBNull(dr("F_BAJA"))), "", dr("F_BAJA"))
                _PUESTO = IIf((IsDBNull(dr("PUESTO"))), "", dr("PUESTO"))
                _CATEGORIA = IIf((IsDBNull(dr("CATEGORIA"))), "", dr("CATEGORIA"))
                _ID_INGENIERO = IIf((IsDBNull(dr("Id_Ingeniero"))), 0, dr("Id_Ingeniero"))
                _Inactivo = IIf((IsDBNull(dr("Inactivo"))), 0, dr("Inactivo"))
                _NOM_CORTO = IIf((IsDBNull(dr("Nom_Corto"))), "", dr("Nom_Corto"))
                _EXTERNO = IIf((IsDBNull(dr("EXTERNO"))), 0, dr("EXTERNO"))
                _Descripcion_Area = IIf((IsDBNull(dr("Descripcion_Area"))), "", dr("Descripcion_Area"))

            Else
                _Id_usuario = ""
                _NOMBRE_COMPLETO = ""
                _Extension = ""
                _Nivel = ""
                _Dias_Ocupados = 0
                _Grupo = 0
                _Id_Div = 0
                _Id_Area = ""
                _Email = ""
                ' _Firma = 0
                ' _Rubrica = 0
                _Id_Sucursal = 0
                _Desc_Sucursal = ""
                _NUM_EMP = ""
                _Nom_Emp = ""
                _AP_PATER = ""
                _AP_MATER = ""
                _TITULO = ""
                _SEXO = ""
                _F_NAC = ""
                _RFC = ""
                _F_INGRESO = ""
                _F_BAJA = ""
                _PUESTO = ""
                _CATEGORIA = ""
                _ID_INGENIERO = 0
                _Inactivo = 0
                _NOM_CORTO = ""
                _EXTERNO = 0
            End If
            cn.Close()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function
    Public Function Valida_Acceso(ByVal sUsuario As String, ByVal id_Sistema As Integer, ByVal sPassword As String) As Boolean
        Dim cmd As New SqlCommand
        If cn.State = ConnectionState.Open Then cn.Close()
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Emp_Buscar"
            .Connection = cn
            .Parameters.Add("@Bandera", 4)
            .Parameters.Add("@Id_Usuario", sUsuario)
            .Parameters.Add("@Id_Sistema", id_Sistema)
        End With
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                If UCase(sPassword) = UCase(dr("Password")) Then
                    Valida_Acceso = True
                Else
                    Valida_Acceso = False
                End If
            Else
                Valida_Acceso = False
            End If
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message  '
        End Try

    End Function
    Public Function BuscaAnalistaSupervisor_OCP()
        ' Esta funcion es solo para el sistema de Certificacion por lo cual abro una conexion para ella
        Dim cmd As New SqlCommand
        If cn_OCP.State = ConnectionState.Open Then cn_OCP.Close()
        cn_OCP.ConnectionString = objConexion.ConexionAnce(sPath_OCP, "Principal", "usradmsistemas", "usradmsistemas")
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_Acceso_Usuarios"
            .Connection = cn_OCP
            .Parameters.Add("@Operacion", "A")
            .Parameters.Add("@Id_Ingeniero", _ID_INGENIERO)
        End With
        Try
            cn_OCP.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _ANALISTA = IIf((IsDBNull(dr("Analista"))), False, dr("Analista"))
                _SUPERVISOR = IIf((IsDBNull(dr("Supervisor"))), False, dr("Supervisor"))
            Else
                _ANALISTA = False
                _SUPERVISOR = False
            End If

        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message '
        End Try
    End Function

    Public Function insertar()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_emp "
        cmd.Connection = cn
        cmd.Parameters.Add("@Nom_Emp", _Nom_Emp)
        cmd.Parameters.Add("@Id_usuario", _Id_usuario)
        cmd.Parameters.Add("@Extension", _Extension)
        cmd.Parameters.Add("@Nivel", SqlDbType.NVarChar, 50, "_Nivel")
        cmd.Parameters.Add("@Dias_Ocupados", SqlDbType.Real, 0, "_Dias_Ocupados")
        cmd.Parameters.Add("@Grupo", SqlDbType.Int, 0, "_Grupo")
        cmd.Parameters.Add("@Id_Div", SqlDbType.Int, 0, "_Id_Div")
        cmd.Parameters.Add("@Id_Area", SqlDbType.NVarChar, 10, "_Id_Area")
        cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 50, "_Email")
        cmd.Parameters.Add("@Firma", _Firma)
        cmd.Parameters.Add("@Rubrica", _Rubrica)
        cmd.Parameters.Add("@Id_Sucursal", _Id_Sucursal)
        cmd.Parameters.Add("@F_Ingreso", _F_INGRESO)
        cmd.Parameters.Add("@Bandera", SqlDbType.Int, 0, _Bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message '
        End Try
    End Function


    Public Function Borrar()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_emp "
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", SqlDbType.Int, 0, _Bandera)
        cmd.Parameters.Add("@Id_usuario", _Id_usuario)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message '
        End Try
    End Function

    Public Function actualizar()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_emp "
        cmd.Connection = cn
        cmd.Parameters.Add("@Nom_Emp", _Nom_Emp)
        cmd.Parameters.Add("@Id_usuario", _Id_usuario)
        cmd.Parameters.Add("@Extension", _Extension)
        cmd.Parameters.Add("@Nivel", "_Nivel")
        cmd.Parameters.Add("@Dias_Ocupados", "_Dias_Ocupados")
        cmd.Parameters.Add("@Grupo", "_Grupo")
        cmd.Parameters.Add("@Id_Div", "_Id_Div")
        cmd.Parameters.Add("@Id_Area", "_Id_Area")
        cmd.Parameters.Add("@Email", "_Email")
        cmd.Parameters.Add("@Firma", _Firma)
        cmd.Parameters.Add("@Rubrica", _Rubrica)
        cmd.Parameters.Add("@Id_Sucursal", _Id_Sucursal)
        cmd.Parameters.Add("@F_Ingreso", _F_INGRESO)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message '
        End Try
    End Function

    Public Function Listar() As DataTable
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Buscar"
        cmd.Connection = cn
        Call llena_parametros(cmd)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("clsempleados")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _Error = "ERROR - " + ex.Source + " " + ex.Message
            Return Nothing
        End Try
    End Function

    Public Sub New(ByVal Identificador As String, ByVal guser As String, ByVal gpassword As String)
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "COMUN", guser, gpassword)
    End Sub

    Public Function Buscar_usuario()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        If cn.State = ConnectionState.Open Then cn.Close()

        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Sistemas"
        cmd.Connection = cn

        With cmd 'el sp es diferente, por eso se definen los parametros aqui
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_Usuario", _Id_usuario)
            .Parameters.Add("@Id_Sistema", _Id_Sistema)
            .Parameters.Add("@Id_grupo", _Id_Grupo)
            .Parameters.Add("@Password", _Password)
        End With
        Try
            cn.Open()
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_usuario = IIf((IsDBNull(dr("Id_usuario"))), "", dr("Id_usuario"))
                _Id_Sistema = IIf((IsDBNull(dr("Id_sistema"))), "", dr("Id_sistema"))
                _Id_Grupo = IIf((IsDBNull(dr("Id_Grupo"))), 0, dr("Id_Grupo"))
                _Password = (IIf((IsDBNull(dr("Password"))), "", dr("Password")))
            Else
                _Id_usuario = ""
                _Id_Sistema = 0
                _Grupo = 0
                _Password = ""
            End If
            cn.Close()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

    Public Function modificar_usuario()
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .CommandText = "sp_C_Emp_Modificar"
            .Connection = cn
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@ID_Usuario", _Id_usuario)
            .Parameters.Add("@Id_Sistema", "_Id_Sistema")
            .Parameters.Add("@Id_Grupo", "_Id_Grupo")
            .Parameters.Add("@Password", _Password)
        End With
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message '
        End Try
    End Function

    Public Function Buscar_Sistema() 'trae la descripcion del sistema
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        If cn.State = ConnectionState.Open Then cn.Close()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Sistemas"
        cmd.Connection = cn
        With cmd 'el sp es diferente, por eso se definen los parametros aqui
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_Sistema", _Id_Sistema)
        End With
        Try
            cn.Open()
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Sistema = IIf((IsDBNull(dr("Id_sistema"))), "", dr("Id_sistema"))
                _Nombre_Sistema = IIf((IsDBNull(dr("Nombre_Sistema"))), 0, dr("Nombre_Sistema"))
            Else
                _Id_Sistema = 0
                _Nombre_Sistema = ""
            End If
            cn.Close()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

    Public Function Buscar_Grupo() 'trae la descripci�n del grupo
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader
        If cn.State = ConnectionState.Open Then cn.Close()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Sistemas"
        cmd.Connection = cn
        With cmd 'el sp es diferente, por eso se definen los parametros aqui
            .Parameters.Add("@Bandera", _Bandera)
            .Parameters.Add("@Id_Sistema", _Id_Sistema)
            .Parameters.Add("@Id_Grupo", _Id_Grupo)
        End With
        Try
            cn.Open()
            dr = cmd.ExecuteReader
            If dr.Read Then
                _Id_Grupo = IIf((IsDBNull(dr("Id_Grupo"))), "", dr("Id_Grupo"))
                _Nombre_Grupo = IIf((IsDBNull(dr("Nombre_Grupo"))), 0, dr("Nombre_Grupo"))
            Else
                _Id_Grupo = 0
                _Nombre_Grupo = ""
            End If
            cn.Close()
        Catch ex As Exception
            Return "ERROR - " + ex.Source + " " + ex.Message
        End Try
    End Function

    Public Sub ListaComboGrupo(ByVal cbo As Object) 'llena el combo de Grupo
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Emp_Sistemas"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Id_Sistema", _Id_Sistema)
        cmd.Parameters.Add("@Id_Grupo", _Id_Grupo)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("clsGrupo")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(2).ColumnName
            cbo.ValueMember = dt.Columns(1).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return
        End Try
    End Sub
End Class