Imports System.Data.SqlClient

Public Class cls
    Dim oConexion As New SqlConnection

    Function ListaComite() As DataTable
        'PARA LLECAR LOS COMITES
        Dim sqlComite As String = "SELECT Cve_Comite, Descripcion FROM C_Comite"
        Dim ds As New DataSet
        Dim adComite As New SqlDataAdapter(sqlComite, oConexion)
        adComite.Fill(ds, "C_Comite")
        Return ds.Tables("C_Comite")
    End Function

    Function ListaCT(ByVal sComite As String) As DataTable
        'PARA LLENAR LOS COMITES T�CNICOS
        'se necesita que se env�e por que Comit� se filtra
        Dim sqlCT As String = "SELECT Cve_Comite, Cve_Comitetec, Descripcion, Objetivo FROM C_Comitetec WHERE Cve_Comite = '" + sComite + "'"
        Dim ds As New DataSet
        Dim adCT As New SqlDataAdapter(sqlCT, oConexion)
        adCT.Fill(ds, "C_ComiteTec")
        Return ds.Tables("C_ComiteTec")
    End Function

    Function ListaSC(ByVal sComite As String, ByVal sCT As String) As DataTable
        'PARA LLENAR LOS SUB T�CNICOS
        'se necesita que se env�e por que Comit� y SC se filtra
        Dim sqlSC As String = "SELECT Cve_Comite, Cve_Comitetec, Cve_Subcomite, Descripcion, Objetivo FROM C_Subcomite WHERE Cve_Comite = '" + sComite + "' and cve_ComiteTec='" + sCT + "'"
        Dim ds As New DataSet
        Dim adCT As New SqlDataAdapter(sqlSC, oConexion)
        adCT.Fill(ds, "C_SubComite")
        Return ds.Tables("C_SubComite")
    End Function

    Function ListaGT(ByVal sComite As String, ByVal sCT As String, ByVal sSC As String) As DataTable
        'PARA LLENAR LOS GRUPOS DE TRABAJO
        'se necesita que se env�e por que Comit� y SC se filtra
        Dim sqlGT As String = "SELECT Cve_Comite, Cve_Comitetec, Cve_Subcomite, Cve_Grupo, Descripcion, Objetivo FROM C_GruposTrabajo WHERE Cve_Comite = '" + sComite + "' and cve_ComiteTec='" + sCT + "' and cve_SubComite='" + sSC + "'"
        Dim ds As New DataSet
        Dim adCT As New SqlDataAdapter(sqlGT, oConexion)
        adCT.Fill(ds, "C_GruposTrabajo")
        Return ds.Tables("C_GruposTrabajo")
    End Function

    Public Sub New()
        oConexion.ConnectionString = ("Data source=ance02;initial catalog=dbNormalizacion; user id = admsis; pwd=admynsys")
    End Sub
End Class
