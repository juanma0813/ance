Imports System.Data.SqlClient
Imports System.Data.DataSet
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Windows.Forms
Imports System.IO
Imports System.IO.File



Public Class frmPNN_temas
    Inherits System.Windows.Forms.Form

#Region " Referencias instanciadas"

    Private objConexion As New clsConexion.cIsConexion
    Private cn As New SqlConnection

    Private oVista As DataView
    Private DragDropTreeView As Boolean
    Private NodoOrigen As TreeNode
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private ObjTiposTema As New ClsTipos_tema.C_Tipos_Tema(0, gUsuario, gPasswordSql)
    Private ObjEmpleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private ObjDt As New ClsDt.P_DT(0, gUsuario, gPasswordSql)
    Private ObjNuevoPeriodo As New NuevoPeriodoComentarios.NuevoPeriodoComentarios(0, gUsuario, gPasswordSql)
    Private ObjAnt As New ClsAnt.P_Ant(0, gUsuario, gPasswordSql)
    Private ObjProy As New clsProy.P_Proy(0, gUsuario, gPasswordSql)
    Private ObjComites As New clsComites.clsComites("PRINCIPAL", gUsuario, gPasswordSql)
    Private ObjComentarios As New clsComentarios.C_Comentarios("PRINCIPAL", gUsuario, gPasswordSql)
    Private ObjJustiRegresos As New ClsJusti_regresos.ClsJusti_regresos(0, gUsuario, gPasswordSql)
    Private clsBusca_F_Sesion As New Cls_Sesiones.Cls_sesiones(0, gUsuario, gPasswordSql)
    Private objRevision As New ClsRevision_Normas.C_Revision_Normas(0, gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim clsDoctosTemas As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)
    Private ObjPlan As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim clsTemas_Normas As New clsTemas_Normas.P_Temas_Normas(0, gUsuario, gPasswordSql)
    Dim ObjDirectorio As New ClsDirectorio.C_Directorio(0, gUsuario, gPasswordSql)
    Dim objNormas As New clsCatalogoNormas.C_Normas(0, gUsuario, gPasswordSql)
    Private objInspeccionPrueba As New ClsInspeccionPruebas.ClsInspeccionPruebas(0, gUsuario, gPasswordSql)
    Private clsCopia As New ClsCopiaArchivos.ClsCopiaArchivos
    Dim clsProy As New clsProy.P_Proy(0, gUsuario, gPasswordSql)
    Private ProcAlter As New ClsProcedimientoAlternativo.P_Procedimiento_Alternativo(0, gUsuario, gPasswordSql)
    Private clsProc As New ClsProcedimientoAlternativo.P_Procedimiento_Alternativo(0, gUsuario, gPasswordSql)
    Private clsTree As New clsViewTree.cls(0, gUsuario, gPasswordSql)

    Private dtTiposTema As DataTable
    Private dtRevision As DataTable
    Private dtDirectorio As DataTable
    Private dtempleados As DataTable
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    ' defino variable del tipo DataRow
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim RegGT As DataRow
    Dim nodo1 As New TreeNode
    Dim sEtapa As String
    Dim Matriz As Array
    Dim svariable As String
    Dim sPlan As String
    Dim stema As String
    Dim sraiz As String
    Dim RefCompleta As String
    Dim bandera As Integer
    Dim sComite As String
    Dim sCt As String
    Dim sSc As String
    Dim sGt As String
    Dim sNormaBasada As String
    Dim sarmonizada As String
    Dim dvComite As DataView
    Dim Reportes As New frmreporte
    Dim myStream As String
    Dim myStream2 As String
    Dim myStream3 As String
    Dim myStream4 As String
    Dim myStream5 As String
    Dim myStream6 As String
    Dim myStream7 As String
    Dim myStream8 As String
    Dim myStream9 As String
    Dim bandCom As Boolean
    Dim Id_etapa As String
    Dim Bandera_tema As Integer
    Dim Bandera_Ant As Integer
    Dim Bandera_Proy As Integer
    Dim Bandera2 As Integer
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim Proceso As Integer
    Dim sta As String
    Dim tipo As Integer
    Dim revision As Integer
    Dim SDocumento As String
    Dim sCuenta As String
    Dim sExt As String
    Dim zId_Etapa As Integer
    Dim sRef_A�o As String
    Dim sRef_Comite As String
    Dim sRef_Consecutivo As String
    Dim sRef_regreso As String
    Dim sRef_traspaso As String
    Dim srefP As String
    Dim band As Boolean
    Dim banFecha As Boolean = False
    Dim oTablaSs As DataTable
    Dim RegSes As DataRow
    Dim iEditar As String
    Public BandPreguntas As Boolean
    Public bandModifClasific As Boolean = False
    Public bandModifClasificAnt As Boolean = True
    Public bandModifClasificProy As Boolean = True
#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents TbPgProgramaTrabajo As System.Windows.Forms.TabPage
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents PnlLectura As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtf2 As System.Windows.Forms.TextBox
    Friend WithEvents txtf1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents f1 As System.Windows.Forms.Label
    Friend WithEvents txtcomite As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txttipoTema As System.Windows.Forms.TextBox
    Friend WithEvents CboTipoTema As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TVcomites As System.Windows.Forms.TreeView
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents txtresponsable As System.Windows.Forms.TextBox
    Friend WithEvents pnlDt As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtClasificacionPT As System.Windows.Forms.TextBox
    Friend WithEvents txttituloPT As System.Windows.Forms.TextBox
    Friend WithEvents lblTitulo As System.Windows.Forms.Label
    Friend WithEvents txtobjetivo As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents txtjustificacion As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents txtnumerotema As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtrevision As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents lblstatus As System.Windows.Forms.Label
    Friend WithEvents TBpt As System.Windows.Forms.TabControl
    Friend WithEvents TbDt As System.Windows.Forms.TabPage
    Friend WithEvents tbAnt As System.Windows.Forms.TabPage
    Friend WithEvents TbAvance As System.Windows.Forms.TabPage
    Friend WithEvents cmdSeguimiento As System.Windows.Forms.ToolBarButton
    Friend WithEvents pnlAnt As System.Windows.Forms.Panel
    Friend WithEvents txtclasificaciondt As System.Windows.Forms.TextBox
    Friend WithEvents pnlProcAlter As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents chkBasada As System.Windows.Forms.CheckBox
    Friend WithEvents Txtbasada As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents cboRevision As System.Windows.Forms.ComboBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents txtF_nmx As System.Windows.Forms.TextBox
    Friend WithEvents txtaprbRev_Edit As System.Windows.Forms.TextBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents txtf_Dtfinal As System.Windows.Forms.TextBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents txtf_Impr_ActaAprob As System.Windows.Forms.TextBox
    Friend WithEvents txtf_Carga_ActaAprob As System.Windows.Forms.TextBox
    Friend WithEvents txtf_Aprob_CTGT_Ant As System.Windows.Forms.TextBox
    Friend WithEvents txtf_Aprob_Comite_Proy As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents txttitulodt As System.Windows.Forms.TextBox
    Friend WithEvents txtresponsableDt As System.Windows.Forms.TextBox
    Friend WithEvents CboResponsableDt As System.Windows.Forms.ComboBox
    Friend WithEvents txtf_des_Nmx As System.Windows.Forms.TextBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txttituloant As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtnumpags_Ant As System.Windows.Forms.TextBox
    Friend WithEvents txtclasificacion_ant As System.Windows.Forms.TextBox
    Friend WithEvents txtresponsable_ant As System.Windows.Forms.TextBox
    Friend WithEvents txtAprob_Revision_Editorial As System.Windows.Forms.TextBox
    Friend WithEvents cboresponsable_ant As System.Windows.Forms.ComboBox
    Friend WithEvents txtf_pub_compub As System.Windows.Forms.TextBox
    Friend WithEvents txtf_lim_compub As System.Windows.Forms.TextBox
    Friend WithEvents txtf_res_compub As System.Windows.Forms.TextBox
    Friend WithEvents txtf_lim_res_compub As System.Windows.Forms.TextBox
    Friend WithEvents txtf_aprob_res_compub As System.Windows.Forms.TextBox
    Friend WithEvents txtf_VoBo_Comite As System.Windows.Forms.TextBox
    Friend WithEvents txtf_inic_rev_proyf As System.Windows.Forms.TextBox
    Friend WithEvents txtf_fin_rev_proyf As System.Windows.Forms.TextBox
    Friend WithEvents txtf_edi_proyf As System.Windows.Forms.TextBox
    Friend WithEvents txtf_impr_Acta_proyf As System.Windows.Forms.TextBox
    Friend WithEvents txtf_carga_acta_proyf As System.Windows.Forms.TextBox
    Friend WithEvents txtf_acuseDGN As System.Windows.Forms.TextBox
    Friend WithEvents txtf_carga_Proyf As System.Windows.Forms.TextBox
    Friend WithEvents DT2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DT1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtadjDtf As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtfcargaDtFinal As System.Windows.Forms.TextBox
    Friend WithEvents cmdDt As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtadjantF As System.Windows.Forms.TextBox
    Friend WithEvents cmdant As System.Windows.Forms.Button
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtcarg_antfinal As System.Windows.Forms.TextBox
    Friend WithEvents tbProy As System.Windows.Forms.TabPage
    Friend WithEvents pnlproy As System.Windows.Forms.Panel
    Friend WithEvents txttitulo_Proy As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtclasificacion_proy As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtresponsable_proy As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsable_proy As System.Windows.Forms.ComboBox
    Friend WithEvents txtf_limitecompub As System.Windows.Forms.TextBox
    Friend WithEvents dtF_Fin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtf_ini_compub As System.Windows.Forms.TextBox
    Friend WithEvents dtF_inicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtpaginas_proy As System.Windows.Forms.TextBox
    Friend WithEvents txtf_aprob_com As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents DTf_aprobComproy As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents cmdactaAprobacion_Proy As System.Windows.Forms.Button
    Friend WithEvents txtf_aprobrescompub As System.Windows.Forms.TextBox
    Friend WithEvents txtf_imp_actaprob_proy As System.Windows.Forms.TextBox
    Friend WithEvents txtfResolucion As System.Windows.Forms.TextBox
    Friend WithEvents dtresolucion As System.Windows.Forms.DateTimePicker
    Friend WithEvents TXTF_limrescompub As System.Windows.Forms.TextBox
    Friend WithEvents dtF_limrescompub As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtf_aprobrescompub As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtvobo As System.Windows.Forms.TextBox
    Friend WithEvents dtvobo As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtfiniRev As System.Windows.Forms.TextBox
    Friend WithEvents dtfiniRev As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtftermrev As System.Windows.Forms.TextBox
    Friend WithEvents dtftermrev As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtf_edic As System.Windows.Forms.TextBox
    Friend WithEvents dtf_edic As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents txtfCargaProyf As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents txtadjactPROYF As System.Windows.Forms.TextBox
    Friend WithEvents cmdproyf As System.Windows.Forms.Button
    Friend WithEvents txtfcarga_actaprobPROYF As System.Windows.Forms.TextBox
    Friend WithEvents txtacusePROYF As System.Windows.Forms.TextBox
    Friend WithEvents dtacusePROYF As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtf_cargaAntf As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents txtresponsable_procalt As System.Windows.Forms.TextBox
    Friend WithEvents txtf_inicresp As System.Windows.Forms.TextBox
    Friend WithEvents txtf_finresp As System.Windows.Forms.TextBox
    Friend WithEvents txtf_inic_com As System.Windows.Forms.TextBox
    Friend WithEvents txtf_fin_com As System.Windows.Forms.TextBox
    Friend WithEvents cboresponsable_procalt As System.Windows.Forms.ComboBox
    Friend WithEvents dtfincom As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtinicom As System.Windows.Forms.DateTimePicker
    Friend WithEvents tdfinresp As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtiniresp As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkAlternativo As System.Windows.Forms.CheckBox
    Friend WithEvents chkNormal As System.Windows.Forms.CheckBox
    Friend WithEvents chkModTec As System.Windows.Forms.CheckBox
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents cmdminuta As System.Windows.Forms.Button
    Friend WithEvents txtminuta As System.Windows.Forms.TextBox
    Friend WithEvents fcarga_minuta As System.Windows.Forms.TextBox
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents txtf_inicioprocalter As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents txtf_cargaminuta As System.Windows.Forms.TextBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents txtreferencia As System.Windows.Forms.TextBox
    Friend WithEvents cmdLoop As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtf_aprobCtGT As System.Windows.Forms.TextBox
    Friend WithEvents dtf_aprobCtGT As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtfcargaActaprobFinal As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtf_impActAprob As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents cmdacta As System.Windows.Forms.Button
    Friend WithEvents txtadjActAprobFinal As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents CmdActaAprobacion As System.Windows.Forms.Button
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents chkarmonizada As System.Windows.Forms.CheckBox
    Friend WithEvents txtarmonizacion As System.Windows.Forms.TextBox
    Friend WithEvents txtjustarm As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents chkrevedit As System.Windows.Forms.CheckBox
    Friend WithEvents txtnumcomTec As System.Windows.Forms.TextBox
    Friend WithEvents optComTecNo As System.Windows.Forms.RadioButton
    Friend WithEvents optComTecSi As System.Windows.Forms.RadioButton
    Friend WithEvents grbComTec As System.Windows.Forms.GroupBox
    Friend WithEvents GrbComEd As System.Windows.Forms.GroupBox
    Friend WithEvents GrbApDT As System.Windows.Forms.GroupBox
    Friend WithEvents optApDtNo As System.Windows.Forms.RadioButton
    Friend WithEvents optApDtSi As System.Windows.Forms.RadioButton
    Friend WithEvents txtnumcomed As System.Windows.Forms.TextBox
    Friend WithEvents optComEdNo As System.Windows.Forms.RadioButton
    Friend WithEvents optComEdSi As System.Windows.Forms.RadioButton
    Friend WithEvents txtF_Correcciones As System.Windows.Forms.TextBox
    Friend WithEvents dtpFCorrec As System.Windows.Forms.DateTimePicker
    Friend WithEvents optCorrNo As System.Windows.Forms.RadioButton
    Friend WithEvents optCorrSi As System.Windows.Forms.RadioButton
    Friend WithEvents txtdifDates As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton9 As System.Windows.Forms.RadioButton
    Friend WithEvents optComTecSiProy As System.Windows.Forms.RadioButton
    Friend WithEvents optComEdSiProy As System.Windows.Forms.RadioButton
    Friend WithEvents txtnumcomTecProy As System.Windows.Forms.TextBox
    Friend WithEvents txtnumcomedProy As System.Windows.Forms.TextBox
    Friend WithEvents txtfverifrefProy As System.Windows.Forms.TextBox
    Friend WithEvents dpFverif_rev As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents pnlRegreso As System.Windows.Forms.Panel
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents lblRef As System.Windows.Forms.Label
    Friend WithEvents lblEtapa As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdRegresar As System.Windows.Forms.Button
    Friend WithEvents cmdCancelar As System.Windows.Forms.Button
    Friend WithEvents optAnt As System.Windows.Forms.RadioButton
    Friend WithEvents optDT As System.Windows.Forms.RadioButton
    Friend WithEvents optPT As System.Windows.Forms.RadioButton
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents txtf_ap2 As System.Windows.Forms.TextBox
    Friend WithEvents DTf_ap_res2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents optProy As System.Windows.Forms.RadioButton
    Public WithEvents tltMensaje As System.Windows.Forms.ToolTip
    Friend WithEvents lnkTitulo As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkObjetivo As System.Windows.Forms.LinkLabel
    Friend WithEvents lklJustificacion As System.Windows.Forms.LinkLabel
    Friend WithEvents lblStatusNorma As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TpHistorial As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents TVHistorialPNN As System.Windows.Forms.TreeView
    Friend WithEvents txthreferencia As System.Windows.Forms.TextBox
    Friend WithEvents txthNumeroTema As System.Windows.Forms.TextBox
    Friend WithEvents txthclasificacion As System.Windows.Forms.TextBox
    Friend WithEvents txthjustiArmonizada As System.Windows.Forms.TextBox
    Friend WithEvents txtharmonizada As System.Windows.Forms.TextBox
    Friend WithEvents chkharmonizada As System.Windows.Forms.CheckBox
    Friend WithEvents txthbasado As System.Windows.Forms.TextBox
    Friend WithEvents chkhbasado As System.Windows.Forms.CheckBox
    Friend WithEvents txthRevision As System.Windows.Forms.TextBox
    Friend WithEvents txthjustificacion As System.Windows.Forms.TextBox
    Friend WithEvents txthobjetivo As System.Windows.Forms.TextBox
    Friend WithEvents txthtitulo As System.Windows.Forms.TextBox
    Friend WithEvents txthresponsable As System.Windows.Forms.TextBox
    Friend WithEvents txthfFin As System.Windows.Forms.TextBox
    Friend WithEvents txthfinicio As System.Windows.Forms.TextBox
    Friend WithEvents txthpertenece As System.Windows.Forms.TextBox
    Friend WithEvents txthtipotema As System.Windows.Forms.TextBox
    Friend WithEvents chkhmodific As System.Windows.Forms.CheckBox
    Friend WithEvents chkhnormal As System.Windows.Forms.CheckBox
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents cmdProy As System.Windows.Forms.Button
    Friend WithEvents txtadjProyfinal As System.Windows.Forms.TextBox
    Friend WithEvents cmdProyectoFinal As System.Windows.Forms.Button
    Friend WithEvents txtProyectoFinal As System.Windows.Forms.TextBox
    Friend WithEvents txtFechaDeclaratoriaVigencia As System.Windows.Forms.TextBox
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents txtPaginasNorma As System.Windows.Forms.TextBox
    Friend WithEvents chkCambiaNorma As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPNN_temas))
        Dim configurationAppSettings As System.Configuration.AppSettingsReader = New System.Configuration.AppSettingsReader
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.TbPgProgramaTrabajo = New System.Windows.Forms.TabPage
        Me.lblStatusNorma = New System.Windows.Forms.Label
        Me.lnkObjetivo = New System.Windows.Forms.LinkLabel
        Me.lklJustificacion = New System.Windows.Forms.LinkLabel
        Me.lnkTitulo = New System.Windows.Forms.LinkLabel
        Me.PnlLectura = New System.Windows.Forms.Panel
        Me.Label95 = New System.Windows.Forms.Label
        Me.txtjustarm = New System.Windows.Forms.TextBox
        Me.txtarmonizacion = New System.Windows.Forms.TextBox
        Me.chkarmonizada = New System.Windows.Forms.CheckBox
        Me.txtreferencia = New System.Windows.Forms.TextBox
        Me.Label85 = New System.Windows.Forms.Label
        Me.Txtbasada = New System.Windows.Forms.TextBox
        Me.chkBasada = New System.Windows.Forms.CheckBox
        Me.lblstatus = New System.Windows.Forms.Label
        Me.txtrevision = New System.Windows.Forms.TextBox
        Me.Label48 = New System.Windows.Forms.Label
        Me.txtnumerotema = New System.Windows.Forms.TextBox
        Me.Label47 = New System.Windows.Forms.Label
        Me.txtjustificacion = New System.Windows.Forms.TextBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.txtobjetivo = New System.Windows.Forms.TextBox
        Me.Label45 = New System.Windows.Forms.Label
        Me.txttituloPT = New System.Windows.Forms.TextBox
        Me.lblTitulo = New System.Windows.Forms.Label
        Me.txtClasificacionPT = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtresponsable = New System.Windows.Forms.TextBox
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtf2 = New System.Windows.Forms.TextBox
        Me.txtf1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.f1 = New System.Windows.Forms.Label
        Me.txtcomite = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TVcomites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.txttipoTema = New System.Windows.Forms.TextBox
        Me.CboTipoTema = New System.Windows.Forms.ComboBox
        Me.cboRevision = New System.Windows.Forms.ComboBox
        Me.DT1 = New System.Windows.Forms.DateTimePicker
        Me.DT2 = New System.Windows.Forms.DateTimePicker
        Me.chkModTec = New System.Windows.Forms.CheckBox
        Me.chkNormal = New System.Windows.Forms.CheckBox
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.TBpt = New System.Windows.Forms.TabControl
        Me.TbDt = New System.Windows.Forms.TabPage
        Me.pnlProcAlter = New System.Windows.Forms.Panel
        Me.grbComTec = New System.Windows.Forms.GroupBox
        Me.optComTecSi = New System.Windows.Forms.RadioButton
        Me.optComTecNo = New System.Windows.Forms.RadioButton
        Me.txtnumcomTec = New System.Windows.Forms.TextBox
        Me.fcarga_minuta = New System.Windows.Forms.TextBox
        Me.Label83 = New System.Windows.Forms.Label
        Me.cmdminuta = New System.Windows.Forms.Button
        Me.txtminuta = New System.Windows.Forms.TextBox
        Me.Label82 = New System.Windows.Forms.Label
        Me.Label51 = New System.Windows.Forms.Label
        Me.txtf_fin_com = New System.Windows.Forms.TextBox
        Me.dtfincom = New System.Windows.Forms.DateTimePicker
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtf_inic_com = New System.Windows.Forms.TextBox
        Me.dtinicom = New System.Windows.Forms.DateTimePicker
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtf_finresp = New System.Windows.Forms.TextBox
        Me.tdfinresp = New System.Windows.Forms.DateTimePicker
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtf_inicresp = New System.Windows.Forms.TextBox
        Me.dtiniresp = New System.Windows.Forms.DateTimePicker
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.txtresponsable_procalt = New System.Windows.Forms.TextBox
        Me.cboresponsable_procalt = New System.Windows.Forms.ComboBox
        Me.GrbApDT = New System.Windows.Forms.GroupBox
        Me.optApDtNo = New System.Windows.Forms.RadioButton
        Me.optApDtSi = New System.Windows.Forms.RadioButton
        Me.GrbComEd = New System.Windows.Forms.GroupBox
        Me.txtnumcomed = New System.Windows.Forms.TextBox
        Me.optComEdNo = New System.Windows.Forms.RadioButton
        Me.optComEdSi = New System.Windows.Forms.RadioButton
        Me.pnlDt = New System.Windows.Forms.Panel
        Me.chkrevedit = New System.Windows.Forms.CheckBox
        Me.chkAlternativo = New System.Windows.Forms.CheckBox
        Me.txtfcargaDtFinal = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtadjDtf = New System.Windows.Forms.TextBox
        Me.cmdDt = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.txttitulodt = New System.Windows.Forms.TextBox
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.txtclasificaciondt = New System.Windows.Forms.TextBox
        Me.txtAprob_Revision_Editorial = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtresponsableDt = New System.Windows.Forms.TextBox
        Me.CboResponsableDt = New System.Windows.Forms.ComboBox
        Me.txtf_des_Nmx = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.tbAnt = New System.Windows.Forms.TabPage
        Me.pnlAnt = New System.Windows.Forms.Panel
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label88 = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label89 = New System.Windows.Forms.Label
        Me.optCorrNo = New System.Windows.Forms.RadioButton
        Me.optCorrSi = New System.Windows.Forms.RadioButton
        Me.Label87 = New System.Windows.Forms.Label
        Me.txtF_Correcciones = New System.Windows.Forms.TextBox
        Me.dtpFCorrec = New System.Windows.Forms.DateTimePicker
        Me.Label86 = New System.Windows.Forms.Label
        Me.txtfcargaActaprobFinal = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtf_impActAprob = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.cmdacta = New System.Windows.Forms.Button
        Me.txtadjActAprobFinal = New System.Windows.Forms.TextBox
        Me.Label54 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.CmdActaAprobacion = New System.Windows.Forms.Button
        Me.txtf_aprobCtGT = New System.Windows.Forms.TextBox
        Me.dtf_aprobCtGT = New System.Windows.Forms.DateTimePicker
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtcarg_antfinal = New System.Windows.Forms.TextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.txtadjantF = New System.Windows.Forms.TextBox
        Me.cmdant = New System.Windows.Forms.Button
        Me.Label32 = New System.Windows.Forms.Label
        Me.txtclasificacion_ant = New System.Windows.Forms.TextBox
        Me.txttituloant = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtresponsable_ant = New System.Windows.Forms.TextBox
        Me.cboresponsable_ant = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtnumpags_Ant = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.tbProy = New System.Windows.Forms.TabPage
        Me.pnlproy = New System.Windows.Forms.Panel
        Me.chkCambiaNorma = New System.Windows.Forms.CheckBox
        Me.txtPaginasNorma = New System.Windows.Forms.TextBox
        Me.txtFechaDeclaratoriaVigencia = New System.Windows.Forms.TextBox
        Me.Label110 = New System.Windows.Forms.Label
        Me.txtProyectoFinal = New System.Windows.Forms.TextBox
        Me.cmdProyectoFinal = New System.Windows.Forms.Button
        Me.Label98 = New System.Windows.Forms.Label
        Me.txtf_ap2 = New System.Windows.Forms.TextBox
        Me.DTf_ap_res2 = New System.Windows.Forms.DateTimePicker
        Me.Label93 = New System.Windows.Forms.Label
        Me.Label90 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtnumcomedProy = New System.Windows.Forms.TextBox
        Me.RadioButton9 = New System.Windows.Forms.RadioButton
        Me.optComEdSiProy = New System.Windows.Forms.RadioButton
        Me.txtdifDates = New System.Windows.Forms.TextBox
        Me.txtfverifrefProy = New System.Windows.Forms.TextBox
        Me.Label94 = New System.Windows.Forms.Label
        Me.dpFverif_rev = New System.Windows.Forms.DateTimePicker
        Me.txtadjactPROYF = New System.Windows.Forms.TextBox
        Me.cmdproyf = New System.Windows.Forms.Button
        Me.Label80 = New System.Windows.Forms.Label
        Me.txtadjProyfinal = New System.Windows.Forms.TextBox
        Me.cmdProy = New System.Windows.Forms.Button
        Me.Label79 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.cmdactaAprobacion_Proy = New System.Windows.Forms.Button
        Me.txtfCargaProyf = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.txtacusePROYF = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.txtfcarga_actaprobPROYF = New System.Windows.Forms.TextBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.txtf_imp_actaprob_proy = New System.Windows.Forms.TextBox
        Me.Label39 = New System.Windows.Forms.Label
        Me.txtf_edic = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.txtftermrev = New System.Windows.Forms.TextBox
        Me.Label41 = New System.Windows.Forms.Label
        Me.txtfiniRev = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.txtvobo = New System.Windows.Forms.TextBox
        Me.Label43 = New System.Windows.Forms.Label
        Me.txtf_aprobrescompub = New System.Windows.Forms.TextBox
        Me.Label53 = New System.Windows.Forms.Label
        Me.txtfResolucion = New System.Windows.Forms.TextBox
        Me.Label78 = New System.Windows.Forms.Label
        Me.TXTF_limrescompub = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.txtf_aprob_com = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.txttitulo_Proy = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.txtclasificacion_proy = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtresponsable_proy = New System.Windows.Forms.TextBox
        Me.cboResponsable_proy = New System.Windows.Forms.ComboBox
        Me.txtf_limitecompub = New System.Windows.Forms.TextBox
        Me.dtF_Fin = New System.Windows.Forms.DateTimePicker
        Me.Label23 = New System.Windows.Forms.Label
        Me.txtf_ini_compub = New System.Windows.Forms.TextBox
        Me.dtF_inicio = New System.Windows.Forms.DateTimePicker
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.txtpaginas_proy = New System.Windows.Forms.TextBox
        Me.DTf_aprobComproy = New System.Windows.Forms.DateTimePicker
        Me.dtresolucion = New System.Windows.Forms.DateTimePicker
        Me.dtf_aprobrescompub = New System.Windows.Forms.DateTimePicker
        Me.dtvobo = New System.Windows.Forms.DateTimePicker
        Me.dtfiniRev = New System.Windows.Forms.DateTimePicker
        Me.dtftermrev = New System.Windows.Forms.DateTimePicker
        Me.dtF_limrescompub = New System.Windows.Forms.DateTimePicker
        Me.dtf_edic = New System.Windows.Forms.DateTimePicker
        Me.dtacusePROYF = New System.Windows.Forms.DateTimePicker
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtnumcomTecProy = New System.Windows.Forms.TextBox
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.optComTecSiProy = New System.Windows.Forms.RadioButton
        Me.TbAvance = New System.Windows.Forms.TabPage
        Me.txtf_cargaminuta = New System.Windows.Forms.TextBox
        Me.Label84 = New System.Windows.Forms.Label
        Me.txtf_inicioprocalter = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtf_cargaAntf = New System.Windows.Forms.TextBox
        Me.Label81 = New System.Windows.Forms.Label
        Me.Label77 = New System.Windows.Forms.Label
        Me.txtf_carga_Proyf = New System.Windows.Forms.TextBox
        Me.Label67 = New System.Windows.Forms.Label
        Me.txtf_acuseDGN = New System.Windows.Forms.TextBox
        Me.Label68 = New System.Windows.Forms.Label
        Me.txtf_carga_acta_proyf = New System.Windows.Forms.TextBox
        Me.Label69 = New System.Windows.Forms.Label
        Me.txtf_impr_Acta_proyf = New System.Windows.Forms.TextBox
        Me.Label70 = New System.Windows.Forms.Label
        Me.txtf_edi_proyf = New System.Windows.Forms.TextBox
        Me.Label71 = New System.Windows.Forms.Label
        Me.txtf_fin_rev_proyf = New System.Windows.Forms.TextBox
        Me.Label72 = New System.Windows.Forms.Label
        Me.txtf_inic_rev_proyf = New System.Windows.Forms.TextBox
        Me.Label73 = New System.Windows.Forms.Label
        Me.txtf_VoBo_Comite = New System.Windows.Forms.TextBox
        Me.Label74 = New System.Windows.Forms.Label
        Me.txtf_aprob_res_compub = New System.Windows.Forms.TextBox
        Me.Label75 = New System.Windows.Forms.Label
        Me.txtf_lim_res_compub = New System.Windows.Forms.TextBox
        Me.Label76 = New System.Windows.Forms.Label
        Me.txtf_res_compub = New System.Windows.Forms.TextBox
        Me.Label66 = New System.Windows.Forms.Label
        Me.txtf_lim_compub = New System.Windows.Forms.TextBox
        Me.Label65 = New System.Windows.Forms.Label
        Me.txtf_pub_compub = New System.Windows.Forms.TextBox
        Me.Label64 = New System.Windows.Forms.Label
        Me.txtf_Aprob_Comite_Proy = New System.Windows.Forms.TextBox
        Me.Label63 = New System.Windows.Forms.Label
        Me.txtf_Aprob_CTGT_Ant = New System.Windows.Forms.TextBox
        Me.Label62 = New System.Windows.Forms.Label
        Me.txtf_Carga_ActaAprob = New System.Windows.Forms.TextBox
        Me.Label61 = New System.Windows.Forms.Label
        Me.txtf_Impr_ActaAprob = New System.Windows.Forms.TextBox
        Me.Label60 = New System.Windows.Forms.Label
        Me.txtf_Dtfinal = New System.Windows.Forms.TextBox
        Me.Label59 = New System.Windows.Forms.Label
        Me.txtaprbRev_Edit = New System.Windows.Forms.TextBox
        Me.Label58 = New System.Windows.Forms.Label
        Me.txtF_nmx = New System.Windows.Forms.TextBox
        Me.Label57 = New System.Windows.Forms.Label
        Me.TpHistorial = New System.Windows.Forms.TabPage
        Me.TVHistorialPNN = New System.Windows.Forms.TreeView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label96 = New System.Windows.Forms.Label
        Me.txthjustiArmonizada = New System.Windows.Forms.TextBox
        Me.txtharmonizada = New System.Windows.Forms.TextBox
        Me.chkharmonizada = New System.Windows.Forms.CheckBox
        Me.txthreferencia = New System.Windows.Forms.TextBox
        Me.Label97 = New System.Windows.Forms.Label
        Me.txthbasado = New System.Windows.Forms.TextBox
        Me.chkhbasado = New System.Windows.Forms.CheckBox
        Me.txthRevision = New System.Windows.Forms.TextBox
        Me.Label99 = New System.Windows.Forms.Label
        Me.txthNumeroTema = New System.Windows.Forms.TextBox
        Me.Label100 = New System.Windows.Forms.Label
        Me.txthjustificacion = New System.Windows.Forms.TextBox
        Me.Label101 = New System.Windows.Forms.Label
        Me.txthobjetivo = New System.Windows.Forms.TextBox
        Me.Label102 = New System.Windows.Forms.Label
        Me.txthtitulo = New System.Windows.Forms.TextBox
        Me.Label103 = New System.Windows.Forms.Label
        Me.txthclasificacion = New System.Windows.Forms.TextBox
        Me.Label104 = New System.Windows.Forms.Label
        Me.Label105 = New System.Windows.Forms.Label
        Me.txthresponsable = New System.Windows.Forms.TextBox
        Me.Label106 = New System.Windows.Forms.Label
        Me.txthfFin = New System.Windows.Forms.TextBox
        Me.txthfinicio = New System.Windows.Forms.TextBox
        Me.Label107 = New System.Windows.Forms.Label
        Me.Label108 = New System.Windows.Forms.Label
        Me.txthpertenece = New System.Windows.Forms.TextBox
        Me.Label109 = New System.Windows.Forms.Label
        Me.txthtipotema = New System.Windows.Forms.TextBox
        Me.chkhmodific = New System.Windows.Forms.CheckBox
        Me.chkhnormal = New System.Windows.Forms.CheckBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.cmdSeguimiento = New System.Windows.Forms.ToolBarButton
        Me.cmdLoop = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.pnlRegreso = New System.Windows.Forms.Panel
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.optProy = New System.Windows.Forms.RadioButton
        Me.cmdCancelar = New System.Windows.Forms.Button
        Me.cmdRegresar = New System.Windows.Forms.Button
        Me.optAnt = New System.Windows.Forms.RadioButton
        Me.optDT = New System.Windows.Forms.RadioButton
        Me.optPT = New System.Windows.Forms.RadioButton
        Me.lblEtapa = New System.Windows.Forms.Label
        Me.lblRef = New System.Windows.Forms.Label
        Me.Label92 = New System.Windows.Forms.Label
        Me.Label91 = New System.Windows.Forms.Label
        Me.tltMensaje = New System.Windows.Forms.ToolTip(Me.components)
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TbPgProgramaTrabajo.SuspendLayout()
        Me.PnlLectura.SuspendLayout()
        Me.TBpt.SuspendLayout()
        Me.TbDt.SuspendLayout()
        Me.pnlProcAlter.SuspendLayout()
        Me.grbComTec.SuspendLayout()
        Me.GrbApDT.SuspendLayout()
        Me.GrbComEd.SuspendLayout()
        Me.pnlDt.SuspendLayout()
        Me.tbAnt.SuspendLayout()
        Me.pnlAnt.SuspendLayout()
        Me.tbProy.SuspendLayout()
        Me.pnlproy.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TbAvance.SuspendLayout()
        Me.TpHistorial.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnlRegreso.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'TbPgProgramaTrabajo
        '
        Me.TbPgProgramaTrabajo.Controls.Add(Me.lblStatusNorma)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.lnkObjetivo)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.lklJustificacion)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.lnkTitulo)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.PnlLectura)
        Me.TbPgProgramaTrabajo.Controls.Add(Me.TVPNN)
        Me.TbPgProgramaTrabajo.Location = New System.Drawing.Point(4, 22)
        Me.TbPgProgramaTrabajo.Name = "TbPgProgramaTrabajo"
        Me.TbPgProgramaTrabajo.Size = New System.Drawing.Size(712, 686)
        Me.TbPgProgramaTrabajo.TabIndex = 0
        Me.TbPgProgramaTrabajo.Text = "Programa de Trabajo"
        '
        'lblStatusNorma
        '
        Me.lblStatusNorma.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusNorma.ForeColor = System.Drawing.Color.Brown
        Me.lblStatusNorma.Location = New System.Drawing.Point(616, 120)
        Me.lblStatusNorma.Name = "lblStatusNorma"
        Me.lblStatusNorma.Size = New System.Drawing.Size(88, 23)
        Me.lblStatusNorma.TabIndex = 139
        '
        'lnkObjetivo
        '
        Me.lnkObjetivo.AutoSize = True
        Me.lnkObjetivo.Location = New System.Drawing.Point(640, 184)
        Me.lnkObjetivo.Name = "lnkObjetivo"
        Me.lnkObjetivo.Size = New System.Drawing.Size(27, 16)
        Me.lnkObjetivo.TabIndex = 16
        Me.lnkObjetivo.TabStop = True
        Me.lnkObjetivo.Text = "Leer"
        '
        'lklJustificacion
        '
        Me.lklJustificacion.AutoSize = True
        Me.lklJustificacion.Location = New System.Drawing.Point(640, 216)
        Me.lklJustificacion.Name = "lklJustificacion"
        Me.lklJustificacion.Size = New System.Drawing.Size(27, 16)
        Me.lklJustificacion.TabIndex = 15
        Me.lklJustificacion.TabStop = True
        Me.lklJustificacion.Text = "Leer"
        '
        'lnkTitulo
        '
        Me.lnkTitulo.AutoSize = True
        Me.lnkTitulo.Location = New System.Drawing.Point(640, 152)
        Me.lnkTitulo.Name = "lnkTitulo"
        Me.lnkTitulo.Size = New System.Drawing.Size(27, 16)
        Me.lnkTitulo.TabIndex = 14
        Me.lnkTitulo.TabStop = True
        Me.lnkTitulo.Text = "Leer"
        '
        'PnlLectura
        '
        Me.PnlLectura.Controls.Add(Me.Label95)
        Me.PnlLectura.Controls.Add(Me.txtjustarm)
        Me.PnlLectura.Controls.Add(Me.txtarmonizacion)
        Me.PnlLectura.Controls.Add(Me.chkarmonizada)
        Me.PnlLectura.Controls.Add(Me.txtreferencia)
        Me.PnlLectura.Controls.Add(Me.Label85)
        Me.PnlLectura.Controls.Add(Me.Txtbasada)
        Me.PnlLectura.Controls.Add(Me.chkBasada)
        Me.PnlLectura.Controls.Add(Me.lblstatus)
        Me.PnlLectura.Controls.Add(Me.txtrevision)
        Me.PnlLectura.Controls.Add(Me.Label48)
        Me.PnlLectura.Controls.Add(Me.txtnumerotema)
        Me.PnlLectura.Controls.Add(Me.Label47)
        Me.PnlLectura.Controls.Add(Me.txtjustificacion)
        Me.PnlLectura.Controls.Add(Me.Label46)
        Me.PnlLectura.Controls.Add(Me.txtobjetivo)
        Me.PnlLectura.Controls.Add(Me.Label45)
        Me.PnlLectura.Controls.Add(Me.txttituloPT)
        Me.PnlLectura.Controls.Add(Me.lblTitulo)
        Me.PnlLectura.Controls.Add(Me.txtClasificacionPT)
        Me.PnlLectura.Controls.Add(Me.Label44)
        Me.PnlLectura.Controls.Add(Me.Label3)
        Me.PnlLectura.Controls.Add(Me.txtresponsable)
        Me.PnlLectura.Controls.Add(Me.cboResponsable)
        Me.PnlLectura.Controls.Add(Me.Label2)
        Me.PnlLectura.Controls.Add(Me.txtf2)
        Me.PnlLectura.Controls.Add(Me.txtf1)
        Me.PnlLectura.Controls.Add(Me.Label1)
        Me.PnlLectura.Controls.Add(Me.f1)
        Me.PnlLectura.Controls.Add(Me.txtcomite)
        Me.PnlLectura.Controls.Add(Me.Label8)
        Me.PnlLectura.Controls.Add(Me.TVcomites)
        Me.PnlLectura.Controls.Add(Me.txttipoTema)
        Me.PnlLectura.Controls.Add(Me.CboTipoTema)
        Me.PnlLectura.Controls.Add(Me.cboRevision)
        Me.PnlLectura.Controls.Add(Me.DT1)
        Me.PnlLectura.Controls.Add(Me.DT2)
        Me.PnlLectura.Controls.Add(Me.chkModTec)
        Me.PnlLectura.Controls.Add(Me.chkNormal)
        Me.PnlLectura.Location = New System.Drawing.Point(184, 8)
        Me.PnlLectura.Name = "PnlLectura"
        Me.PnlLectura.Size = New System.Drawing.Size(472, 656)
        Me.PnlLectura.TabIndex = 2
        '
        'Label95
        '
        Me.Label95.Location = New System.Drawing.Point(16, 344)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(88, 24)
        Me.Label95.TabIndex = 138
        Me.Label95.Text = "Justificaci�n de armonizacion"
        '
        'txtjustarm
        '
        Me.txtjustarm.Location = New System.Drawing.Point(112, 344)
        Me.txtjustarm.Multiline = True
        Me.txtjustarm.Name = "txtjustarm"
        Me.txtjustarm.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtjustarm.Size = New System.Drawing.Size(336, 24)
        Me.txtjustarm.TabIndex = 137
        Me.txtjustarm.Text = ""
        '
        'txtarmonizacion
        '
        Me.txtarmonizacion.Location = New System.Drawing.Point(112, 312)
        Me.txtarmonizacion.Name = "txtarmonizacion"
        Me.txtarmonizacion.Size = New System.Drawing.Size(336, 20)
        Me.txtarmonizacion.TabIndex = 136
        Me.txtarmonizacion.Text = ""
        Me.txtarmonizacion.Visible = False
        '
        'chkarmonizada
        '
        Me.chkarmonizada.Location = New System.Drawing.Point(24, 304)
        Me.chkarmonizada.Name = "chkarmonizada"
        Me.chkarmonizada.Size = New System.Drawing.Size(96, 40)
        Me.chkarmonizada.TabIndex = 135
        Me.chkarmonizada.Text = "Armonizaci�n de Norma"
        '
        'txtreferencia
        '
        Me.txtreferencia.Enabled = False
        Me.txtreferencia.Location = New System.Drawing.Point(112, 16)
        Me.txtreferencia.Name = "txtreferencia"
        Me.txtreferencia.Size = New System.Drawing.Size(192, 20)
        Me.txtreferencia.TabIndex = 133
        Me.txtreferencia.Text = ""
        '
        'Label85
        '
        Me.Label85.Location = New System.Drawing.Point(24, 16)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(80, 24)
        Me.Label85.TabIndex = 134
        Me.Label85.Text = "Referencia"
        '
        'Txtbasada
        '
        Me.Txtbasada.Location = New System.Drawing.Point(112, 272)
        Me.Txtbasada.Name = "Txtbasada"
        Me.Txtbasada.Size = New System.Drawing.Size(336, 20)
        Me.Txtbasada.TabIndex = 9
        Me.Txtbasada.Text = ""
        Me.Txtbasada.Visible = False
        '
        'chkBasada
        '
        Me.chkBasada.Location = New System.Drawing.Point(24, 264)
        Me.chkBasada.Name = "chkBasada"
        Me.chkBasada.Size = New System.Drawing.Size(88, 40)
        Me.chkBasada.TabIndex = 8
        Me.chkBasada.Text = "Basado en Norma Internacional"
        '
        'lblstatus
        '
        Me.lblstatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus.ForeColor = System.Drawing.Color.Blue
        Me.lblstatus.Location = New System.Drawing.Point(312, 112)
        Me.lblstatus.Name = "lblstatus"
        Me.lblstatus.Size = New System.Drawing.Size(112, 24)
        Me.lblstatus.TabIndex = 61
        '
        'txtrevision
        '
        Me.txtrevision.Location = New System.Drawing.Point(112, 384)
        Me.txtrevision.Multiline = True
        Me.txtrevision.Name = "txtrevision"
        Me.txtrevision.Size = New System.Drawing.Size(328, 20)
        Me.txtrevision.TabIndex = 60
        Me.txtrevision.Text = ""
        '
        'Label48
        '
        Me.Label48.Location = New System.Drawing.Point(24, 384)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(72, 24)
        Me.Label48.TabIndex = 59
        Me.Label48.Text = "Revisi�n"
        '
        'txtnumerotema
        '
        Me.txtnumerotema.Location = New System.Drawing.Point(112, 80)
        Me.txtnumerotema.Multiline = True
        Me.txtnumerotema.Name = "txtnumerotema"
        Me.txtnumerotema.Size = New System.Drawing.Size(64, 20)
        Me.txtnumerotema.TabIndex = 1
        Me.txtnumerotema.Text = ""
        '
        'Label47
        '
        Me.Label47.Location = New System.Drawing.Point(24, 80)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(80, 16)
        Me.Label47.TabIndex = 57
        Me.Label47.Text = "N�mero  tema"
        '
        'txtjustificacion
        '
        Me.txtjustificacion.Location = New System.Drawing.Point(112, 208)
        Me.txtjustificacion.Multiline = True
        Me.txtjustificacion.Name = "txtjustificacion"
        Me.txtjustificacion.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtjustificacion.Size = New System.Drawing.Size(336, 24)
        Me.txtjustificacion.TabIndex = 5
        Me.txtjustificacion.Text = ""
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(32, 208)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(72, 24)
        Me.Label46.TabIndex = 55
        Me.Label46.Text = "Justificaci�n"
        '
        'txtobjetivo
        '
        Me.txtobjetivo.Location = New System.Drawing.Point(112, 176)
        Me.txtobjetivo.Multiline = True
        Me.txtobjetivo.Name = "txtobjetivo"
        Me.txtobjetivo.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtobjetivo.Size = New System.Drawing.Size(336, 24)
        Me.txtobjetivo.TabIndex = 4
        Me.txtobjetivo.Text = ""
        '
        'Label45
        '
        Me.Label45.Location = New System.Drawing.Point(32, 176)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(56, 24)
        Me.Label45.TabIndex = 53
        Me.Label45.Text = "Objetivo"
        '
        'txttituloPT
        '
        Me.txttituloPT.Location = New System.Drawing.Point(112, 144)
        Me.txttituloPT.Multiline = True
        Me.txttituloPT.Name = "txttituloPT"
        Me.txttituloPT.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txttituloPT.Size = New System.Drawing.Size(336, 24)
        Me.txttituloPT.TabIndex = 3
        Me.txttituloPT.Text = ""
        '
        'lblTitulo
        '
        Me.lblTitulo.Location = New System.Drawing.Point(32, 144)
        Me.lblTitulo.Name = "lblTitulo"
        Me.lblTitulo.Size = New System.Drawing.Size(56, 24)
        Me.lblTitulo.TabIndex = 51
        Me.lblTitulo.Text = "T�tulo"
        '
        'txtClasificacionPT
        '
        Me.txtClasificacionPT.Location = New System.Drawing.Point(112, 48)
        Me.txtClasificacionPT.Name = "txtClasificacionPT"
        Me.txtClasificacionPT.Size = New System.Drawing.Size(336, 20)
        Me.txtClasificacionPT.TabIndex = 0
        Me.txtClasificacionPT.Text = ""
        '
        'Label44
        '
        Me.Label44.Location = New System.Drawing.Point(24, 48)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(80, 24)
        Me.Label44.TabIndex = 49
        Me.Label44.Text = "Clasificaci�n"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 584)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 24)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Responsable Tema:"
        '
        'txtresponsable
        '
        Me.txtresponsable.Enabled = False
        Me.txtresponsable.Location = New System.Drawing.Point(104, 584)
        Me.txtresponsable.Name = "txtresponsable"
        Me.txtresponsable.Size = New System.Drawing.Size(328, 20)
        Me.txtresponsable.TabIndex = 43
        Me.txtresponsable.Text = ""
        '
        'cboResponsable
        '
        Me.cboResponsable.ItemHeight = 13
        Me.cboResponsable.Location = New System.Drawing.Point(104, 584)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(344, 21)
        Me.cboResponsable.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 23)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "Tipo de Tema:"
        '
        'txtf2
        '
        Me.txtf2.Enabled = False
        Me.txtf2.Location = New System.Drawing.Point(336, 240)
        Me.txtf2.Name = "txtf2"
        Me.txtf2.Size = New System.Drawing.Size(96, 20)
        Me.txtf2.TabIndex = 38
        Me.txtf2.Text = ""
        Me.tltMensaje.SetToolTip(Me.txtf2, "otra cosa")
        '
        'txtf1
        '
        Me.txtf1.Enabled = False
        Me.txtf1.Location = New System.Drawing.Point(112, 240)
        Me.txtf1.Name = "txtf1"
        Me.txtf1.Size = New System.Drawing.Size(104, 20)
        Me.txtf1.TabIndex = 37
        Me.txtf1.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(248, 240)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Fecha de Fin"
        '
        'f1
        '
        Me.f1.Location = New System.Drawing.Point(24, 240)
        Me.f1.Name = "f1"
        Me.f1.Size = New System.Drawing.Size(88, 16)
        Me.f1.TabIndex = 33
        Me.f1.Text = "Fecha de Inicio"
        '
        'txtcomite
        '
        Me.txtcomite.Enabled = False
        Me.txtcomite.Location = New System.Drawing.Point(112, 416)
        Me.txtcomite.Name = "txtcomite"
        Me.txtcomite.Size = New System.Drawing.Size(344, 20)
        Me.txtcomite.TabIndex = 32
        Me.txtcomite.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(24, 416)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 23)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Pertenece:"
        '
        'TVcomites
        '
        Me.TVcomites.ImageList = Me.imgListTreeView
        Me.TVcomites.Location = New System.Drawing.Point(24, 448)
        Me.TVcomites.Name = "TVcomites"
        Me.TVcomites.Size = New System.Drawing.Size(432, 128)
        Me.TVcomites.TabIndex = 15
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'txttipoTema
        '
        Me.txttipoTema.Enabled = False
        Me.txttipoTema.Location = New System.Drawing.Point(112, 112)
        Me.txttipoTema.Name = "txttipoTema"
        Me.txttipoTema.Size = New System.Drawing.Size(184, 20)
        Me.txttipoTema.TabIndex = 40
        Me.txttipoTema.Text = ""
        '
        'CboTipoTema
        '
        Me.CboTipoTema.ItemHeight = 13
        Me.CboTipoTema.Location = New System.Drawing.Point(112, 112)
        Me.CboTipoTema.Name = "CboTipoTema"
        Me.CboTipoTema.Size = New System.Drawing.Size(200, 21)
        Me.CboTipoTema.TabIndex = 2
        '
        'cboRevision
        '
        Me.cboRevision.Location = New System.Drawing.Point(112, 384)
        Me.cboRevision.Name = "cboRevision"
        Me.cboRevision.Size = New System.Drawing.Size(344, 21)
        Me.cboRevision.TabIndex = 10
        '
        'DT1
        '
        Me.DT1.Location = New System.Drawing.Point(112, 240)
        Me.DT1.Name = "DT1"
        Me.DT1.Size = New System.Drawing.Size(120, 20)
        Me.DT1.TabIndex = 62
        '
        'DT2
        '
        Me.DT2.Location = New System.Drawing.Point(336, 240)
        Me.DT2.Name = "DT2"
        Me.DT2.Size = New System.Drawing.Size(112, 20)
        Me.DT2.TabIndex = 63
        '
        'chkModTec
        '
        Me.chkModTec.Location = New System.Drawing.Point(144, 624)
        Me.chkModTec.Name = "chkModTec"
        Me.chkModTec.Size = New System.Drawing.Size(208, 24)
        Me.chkModTec.TabIndex = 132
        Me.chkModTec.Text = "Modificaci�n T�cnica / Cancelacion"
        '
        'chkNormal
        '
        Me.chkNormal.Location = New System.Drawing.Point(24, 624)
        Me.chkNormal.Name = "chkNormal"
        Me.chkNormal.TabIndex = 131
        Me.chkNormal.Text = "Proceso Normal"
        '
        'TVPNN
        '
        Me.TVPNN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TVPNN.ImageIndex = 2
        Me.TVPNN.ImageList = Me.imgListTreeView
        Me.TVPNN.Location = New System.Drawing.Point(8, 8)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = 2
        Me.TVPNN.Size = New System.Drawing.Size(176, 592)
        Me.TVPNN.TabIndex = 13
        '
        'TBpt
        '
        Me.TBpt.Controls.Add(Me.TbPgProgramaTrabajo)
        Me.TBpt.Controls.Add(Me.TbDt)
        Me.TBpt.Controls.Add(Me.tbAnt)
        Me.TBpt.Controls.Add(Me.tbProy)
        Me.TBpt.Controls.Add(Me.TbAvance)
        Me.TBpt.Controls.Add(Me.TpHistorial)
        Me.TBpt.ItemSize = New System.Drawing.Size(111, 18)
        Me.TBpt.Location = New System.Drawing.Point(16, 16)
        Me.TBpt.Name = "TBpt"
        Me.TBpt.SelectedIndex = 0
        Me.TBpt.Size = New System.Drawing.Size(720, 712)
        Me.TBpt.TabIndex = 0
        '
        'TbDt
        '
        Me.TbDt.Controls.Add(Me.pnlProcAlter)
        Me.TbDt.Controls.Add(Me.pnlDt)
        Me.TbDt.Location = New System.Drawing.Point(4, 22)
        Me.TbDt.Name = "TbDt"
        Me.TbDt.Size = New System.Drawing.Size(712, 686)
        Me.TbDt.TabIndex = 1
        Me.TbDt.Text = "Documento de Trabajo"
        '
        'pnlProcAlter
        '
        Me.pnlProcAlter.Controls.Add(Me.grbComTec)
        Me.pnlProcAlter.Controls.Add(Me.fcarga_minuta)
        Me.pnlProcAlter.Controls.Add(Me.Label83)
        Me.pnlProcAlter.Controls.Add(Me.cmdminuta)
        Me.pnlProcAlter.Controls.Add(Me.txtminuta)
        Me.pnlProcAlter.Controls.Add(Me.Label82)
        Me.pnlProcAlter.Controls.Add(Me.Label51)
        Me.pnlProcAlter.Controls.Add(Me.txtf_fin_com)
        Me.pnlProcAlter.Controls.Add(Me.dtfincom)
        Me.pnlProcAlter.Controls.Add(Me.Label10)
        Me.pnlProcAlter.Controls.Add(Me.txtf_inic_com)
        Me.pnlProcAlter.Controls.Add(Me.dtinicom)
        Me.pnlProcAlter.Controls.Add(Me.Label11)
        Me.pnlProcAlter.Controls.Add(Me.txtf_finresp)
        Me.pnlProcAlter.Controls.Add(Me.tdfinresp)
        Me.pnlProcAlter.Controls.Add(Me.Label12)
        Me.pnlProcAlter.Controls.Add(Me.txtf_inicresp)
        Me.pnlProcAlter.Controls.Add(Me.dtiniresp)
        Me.pnlProcAlter.Controls.Add(Me.Label49)
        Me.pnlProcAlter.Controls.Add(Me.Label50)
        Me.pnlProcAlter.Controls.Add(Me.txtresponsable_procalt)
        Me.pnlProcAlter.Controls.Add(Me.cboresponsable_procalt)
        Me.pnlProcAlter.Controls.Add(Me.GrbApDT)
        Me.pnlProcAlter.Controls.Add(Me.GrbComEd)
        Me.pnlProcAlter.Location = New System.Drawing.Point(24, 304)
        Me.pnlProcAlter.Name = "pnlProcAlter"
        Me.pnlProcAlter.Size = New System.Drawing.Size(632, 368)
        Me.pnlProcAlter.TabIndex = 1
        Me.pnlProcAlter.Visible = False
        '
        'grbComTec
        '
        Me.grbComTec.Controls.Add(Me.optComTecSi)
        Me.grbComTec.Controls.Add(Me.optComTecNo)
        Me.grbComTec.Controls.Add(Me.txtnumcomTec)
        Me.grbComTec.Location = New System.Drawing.Point(24, 208)
        Me.grbComTec.Name = "grbComTec"
        Me.grbComTec.Size = New System.Drawing.Size(240, 64)
        Me.grbComTec.TabIndex = 176
        Me.grbComTec.TabStop = False
        Me.grbComTec.Text = "Tuvo Comentarios T�cnicos"
        '
        'optComTecSi
        '
        Me.optComTecSi.Enabled = False
        Me.optComTecSi.Location = New System.Drawing.Point(8, 24)
        Me.optComTecSi.Name = "optComTecSi"
        Me.optComTecSi.Size = New System.Drawing.Size(40, 24)
        Me.optComTecSi.TabIndex = 169
        Me.optComTecSi.Text = "Si"
        '
        'optComTecNo
        '
        Me.optComTecNo.Checked = True
        Me.optComTecNo.Enabled = False
        Me.optComTecNo.Location = New System.Drawing.Point(56, 24)
        Me.optComTecNo.Name = "optComTecNo"
        Me.optComTecNo.Size = New System.Drawing.Size(48, 24)
        Me.optComTecNo.TabIndex = 170
        Me.optComTecNo.TabStop = True
        Me.optComTecNo.Text = "No"
        '
        'txtnumcomTec
        '
        Me.txtnumcomTec.Enabled = False
        Me.txtnumcomTec.Location = New System.Drawing.Point(112, 32)
        Me.txtnumcomTec.Name = "txtnumcomTec"
        Me.txtnumcomTec.TabIndex = 171
        Me.txtnumcomTec.Text = ""
        '
        'fcarga_minuta
        '
        Me.fcarga_minuta.Enabled = False
        Me.fcarga_minuta.Location = New System.Drawing.Point(512, 152)
        Me.fcarga_minuta.Name = "fcarga_minuta"
        Me.fcarga_minuta.Size = New System.Drawing.Size(96, 20)
        Me.fcarga_minuta.TabIndex = 124
        Me.fcarga_minuta.Text = ""
        '
        'Label83
        '
        Me.Label83.Location = New System.Drawing.Point(368, 152)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(136, 48)
        Me.Label83.TabIndex = 123
        Me.Label83.Text = "Fecha de Carga Minuta de Terminaci�n de Procedimiento Alternativo"
        '
        'cmdminuta
        '
        Me.cmdminuta.Location = New System.Drawing.Point(576, 120)
        Me.cmdminuta.Name = "cmdminuta"
        Me.cmdminuta.Size = New System.Drawing.Size(32, 16)
        Me.cmdminuta.TabIndex = 120
        Me.cmdminuta.Text = "....."
        '
        'txtminuta
        '
        Me.txtminuta.Enabled = False
        Me.txtminuta.Location = New System.Drawing.Point(368, 120)
        Me.txtminuta.Name = "txtminuta"
        Me.txtminuta.Size = New System.Drawing.Size(208, 20)
        Me.txtminuta.TabIndex = 119
        Me.txtminuta.Text = ""
        '
        'Label82
        '
        Me.Label82.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(368, 88)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(176, 24)
        Me.Label82.TabIndex = 118
        Me.Label82.Text = "Adjuntar Minuta de Terminaci�n de Procedimiento Alternativo"
        '
        'Label51
        '
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(16, 8)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(152, 24)
        Me.Label51.TabIndex = 106
        Me.Label51.Text = "Procedimiento alternativo"
        '
        'txtf_fin_com
        '
        Me.txtf_fin_com.Enabled = False
        Me.txtf_fin_com.Location = New System.Drawing.Point(176, 176)
        Me.txtf_fin_com.Name = "txtf_fin_com"
        Me.txtf_fin_com.Size = New System.Drawing.Size(96, 20)
        Me.txtf_fin_com.TabIndex = 105
        Me.txtf_fin_com.Text = ""
        '
        'dtfincom
        '
        Me.dtfincom.CustomFormat = "dd/mm/yyyy"
        Me.dtfincom.Location = New System.Drawing.Point(176, 176)
        Me.dtfincom.Name = "dtfincom"
        Me.dtfincom.Size = New System.Drawing.Size(112, 20)
        Me.dtfincom.TabIndex = 103
        Me.dtfincom.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(24, 176)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(152, 24)
        Me.Label10.TabIndex = 104
        Me.Label10.Text = "Fecha de Fin De emisi�n de comentarios "
        '
        'txtf_inic_com
        '
        Me.txtf_inic_com.Enabled = False
        Me.txtf_inic_com.Location = New System.Drawing.Point(176, 136)
        Me.txtf_inic_com.Name = "txtf_inic_com"
        Me.txtf_inic_com.Size = New System.Drawing.Size(96, 20)
        Me.txtf_inic_com.TabIndex = 102
        Me.txtf_inic_com.Text = ""
        '
        'dtinicom
        '
        Me.dtinicom.CustomFormat = "dd/mm/yyyy"
        Me.dtinicom.Location = New System.Drawing.Point(176, 136)
        Me.dtinicom.Name = "dtinicom"
        Me.dtinicom.Size = New System.Drawing.Size(112, 20)
        Me.dtinicom.TabIndex = 100
        Me.dtinicom.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(24, 136)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(144, 32)
        Me.Label11.TabIndex = 101
        Me.Label11.Text = "Fecha de Inicio De emisi�n de comentarios "
        '
        'txtf_finresp
        '
        Me.txtf_finresp.Enabled = False
        Me.txtf_finresp.Location = New System.Drawing.Point(176, 104)
        Me.txtf_finresp.Name = "txtf_finresp"
        Me.txtf_finresp.Size = New System.Drawing.Size(96, 20)
        Me.txtf_finresp.TabIndex = 99
        Me.txtf_finresp.Text = ""
        '
        'tdfinresp
        '
        Me.tdfinresp.CustomFormat = "dd/mm/yyyy"
        Me.tdfinresp.Location = New System.Drawing.Point(176, 104)
        Me.tdfinresp.Name = "tdfinresp"
        Me.tdfinresp.Size = New System.Drawing.Size(112, 20)
        Me.tdfinresp.TabIndex = 97
        Me.tdfinresp.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(24, 104)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(152, 24)
        Me.Label12.TabIndex = 98
        Me.Label12.Text = "Fecha de Fin Responsable"
        '
        'txtf_inicresp
        '
        Me.txtf_inicresp.Enabled = False
        Me.txtf_inicresp.Location = New System.Drawing.Point(176, 72)
        Me.txtf_inicresp.Name = "txtf_inicresp"
        Me.txtf_inicresp.Size = New System.Drawing.Size(96, 20)
        Me.txtf_inicresp.TabIndex = 96
        Me.txtf_inicresp.Text = ""
        '
        'dtiniresp
        '
        Me.dtiniresp.CustomFormat = "dd/mm/yyyy"
        Me.dtiniresp.Location = New System.Drawing.Point(176, 72)
        Me.dtiniresp.Name = "dtiniresp"
        Me.dtiniresp.Size = New System.Drawing.Size(112, 20)
        Me.dtiniresp.TabIndex = 94
        Me.dtiniresp.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label49
        '
        Me.Label49.Location = New System.Drawing.Point(24, 72)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(152, 16)
        Me.Label49.TabIndex = 95
        Me.Label49.Text = "Fecha de Inicio Responsable"
        '
        'Label50
        '
        Me.Label50.Location = New System.Drawing.Point(24, 40)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(136, 24)
        Me.Label50.TabIndex = 91
        Me.Label50.Text = "Responsable Tema Procedimiento Alternativo:"
        '
        'txtresponsable_procalt
        '
        Me.txtresponsable_procalt.Enabled = False
        Me.txtresponsable_procalt.Location = New System.Drawing.Point(176, 40)
        Me.txtresponsable_procalt.Name = "txtresponsable_procalt"
        Me.txtresponsable_procalt.Size = New System.Drawing.Size(248, 20)
        Me.txtresponsable_procalt.TabIndex = 92
        Me.txtresponsable_procalt.Text = ""
        '
        'cboresponsable_procalt
        '
        Me.cboresponsable_procalt.ItemHeight = 13
        Me.cboresponsable_procalt.Location = New System.Drawing.Point(184, 40)
        Me.cboresponsable_procalt.Name = "cboresponsable_procalt"
        Me.cboresponsable_procalt.Size = New System.Drawing.Size(256, 21)
        Me.cboresponsable_procalt.TabIndex = 93
        '
        'GrbApDT
        '
        Me.GrbApDT.Controls.Add(Me.optApDtNo)
        Me.GrbApDT.Controls.Add(Me.optApDtSi)
        Me.GrbApDT.Location = New System.Drawing.Point(280, 216)
        Me.GrbApDT.Name = "GrbApDT"
        Me.GrbApDT.Size = New System.Drawing.Size(136, 48)
        Me.GrbApDT.TabIndex = 0
        Me.GrbApDT.TabStop = False
        Me.GrbApDT.Text = "Aprobado Dt"
        '
        'optApDtNo
        '
        Me.optApDtNo.Checked = True
        Me.optApDtNo.Location = New System.Drawing.Point(72, 16)
        Me.optApDtNo.Name = "optApDtNo"
        Me.optApDtNo.Size = New System.Drawing.Size(56, 24)
        Me.optApDtNo.TabIndex = 169
        Me.optApDtNo.TabStop = True
        Me.optApDtNo.Text = "No"
        '
        'optApDtSi
        '
        Me.optApDtSi.Location = New System.Drawing.Point(8, 16)
        Me.optApDtSi.Name = "optApDtSi"
        Me.optApDtSi.Size = New System.Drawing.Size(56, 24)
        Me.optApDtSi.TabIndex = 168
        Me.optApDtSi.Text = "Si"
        '
        'GrbComEd
        '
        Me.GrbComEd.Controls.Add(Me.txtnumcomed)
        Me.GrbComEd.Controls.Add(Me.optComEdNo)
        Me.GrbComEd.Controls.Add(Me.optComEdSi)
        Me.GrbComEd.Location = New System.Drawing.Point(24, 288)
        Me.GrbComEd.Name = "GrbComEd"
        Me.GrbComEd.Size = New System.Drawing.Size(240, 56)
        Me.GrbComEd.TabIndex = 0
        Me.GrbComEd.TabStop = False
        Me.GrbComEd.Text = "Tuvo Comentarios Editoriales"
        '
        'txtnumcomed
        '
        Me.txtnumcomed.Enabled = False
        Me.txtnumcomed.Location = New System.Drawing.Point(112, 24)
        Me.txtnumcomed.Name = "txtnumcomed"
        Me.txtnumcomed.TabIndex = 178
        Me.txtnumcomed.Text = ""
        '
        'optComEdNo
        '
        Me.optComEdNo.Checked = True
        Me.optComEdNo.Enabled = False
        Me.optComEdNo.Location = New System.Drawing.Point(56, 24)
        Me.optComEdNo.Name = "optComEdNo"
        Me.optComEdNo.Size = New System.Drawing.Size(48, 24)
        Me.optComEdNo.TabIndex = 177
        Me.optComEdNo.TabStop = True
        Me.optComEdNo.Text = "No"
        '
        'optComEdSi
        '
        Me.optComEdSi.Enabled = False
        Me.optComEdSi.Location = New System.Drawing.Point(8, 24)
        Me.optComEdSi.Name = "optComEdSi"
        Me.optComEdSi.Size = New System.Drawing.Size(40, 24)
        Me.optComEdSi.TabIndex = 176
        Me.optComEdSi.Text = "Si"
        '
        'pnlDt
        '
        Me.pnlDt.Controls.Add(Me.chkrevedit)
        Me.pnlDt.Controls.Add(Me.chkAlternativo)
        Me.pnlDt.Controls.Add(Me.txtfcargaDtFinal)
        Me.pnlDt.Controls.Add(Me.Label18)
        Me.pnlDt.Controls.Add(Me.txtadjDtf)
        Me.pnlDt.Controls.Add(Me.cmdDt)
        Me.pnlDt.Controls.Add(Me.Label16)
        Me.pnlDt.Controls.Add(Me.txttitulodt)
        Me.pnlDt.Controls.Add(Me.Label56)
        Me.pnlDt.Controls.Add(Me.Label55)
        Me.pnlDt.Controls.Add(Me.txtclasificaciondt)
        Me.pnlDt.Controls.Add(Me.txtAprob_Revision_Editorial)
        Me.pnlDt.Controls.Add(Me.Label7)
        Me.pnlDt.Controls.Add(Me.Label6)
        Me.pnlDt.Controls.Add(Me.txtresponsableDt)
        Me.pnlDt.Controls.Add(Me.CboResponsableDt)
        Me.pnlDt.Controls.Add(Me.txtf_des_Nmx)
        Me.pnlDt.Controls.Add(Me.Label4)
        Me.pnlDt.Controls.Add(Me.Label9)
        Me.pnlDt.Location = New System.Drawing.Point(24, 24)
        Me.pnlDt.Name = "pnlDt"
        Me.pnlDt.Size = New System.Drawing.Size(632, 256)
        Me.pnlDt.TabIndex = 0
        '
        'chkrevedit
        '
        Me.chkrevedit.Checked = True
        Me.chkrevedit.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkrevedit.Location = New System.Drawing.Point(432, 16)
        Me.chkrevedit.Name = "chkrevedit"
        Me.chkrevedit.Size = New System.Drawing.Size(112, 24)
        Me.chkrevedit.TabIndex = 129
        Me.chkrevedit.Text = "Revisi�n Editorial"
        '
        'chkAlternativo
        '
        Me.chkAlternativo.Location = New System.Drawing.Point(32, 32)
        Me.chkAlternativo.Name = "chkAlternativo"
        Me.chkAlternativo.Size = New System.Drawing.Size(168, 24)
        Me.chkAlternativo.TabIndex = 128
        Me.chkAlternativo.Text = "Procedimiento Alternativo:"
        '
        'txtfcargaDtFinal
        '
        Me.txtfcargaDtFinal.Enabled = False
        Me.txtfcargaDtFinal.Location = New System.Drawing.Point(504, 184)
        Me.txtfcargaDtFinal.Name = "txtfcargaDtFinal"
        Me.txtfcargaDtFinal.Size = New System.Drawing.Size(96, 20)
        Me.txtfcargaDtFinal.TabIndex = 124
        Me.txtfcargaDtFinal.Text = ""
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(392, 184)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(104, 40)
        Me.Label18.TabIndex = 123
        Me.Label18.Text = "Fecha de Carga Documento de Trabajo Final"
        '
        'txtadjDtf
        '
        Me.txtadjDtf.Enabled = False
        Me.txtadjDtf.Location = New System.Drawing.Point(152, 192)
        Me.txtadjDtf.Name = "txtadjDtf"
        Me.txtadjDtf.Size = New System.Drawing.Size(200, 20)
        Me.txtadjDtf.TabIndex = 120
        Me.txtadjDtf.Text = ""
        '
        'cmdDt
        '
        Me.cmdDt.Location = New System.Drawing.Point(352, 192)
        Me.cmdDt.Name = "cmdDt"
        Me.cmdDt.Size = New System.Drawing.Size(32, 16)
        Me.cmdDt.TabIndex = 116
        Me.cmdDt.Text = "....."
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(24, 192)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(128, 48)
        Me.Label16.TabIndex = 114
        Me.Label16.Text = "Adjuntar Documento de Trabajo Final"
        '
        'txttitulodt
        '
        Me.txttitulodt.Location = New System.Drawing.Point(152, 88)
        Me.txttitulodt.Multiline = True
        Me.txttitulodt.Name = "txttitulodt"
        Me.txttitulodt.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txttitulodt.Size = New System.Drawing.Size(448, 20)
        Me.txttitulodt.TabIndex = 17
        Me.txttitulodt.Text = ""
        '
        'Label56
        '
        Me.Label56.Location = New System.Drawing.Point(24, 88)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(72, 23)
        Me.Label56.TabIndex = 108
        Me.Label56.Text = "T�tulo DT"
        '
        'Label55
        '
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(24, 8)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(176, 24)
        Me.Label55.TabIndex = 107
        Me.Label55.Text = "Etapa Documento de Trabajo"
        '
        'txtclasificaciondt
        '
        Me.txtclasificaciondt.Location = New System.Drawing.Point(152, 56)
        Me.txtclasificaciondt.Name = "txtclasificaciondt"
        Me.txtclasificaciondt.Size = New System.Drawing.Size(448, 20)
        Me.txtclasificaciondt.TabIndex = 16
        Me.txtclasificaciondt.Text = ""
        '
        'txtAprob_Revision_Editorial
        '
        Me.txtAprob_Revision_Editorial.Location = New System.Drawing.Point(504, 120)
        Me.txtAprob_Revision_Editorial.Name = "txtAprob_Revision_Editorial"
        Me.txtAprob_Revision_Editorial.Size = New System.Drawing.Size(96, 20)
        Me.txtAprob_Revision_Editorial.TabIndex = 69
        Me.txtAprob_Revision_Editorial.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(280, 120)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(224, 24)
        Me.Label7.TabIndex = 68
        Me.Label7.Text = "Fecha de Aprobaci�n de Revisi�n Editorial"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(24, 160)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 24)
        Me.Label6.TabIndex = 64
        Me.Label6.Text = "Responsable Tema:"
        '
        'txtresponsableDt
        '
        Me.txtresponsableDt.Enabled = False
        Me.txtresponsableDt.Location = New System.Drawing.Point(152, 160)
        Me.txtresponsableDt.Name = "txtresponsableDt"
        Me.txtresponsableDt.Size = New System.Drawing.Size(312, 20)
        Me.txtresponsableDt.TabIndex = 65
        Me.txtresponsableDt.Text = ""
        '
        'CboResponsableDt
        '
        Me.CboResponsableDt.ItemHeight = 13
        Me.CboResponsableDt.Location = New System.Drawing.Point(152, 160)
        Me.CboResponsableDt.Name = "CboResponsableDt"
        Me.CboResponsableDt.Size = New System.Drawing.Size(328, 21)
        Me.CboResponsableDt.TabIndex = 19
        '
        'txtf_des_Nmx
        '
        Me.txtf_des_Nmx.Enabled = False
        Me.txtf_des_Nmx.ForeColor = System.Drawing.Color.Red
        Me.txtf_des_Nmx.Location = New System.Drawing.Point(152, 120)
        Me.txtf_des_Nmx.Name = "txtf_des_Nmx"
        Me.txtf_des_Nmx.Size = New System.Drawing.Size(96, 20)
        Me.txtf_des_Nmx.TabIndex = 63
        Me.txtf_des_Nmx.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(24, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 40)
        Me.Label4.TabIndex = 62
        Me.Label4.Text = "Fecha de Inicio de Desarrollo de NMX"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(24, 64)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 23)
        Me.Label9.TabIndex = 58
        Me.Label9.Text = "Clasificaci�n"
        '
        'tbAnt
        '
        Me.tbAnt.Controls.Add(Me.pnlAnt)
        Me.tbAnt.Location = New System.Drawing.Point(4, 22)
        Me.tbAnt.Name = "tbAnt"
        Me.tbAnt.Size = New System.Drawing.Size(712, 686)
        Me.tbAnt.TabIndex = 2
        Me.tbAnt.Text = "Anteproyecto"
        '
        'pnlAnt
        '
        Me.pnlAnt.Controls.Add(Me.TextBox2)
        Me.pnlAnt.Controls.Add(Me.Label88)
        Me.pnlAnt.Controls.Add(Me.TextBox3)
        Me.pnlAnt.Controls.Add(Me.Button1)
        Me.pnlAnt.Controls.Add(Me.Label89)
        Me.pnlAnt.Controls.Add(Me.optCorrNo)
        Me.pnlAnt.Controls.Add(Me.optCorrSi)
        Me.pnlAnt.Controls.Add(Me.Label87)
        Me.pnlAnt.Controls.Add(Me.txtF_Correcciones)
        Me.pnlAnt.Controls.Add(Me.dtpFCorrec)
        Me.pnlAnt.Controls.Add(Me.Label86)
        Me.pnlAnt.Controls.Add(Me.txtfcargaActaprobFinal)
        Me.pnlAnt.Controls.Add(Me.Label17)
        Me.pnlAnt.Controls.Add(Me.txtf_impActAprob)
        Me.pnlAnt.Controls.Add(Me.Label15)
        Me.pnlAnt.Controls.Add(Me.cmdacta)
        Me.pnlAnt.Controls.Add(Me.txtadjActAprobFinal)
        Me.pnlAnt.Controls.Add(Me.Label54)
        Me.pnlAnt.Controls.Add(Me.Label52)
        Me.pnlAnt.Controls.Add(Me.CmdActaAprobacion)
        Me.pnlAnt.Controls.Add(Me.txtf_aprobCtGT)
        Me.pnlAnt.Controls.Add(Me.dtf_aprobCtGT)
        Me.pnlAnt.Controls.Add(Me.Label20)
        Me.pnlAnt.Controls.Add(Me.txtcarg_antfinal)
        Me.pnlAnt.Controls.Add(Me.Label31)
        Me.pnlAnt.Controls.Add(Me.txtadjantF)
        Me.pnlAnt.Controls.Add(Me.cmdant)
        Me.pnlAnt.Controls.Add(Me.Label32)
        Me.pnlAnt.Controls.Add(Me.txtclasificacion_ant)
        Me.pnlAnt.Controls.Add(Me.txttituloant)
        Me.pnlAnt.Controls.Add(Me.Label29)
        Me.pnlAnt.Controls.Add(Me.Label27)
        Me.pnlAnt.Controls.Add(Me.Label21)
        Me.pnlAnt.Controls.Add(Me.txtresponsable_ant)
        Me.pnlAnt.Controls.Add(Me.cboresponsable_ant)
        Me.pnlAnt.Controls.Add(Me.Label19)
        Me.pnlAnt.Controls.Add(Me.txtnumpags_Ant)
        Me.pnlAnt.Controls.Add(Me.Label13)
        Me.pnlAnt.Controls.Add(Me.Label14)
        Me.pnlAnt.Enabled = False
        Me.pnlAnt.Location = New System.Drawing.Point(16, 16)
        Me.pnlAnt.Name = "pnlAnt"
        Me.pnlAnt.Size = New System.Drawing.Size(624, 576)
        Me.pnlAnt.TabIndex = 59
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(520, 416)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(96, 20)
        Me.TextBox2.TabIndex = 152
        Me.TextBox2.Text = ""
        '
        'Label88
        '
        Me.Label88.Location = New System.Drawing.Point(408, 416)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(120, 32)
        Me.Label88.TabIndex = 151
        Me.Label88.Text = "Fecha de Carga Minuta de Aprobaci�n:"
        '
        'TextBox3
        '
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(160, 424)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(200, 20)
        Me.TextBox3.TabIndex = 150
        Me.TextBox3.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(360, 424)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(32, 16)
        Me.Button1.TabIndex = 149
        Me.Button1.Text = "....."
        '
        'Label89
        '
        Me.Label89.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(32, 424)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(128, 16)
        Me.Label89.TabIndex = 148
        Me.Label89.Text = "Minuta de Aprobaci�n"
        '
        'optCorrNo
        '
        Me.optCorrNo.Location = New System.Drawing.Point(280, 352)
        Me.optCorrNo.Name = "optCorrNo"
        Me.optCorrNo.TabIndex = 147
        Me.optCorrNo.Text = "No"
        '
        'optCorrSi
        '
        Me.optCorrSi.Location = New System.Drawing.Point(168, 352)
        Me.optCorrSi.Name = "optCorrSi"
        Me.optCorrSi.TabIndex = 146
        Me.optCorrSi.Text = "Si"
        '
        'Label87
        '
        Me.Label87.Location = New System.Drawing.Point(40, 360)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(72, 24)
        Me.Label87.TabIndex = 145
        Me.Label87.Text = "Correciones"
        '
        'txtF_Correcciones
        '
        Me.txtF_Correcciones.Enabled = False
        Me.txtF_Correcciones.Location = New System.Drawing.Point(224, 392)
        Me.txtF_Correcciones.Name = "txtF_Correcciones"
        Me.txtF_Correcciones.Size = New System.Drawing.Size(96, 20)
        Me.txtF_Correcciones.TabIndex = 144
        Me.txtF_Correcciones.Text = ""
        '
        'dtpFCorrec
        '
        Me.dtpFCorrec.CustomFormat = "dd/mm/yyyy"
        Me.dtpFCorrec.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpFCorrec.Location = New System.Drawing.Point(224, 392)
        Me.dtpFCorrec.Name = "dtpFCorrec"
        Me.dtpFCorrec.Size = New System.Drawing.Size(112, 20)
        Me.dtpFCorrec.TabIndex = 143
        Me.dtpFCorrec.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label86
        '
        Me.Label86.Location = New System.Drawing.Point(40, 392)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(136, 24)
        Me.Label86.TabIndex = 142
        Me.Label86.Text = "Fecha de Correciones"
        '
        'txtfcargaActaprobFinal
        '
        Me.txtfcargaActaprobFinal.Enabled = False
        Me.txtfcargaActaprobFinal.Location = New System.Drawing.Point(520, 312)
        Me.txtfcargaActaprobFinal.Name = "txtfcargaActaprobFinal"
        Me.txtfcargaActaprobFinal.Size = New System.Drawing.Size(96, 20)
        Me.txtfcargaActaprobFinal.TabIndex = 141
        Me.txtfcargaActaprobFinal.Text = ""
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(408, 312)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(104, 40)
        Me.Label17.TabIndex = 140
        Me.Label17.Text = "Fecha de Carga Acta Aprobaci�n Final"
        '
        'txtf_impActAprob
        '
        Me.txtf_impActAprob.Location = New System.Drawing.Point(512, 224)
        Me.txtf_impActAprob.Name = "txtf_impActAprob"
        Me.txtf_impActAprob.Size = New System.Drawing.Size(96, 20)
        Me.txtf_impActAprob.TabIndex = 139
        Me.txtf_impActAprob.Text = ""
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(288, 224)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(192, 24)
        Me.Label15.TabIndex = 138
        Me.Label15.Text = "Fecha de Impresi�n acta Aprobaci�n"
        '
        'cmdacta
        '
        Me.cmdacta.Location = New System.Drawing.Point(368, 312)
        Me.cmdacta.Name = "cmdacta"
        Me.cmdacta.Size = New System.Drawing.Size(32, 16)
        Me.cmdacta.TabIndex = 137
        Me.cmdacta.Text = "....."
        '
        'txtadjActAprobFinal
        '
        Me.txtadjActAprobFinal.Enabled = False
        Me.txtadjActAprobFinal.Location = New System.Drawing.Point(168, 312)
        Me.txtadjActAprobFinal.Name = "txtadjActAprobFinal"
        Me.txtadjActAprobFinal.Size = New System.Drawing.Size(200, 20)
        Me.txtadjActAprobFinal.TabIndex = 136
        Me.txtadjActAprobFinal.Text = ""
        '
        'Label54
        '
        Me.Label54.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(40, 312)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(144, 24)
        Me.Label54.TabIndex = 135
        Me.Label54.Text = "Adjuntar Acta Aprobaci�n Final"
        '
        'Label52
        '
        Me.Label52.Location = New System.Drawing.Point(32, 224)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(128, 32)
        Me.Label52.TabIndex = 134
        Me.Label52.Text = "Imprimir acta de Aprobaci�n"
        '
        'CmdActaAprobacion
        '
        Me.CmdActaAprobacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdActaAprobacion.ImageIndex = 7
        Me.CmdActaAprobacion.ImageList = Me.ImgListBotonera
        Me.CmdActaAprobacion.Location = New System.Drawing.Point(184, 200)
        Me.CmdActaAprobacion.Name = "CmdActaAprobacion"
        Me.CmdActaAprobacion.Size = New System.Drawing.Size(56, 48)
        Me.CmdActaAprobacion.TabIndex = 133
        '
        'txtf_aprobCtGT
        '
        Me.txtf_aprobCtGT.Location = New System.Drawing.Point(224, 272)
        Me.txtf_aprobCtGT.Name = "txtf_aprobCtGT"
        Me.txtf_aprobCtGT.Size = New System.Drawing.Size(96, 20)
        Me.txtf_aprobCtGT.TabIndex = 132
        Me.txtf_aprobCtGT.Text = ""
        '
        'dtf_aprobCtGT
        '
        Me.dtf_aprobCtGT.CustomFormat = "dd/MM/yyyy"
        Me.dtf_aprobCtGT.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtf_aprobCtGT.Location = New System.Drawing.Point(224, 272)
        Me.dtf_aprobCtGT.Name = "dtf_aprobCtGT"
        Me.dtf_aprobCtGT.Size = New System.Drawing.Size(112, 20)
        Me.dtf_aprobCtGT.TabIndex = 131
        Me.dtf_aprobCtGT.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(40, 272)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(176, 24)
        Me.Label20.TabIndex = 130
        Me.Label20.Text = "Fecha de Aprobaci�n del CT o Gt"
        '
        'txtcarg_antfinal
        '
        Me.txtcarg_antfinal.Enabled = False
        Me.txtcarg_antfinal.Location = New System.Drawing.Point(512, 456)
        Me.txtcarg_antfinal.Name = "txtcarg_antfinal"
        Me.txtcarg_antfinal.Size = New System.Drawing.Size(96, 20)
        Me.txtcarg_antfinal.TabIndex = 129
        Me.txtcarg_antfinal.Text = ""
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(400, 456)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(104, 32)
        Me.Label31.TabIndex = 128
        Me.Label31.Text = "Fecha de Carga Anteproyecto Final"
        '
        'txtadjantF
        '
        Me.txtadjantF.Enabled = False
        Me.txtadjantF.Location = New System.Drawing.Point(152, 464)
        Me.txtadjantF.Name = "txtadjantF"
        Me.txtadjantF.Size = New System.Drawing.Size(200, 20)
        Me.txtadjantF.TabIndex = 127
        Me.txtadjantF.Text = ""
        '
        'cmdant
        '
        Me.cmdant.Location = New System.Drawing.Point(352, 464)
        Me.cmdant.Name = "cmdant"
        Me.cmdant.Size = New System.Drawing.Size(32, 16)
        Me.cmdant.TabIndex = 126
        Me.cmdant.Text = "....."
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(24, 464)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(116, 16)
        Me.Label32.TabIndex = 125
        Me.Label32.Text = "Adjuntar Anteproyecto"
        '
        'txtclasificacion_ant
        '
        Me.txtclasificacion_ant.Location = New System.Drawing.Point(128, 56)
        Me.txtclasificacion_ant.Name = "txtclasificacion_ant"
        Me.txtclasificacion_ant.Size = New System.Drawing.Size(312, 20)
        Me.txtclasificacion_ant.TabIndex = 111
        Me.txtclasificacion_ant.Text = ""
        '
        'txttituloant
        '
        Me.txttituloant.Location = New System.Drawing.Point(128, 96)
        Me.txttituloant.Name = "txttituloant"
        Me.txttituloant.Size = New System.Drawing.Size(312, 20)
        Me.txttituloant.TabIndex = 109
        Me.txttituloant.Text = ""
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(32, 96)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(72, 23)
        Me.Label29.TabIndex = 110
        Me.Label29.Text = "T�tulo Ant"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(24, 8)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(112, 16)
        Me.Label27.TabIndex = 76
        Me.Label27.Text = "Anteproyecto"
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(32, 168)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(72, 24)
        Me.Label21.TabIndex = 73
        Me.Label21.Text = "Responsable Tema:"
        '
        'txtresponsable_ant
        '
        Me.txtresponsable_ant.Enabled = False
        Me.txtresponsable_ant.Location = New System.Drawing.Point(120, 168)
        Me.txtresponsable_ant.Name = "txtresponsable_ant"
        Me.txtresponsable_ant.Size = New System.Drawing.Size(328, 20)
        Me.txtresponsable_ant.TabIndex = 74
        Me.txtresponsable_ant.Text = ""
        '
        'cboresponsable_ant
        '
        Me.cboresponsable_ant.ItemHeight = 13
        Me.cboresponsable_ant.Location = New System.Drawing.Point(120, 168)
        Me.cboresponsable_ant.Name = "cboresponsable_ant"
        Me.cboresponsable_ant.Size = New System.Drawing.Size(344, 21)
        Me.cboresponsable_ant.TabIndex = 75
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(24, 136)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 24)
        Me.Label19.TabIndex = 68
        Me.Label19.Text = "N�mero de P�ginas"
        '
        'txtnumpags_Ant
        '
        Me.txtnumpags_Ant.Enabled = False
        Me.txtnumpags_Ant.Location = New System.Drawing.Point(128, 136)
        Me.txtnumpags_Ant.Name = "txtnumpags_Ant"
        Me.txtnumpags_Ant.Size = New System.Drawing.Size(88, 20)
        Me.txtnumpags_Ant.TabIndex = 69
        Me.txtnumpags_Ant.Text = ""
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(264, 24)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(8, 23)
        Me.Label13.TabIndex = 66
        Me.Label13.Text = "-"
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(24, 64)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 23)
        Me.Label14.TabIndex = 65
        Me.Label14.Text = "Clasificaci�n"
        '
        'tbProy
        '
        Me.tbProy.Controls.Add(Me.pnlproy)
        Me.tbProy.Location = New System.Drawing.Point(4, 22)
        Me.tbProy.Name = "tbProy"
        Me.tbProy.Size = New System.Drawing.Size(712, 686)
        Me.tbProy.TabIndex = 5
        Me.tbProy.Text = "Proyecto"
        '
        'pnlproy
        '
        Me.pnlproy.Controls.Add(Me.chkCambiaNorma)
        Me.pnlproy.Controls.Add(Me.txtPaginasNorma)
        Me.pnlproy.Controls.Add(Me.txtFechaDeclaratoriaVigencia)
        Me.pnlproy.Controls.Add(Me.Label110)
        Me.pnlproy.Controls.Add(Me.txtProyectoFinal)
        Me.pnlproy.Controls.Add(Me.cmdProyectoFinal)
        Me.pnlproy.Controls.Add(Me.Label98)
        Me.pnlproy.Controls.Add(Me.txtf_ap2)
        Me.pnlproy.Controls.Add(Me.DTf_ap_res2)
        Me.pnlproy.Controls.Add(Me.Label93)
        Me.pnlproy.Controls.Add(Me.Label90)
        Me.pnlproy.Controls.Add(Me.GroupBox1)
        Me.pnlproy.Controls.Add(Me.txtdifDates)
        Me.pnlproy.Controls.Add(Me.txtfverifrefProy)
        Me.pnlproy.Controls.Add(Me.Label94)
        Me.pnlproy.Controls.Add(Me.dpFverif_rev)
        Me.pnlproy.Controls.Add(Me.txtadjactPROYF)
        Me.pnlproy.Controls.Add(Me.cmdproyf)
        Me.pnlproy.Controls.Add(Me.Label80)
        Me.pnlproy.Controls.Add(Me.txtadjProyfinal)
        Me.pnlproy.Controls.Add(Me.cmdProy)
        Me.pnlproy.Controls.Add(Me.Label79)
        Me.pnlproy.Controls.Add(Me.Label33)
        Me.pnlproy.Controls.Add(Me.cmdactaAprobacion_Proy)
        Me.pnlproy.Controls.Add(Me.txtfCargaProyf)
        Me.pnlproy.Controls.Add(Me.Label36)
        Me.pnlproy.Controls.Add(Me.txtacusePROYF)
        Me.pnlproy.Controls.Add(Me.Label37)
        Me.pnlproy.Controls.Add(Me.txtfcarga_actaprobPROYF)
        Me.pnlproy.Controls.Add(Me.Label38)
        Me.pnlproy.Controls.Add(Me.txtf_imp_actaprob_proy)
        Me.pnlproy.Controls.Add(Me.Label39)
        Me.pnlproy.Controls.Add(Me.txtf_edic)
        Me.pnlproy.Controls.Add(Me.Label40)
        Me.pnlproy.Controls.Add(Me.txtftermrev)
        Me.pnlproy.Controls.Add(Me.Label41)
        Me.pnlproy.Controls.Add(Me.txtfiniRev)
        Me.pnlproy.Controls.Add(Me.Label42)
        Me.pnlproy.Controls.Add(Me.txtvobo)
        Me.pnlproy.Controls.Add(Me.Label43)
        Me.pnlproy.Controls.Add(Me.txtf_aprobrescompub)
        Me.pnlproy.Controls.Add(Me.Label53)
        Me.pnlproy.Controls.Add(Me.txtfResolucion)
        Me.pnlproy.Controls.Add(Me.Label78)
        Me.pnlproy.Controls.Add(Me.TXTF_limrescompub)
        Me.pnlproy.Controls.Add(Me.Label35)
        Me.pnlproy.Controls.Add(Me.txtf_aprob_com)
        Me.pnlproy.Controls.Add(Me.Label34)
        Me.pnlproy.Controls.Add(Me.txttitulo_Proy)
        Me.pnlproy.Controls.Add(Me.Label30)
        Me.pnlproy.Controls.Add(Me.Label28)
        Me.pnlproy.Controls.Add(Me.txtclasificacion_proy)
        Me.pnlproy.Controls.Add(Me.Label26)
        Me.pnlproy.Controls.Add(Me.Label22)
        Me.pnlproy.Controls.Add(Me.txtresponsable_proy)
        Me.pnlproy.Controls.Add(Me.cboResponsable_proy)
        Me.pnlproy.Controls.Add(Me.txtf_limitecompub)
        Me.pnlproy.Controls.Add(Me.dtF_Fin)
        Me.pnlproy.Controls.Add(Me.Label23)
        Me.pnlproy.Controls.Add(Me.txtf_ini_compub)
        Me.pnlproy.Controls.Add(Me.dtF_inicio)
        Me.pnlproy.Controls.Add(Me.Label24)
        Me.pnlproy.Controls.Add(Me.Label25)
        Me.pnlproy.Controls.Add(Me.txtpaginas_proy)
        Me.pnlproy.Controls.Add(Me.DTf_aprobComproy)
        Me.pnlproy.Controls.Add(Me.dtresolucion)
        Me.pnlproy.Controls.Add(Me.dtf_aprobrescompub)
        Me.pnlproy.Controls.Add(Me.dtvobo)
        Me.pnlproy.Controls.Add(Me.dtfiniRev)
        Me.pnlproy.Controls.Add(Me.dtftermrev)
        Me.pnlproy.Controls.Add(Me.dtF_limrescompub)
        Me.pnlproy.Controls.Add(Me.dtf_edic)
        Me.pnlproy.Controls.Add(Me.dtacusePROYF)
        Me.pnlproy.Controls.Add(Me.GroupBox2)
        Me.pnlproy.Location = New System.Drawing.Point(8, 8)
        Me.pnlproy.Name = "pnlproy"
        Me.pnlproy.Size = New System.Drawing.Size(688, 664)
        Me.pnlproy.TabIndex = 61
        '
        'chkCambiaNorma
        '
        Me.chkCambiaNorma.Location = New System.Drawing.Point(608, 587)
        Me.chkCambiaNorma.Name = "chkCambiaNorma"
        Me.chkCambiaNorma.Size = New System.Drawing.Size(16, 16)
        Me.chkCambiaNorma.TabIndex = 185
        Me.chkCambiaNorma.Text = "Pasar a norma"
        '
        'txtPaginasNorma
        '
        Me.txtPaginasNorma.Location = New System.Drawing.Point(504, 584)
        Me.txtPaginasNorma.Name = "txtPaginasNorma"
        Me.txtPaginasNorma.Size = New System.Drawing.Size(96, 20)
        Me.txtPaginasNorma.TabIndex = 184
        Me.txtPaginasNorma.Text = ""
        '
        'txtFechaDeclaratoriaVigencia
        '
        Me.txtFechaDeclaratoriaVigencia.Enabled = False
        Me.txtFechaDeclaratoriaVigencia.Location = New System.Drawing.Point(520, 624)
        Me.txtFechaDeclaratoriaVigencia.Name = "txtFechaDeclaratoriaVigencia"
        Me.txtFechaDeclaratoriaVigencia.Size = New System.Drawing.Size(96, 20)
        Me.txtFechaDeclaratoriaVigencia.TabIndex = 183
        Me.txtFechaDeclaratoriaVigencia.Text = ""
        Me.txtFechaDeclaratoriaVigencia.Visible = False
        '
        'Label110
        '
        Me.Label110.Location = New System.Drawing.Point(328, 584)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(168, 24)
        Me.Label110.TabIndex = 182
        Me.Label110.Text = "N�mero de P�ginas de la Norma"
        '
        'txtProyectoFinal
        '
        Me.txtProyectoFinal.Enabled = False
        Me.txtProyectoFinal.Location = New System.Drawing.Point(440, 344)
        Me.txtProyectoFinal.Name = "txtProyectoFinal"
        Me.txtProyectoFinal.ReadOnly = True
        Me.txtProyectoFinal.Size = New System.Drawing.Size(208, 20)
        Me.txtProyectoFinal.TabIndex = 181
        Me.txtProyectoFinal.Text = ""
        '
        'cmdProyectoFinal
        '
        Me.cmdProyectoFinal.Location = New System.Drawing.Point(648, 344)
        Me.cmdProyectoFinal.Name = "cmdProyectoFinal"
        Me.cmdProyectoFinal.Size = New System.Drawing.Size(32, 16)
        Me.cmdProyectoFinal.TabIndex = 180
        Me.cmdProyectoFinal.Text = "....."
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(328, 344)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(80, 16)
        Me.Label98.TabIndex = 179
        Me.Label98.Text = "Proyecto Final:"
        '
        'txtf_ap2
        '
        Me.txtf_ap2.Enabled = False
        Me.txtf_ap2.Location = New System.Drawing.Point(208, 424)
        Me.txtf_ap2.Name = "txtf_ap2"
        Me.txtf_ap2.Size = New System.Drawing.Size(96, 20)
        Me.txtf_ap2.TabIndex = 176
        Me.txtf_ap2.Text = ""
        '
        'DTf_ap_res2
        '
        Me.DTf_ap_res2.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.DTf_ap_res2.Location = New System.Drawing.Point(208, 424)
        Me.DTf_ap_res2.Name = "DTf_ap_res2"
        Me.DTf_ap_res2.Size = New System.Drawing.Size(112, 20)
        Me.DTf_ap_res2.TabIndex = 178
        '
        'Label93
        '
        Me.Label93.Location = New System.Drawing.Point(8, 392)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(184, 23)
        Me.Label93.TabIndex = 177
        Me.Label93.Text = "Fecha de aprobaci�n de extensi�n"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(328, 184)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(107, 16)
        Me.Label90.TabIndex = 174
        Me.Label90.Text = "Diferencia de fechas"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtnumcomedProy)
        Me.GroupBox1.Controls.Add(Me.RadioButton9)
        Me.GroupBox1.Controls.Add(Me.optComEdSiProy)
        Me.GroupBox1.Location = New System.Drawing.Point(256, 248)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(224, 48)
        Me.GroupBox1.TabIndex = 173
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tuvo Comentarios Editoriales"
        '
        'txtnumcomedProy
        '
        Me.txtnumcomedProy.Enabled = False
        Me.txtnumcomedProy.Location = New System.Drawing.Point(112, 16)
        Me.txtnumcomedProy.Name = "txtnumcomedProy"
        Me.txtnumcomedProy.TabIndex = 169
        Me.txtnumcomedProy.Text = ""
        '
        'RadioButton9
        '
        Me.RadioButton9.Checked = True
        Me.RadioButton9.Enabled = False
        Me.RadioButton9.Location = New System.Drawing.Point(56, 16)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(48, 24)
        Me.RadioButton9.TabIndex = 168
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "No"
        '
        'optComEdSiProy
        '
        Me.optComEdSiProy.Enabled = False
        Me.optComEdSiProy.Location = New System.Drawing.Point(8, 16)
        Me.optComEdSiProy.Name = "optComEdSiProy"
        Me.optComEdSiProy.Size = New System.Drawing.Size(40, 24)
        Me.optComEdSiProy.TabIndex = 167
        Me.optComEdSiProy.Text = "Si"
        '
        'txtdifDates
        '
        Me.txtdifDates.Enabled = False
        Me.txtdifDates.Location = New System.Drawing.Point(328, 208)
        Me.txtdifDates.Name = "txtdifDates"
        Me.txtdifDates.TabIndex = 172
        Me.txtdifDates.Text = ""
        '
        'txtfverifrefProy
        '
        Me.txtfverifrefProy.Enabled = False
        Me.txtfverifrefProy.Location = New System.Drawing.Point(208, 552)
        Me.txtfverifrefProy.Name = "txtfverifrefProy"
        Me.txtfverifrefProy.Size = New System.Drawing.Size(96, 20)
        Me.txtfverifrefProy.TabIndex = 170
        Me.txtfverifrefProy.Text = ""
        '
        'Label94
        '
        Me.Label94.Location = New System.Drawing.Point(8, 552)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(152, 24)
        Me.Label94.TabIndex = 169
        Me.Label94.Text = "Fecha de verificacion de revision de PROYF"
        '
        'dpFverif_rev
        '
        Me.dpFverif_rev.CustomFormat = "dd/mm/yyyy"
        Me.dpFverif_rev.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dpFverif_rev.Location = New System.Drawing.Point(208, 552)
        Me.dpFverif_rev.Name = "dpFverif_rev"
        Me.dpFverif_rev.Size = New System.Drawing.Size(112, 20)
        Me.dpFverif_rev.TabIndex = 171
        Me.dpFverif_rev.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'txtadjactPROYF
        '
        Me.txtadjactPROYF.Enabled = False
        Me.txtadjactPROYF.Location = New System.Drawing.Point(440, 488)
        Me.txtadjactPROYF.Name = "txtadjactPROYF"
        Me.txtadjactPROYF.Size = New System.Drawing.Size(208, 20)
        Me.txtadjactPROYF.TabIndex = 158
        Me.txtadjactPROYF.Text = ""
        '
        'cmdproyf
        '
        Me.cmdproyf.Location = New System.Drawing.Point(648, 488)
        Me.cmdproyf.Name = "cmdproyf"
        Me.cmdproyf.Size = New System.Drawing.Size(32, 16)
        Me.cmdproyf.TabIndex = 157
        Me.cmdproyf.Text = "....."
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(328, 480)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(80, 40)
        Me.Label80.TabIndex = 156
        Me.Label80.Text = "Adjuntar acta de Aprobaci�n PROYF"
        '
        'txtadjProyfinal
        '
        Me.txtadjProyfinal.Enabled = False
        Me.txtadjProyfinal.Location = New System.Drawing.Point(440, 312)
        Me.txtadjProyfinal.Name = "txtadjProyfinal"
        Me.txtadjProyfinal.Size = New System.Drawing.Size(208, 20)
        Me.txtadjProyfinal.TabIndex = 155
        Me.txtadjProyfinal.Text = ""
        '
        'cmdProy
        '
        Me.cmdProy.Location = New System.Drawing.Point(648, 312)
        Me.cmdProy.Name = "cmdProy"
        Me.cmdProy.Size = New System.Drawing.Size(32, 16)
        Me.cmdProy.TabIndex = 154
        Me.cmdProy.Text = "....."
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(328, 312)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(52, 16)
        Me.Label79.TabIndex = 153
        Me.Label79.Text = "Proyecto:"
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(328, 408)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(152, 32)
        Me.Label33.TabIndex = 152
        Me.Label33.Text = "Imprimir acta de Aprobaci�n Proyecto"
        '
        'cmdactaAprobacion_Proy
        '
        Me.cmdactaAprobacion_Proy.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdactaAprobacion_Proy.ImageIndex = 7
        Me.cmdactaAprobacion_Proy.ImageList = Me.ImgListBotonera
        Me.cmdactaAprobacion_Proy.Location = New System.Drawing.Point(504, 400)
        Me.cmdactaAprobacion_Proy.Name = "cmdactaAprobacion_Proy"
        Me.cmdactaAprobacion_Proy.Size = New System.Drawing.Size(48, 40)
        Me.cmdactaAprobacion_Proy.TabIndex = 151
        '
        'txtfCargaProyf
        '
        Me.txtfCargaProyf.Location = New System.Drawing.Point(504, 368)
        Me.txtfCargaProyf.Name = "txtfCargaProyf"
        Me.txtfCargaProyf.Size = New System.Drawing.Size(96, 20)
        Me.txtfCargaProyf.TabIndex = 139
        Me.txtfCargaProyf.Text = ""
        '
        'Label36
        '
        Me.Label36.Location = New System.Drawing.Point(328, 368)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(136, 16)
        Me.Label36.TabIndex = 138
        Me.Label36.Text = "Fecha de Carga PROYF"
        '
        'txtacusePROYF
        '
        Me.txtacusePROYF.Location = New System.Drawing.Point(504, 560)
        Me.txtacusePROYF.Name = "txtacusePROYF"
        Me.txtacusePROYF.Size = New System.Drawing.Size(96, 20)
        Me.txtacusePROYF.TabIndex = 137
        Me.txtacusePROYF.Text = ""
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(328, 560)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(168, 24)
        Me.Label37.TabIndex = 136
        Me.Label37.Text = "Fecha de acuse DGN PROYF"
        '
        'txtfcarga_actaprobPROYF
        '
        Me.txtfcarga_actaprobPROYF.Location = New System.Drawing.Point(504, 528)
        Me.txtfcarga_actaprobPROYF.Name = "txtfcarga_actaprobPROYF"
        Me.txtfcarga_actaprobPROYF.Size = New System.Drawing.Size(96, 20)
        Me.txtfcarga_actaprobPROYF.TabIndex = 135
        Me.txtfcarga_actaprobPROYF.Text = ""
        '
        'Label38
        '
        Me.Label38.Location = New System.Drawing.Point(328, 528)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(184, 24)
        Me.Label38.TabIndex = 134
        Me.Label38.Text = "Fecha de Carga acta de Aprobaci�n PROYF"
        '
        'txtf_imp_actaprob_proy
        '
        Me.txtf_imp_actaprob_proy.Location = New System.Drawing.Point(504, 448)
        Me.txtf_imp_actaprob_proy.Name = "txtf_imp_actaprob_proy"
        Me.txtf_imp_actaprob_proy.Size = New System.Drawing.Size(96, 20)
        Me.txtf_imp_actaprob_proy.TabIndex = 133
        Me.txtf_imp_actaprob_proy.Text = ""
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(328, 448)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(184, 24)
        Me.Label39.TabIndex = 132
        Me.Label39.Text = "Fecha de Impresi�n acta aprobaci�n PROYF"
        '
        'txtf_edic
        '
        Me.txtf_edic.Location = New System.Drawing.Point(208, 584)
        Me.txtf_edic.Name = "txtf_edic"
        Me.txtf_edic.Size = New System.Drawing.Size(96, 20)
        Me.txtf_edic.TabIndex = 131
        Me.txtf_edic.Text = ""
        '
        'Label40
        '
        Me.Label40.Location = New System.Drawing.Point(8, 584)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(152, 24)
        Me.Label40.TabIndex = 130
        Me.Label40.Text = "Fecha de edici�n PROYF"
        '
        'txtftermrev
        '
        Me.txtftermrev.Location = New System.Drawing.Point(208, 520)
        Me.txtftermrev.Name = "txtftermrev"
        Me.txtftermrev.Size = New System.Drawing.Size(96, 20)
        Me.txtftermrev.TabIndex = 129
        Me.txtftermrev.Text = ""
        '
        'Label41
        '
        Me.Label41.Location = New System.Drawing.Point(8, 520)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(208, 24)
        Me.Label41.TabIndex = 128
        Me.Label41.Text = "Fecha T�rmino Revisi�n PROYF"
        '
        'txtfiniRev
        '
        Me.txtfiniRev.Location = New System.Drawing.Point(208, 488)
        Me.txtfiniRev.Name = "txtfiniRev"
        Me.txtfiniRev.Size = New System.Drawing.Size(96, 20)
        Me.txtfiniRev.TabIndex = 127
        Me.txtfiniRev.Text = ""
        '
        'Label42
        '
        Me.Label42.Location = New System.Drawing.Point(8, 488)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(208, 24)
        Me.Label42.TabIndex = 126
        Me.Label42.Text = "Fecha de Inicio Revisi�n PROYF"
        '
        'txtvobo
        '
        Me.txtvobo.Location = New System.Drawing.Point(208, 456)
        Me.txtvobo.Name = "txtvobo"
        Me.txtvobo.Size = New System.Drawing.Size(96, 20)
        Me.txtvobo.TabIndex = 125
        Me.txtvobo.Text = ""
        '
        'Label43
        '
        Me.Label43.Location = New System.Drawing.Point(8, 464)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(152, 24)
        Me.Label43.TabIndex = 124
        Me.Label43.Text = "Fecha Vo Bo Comit�"
        '
        'txtf_aprobrescompub
        '
        Me.txtf_aprobrescompub.Location = New System.Drawing.Point(208, 392)
        Me.txtf_aprobrescompub.Name = "txtf_aprobrescompub"
        Me.txtf_aprobrescompub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_aprobrescompub.TabIndex = 123
        Me.txtf_aprobrescompub.Text = ""
        '
        'Label53
        '
        Me.Label53.Location = New System.Drawing.Point(8, 424)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(216, 24)
        Me.Label53.TabIndex = 122
        Me.Label53.Text = "Fecha de Aprobaci�n de Resoluci�n a comentario P�blico"
        '
        'txtfResolucion
        '
        Me.txtfResolucion.Location = New System.Drawing.Point(208, 312)
        Me.txtfResolucion.Name = "txtfResolucion"
        Me.txtfResolucion.Size = New System.Drawing.Size(96, 20)
        Me.txtfResolucion.TabIndex = 121
        Me.txtfResolucion.Text = ""
        '
        'Label78
        '
        Me.Label78.Location = New System.Drawing.Point(8, 312)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(208, 24)
        Me.Label78.TabIndex = 120
        Me.Label78.Text = "Fecha de Inicio de Resoluci�n a Comentario P�blico"
        '
        'TXTF_limrescompub
        '
        Me.TXTF_limrescompub.Location = New System.Drawing.Point(208, 352)
        Me.TXTF_limrescompub.Name = "TXTF_limrescompub"
        Me.TXTF_limrescompub.Size = New System.Drawing.Size(96, 20)
        Me.TXTF_limrescompub.TabIndex = 119
        Me.TXTF_limrescompub.Text = ""
        '
        'Label35
        '
        Me.Label35.Location = New System.Drawing.Point(8, 352)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(144, 24)
        Me.Label35.TabIndex = 118
        Me.Label35.Text = "Fecha L�mite de Resoluci�n Comentario P�blico"
        '
        'txtf_aprob_com
        '
        Me.txtf_aprob_com.Location = New System.Drawing.Point(320, 8)
        Me.txtf_aprob_com.Name = "txtf_aprob_com"
        Me.txtf_aprob_com.Size = New System.Drawing.Size(96, 20)
        Me.txtf_aprob_com.TabIndex = 116
        Me.txtf_aprob_com.Text = ""
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(128, 8)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(184, 24)
        Me.Label34.TabIndex = 115
        Me.Label34.Text = "Fecha de Aprobaci�n Comit� Proy"
        '
        'txttitulo_Proy
        '
        Me.txttitulo_Proy.Location = New System.Drawing.Point(128, 72)
        Me.txttitulo_Proy.Name = "txttitulo_Proy"
        Me.txttitulo_Proy.Size = New System.Drawing.Size(312, 20)
        Me.txttitulo_Proy.TabIndex = 111
        Me.txttitulo_Proy.Text = ""
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(32, 72)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(72, 23)
        Me.Label30.TabIndex = 112
        Me.Label30.Text = "T�tulo Proy"
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(16, 16)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(56, 16)
        Me.Label28.TabIndex = 89
        Me.Label28.Text = "Proyecto"
        '
        'txtclasificacion_proy
        '
        Me.txtclasificacion_proy.Location = New System.Drawing.Point(128, 40)
        Me.txtclasificacion_proy.Name = "txtclasificacion_proy"
        Me.txtclasificacion_proy.Size = New System.Drawing.Size(312, 20)
        Me.txtclasificacion_proy.TabIndex = 87
        Me.txtclasificacion_proy.Text = ""
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(32, 40)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(96, 23)
        Me.Label26.TabIndex = 88
        Me.Label26.Text = "Clasificaci�n Proy"
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(24, 136)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(104, 32)
        Me.Label22.TabIndex = 84
        Me.Label22.Text = "Responsable Tema Proy"
        '
        'txtresponsable_proy
        '
        Me.txtresponsable_proy.Enabled = False
        Me.txtresponsable_proy.Location = New System.Drawing.Point(128, 136)
        Me.txtresponsable_proy.Name = "txtresponsable_proy"
        Me.txtresponsable_proy.Size = New System.Drawing.Size(296, 20)
        Me.txtresponsable_proy.TabIndex = 85
        Me.txtresponsable_proy.Text = ""
        '
        'cboResponsable_proy
        '
        Me.cboResponsable_proy.ItemHeight = 13
        Me.cboResponsable_proy.Location = New System.Drawing.Point(128, 136)
        Me.cboResponsable_proy.Name = "cboResponsable_proy"
        Me.cboResponsable_proy.Size = New System.Drawing.Size(312, 21)
        Me.cboResponsable_proy.TabIndex = 86
        '
        'txtf_limitecompub
        '
        Me.txtf_limitecompub.Location = New System.Drawing.Point(208, 208)
        Me.txtf_limitecompub.Name = "txtf_limitecompub"
        Me.txtf_limitecompub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_limitecompub.TabIndex = 83
        Me.txtf_limitecompub.Text = ""
        '
        'dtF_Fin
        '
        Me.dtF_Fin.CustomFormat = "dd/mm/yyyy"
        Me.dtF_Fin.Location = New System.Drawing.Point(208, 208)
        Me.dtF_Fin.Name = "dtF_Fin"
        Me.dtF_Fin.Size = New System.Drawing.Size(112, 20)
        Me.dtF_Fin.TabIndex = 82
        Me.dtF_Fin.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(16, 208)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(192, 24)
        Me.Label23.TabIndex = 81
        Me.Label23.Text = "Fecha L�mite para emitir Comentarios P�blicos"
        '
        'txtf_ini_compub
        '
        Me.txtf_ini_compub.Location = New System.Drawing.Point(208, 176)
        Me.txtf_ini_compub.Name = "txtf_ini_compub"
        Me.txtf_ini_compub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_ini_compub.TabIndex = 80
        Me.txtf_ini_compub.Text = ""
        '
        'dtF_inicio
        '
        Me.dtF_inicio.CustomFormat = "dd/mm/yyyy"
        Me.dtF_inicio.Location = New System.Drawing.Point(208, 176)
        Me.dtF_inicio.Name = "dtF_inicio"
        Me.dtF_inicio.Size = New System.Drawing.Size(112, 20)
        Me.dtF_inicio.TabIndex = 79
        Me.dtF_inicio.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(16, 176)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(184, 24)
        Me.Label24.TabIndex = 78
        Me.Label24.Text = "Fecha de Publicaci�n a periodo de Comentario P�blico"
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(24, 104)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(104, 24)
        Me.Label25.TabIndex = 76
        Me.Label25.Text = "N�mero de P�ginas"
        '
        'txtpaginas_proy
        '
        Me.txtpaginas_proy.Enabled = False
        Me.txtpaginas_proy.Location = New System.Drawing.Point(128, 104)
        Me.txtpaginas_proy.Name = "txtpaginas_proy"
        Me.txtpaginas_proy.Size = New System.Drawing.Size(96, 20)
        Me.txtpaginas_proy.TabIndex = 77
        Me.txtpaginas_proy.Text = ""
        '
        'DTf_aprobComproy
        '
        Me.DTf_aprobComproy.CustomFormat = "dd/mm/yyyy"
        Me.DTf_aprobComproy.Location = New System.Drawing.Point(320, 8)
        Me.DTf_aprobComproy.Name = "DTf_aprobComproy"
        Me.DTf_aprobComproy.Size = New System.Drawing.Size(112, 20)
        Me.DTf_aprobComproy.TabIndex = 117
        Me.DTf_aprobComproy.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtresolucion
        '
        Me.dtresolucion.CustomFormat = "dd/mm/yyyy"
        Me.dtresolucion.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtresolucion.Location = New System.Drawing.Point(208, 312)
        Me.dtresolucion.Name = "dtresolucion"
        Me.dtresolucion.Size = New System.Drawing.Size(112, 20)
        Me.dtresolucion.TabIndex = 141
        Me.dtresolucion.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtf_aprobrescompub
        '
        Me.dtf_aprobrescompub.CustomFormat = "dd/mm/yyyy"
        Me.dtf_aprobrescompub.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtf_aprobrescompub.Location = New System.Drawing.Point(208, 392)
        Me.dtf_aprobrescompub.Name = "dtf_aprobrescompub"
        Me.dtf_aprobrescompub.Size = New System.Drawing.Size(112, 20)
        Me.dtf_aprobrescompub.TabIndex = 142
        Me.dtf_aprobrescompub.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtvobo
        '
        Me.dtvobo.CustomFormat = "dd/mm/yyyy"
        Me.dtvobo.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtvobo.Location = New System.Drawing.Point(208, 456)
        Me.dtvobo.Name = "dtvobo"
        Me.dtvobo.Size = New System.Drawing.Size(112, 20)
        Me.dtvobo.TabIndex = 143
        Me.dtvobo.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtfiniRev
        '
        Me.dtfiniRev.CustomFormat = "dd/mm/yyyy"
        Me.dtfiniRev.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtfiniRev.Location = New System.Drawing.Point(208, 488)
        Me.dtfiniRev.Name = "dtfiniRev"
        Me.dtfiniRev.Size = New System.Drawing.Size(112, 20)
        Me.dtfiniRev.TabIndex = 144
        Me.dtfiniRev.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtftermrev
        '
        Me.dtftermrev.CustomFormat = "dd/mm/yyyy"
        Me.dtftermrev.Location = New System.Drawing.Point(208, 520)
        Me.dtftermrev.Name = "dtftermrev"
        Me.dtftermrev.Size = New System.Drawing.Size(112, 20)
        Me.dtftermrev.TabIndex = 145
        Me.dtftermrev.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtF_limrescompub
        '
        Me.dtF_limrescompub.CustomFormat = "dd/mm/yyyy"
        Me.dtF_limrescompub.Location = New System.Drawing.Point(208, 352)
        Me.dtF_limrescompub.Name = "dtF_limrescompub"
        Me.dtF_limrescompub.Size = New System.Drawing.Size(112, 20)
        Me.dtF_limrescompub.TabIndex = 146
        Me.dtF_limrescompub.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtf_edic
        '
        Me.dtf_edic.CustomFormat = "dd/mm/yyyy"
        Me.dtf_edic.Location = New System.Drawing.Point(208, 584)
        Me.dtf_edic.Name = "dtf_edic"
        Me.dtf_edic.Size = New System.Drawing.Size(112, 20)
        Me.dtf_edic.TabIndex = 147
        Me.dtf_edic.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'dtacusePROYF
        '
        Me.dtacusePROYF.CustomFormat = "dd/mm/yyyy"
        Me.dtacusePROYF.Location = New System.Drawing.Point(504, 560)
        Me.dtacusePROYF.Name = "dtacusePROYF"
        Me.dtacusePROYF.Size = New System.Drawing.Size(112, 20)
        Me.dtacusePROYF.TabIndex = 150
        Me.dtacusePROYF.Value = New Date(2006, 9, 13, 9, 50, 21, 965)
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtnumcomTecProy)
        Me.GroupBox2.Controls.Add(Me.RadioButton3)
        Me.GroupBox2.Controls.Add(Me.optComTecSiProy)
        Me.GroupBox2.Location = New System.Drawing.Point(16, 248)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(224, 48)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Tuvo Comentarios T�cnicos"
        '
        'txtnumcomTecProy
        '
        Me.txtnumcomTecProy.Enabled = False
        Me.txtnumcomTecProy.Location = New System.Drawing.Point(112, 16)
        Me.txtnumcomTecProy.Name = "txtnumcomTecProy"
        Me.txtnumcomTecProy.TabIndex = 165
        Me.txtnumcomTecProy.Text = ""
        '
        'RadioButton3
        '
        Me.RadioButton3.Checked = True
        Me.RadioButton3.Enabled = False
        Me.RadioButton3.Location = New System.Drawing.Point(56, 16)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(48, 24)
        Me.RadioButton3.TabIndex = 164
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "No"
        '
        'optComTecSiProy
        '
        Me.optComTecSiProy.Enabled = False
        Me.optComTecSiProy.Location = New System.Drawing.Point(8, 16)
        Me.optComTecSiProy.Name = "optComTecSiProy"
        Me.optComTecSiProy.Size = New System.Drawing.Size(40, 24)
        Me.optComTecSiProy.TabIndex = 163
        Me.optComTecSiProy.Text = "Si"
        '
        'TbAvance
        '
        Me.TbAvance.Controls.Add(Me.txtf_cargaminuta)
        Me.TbAvance.Controls.Add(Me.Label84)
        Me.TbAvance.Controls.Add(Me.txtf_inicioprocalter)
        Me.TbAvance.Controls.Add(Me.Label5)
        Me.TbAvance.Controls.Add(Me.txtf_cargaAntf)
        Me.TbAvance.Controls.Add(Me.Label81)
        Me.TbAvance.Controls.Add(Me.Label77)
        Me.TbAvance.Controls.Add(Me.txtf_carga_Proyf)
        Me.TbAvance.Controls.Add(Me.Label67)
        Me.TbAvance.Controls.Add(Me.txtf_acuseDGN)
        Me.TbAvance.Controls.Add(Me.Label68)
        Me.TbAvance.Controls.Add(Me.txtf_carga_acta_proyf)
        Me.TbAvance.Controls.Add(Me.Label69)
        Me.TbAvance.Controls.Add(Me.txtf_impr_Acta_proyf)
        Me.TbAvance.Controls.Add(Me.Label70)
        Me.TbAvance.Controls.Add(Me.txtf_edi_proyf)
        Me.TbAvance.Controls.Add(Me.Label71)
        Me.TbAvance.Controls.Add(Me.txtf_fin_rev_proyf)
        Me.TbAvance.Controls.Add(Me.Label72)
        Me.TbAvance.Controls.Add(Me.txtf_inic_rev_proyf)
        Me.TbAvance.Controls.Add(Me.Label73)
        Me.TbAvance.Controls.Add(Me.txtf_VoBo_Comite)
        Me.TbAvance.Controls.Add(Me.Label74)
        Me.TbAvance.Controls.Add(Me.txtf_aprob_res_compub)
        Me.TbAvance.Controls.Add(Me.Label75)
        Me.TbAvance.Controls.Add(Me.txtf_lim_res_compub)
        Me.TbAvance.Controls.Add(Me.Label76)
        Me.TbAvance.Controls.Add(Me.txtf_res_compub)
        Me.TbAvance.Controls.Add(Me.Label66)
        Me.TbAvance.Controls.Add(Me.txtf_lim_compub)
        Me.TbAvance.Controls.Add(Me.Label65)
        Me.TbAvance.Controls.Add(Me.txtf_pub_compub)
        Me.TbAvance.Controls.Add(Me.Label64)
        Me.TbAvance.Controls.Add(Me.txtf_Aprob_Comite_Proy)
        Me.TbAvance.Controls.Add(Me.Label63)
        Me.TbAvance.Controls.Add(Me.txtf_Aprob_CTGT_Ant)
        Me.TbAvance.Controls.Add(Me.Label62)
        Me.TbAvance.Controls.Add(Me.txtf_Carga_ActaAprob)
        Me.TbAvance.Controls.Add(Me.Label61)
        Me.TbAvance.Controls.Add(Me.txtf_Impr_ActaAprob)
        Me.TbAvance.Controls.Add(Me.Label60)
        Me.TbAvance.Controls.Add(Me.txtf_Dtfinal)
        Me.TbAvance.Controls.Add(Me.Label59)
        Me.TbAvance.Controls.Add(Me.txtaprbRev_Edit)
        Me.TbAvance.Controls.Add(Me.Label58)
        Me.TbAvance.Controls.Add(Me.txtF_nmx)
        Me.TbAvance.Controls.Add(Me.Label57)
        Me.TbAvance.Location = New System.Drawing.Point(4, 22)
        Me.TbAvance.Name = "TbAvance"
        Me.TbAvance.Size = New System.Drawing.Size(712, 686)
        Me.TbAvance.TabIndex = 4
        Me.TbAvance.Text = "Historial PNN"
        '
        'txtf_cargaminuta
        '
        Me.txtf_cargaminuta.Enabled = False
        Me.txtf_cargaminuta.Location = New System.Drawing.Point(224, 496)
        Me.txtf_cargaminuta.Name = "txtf_cargaminuta"
        Me.txtf_cargaminuta.Size = New System.Drawing.Size(96, 20)
        Me.txtf_cargaminuta.TabIndex = 110
        Me.txtf_cargaminuta.Text = ""
        '
        'Label84
        '
        Me.Label84.Location = New System.Drawing.Point(24, 496)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(208, 24)
        Me.Label84.TabIndex = 109
        Me.Label84.Text = "Fecha de Carga Minuta de Fin de Procedimiento Alternativo"
        '
        'txtf_inicioprocalter
        '
        Me.txtf_inicioprocalter.AcceptsReturn = True
        Me.txtf_inicioprocalter.Enabled = False
        Me.txtf_inicioprocalter.Location = New System.Drawing.Point(224, 456)
        Me.txtf_inicioprocalter.Name = "txtf_inicioprocalter"
        Me.txtf_inicioprocalter.Size = New System.Drawing.Size(96, 20)
        Me.txtf_inicioprocalter.TabIndex = 108
        Me.txtf_inicioprocalter.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(24, 456)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(208, 24)
        Me.Label5.TabIndex = 107
        Me.Label5.Text = "Fecha de Inicio Procedimiento Alternativo"
        '
        'txtf_cargaAntf
        '
        Me.txtf_cargaAntf.Location = New System.Drawing.Point(224, 296)
        Me.txtf_cargaAntf.Name = "txtf_cargaAntf"
        Me.txtf_cargaAntf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_cargaAntf.TabIndex = 106
        Me.txtf_cargaAntf.Text = ""
        '
        'Label81
        '
        Me.Label81.Location = New System.Drawing.Point(24, 296)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(208, 24)
        Me.Label81.TabIndex = 105
        Me.Label81.Text = "Fecha de Carga Anteproyecto"
        '
        'Label77
        '
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(120, 40)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(376, 40)
        Me.Label77.TabIndex = 104
        Me.Label77.Text = "Historial del Tema en Fechas"
        '
        'txtf_carga_Proyf
        '
        Me.txtf_carga_Proyf.Location = New System.Drawing.Point(536, 400)
        Me.txtf_carga_Proyf.Name = "txtf_carga_Proyf"
        Me.txtf_carga_Proyf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_carga_Proyf.TabIndex = 103
        Me.txtf_carga_Proyf.Text = ""
        '
        'Label67
        '
        Me.Label67.Location = New System.Drawing.Point(336, 400)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(208, 24)
        Me.Label67.TabIndex = 102
        Me.Label67.Text = "Fecha de Carga PROYF"
        '
        'txtf_acuseDGN
        '
        Me.txtf_acuseDGN.Location = New System.Drawing.Point(536, 368)
        Me.txtf_acuseDGN.Name = "txtf_acuseDGN"
        Me.txtf_acuseDGN.Size = New System.Drawing.Size(96, 20)
        Me.txtf_acuseDGN.TabIndex = 101
        Me.txtf_acuseDGN.Text = ""
        '
        'Label68
        '
        Me.Label68.Location = New System.Drawing.Point(336, 368)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(208, 24)
        Me.Label68.TabIndex = 100
        Me.Label68.Text = "Fecha de acuse DGN PROYF"
        '
        'txtf_carga_acta_proyf
        '
        Me.txtf_carga_acta_proyf.Location = New System.Drawing.Point(536, 336)
        Me.txtf_carga_acta_proyf.Name = "txtf_carga_acta_proyf"
        Me.txtf_carga_acta_proyf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_carga_acta_proyf.TabIndex = 99
        Me.txtf_carga_acta_proyf.Text = ""
        '
        'Label69
        '
        Me.Label69.Location = New System.Drawing.Point(336, 336)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(208, 24)
        Me.Label69.TabIndex = 98
        Me.Label69.Text = "Fecha de Carga acta de Aprobaci�n PROYF"
        '
        'txtf_impr_Acta_proyf
        '
        Me.txtf_impr_Acta_proyf.Location = New System.Drawing.Point(536, 304)
        Me.txtf_impr_Acta_proyf.Name = "txtf_impr_Acta_proyf"
        Me.txtf_impr_Acta_proyf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_impr_Acta_proyf.TabIndex = 97
        Me.txtf_impr_Acta_proyf.Text = ""
        '
        'Label70
        '
        Me.Label70.Location = New System.Drawing.Point(336, 304)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(208, 24)
        Me.Label70.TabIndex = 96
        Me.Label70.Text = "Fecha de Impresi�n acta aprobaci�n PROYF"
        '
        'txtf_edi_proyf
        '
        Me.txtf_edi_proyf.Location = New System.Drawing.Point(536, 272)
        Me.txtf_edi_proyf.Name = "txtf_edi_proyf"
        Me.txtf_edi_proyf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_edi_proyf.TabIndex = 95
        Me.txtf_edi_proyf.Text = ""
        '
        'Label71
        '
        Me.Label71.Location = New System.Drawing.Point(336, 272)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(208, 24)
        Me.Label71.TabIndex = 94
        Me.Label71.Text = "Fecha de edici�n PROYF"
        '
        'txtf_fin_rev_proyf
        '
        Me.txtf_fin_rev_proyf.Location = New System.Drawing.Point(536, 240)
        Me.txtf_fin_rev_proyf.Name = "txtf_fin_rev_proyf"
        Me.txtf_fin_rev_proyf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_fin_rev_proyf.TabIndex = 93
        Me.txtf_fin_rev_proyf.Text = ""
        '
        'Label72
        '
        Me.Label72.Location = New System.Drawing.Point(336, 240)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(208, 24)
        Me.Label72.TabIndex = 92
        Me.Label72.Text = "Fecha T�rmino Revisi�n PROYF"
        '
        'txtf_inic_rev_proyf
        '
        Me.txtf_inic_rev_proyf.Location = New System.Drawing.Point(536, 208)
        Me.txtf_inic_rev_proyf.Name = "txtf_inic_rev_proyf"
        Me.txtf_inic_rev_proyf.Size = New System.Drawing.Size(96, 20)
        Me.txtf_inic_rev_proyf.TabIndex = 91
        Me.txtf_inic_rev_proyf.Text = ""
        '
        'Label73
        '
        Me.Label73.Location = New System.Drawing.Point(336, 208)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(208, 24)
        Me.Label73.TabIndex = 90
        Me.Label73.Text = "Fecha de Inicio Revisi�n PROYF"
        '
        'txtf_VoBo_Comite
        '
        Me.txtf_VoBo_Comite.Location = New System.Drawing.Point(536, 176)
        Me.txtf_VoBo_Comite.Name = "txtf_VoBo_Comite"
        Me.txtf_VoBo_Comite.Size = New System.Drawing.Size(96, 20)
        Me.txtf_VoBo_Comite.TabIndex = 89
        Me.txtf_VoBo_Comite.Text = ""
        '
        'Label74
        '
        Me.Label74.Location = New System.Drawing.Point(336, 176)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(208, 24)
        Me.Label74.TabIndex = 88
        Me.Label74.Text = "Fecha Vo Bo Comit�"
        '
        'txtf_aprob_res_compub
        '
        Me.txtf_aprob_res_compub.Location = New System.Drawing.Point(536, 144)
        Me.txtf_aprob_res_compub.Name = "txtf_aprob_res_compub"
        Me.txtf_aprob_res_compub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_aprob_res_compub.TabIndex = 87
        Me.txtf_aprob_res_compub.Text = ""
        '
        'Label75
        '
        Me.Label75.Location = New System.Drawing.Point(336, 144)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(216, 24)
        Me.Label75.TabIndex = 86
        Me.Label75.Text = "Fecha de Aprobaci�n de Resoluci�n a comentario P�blico"
        '
        'txtf_lim_res_compub
        '
        Me.txtf_lim_res_compub.Location = New System.Drawing.Point(536, 112)
        Me.txtf_lim_res_compub.Name = "txtf_lim_res_compub"
        Me.txtf_lim_res_compub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_lim_res_compub.TabIndex = 85
        Me.txtf_lim_res_compub.Text = ""
        '
        'Label76
        '
        Me.Label76.Location = New System.Drawing.Point(336, 112)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(208, 24)
        Me.Label76.TabIndex = 84
        Me.Label76.Text = "Fecha L�mite de Resoluci�n a Comentario P�blico"
        '
        'txtf_res_compub
        '
        Me.txtf_res_compub.Location = New System.Drawing.Point(224, 416)
        Me.txtf_res_compub.Name = "txtf_res_compub"
        Me.txtf_res_compub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_res_compub.TabIndex = 83
        Me.txtf_res_compub.Text = ""
        '
        'Label66
        '
        Me.Label66.Location = New System.Drawing.Point(24, 416)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(208, 24)
        Me.Label66.TabIndex = 82
        Me.Label66.Text = "Fecha de Resoluci�n Comentario P�blico"
        '
        'txtf_lim_compub
        '
        Me.txtf_lim_compub.Location = New System.Drawing.Point(224, 384)
        Me.txtf_lim_compub.Name = "txtf_lim_compub"
        Me.txtf_lim_compub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_lim_compub.TabIndex = 81
        Me.txtf_lim_compub.Text = ""
        '
        'Label65
        '
        Me.Label65.Location = New System.Drawing.Point(24, 384)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(208, 24)
        Me.Label65.TabIndex = 80
        Me.Label65.Text = "Fecha L�mite Comentario P�blico"
        '
        'txtf_pub_compub
        '
        Me.txtf_pub_compub.Location = New System.Drawing.Point(224, 352)
        Me.txtf_pub_compub.Name = "txtf_pub_compub"
        Me.txtf_pub_compub.Size = New System.Drawing.Size(96, 20)
        Me.txtf_pub_compub.TabIndex = 79
        Me.txtf_pub_compub.Text = ""
        '
        'Label64
        '
        Me.Label64.Location = New System.Drawing.Point(24, 352)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(208, 24)
        Me.Label64.TabIndex = 78
        Me.Label64.Text = "Fecha de Publicaci�n Comentario P�blico"
        '
        'txtf_Aprob_Comite_Proy
        '
        Me.txtf_Aprob_Comite_Proy.Location = New System.Drawing.Point(224, 320)
        Me.txtf_Aprob_Comite_Proy.Name = "txtf_Aprob_Comite_Proy"
        Me.txtf_Aprob_Comite_Proy.Size = New System.Drawing.Size(96, 20)
        Me.txtf_Aprob_Comite_Proy.TabIndex = 77
        Me.txtf_Aprob_Comite_Proy.Text = ""
        '
        'Label63
        '
        Me.Label63.Location = New System.Drawing.Point(24, 320)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(208, 24)
        Me.Label63.TabIndex = 76
        Me.Label63.Text = "Fecha de Aprobaci�n Comit� Proy"
        '
        'txtf_Aprob_CTGT_Ant
        '
        Me.txtf_Aprob_CTGT_Ant.Location = New System.Drawing.Point(224, 272)
        Me.txtf_Aprob_CTGT_Ant.Name = "txtf_Aprob_CTGT_Ant"
        Me.txtf_Aprob_CTGT_Ant.Size = New System.Drawing.Size(96, 20)
        Me.txtf_Aprob_CTGT_Ant.TabIndex = 75
        Me.txtf_Aprob_CTGT_Ant.Text = ""
        '
        'Label62
        '
        Me.Label62.Location = New System.Drawing.Point(24, 272)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(208, 24)
        Me.Label62.TabIndex = 74
        Me.Label62.Text = "Fecha de Aprobaci�n Ant CT GT "
        '
        'txtf_Carga_ActaAprob
        '
        Me.txtf_Carga_ActaAprob.Location = New System.Drawing.Point(224, 240)
        Me.txtf_Carga_ActaAprob.Name = "txtf_Carga_ActaAprob"
        Me.txtf_Carga_ActaAprob.Size = New System.Drawing.Size(96, 20)
        Me.txtf_Carga_ActaAprob.TabIndex = 73
        Me.txtf_Carga_ActaAprob.Text = ""
        '
        'Label61
        '
        Me.Label61.Location = New System.Drawing.Point(24, 240)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(208, 24)
        Me.Label61.TabIndex = 72
        Me.Label61.Text = "Fecha de Carga Acta Aprobaci�n"
        '
        'txtf_Impr_ActaAprob
        '
        Me.txtf_Impr_ActaAprob.Location = New System.Drawing.Point(224, 208)
        Me.txtf_Impr_ActaAprob.Name = "txtf_Impr_ActaAprob"
        Me.txtf_Impr_ActaAprob.Size = New System.Drawing.Size(96, 20)
        Me.txtf_Impr_ActaAprob.TabIndex = 71
        Me.txtf_Impr_ActaAprob.Text = ""
        '
        'Label60
        '
        Me.Label60.Location = New System.Drawing.Point(24, 208)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(208, 24)
        Me.Label60.TabIndex = 70
        Me.Label60.Text = "Fecha de Impresi�n Acta Aprobaci�n"
        '
        'txtf_Dtfinal
        '
        Me.txtf_Dtfinal.Location = New System.Drawing.Point(224, 176)
        Me.txtf_Dtfinal.Name = "txtf_Dtfinal"
        Me.txtf_Dtfinal.Size = New System.Drawing.Size(96, 20)
        Me.txtf_Dtfinal.TabIndex = 69
        Me.txtf_Dtfinal.Text = ""
        '
        'Label59
        '
        Me.Label59.Location = New System.Drawing.Point(24, 176)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(208, 24)
        Me.Label59.TabIndex = 68
        Me.Label59.Text = "Fecha de carga DT Final"
        '
        'txtaprbRev_Edit
        '
        Me.txtaprbRev_Edit.Location = New System.Drawing.Point(224, 144)
        Me.txtaprbRev_Edit.Name = "txtaprbRev_Edit"
        Me.txtaprbRev_Edit.Size = New System.Drawing.Size(96, 20)
        Me.txtaprbRev_Edit.TabIndex = 67
        Me.txtaprbRev_Edit.Text = ""
        '
        'Label58
        '
        Me.Label58.Location = New System.Drawing.Point(24, 144)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(216, 24)
        Me.Label58.TabIndex = 66
        Me.Label58.Text = "Fecha de Aprobaci�n Revisi�n Editorial"
        '
        'txtF_nmx
        '
        Me.txtF_nmx.Location = New System.Drawing.Point(224, 112)
        Me.txtF_nmx.Name = "txtF_nmx"
        Me.txtF_nmx.Size = New System.Drawing.Size(96, 20)
        Me.txtF_nmx.TabIndex = 65
        Me.txtF_nmx.Text = ""
        '
        'Label57
        '
        Me.Label57.Location = New System.Drawing.Point(24, 112)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(208, 24)
        Me.Label57.TabIndex = 64
        Me.Label57.Text = "Fecha de Inicio de Desarrollo de NMX"
        '
        'TpHistorial
        '
        Me.TpHistorial.CausesValidation = CType(configurationAppSettings.GetValue("TpHistorial.CausesValidation", GetType(System.Boolean)), Boolean)
        Me.TpHistorial.Controls.Add(Me.TVHistorialPNN)
        Me.TpHistorial.Controls.Add(Me.Panel1)
        Me.TpHistorial.Location = New System.Drawing.Point(4, 22)
        Me.TpHistorial.Name = "TpHistorial"
        Me.TpHistorial.Size = New System.Drawing.Size(712, 686)
        Me.TpHistorial.TabIndex = 6
        Me.TpHistorial.Text = "Avance"
        '
        'TVHistorialPNN
        '
        Me.TVHistorialPNN.ImageIndex = 2
        Me.TVHistorialPNN.ImageList = Me.imgListTreeView
        Me.TVHistorialPNN.Location = New System.Drawing.Point(8, 8)
        Me.TVHistorialPNN.Name = "TVHistorialPNN"
        Me.TVHistorialPNN.SelectedImageIndex = 2
        Me.TVHistorialPNN.Size = New System.Drawing.Size(152, 520)
        Me.TVHistorialPNN.TabIndex = 14
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label96)
        Me.Panel1.Controls.Add(Me.txthjustiArmonizada)
        Me.Panel1.Controls.Add(Me.txtharmonizada)
        Me.Panel1.Controls.Add(Me.chkharmonizada)
        Me.Panel1.Controls.Add(Me.txthreferencia)
        Me.Panel1.Controls.Add(Me.Label97)
        Me.Panel1.Controls.Add(Me.txthbasado)
        Me.Panel1.Controls.Add(Me.chkhbasado)
        Me.Panel1.Controls.Add(Me.txthRevision)
        Me.Panel1.Controls.Add(Me.Label99)
        Me.Panel1.Controls.Add(Me.txthNumeroTema)
        Me.Panel1.Controls.Add(Me.Label100)
        Me.Panel1.Controls.Add(Me.txthjustificacion)
        Me.Panel1.Controls.Add(Me.Label101)
        Me.Panel1.Controls.Add(Me.txthobjetivo)
        Me.Panel1.Controls.Add(Me.Label102)
        Me.Panel1.Controls.Add(Me.txthtitulo)
        Me.Panel1.Controls.Add(Me.Label103)
        Me.Panel1.Controls.Add(Me.txthclasificacion)
        Me.Panel1.Controls.Add(Me.Label104)
        Me.Panel1.Controls.Add(Me.Label105)
        Me.Panel1.Controls.Add(Me.txthresponsable)
        Me.Panel1.Controls.Add(Me.Label106)
        Me.Panel1.Controls.Add(Me.txthfFin)
        Me.Panel1.Controls.Add(Me.txthfinicio)
        Me.Panel1.Controls.Add(Me.Label107)
        Me.Panel1.Controls.Add(Me.Label108)
        Me.Panel1.Controls.Add(Me.txthpertenece)
        Me.Panel1.Controls.Add(Me.Label109)
        Me.Panel1.Controls.Add(Me.txthtipotema)
        Me.Panel1.Controls.Add(Me.chkhmodific)
        Me.Panel1.Controls.Add(Me.chkhnormal)
        Me.Panel1.Enabled = False
        Me.Panel1.Location = New System.Drawing.Point(168, 8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(464, 520)
        Me.Panel1.TabIndex = 3
        '
        'Label96
        '
        Me.Label96.Location = New System.Drawing.Point(16, 344)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(88, 24)
        Me.Label96.TabIndex = 138
        Me.Label96.Text = "Justificaci�n de armonizacion"
        '
        'txthjustiArmonizada
        '
        Me.txthjustiArmonizada.Location = New System.Drawing.Point(112, 344)
        Me.txthjustiArmonizada.Multiline = True
        Me.txthjustiArmonizada.Name = "txthjustiArmonizada"
        Me.txthjustiArmonizada.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txthjustiArmonizada.Size = New System.Drawing.Size(336, 24)
        Me.txthjustiArmonizada.TabIndex = 137
        Me.txthjustiArmonizada.Text = ""
        '
        'txtharmonizada
        '
        Me.txtharmonizada.Location = New System.Drawing.Point(112, 312)
        Me.txtharmonizada.Name = "txtharmonizada"
        Me.txtharmonizada.Size = New System.Drawing.Size(336, 20)
        Me.txtharmonizada.TabIndex = 136
        Me.txtharmonizada.Text = ""
        Me.txtharmonizada.Visible = False
        '
        'chkharmonizada
        '
        Me.chkharmonizada.Location = New System.Drawing.Point(24, 304)
        Me.chkharmonizada.Name = "chkharmonizada"
        Me.chkharmonizada.Size = New System.Drawing.Size(96, 40)
        Me.chkharmonizada.TabIndex = 135
        Me.chkharmonizada.Text = "Armonizaci�n de Norma"
        '
        'txthreferencia
        '
        Me.txthreferencia.Enabled = False
        Me.txthreferencia.Location = New System.Drawing.Point(112, 16)
        Me.txthreferencia.Name = "txthreferencia"
        Me.txthreferencia.Size = New System.Drawing.Size(192, 20)
        Me.txthreferencia.TabIndex = 133
        Me.txthreferencia.Text = ""
        '
        'Label97
        '
        Me.Label97.Location = New System.Drawing.Point(24, 16)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(80, 24)
        Me.Label97.TabIndex = 134
        Me.Label97.Text = "Referencia"
        '
        'txthbasado
        '
        Me.txthbasado.Location = New System.Drawing.Point(112, 272)
        Me.txthbasado.Name = "txthbasado"
        Me.txthbasado.Size = New System.Drawing.Size(336, 20)
        Me.txthbasado.TabIndex = 9
        Me.txthbasado.Text = ""
        Me.txthbasado.Visible = False
        '
        'chkhbasado
        '
        Me.chkhbasado.Location = New System.Drawing.Point(24, 264)
        Me.chkhbasado.Name = "chkhbasado"
        Me.chkhbasado.Size = New System.Drawing.Size(88, 40)
        Me.chkhbasado.TabIndex = 8
        Me.chkhbasado.Text = "Basado en Norma Internacional"
        '
        'txthRevision
        '
        Me.txthRevision.Location = New System.Drawing.Point(112, 384)
        Me.txthRevision.Multiline = True
        Me.txthRevision.Name = "txthRevision"
        Me.txthRevision.Size = New System.Drawing.Size(328, 20)
        Me.txthRevision.TabIndex = 60
        Me.txthRevision.Text = ""
        '
        'Label99
        '
        Me.Label99.Location = New System.Drawing.Point(24, 384)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(72, 24)
        Me.Label99.TabIndex = 59
        Me.Label99.Text = "Revisi�n"
        '
        'txthNumeroTema
        '
        Me.txthNumeroTema.Location = New System.Drawing.Point(112, 80)
        Me.txthNumeroTema.Multiline = True
        Me.txthNumeroTema.Name = "txthNumeroTema"
        Me.txthNumeroTema.Size = New System.Drawing.Size(64, 20)
        Me.txthNumeroTema.TabIndex = 1
        Me.txthNumeroTema.Text = ""
        '
        'Label100
        '
        Me.Label100.Location = New System.Drawing.Point(24, 80)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(80, 16)
        Me.Label100.TabIndex = 57
        Me.Label100.Text = "N�mero  tema"
        '
        'txthjustificacion
        '
        Me.txthjustificacion.Location = New System.Drawing.Point(112, 208)
        Me.txthjustificacion.Multiline = True
        Me.txthjustificacion.Name = "txthjustificacion"
        Me.txthjustificacion.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txthjustificacion.Size = New System.Drawing.Size(336, 24)
        Me.txthjustificacion.TabIndex = 5
        Me.txthjustificacion.Text = ""
        '
        'Label101
        '
        Me.Label101.Location = New System.Drawing.Point(32, 208)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(72, 24)
        Me.Label101.TabIndex = 55
        Me.Label101.Text = "Justificaci�n"
        '
        'txthobjetivo
        '
        Me.txthobjetivo.Location = New System.Drawing.Point(112, 176)
        Me.txthobjetivo.Multiline = True
        Me.txthobjetivo.Name = "txthobjetivo"
        Me.txthobjetivo.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txthobjetivo.Size = New System.Drawing.Size(336, 24)
        Me.txthobjetivo.TabIndex = 4
        Me.txthobjetivo.Text = ""
        '
        'Label102
        '
        Me.Label102.Location = New System.Drawing.Point(32, 176)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(56, 24)
        Me.Label102.TabIndex = 53
        Me.Label102.Text = "Objetivo"
        '
        'txthtitulo
        '
        Me.txthtitulo.Location = New System.Drawing.Point(112, 144)
        Me.txthtitulo.Multiline = True
        Me.txthtitulo.Name = "txthtitulo"
        Me.txthtitulo.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txthtitulo.Size = New System.Drawing.Size(336, 24)
        Me.txthtitulo.TabIndex = 3
        Me.txthtitulo.Text = ""
        '
        'Label103
        '
        Me.Label103.Location = New System.Drawing.Point(32, 144)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(56, 24)
        Me.Label103.TabIndex = 51
        Me.Label103.Text = "T�tulo"
        '
        'txthclasificacion
        '
        Me.txthclasificacion.Location = New System.Drawing.Point(112, 48)
        Me.txthclasificacion.Name = "txthclasificacion"
        Me.txthclasificacion.Size = New System.Drawing.Size(336, 20)
        Me.txthclasificacion.TabIndex = 0
        Me.txthclasificacion.Text = ""
        '
        'Label104
        '
        Me.Label104.Location = New System.Drawing.Point(24, 48)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(80, 24)
        Me.Label104.TabIndex = 49
        Me.Label104.Text = "Clasificaci�n"
        '
        'Label105
        '
        Me.Label105.Location = New System.Drawing.Point(24, 448)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(72, 24)
        Me.Label105.TabIndex = 42
        Me.Label105.Text = "Responsable Tema:"
        '
        'txthresponsable
        '
        Me.txthresponsable.Enabled = False
        Me.txthresponsable.Location = New System.Drawing.Point(112, 448)
        Me.txthresponsable.Name = "txthresponsable"
        Me.txthresponsable.Size = New System.Drawing.Size(328, 20)
        Me.txthresponsable.TabIndex = 43
        Me.txthresponsable.Text = ""
        '
        'Label106
        '
        Me.Label106.Location = New System.Drawing.Point(24, 112)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(88, 23)
        Me.Label106.TabIndex = 39
        Me.Label106.Text = "Tipo de Tema:"
        '
        'txthfFin
        '
        Me.txthfFin.Enabled = False
        Me.txthfFin.Location = New System.Drawing.Point(336, 240)
        Me.txthfFin.Name = "txthfFin"
        Me.txthfFin.Size = New System.Drawing.Size(104, 20)
        Me.txthfFin.TabIndex = 38
        Me.txthfFin.Text = ""
        Me.tltMensaje.SetToolTip(Me.txthfFin, "otra cosa")
        '
        'txthfinicio
        '
        Me.txthfinicio.Enabled = False
        Me.txthfinicio.Location = New System.Drawing.Point(112, 240)
        Me.txthfinicio.Name = "txthfinicio"
        Me.txthfinicio.Size = New System.Drawing.Size(112, 20)
        Me.txthfinicio.TabIndex = 37
        Me.txthfinicio.Text = ""
        '
        'Label107
        '
        Me.Label107.Location = New System.Drawing.Point(248, 240)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(88, 16)
        Me.Label107.TabIndex = 35
        Me.Label107.Text = "Fecha de Fin"
        '
        'Label108
        '
        Me.Label108.Location = New System.Drawing.Point(24, 240)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(88, 16)
        Me.Label108.TabIndex = 33
        Me.Label108.Text = "Fecha de Inicio"
        '
        'txthpertenece
        '
        Me.txthpertenece.Enabled = False
        Me.txthpertenece.Location = New System.Drawing.Point(112, 416)
        Me.txthpertenece.Name = "txthpertenece"
        Me.txthpertenece.Size = New System.Drawing.Size(328, 20)
        Me.txthpertenece.TabIndex = 32
        Me.txthpertenece.Text = ""
        '
        'Label109
        '
        Me.Label109.Location = New System.Drawing.Point(24, 416)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(88, 23)
        Me.Label109.TabIndex = 31
        Me.Label109.Text = "Pertenece:"
        '
        'txthtipotema
        '
        Me.txthtipotema.Enabled = False
        Me.txthtipotema.Location = New System.Drawing.Point(112, 112)
        Me.txthtipotema.Name = "txthtipotema"
        Me.txthtipotema.Size = New System.Drawing.Size(184, 20)
        Me.txthtipotema.TabIndex = 40
        Me.txthtipotema.Text = ""
        '
        'chkhmodific
        '
        Me.chkhmodific.Location = New System.Drawing.Point(152, 488)
        Me.chkhmodific.Name = "chkhmodific"
        Me.chkhmodific.Size = New System.Drawing.Size(208, 24)
        Me.chkhmodific.TabIndex = 132
        Me.chkhmodific.Text = "Modificaci�n T�cnica / Cancelacion"
        '
        'chkhnormal
        '
        Me.chkhnormal.Location = New System.Drawing.Point(32, 488)
        Me.chkhnormal.Name = "chkhnormal"
        Me.chkhnormal.TabIndex = 131
        Me.chkhnormal.Text = "Proceso Normal"
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.cmdSeguimiento, Me.cmdLoop, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 679)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(744, 62)
        Me.tlbBotonera.TabIndex = 15
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'cmdSeguimiento
        '
        Me.cmdSeguimiento.ImageIndex = 6
        Me.cmdSeguimiento.Text = "Seguimiento"
        '
        'cmdLoop
        '
        Me.cmdLoop.ImageIndex = 8
        Me.cmdLoop.Text = "C.Etapa"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'pnlRegreso
        '
        Me.pnlRegreso.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlRegreso.Controls.Add(Me.GroupBox3)
        Me.pnlRegreso.Controls.Add(Me.lblEtapa)
        Me.pnlRegreso.Controls.Add(Me.lblRef)
        Me.pnlRegreso.Controls.Add(Me.Label92)
        Me.pnlRegreso.Controls.Add(Me.Label91)
        Me.pnlRegreso.Location = New System.Drawing.Point(208, 184)
        Me.pnlRegreso.Name = "pnlRegreso"
        Me.pnlRegreso.Size = New System.Drawing.Size(336, 232)
        Me.pnlRegreso.TabIndex = 16
        Me.pnlRegreso.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.optProy)
        Me.GroupBox3.Controls.Add(Me.cmdCancelar)
        Me.GroupBox3.Controls.Add(Me.cmdRegresar)
        Me.GroupBox3.Controls.Add(Me.optAnt)
        Me.GroupBox3.Controls.Add(Me.optDT)
        Me.GroupBox3.Controls.Add(Me.optPT)
        Me.GroupBox3.Location = New System.Drawing.Point(16, 80)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(296, 128)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Etapas"
        '
        'optProy
        '
        Me.optProy.Location = New System.Drawing.Point(16, 96)
        Me.optProy.Name = "optProy"
        Me.optProy.TabIndex = 6
        Me.optProy.Text = "Proyecto"
        '
        'cmdCancelar
        '
        Me.cmdCancelar.Image = CType(resources.GetObject("cmdCancelar.Image"), System.Drawing.Image)
        Me.cmdCancelar.Location = New System.Drawing.Point(240, 24)
        Me.cmdCancelar.Name = "cmdCancelar"
        Me.cmdCancelar.Size = New System.Drawing.Size(50, 50)
        Me.cmdCancelar.TabIndex = 5
        '
        'cmdRegresar
        '
        Me.cmdRegresar.Image = CType(resources.GetObject("cmdRegresar.Image"), System.Drawing.Image)
        Me.cmdRegresar.Location = New System.Drawing.Point(176, 24)
        Me.cmdRegresar.Name = "cmdRegresar"
        Me.cmdRegresar.Size = New System.Drawing.Size(50, 50)
        Me.cmdRegresar.TabIndex = 4
        '
        'optAnt
        '
        Me.optAnt.Location = New System.Drawing.Point(16, 72)
        Me.optAnt.Name = "optAnt"
        Me.optAnt.TabIndex = 2
        Me.optAnt.Text = "Anteproyecto"
        '
        'optDT
        '
        Me.optDT.Location = New System.Drawing.Point(16, 48)
        Me.optDT.Name = "optDT"
        Me.optDT.Size = New System.Drawing.Size(136, 24)
        Me.optDT.TabIndex = 1
        Me.optDT.Text = "Documento de trabajo"
        '
        'optPT
        '
        Me.optPT.Location = New System.Drawing.Point(16, 24)
        Me.optPT.Name = "optPT"
        Me.optPT.Size = New System.Drawing.Size(128, 24)
        Me.optPT.TabIndex = 0
        Me.optPT.Text = "Programa de trabajo"
        '
        'lblEtapa
        '
        Me.lblEtapa.AutoSize = True
        Me.lblEtapa.Location = New System.Drawing.Point(176, 56)
        Me.lblEtapa.Name = "lblEtapa"
        Me.lblEtapa.Size = New System.Drawing.Size(45, 16)
        Me.lblEtapa.TabIndex = 3
        Me.lblEtapa.Text = "Label93"
        '
        'lblRef
        '
        Me.lblRef.AutoSize = True
        Me.lblRef.Location = New System.Drawing.Point(184, 8)
        Me.lblRef.Name = "lblRef"
        Me.lblRef.Size = New System.Drawing.Size(55, 16)
        Me.lblRef.TabIndex = 2
        Me.lblRef.Text = "referencia"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(16, 56)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(160, 16)
        Me.Label92.TabIndex = 1
        Me.Label92.Text = "La referencia esta en etapa de:"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(8, 8)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(121, 18)
        Me.Label91.TabIndex = 0
        Me.Label91.Text = "Regresar de Etapa"
        '
        'tltMensaje
        '
        Me.tltMensaje.AutoPopDelay = 5000
        Me.tltMensaje.InitialDelay = 100
        Me.tltMensaje.ReshowDelay = 100
        Me.tltMensaje.ShowAlways = True
        '
        'TabPage1
        '
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(712, 686)
        Me.TabPage1.TabIndex = 6
        Me.TabPage1.Text = "Historial"
        '
        'frmPNN_temas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(744, 741)
        Me.Controls.Add(Me.pnlRegreso)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TBpt)
        Me.Name = "frmPNN_temas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Captura de Temas y Avance"
        Me.TbPgProgramaTrabajo.ResumeLayout(False)
        Me.PnlLectura.ResumeLayout(False)
        Me.TBpt.ResumeLayout(False)
        Me.TbDt.ResumeLayout(False)
        Me.pnlProcAlter.ResumeLayout(False)
        Me.grbComTec.ResumeLayout(False)
        Me.GrbApDT.ResumeLayout(False)
        Me.GrbComEd.ResumeLayout(False)
        Me.pnlDt.ResumeLayout(False)
        Me.tbAnt.ResumeLayout(False)
        Me.pnlAnt.ResumeLayout(False)
        Me.tbProy.ResumeLayout(False)
        Me.pnlproy.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.TbAvance.ResumeLayout(False)
        Me.TpHistorial.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.pnlRegreso.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Form - frmPNN_temas, Metodos y Procesos"

    Private Sub frmPNN_temas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sEtapa = "Inactivo"
        Call Habilita(sEtapa)
        Call Llena_Plan(TVPNN)
        Call Llena_Plan(TVHistorialPNN)
    End Sub

#End Region

#Region " TreeViews, Metodos y Procesos"

#Region " TreeView - TVPNN, Metodos y Procesos"

#Region " TVPNN - TVPNN_AfterSelect, Metodos y Procesos"

    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVPNN.AfterSelect
        If PnlLectura.Visible = True Then
            svariable = e.Node.FullPath
            Matriz = Split(svariable, "\")

            Select Case Matriz.Length
                Case 1
                    sraiz = Matriz(0)
                    stema = ""
                    sPlan = ""
                    sEtapa = "Inactivo"
                    Call Habilita(sEtapa)
                Case 2
                    sPlan = Matriz(1)
                    sEtapa = "Plan"
                    Call Habilita(sEtapa)
                    TVcomites.Refresh()
                    TVcomites.Nodes.Clear()

                Case 3
                    sPlan = Matriz(1)
                    stema = Matriz(2)
                    sEtapa = "Tema"
                    Call Habilita(sEtapa)
                    If sPlan <> "" And stema <> "" Then
                        Call Llena_Temas(sPlan, stema)
                    End If
                    If lblstatus.Text = "NMX" Then
                        Inactivos(tlbBotonera.Buttons.Item(1))
                        If txtrevision.Text = "Cancelacion de una Norma existente" Then
                            lblStatusNorma.Text = "(cancelada)"
                        Else
                            lblStatusNorma.Text = ""
                        End If
                    Else
                        lblStatusNorma.Text = ""
                        Activos(tlbBotonera.Buttons.Item(1))
                    End If
            End Select

            'llena_tvcomites()
        End If

    End Sub

#End Region

#Region " TVPNN - Llena_Plan, Metodos y Procesos"

    Sub Llena_Plan(ByVal tvplanes As Object)
        oTablaPNN = x.ListaPNN("")
        tvplanes.BeginUpdate()
        nodo = tvplanes.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvplanes.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = x.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.SelectedImageIndex = 5
                nodo1.ImageIndex = 5
            Next
        Next
        tvplanes.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvplanes.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvplanes.Sorted = True
        PnlLectura.Visible = True
        'PnlAgrega.Visible = False
    End Sub

#End Region

#End Region

#Region " TreeView - tvcomites, Metodos y Procesos"

#Region " tvcomites - llena_tvcomites, Metodos y Proceos"

    Private Sub llena_tvcomites()

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim x As New clsViewTree.cls(0, gUsuario, gPasswordSql)

        oTablaComite = x.ListaComite

        TVcomites.Nodes.Clear()
        '
        'TVcomitesview


        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim nodo As New TreeNode
        nodo = TVcomites.Nodes.Add("Selecciona un comit�")
        For Each RegComite In oTablaComite.Rows '******COMITES
            nodo = TVcomites.Nodes(0).Nodes.Add(Trim(RegComite("id_comite")))
            oTablaCT = x.ListaCT(RegComite("id_comite"))
            'Item(Trim(RegComite("Cve_Comite")))
            Dim nodo1 As New TreeNode
            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                nodo1 = nodo.Nodes.Add(Trim(RegCT("id_ct")))
                'nodo = TreeView1.Nodes(i).Nodes.Add(RegComite("Cve_Comite")).Nodes.Add(Trim(RegCT("Cve_Comitetec")))
                oTablaSC = x.ListaSC(RegComite("id_comite"), RegCT("id_ct"))
                Dim nodo2 As New TreeNode
                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    'TreeView1.Nodes.Add(Trim(RegSC("cve_subComite"))) 'mariano
                    nodo2 = nodo1.Nodes.Add(Trim(RegSC("id_sc")))
                    oTablaGT = x.ListaGT(RegComite("id_comite"), RegCT("id_ct"), RegSC("id_sc"))
                    Dim nodo3 As New TreeNode
                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        nodo3 = nodo2.Nodes.Add(Trim(RegGT("id_grupo")))
                    Next
                Next
            Next
        Next
        TVcomites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVcomites.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TVcomites.Sorted = True
        'TVcomitesview.ExpandAll()

    End Sub

#End Region

#Region " tvcomites - llena_comite_edit, Metodos y Proceos"

    Private Sub llena_comite_edit()

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim x As New clsViewTree.cls(0, gUsuario, gPasswordSql)

        oTablaComite = x.ListaComite


        TVcomites.BeginUpdate()
        Dim nodo As New TreeNode
        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        nodo = TVcomites.Nodes.Add("Ra�z")
        For Each RegComite In oTablaComite.Rows '******COMITES
            nodo = TVcomites.Nodes(0).Nodes.Add(Trim(RegComite("Cve_Comite")))
            oTablaCT = x.ListaCT(RegComite("Cve_Comite"))
            'Item(Trim(RegComite("Cve_Comite")))
            Dim nodo1 As New TreeNode
            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                nodo1 = nodo.Nodes.Add(Trim(RegCT("Cve_Comitetec")))
                'nodo = TreeView1.Nodes(i).Nodes.Add(RegComite("Cve_Comite")).Nodes.Add(Trim(RegCT("Cve_Comitetec")))
                oTablaSC = x.ListaSC(RegComite("Cve_comite"), RegCT("cve_comitetec"))
                Dim nodo2 As New TreeNode
                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    'TreeView1.Nodes.Add(Trim(RegSC("cve_subComite"))) 'mariano
                    nodo2 = nodo1.Nodes.Add(Trim(RegSC("Cve_SubComite")))

                    oTablaGT = x.ListaGT(RegComite("cve_Comite"), RegCT("cve_comitetec"), RegSC("cve_subComite"))
                    Dim nodo3 As New TreeNode
                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        nodo3 = nodo2.Nodes.Add(Trim(RegGT("Cve_Grupo")))
                    Next
                Next
            Next
        Next
        TVcomites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVcomites.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TVcomites.Sorted = True

    End Sub

#End Region

#End Region

#End Region

#Region " Sub Habilita(sEtapa), Metodos y Procesos"

    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"
                Call Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(7))
                Call Muestra(PnlLectura, lblstatus)
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(5))

            Case "Agregar"
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(7))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Inactivos(txtf1, txtf2, txtrevision, txttipoTema, txtcomite, DT2, txtjustarm)
                Call Muestra(PnlLectura)
                Call Oculta(lblstatus, Txtbasada, txtarmonizacion)
                Call Activos(PnlLectura, TVcomites)
                Call Activos(txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, lblstatus, DT1)
                Call Activos(chkModTec, chkAlternativo, chkNormal)
                Call Limpia_Campos(txtrevision, txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, txtcomite, txtresponsable, txttipoTema)
                chkAlternativo.Checked = False
                chkBasada.Checked = False

            Case "Editar"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(7), tlbBotonera.Buttons.Item(4))
                Call Activos(PnlLectura)
                Call Inactivos(txtnumerotema, txtrevision, txtf1, txtf2, txttipoTema, txtresponsable, txtcomite, chkModTec, chkAlternativo, chkNormal, DT2)
                Call Activos(txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, lblstatus, DT1)


            Case "Inactivo"
                Call Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Activos(tlbBotonera.Buttons.Item(0))
                Call Limpia_Campos(txtrevision, txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, txtf1, txtf2, txtcomite, txttipoTema, lblstatus, txtresponsable, txtjustarm)
                Call Inactivos(txtrevision, txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, txtf1, txtf2, txtcomite, txttipoTema, txtrevision, lblstatus, txtjustarm)
                chkBasada.Checked = False
            Case "Plan"
                Call Activos(tlbBotonera.Buttons.Item(0))
                Call Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Limpia_Campos(txtrevision, txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, txtf1, txtf2, txtcomite, txttipoTema, txtrevision, lblstatus, txtreferencia, Txtbasada, txtarmonizacion, txtjustarm)
                chkBasada.Checked = False
                chkarmonizada.Checked = False
                Call Inactivos(txtrevision, txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, txtf1, txtf2, txtcomite, txttipoTema, txtrevision, lblstatus)
                Call Inactivos(TVcomites)
                chkBasada.Checked = False
                chkAlternativo.Checked = False
                Call Limpia_Campos(txtrevision, txtnumerotema, txtjustificacion, txtobjetivo, txttituloPT, txtClasificacionPT, txtcomite, txtresponsable, txttipoTema)

            Case "Tema"
                Call Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(3))
                Call Inactivos(PnlLectura)

            Case "Seguimiento"
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(7))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))

            Case "DT"
                Call Activos(txtclasificaciondt, txttitulodt, txtf_des_Nmx, CboResponsableDt, txtAprob_Revision_Editorial, CmdActaAprobacion, txtf_aprobCtGT, dtf_aprobCtGT)
                Call Inactivos(txtf_des_Nmx, txtAprob_Revision_Editorial, txtf_aprobCtGT, txtadjActAprobFinal, txtadjDtf, txtf_impActAprob)


            Case "ANT"
                'Call Inactivos(pnlproy, txtnumpags_Ant, txttituloant, txtclasificacion_ant)
                Call Activos(pnlAnt, txtnumpags_Ant)
                Call Activos(tlbBotonera.Buttons.Item(3))

                Call Inactivos(pnlproy)

            Case "PROY"
                Call Activos(pnlproy)
                Call Inactivos(txtclasificaciondt, txttitulodt, txtf_des_Nmx, CboResponsableDt, txtAprob_Revision_Editorial, CmdActaAprobacion, txtadjActAprobFinal, txtf_aprobCtGT, dtf_aprobCtGT)
                Call Inactivos(txtnumpags_Ant, txttituloant, txtclasificacion_ant)
                Call Inactivos(pnlAnt, txtf_ini_compub, txtf_limitecompub)
                Call Activos(txtpaginas_proy)
                Call Activos(tlbBotonera.Buttons.Item(3))
                Call Inactivos(txtf_aprob_com, txtf_ini_compub, txtf_limitecompub, txtfResolucion, TXTF_limrescompub, txtf_aprobrescompub, txtvobo, txtfiniRev, txtftermrev, txtf_edic, txtadjProyfinal, txtfCargaProyf, txtf_imp_actaprob_proy, txtadjactPROYF, txtfcarga_actaprobPROYF, txtacusePROYF, txtf_cargaAntf, cmdProyectoFinal)


        End Select
    End Sub

#End Region

    Private Sub BtnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Dispose()
    End Sub


    Private Sub Llena_Temas(ByVal splan As String, ByVal stema As String)
        Dim Sstatus As String
        Dim sReferencia As String


        'zok1 si falla comenta todo lo que esta entre los zok 1 descomenta zok2
        'busco los datos para la referencia y solo busco en el store esto
        ObjPrograma.Band = False
        ObjPrograma.Buscar(splan, stema)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        ObjPrograma.sReferencia = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        ObjPrograma.Buscar(splan, stema)
        'zok1

        'zok2 ObjPrograma.Buscar(splan, stema)
        PnlLectura.Enabled = False



        sReferencia = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo
        RefCompleta = sReferencia
        'armo la referencia
        If ObjPrograma.RefRegreso < 10 Then
            RefCompleta = RefCompleta + ObjPrograma.RefRegreso
            sReferencia = sReferencia + "R0" + ObjPrograma.RefRegreso
        Else
            RefCompleta = RefCompleta + ObjPrograma.RefRegreso
            sReferencia = sReferencia + "R" + ObjPrograma.RefRegreso
        End If
        If ObjPrograma.RefTraspaso < 10 Then
            RefCompleta = RefCompleta + ObjPrograma.RefTraspaso
            sReferencia = sReferencia + "T0" + ObjPrograma.RefTraspaso
        Else
            RefCompleta = RefCompleta + ObjPrograma.RefTraspaso
            sReferencia = sReferencia + "T" + ObjPrograma.RefTraspaso
        End If

        sRef_A�o = ObjPrograma.RefA�o
        sRef_Comite = ObjPrograma.RefComite
        sRef_Consecutivo = ObjPrograma.RefConsecutivo
        sRef_regreso = ObjPrograma.RefRegreso
        sRef_traspaso = ObjPrograma.RefTraspaso

        txtreferencia.Text = sReferencia

        txtClasificacionPT.Text = ObjPrograma.Clasificacion
        ObjTiposTema.Buscar(ObjPrograma.Tipo_Tema)
        txttipoTema.Text = ObjTiposTema.Descripcion
        txttituloPT.Text = ObjPrograma.Titulo
        txtobjetivo.Text = ObjPrograma.Obj
        txtjustificacion.Text = ObjPrograma.Justificacion


        txtFechaDeclaratoriaVigencia.Text = BuscaDeclaratoriaVigencia(sRef_A�o, sRef_Comite, sRef_Consecutivo, sRef_regreso, sRef_traspaso, txtClasificacionPT.Text)

        'IIf objPrograma.Basada_Norma =True then chkBasada.Checked 
        If ObjPrograma.Basada_Norma = True Then
            chkBasada.Checked = True
        Else
            chkBasada.Checked = False
        End If

        If ObjPrograma.Armonizada = True Then
            chkarmonizada.Checked = True
        Else
            chkarmonizada.Checked = False
        End If

        txtjustarm.Text = ObjPrograma.Justi_Armonizada
        txtarmonizacion.Text = ObjPrograma.Norma
        If (ObjPrograma.F_Inicio) = Nothing Or (ObjPrograma.F_Inicio) = "01/01/1900" Then
            txtf1.Text = ""
        Else
            txtf1.Text = ObjPrograma.F_Inicio
        End If

        txtf2.Text = ObjPrograma.F_Fin

        objRevision.Buscar(ObjPrograma.Revision)
        txtrevision.Text = objRevision.Descripcion
        txtnumerotema.Text = ObjPrograma.Id_Tema
        If ObjPrograma.Basada_Norma = True Then
            chkBasada.Checked = True
            Txtbasada.Text = ObjPrograma.Norma
        Else
            chkBasada.Checked = False
        End If
        Select Case ObjPrograma.Tipo_Pro
            Case "1" 'Proceso Normal
                chkNormal.Checked = True
                chkAlternativo.Checked = False
                chkModTec.Checked = False
            Case "2" 'Proceso Alternativo
                chkAlternativo.Checked = True
                chkNormal.Checked = False
                chkModTec.Checked = False
            Case "3" 'Modificaci�n T�cnica
                chkModTec.Checked = True
                chkNormal.Checked = False
                chkAlternativo.Checked = False
        End Select

        IdentificaEtapa()

        'TBpt.TabPages.Item(1).Enabled = False
        'TBpt.TabPages.Item(2).Enabled = False
        'TBpt.TabPages.Item(3).Enabled = False
        'TBpt.TabPages.Item(4).Enabled = False


        ObjEmpleados.Bandera = 3
        ObjEmpleados.Id_usuario = ObjPrograma.Responsable
        ObjEmpleados.Buscar()
        txtresponsable.Text = ObjEmpleados.NOMBRE_COMPLETO

        Dim srep As String

        'vALIDACI�N PARA SABER EXACTAMENTE A QUE COMIT� PERTENECE.
        'SI ES GRUPO DE TRABAJO
        If ObjPrograma.ID_Grupo <> "NA" Then
            txtcomite.Text = ObjPrograma.ID_Grupo
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Bandera = 4
            ObjComites.Busca_cuatro()

            srep = ObjComites.Responsable
        End If
        'SI ES SUBCOMITE
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txtcomite.Text = ObjPrograma.ID_SC

            ObjComites.Bandera = 3

            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo

            ObjComites.Busca_tres()

            srep = ObjComites.Responsable

        End If
        'SI ES COMITE TECNICO
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txtcomite.Text = ObjPrograma.ID_CT
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo

            ObjComites.Bandera = 2
            ObjComites.Busca_dos()
            srep = ObjComites.Responsable

        End If
        'SI ES DIRECTO DE COMITE
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txtcomite.Text = ObjPrograma.ID_Comite
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo

            ObjComites.Bandera = 1
            ObjComites.Busca_uno()
            srep = ObjComites.Responsable
        End If
        'Busca Responsable de Ct Gt O comite por default
    End Sub

    Private Sub IdentificaEtapa()
        sComite = ObjPrograma.ID_Comite
        sCt = ObjPrograma.ID_CT
        sSc = ObjPrograma.ID_SC
        sGt = ObjPrograma.ID_Grupo
        Select Case ObjPrograma.ID_etapa
            Case 1
                lblstatus.Text = "PT"
                'Case 2
                '    lblstatus.Text = "PA"
                zId_Etapa = 1
            Case 2
                lblstatus.Text = "DT"
                If ObjPrograma.Tipo_Pro = 3 Then

                End If
                zId_Etapa = 2
            Case 3
                lblstatus.Text = "ANT"
                zId_Etapa = 3
            Case 4
                lblstatus.Text = "PROY"
                zId_Etapa = 4
            Case "5"
                lblstatus.Text = "NMX"
                zId_Etapa = 5

        End Select
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs)
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                sEtapa = "Agregar"
                Call Habilita(sEtapa)
                llena_tvcomites()
                Call Carga_Combos()
            Case 1 'Editar
                sEtapa = "Editar"
                Call Habilita(sEtapa)
                llena_tvcomites()

            Case 2 'Deshacer
                sEtapa = "Nulo"
                Call Habilita(sEtapa)
                Call Limpia_Campos()
            Case 3 'Salvar
                If sEtapa = "Editar" Then
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    Call Actualizar()
                Else
                    sEtapa = "Nulo"
                    Call Habilita(sEtapa)
                    Call Insertar()
                End If
            Case 4
                If MsgBox("�Esta seguro de Borrar este Tema", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Normanet") = MsgBoxResult.Yes Then
                    Call Borra()
                End If
            Case 5

            Case 6
                Me.Dispose()
        End Select
    End Sub
    Private Sub Borra()
        Dim sRef As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

        ObjPrograma.Borrar(sPlan, stema)
        ObjFechasavance.Borrar(sPlan, stema, sRef)
        ObjDt.Borrar(sPlan, stema, sRef)
        ObjAnt.Borrar(sPlan, stema, sRef)
        ObjProy.Borrar(sPlan, stema, sRef)
        ProcAlter.Borrar(sPlan, stema, sRef)
        clsDoctosTemas.Borrar(sPlan, stema, sRef)
        ObjComentarios.BorrarComentario(sPlan, stema, sRef)

        Dim FrmTemas As New frmPNN_temas
        FrmTemas.MdiParent = Me.MdiParent
        Me.Dispose()
        FrmTemas.Show()
    End Sub
    Private Sub Carga_Combos()
        dtTiposTema = ObjTiposTema.ListaCombo()
        dtRevision = objRevision.ListaCombo()

        Dim temp As String = ""
        If txttipoTema.Text <> "" Then temp = txttipoTema.Text
        CboTipoTema.DataSource = dtTiposTema
        CboTipoTema.DisplayMember = dtTiposTema.Columns(1).ColumnName
        CboTipoTema.ValueMember = dtTiposTema.Columns(0).ColumnName
        If sEtapa <> "Editar" Then txttipoTema.Text = CboTipoTema.Text
        If temp <> "" Then
            CboTipoTema.Text = temp
        Else
            txttipoTema.Text = ""
        End If

        temp = ""
        If txtrevision.Text <> "" Then temp = txtrevision.Text
        cboRevision.DataSource = dtRevision
        cboRevision.DisplayMember = dtRevision.Columns(1).ColumnName
        cboRevision.ValueMember = dtRevision.Columns(0).ColumnName
        txtrevision.Text = cboRevision.Text
        If temp <> "" Then
            cboRevision.Text = temp
        Else
            txtrevision.Text = ""
        End If


        'Carga el combo de responsables de normalizaci�n
        ObjEmpleados.Bandera = 6
        ObjEmpleados.ListaCombo(cboResponsable)
        txtresponsable.Text = cboResponsable.Text
        If sEtapa = "Agregar" Then
            txttipoTema.Text = ""
            txtrevision.Text = ""
            txtresponsable.Text = ""
        End If

    End Sub
    Private Sub Insertar()
        Dim Proceso As Integer
        Dim sta As String
        Dim tipo As Integer
        Dim revision As String
        Proceso = 0
        If chkNormal.Checked = False And chkAlternativo.Checked = False And chkModTec.Checked = False Then
            MsgBox("Debes de seleccionar el tipo de Proceso del Tema")
            Exit Sub
        End If

        If chkNormal.Checked = True Then
            Proceso = 1
            sta = "1"
        End If
        If chkAlternativo.Checked = True Then
            Proceso = 2
            sta = "2"
        End If
        If chkModTec.Checked = True Then
            Proceso = 3
            sta = "4"
        End If

        tipo = CboTipoTema.SelectedValue
        If tipo = 1 Then
            revision = "0"
        Else
            revision = cboRevision.SelectedValue
        End If
        If chkBasada.Checked = False And chkarmonizada.Checked = False Then
            MsgBox("Debes seleccionar basado en Norma Internacional o Armonizaci�n de Norma")
            Exit Sub
        End If

        'busco los datos para la referencia y solo busco en el store esto
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, txtnumerotema.Text)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        'Referenciar("abandono")
        'ObjPrograma.sReferencia = srefP
        ObjPrograma.sReferencia = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        ObjPrograma.Buscar(sPlan, txtnumerotema.Text)


        If ObjPrograma.Existe = True Then
            MsgBox("El n�mero de tema ya existe en ese plan, Verificar")
            txtnumerotema.Text = ""
            Exit Sub
        End If

        If chkBasada.Checked = True Then
            If Txtbasada.Text = "" Then
                MsgBox("Basada en Norma no puede ir vac�a.")
                Exit Sub
            Else
                sNormaBasada = Txtbasada.Text
            End If

        Else
            sNormaBasada = ""
        End If
        If chkarmonizada.Checked = True Then
            If txtarmonizacion.Text = "" Then
                MsgBox("Armonizada en Norma no puede ir vac�a.")
                Exit Sub
            Else
                sarmonizada = Txtbasada.Text
            End If
        Else
            sarmonizada = ""
        End If



        ObjPrograma.Busca_Referencia(sPlan, sComite, 1) 'Bandera 1 calcula el a�o de primera publicaci�n
        ObjPrograma.Busca_Referencia(sPlan, sComite, 2, ObjPrograma.RefA�o) 'bandera 2 calcula el ultimo consecutivo

        ObjPrograma.ID_etapa = 1
        If sta = "4" Then ObjPrograma.ID_etapa = CInt(sta)
        ObjPrograma.Insertar(ObjPrograma.RefA�o, sComite, ObjPrograma.RefConsecutivo, 0, 0, sPlan, txtnumerotema.Text, txtClasificacionPT.Text, Proceso, tipo, txttituloPT.Text, txtobjetivo.Text, txtjustificacion.Text, txtf1.Text, txtf2.Text, revision, sComite, sCt, sSc, sGt, sta, cboResponsable.SelectedValue, chkBasada.Checked, IIf(chkBasada.Checked = True, Txtbasada.Text, ""), chkarmonizada.Checked, IIf(chkarmonizada.Checked = True, txtjustarm.Text, ""), IIf(chkarmonizada.Checked = True, txtarmonizacion.Text, ""))

        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        Dim sRef As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1
        ObjFechasavance.Buscar(txtnumerotema.Text, sPlan, sRef)


        'zok1 si falla comenta todo lo que esta entre los zok 1 descomenta zok2
        'busco los datos para la referencia y solo busco en el store esto
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, CInt(txtnumerotema.Text))
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        ObjPrograma.sReferencia = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        ObjPrograma.Buscar(sPlan, CInt(txtnumerotema.Text))
        'zok1

        'zok2 ObjPrograma.Buscar(sPlan, CInt(txtnumerotema.Text))
        If ObjFechasavance.BANDERA = False Then
            ObjFechasavance.RefA�o = ObjPrograma.RefA�o
            ObjFechasavance.RefComite = ObjPrograma.RefComite
            ObjFechasavance.RefConsecutivo = ObjPrograma.RefConsecutivo
            ObjFechasavance.RefRegreso = ObjPrograma.RefRegreso
            ObjFechasavance.RefTraspaso = ObjPrograma.RefTraspaso
            ObjFechasavance.Status = 1
            ObjFechasavance.sReferencia = ObjPrograma.sReferencia
            ObjFechasavance.Actualiza(1, sPlan, txtnumerotema.Text, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
            'ValidaEtapa1()
            EtapasInspeccion()
        End If
        sEtapa = "Tema"
        Call Habilita(sEtapa)
        Call Llena_Plan(TVHistorialPNN)
        MsgBox("Se ha capturado correctamente el tema en el Programa de Trabajo correspondiente")
        Dim FrmTemas As New frmPNN_temas
        FrmTemas.MdiParent = Me.MdiParent
        Me.Dispose()
        FrmTemas.Show()


    End Sub
    Private Sub Actualizar()

        Proceso = 0
        If chkNormal.Checked = False And chkAlternativo.Checked = False And chkModTec.Checked = False Then
            MsgBox("Debes de seleccionar el tipo de Proceso del Tema")
            Exit Sub
        End If

        If chkNormal.Checked = True Then
            Proceso = 1
            sta = "1"
        End If
        If chkAlternativo.Checked = True Then
            Proceso = 2
            sta = "2"
        End If
        If chkModTec.Checked = True Then
            Proceso = 3
            sta = "3"
        End If
        revision = cboRevision.SelectedValue
        tipo = CboTipoTema.SelectedValue

        If chkBasada.Checked = True And chkarmonizada.Checked = False Then
            If Txtbasada.Text = "" Then
                MsgBox("Basada en Norma no puede ir vac�a.")
                Exit Sub
            Else
                sNormaBasada = Txtbasada.Text
            End If
        End If

        If chkarmonizada.Checked = True And chkBasada.Checked = False Then
            If txtarmonizacion.Text = "" Then
                MsgBox("Arminizaci�n en Norma no puede ir vac�a.")
                Exit Sub
            Else
                sNormaBasada = txtarmonizacion.Text
            End If
        End If
        If chkBasada.Checked = False And chkarmonizada.Checked = False Then
            MsgBox("Debes seleccionar basado en Norma Internacional o Armonizaci�n de Norma")
            Exit Sub
        End If

        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        Dim sRef As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1

        ObjFechasavance.Buscar(txtnumerotema.Text, sPlan, sRef)

        If ObjFechasavance.BANDERA = False Then
            ObjFechasavance.Actualiza(1, sPlan, txtnumerotema.Text, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
        End If

        If chkarmonizada.Checked = True Then
            ObjPrograma.Armonizada = True
        Else
            ObjPrograma.Armonizada = False
            ObjPrograma.Justi_Armonizada = ""
        End If
        ObjPrograma.sReferencia = sRef
        ObjFechasavance.F_carga_minuta = fcarga_minuta.Text
        ObjPrograma.Actualizar(sPlan, stema, txtClasificacionPT.Text, Proceso, tipo, txttituloPT.Text, txtobjetivo.Text, txtjustificacion.Text, txtf1.Text, txtf2.Text, revision, sComite, sCt, sSc, sGt, ObjPrograma.ID_etapa, cboResponsable.SelectedValue, chkBasada.Checked, sNormaBasada)
        EtapasInspeccion()
        TVcomites.Nodes.Clear()
        TVPNN.Nodes.Clear()
        TVPNN.Refresh()
        TVcomites.Refresh()
        sEtapa = "Tema"
        Call Habilita(sEtapa)
        Call Llena_Plan(TVHistorialPNN)
        TVPNN.Sorted = True
        Dim FrmTemas As New frmPNN_temas
        FrmTemas.MdiParent = Me.MdiParent
        Me.Dispose()
        FrmTemas.Show()
    End Sub



    Private Sub TVcomitesview_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVcomites.AfterSelect
        Dim Matriz As Array
        Dim svariable As String

        Dim sraiz As String
        Dim bandera As Integer
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                sComite = "NA"
                sCt = "NA"
                sSc = "NA"
                sGt = "NA"

            Case 2
                sComite = Matriz(1)
                sCt = "NA"
                sSc = "NA"
                sGt = "NA"

                txtcomite.Text = ""
                txtcomite.Text = Matriz(1)

                ObjComites.ID_Comite = Matriz(1)
                ObjComites.Bandera = 1
                ObjComites.Busca_uno()
                Call llena_responsable(ObjComites.Responsable)
                cboResponsable.SelectedValue = ObjComites.Responsable






            Case 3

                If Microsoft.VisualBasic.Left(Matriz(2), 2) = "GT" Then
                    sComite = Matriz(1)
                    sCt = "NA"
                    sSc = "NA"
                    sGt = Matriz(2)
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(2)

                    ObjComites.ID_Comite = Matriz(1)
                    ObjComites.ID_CT = sCt
                    ObjComites.ID_SC = sSc
                    ObjComites.ID_GT = sGt
                    ObjComites.Bandera = 4
                    ObjComites.Busca_cuatro()
                    Call llena_responsable(ObjComites.Responsable)
                    Try
                        cboResponsable.SelectedValue = ObjComites.Responsable
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try

                Else

                    sComite = Matriz(1)
                    sCt = Matriz(2)
                    sSc = "NA"
                    sGt = "NA"
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(2)
                    ObjComites.ID_Comite = Matriz(1)
                    ObjComites.ID_CT = Matriz(2)
                    ObjComites.ID_SC = sSc
                    ObjComites.ID_GT = sGt
                    ObjComites.Bandera = 2
                    ObjComites.Busca_dos()
                    Call llena_responsable(ObjComites.Responsable)
                    cboResponsable.SelectedValue = ObjComites.Responsable

                End If

            Case 4

                If Microsoft.VisualBasic.Left(Matriz(3), 2) = "GT" Then
                    sComite = Matriz(1)
                    sCt = Matriz(2)
                    sSc = "NA"
                    sGt = Matriz(3)
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(3)

                    ObjComites.ID_Comite = Matriz(1)
                    ObjComites.ID_CT = Matriz(2)
                    ObjComites.ID_SC = sSc
                    ObjComites.ID_GT = Matriz(3)
                    ObjComites.Bandera = 4
                    ObjComites.Busca_cuatro()
                    Call llena_responsable(ObjComites.Responsable)
                    cboResponsable.SelectedValue = ObjComites.Responsable





                Else

                    sComite = Matriz(1)
                    sCt = Matriz(2)
                    sSc = Matriz(3)
                    sGt = "NA"
                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(3)

                    ObjComites.ID_Comite = Matriz(1)
                    ObjComites.ID_CT = Matriz(2)
                    ObjComites.ID_SC = Matriz(3)
                    ObjComites.ID_GT = sGt
                    ObjComites.Bandera = 3
                    ObjComites.Busca_tres()
                    Call llena_responsable(ObjComites.Responsable)
                    cboResponsable.SelectedValue = ObjComites.Responsable

                End If


            Case 5
                sComite = Matriz(1)
                sCt = Matriz(2)
                sSc = Matriz(3)
                sGt = Matriz(4)
                txtcomite.Text = ""
                txtcomite.Text = Matriz(4)

                ObjComites.ID_Comite = Matriz(1)
                ObjComites.ID_CT = Matriz(2)
                ObjComites.ID_SC = Matriz(3)
                ObjComites.ID_GT = Matriz(4)
                ObjComites.Bandera = 4
                ObjComites.Busca_cuatro()
                Call llena_responsable(ObjComites.Responsable)
                cboResponsable.SelectedValue = ObjComites.Responsable
        End Select
    End Sub


    Private Sub CboTipoTema_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboTipoTema.SelectedIndexChanged
        If sEtapa = "Agregar" Then
            txttipoTema.Text = CboTipoTema.Text

            If CboTipoTema.Text = "Proyecto Publicado" Then
                txtobjetivo.Text = "Na"
                txtobjetivo.Enabled = False
                txtjustificacion.Text = "Na"
                txtjustificacion.Enabled = False
                DT1.Enabled = False
                cboRevision.Enabled = False
                DT2.Enabled = True
            Else
                txtobjetivo.Text = ""
                txtobjetivo.Enabled = True
                txtjustificacion.Enabled = True
                txtjustificacion.Text = ""
                DT1.Enabled = True
                DT2.Enabled = False
                cboRevision.Enabled = True
                txtf1.Text = ""
                txtf2.Text = ""
            End If
        End If
        If sEtapa = "Editar" Then
            txttipoTema.Text = CboTipoTema.Text
        End If
    End Sub

    Private Sub cboResponsable_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsable.SelectedIndexChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtresponsable.Text = cboResponsable.Text
        End If
    End Sub

    Private Sub chkNormal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If chkNormal.Checked = True Then
            chkAlternativo.Checked = False
            chkModTec.Checked = False
        End If
    End Sub

    Private Sub txtClasificacionPT_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtClasificacionPT.Validating
        If sEtapa = "Agregar" Then
            If txtClasificacionPT.Text = "" Then
                MsgBox("El campo de Clasificaci�n del tema es requerido")
                txtClasificacionPT.Focus()
            End If
        End If
    End Sub
    Function Limpia_Treevies()
        oTablaPNN.Clear()
        oTablaDPy.Clear()
        TVPNN.Nodes.Clear()
    End Function
    Private Sub tlbBotonera_ButtonClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Dim Ibandera As Integer
        Dim DocumentoProyectoFinal As String = ""
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                sEtapa = "Agregar"
                If sPlan = "" And stema = "" Then
                    If MsgBox("Desea agregar un nuevo Plan Nacional De Normalizacion?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Normanet") = MsgBoxResult.Yes Then
                        Dim frmPlan As New frmPNN
                        frmPlan.MdiParent = Me.MdiParent
                        frmPlan.Show()
                    End If
                Else
                    Call Habilita(sEtapa)
                    Call llena_TreeView()
                    Call Carga_Combos()
                End If
            Case 1 'Editar
                sEtapa = "Editar"
                Call Habilita(sEtapa)
                TVcomites.Refresh()
                TVcomites.Nodes.Clear()
                Call llena_TreeView()
                Call Carga_Combos()
                Call Carga_Combos_Responsable("PT")
                'llena_tvcomites()
            Case 2 'Deshacer

                Dim FrmTemas As New frmPNN_temas
                frmtemas.MdiParent = Me.MdiParent
                Me.Dispose()
                FrmTemas.Show()

            Case 3 'Salvar
                '****Para traer la ruta donde se insertan los documentos
                Dim ruta As String
                If ObjPrograma.ID_Grupo <> "NA" Then
                    ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
                End If
                'SI ES SUBCOMITE
                If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
                End If
                'SI ES COMITE TECNICO
                If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
                End If
                'SI ES DIRECTO DE COMITE
                If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
                    ruta = ObjPrograma.ID_Comite
                End If
                Select Case sEtapa
                    Case "Editar"
                        Call Actualizar()

                    Case "Agregar"
                        Call Insertar()

                    Case "DT"
                        Id_etapa = 2

                        If chkrevedit.Checked And txtAprob_Revision_Editorial.Text = "" Then
                            MsgBox("Falta Fecha de Aprobaci�n de Revisi�n Editorial")
                        End If

                        If chkAlternativo.Checked And (txtf_inicresp.Text = "" Or txtf_finresp.Text = "") Then
                            MsgBox("Faltan fechas de procedimiento alternativo por capturar")
                            Exit Sub
                        End If

                        If bandModifClasific <> True Then
                            MsgBox("Aun no se ha modificado la clasificacion")
                            Exit Sub
                        End If
                        Dim bandHayComentarios As Boolean = False
                        If optComTecSi.Checked And optApDtNo.Checked Then
                            Preguntas(2, "DT")
                            bandHayComentarios = True
                            If band = True Then Exit Sub
                        End If

                        Dim sref As String

                        ObjPrograma.Band = False
                        ObjPrograma.Buscar(sPlan, stema)
                        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

                        ObjDt.Buscar(stema, sPlan, sref)
                        If ObjDt.Encontrado = True Then
                            ObjDt.Bandera = True
                            Ibandera = 2
                        Else
                            ObjDt.Bandera = False
                            Ibandera = 1
                        End If

                        If chkAlternativo.Checked = True Then
                            ObjPrograma.Band = False
                            ObjPrograma.Buscar(sPlan, stema)
                            sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

                            ObjPrograma.Cambia_Proceso(stema, sPlan, sref)
                        End If


                        'Aqui se mandan los par�metros para entrar al sp segun sea el caso edicion o inserci�n
                        ObjDt.RefA�o = sRef_A�o
                        ObjDt.RefComite = sRef_Comite
                        ObjDt.RefConsecutivo = sRef_Consecutivo
                        ObjDt.RefRegreso = sRef_regreso
                        ObjDt.RefTraspaso = sRef_traspaso
                        Dim representante As String
                        CboResponsableDt.Text = txtresponsableDt.Text
                        representante = CboResponsableDt.SelectedValue
                        ObjDt.Actualiza(stema, sPlan, txttitulodt.Text, txtclasificaciondt.Text, representante, Ibandera, Id_etapa)
                        'zok clsDt.Actualiza(stema, sPlan, txttitulodt.Text, txtclasificaciondt.Text, CboResponsableDt.SelectedValue, Ibandera, Id_etapa)

                        'ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo

                        'Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server") + objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Comentarios")) + "\" + ruta + "\" + txtadjDtf.Text)
                        Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\" + txtadjDtf.Text)
                        Dim sPath2 = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\" + txtadjActAprobFinal.Text)
                        Dim sPath6 = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\" + txtminuta.Text)
                        Dim rutaOriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\")


                        'Aqui se valida si trae documento adjunto y se copia el archivo
                        If myStream <> "" Then
                            ObjPrograma.Band = False
                            ObjPrograma.Buscar(sPlan, stema)
                            clsDoctosTemas.RefA�o = ObjPrograma.RefA�o
                            clsDoctosTemas.RefComite = ObjPrograma.RefComite
                            clsDoctosTemas.RefConsecutivo = ObjPrograma.RefConsecutivo
                            clsDoctosTemas.RefRegreso = ObjPrograma.RefRegreso
                            clsDoctosTemas.RefTraspaso = ObjPrograma.RefTraspaso
                            clsDoctosTemas.Status = 1
                            clsCopia.CopiaArchivos(myStream, sPath, rutaOriginal)
                            clsDoctosTemas.Actualiza(stema, sPlan, "3", txtadjDtf.Text, 1)
                        End If
                        If myStream2 <> "" Then
                            clsCopia.CopiaArchivos(myStream2, sPath2, rutaOriginal)
                            txtfcargaActaprobFinal.Text = Format(Today.Now, "dd/MM/yyyy")
                            clsDoctosTemas.Actualiza(stema, sPlan, "4", txtadjActAprobFinal.Text, 1)

                        End If
                        Dim ref As String
                        If myStream6 <> "" Then
                            'zok1 
                            ObjPrograma.Band = False
                            ObjPrograma.Buscar(sPlan, stema)
                            ObjPrograma.Band = True
                            'ya que saque los datos busco con la referencia para que me de el verdadero registro
                            ref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
                            'zok1
                            clsCopia.CopiaArchivos(myStream6, sPath6, rutaOriginal)
                            clsDoctosTemas.RefA�o = ObjPrograma.RefA�o
                            clsDoctosTemas.RefComite = ObjPrograma.RefComite
                            clsDoctosTemas.RefConsecutivo = ObjPrograma.RefConsecutivo
                            clsDoctosTemas.RefRegreso = ObjPrograma.RefRegreso
                            clsDoctosTemas.RefTraspaso = ObjPrograma.RefTraspaso
                            clsDoctosTemas.Status = 1
                            'zok
                            clsDoctosTemas.Buscar(stema, sPlan, "12", sref)
                            clsDoctosTemas.sReferencia = sref
                            If clsDoctosTemas.Encontrado = True Then
                                clsDoctosTemas.Actualiza(stema, sPlan, "12", txtminuta.Text, 2)
                            Else
                                clsDoctosTemas.Actualiza(stema, sPlan, "12", txtminuta.Text, 1)
                            End If
                        End If


                        ObjPrograma.Band = False
                        ObjPrograma.Buscar(sPlan, stema)
                        ObjPrograma.Band = True
                        'ya que saque los datos busco con la referencia para que me de el verdadero registro
                        ref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
                        'zok1

                        ObjPrograma.Buscar(sPlan, stema)
                        If ObjPrograma.Tipo_Pro = 2 Then

                            pnlProcAlter.Visible = True
                            ProcAlter.Buscar(sPlan, stema, sref)
                            If ProcAlter.Encontrado = True Then
                                ProcAlter.Bandera = 2
                            Else
                                ProcAlter.Bandera = 1
                                ProcAlter.Status = 1
                            End If

                            ObjPrograma.Buscar(sPlan, stema)
                            With ProcAlter
                                .RefTraspaso = ObjPrograma.RefTraspaso
                                .RefA�o = ObjPrograma.RefA�o
                                .RefComite = ObjPrograma.RefComite
                                .RefRegreso = ObjPrograma.RefRegreso
                                .RefConsecutivo = ObjPrograma.RefConsecutivo

                                .Id_Plan = sPlan
                                .Id_tema = stema
                                .Responsable = cboresponsable_procalt.SelectedValue
                                .F_Inicio_Responsable = IIf(txtf_inicresp.Text = "" = True, Nothing, txtf_inicresp.Text)
                                .F_Fin_Responsable = IIf(txtf_finresp.Text = "" = True, Nothing, txtf_finresp.Text)
                                .F_Inicio_Comentarios = IIf(txtf_inic_com.Text = "" = True, Nothing, txtf_inic_com.Text)
                                .F_Fin_Comentarios = IIf(txtf_fin_com.Text = "" = True, Nothing, txtf_fin_com.Text)
                                .F_Carga_Minuta_Terminacion = IIf(fcarga_minuta.Text = "" = True, Nothing, fcarga_minuta.Text)
                                .sReferencia = sref
                                .Actualiza()
                            End With
                        End If

                        'Validacion para cambiar de etapa
                        '******************************************************
                        '******************************************************
                        'If (optComTecNo.Checked = False And optComEdNo.Checked = False) Or optApDtSi.Checked Or chkAlternativo.Checked = True Then
                        Dim pasa As Boolean
                        If chkrevedit.Checked = False And txtAprob_Revision_Editorial.Text = "" Then
                            pasa = True
                        Else
                            If chkrevedit.Checked = True And txtAprob_Revision_Editorial.Text <> "" Then
                                pasa = True
                            Else
                                pasa = False
                            End If
                        End If
                        If chkrevedit.Checked = True Then
                            If txtf_des_Nmx.Text <> "" And pasa = True And txtfcargaDtFinal.Text <> "" And bandHayComentarios = False Then
                                Id_etapa = 3
                                MsgBox("El tema avanzar� de Dt a Anteproyecto")
                            End If
                        Else
                            If txtf_des_Nmx.Text <> "" And txtfcargaDtFinal.Text <> "" Then
                                Id_etapa = 3
                                MsgBox("El tema avanzar� de Dt a Anteproyecto")
                            End If

                        End If
                        ''If txtf_des_Nmx.Text <> "" And txtAprob_Revision_Editorial.Text <> "" And txtfcargaDtFinal.Text <> "" And txtf_impActAprob.Text <> "" And txtfcargaActaprobFinal.Text <> "" And txtf_aprobCtGT.Text <> "" Then
                        ''    Id_etapa = 3
                        ''    MsgBox("El tema avanzar� de Dt a Anteproyecto")
                        ''End If


                        '*******************************************************************
                        'actualiza las fechas de fechas en avance
                        ObjFechasavance.sReferencia = sref
                        ObjFechasavance.Avance_Fechas_Editar_DT(stema, sPlan, txtf_des_Nmx.Text, txtfcargaDtFinal.Text, txtAprob_Revision_Editorial.Text, Id_etapa)
                        MsgBox("Los datos del tema han sido actualizados correctamente")
                        pnlDt.Enabled = False
                        EtapasInspeccion()
                        Dim FrmTemas As New frmPNN_temas
                        frmtemas.MdiParent = Me.MdiParent
                        Me.Dispose()
                        FrmTemas.Show()

                    Case "ANT"
                        Dim ClsAnt As New ClsAnt.P_Ant(0, gUsuario, gPasswordSql)
                        Referenciar("abandono")
                        ClsAnt.Buscar(stema, sPlan, srefP)
                        If bandModifClasificAnt = True Then
                            MsgBox("Aun no se ha modificado la clasificacion")
                            Exit Sub
                        End If
                        'zok1
                        'busco los datos para la referencia y solo busco en el store esto
                        Referenciar("abandono")
                        ClsAnt.Buscar(stema, sPlan, srefP)
                        If ClsAnt.Encontrado = True Then
                            Ibandera = 2
                        Else
                            Ibandera = 1
                        End If
                        Bandera_Ant = 3
                        'If txtclasificacion_ant.Text <> "" And txttituloant.Text <> "" And txtnumpags_Ant.Text <> "" And txtresponsable_ant.Text <> "" And txtadjantF.Text <> "" And txtcarg_antfinal.Text <> "" And txtfcargaActaprobFinal.Text <> "" And TextBox2.Text <> "" And txtcarg_antfinal.Text <> "" Then
                        If txtf_impActAprob.Text <> "" And txtf_aprobCtGT.Text <> "" And txtfcargaActaprobFinal.Text <> "" And TextBox2.Text <> "" And txtcarg_antfinal.Text <> "" Then
                            Bandera_Ant = 4
                            MsgBox("El tema se pasar� a etapa de Proyecto")
                        End If
                        'Dim sPath3 = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\")
                        Dim spath3 As String
                        Dim Rutaoriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\")

                        'Aqui se valida si trae documento adjunto y se copia el archivo Anteproyecto FInal
                        If myStream5 <> "" Then
                            spath3 = rutaoriginal + txtadjantF.Text
                            clsCopia.CopiaArchivos(myStream5, spath3, Rutaoriginal)
                            clsDoctosTemas.Actualiza(stema, sPlan, "7", txtadjantF.Text, 1)
                            spath3 = ""
                        End If

                        If myStream7 <> "" Then
                            spath3 = rutaoriginal + txtadjActAprobFinal.Text
                            clsCopia.CopiaArchivos(myStream7, spath3, Rutaoriginal)
                            'no se para que sirve
                            clsDoctosTemas.Actualiza(stema, sPlan, "4", txtadjActAprobFinal.Text, 1)
                            spath3 = ""
                        End If

                        If myStream8 <> "" Then
                            spath3 = rutaoriginal + TextBox3.Text
                            clsCopia.CopiaArchivos(myStream8, spath3, Rutaoriginal)
                            'no se para que sirve
                            clsDoctosTemas.Actualiza(stema, sPlan, "15", TextBox3.Text, 1)
                            spath3 = ""
                        End If

                        ClsAnt.RefA�o = ObjPrograma.RefA�o
                        ClsAnt.RefComite = ObjPrograma.RefComite
                        ClsAnt.RefConsecutivo = ObjPrograma.RefConsecutivo
                        ClsAnt.RefRegreso = ObjPrograma.RefRegreso
                        ClsAnt.RefTraspaso = ObjPrograma.RefTraspaso
                        ClsAnt.F_Correcciones = txtF_Correcciones.Text
                        ClsAnt.Correcciones = IIf(optCorrSi.Checked = True, 1, 0)
                        If optCorrSi.Checked = False Then ClsAnt.F_Correcciones = Nothing
                        ClsAnt.Actualiza(Ibandera, sPlan, stema, txttituloant.Text, txtnumpags_Ant.Text, txtclasificacion_ant.Text, cboresponsable_ant.SelectedValue, Bandera_Ant, srefP)
                        'actuliza las fechas en esta etapa
                        '*************************************************************
                        'inserta o actualiza las fechas 
                        If txtf_impActAprob.Text <> "" Then ObjFechasavance.F_Impresion_ActaAprobacion = txtf_impActAprob.Text
                        If txtfcargaActaprobFinal.Text <> "" Then ObjFechasavance.F_Carga_ActaAprobacion = txtfcargaActaprobFinal.Text
                        If TextBox2.Text <> "" Then ObjFechasavance.F_Carga_minuta_Apro = TextBox2.Text
                        If txtcarg_antfinal.Text <> "" Then ObjFechasavance.F_CARGA_ANTF = txtcarg_antfinal.Text

                        'inserto los documentos en las tablas
                        If txtadjActAprobFinal.Text <> "" Then
                            insertaDoctos(txtadjActAprobFinal.Text, 4)
                            cmdacta.Enabled = False
                        End If

                        If TextBox3.Text <> "" Then
                            insertaDoctos(TextBox3.Text, 15)
                            Button1.Enabled = False
                        End If
                        If txtadjantF.Text <> "" Then
                            insertaDoctos(txtadjantF.Text, 7)
                            cmdant.Enabled = False
                        End If

                        ObjFechasavance.Avance_Fechas_Editar_Ant(stema, sPlan, Bandera_Ant, txtf_aprobCtGT.Text, txtcarg_antfinal.Text, srefP)
                        MsgBox("Los datos del tema han sido actualizados correctamente")
                        pnlAnt.Enabled = False
                        EtapasInspeccion()
                        Dim FrmTemas As New frmPNN_temas
                        frmtemas.MdiParent = Me.MdiParent
                        Me.Dispose()
                        FrmTemas.Show()


                    Case "PROY"
                        If bandModifClasificProy = True Then
                            MsgBox("Aun no se ha modificado la clasificacion")
                            Exit Sub
                        End If
                        If txtf_ini_compub.Text = "" Then
                            'MsgBox("La Fecha de Publicaci�n a periodo de Comentario P�blico" & vbCrLf & " No puede estar en blanco")
                            MsgBox("Falta la Fecha de Publicaci�n a periodo de Comentario P�blico")
                            banFecha = False 'NUEVO
                            'Exit Sub
                        End If
                        If banFecha = True Then
                            MsgBox("La Diferencia de fechas no puede ser menor a 60 dias")
                            Exit Sub
                        End If

                        Dim bandabandonar As Boolean = False

                        If txtf_ap2.Text = "" Then
                            bandabandonar = True
                        Else
                            DTf_ap_res2.Value = txtf_ap2.Text
                        End If
                        If TXTF_limrescompub.Text <> "" Then

                            If Today.Date <= CDate(TXTF_limrescompub.Text) Then
                                'ose nada y guarda
                            Else
                                If txtf_ap2.Text <> "" Then
                                    'osea otra vez nada y guardo
                                Else
                                    Preguntas(4, "PROY", True)
                                    'If band = True Then Exit Sub
                                    Exit Sub
                                End If
                            End If
                        End If


                        'roy me dijo que si tenia esta fecha txtf_aprobrescompub no preguntaba lo siguiente
                        ' actulizacion roy me dijo que ademas si txtf_limitecompub.Text < a hoy entonces pregunto
                        ' que siempre no que 
                        'If bandCom = True And txtvobo.Text = "" And txtf_aprobrescompub.Text = "" And CDate(txtf_limitecompub.Text) < Today.Now Then
                        If TXTF_limrescompub.Text <> "" Then
                            If bandCom = True And txtvobo.Text = "" And CDate(TXTF_limrescompub.Text) <= Today.Now Then
                                MsgBox("Fecha Vo. Bo. Comit� es necesaria ya que tuvo comentarios")
                                Exit Sub
                            End If
                        End If

                        Referenciar("abandono")
                        clsProy.Buscar(stema, sPlan, srefP)
                        If clsProy.Encontrado = True Then
                            Ibandera = 2
                        Else
                            Ibandera = 1
                        End If
                        Bandera_Proy = 4
                        Dim sPath4 = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\" + txtadjProyfinal.Text)
                        Dim Rutaoriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\")
                        'Aqui se valida si trae documento adjunto y se copia el archivo Proyecto FInal
                        Referenciar("abandono")
                        clsDoctosTemas.RefA�o = ObjPrograma.RefA�o
                        clsDoctosTemas.RefComite = ObjPrograma.RefComite
                        clsDoctosTemas.RefConsecutivo = ObjPrograma.RefConsecutivo
                        clsDoctosTemas.RefRegreso = ObjPrograma.RefRegreso
                        clsDoctosTemas.RefTraspaso = ObjPrograma.RefTraspaso
                        If myStream3 <> "" Then
                            clsCopia.CopiaArchivos(myStream3, sPath4, Rutaoriginal)
                            clsDoctosTemas.Actualiza(stema, sPlan, "8", txtadjProyfinal.Text, 1)
                        End If

                        REM usar un metodo para adjuntar (no se utiliza la clase por falta de porformance
                        DocumentoProyectoFinal = ProcesarDocumentoFinal()
                        If DocumentoProyectoFinal <> "" Then
                            clsDoctosTemas.Actualiza(stema, sPlan, "22", DocumentoProyectoFinal, 1)
                        End If

                        Dim sPath5 = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\" + txtadjactPROYF.Text)
                        RutaOriginal = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + ruta + "\")
                        'documento Acta de aprobacion Proy
                        If myStream4 <> "" Then
                            clsCopia.CopiaArchivos(myStream4, sPath5, RutaOriginal)
                            clsDoctosTemas.Actualiza(stema, sPlan, "6", txtadjactPROYF.Text, 1)
                        End If
                        'aqui se valida para que contenga todos los datos necesarios para avanzar de etapa a NMX
                        'If txtf_ini_compub.Text <> "" And txtf_limitecompub.Text <> "" And txtclasificacion_proy.Text <> "" And txtresponsable_proy.Text <> "" And txtpaginas_proy.Text <> "" And txttitulo_Proy.Text <> "" And txtf_limitecompub.Text <> "" And txtfResolucion.Text <> "" And TXTF_limrescompub.Text <> "" And txtf_aprobrescompub.Text <> "" And txtvobo.Text <> "" And txtfiniRev.Text <> "" And txtftermrev.Text <> "" And txtf_edic.Text <> "" And txtfCargaProyf.Text <> "" And txtf_imp_actaprob_proy.Text <> "" And txtfcarga_actaprobPROYF.Text <> "" And txtacusePROYF.Text <> "" Then

                        ' actulizacion roy me dijo que ademas si txtf_limitecompub.Text < a hoy entonces pregunto

                        If txtf_limitecompub.Text <> "" Then
                            If bandCom = True And txtf_aprobrescompub.Text = "" And CDate(txtf_limitecompub.Text) < Today.Now Then
                                If txtf_ap2.Text = "" Then
                                    Preguntas(4, "ANT")
                                End If
                            End If
                            ''If txtftermrev.Text <> "" And txtfverifrefProy.Text <> "" And txtf_edic.Text <> "" And txtfCargaProyf.Text <> "" And txtf_imp_actaprob_proy.Text <> "" And txtfcarga_actaprobPROYF.Text <> "" And txtacusePROYF.Text <> "" Then
                            ''segun roy siempre guarda tenga o no las fechsa de txtftermrev y txtfverifrefProy
                            'HMC 3-Mar-2015: SE CONVIERTE EN LLAVE el Check para cambiar a Norma 
                            'If txtf_edic.Text <> "" And txtfCargaProyf.Text <> "" And txtf_imp_actaprob_proy.Text <> "" And txtfcarga_actaprobPROYF.Text <> "" And txtacusePROYF.Text <> "" Then

                            If txtf_edic.Text <> "" And txtfCargaProyf.Text <> "" And txtf_imp_actaprob_proy.Text <> "" And txtfcarga_actaprobPROYF.Text <> "" And txtacusePROYF.Text <> "" And chkCambiaNorma.Checked = True And txtfiniRev.Text <> "" And txtftermrev.Text <> "" And txtfverifrefProy.Text <> "" Then
                                Bandera_Proy = 5
                            Else
                                Bandera_Proy = 4
                                If chkCambiaNorma.Checked = True Then
                                    MsgBox("Favor de verificar los campos de fecha requeridos para pasar a norma.")
                                End If
                            End If
                        End If

                        Referenciar("abandono")
                        clsProy.RefA�o = ObjPrograma.RefA�o
                        clsProy.RefComite = ObjPrograma.RefComite
                        clsProy.RefConsecutivo = ObjPrograma.RefConsecutivo
                        clsProy.RefRegreso = ObjPrograma.RefRegreso
                        clsProy.RefTraspaso = ObjPrograma.RefTraspaso
                        clsProy.sReferencia = srefP
                        clsProy.Actualiza(Ibandera, sPlan, stema, txtclasificacion_proy.Text, txttitulo_Proy.Text, txtpaginas_proy.Text, 0, cboResponsable_proy.SelectedValue, Bandera_Proy, srefP, txtPaginasNorma.Text)
                        ObjFechasavance.sReferencia = srefP
                        ObjFechasavance.F_VerifRev_PROYF = IIf(txtfverifrefProy.Text = "", Nothing, txtfverifrefProy.Text)
                        ObjFechasavance.F_Amp_Resolucion = IIf(txtf_aprobrescompub.Text = "", Nothing, txtf_aprobrescompub.Text)

                        ObjFechasavance.Avance_Fechas_Editar_Proy(stema, sPlan, Bandera_Proy, txtf_aprob_com.Text, txtf_ini_compub.Text, txtf_limitecompub.Text, txtfResolucion.Text, TXTF_limrescompub.Text, txtf_ap2.Text, txtvobo.Text, txtfiniRev.Text, txtftermrev.Text, txtf_edic.Text, txtf_imp_actaprob_proy.Text, txtfcarga_actaprobPROYF.Text, txtacusePROYF.Text, txtfCargaProyf.Text)
                        'HMC 3-Mar-2015: SE CONVIERTE EN LLAVE el Check para cambiar a Norma 
                        'If Bandera_Proy = 5 Then
                        If Bandera_Proy = 5 Then
                            REM no es posible pasar a norma si se tienen comentarios y no se ha agregado
                            REM el documento de proyecto final tras comentarios
                            If (optComTecSiProy.Checked Or optComEdSiProy.Checked) And txtProyectoFinal.Text = "" Then
                                MsgBox("Para pasar a norma es necesario adjuntar el proyecto final")
                                Exit Sub
                            End If

                            If txtrevision.Text = "Cancelacion de una Norma existente" Then
                                MsgBox("El proyeto pasara a Normas Canceladas")
                                objNormas.Inactivo = 1
                                While FechaDeclaratoria = ""
                                    Dim InsertaFecha As New FrmInsertaFecha
                                    InsertaFecha.ShowDialog()
                                End While
                                objNormas.F_Avi_Cancelacion = FechaDeclaratoria

                                objNormas.Bandera = 2
                                objNormas.Clasificacion = UCase(txtclasificacion_proy.Text).Replace("PROY-", "")
                                'objNormas.Inactivo = 0
                                objNormas.CancelaA = UCase(txtclasificacion_proy.Text).Replace("PROY-", "")
                                objNormas.cancelaNorma()
                            Else
                                MsgBox("El proyeto pasara a Norma")
                                objNormas.Inactivo = 0
                            End If
                            clsTemas_Normas.Buscar(stema, sPlan, UCase(txtclasificacion_proy.Text).Replace("PROY-", ""))
                            If clsTemas_Normas.Encontrado = False Then
                                Referenciar("abandono")
                                With clsTemas_Normas
                                    'Inserta en P_temas Normas
                                    .RefA�o = ObjPrograma.RefA�o
                                    .RefComite = ObjPrograma.RefComite
                                    .RefConsecutivo = ObjPrograma.RefConsecutivo
                                    .RefRegreso = ObjPrograma.RefRegreso
                                    .RefTraspaso = ObjPrograma.RefTraspaso
                                    .Actualiza(stema, sPlan, UCase(txtclasificacion_proy.Text).Replace("PROY-", ""), 1)

                                    'por si ya existe no la agrego

                                    'Inserta en C_Normas
                                    ObjPrograma.Buscar(sPlan, stema)
                                    'HMC: Ajuste para registrar como pasa de proyecto a norma - 16-ENE-2015
                                    objNormas.RefA�o = ObjPrograma.RefA�o
                                    objNormas.RefComite = ObjPrograma.RefComite
                                    objNormas.RefConsecutivo = ObjPrograma.RefConsecutivo
                                    objNormas.RefRegreso = ObjPrograma.RefRegreso
                                    objNormas.RefTraspaso = ObjPrograma.RefTraspaso
                                    'Fin ajuste HMC

                                    objNormas.ID_Comite = ObjPrograma.ID_Comite
                                    objNormas.ID_CT = ObjPrograma.ID_CT
                                    objNormas.ID_SC = ObjPrograma.ID_SC
                                    objNormas.ID_Grupo = ObjPrograma.ID_Grupo
                                    objNormas.Clasificacion = UCase(txtclasificacion_proy.Text).Replace("PROY-", "")
                                    objNormas.TIE = txttitulo_Proy.Text
                                    objNormas.Bandera = 1
                                    objNormas.No_Paginas = txtpaginas_proy.Text
                                    objNormas.Resp_Publicacion = cboResponsable_proy.SelectedValue
                                    objNormas.Agregar()
                                End With
                            End If
                        End If
                        'para salir
                        EtapasInspeccion()
                        MsgBox("Los datos del tema han sido actualizados correctamente")
                        pnlproy.Enabled = False
                        Dim FrmTemas As New frmPNN_temas
                        frmtemas.MdiParent = Me.MdiParent
                        Me.Dispose()
                        FrmTemas.Show()
                End Select

            Case 4 'borrar
                If MsgBox("�Esta seguro de Borrar este Tema", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Normanet") = MsgBoxResult.Yes Then
                    Call Borra() 'desactiva la referencia en la tabla de programa de trabajo
                End If
            Case 5 'Seguimiento
                sEtapa = "Seguimiento"
                Call Habilita(sEtapa)
                IdentificaEtapa()

                Select Case lblstatus.Text
                    Case "PT"
                        Call Seguimiento_Dt()
                        'ObjEmpleados.ListaCombo(cboresponsable_procalt)
                        'cboresponsable_procalt.SelectedValue = ObjComites.Responsable
                    Case "DT" '*********************************************************************
                        'Etapa de ANteproyecto
                        Call Seguimiento_Dt()
                        'ObjEmpleados.ListaCombo(cboresponsable_procalt)
                        'cboresponsable_procalt.SelectedValue = ObjComites.Responsable
                    Case "PA"
                        'TBpt.TabPages.Item(2).Enabled = True
                        'pnlProcAlter.Enabled = True
                        'ObjEmpleados.ListaCombo(cboresponsable_procalt)
                        'cboresponsable_procalt.SelectedValue = ObjComites.Responsable
                    Case "ANT" '*************************************************************************
                        Call Seguimiento_Dt()
                        Call Seguimiento_Ant()
                        'Call Seguimiento_Proy()
                        'ObjEmpleados.ListaCombo(cboresponsable_procalt)
                        'cboresponsable_procalt.SelectedValue = ObjComites.Responsable
                    Case "PROY"
                        ObjPrograma.Band = True
                        Referenciar("abandono")
                        ObjPrograma.sReferencia = srefP
                        ObjPrograma.Buscar(sPlan, stema)
                        ObjPrograma.Band = False

                        If ObjPrograma.Tipo_Pro = 3 Then
                            Seguimiento_Proy()
                        Else
                            Call Seguimiento_Dt()
                            Call Seguimiento_Ant()
                            Call Seguimiento_Proy()
                            'ObjEmpleados.ListaCombo(cboresponsable_procalt)
                            'cboresponsable_procalt.SelectedValue = ObjComites.Responsable
                        End If

                    Case "NMX"
                        Call Seguimiento_Dt()
                        Call Seguimiento_Ant()
                        Call Seguimiento_Proy()

                End Select

                'Busca fecha declaratoria de vigencia
                'BuscaDeclaratoriaVigencia(srefP)
                '

                If lblstatus.Text = "NMX" Then
                    'Oculta(tlbBotonera.Buttons.Item(3))
                    'Bloqueo(tlbBotonera.Buttons.Item(3))
                    Inactivos(tlbBotonera.Buttons.Item(3), pnlproy)
                End If
                'TBpt.TabPages(5). = False
                TVHistorialPNN.Enabled = False
            Case 6 'REGRESAR
                LimpiaOPT()
                Inactivos(optAnt, optDT, optPT, optProy)
                pnlRegreso.Visible = True
                TbPgProgramaTrabajo.Enabled = False
                lblRef.Text = txtreferencia.Text()
                lblEtapa.Text = lblstatus.Text
                Valida()
            Case 7
                Me.Dispose()
        End Select
    End Sub

    Private Function BuscaDeclaratoriaVigencia(ByVal sRef_A�o, ByVal sRef_Comite, ByVal sRef_Consecutivo, ByVal sRef_regreso, ByVal sRef_traspaso, ByVal sClasificacion) As String
AbreConexion
        If cn.State = ConnectionState.Open Then cn.Close()

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Norma_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", 13)
        cmd.Parameters.Add("@Clasificacion", IIf(sClasificacion = "", DBNull.Value, sClasificacion))
        cmd.Parameters.Add("@RefA�o", IIf(sRef_A�o = "", DBNull.Value, sRef_A�o))
        cmd.Parameters.Add("@RefComite", IIf(sRef_Comite = "", DBNull.Value, sRef_Comite))
        cmd.Parameters.Add("@RefConsecutivo", IIf(sRef_Consecutivo = "", DBNull.Value, sRef_Consecutivo))
        cmd.Parameters.Add("@RefRegreso", IIf(sRef_regreso = "", DBNull.Value, sRef_regreso))
        cmd.Parameters.Add("@RefTraspaso", IIf(sRef_traspaso = "", DBNull.Value, sRef_traspaso))


        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Encontrado")
        'Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da = New Data.SqlClient.SqlDataAdapter(cmd)
        Try
            da.Fill(dt)
            BuscaDeclaratoriaVigencia = dt.Rows(0).Item("F_Decla_Vigencia")

        Catch ex As Exception
            Dim ms
            ms = ex.Message
        End Try
        cn.Close()

    End Function

    Private Sub AbreConexion()
        objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "COMUN", "admsis", "admynsys")
        cn.ConnectionString = objConexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "PRINCIPAL", "admsis", "admynsys")
    End Sub

    Private Function ProcesarDocumentoFinal() As String
        Dim sRutaFinal As String
        Dim Comite, Ct, Sc, Gt As String
        Dim NombreArchivo As String
        Dim Extencion As String
        Dim ArchivoArr() As String

        REM verifiar si el archico es nuevo por medio de la ruta
        If NombreArchivoPorRuta(txtProyectoFinal.Text) <> "" Then
            REM adjuntamos el nuevo archivo

            OptenerComites(txtcomite.Text, Comite, Ct, Sc, Gt, False)

            Try
                Dim nodos() As String
                Dim sRutaDoctos = Configuration.ConfigurationSettings.AppSettings("DocumentosProceso").ToString
                Dim Ruta = Comite & "\" _
                        & IIf(Ct = "NA", "", Ct & "\") _
                        & IIf(Sc = "NA", "", Sc & "\") _
                        & IIf(Gt = "NA", "", Gt & "\")

                If Not Directory.Exists(sRutaDoctos & Ruta) Then Directory.CreateDirectory(sRutaDoctos & Ruta)
                nodos = Split(TVPNN.SelectedNode.FullPath, "\")
                NombreArchivo = "ProyF_" & nodos(1).Replace(" ", "_") & "_" & txtnumerotema.Text

                ArchivoArr = Split(txtProyectoFinal.Text, ".")
                NombreArchivo &= "." & ArchivoArr(ArchivoArr.Length - 1)

                If File.Exists(sRutaDoctos & Ruta & NombreArchivo) Then File.Delete(sRutaDoctos & Ruta & NombreArchivo)
                File.Copy(txtProyectoFinal.Text, sRutaDoctos & Ruta & NombreArchivo)

            Catch ex As Exception
                MsgBox(ex.Message)
                NombreArchivo = ""
            End Try
        End If

        Return NombreArchivo
    End Function

    Private Sub OptenerComites(ByVal Pertence As String, ByRef Comite As String, ByRef Ct As String, ByRef Sc As String, ByRef Gt As String, ByVal porSesion As Boolean)
        Dim dt As DataTable
        Dim objSesion As New clsSesiones.Maple.clsSesion
        Try
            objSesion.Bandera = "s22"
            objSesion.Id_Comite = Pertence
            dt = objSesion.Listar()

            Comite = IIf(IsDBNull(dt.Rows(0).Item("ID_Comite")), "", dt.Rows(0).Item("ID_Comite"))
            Ct = IIf(IsDBNull(dt.Rows(0).Item("ID_CT")), "", dt.Rows(0).Item("ID_CT"))
            Sc = IIf(IsDBNull(dt.Rows(0).Item("Id_SC")), "", dt.Rows(0).Item("Id_SC"))
            Gt = IIf(IsDBNull(dt.Rows(0).Item("ID_Grupo")), "", dt.Rows(0).Item("ID_Grupo"))
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesion = Nothing
            dt = Nothing
        End Try
    End Sub

    Private Function NombreArchivoPorRuta(ByVal sArchivoRuta) As String
        Dim iIndice As Integer
        Dim sNombreArTem As String = ""
        Dim sExt As String

        'nombre archivo
        For iIndice = Len(sArchivoRuta) To 1 Step -1
            If Mid(sArchivoRuta, iIndice, 1) = "\" Then
                sNombreArTem = Mid(sArchivoRuta, iIndice + 1)
                iIndice = 1
            End If
        Next iIndice

        Return sNombreArTem
    End Function

    Private Sub Preguntas(ByVal id_etapa As Integer, ByVal etapa As String, Optional ByVal bandProy As Boolean = False)
        BandPreguntas = False
        If MsgBox("�Deseas cancelar el proyecto?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Normanet") = MsgBoxResult.Yes Then
            Dim Fabandono As New FrmAbandono
            Fabandono.ShowDialog()
            'actualizar todos los comentarios tecnicos con esa referencia
            ObjComentarios.Id_Etapa = id_etapa
            ObjComentarios.Bandera = 6
            Referenciar("abandono")
            ObjComentarios.JustiAbandono = respuesta
            ObjComentarios.sReferencia = srefP
            ObjComentarios.Actualizar()
            'Abandonar()
            abandono()
            MsgBox("El tema fue abandonado")
            BandPreguntas = True
            Dim FrmTemas As New frmPNN_temas
            frmtemas.MdiParent = Me.MdiParent
            Me.Dispose()
            FrmTemas.Show()
            band = True
        Else
            If bandProy = False Then
                If MsgBox("�Deseas abrir otro periodo de comentarios?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Normanet") = MsgBoxResult.Yes Then
                    NuevoPeriodo(id_etapa, etapa)
                    MsgBox("Se abrio otro periodo de comentarios")
                    BandPreguntas = True
                    Dim FrmTemas As New frmPNN_temas
                    frmtemas.MdiParent = Me.MdiParent
                    Me.Dispose()
                    FrmTemas.Show()
                    band = True
                End If
            End If
        End If
    End Sub
    Private Sub LimpiaOPT(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Checked = False
        Next objeto
    End Sub
    Private Sub Valida()
        Select Case lblEtapa.Text
            Case "NMX"
                pnlRegreso.Visible = False
                MsgBox("No se puede regresar de etapa ya que se encuentra en NORMA")
                TbPgProgramaTrabajo.Enabled = True
            Case "PROY"
                optProy.Enabled = True
                optAnt.Enabled = True
                optDT.Enabled = True
                optPT.Enabled = True
            Case "ANT"
                optProy.Enabled = False
                optAnt.Enabled = True
                optDT.Enabled = True
                optPT.Enabled = True
            Case "DT"
                optProy.Enabled = False
                optAnt.Enabled = False
                optDT.Enabled = True
                optPT.Enabled = True
            Case "PT"
                optProy.Enabled = False
                pnlRegreso.Visible = False
                MsgBox("No se puede regresar de etapa ya que se encuentra en PT")
                TbPgProgramaTrabajo.Enabled = True
        End Select
    End Sub

    Public Sub insertaDoctos(ByVal NombreDocumento As String, ByVal id_TipoDoc As String)
        'zok1 
        Dim sref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1
        With clsDoctosTemas
            .Buscar(stema, sPlan, id_TipoDoc, sref)
            .sReferencia = sref
            If .Encontrado = True Then
                'si lo encuentra lo actualiza
                .Actualiza(stema, sPlan, id_TipoDoc, NombreDocumento, 2)
            Else
                'si no lo encuentra lo inserta
                .RefA�o = ObjPrograma.RefA�o
                .RefComite = ObjPrograma.RefComite
                .RefConsecutivo = ObjPrograma.RefConsecutivo
                .RefRegreso = ObjPrograma.RefRegreso
                .RefTraspaso = ObjPrograma.RefTraspaso
                .Actualiza(stema, sPlan, id_TipoDoc, NombreDocumento, 1)
            End If
        End With
    End Sub

    Private Sub InsertaProy(ByVal incRegreso As Integer, ByVal incTraspaso As Integer)
        Referenciar("abandono")
        ObjProy.Buscar(stema, sPlan, srefP)
        If ObjProy.Encontrado = True Then
            With ObjProy
                .bandera2 = 3
                .RefRegreso = .RefRegreso + incRegreso
                .RefTraspaso = .RefTraspaso + incTraspaso
                Referenciar("abandono")
                .Insertar(srefP)
            End With
            ModificaProy(4)
        End If
    End Sub
    Private Sub ModificaProy(ByVal ibandera As Integer)
        With ObjProy
            .Tipo = "abandono"
            Referenciar("abandono")
            .Buscar(stema, sPlan, srefP)
            'If .RefRegreso > 0 Then
            'Referenciar("abandono")
            .ActualizaRefAnterior(srefP, ibandera)
            'End If
        End With
    End Sub
    Private Sub InsertaPant(ByVal incRegreso As Integer, ByVal incTraspaso As Integer)
        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        Dim sref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1

        ObjAnt.Buscar(stema, sPlan, sref)
        If ObjAnt.Encontrado = True Then
            With ObjAnt
                .Bandera2 = 3
                .RefRegreso = .RefRegreso + incRegreso
                .RefTraspaso = .RefTraspaso + incTraspaso
                .Insertar()
            End With
            ModificaANT(4)
        End If
    End Sub
    Private Sub ModificaANT(ByVal bande As Integer)
        Referenciar("abandono")
        With ObjAnt
            .Tipo = "abandono"
            .Buscar(stema, sPlan, srefP)
            'If .RefRegreso > 0 Then
            .sReferencia = srefP
            .ActualizaRefAnterior(bande)
            'End If
        End With
    End Sub
    Private Sub InsertaPDT(ByVal incRegreso As Integer, ByVal incTraspaso As Integer)
        Referenciar("abandono")
        ObjDt.Buscar(stema, sPlan, srefP)
        If ObjDt.Encontrado = True Then
            With ObjDt
                .bandera2 = 3
                .RefRegreso = .RefRegreso + incRegreso
                .RefTraspaso = .RefTraspaso + incTraspaso
                .Insertar()
                'ObjPrograma.Buscar(sPlan, stema)
                'ObjPrograma.Tipo_Pro = 1
                'ObjPrograma.InsertaTodo()
            End With
            ModificaPDT(4)
        End If
    End Sub
    Private Sub ModificaPDT(ByVal bande As Integer)
        Referenciar("abandono")
        With ObjDt
            .Tipo = "abandono"
            .Buscar(stema, sPlan, srefP)
            'If .RefRegreso > 0 Then
            .sReferencia = srefP
            .ActualizaRefAnterior(bande)
            'End If
        End With
    End Sub
    Private Sub InsertaPrograma(ByVal tipo As String, ByVal incRegreso As Integer, ByVal etapa As Integer, ByVal incTraspaso As Integer, ByVal tipo_pro As Integer, Optional ByVal etapaAbandono As Integer = 0)
        ObjPrograma.Tipo = tipo
        ObjPrograma.Buscar(sPlan, stema)
        If ObjPrograma.Existe = True Then
            With ObjPrograma
                .ID_etapa = etapa
                .Insertar(.RefA�o, .RefComite, .RefConsecutivo, (.RefRegreso + incRegreso), (.RefTraspaso + incTraspaso), .Id_Plan, .Id_Tema, .Clasificacion, tipo_pro, .Tipo_Tema, .Titulo, .Obj, .Justificacion, .F_Inicio, .F_Fin, .Revision, .ID_Comite, .ID_CT, .ID_SC, .ID_Grupo, 1, .Responsable, .Basada_Norma, .Norma, .Armonizada, .Justificacion, "")
            End With
            modificarprog(etapaAbandono)
        End If
    End Sub
    Private Sub InsertaPAvanceTemas(ByVal incRegreso As Integer, ByVal incTraspaso As Integer, ByVal etapa As String)
        Referenciar("abandono")
        ObjFechasavance.Buscar(stema, sPlan, srefP)
        If ObjFechasavance.Encontrado = True Then
            ObjFechasavance.BANDERA = 4
            ObjFechasavance.RefRegreso = ObjFechasavance.RefRegreso + incRegreso
            ObjFechasavance.RefTraspaso = ObjFechasavance.RefTraspaso + incTraspaso
            ObjFechasavance.Insertar(etapa)
            ModificaAvancesTemas(5)
        End If
    End Sub
    Private Sub ModificaAvancesTemas(ByVal bande As Integer)

        Referenciar("abandono")
        With ObjFechasavance
            .Tipo = "abandono"
            .Buscar(stema, sPlan, srefP)
            'If .RefRegreso > 0 Then
            .sReferencia = srefP
            .ActualizaRefAnterior(bande)
            'End If
        End With
    End Sub
    Private Sub modificarprog(Optional ByVal etapaAbandono As Integer = 0)
        Referenciar("abandono")
        With ObjPrograma
            .Tipo = "abandono"
            .Buscar(sPlan, stema)
            'If .RefRegreso > 0 Then
            .sReferencia = srefP
            .ActualizaRefAnterior(etapaAbandono)
            'End If
        End With
    End Sub

    Private Sub NuevoPeriodo(ByVal id_etapa As Integer, ByVal Etapa As String)
        Referenciar("abandono")
        InsertaPeriodoCom()
        InsertaPDT(1, 0)
        InsertaPant(1, 0)
        InsertaProy(1, 0)
        ProcAlternativo(1, 0)
        InsertaPAvanceTemas(1, 0, "DT")
        InsertaPrograma("abandono", 1, id_etapa, 0, ObjPrograma.Tipo_Pro)
        clsDoctosTemas.Borrar(sPlan, stema, srefP)
    End Sub
    Private Sub ProcAlternativo(ByVal inc As Integer, ByVal inc2 As Integer)
        Referenciar("abandono")
        ProcAlter.Buscar(sPlan, stema, srefP)
        ObjNuevoPeriodo.sReferencia = srefP
        ObjNuevoPeriodo.Buscar(stema, sPlan)
        If ProcAlter.Encontrado = True Then
            With ProcAlter
                .RefRegreso = .RefRegreso + inc
                .RefTraspaso = .RefTraspaso + inc2
                .Bandera = 3
                If ObjNuevoPeriodo.Encontrado Then
                    .F_Inicio_Comentarios = Nothing
                    .F_Fin_Comentarios = Nothing
                End If
                .Insertar()
            End With
            ActualizaProcAlternativo(5)
        End If
    End Sub
    Private Sub ActualizaProcAlternativo(ByVal bande As Integer)
        Referenciar("abandono")
        With ProcAlter
            .Tipo = "abandono"
            .Buscar(sPlan, stema, srefP)
            'If .RefRegreso > 0 Then
            .Bandera = bande
            .sReferencia = srefP
            .ActualizaProgAnterior()
            'End If
        End With
    End Sub
    Private Sub InsertaPeriodoCom()
        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        Dim sRef As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1
        ObjNuevoPeriodo.sReferencia = sRef
        ObjNuevoPeriodo.Buscar(stema, sPlan)
        ProcAlter.Buscar(sPlan, stema, sRef) 'es necesario guardar primero el proc alternativo
        If ProcAlter.Encontrado = True Then
            With ObjNuevoPeriodo

                .Bandera = 1
                .Id_Plan = sPlan
                .Id_Tema = stema
                .Consecutivo = .Consecutivo + 1
                .F_Inicial = ProcAlter.F_Inicio_Comentarios
                .F_Final = ProcAlter.F_Fin_Comentarios
                .Status = True

                .RefA�o = ObjPrograma.RefA�o
                .RefComite = ObjPrograma.RefComite
                .RefConsecutivo = ObjPrograma.RefConsecutivo
                .RefRegreso = ObjPrograma.RefRegreso
                .RefTraspaso = ObjPrograma.RefTraspaso
                .Insertar()

                If .Consecutivo > 0 Then
                    ActualizaPeriodoComentarios()
                End If
            End With
        End If
    End Sub
    Private Sub ActualizaPeriodoComentarios()
        ObjNuevoPeriodo.Bandera = 2
        ObjNuevoPeriodo.Status = False
        ObjNuevoPeriodo.Actualizar()
    End Sub
    Private Sub Seguimiento_Dt()
        sEtapa = "DT"
        Call Habilita(sEtapa)
        TBpt.TabPages.Item(1).Enabled = True
        TBpt.SelectedTab = TBpt.TabPages.Item(1)
        pnlDt.Enabled = True
        'Aqui se busca la primer sesi�n cerrada relacionada con ese tema del Plan
        clsBusca_F_Sesion.Bandera = 8
        clsBusca_F_Sesion.Id_tema = stema
        clsBusca_F_Sesion.Id_Plan = sPlan

        Referenciar("abandono")
        ObjFechasavance.Buscar(stema, sPlan, srefP)
        If ObjFechasavance.F_Inic_Desarrollo_Nmx = "" Then
            clsBusca_F_Sesion.Trae_Fecha()
            ObjFechasavance.sReferencia = srefP
            ObjFechasavance.BANDERA = 7
            ObjFechasavance.F_Inic_Desarrollo_Nmx = clsBusca_F_Sesion.Fecha
            ObjFechasavance.ActualizaF_DesarrolloNMX()
        End If

        txtf_des_Nmx.Text = clsBusca_F_Sesion.Fecha
        '************************************************************************
        'Busca los datos de Dt si es que ya existen
        Dim sref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

        ObjDt.Buscar(stema, sPlan, sref)
        If ObjDt.Encontrado = True Then

            txtclasificaciondt.Text = ObjDt.Clasificacion
            txttitulodt.Text = ObjDt.Titulo
            txtresponsableDt.Text = ObjDt.Responsable
            chkAlternativo.Enabled = False
            bandModifClasific = True
        Else
            ObjDirectorio.ListaCombo(cboresponsable_procalt)
            txtclasificaciondt.Text = txtClasificacionPT.Text
            txttitulodt.Text = txttituloPT.Text
            txtresponsableDt.Text = ObjPrograma.Responsable
            chkAlternativo.Enabled = True
            If chkModTec.Checked = False Then
                MsgBox("Modifica la clasificacion y el titulo acorde a la etapa")
            End If
        End If
        If txtresponsableDt.Text <> "" Then
            'Busca el nombre completo del responsable si es que ya existe en dt
            ObjEmpleados.Bandera = 3
            ObjEmpleados.Id_usuario = txtresponsableDt.Text
            ObjEmpleados.Buscar()
            If IsDBNull(ObjEmpleados.NOMBRE_COMPLETO) Then
                txtresponsableDt.Visible = False
            Else
                Call Carga_Combos_Responsable("DT")
                txtresponsableDt.Text = ObjEmpleados.NOMBRE_COMPLETO
            End If
        Else

        End If
        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1


        'Se busca las fechas de Inicio desarrollo mx o las fechas de aprobaci�n Revisi�n editorial
        ObjFechasavance.Buscar(stema, sPlan, sref)
        If ObjFechasavance.Encontrado = False Then
            ObjFechasavance.Status = 1
            ObjFechasavance.Actualiza(1, sPlan, stema, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
        End If

        If ObjFechasavance.F_Aprob_Revisi�n_Editorial = "" Then
            txtAprob_Revision_Editorial.Text = ""
        Else
            txtAprob_Revision_Editorial.Text = Format(CDate(ObjFechasavance.F_Aprob_Revisi�n_Editorial), "dd/MM/yyyy")
        End If

        If ObjFechasavance.F_Inic_Desarrollo_Nmx = "" Then
            txtf_des_Nmx.Text = ""
        Else
            txtf_des_Nmx.Text = Format(CDate(ObjFechasavance.F_Inic_Desarrollo_Nmx), "dd/MM/yyyy")
        End If

        'valida la fecha de impresi�n de acta de aprobaci�n
        If ObjFechasavance.F_Impresion_ActaAprobacion = "" Then
            CmdActaAprobacion.Enabled = True
            txtf_impActAprob.Text = ""
        Else
            'CmdActaAprobacion.Enabled = False
            txtf_impActAprob.Text = Format(CDate(ObjFechasavance.F_Impresion_ActaAprobacion), "dd/MM/yyyy")
        End If

        'Valida la fecha de carga de dt final
        If ObjFechasavance.F_Carga_DtFinal = "" Then
            txtfcargaDtFinal.Text = ""
        Else
            txtfcargaDtFinal.Text = Format(CDate(ObjFechasavance.F_Carga_DtFinal), "dd/MM/yyyy")
        End If
        'Valida la fecha de carga del acta de aprobaci�n
        If ObjFechasavance.F_Carga_ActaAprobacion = "" Then
            txtfcargaActaprobFinal.Text = ""
        Else
            txtfcargaActaprobFinal.Text = Format(CDate(ObjFechasavance.F_Carga_ActaAprobacion), "dd/MM/yyyy")
        End If

        If ObjFechasavance.F_Aprobacion_CTGT_ANT = "" Then
            txtf_aprobCtGT.Text = ""
        Else
            txtf_aprobCtGT.Text = Format(CDate(ObjFechasavance.F_Aprobacion_CTGT_ANT), "dd/MM/yyyy")
        End If
        'Esta clase busca los documentos de este tema para el tipo de Documeto 3 Documento de Trabajo Final
        'zok1 
        Dim ref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        ref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1

        clsDoctosTemas.Buscar(stema, sPlan, "3", sref)
        If clsDoctosTemas.Encontrado = True Then
            txtadjDtf.Text = clsDoctosTemas.Documento
            cmdDt.Enabled = False
        Else
            txtadjDtf.Text = ""
            cmdDt.Enabled = True
        End If

        clsDoctosTemas.Buscar(stema, sPlan, "12", sref)
        If clsDoctosTemas.Encontrado = True Then
            txtminuta.Text = clsDoctosTemas.Documento
            cmdminuta.Enabled = False
        Else
            txtminuta.Text = ""
            cmdminuta.Enabled = True
        End If

        'Esta clase busca los documentos de este tema para el tipo de Acta de Aprobaci�n final 4
        'zok1 
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        ref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

        'zok1
        clsDoctosTemas.Buscar(stema, sPlan, "4", sref)
        If clsDoctosTemas.Encontrado = True Then
            txtadjActAprobFinal.Text = clsDoctosTemas.Documento
            cmdacta.Enabled = False
        Else
            txtadjActAprobFinal.Text = ""
            cmdacta.Enabled = True
        End If
        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1
        'Si el tema es procedimiento alternativo
        If ObjPrograma.Tipo_Pro = 2 Then

            Inactivos(txtresponsable_procalt, txtf_inicresp, txtf_finresp, txtf_inic_com, txtf_fin_com, fcarga_minuta)
            pnlProcAlter.Visible = True
            clsProc.Buscar(sPlan, stema, sref)
            If clsProc.Encontrado = True Then
                'txtresponsable_procalt.Text = clsProc.Responsable
                txtf_inicresp.Text = clsProc.F_Inicio_Responsable
                txtf_finresp.Text = clsProc.F_Fin_Responsable
                txtf_inic_com.Text = clsProc.F_Inicio_Comentarios
                txtf_fin_com.Text = clsProc.F_Fin_Comentarios
                fcarga_minuta.Text = clsProc.F_Carga_Minuta_Terminacion
                Dim band As Boolean = False
                If txtresponsable_procalt.Text <> "" Then
                    'Busca el nombre completo del responsable si es que ya existe en dt
                    ObjEmpleados.Bandera = 3
                    ObjEmpleados.Id_usuario = txtresponsable_procalt.Text
                    ObjEmpleados.Buscar()
                    If IsDBNull(ObjEmpleados.NOMBRE_COMPLETO) Then
                        txtresponsableDt.Visible = False
                    Else
                        'txtresponsable_procalt.Text = ObjEmpleados.NOMBRE_COMPLETO
                        cboresponsable_procalt.SelectedValue = clsProc.Responsable
                        txtresponsable_procalt.Text = cboresponsable_procalt.Text
                        band = True
                    End If
                Else
                    Call Carga_Combos_Responsable("DT")
                End If
                If band <> True Then
                    Carga_Combos_Responsable("ALT")
                End If
                'Carga_Combos_Responsable("ALT")
                chkAlternativo.Checked = True
                chkAlternativo.Enabled = False

            Else
                txtresponsable_procalt.Text = ""
                txtf_inicresp.Text = ""
                txtf_finresp.Text = ""
                txtf_inic_com.Text = ""
                txtf_fin_com.Text = ""
                Carga_Combos_Responsable("ALT")
                chkAlternativo.Checked = True
                chkAlternativo.Enabled = False
            End If
        End If
        procedimientoAlt()
        Referenciar("abandono")
        band = False
        If ObjPrograma.ID_etapa > 2 And ObjPrograma.ID_etapa < 10 And txtAprob_Revision_Editorial.Text = "" Then
            band = True
            chkrevedit.Checked = False
        End If
        If ObjPrograma.ID_etapa > 2 And ObjPrograma.ID_etapa < 10 And optComTecSi.Checked Then
            optApDtSi.Checked = True
            GrbApDT.Enabled = False
        End If
    End Sub
    Sub Carga_Combos_Responsable(ByVal etapa As String)
        ObjEmpleados.Bandera = 6
        Select Case etapa
            Case "PT"
                ObjEmpleados.ListaCombo(cboResponsable) 'PROGRAMA DE TRABAJO
                cboResponsable.SelectedValue = ObjPrograma.Responsable
            Case "DT"
                ObjEmpleados.ListaCombo(CboResponsableDt) 'ETAPA DE DT
                CboResponsableDt.SelectedValue = ObjDt.Responsable
            Case "PROC"
                'ObjEmpleados.ListaCombo(cboresponsable_procalt) 'ETAPA DE PROCALTERNATIVO
                ObjDirectorio.ListaCombo(cboresponsable_procalt)
                cboresponsable_procalt.SelectedValue = ObjDt.Responsable
            Case "ANT"
                ObjEmpleados.ListaCombo(cboresponsable_ant) 'ETAPA ANT
                cboresponsable_ant.SelectedValue = ObjAnt.Responsable
            Case "PROY"
                ObjEmpleados.ListaCombo(cboResponsable_proy) 'ETAPA PROY
                cboResponsable_proy.SelectedValue = ObjProy.Responsable
            Case "ALT"
                dtDirectorio = ObjDirectorio.ListaCombo(cboresponsable_procalt) 'ETAPA proc alt
                ObjDirectorio.ListaCombo(cboresponsable_procalt)
                'cboresponsable_procalt.SelectedValue = clsProc.Responsable
        End Select
        'ProcAlter
        Referenciar("abandono")
        ProcAlter.Buscar(sPlan, stema, srefP)
        If ProcAlter.Responsable <> "" Then
            cboresponsable_procalt.SelectedValue = ProcAlter.Responsable
        End If
        ''If ObjComites.Responsable <> "" Then
        ''    ObjEmpleados.ListaCombo(cboresponsable_procalt)
        ''    cboresponsable_procalt.SelectedValue = ObjComites.Responsable
        ''End If
    End Sub
    Private Sub Seguimiento_Ant()
        TBpt.TabPages.Item(2).Enabled = True
        TBpt.SelectedTab = TBpt.TabPages.Item(2)
        sEtapa = "ANT"
        Call Habilita(sEtapa)
        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        Dim sref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1
        ObjAnt.Buscar(stema, sPlan, sref)
        If ObjAnt.Encontrado = False Then
            If chkModTec.Checked = False Then
                MsgBox("Modifica la clasificacion y el titulo acorde a la etapa")
            End If
            bandModifClasificAnt = True
        Else
            bandModifClasificAnt = False
        End If
        ObjDt.Buscar(stema, sPlan, sref)

        Call Carga_Combos_Responsable("ANT")
        txtnumpags_Ant.Text = ObjAnt.Num_Paginas
        If ObjAnt.Clasificacion <> "" Then txtclasificacion_ant.Text = ObjAnt.Clasificacion
        If ObjAnt.Clasificacion = "" Then txtclasificacion_ant.Text = ObjDt.Clasificacion
        If ObjAnt.Titulo <> "" Then txttituloant.Text = ObjAnt.Titulo
        If ObjAnt.Titulo = "" Then txttituloant.Text = txttitulodt.Text
        If ObjAnt.Responsable <> "" Then
            ObjEmpleados.Bandera = 3
            ObjEmpleados.Id_usuario = ObjAnt.Responsable
            ObjEmpleados.Buscar()
            txtresponsable_ant.Text = ObjEmpleados.NOMBRE_COMPLETO
            cboresponsable_ant.SelectedValue = ObjAnt.Responsable
        Else
            txtresponsable_ant.Text = txtresponsableDt.Text
            'cboresponsable_ant.Text = txtresponsableDt.Text
            cboresponsable_ant.SelectedValue = ObjDt.Responsable
        End If


        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1

        ObjFechasavance.Buscar(stema, sPlan, sref)
        If ObjFechasavance.BANDERA = True Then
            txtcarg_antfinal.Text = ObjFechasavance.F_CARGA_ANTF
            TextBox2.Text = ObjFechasavance.F_Carga_minuta_Apro
        Else
            txtcarg_antfinal.Text = ""
        End If

        'mostramos los documentos 
        clsDoctosTemas.Buscar(stema, sPlan, "4", sref)
        If clsDoctosTemas.Documento <> "" Then
            txtadjActAprobFinal.Text = clsDoctosTemas.Documento
            cmdacta.Enabled = False
        Else
            txtadjActAprobFinal.Text = ""
            cmdacta.Enabled = True
        End If

        clsDoctosTemas.Buscar(stema, sPlan, "15", sref)
        If clsDoctosTemas.Documento <> "" Then
            TextBox3.Text = clsDoctosTemas.Documento
            Button1.Enabled = False
        Else
            TextBox3.Text = ""
            Button1.Enabled = True
        End If

        clsDoctosTemas.Buscar(stema, sPlan, "7", sref)
        If clsDoctosTemas.Documento <> "" Then
            txtadjantF.Text = clsDoctosTemas.Documento
            cmdant.Enabled = False
        Else
            txtadjantF.Text = ""
            cmdant.Enabled = True
        End If

        'zok1 
        Dim ref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        ref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

        'zok1
        'Busca el documento ant final
        clsDoctosTemas.Buscar(stema, sPlan, "7", sref)
        If clsDoctosTemas.Encontrado = True Then
            txtadjantF.Text = clsDoctosTemas.Documento
        Else
            txtadjantF.Text = ""
        End If

        ObjAnt.Buscar(stema, sPlan, sref)
        If ObjAnt.Correcciones = True Then
            optCorrSi.Checked = True
            txtF_Correcciones.Text = ObjAnt.F_Correcciones
        Else
            optCorrNo.Checked = True
        End If

    End Sub
    Private Sub Seguimiento_Proy()
        TBpt.TabPages.Item(3).Enabled = True
        If lblstatus.Text = "NMX" Then
            TBpt.SelectedTab = TBpt.TabPages.Item(0)
        Else
            TBpt.SelectedTab = TBpt.TabPages.Item(3)
        End If
        sEtapa = "PROY"
        Call Habilita(sEtapa)
        Referenciar("abandono")
        ObjProy.Buscar(stema, sPlan, srefP)
        If ObjProy.Encontrado = False Then
            MsgBox("Modifica la clasificacion y el titulo acorde a la etapa")
            bandModifClasificProy = True
        End If


        ObjPrograma.Band = True
        Referenciar("abandono")
        ObjPrograma.sReferencia = srefP
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.Band = False

        If ObjPrograma.Tipo_Pro = 3 And ObjProy.Clasificacion = "" Then
            txtclasificacion_proy.Text = txtClasificacionPT.Text + "-" + CStr(Now.Year)
        Else
            If ObjProy.Clasificacion = "" Then
                txtclasificacion_proy.Text = txtclasificacion_ant.Text + "-" + CStr(Now.Year)
            Else
                txtclasificacion_proy.Text = ObjProy.Clasificacion
                bandModifClasificProy = False
            End If
        End If
        txtpaginas_proy.Text = ObjProy.Num_Paginas
        txtPaginasNorma.Text = ObjProy.sPaginasNorma
        If ObjPrograma.Tipo_Pro = 3 And ObjProy.Clasificacion = "" Then
            txttitulo_Proy.Text = txttituloPT.Text
        Else
            If ObjProy.Titulo = "" Then
                txttitulo_Proy.Text = txttituloant.Text
            Else
                txttitulo_Proy.Text = ObjProy.Titulo
            End If
        End If
        ObjEmpleados.Bandera = 3
        ObjEmpleados.Id_usuario = ObjProy.Responsable
        ObjEmpleados.Buscar()
        txtresponsable_proy.Text = ObjEmpleados.NOMBRE_COMPLETO
        Call Carga_Combos_Responsable("PROY")

        'zok1
        'busco los datos para la referencia y solo busco en el store esto
        Dim sRef As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        'zok1

        ObjFechasavance.Buscar(stema, sPlan, sRef)
        If ObjFechasavance.BANDERA = True Then
            txtf_imp_actaprob_proy.Text = ObjFechasavance.F_Impresion_ActaAprobacion_PROYF
            Call Llena_Avance_Proy()
        Else
            txtf_imp_actaprob_proy.Text = ""
        End If
        'zok1 
        Dim ref As String
        ObjPrograma.Band = False
        ObjPrograma.Buscar(sPlan, stema)
        ObjPrograma.Band = True
        'ya que saque los datos busco con la referencia para que me de el verdadero registro
        ref = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso

        'zok1
        'Busca los datos de la pantalla de Proyecto
        clsDoctosTemas.Buscar(stema, sPlan, "8", sRef)
        If clsDoctosTemas.Encontrado = True Then
            txtadjProyfinal.Text = clsDoctosTemas.Documento
        Else
            txtadjProyfinal.Text = ""
        End If

        REM busco el proyecto final despues de comentarios
        clsDoctosTemas.Buscar(stema, sPlan, "22", sRef)
        If clsDoctosTemas.Encontrado = True Then
            txtProyectoFinal.Text = clsDoctosTemas.Documento
            cmdProyectoFinal.Enabled = False
        Else
            txtProyectoFinal.Text = ""
            cmdProyectoFinal.Enabled = True
        End If

        clsDoctosTemas.Buscar(stema, sPlan, "6", sRef)
        If clsDoctosTemas.Encontrado = True Then
            txtadjactPROYF.Text = clsDoctosTemas.Documento
        Else
            txtadjactPROYF.Text = ""
        End If
        If ObjProy.Responsable = "" Then
            txtresponsable_proy.Text = txtresponsable.Text
            cboResponsable_proy.Text = txtresponsable.Text
            'Else
            '    txtresponsable_proy.Text = ObjProy.Responsable
        End If

        BuscaComentarios("TEC", optComTecSiProy, txtnumcomTecProy, 4)
        BuscaComentarios("ED", optComEdSiProy, txtnumcomedProy, 4)
        bandCom = False

        If optComTecSiProy.Checked = False Then
            txtnumcomTecProy.Visible = False
        Else
            txtnumcomTecProy.Visible = True
            bandCom = True
        End If

        If optComEdSiProy.Checked = False Then
            txtnumcomedProy.Visible = False
        Else
            txtnumcomedProy.Visible = True
            bandCom = True
        End If

        If bandCom = True Then
            DTf_ap_res2.Visible = True
            txtf_ap2.Visible = True
            dtresolucion.Enabled = True
            dtF_limrescompub.Enabled = True
            dtvobo.Visible = True
            txtvobo.Visible = True
            'dtf_aprobrescompub.Visible = True
            'txtf_aprobrescompub.Visible = True
        Else
            DTf_ap_res2.Visible = False
            txtf_ap2.Visible = False

            dtF_limrescompub.Enabled = False
            dtresolucion.Enabled = False
            dtvobo.Visible = False
            txtvobo.Visible = False
            'dtf_aprobrescompub.Visible = False
            'txtf_aprobrescompub.Visible = False
        End If
    End Sub
    Sub Llena_Avance_Proy()
        DTf_aprobComproy.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_Comite_PROY) = True, "", ObjFechasavance.F_Aprobacion_Comite_PROY)
        txtf_aprob_com.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_Comite_PROY) = True, "", ObjFechasavance.F_Aprobacion_Comite_PROY)

        dtF_inicio.Text = IIf(IsDBNull(ObjFechasavance.F_Publicacion_ComentarioPublico) = True, "", ObjFechasavance.F_Publicacion_ComentarioPublico)
        txtf_ini_compub.Text = IIf(IsDBNull(ObjFechasavance.F_Publicacion_ComentarioPublico) = True, "", ObjFechasavance.F_Publicacion_ComentarioPublico)

        dtF_Fin.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_ComentarioPublico)
        txtf_limitecompub.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_ComentarioPublico)

        dtresolucion.Text = IIf(IsDBNull(ObjFechasavance.F_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Resolucion_ComentarioPublico)
        txtfResolucion.Text = IIf(IsDBNull(ObjFechasavance.F_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Resolucion_ComentarioPublico)

        dtF_limrescompub.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico)
        TXTF_limrescompub.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico)

        dtf_aprobrescompub.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico)
        txtf_ap2.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico)

        dtvobo.Text = IIf(IsDBNull(ObjFechasavance.F_VoBo_CONANCE) = True, "", ObjFechasavance.F_VoBo_CONANCE)
        txtvobo.Text = IIf(IsDBNull(ObjFechasavance.F_VoBo_CONANCE) = True, "", ObjFechasavance.F_VoBo_CONANCE)

        dtfiniRev.Text = IIf(IsDBNull(ObjFechasavance.F_Inicio_Revision_PROYF) = True, "", ObjFechasavance.F_Inicio_Revision_PROYF)
        txtfiniRev.Text = IIf(IsDBNull(ObjFechasavance.F_Inicio_Revision_PROYF) = True, "", ObjFechasavance.F_Inicio_Revision_PROYF)

        dtftermrev.Text = IIf(IsDBNull(ObjFechasavance.F_Termino_Revision_PROYF) = True, "", ObjFechasavance.F_Termino_Revision_PROYF)
        txtftermrev.Text = IIf(IsDBNull(ObjFechasavance.F_Termino_Revision_PROYF) = True, "", ObjFechasavance.F_Termino_Revision_PROYF)


        dpFverif_rev.Text = IIf(IsDBNull(ObjFechasavance.F_VerifRev_PROYF) = True, "", ObjFechasavance.F_VerifRev_PROYF)
        txtfverifrefProy.Text = IIf(IsDBNull(ObjFechasavance.F_VerifRev_PROYF) = True, "", ObjFechasavance.F_VerifRev_PROYF)

        dtf_edic.Text = IIf(IsDBNull(ObjFechasavance.F_Edicion_PROYF) = True, "", ObjFechasavance.F_Edicion_PROYF)
        txtf_edic.Text = IIf(IsDBNull(ObjFechasavance.F_Edicion_PROYF) = True, "", ObjFechasavance.F_Edicion_PROYF)

        txtf_imp_actaprob_proy.Text = IIf(IsDBNull(ObjFechasavance.F_Impresion_ActaAprobacion_PROYF) = True, "", ObjFechasavance.F_Impresion_ActaAprobacion_PROYF)
        txtfcarga_actaprobPROYF.Text = IIf(IsDBNull(ObjFechasavance.F_Carga_ActaAprobacion_PROYF) = True, "", ObjFechasavance.F_Carga_ActaAprobacion_PROYF)

        dtacusePROYF.Text = IIf(IsDBNull(ObjFechasavance.F_ACUSE_DGN_PROYF) = True, "", ObjFechasavance.F_ACUSE_DGN_PROYF)
        txtacusePROYF.Text = IIf(IsDBNull(ObjFechasavance.F_ACUSE_DGN_PROYF) = True, "", ObjFechasavance.F_ACUSE_DGN_PROYF)

        txtfCargaProyf.Text = IIf(IsDBNull(ObjFechasavance.F_CARGA_PROYF) = True, "", ObjFechasavance.F_CARGA_PROYF)
        txtf_aprobrescompub.Text = IIf(IsDBNull(ObjFechasavance.F_Amp_Resolucion) = True, Nothing, ObjFechasavance.F_Amp_Resolucion)
    End Sub

    Private Sub Llena_Avance()
        txtF_nmx.Text = IIf(IsDBNull(ObjFechasavance.F_Inic_Desarrollo_Nmx) = True, "", ObjFechasavance.F_Inic_Desarrollo_Nmx)
        txtaprbRev_Edit.Text = IIf(IsDBNull(ObjFechasavance.F_Aprob_Revisi�n_Editorial) = True, "", ObjFechasavance.F_Aprob_Revisi�n_Editorial)
        txtf_Dtfinal.Text = IIf(IsDBNull(ObjFechasavance.F_Carga_DtFinal) = True, "", ObjFechasavance.F_Carga_DtFinal)
        txtf_Impr_ActaAprob.Text = IIf(IsDBNull(ObjFechasavance.F_Impresion_ActaAprobacion) = True, "", ObjFechasavance.F_Impresion_ActaAprobacion)
        txtf_Carga_ActaAprob.Text = IIf(IsDBNull(ObjFechasavance.F_Carga_ActaAprobacion) = True, "", ObjFechasavance.F_Carga_ActaAprobacion)
        txtf_Aprob_CTGT_Ant.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_CTGT_ANT) = True, "", ObjFechasavance.F_Aprobacion_CTGT_ANT)
        txtf_Aprob_Comite_Proy.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_Comite_PROY) = True, "", ObjFechasavance.F_Aprobacion_Comite_PROY)
        txtf_pub_compub.Text = IIf(IsDBNull(ObjFechasavance.F_Publicacion_ComentarioPublico) = True, "", ObjFechasavance.F_Publicacion_ComentarioPublico)
        txtf_lim_compub.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_ComentarioPublico)
        txtf_res_compub.Text = IIf(IsDBNull(ObjFechasavance.F_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Resolucion_ComentarioPublico)
        txtf_lim_res_compub.Text = IIf(IsDBNull(ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Limite_Aprobacion_Resolucion_ComentarioPublico)
        txtf_aprob_res_compub.Text = IIf(IsDBNull(ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico) = True, "", ObjFechasavance.F_Aprobacion_Resolucion_ComentarioPublico)
        txtf_VoBo_Comite.Text = IIf(IsDBNull(ObjFechasavance.F_VoBo_CONANCE) = True, "", ObjFechasavance.F_VoBo_CONANCE)
        txtf_inic_rev_proyf.Text = IIf(IsDBNull(ObjFechasavance.F_Inicio_Revision_PROYF) = True, "", ObjFechasavance.F_Inicio_Revision_PROYF)
        txtf_fin_rev_proyf.Text = IIf(IsDBNull(ObjFechasavance.F_Termino_Revision_PROYF) = True, "", ObjFechasavance.F_Termino_Revision_PROYF)
        txtf_edi_proyf.Text = IIf(IsDBNull(ObjFechasavance.F_Edicion_PROYF) = True, "", ObjFechasavance.F_Edicion_PROYF)
        txtf_impr_Acta_proyf.Text = IIf(IsDBNull(ObjFechasavance.F_Impresion_ActaAprobacion_PROYF) = True, "", ObjFechasavance.F_Impresion_ActaAprobacion_PROYF)
        txtf_carga_acta_proyf.Text = IIf(IsDBNull(ObjFechasavance.F_Carga_ActaAprobacion_PROYF) = True, "", ObjFechasavance.F_Carga_ActaAprobacion_PROYF)
        txtf_acuseDGN.Text = IIf(IsDBNull(ObjFechasavance.F_ACUSE_DGN_PROYF) = True, "", ObjFechasavance.F_ACUSE_DGN_PROYF)
        txtf_carga_Proyf.Text = IIf(IsDBNull(ObjFechasavance.F_CARGA_PROYF) = True, "", ObjFechasavance.F_CARGA_PROYF)
        txtf_cargaAntf.Text = IIf(IsDBNull(ObjFechasavance.F_CARGA_ANTF) = True, "", ObjFechasavance.F_CARGA_ANTF)
    End Sub

#Region " TVcomites - LLena_treeview, Metodos y Procesos"

    Private Sub llena_TreeView()

        Cursor.Current = Cursors.WaitCursor
        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = TVcomites.Nodes.Add("Seleccione un Comit�")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        TVcomites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = TVcomites.Nodes.Add("Seleccione un Comit�")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = TVcomites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        TVcomites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        'tvComites.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TVcomites.ResetText()

        Cursor.Current = Cursors.Default

    End Sub

#End Region

#Region " TextBox, Metodos y Procesos"

#Region " TextBox - txttituloPT, Metodos y Procesos"

    Private Sub txttituloPT_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txttituloPT.Validating
        If sEtapa = "Agregar" Then
            If txttituloPT.Text = "" Then
                MsgBox("El campo de T�tulo del tema es requerido")
                txttituloPT.Focus()
            End If
        End If
    End Sub

#End Region

#Region " TextBox - txtobjetivo, Metodos y Procesos"

    Private Sub txtobjetivo_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtobjetivo.Validating
        If sEtapa = "Agregar" Then
            If txtobjetivo.Text = "" Then
                MsgBox("El campo de Objetivo del tema es requerido")
                txtobjetivo.Focus()
            End If
        End If
    End Sub

#End Region

#Region " TextBox - txtjustificacion, Metodos y Procesos"

    Private Sub txtjustificacion_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtjustificacion.Validating
        If sEtapa = "Agregar" Then
            If txtjustificacion.Text = "" Then
                MsgBox("El campo de Justificaci�n del tema es requerido")
                txtjustificacion.Focus()
            End If
        End If
    End Sub

#End Region

#Region " TextBox - txtrevision, Metodos y Procesos"

    Private Sub txtrevision_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtrevision.Validating
        If sEtapa = "Agregar" Then
            If txtrevision.Text = "" Then
                MsgBox("El campo de Revisi�n del tema es requerido")
                txtrevision.Focus()
            End If
        End If
    End Sub

#End Region

#End Region

    Private Sub chkAlternativo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If chkAlternativo.Checked = True Then
            chkNormal.Checked = False
            chkModTec.Checked = False
        End If
    End Sub
    Private Sub chkModTec_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If chkModTec.Checked = True Then
            chkAlternativo.Checked = False
            chkNormal.Checked = False
        End If
    End Sub
    Private Sub frmPNN_temas_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated

        'MessageBox.Show("Aqui tampoco")
        If Activo_Temas <> 0 Then
            sEtapa = "Inactivo"
            Call Habilita(sEtapa)

            TVcomites.Nodes.Clear()
            TVPNN.Nodes.Clear()
            TVPNN.Refresh()
            Call Llena_Plan(TVHistorialPNN)
            Activo_Temas = 0

        End If
        'sEtapa = "Inactivo"
        'Call Habilita(sEtapa)
    End Sub
    Private Sub pnlComentarios_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub chkBasada_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBasada.CheckedChanged
        If chkBasada.Checked = True Then
            Txtbasada.Visible = True
            txtarmonizacion.Visible = False
            chkarmonizada.Visible = False
            txtjustarm.Visible = False
            Label95.Visible = False
            chkarmonizada.Checked = False
        Else
            Txtbasada.Visible = False
            txtarmonizacion.Visible = False
            chkarmonizada.Visible = True
            txtjustarm.Visible = False
            Label95.Visible = False
        End If
    End Sub


    Private Sub TBpt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TBpt.SelectedIndexChanged
        If TBpt.SelectedTab Is TBpt.TabPages(4) Then
            'zok1
            'busco los datos para la referencia y solo busco en el store esto
            Dim sRef As String
            ObjPrograma.Band = False
            ObjPrograma.Buscar(sPlan, stema)
            sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
            'zok1

            'para Mostrar todas las fechas en el historial de avance en fechas
            ObjFechasavance.Buscar(stema, sPlan, sRef)
            If ObjFechasavance.BANDERA = True Then
                Call Inactivos(txtF_nmx, txtaprbRev_Edit, txtf_Dtfinal, txtf_Impr_ActaAprob, txtf_Carga_ActaAprob, txtf_Aprob_CTGT_Ant, txtf_Aprob_Comite_Proy, txtf_pub_compub, txtf_lim_compub, txtf_res_compub)
                Call Inactivos(txtf_lim_res_compub, txtf_aprob_res_compub, txtf_VoBo_Comite, txtf_inic_rev_proyf, txtf_fin_rev_proyf, txtf_edi_proyf, txtf_impr_Acta_proyf, txtf_carga_acta_proyf, txtf_acuseDGN, txtf_carga_Proyf, txtf_cargaAntf)
                Call Llena_Avance()
            Else
                Call Inactivos(txtF_nmx, txtaprbRev_Edit, txtf_Dtfinal, txtf_Impr_ActaAprob, txtf_Carga_ActaAprob, txtf_Aprob_CTGT_Ant, txtf_Aprob_Comite_Proy, txtf_pub_compub, txtf_lim_compub, txtf_res_compub)
                Call Inactivos(txtf_lim_res_compub, txtf_aprob_res_compub, txtf_VoBo_Comite, txtf_inic_rev_proyf, txtf_fin_rev_proyf, txtf_edi_proyf, txtf_impr_Acta_proyf, txtf_carga_acta_proyf, txtf_acuseDGN, txtf_carga_Proyf, txtf_cargaAntf)
                Call Limpia_Campos(txtF_nmx, txtaprbRev_Edit, txtf_Dtfinal, txtf_Impr_ActaAprob, txtf_Carga_ActaAprob, txtf_Aprob_CTGT_Ant, txtf_Aprob_Comite_Proy, txtf_pub_compub, txtf_lim_compub, txtf_res_compub)
                Call Limpia_Campos(txtf_lim_res_compub, txtf_aprob_res_compub, txtf_VoBo_Comite, txtf_inic_rev_proyf, txtf_fin_rev_proyf, txtf_edi_proyf, txtf_impr_Acta_proyf, txtf_carga_acta_proyf, txtf_acuseDGN, txtf_carga_Proyf, txtf_cargaAntf)
            End If
        End If
        Select Case TBpt.SelectedTab.TabIndex
            Case 0 To 5
                tlbBotonera.Visible = True
            Case 6
                tlbBotonera.Visible = False
        End Select
    End Sub
    Private Sub cboRevision_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboRevision.SelectedIndexChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtrevision.Text = cboRevision.Text
        End If
    End Sub
    Private Sub CmdActaAprobacion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If txtAprob_Revision_Editorial.Text = "" Then
            MsgBox("No existe fecha de aprobaci�n de Revisi�n editorial")
            Exit Sub
        Else
            SGralTema = ""
            SGralPlan = ""
            gReporte = ""
            sGralComite = ""
            sGralTitulo = ""
            sGralClasificacion = ""
            sGralFecha = ""
            SGralTema = stema
            SGralPlan = sPlan
            sGralTitulo = txttitulodt.Text
            sGralComite = txtcomite.Text
            sGralClasificacion = txtclasificaciondt.Text
            sGralFecha = Format(Today.Now, "dd/MM/yyyy")

            txtf_impActAprob.Text = Format(Today.Now, "dd/MM/yyyy")
            txtf_impActAprob.Enabled = False
            gReporte = "Acta_Aprob_Dt"
            Reportes.Show()
            Reportes.MdiParent = frmMenu
        End If
    End Sub

    Private Sub CboResponsableDt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboResponsableDt.SelectedIndexChanged
        If sEtapa = "DT" Or sEtapa = "Editar" Then
            txtresponsableDt.Text = CboResponsableDt.Text
        End If
    End Sub

    Private Sub DT1_ValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DT1.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtf1.Text = Format(DT1.Value, "dd/MM/yyyy")
            DT2.Enabled = True
        End If
    End Sub

    Private Sub DT2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DT2.ValueChanged
        If sEtapa = "Agregar" Or sEtapa = "Editar" Then
            txtf2.Text = Format(DT2.Value, "dd/MM/yyyy")
            If CboTipoTema.Text = "Proyecto Publicado" Then
                txtf2.Text = Format(DT2.Value, "dd/MM/yyyy")
            Else
                If DT2.Value <= DT1.Value Then
                    MsgBox("La fecha de T�rmino debe ser mayor a la fecha de Inicio")
                    txtf2.Text = ""
                    Exit Sub
                End If


            End If

        End If
    End Sub

    Private Sub dtf_aprobCtGT_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If sEtapa = "DT" Then
            txtf_aprobCtGT.Text = Format(dtf_aprobCtGT.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub Label15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDt.Click

        '============================================================================================
        'If chkAlternativo.Checked = True And fcarga_minuta.Text = "" Then
        '    MsgBox("No se ha adjuntado la minuta de terminaci�n de Procedimiento alternativo")
        '    Exit Sub
        'Else
        '============================================================================================
        If Me.optComTecSi.Checked = True And Me.chkAlternativo.Checked = True And fcarga_minuta.Text = "" Then
            MsgBox("No se ha adjuntado la minuta de terminaci�n de Procedimiento alternativo")
            Exit Sub
        Else
            Dim openFileDialog1 As New OpenFileDialog
            Dim iIndice As Integer
            Dim Archivo As String


            openFileDialog1.InitialDirectory = "c:\"
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
            openFileDialog1.FilterIndex = 2
            openFileDialog1.RestoreDirectory = True
            Archivo = ""
            myStream = ""
            iIndice = 0

            If openFileDialog1.ShowDialog() = DialogResult.OK Then
                myStream = openFileDialog1.FileName()
                If Not (myStream = "") Then
                    For iIndice = Len(myStream) To 1 Step -1
                        If Mid(myStream, iIndice, 1) = "\" Then
                            Archivo = Mid(myStream, iIndice + 1)
                            iIndice = 1
                        End If
                    Next iIndice
                    'Para Renombrar el archivo
                    sCuenta = Len(ObjPrograma.Id_Plan)
                    sExt = Len(Archivo)
                    Dim Part As String
                    REM Part = Mid(Archivo, CInt(sExt - 3), 4)
                    Dim sCadena() As String = Split(Archivo, ".")
                    Part = "." & sCadena(sCadena.Length - 1)

                    'End Select
                    SDocumento = "TEMDT" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part

                    'txtadjDtf.Text = Archivo
                    txtadjDtf.Text = SDocumento

                    txtfcargaDtFinal.Text = Format(Date.Now, "dd/MM/yyyy")
                End If

            End If
        End If


    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream2 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream2 = openFileDialog1.FileName()
            If Not (myStream2 = "") Then
                For iIndice = Len(myStream2) To 1 Step -1
                    If Mid(myStream2, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream2, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                sCuenta = Len(ObjPrograma.Id_Plan)
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'End Select
                SDocumento = "TEMAAD" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part



                ' clsCopia.CopiaArchivos(myStream, "c:\ance")
                txtadjActAprobFinal.Text = SDocumento
                txtfcargaActaprobFinal.Text = Format(Date.Now, "dd/MM/yyyy")

            End If

        End If
    End Sub

    Private Sub cboresponsable_ant_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboresponsable_ant.SelectedIndexChanged
        If sEtapa = "Agregar" Or sEtapa = "ANT" Then
            txtresponsable_ant.Text = cboresponsable_ant.Text
        End If

    End Sub


    Private Sub dtf_aprobCtGT_ValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If sEtapa = "DT" Then
            txtf_aprobCtGT.Text = Format(dtf_aprobCtGT.Value, "dd/MM/yyyy")
        End If
    End Sub

    'Private Sub dtF_inicio_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If sEtapa = "PROY" Then
    '        txtf_ini_compub.Text = dtF_inicio.Value
    '    End If
    'End Sub

    'Private Sub dtF_Fin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If sEtapa = "PROY" Then
    '        txtf_limitecompub.Text = dtF_Fin.Value
    '    End If
    'End Sub


    Private Sub DTf_aprobComproy_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTf_aprobComproy.ValueChanged
        If sEtapa = "PROY" Then
            txtf_aprob_com.Text = Format(DTf_aprobComproy.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub cmdactaAprobacion_Proy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdactaAprobacion_Proy.Click
        ''If txtf_aprobrescompub.Text = "" And DateDiff(DateInterval.Day, dtresolucion.Value, dtF_limrescompub.Value) <> DateDiff(DateInterval.Day, dtresolucion.Value, dtresolucion.Value.AddMonths(6)) And optComTecSiProy.Checked Then
        ''    'MsgBox("No existe Fecha de Aprobaci�n de Resoluci�n a comentario P�blico")
        ''    MsgBox("No existe Fecha de Fecha de Aprobaci�n Comit� Proy")
        ''    Exit Sub
        ''Else
        If txtf_aprob_com.Text = "" Or txtf_edic.Text = "" Then
            MsgBox("No se puede mostrar el Acta si falta la Fecha de Aprobaci�n Comit� Proy" & Chr(13) & "O Fecha de edicion de proyecto final ")
            Exit Sub
        End If
        buscaComite()
        BuscaSesion(CDate(txtf_aprob_com.Text))
        BuscaPre()
        'sPreConance = ObjDirectorio.BuscaPresidentes
        SGralTema = ""
        SGralPlan = ""
        gReporte = ""
        sGralComite = ""
        sGralTitulo = ""
        sGralClasificacion = ""
        sGralFecha = ""
        SGralTema = stema
        SGralPlan = sPlan
        sGralTitulo = UCase(txttitulo_Proy.Text)
        sGralComite = txtcomite.Text
        sGralClasificacion = txtclasificacion_proy.Text
        sGralFecha = Format(Today.Now, "dd/MMMM/yyyy")
        sGralFecha = sGralFecha.Replace("/", " de ")

        sPaginas = txtpaginas_proy.Text
        sNorma = txtclasificacion_proy.Text

        ObjPrograma.Buscar(sPlan, stema)
        sCancela = IIf(ObjPrograma.Revision = 2, txtClasificacionPT.Text, "")
        txtf_imp_actaprob_proy.Text = Format(Today.Now, "dd/MM/yyyy")
        txtf_impActAprob.Enabled = False
        gReporte = "Acta_Aprob_PROY"
        'Reportes.Show()
        'Reportes.MdiParent = frmMenu
        Dim Reporte As New frmreporte
        Reporte.MdiParent = Me.MdiParent
        Reporte.Show()

        'End If
    End Sub
    Private Sub BuscaPre()
        ObjDirectorio.PreAnce = True
        ObjDirectorio.PreConance = False
        sPreAnce = UCase(ObjDirectorio.BuscaPresidentes)

        ObjDirectorio.PreAnce = False
        ObjDirectorio.PreConance = True
        sPreConance = UCase(ObjDirectorio.BuscaPresidentes)
    End Sub

    Private Sub buscaComite()
        ObjPrograma.Buscar(sPlan, stema)
        sComite = ObjPrograma.ID_Comite
        sCt = ObjPrograma.ID_CT
        sSc = ObjPrograma.ID_SC
        sGt = ObjPrograma.ID_Grupo
        sComiteT = ObjPrograma.ID_CT.Replace("CT", "")
    End Sub
    Private Sub BuscaSesion(ByVal fApProy As Date)
        'oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), "NA", "")  '********Sesiones Comite
        'oTablaSs = sesiones(sComite, sCt, sSc, sGt, "")
        oTablaSs = sesiones(sComite, "NA", "NA", "NA", "")
        Dim fFecha As Date
        Dim bandSes As Boolean = False
        If oTablaSs.Rows.Count > 0 Then
            For Each RegSes In oTablaSs.Rows
                fFecha = RegSes("Fecha")
                If fApProy = fFecha Then
                    sSesion = Microsoft.VisualBasic.Left(RegSes("numero"), 5)
                    bandSes = True
                End If
            Next
        End If

        If bandSes <> True Then
            sSesion = " del " & fApProy
        End If
    End Sub
    Private Function sesiones(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String) As DataTable
        Cursor.Current = Cursors.WaitCursor
        Dim combotable As DataTable
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columna As DataColumn
        Dim cm As CurrencyManager

        Try
            With objsesiones
                .Bandera = 9
                .Id_Comite = comite
                .Id_CT = CT
                .Id_SC = SC
                .Id_Grupo = grupo
                combotable = .Listar()
            End With
            If CT.Trim <> "NA" Then
                comite = CT.Trim
            ElseIf SC.Trim <> "NA" Then
                comite = SC.Trim
            ElseIf grupo.Trim <> "NA" Then
                comite = grupo.Trim
            End If
            combotable.Columns.Add("Numero")
            iNumero = 0
            For Each regs In combotable.Rows
                iNumero = iNumero + 1
                combotable.Rows(iNumero - 1).Item("Numero") = iNumero.ToString + "/" + Format$(regs("Fecha"), "yy") + " " + comite.Trim
            Next

            If iNumero = 0 And iEditar <> Nothing Then
                MsgBox("No tiene asignada ninguna Sesion", MsgBoxStyle.Information)
            End If

            cm = CType(BindingContext(combotable), CurrencyManager)
            Dim dv As DataView = CType(cm.List, DataView)
            If compara.Length > 0 Then dv.RowFilter = "Numero = '" & compara & "'"
            Cursor.Current = Cursors.Default
            Return combotable

        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Function

    Private Sub dtF_inicio_ValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtF_inicio.ValueChanged
        Dim sDiaSemana As String
        If sEtapa = "PROY" Then
            txtf_ini_compub.Text = Format(dtF_inicio.Value, "dd/MM/yyyy")
            'el roy me dijo que son 60 dias no 61 como se tenia
            'dtF_Fin.Value = dtF_inicio.Value.AddDays(61)
            dtF_Fin.Value = dtF_inicio.Value.AddDays(60)
            sDiaSemana = Format(dtF_Fin.Value, "dddd")
            Select Case LCase(sDiaSemana)
                Case "domingo", "sunday"
                    dtF_Fin.Value = dtF_Fin.Value.AddDays(1)
                Case "s�bado", "saturday"
                    dtF_Fin.Value = dtF_Fin.Value.AddDays(2)
            End Select
        End If
    End Sub

    Private Sub dtF_Fin_ValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtF_Fin.ValueChanged
        Dim sDiaSemana As String
        If sEtapa = "PROY" Then
            txtf_limitecompub.Text = Format(dtF_Fin.Value, "dd/MM/yyyy")
            banFecha = False
            'txtdifDates.Text = (DateDiff(DateInterval.Day, dtF_inicio.Value, dtF_Fin.Value)) - 1
            txtdifDates.Text = (DateDiff(DateInterval.Day, dtF_inicio.Value, dtF_Fin.Value))
            If txtdifDates.Text < 60 Then
                banFecha = True
            End If
            If CInt(txtdifDates.Text) <= 0 Then txtdifDates.Text = 0
        Else
            banFecha = False
        End If
        If bandCom = True Then
            dtresolucion.Value = dtF_Fin.Value.AddDays(1)

            sDiaSemana = Format(dtresolucion.Value, "dddd")
            Select Case LCase(sDiaSemana)
                Case "domingo", "sunday"
                    dtresolucion.Value = dtresolucion.Value.AddDays(1)
                Case "s�bado", "saturday"
                    dtresolucion.Value = dtresolucion.Value.AddDays(2)
            End Select
        End If
    End Sub

    Private Sub dtresolucion_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtresolucion.ValueChanged
        Dim sDiaSemana As String
        If sEtapa = "PROY" Then
            txtfResolucion.Text = Format(dtresolucion.Value, "dd/MM/yyyy")
            sDiaSemana = Format(dtF_limrescompub.Value, "dddd")
        End If
        If bandCom = True Then
            dtF_limrescompub.Value = dtresolucion.Value.AddMonths(6)
            sDiaSemana = Format(dtF_limrescompub.Value, "dddd")
        End If
        Select Case LCase(sDiaSemana)
            Case "domingo", "sunday"
                dtF_limrescompub.Value = dtF_limrescompub.Value.AddDays(1)
            Case "s�bado", "saturday"
                dtF_limrescompub.Value = dtF_limrescompub.Value.AddDays(2)
        End Select
    End Sub

    Private Sub dtF_limrescompub_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtF_limrescompub.ValueChanged
        If sEtapa = "PROY" Then
            TXTF_limrescompub.Text = Format(dtF_limrescompub.Value, "dd/MM/yyyy")
        End If
        If dtresolucion.Visible = True And DateDiff(DateInterval.Day, dtresolucion.Value, dtF_limrescompub.Value) > DateDiff(DateInterval.Day, dtresolucion.Value, dtresolucion.Value.AddMonths(6)) Then
            dtf_aprobrescompub.Visible = True
            txtf_aprobrescompub.Visible = True
        Else
            dtf_aprobrescompub.Visible = False
            txtf_aprobrescompub.Visible = False
            txtf_aprobrescompub.Text = ""
        End If

    End Sub

    Private Sub dtf_aprobrescompub_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtf_aprobrescompub.ValueChanged
        If sEtapa = "PROY" Then
            txtf_aprobrescompub.Text = Format(dtf_aprobrescompub.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtvobo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtvobo.ValueChanged
        Dim sdiasemana As String
        If sEtapa = "PROY" Then
            txtvobo.Text = Format(dtvobo.Value, "dd/MM/yyyy")
            sdiasemana = Format(dtfiniRev.Value, "dddd")
            If bandCom = True Then
                dtfiniRev.Value = dtvobo.Value.AddDays(1)
                sdiasemana = Format(dtfiniRev.Value, "dddd")
            End If
        End If

        Select Case LCase(sdiasemana)
            Case "domingo", "sunday"
                dtfiniRev.Value = dtfiniRev.Value.AddDays(1)
            Case "s�bado", "saturday"
                dtfiniRev.Value = dtfiniRev.Value.AddDays(2)
        End Select
    End Sub

    Private Sub dtfiniRev_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfiniRev.ValueChanged
        If sEtapa = "PROY" Then
            txtfiniRev.Text = Format(dtfiniRev.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtftermrev_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtftermrev.ValueChanged
        If sEtapa = "PROY" Then
            txtftermrev.Text = Format(dtftermrev.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtf_edic_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtf_edic.ValueChanged
        'si tengo comentarios y tengo fecha de aprobacion de resolucion a comentarios publicos 
        If sEtapa = "PROY" Then
            If (optComTecSiProy.Checked Or optComEdSiProy.Checked) And txtf_ap2.Text <> "" Then
                txtf_edic.Text = Format(dtf_edic.Value, "dd/MM/yyyy")
            End If
            'si no tengo comnetarios
            If optComTecSiProy.Checked = False And optComEdSiProy.Checked = False Then
                txtf_edic.Text = Format(dtf_edic.Value, "dd/MM/yyyy")
            End If
        End If
    End Sub

    Private Sub cmdproy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdProy.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream3 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream3 = openFileDialog1.FileName()
            If Not (myStream3 = "") Then
                For iIndice = Len(myStream3) To 1 Step -1
                    If Mid(myStream3, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream3, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                sCuenta = Len(ObjPrograma.Id_Plan)
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'End Select
                SDocumento = "TEMPYF" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part


                ' clsCopia.CopiaArchivos(myStream, "c:\ance")
                txtadjProyfinal.Text = SDocumento
                txtfCargaProyf.Text = Format(Date.Now, "dd/MM/yyyy")
            End If

        End If
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdproyf.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream4 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream4 = openFileDialog1.FileName()
            If Not (myStream4 = "") Then
                For iIndice = Len(myStream4) To 1 Step -1
                    If Mid(myStream4, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream4, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice

                sCuenta = Len(ObjPrograma.Id_Plan)
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'End Select
                SDocumento = "TEMAAP" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part


                ' clsCopia.CopiaArchivos(myStream, "c:\ance")
                'txtadjactPROYF.Text = Archivo
                txtadjactPROYF.Text = SDocumento
                txtfcarga_actaprobPROYF.Text = Format(Date.Now, "dd/MM/yyyy")
            End If

        End If
    End Sub


    Private Sub dtacusePROYF_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtacusePROYF.ValueChanged
        If sEtapa = "PROY" Then
            txtacusePROYF.Text = Format(dtacusePROYF.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub cboResponsable_proy_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsable_proy.SelectedIndexChanged
        If sEtapa = "PROY" Then
            txtresponsable_proy.Text = cboResponsable_proy.Text
        End If
    End Sub

    Private Sub cmdant_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdant.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream3 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream5 = openFileDialog1.FileName()
            If Not (myStream5 = "") Then
                For iIndice = Len(myStream5) To 1 Step -1
                    If Mid(myStream5, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream5, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice

                sCuenta = Len(ObjPrograma.Id_Plan)
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'End Select
                SDocumento = "TEMANF" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part

                ' clsCopia.CopiaArchivos(myStream, "c:\ance")
                txtadjantF.Text = SDocumento
                txtcarg_antfinal.Text = Format(Date.Now, "dd/MM/yyyy")
            End If

        End If
    End Sub


    Private Sub cboresponsable_procalt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboresponsable_procalt.SelectedIndexChanged
        If sEtapa = "DT" Then
            txtresponsable_procalt.Text = cboresponsable_procalt.Text
        End If
    End Sub


    Private Sub dtiniresp_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtiniresp.ValueChanged
        If sEtapa = "DT" Then
            txtf_inicresp.Text = Format(dtiniresp.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub tdfinresp_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tdfinresp.ValueChanged
        If sEtapa = "DT" Then
            txtf_finresp.Text = Format(tdfinresp.Value, "dd/MM/yyyy")
        End If

    End Sub

    Private Sub dtinicom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtinicom.ValueChanged
        If sEtapa = "DT" Then
            txtf_inic_com.Text = Format(dtinicom.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub dtfincom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfincom.ValueChanged
        If sEtapa = "DT" Then
            txtf_fin_com.Text = Format(dtfincom.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub chkAlternativo_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAlternativo.CheckedChanged
        procedimientoAlt()
    End Sub
    Private Sub procedimientoAlt()
        If chkAlternativo.Checked = True Then
            pnlProcAlter.Visible = True

            BuscaComentarios("TEC", optComTecSi, txtnumcomTec, 2)
            BuscaComentarios("ED", optComEdSi, txtnumcomed, 2)
            If optComTecNo.Checked = True Then
                GrbApDT.Visible = False
                cmdminuta.Enabled = True
            Else
                GrbApDT.Visible = True
                cmdminuta.Enabled = False
            End If
        Else
            pnlProcAlter.Visible = False
            txtnumcomTec.Text = ""
            txtnumcomed.Text = ""
        End If
    End Sub
    Private Sub BuscaComentarios(ByVal tipocom As String, ByVal radio As RadioButton, ByVal text As TextBox, ByVal id_etapa As Integer)
        Dim temp As Integer
        If sPlan = "" And stema = "" Then
            Exit Sub
        End If
        ObjComentarios.Bandera = 41
        ObjComentarios.Id_Plan = sPlan
        ObjComentarios.Id_Tema = stema
        ObjComentarios.Id_Etapa = id_etapa
        'ObjComentarios.BuscaComentario()

        'temp = zId_Etapa
        'If zId_Etapa = 1 Then
        '    zId_Etapa = 2
        'End If

        ''If zId_Etapa > 2 Then
        ''    zId_Etapa = 2
        ''End If

        'ObjComentarios.Id_Etapa = zId_Etapa
        ObjComentarios.Tipo_comentario = tipocom
        ObjComentarios.Referencia = RefCompleta
        ObjComentarios.BuscaComentario()
        If ObjComentarios.traeComentarios = True Then
            radio.Checked = True
            text.Text = ObjComentarios.Contador
        Else
            radio.Checked = False
            text.Text = ""
        End If
        'zId_Etapa = temp

        REM en caso de tener comentarios de cualquier tipo entonces habilito la carga de proyecto final
        If (optComTecSiProy.Checked = True Or optComEdSiProy.Checked = True) Then
            cmdProyectoFinal.Enabled = True
        Else
            cmdProyectoFinal.Enabled = False
        End If
    End Sub

    Private Sub cmdminuta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdminuta.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream6 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream6 = openFileDialog1.FileName()
            If Not (myStream6 = "") Then
                For iIndice = Len(myStream6) To 1 Step -1
                    If Mid(myStream6, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream6, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                sCuenta = Len(ObjPrograma.Id_Plan)


                ''sExt = Len(Archivo)
                ''Dim Part As String
                ''Part = Mid(Archivo, CInt(sExt - 3), 4)
                sExt = Len(Archivo)
                Dim Part As String
                REM Part = Mid(Archivo, CInt(sExt - 3), 4)
                Dim sCadena() As String = Split(Archivo, ".")
                Part = "." & sCadena(sCadena.Length - 1)

                'End Select
                SDocumento = "TEMMTA" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part
                ' clsCopia.CopiaArchivos(myStream, "c:\ance")
                txtminuta.Text = SDocumento
                fcarga_minuta.Text = Format(Date.Now, "dd/MM/yyyy")
            End If

        End If
    End Sub

    Private Sub pnlProcAlter_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlProcAlter.Paint

    End Sub

    Private Sub chkModTec_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkModTec.CheckedChanged
        If sEtapa = "Agregar" Then
            If chkModTec.Checked = True Then
                chkNormal.Checked = False
            End If
        End If
    End Sub

    Private Sub chkNormal_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNormal.CheckedChanged
        If sEtapa = "Agregar" Then
            If chkNormal.Checked = True Then
                chkModTec.Checked = False
            End If
        End If
    End Sub

    Private Sub TbPgProgramaTrabajo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TbPgProgramaTrabajo.Click

    End Sub
    Sub llena_responsable(ByVal responsable As String)
        Try

            'objempleados.Bandera = 6  'funfiona cuando se llena el treeview
            ObjEmpleados.ID_Area = "12"
            ObjEmpleados.Id_usuario = responsable
            'cboResponsable.DataSource = 
            ObjEmpleados.ListaCombo(cboResponsable)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub chkarmonizada_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkarmonizada.CheckedChanged
        If chkarmonizada.Checked = True Then
            Txtbasada.Visible = False
            txtarmonizacion.Visible = True
            chkarmonizada.Visible = True
            txtjustarm.Visible = True
            Label95.Visible = True
            txtjustarm.Enabled = True
        Else
            txtarmonizacion.Visible = False
            Txtbasada.Visible = False
            chkBasada.Visible = True
            txtjustarm.Visible = False
            Label95.Visible = False
            txtjustarm.Enabled = False
            If chkBasada.Checked = True Then Txtbasada.Visible = True
        End If
    End Sub

    Private Sub CmdActaAprobacion_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdActaAprobacion.Click
        If txtAprob_Revision_Editorial.Text = "" And chkrevedit.Checked Then
            MsgBox("No existe fecha de aprobaci�n de Revisi�n editorial")
            Exit Sub
        Else
            SGralTema = ""
            SGralPlan = ""
            gReporte = ""
            sGralComite = ""
            sGralTitulo = ""
            sGralClasificacion = ""
            sGralFecha = ""
            SGralTema = stema
            SGralPlan = sPlan
            sGralTitulo = txttituloant.Text

            Referenciar("abandono")
            If (ObjPrograma.ID_CT = "" Or ObjPrograma.ID_CT = "NA") Then

                ObjComites.Bandera = 4
                ObjComites.ID_Comite = ObjPrograma.ID_Comite
                ObjComites.ID_CT = ObjPrograma.ID_CT
                ObjComites.ID_SC = ObjPrograma.ID_SC
                ObjComites.ID_GT = ObjPrograma.ID_Grupo
                ObjComites.Busca_uno()
                'modificacion segun roy tienen se controla en la descripcion q dira el acta
                sGralComite = ObjComites.Descripcion
                'sGralComite = ObjPrograma.ID_Grupo
            Else
                ObjComites.Bandera = 2
                ObjComites.ID_CT = ObjPrograma.ID_CT
                ObjComites.Busca_uno()
                'modificacion segun roy tienen se controla en la descripcion q dira el acta
                sGralComite = ObjComites.Descripcion
            End If
            'sGralComite = txtcomite.Text
            sGralClasificacion = txtclasificacion_ant.Text
            'sGralFecha = Format(Today.Now, "dd/MMMM/yyyy")
            sGralFecha = Format(Today.Now, "dd/MMMM/yyyy")
            sGralFecha = sGralFecha.Replace("/", " de ")
            txtf_impActAprob.Text = Format(Today.Now, "dd/MM/yyyy")
            txtf_impActAprob.Enabled = False
            gReporte = "Acta_Aprob_Dt"

            Dim Reporte As New frmreporte
            Reporte.MdiParent = Me.MdiParent
            Reporte.Show()

            'Reportes.Show()
            'Reportes.MdiParent = frmMenu

        End If
    End Sub

    Private Sub dtf_aprobCtGT_ValueChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtf_aprobCtGT.ValueChanged
        txtf_aprobCtGT.Text = dtf_aprobCtGT.Text
    End Sub

    Private Sub cmdacta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdacta.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream7 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream7 = openFileDialog1.FileName()
            If Not (myStream7 = "") Then
                For iIndice = Len(myStream7) To 1 Step -1
                    If Mid(myStream7, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream7, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                'Para Renombrar el archivo
                sCuenta = Len(ObjPrograma.Id_Plan)
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'End Select
                SDocumento = "TEMANTAAF" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part
                txtadjActAprobFinal.Text = SDocumento
                txtfcargaActaprobFinal.Text = Format(Now(), "dd/MM/yyyy")
                'txtadjDtf.Text = Archivo
                'txtadjDtf.Text = SDocumento
                txtfcargaDtFinal.Text = Format(Date.Now, "dd/MM/yyyy")
            End If
        End If
    End Sub

    Private Sub Button1_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String


        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        Archivo = ""
        myStream8 = ""
        iIndice = 0

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream8 = openFileDialog1.FileName()
            If Not (myStream8 = "") Then
                For iIndice = Len(myStream8) To 1 Step -1
                    If Mid(myStream8, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream8, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                'Para Renombrar el archivo
                sCuenta = Len(ObjPrograma.Id_Plan)
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                'End Select
                SDocumento = "TEMPROYMA" + Mid(ObjPrograma.Id_Plan, CInt(sCuenta - 3), 4) + "_" + Format$(ObjPrograma.Id_Tema, "0000") + Part

                'txtadjDtf.Text = Archivo
                TextBox3.Text = SDocumento
                TextBox2.Text = Format(Now(), "dd/MM/yyyy")
                txtfcargaDtFinal.Text = Format(Date.Now, "dd/MM/yyyy")
            End If

        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optCorrNo.CheckedChanged
        txtF_Correcciones.Text = ""
        txtF_Correcciones.Visible = False
        dtpFCorrec.Text = Nothing
        dtpFCorrec.Visible = False
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optCorrSi.CheckedChanged
        txtF_Correcciones.Visible = True
        dtpFCorrec.Visible = True
        txtF_Correcciones.Text = ""
    End Sub

    Private Sub dtpFCorrec_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpFCorrec.ValueChanged
        txtF_Correcciones.Text = dtpFCorrec.Text
    End Sub
    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(sPlan, stema)
        srefP = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
    End Sub

    Private Sub dtF_Fin_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtF_Fin.LostFocus
        If banFecha = True Then
            MsgBox("La Diferencia de fechas no puede ser menor a 60 dias")
            Exit Sub
        End If
    End Sub

    Private Sub dpFverif_rev_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dpFverif_rev.ValueChanged
        If sEtapa = "PROY" Then
            txtfverifrefProy.Text = Format(dpFverif_rev.Value, "dd/MM/yyyy")
        End If
    End Sub

    Private Sub cmdRegresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRegresar.Click
        TbPgProgramaTrabajo.Enabled = True
        If optPT.Checked = True Then
            abandono()
            JustificRegreso()
        End If
        Referenciar("abandono")
        If optDT.Checked = True Then
            ModificaProy(5)
            ModificaANT(5)

            InsertaPAvanceTemas(1, 0, "DT")
            ModificaPDT(5)
            ActualizaProcAlternativo(5)
            'InsertaPDT(1, 0)
            'ProcAlternativo(1, 0)
            InsertaPrograma("abandono", 1, 2, 0, ObjPrograma.Tipo_Pro)
            ProgTrabDoctos(3, 6)
            ProgTrabDoctos(12, 6)
            JustificRegreso()
        End If
        If optAnt.Checked = True Then
            ModificaProy(5)
            'InsertaPant(1, 0)
            ModificaANT(5)

            InsertaPAvanceTemas(1, 0, "ANT")
            InsertaPDT(1, 0)
            ProcAlternativo(1, 0)
            InsertaPrograma("abandono", 1, 3, 0, ObjPrograma.Tipo_Pro)

            ProgTrabDoctos(3, 6)
            ProgTrabDoctos(12, 6)
            ProgTrabDoctos(7, 6)
            ProgTrabDoctos(4, 6)
            ProgTrabDoctos(15, 6)

            JustificRegreso()
        End If
        If optProy.Checked = True Then
            ModificaProy(5) 'pone en status 10 la referencia de proyecto
            InsertaPant(1, 0)

            InsertaPAvanceTemas(1, 0, "ANT")
            InsertaPDT(1, 0)
            ProcAlternativo(1, 0)
            InsertaPrograma("abandono", 1, 4, 0, ObjPrograma.Tipo_Pro) 'modificada

            ProgTrabDoctos(3, 6)
            ProgTrabDoctos(12, 6)
            ProgTrabDoctos(7, 6)
            ProgTrabDoctos(4, 6)
            ProgTrabDoctos(15, 6)

            'JustificRegreso()
        End If
        Dim FrmTemas As New frmPNN_temas
        FrmTemas.MdiParent = Me.MdiParent
        Me.Dispose()
        FrmTemas.Show()
    End Sub

    Private Sub JustificRegreso()
        Dim Justific As New FrmAbandono
        Justific.ShowDialog()
        Referenciar("abandono")
        ObjJustiRegresos.ref_a�o = ObjPrograma.RefA�o
        ObjJustiRegresos.ref_comite = ObjPrograma.RefComite
        ObjJustiRegresos.ref_consecutivo = ObjPrograma.RefConsecutivo
        ObjJustiRegresos.ref_regreso = ObjPrograma.RefRegreso
        ObjJustiRegresos.ref_traspaso = ObjPrograma.RefTraspaso
        ObjJustiRegresos.Status = 1
        ObjJustiRegresos.F_Regreso = Format(Now, "dd/MM/yyyy")
        ObjJustiRegresos.Justificacion = respuesta
        ObjJustiRegresos.Bandera = 1
        ObjJustiRegresos.Insertar()
    End Sub

    Private Sub cmdCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancelar.Click
        pnlRegreso.Visible = False
        TbPgProgramaTrabajo.Enabled = True
    End Sub
    Private Sub ProgTrabDoctos(ByVal Tipo_docto As Integer, ByVal bandDoctos As Integer)
        Referenciar("abandono")
        clsDoctosTemas.Id_tipo_doc = Tipo_docto
        'clsDoctosTemas.sReferencia = srefP
        With ObjPrograma
            clsDoctosTemas.RefA�o = .RefA�o
            clsDoctosTemas.RefComite = .RefComite
            clsDoctosTemas.RefConsecutivo = .RefConsecutivo
            clsDoctosTemas.RefRegreso = .RefRegreso
            clsDoctosTemas.RefTraspaso = .RefTraspaso
        End With
        clsDoctosTemas.Actualiza(stema, sPlan, "", "", bandDoctos)
    End Sub
    Private Sub abandono()
        ModificaProy(5)
        ModificaANT(5)
        ModificaPDT(5)
        ModificaAvancesTemas(6)
        ActualizaProcAlternativo(6)
        ProgTrabDoctos(0, 5)

        InsertaPrograma("abandono", 1, 1, 0, 1, 11)

        Referenciar("abandono")
        ObjFechasavance.RefA�o = ObjPrograma.RefA�o
        ObjFechasavance.RefComite = ObjPrograma.RefComite
        ObjFechasavance.RefConsecutivo = ObjPrograma.RefConsecutivo
        ObjFechasavance.RefRegreso = ObjPrograma.RefRegreso
        ObjFechasavance.RefTraspaso = ObjPrograma.RefTraspaso
        ObjFechasavance.Actualiza(1, sPlan, stema, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
    End Sub
    Private Sub txtclasificaciondt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtclasificaciondt.KeyPress
        bandModifClasific = True
    End Sub

    Private Sub chkrevedit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkrevedit.CheckedChanged
        If band <> True Then
            If chkrevedit.Checked = False Then
                If (MsgBox("No se contemplara la fecha de aprobacion de revision editorial", MsgBoxStyle.OKCancel) = MsgBoxResult.OK) Then
                    chkrevedit.Checked = False
                Else
                    chkrevedit.Checked = True
                End If
            End If
        End If
    End Sub

    Private Sub optApDtSi_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optApDtSi.CheckedChanged
        If optApDtSi.Checked Then
            cmdminuta.Enabled = True
        Else
            cmdminuta.Enabled = False
        End If
    End Sub

    Private Sub txtclasificacion_ant_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtclasificacion_ant.KeyPress
        bandModifClasificAnt = False
    End Sub

    Private Sub txtclasificacion_proy_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtclasificacion_proy.KeyPress
        bandModifClasificProy = False
    End Sub

    Private Sub DTf_ap_res2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTf_ap_res2.ValueChanged
        txtf_ap2.Text = Format(DTf_ap_res2.Value, "dd/MM/yyyy")
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkTitulo.LinkClicked
        tltMensaje.SetToolTip(lnkTitulo, txttituloPT.Text)
    End Sub

    Private Sub lnkObjetivo_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkObjetivo.LinkClicked
        tltMensaje.SetToolTip(lnkObjetivo, txtobjetivo.Text)
    End Sub

    Private Sub lklJustificacion_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lklJustificacion.LinkClicked
        tltMensaje.SetToolTip(lklJustificacion, txtjustificacion.Text)
    End Sub
    Private Sub EtapasInspeccion()
        llenaPrevio()
        ValidaEtapa1()
        ValidaEtapa2()
        ValidaEtapa3()
        ValidaEtapa4()
        ValidaEtapa5()
        ValidaEtapa6()
    End Sub
    Private Sub llenaPrevio()
        objInspeccionPrueba.ref_a�o = ObjPrograma.RefA�o
        objInspeccionPrueba.ref_comite = ObjPrograma.RefComite
        objInspeccionPrueba.ref_consecutivo = ObjPrograma.RefConsecutivo
        objInspeccionPrueba.ref_regreso = ObjPrograma.RefRegreso
        objInspeccionPrueba.ref_traspaso = ObjPrograma.RefTraspaso
    End Sub
    Private Sub ValidaEtapa1()
        'si hay fecha del dof entonces
        ''''si no es proyecto publicado o modificacion tecnica entonces
        '''''''IA
        ''''de locontario
        '''''''NA
        'de lo contrario
        ''''IE

        'referencio
        stema = txtnumerotema.Text
        Referenciar("abandono")
        'busco fecha del dof
        ObjPlan.Buscar(sPlan)

        'busco si existe ya el registro en inspeccion prueba
        objInspeccionPrueba.sReferencia = srefP
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        'inserta
        If objInspeccionPrueba.Encontrado = False Then
            objInspeccionPrueba.Bandera = 3
            'lleno datos previos
            llenaPrevio()
        Else 'actualiza
            objInspeccionPrueba.Bandera = 4
        End If

        If ObjPlan.Publicado_DOF <> "" Then
            If CboTipoTema.SelectedValue <> 1 And chkModTec.Checked = False Then
                'ia
                objInspeccionPrueba.E1_1 = "IA"
                objInspeccionPrueba.E1_2 = "IA"
            Else
                'na
                objInspeccionPrueba.E1_1 = "NA"
                objInspeccionPrueba.E1_2 = "NA"
            End If
        Else
            'ie
            objInspeccionPrueba.E1_1 = "IE"
            objInspeccionPrueba.E1_2 = "IE"
        End If
        objInspeccionPrueba.Insertar()
    End Sub
    Private Sub ValidaEtapa2()
        'Si es modificaion tecnica o proyecto publicado
        '''NA en todas las inspescciones
        'de lo contrario
        '''si tengo fecha �aprobacion? rev editorial
        ''''''IA en 1 y 5
        '''de lo contrario
        ''''''Si en 1 y5
        '''si tengo fecha de aprobacion edit
        ''''''IE en 2,3,4
        '''de lo contrario
        ''''''SI en 2,3,4

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If cboRevision.SelectedValue = 1 Or chkModTec.Checked Then
            objInspeccionPrueba.E2_1 = "NA"
            objInspeccionPrueba.E2_2 = "NA"
            objInspeccionPrueba.E2_3 = "NA"
            objInspeccionPrueba.E2_4 = "NA"
            objInspeccionPrueba.E2_5 = "NA"
        Else
            If txtAprob_Revision_Editorial.Text <> "" Then
                objInspeccionPrueba.E2_1 = "IA"
                objInspeccionPrueba.E2_5 = "IA"
            Else
                objInspeccionPrueba.E2_1 = "SI"
                objInspeccionPrueba.E2_5 = "SI"
            End If

            If txtf_aprobCtGT.Text <> "" Then
                objInspeccionPrueba.E2_2 = "IA"
                objInspeccionPrueba.E2_3 = "IA"
                objInspeccionPrueba.E2_4 = "IA"
            Else
                If txtAprob_Revision_Editorial.Text <> "" Then
                    objInspeccionPrueba.E2_2 = "IE"
                    objInspeccionPrueba.E2_3 = "IE"
                    objInspeccionPrueba.E2_4 = "IE"
                Else
                    objInspeccionPrueba.E2_2 = "SI"
                    objInspeccionPrueba.E2_3 = "SI"
                    objInspeccionPrueba.E2_4 = "SI"
                End If
            End If
        End If
        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub
    Private Sub ValidaEtapa3()
        'Si tengo fecha de aprobacion comite proy
        '''IA
        'de lo contrario
        '''''si tengo fecha de aprobacion del CT o GT
        ''''''''IE
        '''''de lo contrario
        ''''''''NA
        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtf_aprob_com.Text <> "" Then
            objInspeccionPrueba.E3_1 = "IA"
            objInspeccionPrueba.E3_2 = "IA"
            objInspeccionPrueba.E3_3 = "IA"
        Else
            If txtf_aprobCtGT.Text <> "" Then
                objInspeccionPrueba.E3_1 = "IE"
                objInspeccionPrueba.E3_2 = "IE"
                objInspeccionPrueba.E3_3 = "IE"
            Else
                objInspeccionPrueba.E3_1 = "NA"
                objInspeccionPrueba.E3_2 = "NA"
                objInspeccionPrueba.E3_3 = "NA"
            End If
        End If
        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()

    End Sub
    Private Sub ValidaEtapa4()
        'si tengo fecha de publicacion a periodo de comentarios publicos
        ''''IA
        'de locontrario
        ''''si tengo fecha de aprobacion comite proy
        '''''''IE
        ''''de lo contrario
        '''''''NA

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtf_ini_compub.Text <> "" Then
            objInspeccionPrueba.E4_1 = "IA"
            objInspeccionPrueba.E4_2 = "IA"
            objInspeccionPrueba.E4_3 = "IA"
            objInspeccionPrueba.E4_4 = "IA"
        Else
            If txtf_aprob_com.Text <> "" Then
                objInspeccionPrueba.E4_1 = "IE"
                objInspeccionPrueba.E4_2 = "IE"
                objInspeccionPrueba.E4_3 = "IE"
                objInspeccionPrueba.E4_4 = "IE"
            Else
                objInspeccionPrueba.E4_1 = "NA"
                objInspeccionPrueba.E4_2 = "NA"
                objInspeccionPrueba.E4_3 = "NA"
                objInspeccionPrueba.E4_4 = "NA"
            End If
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub
    Private Sub ValidaEtapa5()
        'si tengo fecha de publicacion a periodo de comentarios publicos
        ''''IA
        'de lo contrario
        ''''NA

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtf_ini_compub.Text <> "" Then
            objInspeccionPrueba.E5_1 = "IA"
        Else
            objInspeccionPrueba.E5_1 = "NA"
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub
    Private Sub ValidaEtapa6()

        Referenciar("Abandono")
        objInspeccionPrueba.Bandera = 2
        objInspeccionPrueba.Buscar()
        objInspeccionPrueba.sReferencia = srefP

        If txtf_ap2.Text <> "" Then
            objInspeccionPrueba.E6_1 = "IA"
            objInspeccionPrueba.E6_2 = "IA"
            objInspeccionPrueba.E6_3 = "IA"
            objInspeccionPrueba.E6_4 = "IA"
        Else
            If txtfResolucion.Text <> "" Then
                objInspeccionPrueba.E6_1 = "IE"
                objInspeccionPrueba.E6_2 = "IE"
                objInspeccionPrueba.E6_3 = "IE"
                objInspeccionPrueba.E6_4 = "IE"
            Else
                objInspeccionPrueba.E6_1 = "NA"
                objInspeccionPrueba.E6_2 = "NA"
                objInspeccionPrueba.E6_3 = "NA"
                objInspeccionPrueba.E6_4 = "NA"
                'objInspeccionPrueba.E6_5 = "NA"
                'objInspeccionPrueba.E6_6 = "NA"
            End If

        End If

        If txtvobo.Text <> "" Then
            objInspeccionPrueba.E6_5 = "IA"
            objInspeccionPrueba.E6_6 = "IA"
        Else
            objInspeccionPrueba.E6_5 = ""
            objInspeccionPrueba.E6_6 = ""
        End If

        'buscar si hay abandono 
        ObjPrograma.Bandera = 6
        ObjPrograma.sReferencia = srefP
        ObjPrograma.BuscaAbandono()
        If ObjPrograma.Existe = True Then
            objInspeccionPrueba.E6_6 = "IA"
        End If

        objInspeccionPrueba.Bandera = 4
        objInspeccionPrueba.Insertar()
    End Sub

    Private Sub TVHistorialPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVHistorialPNN.AfterSelect
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")
        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                stema = ""
                sPlan = ""
            Case 2
                sPlan = Matriz(1)
                sEtapa = "Plan"
                TVHistorialPNN.Refresh()
                TVHistorialPNN.Nodes.Clear()
            Case 3
                sPlan = Matriz(1)
                stema = Matriz(2)
                If sPlan <> "" And stema <> "" Then
                    Call temas_historial(sPlan, stema)
                End If
        End Select
    End Sub
    Private Sub temas_historial(ByVal splan As String, ByVal stema As String)
        Dim sreftemp As String
        Dim srep As String
        Referenciar("abandono")
        sreftemp = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + "0" + "0"

        ObjPrograma.Bandera = 37
        ObjPrograma.Band = True
        ObjPrograma.sReferencia = sreftemp
        ObjPrograma.Buscar(splan, stema)

        'llenando los campos
        txthreferencia.Text = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + "R" + Format(ObjPrograma.RefRegreso, "00") + "T" + Format(ObjPrograma.RefTraspaso, "00")
        txthclasificacion.Text = ObjPrograma.Clasificacion
        txthNumeroTema.Text = ObjPrograma.Id_Tema

        'buscar tipo tema
        ObjTiposTema.Buscar(ObjPrograma.Tipo_Tema)
        txthtipotema.Text = ObjTiposTema.Descripcion

        txthtitulo.Text = ObjPrograma.Titulo
        txthobjetivo.Text = ObjPrograma.Obj
        txthjustificacion.Text = ObjPrograma.Justificacion
        txthfinicio.Text = ObjPrograma.F_Inicio
        txthfFin.Text = ObjPrograma.F_Fin


        If ObjPrograma.Basada_Norma = True Then
            chkhbasado.Checked = True
        Else
            chkhbasado.Checked = False
        End If

        If ObjPrograma.Armonizada = True Then
            chkharmonizada.Checked = True
        Else
            chkharmonizada.Checked = False
        End If

        txthbasado.Text = ObjPrograma.Id_Norma
        txtharmonizada.Text = ObjPrograma.Id_Norma

        txthjustiArmonizada.Text = ObjPrograma.Justi_Armonizada
        txthRevision.Text = ObjPrograma.Revision



        'busca responsable
        ObjEmpleados.Bandera = 3
        ObjEmpleados.Id_usuario = ObjPrograma.Responsable
        ObjEmpleados.Buscar()
        txthresponsable.Text = ObjEmpleados.NOMBRE_COMPLETO



        'vALIDACI�N PARA SABER EXACTAMENTE A QUE COMIT� PERTENECE.
        'SI ES GRUPO DE TRABAJO
        If ObjPrograma.ID_Grupo <> "NA" Then
            txthpertenece.Text = ObjPrograma.ID_Grupo
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Bandera = 4
            ObjComites.Busca_cuatro()

            srep = ObjComites.Responsable
        End If
        'SI ES SUBCOMITE
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txthpertenece.Text = ObjPrograma.ID_SC
            ObjComites.Bandera = 3
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo
            ObjComites.Busca_tres()
            srep = ObjComites.Responsable

        End If
        'SI ES COMITE TECNICO
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txthpertenece.Text = ObjPrograma.ID_CT
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo

            ObjComites.Bandera = 2
            ObjComites.Busca_dos()
            srep = ObjComites.Responsable

        End If
        'SI ES DIRECTO DE COMITE
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then
            txthpertenece.Text = ObjPrograma.ID_Comite
            ObjComites.ID_Comite = ObjPrograma.ID_Comite
            ObjComites.ID_CT = ObjPrograma.ID_CT
            ObjComites.ID_SC = ObjPrograma.ID_SC
            ObjComites.ID_GT = ObjPrograma.ID_Grupo

            ObjComites.Bandera = 1
            ObjComites.Busca_uno()
            srep = ObjComites.Responsable
        End If

        If ObjPrograma.Tipo_Pro = 1 Or ObjPrograma.Tipo_Pro = 2 Then
            chkhnormal.Checked = True
        Else
            chkhnormal.Checked = False
        End If

        If ObjPrograma.Tipo_Pro = 3 Then
            chkhmodific.Checked = True
        Else
            chkhmodific.Checked = False
        End If
    End Sub

    Private Sub chkhbasado_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkhbasado.CheckedChanged
        If chkhbasado.Checked = True Then
            txthbasado.Visible = True
            txtharmonizada.Visible = False
        Else
            txthbasado.Visible = False
            txtharmonizada.Visible = True
        End If
    End Sub

    Private Sub chkharmonizada_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkharmonizada.CheckedChanged
        If chkharmonizada.Checked Then
            txthbasado.Visible = False
            txtharmonizada.Visible = True
        Else
            txthbasado.Visible = True
            txtharmonizada.Visible = False
        End If
    End Sub

    Private Sub optApDtNo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optApDtNo.CheckedChanged
        txtfcargaDtFinal.Text = ""
        txtminuta.Text = ""
        fcarga_minuta.Text = ""
        txtadjDtf.Text = ""
    End Sub

    Private Sub cmdProyectoFinal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdProyectoFinal.Click
        REM txtProyecoFinal
        Dim dlgOpen As New OpenFileDialog
        dlgOpen.ShowDialog()
        txtProyectoFinal.Text = dlgOpen.FileName
        dlgOpen.RestoreDirectory = True
        dlgOpen = Nothing
    End Sub

    Private Sub txtPaginasNorma_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPaginasNorma.KeyPress
        If Not IsNumeric(e.KeyChar) And e.KeyChar <> "" Then
            e.Handled = True
            MsgBox("Solo se permiten valores numericos")
        End If
    End Sub
End Class

