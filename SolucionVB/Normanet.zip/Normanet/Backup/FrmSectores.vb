Imports System.Windows.Forms
Imports System.Data.SqlClient

Public Class FrmSectores
    Inherits System.Windows.Forms.Form
    Dim ValEditar, iEditar As Integer
    Public bandInactivo As Integer
    Dim objsector As New ClsSector.ClsSector("principal", gUsuario, gPasswordSql)

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents GpBoxLectura As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmbSectores As System.Windows.Forms.ComboBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents Borrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents GpBoxAgrega As System.Windows.Forms.GroupBox
    Friend WithEvents TxtDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblactivo As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmSectores))
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.Borrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.GpBoxLectura = New System.Windows.Forms.GroupBox
        Me.CmbSectores = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.GpBoxAgrega = New System.Windows.Forms.GroupBox
        Me.TxtDescripcion = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblactivo = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.GpBoxLectura.SuspendLayout()
        Me.GpBoxAgrega.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.Borrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 159)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(406, 62)
        Me.tlbBotonera.TabIndex = 46
        Me.tlbBotonera.TabStop = True
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 3
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 2
        Me.cmdGuardar.Text = "Guardar"
        '
        'Borrar
        '
        Me.Borrar.ImageIndex = 5
        Me.Borrar.Text = "Inactivar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 4
        Me.cmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'GpBoxLectura
        '
        Me.GpBoxLectura.Controls.Add(Me.CmbSectores)
        Me.GpBoxLectura.Controls.Add(Me.Label1)
        Me.GpBoxLectura.Location = New System.Drawing.Point(8, 8)
        Me.GpBoxLectura.Name = "GpBoxLectura"
        Me.GpBoxLectura.Size = New System.Drawing.Size(392, 136)
        Me.GpBoxLectura.TabIndex = 47
        Me.GpBoxLectura.TabStop = False
        Me.GpBoxLectura.Text = "Sectores"
        '
        'CmbSectores
        '
        Me.CmbSectores.Location = New System.Drawing.Point(80, 24)
        Me.CmbSectores.Name = "CmbSectores"
        Me.CmbSectores.Size = New System.Drawing.Size(296, 22)
        Me.CmbSectores.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Descripci�n:"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'GpBoxAgrega
        '
        Me.GpBoxAgrega.Controls.Add(Me.Label3)
        Me.GpBoxAgrega.Controls.Add(Me.TxtDescripcion)
        Me.GpBoxAgrega.Controls.Add(Me.Label2)
        Me.GpBoxAgrega.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GpBoxAgrega.Location = New System.Drawing.Point(8, 8)
        Me.GpBoxAgrega.Name = "GpBoxAgrega"
        Me.GpBoxAgrega.Size = New System.Drawing.Size(392, 136)
        Me.GpBoxAgrega.TabIndex = 1
        Me.GpBoxAgrega.TabStop = False
        Me.GpBoxAgrega.Text = "Sectores"
        '
        'TxtDescripcion
        '
        Me.TxtDescripcion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDescripcion.Location = New System.Drawing.Point(80, 24)
        Me.TxtDescripcion.Name = "TxtDescripcion"
        Me.TxtDescripcion.Size = New System.Drawing.Size(296, 20)
        Me.TxtDescripcion.TabIndex = 0
        Me.TxtDescripcion.Text = ""
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(80, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 5
        '
        'lblactivo
        '
        Me.lblactivo.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblactivo.Location = New System.Drawing.Point(152, 96)
        Me.lblactivo.Name = "lblactivo"
        Me.lblactivo.Size = New System.Drawing.Size(240, 40)
        Me.lblactivo.TabIndex = 57
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 23)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Descripci�n:"
        '
        'FrmSectores
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(406, 221)
        Me.Controls.Add(Me.lblactivo)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.GpBoxAgrega)
        Me.Controls.Add(Me.GpBoxLectura)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "FrmSectores"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Sectores"
        Me.GpBoxLectura.ResumeLayout(False)
        Me.GpBoxAgrega.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

    Private Sub packet(ByVal bandera As Integer)
        With tlbBotonera
            If bandera = 1 Then
                Activos(.Buttons(1), .Buttons(2))
                Inactivos(TxtDescripcion, .Buttons(3), .Buttons(4))
            ElseIf bandera = 2 Then
                Inactivos(.Buttons(1), .Buttons(2))
                Activos(TxtDescripcion, .Buttons(3), .Buttons(4))
            End If
        End With

    End Sub

    Private Sub Carga_Combo()
        Dim oTablaST As DataTable
        Dim RegST As DataRow
        objsector.Bandera = 1
        objsector.ListaCombo(CmbSectores)
    End Sub

    Private Sub Guardar()
        Cursor.Current = Cursors.WaitCursor
        Dim iregistros As Integer
        If iEditar = 1 Then
            If Len(ValEditar) > 0 Then
                objsector.Bandera = 2
                objsector.ID_Sector = ValEditar
                objsector.Descripcion = (TxtDescripcion.Text)
                Try
                    objsector.Actualizar()
                Catch ex As Exception
                    Cursor.Current = Cursors.Default
                End Try
            End If
        Else
            objsector.Bandera = 1
            objsector.Descripcion = TxtDescripcion.Text
            Try
                objsector.Insertar()
            Catch ex As Exception
                Cursor.Current = Cursors.Default
            End Try
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " Forms - FrmSectores, Metodos y Procesos"

    Private Sub FrmSectores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call packet(1)
        GpBoxAgrega.Visible = False
        GpBoxLectura.Visible = True

        Call Carga_Combo()
        TxtDescripcion.CausesValidation = True

    End Sub

#End Region

#Region " ToolBar - tlbBotonera, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1
                packet(2)
                GpBoxAgrega.Visible = True
                GpBoxLectura.Visible = False
                iEditar = 0
                TxtDescripcion.Text = ""
            Case 2
                If CmbSectores.ValueMember <> "" Then
                    packet(2)
                    GpBoxAgrega.Visible = True
                    GpBoxLectura.Visible = False
                    ValEditar = CmbSectores.SelectedValue
                    TxtDescripcion.Text = CmbSectores.Text
                    iEditar = 1
                End If
            Case 3
                packet(1)
                GpBoxAgrega.Visible = False
                GpBoxLectura.Visible = True
                iEditar = 0
                TxtDescripcion.Text = ""
            Case 4
                If TxtDescripcion.Text = "" Then
                    MsgBox("Debes escribir el sector")
                    Exit Sub
                End If
                Call Guardar()
                packet(1)
                GpBoxAgrega.Visible = False
                GpBoxLectura.Visible = True
                iEditar = 0
                TxtDescripcion.Text = ""
                Call Carga_Combo()
            Case 5 'borrar
                If lblactivo.Text = "Activo" Then
                    If MsgBox("�Deseas Inactivar el sector?", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        bandInactivo = 1
                    Else
                        Exit Sub
                    End If
                Else
                    If MsgBox("�Deseas Activar el sector?", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        bandInactivo = 0
                    Else
                        Exit Sub
                    End If
                End If
                objsector.Inactivo = bandInactivo
                objsector.Bandera = 2
                objsector.Actualizar()
                Dim Sectores As New FrmSectores
                Sectores.MdiParent = Me.MdiParent
                Me.Dispose()
                sectores.show()
            Case 7
                Me.Dispose()
        End Select
    End Sub

    ''Private Sub tlbBotonera_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles tlbBotonera.Validating
    ''    If GpBoxAgrega.Visible = True Then
    ''        Dim itam As Integer
    ''        itam = Len(TxtDescripcion.Text)
    ''        If itam = 0 Then
    ''            ErrorProvider1.SetError(Me.TxtDescripcion, "Debes escribir el Sector")
    ''            tlbBotonera.Buttons(4).Enabled = False
    ''            Return
    ''        Else
    ''            If itam > 25 Then
    ''                ErrorProvider1.SetError(Me.TxtDescripcion, "Debes escribir un nombre menor a 15 caracteres")
    ''                tlbBotonera.Buttons(4).Enabled = False
    ''                Return
    ''            Else
    ''                ErrorProvider1.SetError(Me.TxtDescripcion, "")
    ''                tlbBotonera.Buttons(4).Enabled = True
    ''            End If
    ''        End If
    ''    End If

    ''End Sub

#End Region

#Region "TextBox - TxtDescripcion, Metodos y Procesos"

    ''Private Sub TxtDescripcion_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtDescripcion.Validating
    ''    If GpBoxAgrega.Visible = True Then
    ''        Dim itam As Integer
    ''        itam = Len(TxtDescripcion.Text)
    ''        If itam = 0 Then
    ''            ErrorProvider1.SetError(Me.TxtDescripcion, "Debes escribir el Sector")
    ''            tlbBotonera.Buttons(4).Enabled = False
    ''            Return
    ''        Else
    ''            If itam > 25 Then
    ''                ErrorProvider1.SetError(Me.TxtDescripcion, "Debes escribir un Sector menor a 15 caracteres")
    ''                tlbBotonera.Buttons(4).Enabled = False
    ''                Return
    ''            Else
    ''                ErrorProvider1.SetError(Me.TxtDescripcion, "")
    ''                tlbBotonera.Buttons(4).Enabled = True
    ''            End If
    ''        End If
    ''    End If
    ''End Sub


#End Region

    Private Sub CmbSectores_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbSectores.SelectedIndexChanged
        objsector.ID_Sector = CmbSectores.SelectedValue
        objsector.Buscar()
        If objsector.Inactivo = 0 Then
            lblactivo.Text = "Activo"
            tlbBotonera.Buttons.Item(5).Text = "Inactivar"
        Else
            lblactivo.Text = "Inactivo"
            tlbBotonera.Buttons.Item(5).Text = "Activar"
        End If
    End Sub

    Private Sub TxtDescripcion_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtDescripcion.TextChanged

    End Sub
End Class
