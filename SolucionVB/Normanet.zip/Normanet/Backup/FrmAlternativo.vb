Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.IO

Public Class FrmAlternativo
    Inherits System.Windows.Forms.Form
    Dim objconexion As New clsConexion.cIsConexion
    Dim cn As New SqlConnection
    Dim objComentarios As New clsComentarios.C_Comentarios("Principal", gUsuario, gPasswordSql)

    Dim iCaso As Integer
    Dim dvPNN As DataView
    Dim objComites As New clsComites.clsComites("Principal", gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Private clsProc As New ClsProcedimientoAlternativo.P_Procedimiento_Alternativo(0, gUsuario, gPasswordSql)
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Dim sTipoProceso As String
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim ObjDirectorio As New ClsDirectorio.C_Directorio(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    ' defino variable del tipo DataRow
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim DtCom As DataTable
    Dim Com As DataRow
    Dim RegGT As DataRow
    Dim nodo1 As New TreeNode
    Dim nodo2 As New TreeNode
    Dim array_texto As Array
    Dim srefP As String
    Dim splan As String
    Dim stema As Integer

    'Variables globales mmendoza
    Dim myStream As String
    Dim SDocumento As String
    Public rutaOriginal As String
    Private objiniarray As New clsIniarray.ClsIniArray
    Private clsDoctosTemas As New ClsDocumentos_Prog_Trab.P_Prog_Trab_Documentos(0, gUsuario, gPasswordSql)
    Private clsCopia As New ClsCopiaArchivos.ClsCopiaArchivos

    Private tipoCom As TiposComentario

    Private Enum TiposComentario As Integer
        Normal = 0
        Matriz = 1
        Nulo = 3
    End Enum


#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents txtTema As System.Windows.Forms.TextBox
    Friend WithEvents txtPNN As System.Windows.Forms.TextBox
    Friend WithEvents tvPNN As System.Windows.Forms.TreeView
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents lblSB As System.Windows.Forms.Label
    Friend WithEvents txtIdComentarios As System.Windows.Forms.TextBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents gpbDatosPersonales As System.Windows.Forms.GroupBox
    Friend WithEvents gbpComentarios As System.Windows.Forms.GroupBox
    Friend WithEvents txtPropuestasCambios As System.Windows.Forms.TextBox
    Friend WithEvents txtComentario As System.Windows.Forms.TextBox
    Friend WithEvents txtParrafo As System.Windows.Forms.TextBox
    Friend WithEvents txtCapituloInciso As System.Windows.Forms.TextBox
    Friend WithEvents cboTipoComentario As System.Windows.Forms.ComboBox
    Friend WithEvents lblTipoComentario As System.Windows.Forms.Label
    Friend WithEvents lblCapituloInciso As System.Windows.Forms.Label
    Friend WithEvents lblParrafo As System.Windows.Forms.Label
    Friend WithEvents lblComentario As System.Windows.Forms.Label
    Friend WithEvents lblPropuestasCambios As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtDomicilio As System.Windows.Forms.TextBox
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents lblNombre As System.Windows.Forms.Label
    Friend WithEvents lblEmpresa As System.Windows.Forms.Label
    Friend WithEvents lblDomicilio As System.Windows.Forms.Label
    Friend WithEvents lblTelefono As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtkFecPublicacionConsulta As System.Windows.Forms.DateTimePicker
    Friend WithEvents cboClasificacion As System.Windows.Forms.ComboBox
    Friend WithEvents lblPNN As System.Windows.Forms.Label
    Friend WithEvents txtFecLimiteComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecPublicacionConsulta As System.Windows.Forms.TextBox
    Friend WithEvents lblClasificacion As System.Windows.Forms.Label
    Friend WithEvents cboPNN As System.Windows.Forms.ComboBox
    Friend WithEvents lblFecPublicacionConsulta As System.Windows.Forms.Label
    Friend WithEvents lblFecLimiteComentarios As System.Windows.Forms.Label
    Friend WithEvents dtkFecLimiteComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton8 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents grpTipoCaptura As System.Windows.Forms.GroupBox
    Friend WithEvents optDirectorio As System.Windows.Forms.RadioButton
    Friend WithEvents optManual As System.Windows.Forms.RadioButton
    Friend WithEvents cboNombre As System.Windows.Forms.ComboBox
    Friend WithEvents tpMatrizCom As System.Windows.Forms.TabPage
    Friend WithEvents gbxMatriz As System.Windows.Forms.GroupBox
    Friend WithEvents nudComTec As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents nudComEdit As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtMatrizDoc As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdMatxDoc As System.Windows.Forms.Button
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents cmdVerMatriz As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmAlternativo))
        Me.txtTema = New System.Windows.Forms.TextBox
        Me.txtPNN = New System.Windows.Forms.TextBox
        Me.tvPNN = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.lblSB = New System.Windows.Forms.Label
        Me.txtIdComentarios = New System.Windows.Forms.TextBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.gpbDatosPersonales = New System.Windows.Forms.GroupBox
        Me.cboNombre = New System.Windows.Forms.ComboBox
        Me.gbpComentarios = New System.Windows.Forms.GroupBox
        Me.txtPropuestasCambios = New System.Windows.Forms.TextBox
        Me.txtComentario = New System.Windows.Forms.TextBox
        Me.txtParrafo = New System.Windows.Forms.TextBox
        Me.txtCapituloInciso = New System.Windows.Forms.TextBox
        Me.cboTipoComentario = New System.Windows.Forms.ComboBox
        Me.lblTipoComentario = New System.Windows.Forms.Label
        Me.lblCapituloInciso = New System.Windows.Forms.Label
        Me.lblParrafo = New System.Windows.Forms.Label
        Me.lblComentario = New System.Windows.Forms.Label
        Me.lblPropuestasCambios = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtTelefono = New System.Windows.Forms.TextBox
        Me.txtDomicilio = New System.Windows.Forms.TextBox
        Me.txtEmpresa = New System.Windows.Forms.TextBox
        Me.txtNombre = New System.Windows.Forms.TextBox
        Me.lblNombre = New System.Windows.Forms.Label
        Me.lblEmpresa = New System.Windows.Forms.Label
        Me.lblDomicilio = New System.Windows.Forms.Label
        Me.lblTelefono = New System.Windows.Forms.Label
        Me.lblFax = New System.Windows.Forms.Label
        Me.lblEmail = New System.Windows.Forms.Label
        Me.grpTipoCaptura = New System.Windows.Forms.GroupBox
        Me.optDirectorio = New System.Windows.Forms.RadioButton
        Me.optManual = New System.Windows.Forms.RadioButton
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dtkFecPublicacionConsulta = New System.Windows.Forms.DateTimePicker
        Me.cboClasificacion = New System.Windows.Forms.ComboBox
        Me.lblPNN = New System.Windows.Forms.Label
        Me.txtFecLimiteComentarios = New System.Windows.Forms.TextBox
        Me.txtFecPublicacionConsulta = New System.Windows.Forms.TextBox
        Me.lblClasificacion = New System.Windows.Forms.Label
        Me.cboPNN = New System.Windows.Forms.ComboBox
        Me.lblFecPublicacionConsulta = New System.Windows.Forms.Label
        Me.lblFecLimiteComentarios = New System.Windows.Forms.Label
        Me.dtkFecLimiteComentarios = New System.Windows.Forms.DateTimePicker
        Me.tpMatrizCom = New System.Windows.Forms.TabPage
        Me.gbxMatriz = New System.Windows.Forms.GroupBox
        Me.nudComTec = New System.Windows.Forms.NumericUpDown
        Me.Label2 = New System.Windows.Forms.Label
        Me.nudComEdit = New System.Windows.Forms.NumericUpDown
        Me.txtMatrizDoc = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmdMatxDoc = New System.Windows.Forms.Button
        Me.Label80 = New System.Windows.Forms.Label
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdVerMatriz = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton8 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gpbDatosPersonales.SuspendLayout()
        Me.gbpComentarios.SuspendLayout()
        Me.grpTipoCaptura.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tpMatrizCom.SuspendLayout()
        Me.gbxMatriz.SuspendLayout()
        CType(Me.nudComTec, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudComEdit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtTema
        '
        Me.txtTema.Location = New System.Drawing.Point(64, 353)
        Me.txtTema.Name = "txtTema"
        Me.txtTema.Size = New System.Drawing.Size(48, 20)
        Me.txtTema.TabIndex = 61
        Me.txtTema.Text = ""
        Me.txtTema.Visible = False
        '
        'txtPNN
        '
        Me.txtPNN.Location = New System.Drawing.Point(10, 353)
        Me.txtPNN.Name = "txtPNN"
        Me.txtPNN.Size = New System.Drawing.Size(46, 20)
        Me.txtPNN.TabIndex = 60
        Me.txtPNN.Text = ""
        Me.txtPNN.Visible = False
        '
        'tvPNN
        '
        Me.tvPNN.ImageList = Me.imgListTreeView
        Me.tvPNN.Location = New System.Drawing.Point(4, 7)
        Me.tvPNN.Name = "tvPNN"
        Me.tvPNN.Size = New System.Drawing.Size(193, 341)
        Me.tvPNN.TabIndex = 59
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'lblSB
        '
        Me.lblSB.Location = New System.Drawing.Point(3, 382)
        Me.lblSB.Name = "lblSB"
        Me.lblSB.Size = New System.Drawing.Size(191, 16)
        Me.lblSB.TabIndex = 63
        Me.lblSB.Visible = False
        '
        'txtIdComentarios
        '
        Me.txtIdComentarios.Location = New System.Drawing.Point(115, 353)
        Me.txtIdComentarios.Name = "txtIdComentarios"
        Me.txtIdComentarios.Size = New System.Drawing.Size(48, 20)
        Me.txtIdComentarios.TabIndex = 62
        Me.txtIdComentarios.Text = ""
        Me.txtIdComentarios.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.tpMatrizCom)
        Me.TabControl1.Location = New System.Drawing.Point(202, 4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(584, 448)
        Me.TabControl1.TabIndex = 58
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.gpbDatosPersonales)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(576, 422)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos Personales/Comentarios"
        '
        'gpbDatosPersonales
        '
        Me.gpbDatosPersonales.Controls.Add(Me.cboNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.gbpComentarios)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmail)
        Me.gpbDatosPersonales.Controls.Add(Me.txtFax)
        Me.gpbDatosPersonales.Controls.Add(Me.txtTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.txtDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.txtNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.lblDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.lblTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.lblFax)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmail)
        Me.gpbDatosPersonales.Controls.Add(Me.grpTipoCaptura)
        Me.gpbDatosPersonales.Location = New System.Drawing.Point(5, 4)
        Me.gpbDatosPersonales.Name = "gpbDatosPersonales"
        Me.gpbDatosPersonales.Size = New System.Drawing.Size(564, 404)
        Me.gpbDatosPersonales.TabIndex = 3
        Me.gpbDatosPersonales.TabStop = False
        '
        'cboNombre
        '
        Me.cboNombre.Enabled = False
        Me.cboNombre.Location = New System.Drawing.Point(72, 8)
        Me.cboNombre.Name = "cboNombre"
        Me.cboNombre.Size = New System.Drawing.Size(264, 21)
        Me.cboNombre.TabIndex = 66
        Me.cboNombre.Visible = False
        '
        'gbpComentarios
        '
        Me.gbpComentarios.Controls.Add(Me.txtPropuestasCambios)
        Me.gbpComentarios.Controls.Add(Me.txtComentario)
        Me.gbpComentarios.Controls.Add(Me.txtParrafo)
        Me.gbpComentarios.Controls.Add(Me.txtCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.cboTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.lblParrafo)
        Me.gbpComentarios.Controls.Add(Me.lblComentario)
        Me.gbpComentarios.Controls.Add(Me.lblPropuestasCambios)
        Me.gbpComentarios.Location = New System.Drawing.Point(8, 176)
        Me.gbpComentarios.Name = "gbpComentarios"
        Me.gbpComentarios.Size = New System.Drawing.Size(440, 212)
        Me.gbpComentarios.TabIndex = 19
        Me.gbpComentarios.TabStop = False
        '
        'txtPropuestasCambios
        '
        Me.txtPropuestasCambios.Location = New System.Drawing.Point(160, 149)
        Me.txtPropuestasCambios.Multiline = True
        Me.txtPropuestasCambios.Name = "txtPropuestasCambios"
        Me.txtPropuestasCambios.Size = New System.Drawing.Size(272, 56)
        Me.txtPropuestasCambios.TabIndex = 60
        Me.txtPropuestasCambios.Text = "txtPropuestasCambios"
        '
        'txtComentario
        '
        Me.txtComentario.Location = New System.Drawing.Point(160, 94)
        Me.txtComentario.Multiline = True
        Me.txtComentario.Name = "txtComentario"
        Me.txtComentario.Size = New System.Drawing.Size(272, 48)
        Me.txtComentario.TabIndex = 59
        Me.txtComentario.Text = "txtComentario"
        '
        'txtParrafo
        '
        Me.txtParrafo.Location = New System.Drawing.Point(160, 66)
        Me.txtParrafo.Name = "txtParrafo"
        Me.txtParrafo.TabIndex = 58
        Me.txtParrafo.Text = "txtParrafo"
        '
        'txtCapituloInciso
        '
        Me.txtCapituloInciso.Location = New System.Drawing.Point(160, 42)
        Me.txtCapituloInciso.Name = "txtCapituloInciso"
        Me.txtCapituloInciso.TabIndex = 57
        Me.txtCapituloInciso.Text = "txtCapituloInciso"
        '
        'cboTipoComentario
        '
        Me.cboTipoComentario.Location = New System.Drawing.Point(160, 16)
        Me.cboTipoComentario.Name = "cboTipoComentario"
        Me.cboTipoComentario.Size = New System.Drawing.Size(260, 21)
        Me.cboTipoComentario.TabIndex = 56
        Me.cboTipoComentario.Text = "cboTipoComentario"
        '
        'lblTipoComentario
        '
        Me.lblTipoComentario.AutoSize = True
        Me.lblTipoComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipoComentario.Location = New System.Drawing.Point(16, 16)
        Me.lblTipoComentario.Name = "lblTipoComentario"
        Me.lblTipoComentario.Size = New System.Drawing.Size(94, 16)
        Me.lblTipoComentario.TabIndex = 52
        Me.lblTipoComentario.Text = "Tipo Comentario"
        '
        'lblCapituloInciso
        '
        Me.lblCapituloInciso.AutoSize = True
        Me.lblCapituloInciso.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCapituloInciso.Location = New System.Drawing.Point(16, 42)
        Me.lblCapituloInciso.Name = "lblCapituloInciso"
        Me.lblCapituloInciso.Size = New System.Drawing.Size(85, 16)
        Me.lblCapituloInciso.TabIndex = 51
        Me.lblCapituloInciso.Text = "Cap�tulo Inciso"
        '
        'lblParrafo
        '
        Me.lblParrafo.AutoSize = True
        Me.lblParrafo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParrafo.Location = New System.Drawing.Point(16, 66)
        Me.lblParrafo.Name = "lblParrafo"
        Me.lblParrafo.Size = New System.Drawing.Size(114, 16)
        Me.lblParrafo.TabIndex = 53
        Me.lblParrafo.Text = "P�rrafo/Tabla/Figura"
        '
        'lblComentario
        '
        Me.lblComentario.AutoSize = True
        Me.lblComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComentario.Location = New System.Drawing.Point(16, 94)
        Me.lblComentario.Name = "lblComentario"
        Me.lblComentario.Size = New System.Drawing.Size(67, 16)
        Me.lblComentario.TabIndex = 55
        Me.lblComentario.Text = "Comentario"
        '
        'lblPropuestasCambios
        '
        Me.lblPropuestasCambios.AutoSize = True
        Me.lblPropuestasCambios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPropuestasCambios.Location = New System.Drawing.Point(16, 149)
        Me.lblPropuestasCambios.Name = "lblPropuestasCambios"
        Me.lblPropuestasCambios.Size = New System.Drawing.Size(133, 16)
        Me.lblPropuestasCambios.TabIndex = 54
        Me.lblPropuestasCambios.Text = "Propuestas de Cambios"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(399, 73)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(160, 20)
        Me.txtEmail.TabIndex = 18
        Me.txtEmail.Text = "txtEmail"
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(399, 41)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(160, 20)
        Me.txtFax.TabIndex = 17
        Me.txtFax.Text = "txtFax"
        '
        'txtTelefono
        '
        Me.txtTelefono.Location = New System.Drawing.Point(399, 9)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(160, 20)
        Me.txtTelefono.TabIndex = 16
        Me.txtTelefono.Text = "txtTelefono"
        '
        'txtDomicilio
        '
        Me.txtDomicilio.Location = New System.Drawing.Point(71, 73)
        Me.txtDomicilio.Multiline = True
        Me.txtDomicilio.Name = "txtDomicilio"
        Me.txtDomicilio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDomicilio.Size = New System.Drawing.Size(264, 87)
        Me.txtDomicilio.TabIndex = 15
        Me.txtDomicilio.Text = "txtDomicilio"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Location = New System.Drawing.Point(71, 41)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(264, 20)
        Me.txtEmpresa.TabIndex = 14
        Me.txtEmpresa.Text = "txtEmpresa"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(71, 9)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(264, 20)
        Me.txtNombre.TabIndex = 13
        Me.txtNombre.Text = "txtNombre"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombre.Location = New System.Drawing.Point(16, 13)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(47, 16)
        Me.lblNombre.TabIndex = 12
        Me.lblNombre.Text = "Nombre"
        '
        'lblEmpresa
        '
        Me.lblEmpresa.AutoSize = True
        Me.lblEmpresa.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpresa.Location = New System.Drawing.Point(11, 42)
        Me.lblEmpresa.Name = "lblEmpresa"
        Me.lblEmpresa.Size = New System.Drawing.Size(52, 16)
        Me.lblEmpresa.TabIndex = 12
        Me.lblEmpresa.Text = "Empresa"
        '
        'lblDomicilio
        '
        Me.lblDomicilio.AutoSize = True
        Me.lblDomicilio.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDomicilio.Location = New System.Drawing.Point(11, 73)
        Me.lblDomicilio.Name = "lblDomicilio"
        Me.lblDomicilio.Size = New System.Drawing.Size(55, 16)
        Me.lblDomicilio.TabIndex = 12
        Me.lblDomicilio.Text = "Domicilio"
        '
        'lblTelefono
        '
        Me.lblTelefono.AutoSize = True
        Me.lblTelefono.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTelefono.Location = New System.Drawing.Point(343, 9)
        Me.lblTelefono.Name = "lblTelefono"
        Me.lblTelefono.Size = New System.Drawing.Size(51, 16)
        Me.lblTelefono.TabIndex = 12
        Me.lblTelefono.Text = "Tel�fono"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFax.Location = New System.Drawing.Point(367, 41)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(24, 16)
        Me.lblFax.TabIndex = 12
        Me.lblFax.Text = "Fax"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(359, 73)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(34, 16)
        Me.lblEmail.TabIndex = 12
        Me.lblEmail.Text = "Email"
        '
        'grpTipoCaptura
        '
        Me.grpTipoCaptura.Controls.Add(Me.optDirectorio)
        Me.grpTipoCaptura.Controls.Add(Me.optManual)
        Me.grpTipoCaptura.Enabled = False
        Me.grpTipoCaptura.Location = New System.Drawing.Point(352, 112)
        Me.grpTipoCaptura.Name = "grpTipoCaptura"
        Me.grpTipoCaptura.Size = New System.Drawing.Size(200, 48)
        Me.grpTipoCaptura.TabIndex = 65
        Me.grpTipoCaptura.TabStop = False
        Me.grpTipoCaptura.Text = "Tipo de Captura"
        '
        'optDirectorio
        '
        Me.optDirectorio.Location = New System.Drawing.Point(80, 16)
        Me.optDirectorio.Name = "optDirectorio"
        Me.optDirectorio.TabIndex = 1
        Me.optDirectorio.Text = "Directorio"
        '
        'optManual
        '
        Me.optManual.Checked = True
        Me.optManual.Location = New System.Drawing.Point(8, 16)
        Me.optManual.Name = "optManual"
        Me.optManual.TabIndex = 0
        Me.optManual.TabStop = True
        Me.optManual.Text = "Manual"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(576, 422)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Proc. Alternativo       "
        Me.TabPage1.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtkFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.cboClasificacion)
        Me.GroupBox1.Controls.Add(Me.lblPNN)
        Me.GroupBox1.Controls.Add(Me.txtFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.txtFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblClasificacion)
        Me.GroupBox1.Controls.Add(Me.cboPNN)
        Me.GroupBox1.Controls.Add(Me.lblFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.dtkFecLimiteComentarios)
        Me.GroupBox1.Location = New System.Drawing.Point(24, 104)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(496, 136)
        Me.GroupBox1.TabIndex = 53
        Me.GroupBox1.TabStop = False
        '
        'dtkFecPublicacionConsulta
        '
        Me.dtkFecPublicacionConsulta.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecPublicacionConsulta.Location = New System.Drawing.Point(304, 56)
        Me.dtkFecPublicacionConsulta.Name = "dtkFecPublicacionConsulta"
        Me.dtkFecPublicacionConsulta.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecPublicacionConsulta.TabIndex = 31
        Me.dtkFecPublicacionConsulta.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecPublicacionConsulta.Visible = False
        '
        'cboClasificacion
        '
        Me.cboClasificacion.Location = New System.Drawing.Point(192, 16)
        Me.cboClasificacion.Name = "cboClasificacion"
        Me.cboClasificacion.Size = New System.Drawing.Size(260, 21)
        Me.cboClasificacion.TabIndex = 30
        Me.cboClasificacion.Text = "cboClasificacion"
        Me.cboClasificacion.Visible = False
        '
        'lblPNN
        '
        Me.lblPNN.AutoSize = True
        Me.lblPNN.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPNN.Location = New System.Drawing.Point(8, 16)
        Me.lblPNN.Name = "lblPNN"
        Me.lblPNN.Size = New System.Drawing.Size(28, 16)
        Me.lblPNN.TabIndex = 29
        Me.lblPNN.Text = "PNN"
        Me.lblPNN.Visible = False
        '
        'txtFecLimiteComentarios
        '
        Me.txtFecLimiteComentarios.Location = New System.Drawing.Point(192, 88)
        Me.txtFecLimiteComentarios.Name = "txtFecLimiteComentarios"
        Me.txtFecLimiteComentarios.TabIndex = 26
        Me.txtFecLimiteComentarios.Text = "txtFecLimiteComentarios"
        '
        'txtFecPublicacionConsulta
        '
        Me.txtFecPublicacionConsulta.Location = New System.Drawing.Point(192, 56)
        Me.txtFecPublicacionConsulta.Name = "txtFecPublicacionConsulta"
        Me.txtFecPublicacionConsulta.TabIndex = 25
        Me.txtFecPublicacionConsulta.Text = "FecPublicacionConsulta"
        '
        'lblClasificacion
        '
        Me.lblClasificacion.AutoSize = True
        Me.lblClasificacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacion.Location = New System.Drawing.Point(8, 24)
        Me.lblClasificacion.Name = "lblClasificacion"
        Me.lblClasificacion.Size = New System.Drawing.Size(74, 16)
        Me.lblClasificacion.TabIndex = 20
        Me.lblClasificacion.Text = "Clasificacion"
        Me.lblClasificacion.Visible = False
        '
        'cboPNN
        '
        Me.cboPNN.Location = New System.Drawing.Point(192, 16)
        Me.cboPNN.Name = "cboPNN"
        Me.cboPNN.Size = New System.Drawing.Size(260, 21)
        Me.cboPNN.TabIndex = 24
        Me.cboPNN.Text = "cboPNN"
        Me.cboPNN.Visible = False
        '
        'lblFecPublicacionConsulta
        '
        Me.lblFecPublicacionConsulta.AutoSize = True
        Me.lblFecPublicacionConsulta.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecPublicacionConsulta.Location = New System.Drawing.Point(8, 64)
        Me.lblFecPublicacionConsulta.Name = "lblFecPublicacionConsulta"
        Me.lblFecPublicacionConsulta.Size = New System.Drawing.Size(175, 16)
        Me.lblFecPublicacionConsulta.TabIndex = 19
        Me.lblFecPublicacionConsulta.Text = "Fecha de Inicio de Comentarios"
        '
        'lblFecLimiteComentarios
        '
        Me.lblFecLimiteComentarios.AutoSize = True
        Me.lblFecLimiteComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecLimiteComentarios.Location = New System.Drawing.Point(8, 96)
        Me.lblFecLimiteComentarios.Name = "lblFecLimiteComentarios"
        Me.lblFecLimiteComentarios.Size = New System.Drawing.Size(146, 16)
        Me.lblFecLimiteComentarios.TabIndex = 21
        Me.lblFecLimiteComentarios.Text = "Fecha Fin de Comentarios"
        '
        'dtkFecLimiteComentarios
        '
        Me.dtkFecLimiteComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecLimiteComentarios.Location = New System.Drawing.Point(304, 88)
        Me.dtkFecLimiteComentarios.Name = "dtkFecLimiteComentarios"
        Me.dtkFecLimiteComentarios.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecLimiteComentarios.TabIndex = 31
        Me.dtkFecLimiteComentarios.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecLimiteComentarios.Visible = False
        '
        'tpMatrizCom
        '
        Me.tpMatrizCom.Controls.Add(Me.gbxMatriz)
        Me.tpMatrizCom.Location = New System.Drawing.Point(4, 22)
        Me.tpMatrizCom.Name = "tpMatrizCom"
        Me.tpMatrizCom.Size = New System.Drawing.Size(576, 422)
        Me.tpMatrizCom.TabIndex = 2
        Me.tpMatrizCom.Text = "Matriz de Cometarios"
        '
        'gbxMatriz
        '
        Me.gbxMatriz.Controls.Add(Me.nudComTec)
        Me.gbxMatriz.Controls.Add(Me.Label2)
        Me.gbxMatriz.Controls.Add(Me.nudComEdit)
        Me.gbxMatriz.Controls.Add(Me.txtMatrizDoc)
        Me.gbxMatriz.Controls.Add(Me.Label1)
        Me.gbxMatriz.Controls.Add(Me.cmdMatxDoc)
        Me.gbxMatriz.Controls.Add(Me.Label80)
        Me.gbxMatriz.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxMatriz.Location = New System.Drawing.Point(24, 16)
        Me.gbxMatriz.Name = "gbxMatriz"
        Me.gbxMatriz.Size = New System.Drawing.Size(504, 128)
        Me.gbxMatriz.TabIndex = 168
        Me.gbxMatriz.TabStop = False
        '
        'nudComTec
        '
        Me.nudComTec.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudComTec.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.nudComTec.Location = New System.Drawing.Point(424, 29)
        Me.nudComTec.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudComTec.Name = "nudComTec"
        Me.nudComTec.Size = New System.Drawing.Size(64, 20)
        Me.nudComTec.TabIndex = 167
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(160, 16)
        Me.Label2.TabIndex = 165
        Me.Label2.Text = "No. Comentarios Editoriales:"
        '
        'nudComEdit
        '
        Me.nudComEdit.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudComEdit.Location = New System.Drawing.Point(184, 28)
        Me.nudComEdit.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudComEdit.Name = "nudComEdit"
        Me.nudComEdit.Size = New System.Drawing.Size(64, 20)
        Me.nudComEdit.TabIndex = 166
        '
        'txtMatrizDoc
        '
        Me.txtMatrizDoc.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMatrizDoc.Location = New System.Drawing.Point(208, 80)
        Me.txtMatrizDoc.Name = "txtMatrizDoc"
        Me.txtMatrizDoc.ReadOnly = True
        Me.txtMatrizDoc.Size = New System.Drawing.Size(224, 20)
        Me.txtMatrizDoc.TabIndex = 161
        Me.txtMatrizDoc.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(264, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 16)
        Me.Label1.TabIndex = 164
        Me.Label1.Text = "No. Comentarios T�cnicos:"
        '
        'cmdMatxDoc
        '
        Me.cmdMatxDoc.Location = New System.Drawing.Point(440, 80)
        Me.cmdMatxDoc.Name = "cmdMatxDoc"
        Me.cmdMatxDoc.Size = New System.Drawing.Size(40, 16)
        Me.cmdMatxDoc.TabIndex = 160
        Me.cmdMatxDoc.Text = "....."
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(16, 80)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(192, 16)
        Me.Label80.TabIndex = 159
        Me.Label80.Text = "Adjuntar Matriz de Comentarios:"
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton7, Me.cmdAgregar, Me.cmdEditar, Me.cmdVerMatriz, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.ToolBarButton8, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 456)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(792, 62)
        Me.tlbBotonera.TabIndex = 64
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdVerMatriz
        '
        Me.cmdVerMatriz.ImageIndex = 6
        Me.cmdVerMatriz.Text = "Ver Matriz"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'ToolBarButton8
        '
        Me.ToolBarButton8.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'FrmAlternativo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 518)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.tvPNN)
        Me.Controls.Add(Me.txtIdComentarios)
        Me.Controls.Add(Me.txtTema)
        Me.Controls.Add(Me.txtPNN)
        Me.Controls.Add(Me.lblSB)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "FrmAlternativo"
        Me.Text = "Captura de Comentarios Proc. Alternativo"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.gpbDatosPersonales.ResumeLayout(False)
        Me.gbpComentarios.ResumeLayout(False)
        Me.grpTipoCaptura.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.tpMatrizCom.ResumeLayout(False)
        Me.gbxMatriz.ResumeLayout(False)
        CType(Me.nudComTec, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudComEdit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FrmAlternativo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sTipoProceso = "Nulo"
        Call Habilita(sTipoProceso)
        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        Call inicializa()
        objComentarios.Bandera = 6 'cboComentario
        Call Carga_Combo(cboTipoComentario)
        Call llena_TreeView()
    End Sub

#Region "  Inicializa"
    Sub inicializa()
        'Datos Personales
        Limpia_Campos(txtNombre, txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        'Proyecto
        Limpia_Campos(cboPNN, cboClasificacion, txtFecPublicacionConsulta, txtFecLimiteComentarios)
        'Comentarios
        Limpia_Campos(cboTipoComentario, txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios)
        'Comentarios matriz
        Limpia_Campos(nudComEdit, nudComTec, txtMatrizDoc)

        Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar, cboNombre, grpTipoCaptura)
        Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios)
        Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)

        'matriz
        Inactivos(nudComEdit, nudComTec, txtMatrizDoc, cmdMatxDoc, cmdVerMatriz)
        Oculta(cmdMatxDoc)

        cboTipoComentario.Enabled = False
        optManual.Checked = True

    End Sub
#End Region

#Region " Botonera"
    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                tvPNN.Enabled = False
                sTipoProceso = "Agregar"
                Call Habilita(sTipoProceso)
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)
                'Call Agregar()

            Case 2 'EDITAR
                If iCaso = 4 Then 'Editar Comentario
                    tvPNN.Enabled = False
                    sTipoProceso = "Editar"
                    Call Habilita(sTipoProceso)

                    If tipoCom = TiposComentario.Normal Then
                        Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                        Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail, grpTipoCaptura)
                        objComentarios.Bandera = 6
                        Call Carga_Combo(cboTipoComentario)
                        cboTipoComentario.SelectedValue = objComentarios.Tipo_comentario
                        Activos(cboTipoComentario)
                        TabControl1.SelectedTab = TabControl1.TabPages.Item(0)
                        Oculta(cmdMatxDoc)
                    ElseIf tipoCom = TiposComentario.Matriz Then
                        Activos(txtMatrizDoc, nudComEdit, nudComTec)
                        TabControl1.SelectedTab = TabControl1.TabPages.Item(2)
                    End If
                End If
            Case 3 'Ver Matriz
                If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
                    'abre el archivo que se desea adjuntar para verificar que sea el correcto
                    If myStream <> "" Then
                        Try
                            System.Diagnostics.Process.Start(myStream)
                        Catch ex As Exception
                            MsgBox("Archivo no encontrado en la ruta : " + myStream)
                        End Try
                    Else
                        Try
                            System.Diagnostics.Process.Start(rutaOriginal)
                        Catch ex As Exception
                            MsgBox("Archivo no encontrado en la ruta : " + rutaOriginal)
                        End Try
                    End If
                Else
                    'consulta el documento guardado
                    If rutaOriginal <> "" Then
                        Try
                            System.Diagnostics.Process.Start(rutaOriginal)
                        Catch ex As Exception
                            MsgBox("Archivo no encontrado en la ruta : " + rutaOriginal)
                        End Try
                        rutaOriginal = ""
                    End If
                End If
            Case 4 'DESHACER
                Activos(tvPNN)
                Call Deshacer()
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                ', cmdAgregar, cmdEditar, cmdBorrar)
                sTipoProceso = "Nulo"
            Case 5 'GUARDAR
                '''Inactivos(cmdDeshacer, cmdGuardar, grdCanceladas)
                '''Activos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                '---CODIGO ORIGINAL---
                'Call Guardar()
                If TabControl1.SelectedIndex = 0 And cboTipoComentario.Enabled = True Then
                    tipoCom = TiposComentario.Normal
                    Call Guardar()
                ElseIf TabControl1.SelectedIndex = 2 And nudComEdit.Enabled = True Then
                    tipoCom = TiposComentario.Matriz
                    If SiVacio(txtMatrizDoc, nudComEdit, nudComTec) Then
                        Call GuardarMatriz()
                    Else
                        MsgBox("Verifica que todos los campos esten completados", MsgBoxStyle.Exclamation, "Campos Vac�os")
                    End If
                Else
                    If TabControl1.SelectedIndex = 1 Then
                        MsgBox("Debe ubicarse en la pesta�a que contiene los datos que se desean guardar", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("No puede agregar en esta ventana por que se encuentra inactiva", MsgBoxStyle.Exclamation)
                    End If
                    Exit Sub
                End If

                sTipoProceso = "Nulo"

            Case 6 'BORRAR
                Call Borrar()

            Case 8 'SALIR
                'Me.Close()
                Me.Dispose()
        End Select
    End Sub
#End Region

#Region " Llena TreeView"
    Private Sub llena_TreeView()
        oTablaPNN = x.ListaPNN("")
        tvPNN.Nodes.Clear()
        tvPNN.BeginUpdate()
        nodo = tvPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = x.ListaTemasProcAlter(RegPNN("id_plan"))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                objComentarios.Bandera = 4
                objComentarios.Id_Plan = RegPNN("id_plan")
                objComentarios.Id_Tema = RegDPy("id_tema")
                objComentarios.Id_Etapa = 2
                DtCom = objComentarios.Buscar_PNN
                If DtCom.Rows.Count <> 0 Then
                    For Each Com In DtCom.Rows
                        'nodo2 = nodo1.Nodes.Add(Com("Id_Comentario"))
                        nodo2 = nodo1.Nodes.Add("COM" + Format$(Com("Id_Comentario"), "0000"))
                    Next
                Else
                    objComentarios.Id_Etapa = 2
                    objComentarios.Bandera = 5
                    DtCom = Nothing
                    DtCom = objComentarios.Buscar_ComMatriz
                    If DtCom.Rows.Count <> 0 Then
                        For Each Com In DtCom.Rows
                            nodo2 = nodo1.Nodes.Add("COMATRIZ0001")
                        Next
                    End If
                End If
            Next
        Next
        tvPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvPNN.Sorted = True

        DtCom = Nothing
        oTablaDPy = Nothing
        oTablaPNN = Nothing
        nodo = Nothing
        nodo1 = Nothing
        nodo2 = Nothing
        RegPNN = Nothing
        RegDPy = Nothing
        Com = Nothing
    End Sub
#End Region

#Region " AfterSelect (Despues de seleccionar un nodo)"
    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvPNN.AfterSelect
        Dim svariable As String
        Dim i As Integer

        svariable = e.Node.FullPath
        lblSB.Text = e.Node.FullPath
        iCaso = 0
        array_texto = Split(lblSB.Text, "\")

        For i = 0 To array_texto.Length - 1
            Select Case i
                Case 1
                    txtPNN.Text = array_texto(i)
                Case 2
                    txtTema.Text = array_texto(i)
            End Select
        Next
        Limpia_Campos(txtFecPublicacionConsulta, txtFecLimiteComentarios)
        Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        Limpia_Campos(nudComEdit, nudComTec, txtMatrizDoc)

        Inactivos(cmdAgregar, cmdEditar, cmdVerMatriz, cmdDeshacer, cmdGuardar, cmdBorrar)

        Select Case array_texto.Length
            Case 1 'selecciona
                Limpia_Campos(txtPNN)
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)

            Case 2 'planes
                txtPNN.Text = array_texto(1)
                iCaso = 2
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)

            Case 3 'temas
                Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                Activos(cmdAgregar)
                TabControl1.SelectedTab = TabControl1.TabPages.Item(1)

                'trabajar con tvPNN.selectedNode.lastNode para evaluar si tiene nodos hijos y de que tipo son as�saber como se realizar� el datalle
                Dim node As TreeNode = tvPNN.SelectedNode.LastNode
                If Not node Is Nothing Then
                    If node.Text = "COMATRIZ0001" Then
                        tipoCom = TiposComentario.Matriz
                        Inactivos(cmdAgregar)
                    Else
                        tipoCom = TiposComentario.Normal
                    End If
                Else
                    tipoCom = TiposComentario.Nulo
                End If

                'zok1
                'busco los datos para la referencia y solo busco en el store esto
                Dim ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
                Dim sRef As String
                ObjPrograma.Band = False
                ObjPrograma.Buscar(array_texto(1), array_texto(2))
                sRef = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
                'zok1

                'busca la informaci�n del tema en avance temas fechas
                'ObjFechasavance.Buscar(array_texto(2), array_texto(1), sRef)
                clsProc.Buscar(array_texto(1), array_texto(2), sRef)
                txtFecPublicacionConsulta.Text = clsProc.F_Inicio_Comentarios
                txtFecLimiteComentarios.Text = clsProc.F_Fin_Comentarios

                'txtFecLimiteAnalisisComentarios.Text = ObjFechasavance.F_Resolucion_ComentarioPublico
            Case 4 'id_comentarios
                Activos(cmdEditar, cmdBorrar)
                Oculta(cmdMatxDoc)

                If array_texto(3) = "COMATRIZ0001" Then
                    tipoCom = TiposComentario.Matriz

                    Activos(cmdVerMatriz)

                    objComentarios.Bandera = 5
                    objComentarios.Id_Plan = array_texto(1)
                    objComentarios.Id_Tema = array_texto(2)
                    objComentarios.Id_Etapa = 2
                    objComentarios.Llena_Campos_Matriz()

                    nudComEdit.Text = objComentarios.NumComEdit
                    nudComTec.Text = objComentarios.NumComTec
                    txtMatrizDoc.Text = objComentarios.DocMatriz

                    PathDocMatriz()

                    TabControl1.SelectedTab = TabControl1.TabPages.Item(2)
                Else
                    tipoCom = TiposComentario.Normal

                    objComentarios.Bandera = 5
                    objComentarios.Id_Plan = array_texto(1)
                    objComentarios.Id_Tema = array_texto(2)
                    objComentarios.Id_Comentario = CInt(Mid(array_texto(3), 4))
                    objComentarios.Llena_Campos()

                    txtFecPublicacionConsulta.Text = objComentarios.Fecha_inicio
                    txtFecLimiteComentarios.Text = objComentarios.Fecha_Fin

                    txtCapituloInciso.Text = objComentarios.Capitulo_inciso
                    txtParrafo.Text = objComentarios.Parrafotablafigura
                    txtComentario.Text = objComentarios.Comentarios
                    txtPropuestasCambios.Text = objComentarios.Propuesta_cambios
                    txtNombre.Text = objComentarios.Nombre
                    txtEmpresa.Text = objComentarios.Empresa
                    txtDomicilio.Text = objComentarios.Domicilio_Empresa
                    txtTelefono.Text = objComentarios.Telefono
                    txtFax.Text = objComentarios.Fax
                    txtEmail.Text = objComentarios.Email

                    objComentarios.Bandera = 8 'cboComentario

                    objComentarios.ListaCombo(cboTipoComentario)
                    cboTipoComentario.SelectedValue = objComentarios.Tipo_comentario
                    TabControl1.SelectedTab = TabControl1.TabPages.Item(0)
                End If
                txtIdComentarios.Text = array_texto(3)
                iCaso = 4
            Case 4
                iCaso = 5
        End Select
    End Sub
#End Region

#Region " AGREGAR"
    Private Sub Agregar()
        Inactivos(tvPNN, cmdBorrar)
        Dim sSqlAgregar As String
        '''If iCaso = 1 Then
        '''    MsgBox("No puedes agregar un Plan desde aqui", MsgBoxStyle.Information, "PNN")
        '''    '''Activos(cmdDeshacer, cmdGuardar, txtComite, txtDescripcion)
        '''    '''Activos(cboResponsable)
        '''    '''Limpia_Campos(txtComite, txtDescripcion)
        '''    '''Exit Sub
        '''End If

        '''If iCaso = 2 Then
        '''    MsgBox("No puedes agregar un Tema desde aqui", MsgBoxStyle.Information, "PNN")
        '''    '''Activos(cmdDeshacer, cmdGuardar, txtCT, txtDescripcion, txtObjetivo)
        '''    '''Activos(cboResponsable)
        '''    '''Limpia_Campos(txtCT, txtDescripcion, txtObjetivo)
        '''    '''Exit Sub
        '''End If


    End Sub
#End Region

#Region " EDITAR"

#End Region

#Region " DESHACER"
    Public Sub Deshacer()
        tvPNN.Nodes.Clear()
        Call inicializa()
        Call llena_TreeView()
        cboTipoComentario.Enabled = False
    End Sub

#End Region

#Region " GUARDAR"
    Dim iDetalle As Integer

    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(splan, stema)
        srefP = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
        splan = Nothing
        stema = Nothing
    End Sub



    Private Sub Guardar()
        Dim sSqlAgregar As String
        If sTipoProceso = "Agregar" Then '*****************IF*************AGREGAR
            objComentarios.Bandera = 1
            objComentarios.Id_Plan = array_texto(1)
            objComentarios.Id_Tema = array_texto(2)
            objComentarios.Buscar_ID_Detalle()
            iDetalle = objComentarios.Id_Comentario

            With objComentarios
                .Bandera = 1
                .Id_Comentario = iDetalle
                .Fecha_Comentario = txtFecPublicacionConsulta.Text
                .Id_Plan = array_texto(1)
                .Id_Tema = array_texto(2)
                .Id_Etapa = 2
                .Nombre = txtNombre.Text
                .Empresa = txtEmpresa.Text
                .Domicilio_Empresa = txtDomicilio.Text
                .Telefono = txtTelefono.Text
                .Fax = txtFax.Text
                .Email = txtEmail.Text
                .Tipo_comentario = cboTipoComentario.SelectedValue
                .Capitulo_inciso = txtCapituloInciso.Text
                .Parrafotablafigura = txtParrafo.Text
                .Comentarios = txtComentario.Text
                .Propuesta_cambios = txtPropuestasCambios.Text
                '.Respuesta = ""
                '.Fecha_inicio = txtFecLimiteComentarios.Text
                '.Fecha_Fin = txtFecLimiteAnalisisComentarios.Text
                splan = array_texto(1)
                stema = array_texto(2)
                Referenciar("abandono")

                .RefA�o = ObjPrograma.RefA�o
                .RefComite = ObjPrograma.RefComite
                .RefConsecutivo = ObjPrograma.RefConsecutivo
                .RefRegreso = ObjPrograma.RefRegreso
                .RefTraspaso = ObjPrograma.RefTraspaso
                .Status = 1
                .Agregar()
            End With
            tvPNN.Nodes.Clear()
            Call inicializa()
            Call llena_TreeView()
            Limpia_Campos(txtPNN, txtTema, txtIdComentarios)
            tvPNN.Enabled = True




        ElseIf sTipoProceso = "Editar" Then '****************ELSE**************EDITAR



            With objComentarios
                .Bandera = 2
                .Id_Comentario = CInt(Mid(array_texto(3), 4))
                .Fecha_Comentario = txtFecPublicacionConsulta.Text
                .Id_Plan = array_texto(1)
                .Id_Tema = array_texto(2)
                .Nombre = txtNombre.Text
                .Empresa = txtEmpresa.Text
                .Domicilio_Empresa = txtDomicilio.Text
                .Telefono = txtTelefono.Text
                .Fax = txtFax.Text
                .Email = txtEmail.Text
                .Tipo_comentario = cboTipoComentario.SelectedValue
                .Capitulo_inciso = txtCapituloInciso.Text
                .Parrafotablafigura = txtParrafo.Text
                .Comentarios = txtComentario.Text
                .Propuesta_cambios = txtPropuestasCambios.Text
                .Respuesta = ""
                ' .Fecha_inicio = txtFecLimiteComentarios.Text
                ' .Fecha_Fin = txtFecLimiteAnalisisComentarios.Text
                .Actualizar()
            End With
            tvPNN.Nodes.Clear()
            Call inicializa()
            Call llena_TreeView()
            Limpia_Campos(txtPNN, txtTema, txtIdComentarios)
            tvPNN.Enabled = True



        End If
    End Sub

    Private Sub GuardarMatriz()
        With objComentarios
            .NumComEdit = Integer.Parse(nudComEdit.Text)
            .NumComTec = Integer.Parse(nudComTec.Text)
            .DocMatriz = txtMatrizDoc.Text
            .Id_Etapa = 2

            splan = array_texto(1)
            stema = array_texto(2)
            Referenciar("abandono")

            .RefA�o = ObjPrograma.RefA�o
            .RefComite = ObjPrograma.RefComite
            .RefConsecutivo = ObjPrograma.RefConsecutivo
            .RefRegreso = ObjPrograma.RefRegreso
            .RefTraspaso = ObjPrograma.RefTraspaso
        End With

        Dim ruta As String
        If ObjPrograma.ID_Grupo <> "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite

        Dim server = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")
        Dim carpeta = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Comentarios")

        Dim Rutaoriginal = server + carpeta + "\" + ruta + "\"
        Dim sPath = Rutaoriginal + txtMatrizDoc.Text
        If myStream <> "" Then
            clsCopia.CopiaArchivos(myStream, sPath, Rutaoriginal)
        End If

        If Not clsCopia.er Then
            If sTipoProceso = "Agregar" Then
                With objComentarios
                    .Bandera = 2
                    .AgregarComMatriz()
                End With
            ElseIf sTipoProceso = "Editar" Then
                With objComentarios
                    .Bandera = 3
                    .ActualizarComMatriz()
                End With
            End If
        End If

        'tvPNN.Nodes.Clear()
        Call inicializa()
        Call llena_TreeView()
        Limpia_Campos(txtPNN, txtTema, txtIdComentarios)
        tvPNN.Enabled = True
    End Sub

#End Region

#Region " BORRAR"
    Public Sub Borrar()
        If MsgBox("�Estas seguro que deseas eliminar este Comentario: " & txtPNN.Text & "/" & txtTema.Text & "/" & txtIdComentarios.Text & " ", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
            Try
                If tipoCom = TiposComentario.Normal Then
                    With objComentarios
                        .Bandera = 5
                        .Id_Plan = array_texto(1) 'txtPNN.Text
                        .Id_Tema = array_texto(2) 'txtTema.Text
                        .Id_Comentario = CInt(Mid(array_texto(3), 4)) 'txtIdComentarios.Text
                        .Id_Etapa = 2
                        .Borrar()
                    End With

                ElseIf tipoCom = TiposComentario.Matriz Then
                    splan = array_texto(1)
                    stema = array_texto(2)
                    Referenciar("abandono")

                    Dim ruta As String
                    If ObjPrograma.ID_Grupo <> "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
                    If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
                    If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
                    If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite

                    Dim server = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")
                    Dim carpeta = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Comentarios")
                    Dim sPath = server + carpeta + "\" + ruta + "\" + txtMatrizDoc.Text

                    File.Delete(sPath)

                    With objComentarios
                        .Bandera = 4
                        .Id_Plan = array_texto(1)
                        .Id_Tema = array_texto(2)
                        .Id_Etapa = 2
                        .RefA�o = ObjPrograma.RefA�o
                        .RefComite = ObjPrograma.RefComite
                        .RefConsecutivo = ObjPrograma.RefConsecutivo
                        .RefRegreso = ObjPrograma.RefRegreso
                        .RefTraspaso = ObjPrograma.RefTraspaso
                        .Status = 2
                        .BorrarComMatriz()
                    End With
                End If
                tvPNN.Nodes.Clear()
                Call llena_TreeView()
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation)
            End Try
        End If
    End Sub

    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"


            Case "Agregar"

                Dim node As TreeNode = tvPNN.SelectedNode.LastNode
                If node Is Nothing Then
                    Activos(cmdDeshacer, cmdGuardar, cmdVerMatriz)
                    Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdVerMatriz)
                    Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios)

                    Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                    Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail, cboNombre, grpTipoCaptura)
                    cboTipoComentario.Enabled = True
                    objComentarios.Bandera = 6

                    Call Carga_Combo(cboTipoComentario)
                    Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                    Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)

                    Activos(nudComEdit, nudComTec, cmdMatxDoc)
                    Limpia_Campos(txtMatrizDoc, nudComEdit, nudComTec)
                    Muestra(cmdMatxDoc)
                Else
                    Activos(cmdDeshacer, cmdGuardar, cmdVerMatriz)
                    Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdVerMatriz)
                    Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios)

                    Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                    Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail, cboNombre, grpTipoCaptura)
                    cboTipoComentario.Enabled = True
                    objComentarios.Bandera = 6

                    Call Carga_Combo(cboTipoComentario)
                    Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                    Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                End If
            Case "Editar"
                Activos(cmdDeshacer, cmdGuardar, cmdMatxDoc)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cboNombre)
                Muestra(cmdMatxDoc)
                If myStream <> "" Then
                    Activos(cmdVerMatriz)
                End If
        End Select
    End Sub

    Sub Carga_Combo(ByVal cbo As Object)
        objComentarios.ListaCombo(cbo)
    End Sub
#End Region

    Private Sub optManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optManual.CheckedChanged
        If optManual.Checked Then
            txtNombre.Visible = True
            cboNombre.Visible = False
            Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
            Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        Else
            txtNombre.Visible = False
            cboNombre.Visible = True
            ObjDirectorio.ListaCombo(cboNombre)
        End If
    End Sub

    Private Sub cboNombre_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboNombre.SelectedIndexChanged
        ObjDirectorio.ID_Directorio = cboNombre.SelectedValue
        ObjDirectorio.Buscar()
        llenacampos()
    End Sub

    Private Sub llenacampos()
        txtNombre.Text = ObjDirectorio.Nombre
        txtEmpresa.Text = ObjDirectorio.Empresa
        txtDomicilio.Text = ObjDirectorio.Domicilio
        txtTelefono.Text = ObjDirectorio.Telefono
        txtFax.Text = ObjDirectorio.Fax
        txtEmail.Text = ObjDirectorio.Mail
    End Sub

    Private Sub cmdMatxDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdMatxDoc.Click
        Dim openFileDialog1 As New OpenFileDialog
        Dim iIndice As Integer
        Dim Archivo As String
        Dim sExt As String

        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "txt files (*.pdf)|*.pdf|(*.doc)|*.doc|(*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True

        Archivo = myStream = ""
        iIndice = 0

        splan = array_texto(1)
        stema = array_texto(2)
        Referenciar("abandono")

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream = openFileDialog1.FileName()
            If Not (myStream = "") Then
                For iIndice = Len(myStream) To 1 Step -1
                    If Mid(myStream, iIndice, 1) = "\" Then
                        Archivo = Mid(myStream, iIndice + 1)
                        iIndice = 1
                    End If
                Next iIndice
                sExt = Len(Archivo)
                Dim Part As String
                Part = Mid(Archivo, CInt(sExt - 3), 4)

                SDocumento = "TempMatx" + "_" + Format(ObjPrograma.Id_Tema, "0000") + "_1" + Part
                txtMatrizDoc.Text = SDocumento
                Activos(cmdVerMatriz)
            End If
        End If
    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedIndex = 2 Then
            If txtMatrizDoc.Text <> "" Then
                Activos(cmdVerMatriz)
            End If
        Else
            Inactivos(cmdVerMatriz)
        End If
    End Sub

    Private Sub PathDocMatriz()
        Dim ruta As String

        splan = array_texto(1)
        stema = array_texto(2)
        Referenciar("abandono")

        If ObjPrograma.ID_Grupo <> "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC + "\" + ObjPrograma.ID_Grupo
        If ObjPrograma.ID_SC <> "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT + "\" + ObjPrograma.ID_SC
        If ObjPrograma.ID_CT <> "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite + "\" + ObjPrograma.ID_CT
        If ObjPrograma.ID_Comite <> "NA" And ObjPrograma.ID_CT = "NA" And ObjPrograma.ID_SC = "NA" And ObjPrograma.ID_Grupo = "NA" Then ruta = ObjPrograma.ID_Comite

        Dim server = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")
        Dim carpeta = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "Comentarios")
        Dim rutaCarpetas = server + carpeta + "\" + ruta + "\"
        Dim sPath = rutaCarpetas + txtMatrizDoc.Text

        rutaOriginal = sPath
    End Sub


End Class
