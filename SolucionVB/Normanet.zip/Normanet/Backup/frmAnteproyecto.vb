Public Class frmAnteproyecto
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents PnlLectura As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lbla�o As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tvTemasDT As System.Windows.Forms.TreeView
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents cmdActa As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAnteproyecto))
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.PnlLectura = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.lbla�o = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.txt1 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.tvTemasDT = New System.Windows.Forms.TreeView
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.cmdActa = New System.Windows.Forms.ToolBarButton
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.PnlLectura.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'TVPNN
        '
        Me.TVPNN.ImageIndex = -1
        Me.TVPNN.Location = New System.Drawing.Point(8, 2)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = -1
        Me.TVPNN.Size = New System.Drawing.Size(176, 464)
        Me.TVPNN.TabIndex = 18
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'PnlLectura
        '
        Me.PnlLectura.Controls.Add(Me.Label4)
        Me.PnlLectura.Controls.Add(Me.Label5)
        Me.PnlLectura.Controls.Add(Me.lbla�o)
        Me.PnlLectura.Controls.Add(Me.TextBox1)
        Me.PnlLectura.Controls.Add(Me.txt1)
        Me.PnlLectura.Controls.Add(Me.Label3)
        Me.PnlLectura.Controls.Add(Me.Label2)
        Me.PnlLectura.Controls.Add(Me.Label1)
        Me.PnlLectura.Controls.Add(Me.tvTemasDT)
        Me.PnlLectura.Location = New System.Drawing.Point(192, 6)
        Me.PnlLectura.Name = "PnlLectura"
        Me.PnlLectura.Size = New System.Drawing.Size(472, 456)
        Me.PnlLectura.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(264, 152)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(8, 23)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "-"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(24, 152)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 23)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "Clasificaci�n"
        '
        'lbla�o
        '
        Me.lbla�o.Location = New System.Drawing.Point(272, 152)
        Me.lbla�o.Name = "lbla�o"
        Me.lbla�o.Size = New System.Drawing.Size(32, 23)
        Me.lbla�o.TabIndex = 39
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(232, 151)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(32, 20)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Text = "-"
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(194, 151)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(30, 20)
        Me.txt1.TabIndex = 1
        Me.txt1.Text = "-"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(171, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 23)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "J-"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(139, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 23)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "NMX-"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(104, 152)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 23)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "ANT-"
        '
        'tvTemasDT
        '
        Me.tvTemasDT.ImageIndex = -1
        Me.tvTemasDT.Location = New System.Drawing.Point(88, 16)
        Me.tvTemasDT.Name = "tvTemasDT"
        Me.tvTemasDT.SelectedImageIndex = -1
        Me.tvTemasDT.Size = New System.Drawing.Size(296, 88)
        Me.tvTemasDT.TabIndex = 30
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'cmdActa
        '
        Me.cmdActa.ImageIndex = 6
        Me.cmdActa.Text = "Acta Aprobaci�n"
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.CmdSalir, Me.cmdActa})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 472)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(672, 62)
        Me.tlbBotonera.TabIndex = 19
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'frmAnteproyecto
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(672, 534)
        Me.Controls.Add(Me.PnlLectura)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TVPNN)
        Me.Name = "frmAnteproyecto"
        Me.Text = "frmAnteproyecto"
        Me.PnlLectura.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
