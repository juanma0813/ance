Imports System.Data.SqlClient
Imports System.Windows.Forms
Public Class frmP_Usuarios
    Inherits System.Windows.Forms.Form

    Dim cn As New SqlConnection
    Dim objConexion As New clsConexion.cIsConexion
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim sTipoProceso As String

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents gpbNombre As System.Windows.Forms.GroupBox
    Friend WithEvents chkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents lblActivo As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtGrupo As System.Windows.Forms.TextBox
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents txtClaveUsuario As System.Windows.Forms.TextBox
    Friend WithEvents cboGrupo As System.Windows.Forms.ComboBox
    Friend WithEvents cboNombre As System.Windows.Forms.ComboBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblGrupo As System.Windows.Forms.Label
    Friend WithEvents lblNombre As System.Windows.Forms.Label
    Friend WithEvents lblClaveUsuario As System.Windows.Forms.Label
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmP_Usuarios))
        Me.gpbNombre = New System.Windows.Forms.GroupBox
        Me.chkActivo = New System.Windows.Forms.CheckBox
        Me.lblActivo = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.txtGrupo = New System.Windows.Forms.TextBox
        Me.txtNombre = New System.Windows.Forms.TextBox
        Me.txtClaveUsuario = New System.Windows.Forms.TextBox
        Me.cboGrupo = New System.Windows.Forms.ComboBox
        Me.cboNombre = New System.Windows.Forms.ComboBox
        Me.lblPassword = New System.Windows.Forms.Label
        Me.lblGrupo = New System.Windows.Forms.Label
        Me.lblNombre = New System.Windows.Forms.Label
        Me.lblClaveUsuario = New System.Windows.Forms.Label
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.gpbNombre.SuspendLayout()
        Me.SuspendLayout()
        '
        'gpbNombre
        '
        Me.gpbNombre.Controls.Add(Me.chkActivo)
        Me.gpbNombre.Controls.Add(Me.lblActivo)
        Me.gpbNombre.Controls.Add(Me.txtPassword)
        Me.gpbNombre.Controls.Add(Me.txtGrupo)
        Me.gpbNombre.Controls.Add(Me.txtNombre)
        Me.gpbNombre.Controls.Add(Me.txtClaveUsuario)
        Me.gpbNombre.Controls.Add(Me.cboGrupo)
        Me.gpbNombre.Controls.Add(Me.cboNombre)
        Me.gpbNombre.Controls.Add(Me.lblPassword)
        Me.gpbNombre.Controls.Add(Me.lblGrupo)
        Me.gpbNombre.Controls.Add(Me.lblNombre)
        Me.gpbNombre.Controls.Add(Me.lblClaveUsuario)
        Me.gpbNombre.Location = New System.Drawing.Point(7, 0)
        Me.gpbNombre.Name = "gpbNombre"
        Me.gpbNombre.Size = New System.Drawing.Size(465, 200)
        Me.gpbNombre.TabIndex = 52
        Me.gpbNombre.TabStop = False
        '
        'chkActivo
        '
        Me.chkActivo.Location = New System.Drawing.Point(128, 172)
        Me.chkActivo.Name = "chkActivo"
        Me.chkActivo.Size = New System.Drawing.Size(16, 18)
        Me.chkActivo.TabIndex = 11
        '
        'lblActivo
        '
        Me.lblActivo.AutoSize = True
        Me.lblActivo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblActivo.Location = New System.Drawing.Point(16, 174)
        Me.lblActivo.Name = "lblActivo"
        Me.lblActivo.Size = New System.Drawing.Size(39, 16)
        Me.lblActivo.TabIndex = 10
        Me.lblActivo.Text = "Activo"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(128, 139)
        Me.txtPassword.MaxLength = 8
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(128, 20)
        Me.txtPassword.TabIndex = 9
        Me.txtPassword.Text = ""
        '
        'txtGrupo
        '
        Me.txtGrupo.Location = New System.Drawing.Point(128, 99)
        Me.txtGrupo.Name = "txtGrupo"
        Me.txtGrupo.Size = New System.Drawing.Size(300, 20)
        Me.txtGrupo.TabIndex = 8
        Me.txtGrupo.Text = ""
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(128, 60)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(300, 20)
        Me.txtNombre.TabIndex = 7
        Me.txtNombre.Text = ""
        '
        'txtClaveUsuario
        '
        Me.txtClaveUsuario.Location = New System.Drawing.Point(128, 24)
        Me.txtClaveUsuario.Name = "txtClaveUsuario"
        Me.txtClaveUsuario.TabIndex = 6
        Me.txtClaveUsuario.Text = ""
        '
        'cboGrupo
        '
        Me.cboGrupo.Location = New System.Drawing.Point(128, 99)
        Me.cboGrupo.Name = "cboGrupo"
        Me.cboGrupo.Size = New System.Drawing.Size(318, 21)
        Me.cboGrupo.TabIndex = 5
        '
        'cboNombre
        '
        Me.cboNombre.Location = New System.Drawing.Point(128, 60)
        Me.cboNombre.Name = "cboNombre"
        Me.cboNombre.Size = New System.Drawing.Size(318, 21)
        Me.cboNombre.TabIndex = 4
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassword.Location = New System.Drawing.Point(16, 144)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(58, 16)
        Me.lblPassword.TabIndex = 3
        Me.lblPassword.Text = "Password"
        '
        'lblGrupo
        '
        Me.lblGrupo.AutoSize = True
        Me.lblGrupo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrupo.Location = New System.Drawing.Point(16, 103)
        Me.lblGrupo.Name = "lblGrupo"
        Me.lblGrupo.Size = New System.Drawing.Size(38, 16)
        Me.lblGrupo.TabIndex = 2
        Me.lblGrupo.Text = "Grupo"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombre.Location = New System.Drawing.Point(16, 64)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(47, 16)
        Me.lblNombre.TabIndex = 1
        Me.lblNombre.Text = "Nombre"
        '
        'lblClaveUsuario
        '
        Me.lblClaveUsuario.AutoSize = True
        Me.lblClaveUsuario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClaveUsuario.Location = New System.Drawing.Point(16, 25)
        Me.lblClaveUsuario.Name = "lblClaveUsuario"
        Me.lblClaveUsuario.TabIndex = 0
        Me.lblClaveUsuario.Text = "Clave de Usuario:"
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 205)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(479, 62)
        Me.tlbBotonera.TabIndex = 53
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'frmP_Usuarios
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(479, 267)
        Me.Controls.Add(Me.gpbNombre)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Name = "frmP_Usuarios"
        Me.Text = "Usuarios"
        Me.gpbNombre.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Sub Inicializa_Inactivos()
        Limpia_Campos(txtClaveUsuario, txtGrupo, txtPassword)
        Inactivos(txtClaveUsuario, txtNombre, txtGrupo, txtPassword)
        Inactivos(cboNombre, cboGrupo)
        Inactivos(cmdDeshacer)
    End Sub

    Sub Inicializa_Activos()
        If sTipoProceso = "Agregar" Then
            Activos(txtClaveUsuario, txtPassword)
            Activos(cboGrupo)
        End If

        If sTipoProceso = "Editar" Then
            Activos(txtPassword)
            Activos(cboGrupo)
        End If
        ''Activos(txtClaveUsuario, txtPassword)
        ''Activos(cboNombre, cboGrupo)
    End Sub
    Private Sub fmrP_Usuarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sTipoProceso = "Nulo"
        'Call llena_usuarios(s)
        Call Inicializa_Inactivos()
        Activos(cboNombre)
        Call Llena_usuarios()
    End Sub

    Sub Llena_usuarios()
        objempleados.Bandera = 6
        objempleados.ListaCombo(cboNombre)
    End Sub

    Private Sub cboNombre_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboNombre.SelectedIndexChanged
        If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
            txtNombre.Text = cboNombre.SelectedValue
            If txtNombre.Text <> "" Then
                objempleados.Bandera = 3
                objempleados.Id_usuario = txtNombre.Text
                objempleados.Id_usuario = cboNombre.SelectedValue
                objempleados.Buscar()
                If IsDBNull(objempleados.NOMBRE_COMPLETO) Then
                    txtNombre.Visible = False
                Else
                    txtNombre.Text = objempleados.NOMBRE_COMPLETO
                End If
            End If
        Else
            If Not (cboNombre.SelectedValue <> "") Then
                txtNombre.Text = cboNombre.SelectedText
            Else
                txtNombre.Text = cboNombre.Text
                Call llena_campos(cboNombre.SelectedValue)

            End If
        End If
    End Sub

    Private Sub llena_campos(ByVal id_Usuario As String)
        objempleados.Bandera = 1
        objempleados.Id_usuario = (id_Usuario)
        objempleados.Id_Sistema = 16
        objempleados.Buscar_usuario()

        txtClaveUsuario.Text = objempleados.Id_usuario
        txtPassword.Text = objempleados.Password

        objempleados.Bandera = 4 ''llena el combo con los datos
        objempleados.Id_Sistema = 16
        objempleados.Id_Grupo = objempleados.Id_Grupo
        objempleados.ListaComboGrupo(cboGrupo)

        objempleados.Bandera = 3 ''busca la descripcion espec�fica del usuarios seleccionada
        objempleados.Id_usuario = (id_Usuario)
        objempleados.Id_Sistema = 16
        objempleados.Id_Grupo = objempleados.Id_Grupo
        objempleados.Buscar_Grupo()
        txtGrupo.Text = objempleados.Nombre_Grupo
    End Sub

    Private Sub Agregar()
        Call Inicializa_Activos()
        Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
        Activos(cmdDeshacer, cmdGuardar)
    End Sub

    Private Sub Editar()
        Call Inicializa_Activos()
        Inactivos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
        Activos(cmdDeshacer, cmdGuardar)
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                sTipoProceso = "Agregar"
                Call Agregar()
                txtGrupo.Text = cboGrupo.Text

            Case 2 'EDITAR
                sTipoProceso = "Editar"
                Activos(cmdDeshacer, cmdGuardar)
                Call Editar()
                txtGrupo.Text = cboGrupo.Text

            Case 3 'DESHACER
                sTipoProceso = "Nulo"
                Call Llena_usuarios()
                Call Inicializa_Inactivos()
                Activos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Inactivos(cmdDeshacer, cmdGuardar)
                Activos(cboNombre)

                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, txtSGT, cboResponsable)

            Case 4 'GUARDAR
                Call Guardar()

            Case 5 'BORRAR
                'Call Borrar()

            Case 7 'SALIR
                Me.Close()
        End Select
    End Sub

    Private Sub cboGrupo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboGrupo.SelectedIndexChanged
        txtGrupo.Text = cboGrupo.Text

        '''If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
        '''    txtGrupo.Text = cboGrupo.SelectedValue
        '''    If txtGrupo.Text <> "" Then

        '''        objempleados.Bandera = 4 ''llena el combo con los datos
        '''        objempleados.Id_Sistema = 16
        '''        objempleados.ListaComboGrupo(cboGrupo)

        '''        txtGrupo.Text = cboGrupo.SelectedText
        '''        txtGrupo.Text = objempleados.Nombre_Grupo

        '''    End If
        '''Else
        '''    If cboGrupo.SelectedValue = "" Then
        '''        txtGrupo.Text = cboGrupo.SelectedText
        '''    Else
        '''        txtGrupo.Text = cboGrupo.Text
        '''    End If
        '''End If

    End Sub

    Private Sub Guardar()
        If txtClaveUsuario.Text = "" Or txtPassword.Text = "" Or txtGrupo.Text = "" Then Exit Sub

        If sTipoProceso = "Agregar" Then
            objempleados.Bandera = 3
            objempleados.Id_usuario = txtClaveUsuario.Text
            objempleados.Buscar()
            If objempleados.NOMBRE_COMPLETO = "" Or IsDBNull(objempleados.NOMBRE_COMPLETO) Then
                MsgBox("Est� clave de usuario no es v�lida, verifica la clave", MsgBoxStyle.Information, "Usuarios")
                Exit Sub
            Else
                If MsgBox("Este nombre es correcto para la clave de usuarios:" + Chr(13) + objempleados.NOMBRE_COMPLETO, MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
                    Exit Sub
                End If
            End If



        ElseIf sTipoProceso = "Editar" Then
            '

        End If
    End Sub

    Private Sub gpbNombre_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gpbNombre.Enter

    End Sub
End Class
