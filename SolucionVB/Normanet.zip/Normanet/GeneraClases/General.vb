Imports System.Data.SqlClient
Imports System.IO

Module General

    Public sConexion As String

    Sub main()
        Try
        Catch ex As Exception
            MessageBox.Show("Es un error " & ex.Message)
        End Try
    End Sub

    Public Tabla(350) As String
    Public DimensionTabla As Integer
    Public Campos(1, 50) As String
    Public _DimensionCampos As System.Int32


    Public RutaPath As String
    Public ArcClase As String
    Public Tabulador As String = "     "
    Public Tabulador2 As String = "          "
    Public Tabulador3 As String = "              "
    Public Tabulador4 As String = "                  "
    Public Tabulador5 As String = "                      "
    Public CadenaCero As String = Chr(34) & "0" & Chr(34)


    '********************************************************************************
    Public Function EscribeClase() As String
        Dim ArClase As New System.IO.StreamWriter(RutaPath & ArcClase & ".vb")
        Dim I As Integer
        Dim IsLlave As String
        Dim CWhere As String
        For I = 0 To _DimensionCampos - 1
            IsLlave = Campos(6, I).ToString
            If IsLlave = "True" Then
                CWhere = Campos(0, I).ToString()
            End If
        Next
        If CWhere = "" Then
            ArClase.WriteLine("")
            SeparaLineas(ArClase)
            SeparaLineas(ArClase)
            ArClase.WriteLine(Tabulador & "'" & Tabulador5 & " NO TIENE CAMPO LLAVE CUIDADO")
            ArClase.WriteLine(Tabulador & "'" & Tabulador3 & "Puede Afectar el correcto funcionamiento de las funciones")
            ArClase.WriteLine(Tabulador & "'" & Tabulador2 & "De Actualizacion y de Borrado ya que se hacen sobre un campo llave")
            SeparaLineas(ArClase)
            SeparaLineas(ArClase)
            ArClase.WriteLine("")
        Else
            ArClase.WriteLine("")
            SeparaLineas(ArClase)
            SeparaLineas(ArClase)
            ArClase.WriteLine(Tabulador & "'" & Tabulador5 & " ESTOS SON LOS CAMPOS LLAVE QUE TIENE LA TABLA")
            For I = 0 To _DimensionCampos - 1
                IsLlave = Campos(6, I).ToString
                If IsLlave = "True" Then
                    ArClase.WriteLine(Tabulador & "'" & Tabulador3 & Campos(0, I).ToString())
                End If
            Next
            SeparaLineas(ArClase)
            SeparaLineas(ArClase)
            ArClase.WriteLine("")
        End If
        Encabezado(ArClase)
        CierraArchivo(ArClase)

    End Function

    '********************************************************************************
    Public Function SeparaLineas(ByRef arclase) As String
        arclase.WriteLine(Tabulador & "'*****************************************************************************")
    End Function

    '********************************************************************************


    '********************************************************************************
    Public Function CierraArchivo(ByRef arclase) As String
        ArClase.WriteLine("End Class")
        ArClase.Close()
    End Function
    '********************************************************************************
    Public Function Encabezado(ByRef arclase) As String
        Dim xconexion As New Conexion
        ArClase.WriteLine("'*************************************************************************************")
        arclase.WriteLine("'Clase " & ArcClase & " Generada automaticamente")
        arclase.WriteLine("'Desarrollada por EXTI, S.C. para ANCE, A.C.")
        ArClase.WriteLine("'Fecha : " & Now & "")
        arclase.WriteLine("'*************************************************************************************")
        arclase.WriteLine("")
        arclase.WriteLine("")
        arclase.WriteLine("Option Explicit")
        ArClase.WriteLine("Imports System")
        ArClase.WriteLine("Imports System.Data")
        ArClase.WriteLine("Imports System.Data.SqlClient")
        arclase.WriteLine("")

        arclase.WriteLine("Public Class " & ArcClase)
        arclase.WriteLine("")
        arclase.WriteLine("     '''''''Declaracion de Variables Privadas")
        Variables(arclase)

        arclase.WriteLine("")
        arclase.WriteLine("     '''''''Declaracion de Propiedades publicas")
        Propiedades(arclase)

        arclase.WriteLine("")
        arclase.WriteLine(Tabulador & "Public Sub New () ")
        arclase.WriteLine(Tabulador & "End Sub")

        arclase.WriteLine("")
        arclase.WriteLine("     '''''''''''''''''Genera una la lista de campos")
        Lista(arclase)

        arclase.WriteLine("")
        arclase.WriteLine("     '''''''''''''''''Funcion para buscar datos en la tabla segun parametro")
        Buscar(arclase)

        arclase.WriteLine("")
        arclase.WriteLine("     '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos")
        StoreProcedures(arclase)


    End Function
    '********************************************************************************
    Public Function Variables(ByRef arclase) As String
        Dim I As Integer
        arclase.WriteLine(Tabulador & "Private ds" & ArcClase & " AS New DataSet")
        arclase.WriteLine(Tabulador & "Private cn  AS New SQLConnection")
        For I = 0 To _DimensionCampos - 1
            arclase.WriteLine(Tabulador & "Private _" & Campos(0, I).ToString() & " as " & Campos(12, I).Substring(7))
        Next
        arclase.WriteLine(Tabulador & "Private sSql as String")
    End Function
    '********************************************************************************
    Public Function Propiedades(ByRef arclase) As String
        Dim Campo As String
        Dim Tipo As String
        Dim Variable As String
        Dim I As Integer
        Dim Longitud As String
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Longitud = Campos(2, I).ToString
            Variable = "_" & Campo
            arclase.WriteLine(Tabulador & "Public Property " & Campo & "()")
            arclase.WriteLine(Tabulador2 & "Get")
            arclase.WriteLine(Tabulador3 & "Return " & Variable)
            arclase.WriteLine(Tabulador2 & "End Get")
            arclase.WriteLine(Tabulador2 & "Set(ByVal Value)")
            arclase.WriteLine(Tabulador3 & Variable & " = Value")
            arclase.WriteLine(Tabulador2 & "End Set")
            arclase.WriteLine(Tabulador & "End Property")
            arclase.WriteLine("")
        Next
    End Function
    '********************************************************************************
    Public Function PropiedadDefault1(ByRef arclase) As String
        Dim Campo As String
        Dim Tipo As String
        Dim Variable As String
        Dim I As Integer
        arclase.WriteLine(Tabulador & "public Default Property Item(Index as Integer) as String")
        arclase.WriteLine(Tabulador2 & "Get")
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Variable = "_" & Campo
            If I = 0 Then
                arclase.WriteLine(Tabulador3 & "If Index = 0 Then")
            Else
                arclase.WriteLine(Tabulador3 & "elseif index = " & I & " Then")
            End If
            arclase.WriteLine(Tabulador4 & "Return Me." & Campo & ".ToString()")
        Next
        arclase.WriteLine(Tabulador3 & "End If")
        arclase.WriteLine(Tabulador2 & "End Get")
        arclase.WriteLine(Tabulador2 & "Set(Value as String)")
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Variable = "_" & Campo
            If I = 0 Then
                arclase.WriteLine(Tabulador3 & "If Index = 0 Then")
            Else
                arclase.WriteLine(Tabulador3 & "ElseIf Index = " & I & " Then")
            End If
            Select Case Tipo
                Case Is = "System.Decimal"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.Int16"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.Int32"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.Int64()"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.DateTime"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.DateTime.Parse(Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Datetime.Now")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Else
                    arclase.WriteLine(Tabulador4 & "Me." & Campo & "= Value")
            End Select
        Next
        arclase.WriteLine(Tabulador3 & "End If")
        arclase.WriteLine(Tabulador2 & "End Set")
        arclase.WriteLine(Tabulador & "End Property")
    End Function
    '********************************************************************************
    Public Function PropiedadDefault2(ByRef arclase) As String
        Dim Campo As String
        Dim Tipo As String
        Dim Variable As String
        Dim Campo_Pre As String
        Dim I As Integer
        arclase.WriteLine(Tabulador & "public Default Property Item(Index as String) as String")
        arclase.WriteLine(Tabulador2 & "Get")
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Campo_Pre = Chr(34) & Campo & Chr(34)
            Variable = "_" & Campo
            If I = 0 Then
                arclase.WriteLine(Tabulador3 & "If Index = " & Campo_Pre & " Then")
            Else
                arclase.WriteLine(Tabulador3 & "ElseIf Index = " & Campo_Pre & " Then")
            End If
            arclase.WriteLine(Tabulador4 & "Return Me." & Campo & ".ToString()")
        Next
        arclase.WriteLine(Tabulador3 & "End If")
        arclase.WriteLine(Tabulador2 & "End Get")
        arclase.WriteLine(Tabulador2 & "Set(Value as String)")
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Variable = "_" & Campo
            Campo_Pre = Chr(34) & Campo & Chr(34)
            If I = 0 Then
                arclase.WriteLine(Tabulador3 & "If Index = " & Campo_Pre & " Then")
            Else
                arclase.WriteLine(Tabulador3 & "ElseIf Index = " & Campo_Pre & " Then")
            End If
            Select Case Tipo
                Case Is = "System.Decimal"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Decimal.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.Int16"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int16.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.Int32"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int32.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.Int64()"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & " & Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Int64.Parse(" & CadenaCero & ")")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Is = "System.DateTime"
                    arclase.WriteLine(Tabulador4 & "Try")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.DateTime.Parse(Value)")
                    arclase.WriteLine(Tabulador4 & "Catch")
                    arclase.WriteLine(Tabulador5 & "Me." & Campo & " = System.Datetime.Now")
                    arclase.WriteLine(Tabulador4 & "End Try")
                Case Else
                    arclase.WriteLine(Tabulador4 & "Me." & Campo & " = Value")
            End Select
        Next
        arclase.WriteLine(Tabulador3 & "End If")
        arclase.WriteLine(Tabulador2 & "End Set")
        arclase.WriteLine(Tabulador & "End Property")
    End Function
    ''''********************************************************************************
    '''Public Function EstCadCon(ByRef arclase) As String
    '''    Dim xconexion As New Conexion
    '''    ArClase.WriteLine(Tabulador & "public   CadenaConexion as String = " & Chr(34) & xconexion.Cadenaconexion & Chr(34))
    '''End Function
    '********************************************************************************
    Public Function EstCadSel(ByRef arclase) As String
        arclase.WriteLine(Tabulador & "public   CadenaSelect as String = " & Chr(34) & "Select * From " & ArcClase & Chr(34))
    End Function
    '********************************************************************************
    '''Public Function EstNew(ByRef arclase) As String
    '''    ArClase.WriteLine(Tabulador & "public Sub New () ")
    '''    ArClase.WriteLine(Tabulador & "End Sub")
    '''    ArClase.WriteLine(Tabulador & "public Sub New (conex as String) ")
    '''    ArClase.WriteLine(Tabulador2 & "CadenaConexion =  conex")
    '''    ArClase.WriteLine(Tabulador & "End Sub")
    '''End Function
    '********************************************************************************
    Public Function Tab2Obj(ByRef arclase) As String
        Dim I As Integer
        Dim Campo As String
        Dim Variable As String
        Dim Tipo As String
        Dim Campo_Pre As String
        arclase.WriteLine(Tabulador & "Private   function row2" & ArcClase & "(r As DataRow) as " & ArcClase)
        arclase.WriteLine(Tabulador2 & "Dim o" & ArcClase & " as New " & ArcClase)
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Variable = "_" & Campo
            Campo_Pre = Chr(34) & Campo & Chr(34)
            Select Case Tipo
                Case Is = "System.Decimal"
                    arclase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Decimal.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
                Case Is = "System.Int16"
                    arclase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Int16.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
                Case Is = "System.Int32"
                    arclase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Int32.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
                Case Is = "System.Int64"
                    arclase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = System.Int64.Parse(" & CadenaCero & " & r(" & Campo_Pre & ").ToString())")
                Case Is = "System.DateTime"
                    arclase.WriteLine(Tabulador3 & "Try")
                    arclase.WriteLine(Tabulador4 & "o" & ArcClase & "." & Campo & " = DateTime.Parse(r(" & Campo_Pre & ").ToString())")
                    arclase.WriteLine(Tabulador3 & "Catch")
                    arclase.WriteLine(Tabulador4 & "o" & ArcClase & "." & Campo & " = DateTime.Now")
                    arclase.WriteLine(Tabulador3 & "End Try")
                Case Else
                    arclase.WriteLine(Tabulador3 & "o" & ArcClase & "." & Campo & " = r(" & Campo_Pre & ").ToString()")
            End Select
        Next
        arclase.WriteLine(Tabulador2 & "Return o" & ArcClase)
        arclase.WriteLine(Tabulador & "End Function")
    End Function
    '********************************************************************************
    Public Function Obj2Tab(ByRef arclase) As String
        Dim I As Integer
        Dim J As Integer
        Dim Campo As String
        Dim Variable As String
        Dim Tipo As String
        Dim Campo_Pre As String
        Dim CadSel As String
        Dim Primary As String
        Dim Lllave As Boolean = False
        arclase.WriteLine(Tabulador & "Private   Sub " & ArcClase & "2row(o" & ArcClase & " as " & ArcClase & ", r as Datarow)")
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(1, I).ToString
            Variable = "_" & Campo
            Campo_Pre = Chr(34) & Campo & Chr(34)
            '''For J = 1 To 200
            '''    If UCase(RTrim(Llaves(1, J))) = UCase(RTrim(ArcClase)) And UCase(RTrim(Llaves(0, J))) = UCase(RTrim(Campo)) Then
            '''        Lllave = True
            '''        Exit For
            '''    End If
            '''Next
            If Lllave Then
                arclase.WriteLine(Tabulador2 & "'r(" & Campo_Pre & ") = o" & ArcClase & "." & Campo & " Es un campo Llave")
                Lllave = False
            Else
                arclase.WriteLine(Tabulador2 & "r(" & Campo_Pre & ") = o" & ArcClase & "." & Campo)
            End If
        Next
        arclase.WriteLine(Tabulador & "End Sub")
    End Function
    '********************************************************************************
    Public Function Fil2Obj(ByRef arclase) As String
        Dim I As Integer
        Dim Campo As String
        Dim Variable As String
        Dim Tipo As String
        Dim Campo_Pre As String
        Dim Primary As String
        arclase.WriteLine(Tabulador & "Private   Sub nuevo" & ArcClase & "(dt as DataTable, o" & ArcClase & " as " & ArcClase & ")")
        arclase.WriteLine(Tabulador2 & "Dim Dr as DataRow = dt.NewRow()")
        arclase.WriteLine(Tabulador2 & "Dim oc as " & ArcClase & " = row2" & ArcClase & "(dr)")
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Variable = "_" & Campo
            Campo_Pre = Chr(34) & Campo & Chr(34)
            arclase.WriteLine(Tabulador2 & "oc." & Campo & " = o" & ArcClase & "." & Campo)
        Next
        arclase.WriteLine(Tabulador2 & ArcClase & "2row(oc,dr)")
        arclase.WriteLine(Tabulador2 & "dt.rows.add(dr)")
        arclase.WriteLine(Tabulador & "End Sub")
    End Function
    '********************************************************************************
    Public Function ObtTabla(ByRef arclase) As String
        arclase.WriteLine(Tabulador & "Public   Function Tabla() as DataTable")
        arclase.WriteLine(Tabulador2 & "Return Tabla(CadenaSelect)")
        arclase.WriteLine(Tabulador & "End function")
    End Function
    '********************************************************************************
    Public Function Lista(ByRef arclase) As String
        arclase.WriteLine(Tabulador & "Public   Function ListaCombo() as DataTable")
        arclase.WriteLine(Tabulador2 & "Dim da as SqldataAdapter")
        arclase.WriteLine(Tabulador2 & "Dim dt as New DataTable(" & Chr(34) & ArcClase & Chr(34) & ")")
        arclase.WriteLine(Tabulador2 & "Try")
        arclase.WriteLine(Tabulador3 & "da = New SqlDataAdapter(Sel, CadenaConexion)")
        arclase.WriteLine(Tabulador3 & "Da.Fill(dt)")
        arclase.WriteLine(Tabulador2 & "Catch")
        arclase.WriteLine(Tabulador3 & "Return Nothing")
        arclase.WriteLine(Tabulador2 & "End Try")
        arclase.WriteLine(Tabulador2 & "Return dt")
        arclase.WriteLine(Tabulador & "End Function")
    End Function
    '********************************************************************************
    Public Function Buscar(ByRef arclase) As String
        Dim I As Integer
        arclase.WriteLine(Tabulador & "Public   Sub Buscar()")
        arclase.WriteLine("'***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****")
        arclase.WriteLine(Tabulador2 & "sSql = " & Chr(34) & "SELECT * FROM " & ArcClase & " WHERE Campo_Llave = sClave")
        arclase.WriteLine(Tabulador2 & "Dim cmd As New SqlCommand(sSql, cn)")
        arclase.WriteLine(Tabulador2 & "Dim dr As SqlDatareader")
        arclase.WriteLine(Tabulador2 & "cn.Open()")
        arclase.WriteLine(Tabulador2 & "dr = cmd.ExecuteReader")
        arclase.WriteLine(Tabulador2 & "If dr.Read Then")
        For I = 0 To _DimensionCampos - 1
            arclase.WriteLine(Tabulador3 & "_" & Campos(0, I).ToString() & " = dr(" & Chr(34) & Campos(0, I).ToString() & Chr(34) & ")")
        Next
        arclase.WriteLine(Tabulador2 & "Else")
        For I = 0 To _DimensionCampos - 1
            arclase.WriteLine(Tabulador3 & "_" & Campos(0, I).ToString() & " = " & Chr(34) & Chr(34))
        Next
        arclase.WriteLine(Tabulador2 & "End If")
        arclase.WriteLine(Tabulador2 & "cn.Close()")
        arclase.WriteLine(Tabulador & "End Sub")
    End Function
    '********************************************************************************
    Public Function Actualiza(ByRef arclase) As String
        Dim I As Integer
        Dim Campo As String
        Dim Llave As String
        Dim isLlave As String
        For I = 0 To _DimensionCampos - 1
            isLlave = Campos(6, I).ToString
            If isLlave = "True" Then
                Campo = Campos(0, I).ToString
                Exit For
            End If
        Next
        arclase.WriteLine(Tabulador & "public Function Actualizar() as String")
        arclase.WriteLine(Tabulador2 & "Dim Sel as string = " & Chr(34) & "Select * From " & ArcClase & " Where " & Campo & " = " & Chr(34) & " & Me." & Campo & ".ToString()")
        arclase.WriteLine(Tabulador2 & "Return Actualizar(Sel)")
        arclase.WriteLine(Tabulador & "End Function")
    End Function
    '********************************************************************************
    Public Function StoreProcedures(ByRef arclase) As String
        Dim I As Integer
        Dim Campo As String
        Dim Cadena As String
        Dim Tipo As String
        Dim IsLlave As String
        Dim Longitud As String
        Dim campollave As String
        Dim Total As Integer
        arclase.WriteLine(Tabulador & "Public Function Actualizar() as String")
        arclase.WriteLine(Tabulador2 & "Dim cmd As New Sqlcommand(" & Chr(34) & "NOMBRE_STORE" & Chr(34) & ", cn)")

        Total = _DimensionCampos - 2
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            IsLlave = Campos(6, I).ToString
            If IsLlave = "True" Then
                campollave = Campo
            Else
                If I = Total Then
                    Cadena = Cadena & Campo & " = @" & Campo & ", "
                Else
                    Cadena = Cadena & Campo & " = @" & Campo & ", "
                End If
            End If
        Next
        arclase.WriteLine(Tabulador2 & "sSql =" & Chr(34) & "UPDATE " & ArcClase & " SET " & Cadena & "Where (" & campollave & " = @" & campollave & ")" & Chr(34))
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Longitud = Campos(2, I).ToString
            Select Case UCase(Tipo)
                Case "SYSTEM.STRING"
                    Tipo = "SqlDbType.NvarChar"
                Case "SYSTEM.INT32"
                    Tipo = "SqlDbType.Int"
                    Longitud = "0"
                Case "SYSTEM.INT16"
                    Tipo = "SqlDbType.Int"
                    Longitud = "0"
                Case "SYSTEM.DATETIME"
                    Tipo = "SqlDbType.Datetime"
                    Longitud = "0"
                Case Else
                    Tipo = "SqlDbType.Real"
                    Longitud = "0"
            End Select

            arclase.WriteLine(Tabulador2 & "cmd.Parameters.Add(" & Chr(34) & "@" & Campo & Chr(34) & ", " & Tipo & ", " & Longitud & ", " & Chr(34) & "_" & Campo & Chr(34) & ")")
        Next
        arclase.WriteLine(Tabulador2 & "Try")
        arclase.WriteLine(Tabulador3 & "cmd.ExecuteNonQuery()")
        arclase.WriteLine(Tabulador2 & "Catch ex As Exception")
        arclase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
        arclase.WriteLine(Tabulador2 & "End Try")

        arclase.WriteLine(Tabulador & "End Function")
        arclase.WriteLine(Tabulador & "")
        arclase.WriteLine(Tabulador & "")

        Dim CadValores As String
        Cadena = ""

        arclase.WriteLine(Tabulador & "Public Function Insertar() as String")
        arclase.WriteLine(Tabulador2 & "Dim cmd As New Sqlcommand(" & Chr(34) & "NOMBRE_STORE" & Chr(34) & ", cn)")

        Total = _DimensionCampos - 2
        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            IsLlave = Campos(6, I).ToString
            If IsLlave = "True" Then
            Else
                If I = Total Then
                    Cadena = Cadena & Campo & ")"
                    CadValores = CadValores & "@" & Campo & ")"
                Else
                    Cadena = Cadena & Campo & ", "
                    CadValores = CadValores & "@" & Campo & ", "
                End If
            End If
        Next
        arclase.WriteLine(Tabulador2 & "sSql =" & Chr(34) & "INSERT INTO " & _
        ArcClase & " (" & Cadena & " VALUES (" & CadValores & Chr(34))

        For I = 0 To _DimensionCampos - 1
            Campo = Campos(0, I).ToString()
            Tipo = Campos(12, I).ToString
            Longitud = Campos(2, I).ToString
            Select Case UCase(Tipo)
                Case "SYSTEM.STRING"
                    Tipo = "SqlDbType.NvarChar"
                Case "SYSTEM.INT32"
                    Tipo = "SqlDbType.Int"
                    Longitud = "0"
                Case "SYSTEM.INT16"
                    Tipo = "SqlDbType.Int"
                    Longitud = "0"
                Case "SYSTEM.DATETIME"
                    Tipo = "SqlDbType.Datetime"
                    Longitud = "0"
                Case Else
                    Tipo = "SqlDbType.Real"
                    Longitud = "0"
            End Select
            arclase.WriteLine(Tabulador2 & "cmd.Parameters.Add(" & Chr(34) & "@" & Campo & Chr(34) & ", " & Tipo & ", " & Longitud & ", " & Chr(34) & "_" & Campo & Chr(34) & ")")
        Next
        arclase.WriteLine(Tabulador2 & "Try")
        arclase.WriteLine(Tabulador3 & "cmd.ExecuteNonQuery()")
        arclase.WriteLine(Tabulador2 & "Catch ex As Exception")
        arclase.WriteLine(Tabulador3 & "Return " & Chr(34) & "ERROR: " & Chr(34) & " & ex.Message")
        arclase.WriteLine(Tabulador2 & "End Try")

        arclase.WriteLine(Tabulador & "End Function")
    End Function

End Module
