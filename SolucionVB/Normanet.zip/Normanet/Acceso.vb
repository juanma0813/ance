Public Class Acceso
    Inherits System.Windows.Forms.Form
    Private objConexion As New clsConexion.cIsConexion
    Private ObjUsuario As New clsUsuarios.clsUsuarios(1, "", "")

#Region " C�digo generado por el Dise�ador de Windows Forms "




    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtUsuario As System.Windows.Forms.TextBox
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
    Friend WithEvents ImgList As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Acceso))
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtUsuario = New System.Windows.Forms.TextBox
        Me.txtpassword = New System.Windows.Forms.TextBox
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ImgList = New System.Windows.Forms.ImageList(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(32, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Usuario"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(32, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Password"
        '
        'txtUsuario
        '
        Me.txtUsuario.Location = New System.Drawing.Point(96, 24)
        Me.txtUsuario.Name = "txtUsuario"
        Me.txtUsuario.Size = New System.Drawing.Size(192, 20)
        Me.txtUsuario.TabIndex = 2
        Me.txtUsuario.Text = ""
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(96, 64)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txtpassword.Size = New System.Drawing.Size(192, 20)
        Me.txtpassword.TabIndex = 3
        Me.txtpassword.Text = ""
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgList
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 104)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(336, 62)
        Me.tlbBotonera.TabIndex = 4
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 28
        Me.ToolBarButton1.Text = "Acceso"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 26
        Me.ToolBarButton2.Text = "Salir"
        '
        'ImgList
        '
        Me.ImgList.ImageSize = New System.Drawing.Size(38, 36)
        Me.ImgList.ImageStream = CType(resources.GetObject("ImgList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgList.TransparentColor = System.Drawing.Color.Transparent
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(320, 88)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'Acceso
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 166)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.txtpassword)
        Me.Controls.Add(Me.txtUsuario)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Acceso"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Acceso Normanet"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0
                Acceso()
            Case 1
                End
        End Select
    End Sub

    Private Sub Acceso_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        agregar(Me.txtUsuario)
        agregar(Me.txtpassword)
    End Sub

    Private Sub Acceso()
#If DEBUG Then
        txtUsuario.Text = "admsis"
        txtpassword.Text = "admynsys"
        'txtUsuario.Text = "sa"
        'txtpassword.Text = "0000"
#End If

        If txtUsuario.Text = "" Or txtpassword.Text = "" Then Exit Sub
        gUsuario = txtUsuario.Text
        'Sirve para Verificar que el usaurio exista en la BD de DbAnce
        ' ObjUsuario.Nombre_Usuario(gUsuario)
        'sirve para validar sus permisos en sql del usuario
        iId_Sistema = 16
        If ObjUsuario.Acceso(gUsuario, txtpassword.Text, "16") Then
            iGrupo = ObjUsuario.Grupo
            ObjUsuario.Conexion(gUsuario)
            gPasswordSql = txtpassword.Text

            If gUsuario = "ADMSIS" Or gUsuario = "admsis" Or gUsuario = "sa" Then
                stUsuario = "ADMINISTRADOR"
            Else
                stUsuario = txtUsuario.Text
            End If

            Me.Hide()
            frmMenu.Show()

            REM Me.Hide()
        Else
            MessageBox.Show("El Usuario no Existe, favor de Verificar", "Error de Acceso", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1)
            txtUsuario.SelectAll()
        End If
    End Sub

    Private Sub EnterBox(ByVal sender As System.Object, ByVal e As KeyPressEventArgs)
        If e.KeyChar = Convert.ToChar(Keys.Return) Then 'si el evento es <enrter> entra
            Call Acceso()
        End If
    End Sub

    Function agregar(ByVal caja As TextBox) 'introduce los eventos de los texbox para capturar el >enter>
        AddHandler caja.KeyPress, New System.Windows.Forms.KeyPressEventHandler(AddressOf EnterBox)
    End Function

    Private Sub txtUsuario_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUsuario.TextChanged

    End Sub

    Private Sub txtpassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpassword.TextChanged

    End Sub
End Class
