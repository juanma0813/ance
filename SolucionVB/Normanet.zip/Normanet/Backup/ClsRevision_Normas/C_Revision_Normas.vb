
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_Revision_Normas Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 18/10/2006 10:41:15 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class C_Revision_Normas

     '''''''Declaracion de Variables Privadas
     Private dsC_Revision_Normas AS New DataSet
    Private _Id_RevisionNorma As Integer
     Private _Descripcion as System.String
     Private sSql as String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo
     '''''''Declaracion de Propiedades publicas
    Public Property Id_RevisionNorma() As Integer
        Get
            Return _Id_RevisionNorma
        End Get
        Set(ByVal Value As Integer)
            _Id_RevisionNorma = Value
        End Set
    End Property

    Public Property Descripcion() As System.String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As System.String)
            _Descripcion = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub
    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Revision_Normas")
        Try
            da = New SqlDataAdapter("Select * from c_Revision_Normas", cn)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As Integer) As C_Revision_Normas
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM c_Revision_Normas WHERE Id_RevisionNorma = '" & sClave & "'"
        Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da.Fill(dsC_Revision_Normas, "C_Encontrado")
        cn.Close()
        If dsC_Revision_Normas.Tables("C_Encontrado").Rows.Count > 0 Then
            _Id_RevisionNorma = dsC_Revision_Normas.Tables("C_Encontrado").Rows(0).Item("Id_RevisionNorma")
            _Descripcion = dsC_Revision_Normas.Tables("C_Encontrado").Rows(0).Item("Descripcion")
        Else
            _Id_RevisionNorma = 0
            _Descripcion = ""
        End If
        dsC_Revision_Normas.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE C_Revision_Normas SET Id_RevisionNorma = @Id_RevisionNorma, Descripcion = @Descripcion, Where ( = @)"
        cmd.Parameters.Add("@Id_RevisionNorma", SqlDbType.Int, 0, "_Id_RevisionNorma")
        cmd.Parameters.Add("@Descripcion", SqlDbType.NVarChar, 50, "_Descripcion")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "INSERT INTO C_Revision_Normas (Id_RevisionNorma)Descripcion,  VALUES (@Id_RevisionNorma)@Descripcion, "
        cmd.Parameters.Add("@Id_RevisionNorma", SqlDbType.Int, 0, "_Id_RevisionNorma")
        cmd.Parameters.Add("@Descripcion", SqlDbType.NVarChar, 50, "_Descripcion")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
