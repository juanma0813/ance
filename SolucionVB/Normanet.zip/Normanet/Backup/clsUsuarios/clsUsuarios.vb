'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
'   NOMBRE DE LA CLASE: CLASE DE USUARIOS DE VISITAS DE SEGUIMIENTO
'   DESARROLLADA POR : EXTI, S.C. PARA ANCE, A.C.
'                      EMMANUEL ESPINOSA JUAREZ 
'   FECHA: 30 SEPTIEMBRE 2005
'
'   BASES RELACIONADAS: dbANCE
'
'   TIPO: SOLO LECTURA
'
'   DESCRIPCION: ENLISTA TODOS LOS USUARIOS DE LA BASE EN TOMADAS DE LA TABLA C_EMPLEADOS VERIFICA QUE EL USUARIO
'                EXISTA VALIDA SU PASSWORD E IDENTIFICA A QUE GRUPO PERTENECE, BUSCA EL PASSWORD DE SQL ASIGNADO
'                AL USUARIO TOMANDO COMO REFERENCIA LA TABLA C_Empleados_Sistema
'
'   FECHA MODIFICACION: 17/01/06
'   MODIFICACION REALIZADA: SE AGREGO EL METODO "Nombre_Usuario" QUE RECUPERA EL NOMBRE COMPLETO DEL USUARIO QUE
'                           SE LOGUEA PARA MOSTRARLO EN EL STATUS BAR
'
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class clsUsuarios
    Private cn As New SqlClient.SqlConnection
    Private dsGrupo As New DataSet
    Private objConexion As New clsConexionArchivo.clsConexionArchivo
    Private sSql As String
    Private sId_Usuario As String
    Private sNombre As String
    Private sPasswordSql As String
    'EEJ: nos servira para identificar el grupo para poder hacer la conexion correcta del usuario
    Private iGrupo As Integer
    Private _Usuario As String


    Public Property Id_Usuario()
        Get
            Id_Usuario = sId_Usuario
        End Get
        Set(ByVal Value)
            Id_Usuario = Value
        End Set
    End Property

    Public Property Nombre()
        Get
            Nombre = sNombre
        End Get
        Set(ByVal Value)
            sNombre = Value
        End Set
    End Property

    Public Property Grupo()
        Get
            Grupo = iGrupo
        End Get
        Set(ByVal Value)
            iGrupo = Value
        End Set
    End Property

    Public Property PasswordSql()
        Get
            PasswordSql = sPasswordSql
        End Get
        Set(ByVal Value)
            sPasswordSql = Value
        End Set
    End Property

    Public Property Usuario()
        Get
            Usuario = _Usuario
        End Get
        Set(ByVal Value)
            _Usuario = Value
        End Set
    End Property

    '''LHMG
    '''Enlista todos los Usuarios de la base dbANCE en la tabla de C_Empleados
    Public Sub Lista(ByRef ds As DataSet)
        sSql = "Select * FROM C_Empleados "
        sSql = sSql + " Order by 2"
        Dim ad As New SqlDataAdapter(sSql, cn)

        cn.Open()
        ad.Fill(ds, "C_Usuarios")
        cn.Close()

    End Sub

    '''''LHMG
    '''''Busca que un Usuario este registrado en C_Empleados
    '''''valida su password e identifica el grupo al ke pertenece
    Public Function Acceso(ByVal sUsuario As String, ByVal sPassword As String, ByVal sSistema As String) As Boolean
        Dim iEncontrado As Integer

        sSql = "SELECT Count(Id_Usuario)as Encontrado FROM C_Empleados WHERE Id_Usuario = '" + sUsuario + "'"
        Dim cmd As New SqlCommand(sSql, cn)
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()

            iEncontrado = cmd.ExecuteNonQuery()
        Catch ex As Exception
            REM Return False
            iEncontrado = 0
            MsgBox(ex.Message)
        End Try


        If iEncontrado <> 0 Then
            Id_Grupo(sUsuario, sSistema, sPassword)
            If iGrupo = 0 Then
                Return False
            Else
                Return True
            End If
        Else
            Return False
        End If

    End Function

    ''EEJ 19/09/05: 
    ''En base al usuario y al sistema se valida el password y se obtine el grupo al cual pertenece el usuario
    Private Sub Id_Grupo(ByVal sUsuario As String, ByVal sSistema As String, ByVal sPassword As String)
        sSql = "SELECT Id_Grupo, Password FROM C_Empleados_Sistema WHERE Id_Usuario= '" + sUsuario + "' AND ID_Sistema = " + sSistema + " AND Password = '" + sPassword + "' order by id_grupo desc"

        Dim ad As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        ad.Fill(dsGrupo, "C_Grupo")

        If dsGrupo.Tables("C_Grupo").Rows.Count > 0 Then
            iGrupo = dsGrupo.Tables("C_Grupo").Rows(0).Item("Id_Grupo")
        Else
            iGrupo = 0
            MessageBox.Show("Usuario o Password Incorrecto!!", "Verificar Datos", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
        End If
        cn.Close()

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    ''EEJ: 21/09/05
    ''Busca el Password de SQL asignado al usuario tomando como referencia la tabla C_Empleados_sistema
    Public Sub Conexion(ByVal sUsuario As String)
        Dim sPassword As String


        sSql = "SELECT Password FROM C_Empleados_Sistema WHERE ID_Usuario = '" + sUsuario + "' AND Id_Sistema = 0 AND Id_Grupo = 0 "
        Dim ad As New SqlDataAdapter(sSql, cn)
        cn.Open()
        ad.Fill(dsGrupo, "C_Password")
        cn.Close()
        If dsGrupo.Tables("C_Password").Rows.Count > 0 Then
            sPasswordSql = dsGrupo.Tables("C_Password").Rows(0).Item("Password")
        End If

    End Sub

    ''EEJ: 17/01/06
    ''Traigo el nombre completo del usuario para mostrarlor en el status bar
    Public Sub Nombre_Usuario(ByVal Usuario As String)
        Dim cmd As New SqlCommand

        sSql = "SELECT AN_EMP.NOMP_EMP + ' ' + dbo.AN_EMP.AP_PATER + ' ' + dbo.AN_EMP.AP_MATER AS Nombre"
        sSql += " FROM C_Empleados INNER JOIN AN_EMP ON C_Empleados.Nom_Emp = AN_EMP.NUM_EMP"
        sSql += " WHERE C_Empleados.Id_Usuario = '" & Usuario & "'"
        cn.Open()
        cmd.Connection = cn
        cmd.CommandText = sSql
        _Usuario = cmd.ExecuteScalar
        cn.Close()
        cmd.Dispose()

    End Sub

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        ''EEJ: 21/09/05
        ''Conexion con el archivo .ini para conextarse con el usuario ke inicio la sesion de trabajo
        sSql = objConexion.Conexion(1, Usuario, Password)
        cn.ConnectionString = sSql

    End Sub

End Class
