Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Collections


Public Class FrmSesiones
    Inherits System.Windows.Forms.Form

#Region "  Otras Variables"

    Private oVista As DataView
    Dim dvComite As DataView
    Dim dvCT As DataView
    Dim dvC As DataView
    Dim dvGT As DataView
    Dim DTRes As New DataTable ''' datos editables para restaurar
    Dim DTResTem As New DataTable ''' datos editables para restaurar
    Dim DTResArch As New DataTable ''' datos editables para restaurar
    Dim existe, Accion As Boolean
    Dim ValEditar As Integer
    Dim sError, iEditar, sValTreeView, sFechaPk, shoraiPk, shoratPk, sReubica, spath As String
    Dim sesion, i, solicitud, istasol, istasesion As Integer
    Public sPasada As String
    Public stema As Integer
    Public splan As String
    Public srefp As String
    Public giStatus As Integer

#End Region

#Region " Inicializaci�n de   Dll's"
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objsesiones As New Cls_Sesiones.Cls_sesiones("principal", gUsuario, gPasswordSql)
    Dim objplanes As New ClsPlan.P_Plan(0, gUsuario, gPasswordSql)
    Dim objprogtrab As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Dim objsalas As New Cls_Salas.Cls_Salas("EXTRA", gUsuario, gPasswordSql)
    Dim objiniarray As New clsIniarray.ClsIniArray
    Dim objComites As New clsComites.clsComites("Principal", gUsuario, gPasswordSql)

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()


        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
        objplanes.Inicializa(0, gUsuario, gPasswordSql)
        objempleados.Inicializa(Application.StartupPath & "\principal.ini", "comun", gUsuario, gPasswordSql)

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents tvComites As System.Windows.Forms.TreeView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GridTemas As System.Windows.Forms.DataGrid
    Friend WithEvents GridArchivos As System.Windows.Forms.DataGrid
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CboResponsable As System.Windows.Forms.ComboBox

    Friend WithEvents CboSesiones As System.Windows.Forms.ComboBox
    Friend WithEvents DTPker As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtAsunto As System.Windows.Forms.TextBox
    Friend WithEvents TxtLugar As System.Windows.Forms.TextBox
    Friend WithEvents TxtNo_Sol_Sala As System.Windows.Forms.TextBox
    Friend WithEvents LblSol As System.Windows.Forms.Label
    Friend WithEvents Lblsal As System.Windows.Forms.Label
    Friend WithEvents CkBxSalasANCE As System.Windows.Forms.CheckBox
    Friend WithEvents Lblchksala As System.Windows.Forms.Label
    Friend WithEvents lblGridTemas As System.Windows.Forms.Label
    Friend WithEvents LblGridArchivos As System.Windows.Forms.Label
    Friend WithEvents lblSesiones As System.Windows.Forms.Label
    Friend WithEvents CboEquipo As System.Windows.Forms.ComboBox
    Friend WithEvents Lblcounttemas As System.Windows.Forms.Label
    Friend WithEvents LblcountArch As System.Windows.Forms.Label
    Friend WithEvents TxtNotas As System.Windows.Forms.TextBox
    Friend WithEvents lblNotas As System.Windows.Forms.Label
    Friend WithEvents Lblhi As System.Windows.Forms.Label
    Friend WithEvents Lblht As System.Windows.Forms.Label
    Friend WithEvents LblTreeView As System.Windows.Forms.Label
    Friend WithEvents Lblcomite As System.Windows.Forms.Label
    Friend WithEvents DTPkrhoraini As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPkrhoratem As System.Windows.Forms.DateTimePicker
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents cbosalas As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmSesiones))
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.lblSesiones = New System.Windows.Forms.Label
        Me.tvComites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.DTPker = New System.Windows.Forms.DateTimePicker
        Me.Lblhi = New System.Windows.Forms.Label
        Me.TxtAsunto = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TxtLugar = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblGridTemas = New System.Windows.Forms.Label
        Me.GridTemas = New System.Windows.Forms.DataGrid
        Me.GridArchivos = New System.Windows.Forms.DataGrid
        Me.LblGridArchivos = New System.Windows.Forms.Label
        Me.TxtNo_Sol_Sala = New System.Windows.Forms.TextBox
        Me.LblSol = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.CboResponsable = New System.Windows.Forms.ComboBox
        Me.Lblsal = New System.Windows.Forms.Label
        Me.CboSesiones = New System.Windows.Forms.ComboBox
        Me.CkBxSalasANCE = New System.Windows.Forms.CheckBox
        Me.Lblchksala = New System.Windows.Forms.Label
        Me.CboEquipo = New System.Windows.Forms.ComboBox
        Me.Lblcounttemas = New System.Windows.Forms.Label
        Me.LblcountArch = New System.Windows.Forms.Label
        Me.TxtNotas = New System.Windows.Forms.TextBox
        Me.lblNotas = New System.Windows.Forms.Label
        Me.Lblht = New System.Windows.Forms.Label
        Me.LblTreeView = New System.Windows.Forms.Label
        Me.Lblcomite = New System.Windows.Forms.Label
        Me.DTPkrhoraini = New System.Windows.Forms.DateTimePicker
        Me.DTPkrhoratem = New System.Windows.Forms.DateTimePicker
        Me.cbosalas = New System.Windows.Forms.ComboBox
        CType(Me.GridTemas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridArchivos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 553)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(746, 62)
        Me.tlbBotonera.TabIndex = 16
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'lblSesiones
        '
        Me.lblSesiones.AutoSize = True
        Me.lblSesiones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSesiones.Location = New System.Drawing.Point(256, 19)
        Me.lblSesiones.Name = "lblSesiones"
        Me.lblSesiones.Size = New System.Drawing.Size(82, 16)
        Me.lblSesiones.TabIndex = 49
        Me.lblSesiones.Text = "Clave Sesion: "
        '
        'tvComites
        '
        Me.tvComites.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tvComites.ImageList = Me.imgListTreeView
        Me.tvComites.Location = New System.Drawing.Point(8, 48)
        Me.tvComites.Name = "tvComites"
        Me.tvComites.SelectedImageIndex = 1
        Me.tvComites.Size = New System.Drawing.Size(240, 496)
        Me.tvComites.TabIndex = 0
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(288, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 16)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "Fecha: "
        '
        'DTPker
        '
        Me.DTPker.CustomFormat = "dd/MM/yyyy"
        Me.DTPker.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPker.Location = New System.Drawing.Point(341, 46)
        Me.DTPker.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DTPker.Name = "DTPker"
        Me.DTPker.Size = New System.Drawing.Size(163, 20)
        Me.DTPker.TabIndex = 1
        '
        'Lblhi
        '
        Me.Lblhi.AutoSize = True
        Me.Lblhi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblhi.Location = New System.Drawing.Point(536, 19)
        Me.Lblhi.Name = "Lblhi"
        Me.Lblhi.Size = New System.Drawing.Size(74, 16)
        Me.Lblhi.TabIndex = 55
        Me.Lblhi.Text = "Comienza a: "
        '
        'TxtAsunto
        '
        Me.TxtAsunto.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAsunto.Location = New System.Drawing.Point(341, 80)
        Me.TxtAsunto.Multiline = True
        Me.TxtAsunto.Name = "TxtAsunto"
        Me.TxtAsunto.Size = New System.Drawing.Size(395, 43)
        Me.TxtAsunto.TabIndex = 7
        Me.TxtAsunto.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(288, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 16)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "Asunto: "
        '
        'TxtLugar
        '
        Me.TxtLugar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLugar.Location = New System.Drawing.Point(341, 134)
        Me.TxtLugar.Name = "TxtLugar"
        Me.TxtLugar.Size = New System.Drawing.Size(208, 20)
        Me.TxtLugar.TabIndex = 8
        Me.TxtLugar.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(288, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 16)
        Me.Label4.TabIndex = 61
        Me.Label4.Text = "Lugar: "
        '
        'lblGridTemas
        '
        Me.lblGridTemas.AutoSize = True
        Me.lblGridTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGridTemas.Location = New System.Drawing.Point(288, 168)
        Me.lblGridTemas.Name = "lblGridTemas"
        Me.lblGridTemas.Size = New System.Drawing.Size(47, 16)
        Me.lblGridTemas.TabIndex = 63
        Me.lblGridTemas.Text = "Temas: "
        '
        'GridTemas
        '
        Me.GridTemas.AllowDrop = True
        Me.GridTemas.AllowNavigation = False
        Me.GridTemas.BackgroundColor = System.Drawing.Color.White
        Me.GridTemas.CaptionVisible = False
        Me.GridTemas.DataMember = ""
        Me.GridTemas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridTemas.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.GridTemas.HeaderBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GridTemas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GridTemas.Location = New System.Drawing.Point(341, 168)
        Me.GridTemas.Name = "GridTemas"
        Me.GridTemas.Size = New System.Drawing.Size(395, 120)
        Me.GridTemas.TabIndex = 10
        '
        'GridArchivos
        '
        Me.GridArchivos.AllowNavigation = False
        Me.GridArchivos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GridArchivos.BackgroundColor = System.Drawing.Color.White
        Me.GridArchivos.CaptionVisible = False
        Me.GridArchivos.DataMember = ""
        Me.GridArchivos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridArchivos.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.GridArchivos.HeaderBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GridArchivos.HeaderFont = New System.Drawing.Font("Arial", 9.290323!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GridArchivos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GridArchivos.Location = New System.Drawing.Point(341, 300)
        Me.GridArchivos.Name = "GridArchivos"
        Me.GridArchivos.Size = New System.Drawing.Size(395, 120)
        Me.GridArchivos.TabIndex = 11
        '
        'LblGridArchivos
        '
        Me.LblGridArchivos.AccessibleName = "+-"
        Me.LblGridArchivos.AutoSize = True
        Me.LblGridArchivos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblGridArchivos.Location = New System.Drawing.Point(272, 300)
        Me.LblGridArchivos.Name = "LblGridArchivos"
        Me.LblGridArchivos.Size = New System.Drawing.Size(60, 16)
        Me.LblGridArchivos.TabIndex = 65
        Me.LblGridArchivos.Text = "Archivos: "
        '
        'TxtNo_Sol_Sala
        '
        Me.TxtNo_Sol_Sala.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TxtNo_Sol_Sala.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNo_Sol_Sala.Location = New System.Drawing.Point(597, 518)
        Me.TxtNo_Sol_Sala.Name = "TxtNo_Sol_Sala"
        Me.TxtNo_Sol_Sala.Size = New System.Drawing.Size(139, 20)
        Me.TxtNo_Sol_Sala.TabIndex = 68
        Me.TxtNo_Sol_Sala.Text = ""
        '
        'LblSol
        '
        Me.LblSol.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LblSol.AutoSize = True
        Me.LblSol.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSol.Location = New System.Drawing.Point(541, 520)
        Me.LblSol.Name = "LblSol"
        Me.LblSol.Size = New System.Drawing.Size(59, 16)
        Me.LblSol.TabIndex = 69
        Me.LblSol.Text = "Solicitud: "
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(256, 488)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 16)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "Responsable: "
        '
        'CboResponsable
        '
        Me.CboResponsable.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CboResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboResponsable.Location = New System.Drawing.Point(341, 485)
        Me.CboResponsable.Name = "CboResponsable"
        Me.CboResponsable.Size = New System.Drawing.Size(395, 22)
        Me.CboResponsable.TabIndex = 13
        '
        'Lblsal
        '
        Me.Lblsal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Lblsal.AutoSize = True
        Me.Lblsal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblsal.Location = New System.Drawing.Point(304, 520)
        Me.Lblsal.Name = "Lblsal"
        Me.Lblsal.Size = New System.Drawing.Size(34, 16)
        Me.Lblsal.TabIndex = 73
        Me.Lblsal.Text = "Sala: "
        '
        'CboSesiones
        '
        Me.CboSesiones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.CboSesiones.Enabled = False
        Me.CboSesiones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboSesiones.Location = New System.Drawing.Point(341, 16)
        Me.CboSesiones.Name = "CboSesiones"
        Me.CboSesiones.Size = New System.Drawing.Size(163, 21)
        Me.CboSesiones.TabIndex = 1
        '
        'CkBxSalasANCE
        '
        Me.CkBxSalasANCE.Location = New System.Drawing.Point(717, 136)
        Me.CkBxSalasANCE.Name = "CkBxSalasANCE"
        Me.CkBxSalasANCE.Size = New System.Drawing.Size(16, 16)
        Me.CkBxSalasANCE.TabIndex = 9
        Me.CkBxSalasANCE.Visible = False
        '
        'Lblchksala
        '
        Me.Lblchksala.AutoSize = True
        Me.Lblchksala.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblchksala.Location = New System.Drawing.Point(573, 136)
        Me.Lblchksala.Name = "Lblchksala"
        Me.Lblchksala.Size = New System.Drawing.Size(127, 16)
        Me.Lblchksala.TabIndex = 75
        Me.Lblchksala.Text = "Solicitar Sala a ANCE: "
        Me.Lblchksala.Visible = False
        '
        'CboEquipo
        '
        Me.CboEquipo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CboEquipo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboEquipo.Location = New System.Drawing.Point(597, 517)
        Me.CboEquipo.Name = "CboEquipo"
        Me.CboEquipo.Size = New System.Drawing.Size(139, 22)
        Me.CboEquipo.TabIndex = 15
        '
        'Lblcounttemas
        '
        Me.Lblcounttemas.AutoSize = True
        Me.Lblcounttemas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblcounttemas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Lblcounttemas.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.Lblcounttemas.Location = New System.Drawing.Point(320, 192)
        Me.Lblcounttemas.Name = "Lblcounttemas"
        Me.Lblcounttemas.Size = New System.Drawing.Size(12, 18)
        Me.Lblcounttemas.TabIndex = 79
        Me.Lblcounttemas.Text = "0"
        '
        'LblcountArch
        '
        Me.LblcountArch.AutoSize = True
        Me.LblcountArch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblcountArch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblcountArch.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblcountArch.Location = New System.Drawing.Point(320, 326)
        Me.LblcountArch.Name = "LblcountArch"
        Me.LblcountArch.Size = New System.Drawing.Size(12, 18)
        Me.LblcountArch.TabIndex = 80
        Me.LblcountArch.Text = "0"
        '
        'TxtNotas
        '
        Me.TxtNotas.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TxtNotas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNotas.Location = New System.Drawing.Point(341, 432)
        Me.TxtNotas.Multiline = True
        Me.TxtNotas.Name = "TxtNotas"
        Me.TxtNotas.Size = New System.Drawing.Size(395, 43)
        Me.TxtNotas.TabIndex = 12
        Me.TxtNotas.Text = ""
        '
        'lblNotas
        '
        Me.lblNotas.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblNotas.AutoSize = True
        Me.lblNotas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotas.Location = New System.Drawing.Point(296, 432)
        Me.lblNotas.Name = "lblNotas"
        Me.lblNotas.Size = New System.Drawing.Size(39, 16)
        Me.lblNotas.TabIndex = 81
        Me.lblNotas.Text = "Nota:  "
        '
        'Lblht
        '
        Me.Lblht.AutoSize = True
        Me.Lblht.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblht.Location = New System.Drawing.Point(536, 48)
        Me.Lblht.Name = "Lblht"
        Me.Lblht.Size = New System.Drawing.Size(65, 16)
        Me.Lblht.TabIndex = 83
        Me.Lblht.Text = "Termina a: "
        '
        'LblTreeView
        '
        Me.LblTreeView.AutoSize = True
        Me.LblTreeView.Font = New System.Drawing.Font("Arial", 7.75!)
        Me.LblTreeView.Location = New System.Drawing.Point(16, 32)
        Me.LblTreeView.Name = "LblTreeView"
        Me.LblTreeView.Size = New System.Drawing.Size(0, 15)
        Me.LblTreeView.TabIndex = 84
        Me.LblTreeView.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Lblcomite
        '
        Me.Lblcomite.AutoSize = True
        Me.Lblcomite.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblcomite.Location = New System.Drawing.Point(8, 8)
        Me.Lblcomite.Name = "Lblcomite"
        Me.Lblcomite.Size = New System.Drawing.Size(126, 16)
        Me.Lblcomite.TabIndex = 85
        Me.Lblcomite.Text = "Comite Seleccionado: "
        '
        'DTPkrhoraini
        '
        Me.DTPkrhoraini.CustomFormat = "HH:mm"
        Me.DTPkrhoraini.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoraini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoraini.Location = New System.Drawing.Point(632, 16)
        Me.DTPkrhoraini.Name = "DTPkrhoraini"
        Me.DTPkrhoraini.ShowUpDown = True
        Me.DTPkrhoraini.Size = New System.Drawing.Size(104, 20)
        Me.DTPkrhoraini.TabIndex = 86
        Me.DTPkrhoraini.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'DTPkrhoratem
        '
        Me.DTPkrhoratem.CustomFormat = "HH:mm "
        Me.DTPkrhoratem.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoratem.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoratem.Location = New System.Drawing.Point(632, 45)
        Me.DTPkrhoratem.Name = "DTPkrhoratem"
        Me.DTPkrhoratem.ShowUpDown = True
        Me.DTPkrhoratem.Size = New System.Drawing.Size(104, 20)
        Me.DTPkrhoratem.TabIndex = 87
        Me.DTPkrhoratem.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'cbosalas
        '
        Me.cbosalas.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cbosalas.Location = New System.Drawing.Point(344, 518)
        Me.cbosalas.Name = "cbosalas"
        Me.cbosalas.Size = New System.Drawing.Size(184, 21)
        Me.cbosalas.TabIndex = 88
        Me.cbosalas.Text = "ComboBox1"
        '
        'FrmSesiones
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(746, 615)
        Me.Controls.Add(Me.cbosalas)
        Me.Controls.Add(Me.DTPkrhoratem)
        Me.Controls.Add(Me.DTPkrhoraini)
        Me.Controls.Add(Me.Lblcomite)
        Me.Controls.Add(Me.Lblht)
        Me.Controls.Add(Me.TxtNotas)
        Me.Controls.Add(Me.lblNotas)
        Me.Controls.Add(Me.LblcountArch)
        Me.Controls.Add(Me.Lblcounttemas)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.LblGridArchivos)
        Me.Controls.Add(Me.lblGridTemas)
        Me.Controls.Add(Me.Lblhi)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblSesiones)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.Lblchksala)
        Me.Controls.Add(Me.Lblsal)
        Me.Controls.Add(Me.LblSol)
        Me.Controls.Add(Me.TxtLugar)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtAsunto)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtNo_Sol_Sala)
        Me.Controls.Add(Me.CboSesiones)
        Me.Controls.Add(Me.LblTreeView)
        Me.Controls.Add(Me.CboResponsable)
        Me.Controls.Add(Me.GridArchivos)
        Me.Controls.Add(Me.GridTemas)
        Me.Controls.Add(Me.DTPker)
        Me.Controls.Add(Me.tvComites)
        Me.Controls.Add(Me.CkBxSalasANCE)
        Me.Controls.Add(Me.CboEquipo)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(754, 649)
        Me.Name = "FrmSesiones"
        Me.Text = "Sesiones"
        CType(Me.GridTemas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridArchivos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

#Region "Sub -  Habilita(Etapa), Metodos y Procesos"

    Private Sub Habilita(ByVal Etapa As String)
        With tlbBotonera
            Select Case Etapa
                Case "Nulo"
                    Activos(.Buttons(1), .Buttons(2), .Buttons(5))
                    Inactivos(.Buttons(3), .Buttons(4))
                Case "Agregar"
                    Inactivos(.Buttons(1), .Buttons(2), .Buttons(5))
                    Activos(.Buttons(3), .Buttons(4))
            End Select
        End With

    End Sub

#End Region

#Region " Sub - Finalize, Metodos y Procesos"

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

#End Region

#Region "Sub  Regresa_path, Metodos y Procesos"

    Public Function Regresa_Path(ByVal lblarray As Array) As String

        Select Case UCase(Mid(lblarray(lblarray.Length - 1), 1, 3))
            Case "CT "
                Return lblarray(0) + " \ " + lblarray(1) + " \ NA \ NA"

            Case "SC "
                Select Case lblarray.Length
                    Case 2
                        Return lblarray(0) + " \ NA \ " + lblarray(1) + " \ NA"
                    Case 3
                        Return lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ NA"
                End Select
            Case "GT "
                Select Case lblarray.Length
                    Case 2
                        Return lblarray(0) + " \ NA \ NA \ " + lblarray(1)
                    Case 3
                        If UCase(Mid(lblarray(1), 1, 2)) = "CT" Then
                            Return lblarray(0) + " \ " + lblarray(1) + " \ NA \ " + lblarray(2)
                        ElseIf UCase(Mid(lblarray(1), 1, 2)) = "SC" Then
                            Return lblarray(0) + " \ NA \ " + lblarray(1) + " \ " + lblarray(2)
                        End If
                    Case 4
                        Return lblarray(0) + " \ " + lblarray(1) + " \ " + lblarray(2) + " \ " + lblarray(3)
                End Select
            Case ""
                Return "NA \ NA \ NA \ NA"
            Case Else
                Select Case lblarray.Length
                    Case 0
                        Return "NA \ NA \ NA \ NA"
                    Case 1
                        Return lblarray(0) + " \ NA \ NA \ NA"
                    Case Else
                        Dim regresai As String
                        Dim i As Integer
                        For i = 0 To lblarray.Length - 2
                            If i = 0 Then regresai = lblarray(0) Else regresai = regresai + " \ " + lblarray(i)
                        Next
                        Return Regresa_Path(Split(regresai, " \ "))
                End Select

        End Select
    End Function

#End Region

#Region " Funciones - Eliminar, Metodos y Procesos"

    Private Function Eliminar() As Boolean
        With objsesiones
            Dim sesion2 As Integer
            Dim dr As DataRow
            .Id_Sesion = CboSesiones.SelectedValue
            .Bandera = 2
            DTRes = .Listar
            dr = DTRes.Rows(0)
            istasesion = dr(3)
            .Status = 3
            .Bandera = 13
            Try
                Accion = .Actualizar()
                'ErrorProvider1.SetError(CboSesiones, "Eliminaste esta Sesion : " + Chr(13) + Chr(13) + CStr(.Id_Sesion))
            Catch ex As Exception When Accion = False
                MsgBox("Error G001 - Al intentar Eliminar Registro..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                Restaurar("agrega-borra", CboSesiones.SelectedValue)
                Return False
            End Try
            Return True
        End With
    End Function

#End Region

#Region " Guarda Datos"

    Private Function guardar() As Boolean
        Dim dt As New DataTable
        Dim dr As DataRow
        Dim dr2 As DataRow
        Dim array_texto As Array
        Dim i As Integer
        Try
            array_texto = Split(Regresa_Path(Split(LblTreeView.Text, " - ")), " \ ")
            'If valida("comites") And valida("dtpker") And valida("Horario") And valida("Asunto") Then
            If valida("comites") And valida("Horario") And valida("Asunto") Then
                Select Case iEditar

                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''-----------------------------------------------------------------------------------------------------------------------------------------------
                Case "Agregar"                              '''------------------- Agregar ------------------
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''---------------------------------------------------------------------------------------------------------------------------------------------

                        With objsesiones
                            ''''''''''''''''''''''''''''' Inserta datos en P_sesion, nuevo registro ''''''''''''''''''''''''''''' 

                            .Id_Comite = array_texto(0)
                            .Id_CT = array_texto(1)
                            .Id_SC = array_texto(2)
                            .Id_Grupo = array_texto(3)

                            .Fecha = DTPker.Value
                            .HoraI = Format(DTPkrhoraini.Value, "HH:mm")
                            .HoraT = Format(DTPkrhoratem.Value, "HH:mm")
                            .Asunto = TxtAsunto.Text
                            .Lugar = TxtLugar.Text
                            .Responsable = CboResponsable.SelectedValue
                            .Notas = TxtNotas.Text
                            If sPasada = "pasada" Then
                                .Status = 2
                            Else
                                .Status = 1
                            End If

                            .Bandera = 1
                            Try
                                Accion = .Insertar()
                                sesion = .Id_Sesion
                            Catch ex As Exception When Accion = False
                                MsgBox("Error G001 - Al intentar guardar Registro..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                Restaurar("agrega-borra", .Id_Sesion)
                                Return False
                            End Try
                            ''''''''''''''''''''''''''''' Inserta datos en P_sesion_temas, nuevo registro ''''''''''''''''''''''''''''' 
                            .Bandera = 4
                            dt = .Listar()
                            DTTemas = GridTemas.DataSource()
                            If DTTemas.Rows.Count > 0 Then
                                For i = 0 To DTTemas.Rows.Count - 1
                                    Accion = validagrid("temas 1 2 3", i)
                                    If Not Accion Then
                                        MsgBox("Error G002 - Al intentar guardar o leer el  Registro de Temas..." + Chr(13), MsgBoxStyle.Critical)
                                        Restaurar("agrega-borra", sesion)
                                        Return False
                                    End If
                                Next
                                Try
                                    For Each dr In DTTemas.Rows
                                        existe = False
                                        For Each dr2 In dt.Rows
                                            If dr(0) <> dr2(0) And dr(1) <> dr2(1) Then existe = True
                                        Next
                                        If Not existe And IIf(IsDBNull(dr(3)), 0, dr(3)) = 0 Then
                                            stema = dr(1)
                                            splan = dr(0)
                                            Referenciar("abandono")

                                            .Id_Plan = dr(0)
                                            .Id_tema = dr(1)
                                            .Inactivo = 0
                                            .Bandera = 2
                                            .RefA�o = ObjPrograma.RefA�o
                                            .RefComite = ObjPrograma.RefComite
                                            .RefConsecutivo = ObjPrograma.RefConsecutivo
                                            .RefRegreso = ObjPrograma.RefRegreso
                                            .RefTraspaso = ObjPrograma.RefTraspaso

                                            Try
                                                Accion = .Insertar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G004 - Al intentar guardar o leer el  Registro de Temas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("agrega-borra", sesion)
                                                Return False
                                            End Try
                                        End If
                                    Next
                                    dt = Nothing
                                Catch ex As Exception
                                    MsgBox("Error G005 - Al intentar guardar Registro de Temas..." + ex.Message, MsgBoxStyle.Critical)
                                    Return False
                                End Try
                            Else
                                MsgBox("Error G003 - No asignaste ningun Tema..." + Chr(13) + Chr(13) + "Debes asignar un tema a esta sesion por lo menos.", MsgBoxStyle.Critical)
                                ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un Plan y un tema para una sesion.")
                                Restaurar("agrega-borra", sesion)
                                Return False
                            End If
                            ''''''''''''''''''''''''''''' Inserta datos en P_sesion_doctos, nuevo registro ''''''''''''''''''''''''''''' 
                            .Bandera = 5
                            dt = .Listar()
                            DTArchivos = GridArchivos.DataSource()
                            If DTArchivos.Rows.Count > 0 Then
                                For i = 0 To DTArchivos.Rows.Count - 1
                                    Accion = validagrid("archivos 1 3 2", i)
                                    If Not Accion Then
                                        MsgBox("Error G006 - Debes activar o desactivar la casilla, en la columna de Activar." + Chr(13) + Chr(13) + "En la linea " + CStr(i + 1) + ".", MsgBoxStyle.Critical)
                                        Restaurar("agrega-borra", sesion)
                                        Return False
                                    End If
                                Next
                                Try
                                    Dim DtTipos As New DataTable
                                    sesion = .Id_Sesion
                                    For Each dr In DTArchivos.Rows
                                        existe = False
                                        Dim archivo
                                        archivo = dr(1)
                                        For Each dr2 In dt.Rows
                                            If dr(0) <> dr2(0) And dr2(1) <> archivo Then existe = True
                                        Next
                                        Dim comitepath

                                        If array_texto(0) <> "NA" Then comitepath = array_texto(0)
                                        If array_texto(1) <> "NA" Then comitepath = comitepath + "\" + array_texto(1)
                                        If array_texto(2) <> "NA" Then comitepath = comitepath + "\" + array_texto(2)
                                        If array_texto(3) <> "NA" Then comitepath = comitepath + "\" + array_texto(3)


                                        Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + comitepath)
                                        Try
                                            Accion = valida("Directorio" + " _#_ " + sPath)
                                        Catch ex As Exception When Accion = False
                                            Restaurar("agrega-borra", sesion)
                                            Return False
                                        End Try
                                        If Not existe Then
                                            If File.Exists(sPath + "\" + archivo) Then
                                                If MsgBox("El archivo (" + CStr(archivo) + ") ya existe en el Servidor..." + Chr(13) + Chr(13) + " �Desea sobrescribir el archivo?", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                                                    File.Copy(dr(2), sPath + "\" + archivo, True)
                                                End If
                                            Else
                                                If Not Directory.Exists(sPath) Then
                                                    Directory.CreateDirectory(sPath)
                                                End If
                                                File.Copy(dr(2), sPath + "\" + archivo)
                                            End If
                                            .Descripcion_Docto = dr(0)
                                            .Bandera = 7
                                            DtTipos = .Listar()
                                            Dim dr3 = DtTipos.Rows(0)
                                            .Id_Tipo = dr3(0)
                                            .Id_Sesion = sesion
                                            .Docto = archivo
                                            If dr(3) Is System.DBNull.Value Then .Inactivo = 1 Else .Inactivo = IIf(dr(3), 1, 0)
                                            .Bandera = 3
                                            Try
                                                Accion = .Insertar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G007 - Al intentar guardar o leer el  Registro de Archivos..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("agrega-borra", sesion)
                                                Return False
                                            End Try
                                        End If
                                    Next
                                    dt = Nothing
                                Catch ex As Exception
                                    MsgBox("Error G008 - Al intentar guardar Registro de Archivos..." + ex.Message + ex.InnerException.ToString, MsgBoxStyle.Critical)
                                    Restaurar("agrega-borra", sesion)
                                    Return False
                                End Try
                            End If
                            If CkBxSalasANCE.Visible = True Then
                                If valida("salas") Then
                                    With objsalas
                                        .F_Solicitada = Format$(DTPker.Value, "dd/MM/yyyy")
                                        .F_Apartado = Format$(Now(), "dd/MM/yyyy")
                                        .Id_Area = CInt(objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Sistema", "id_area"))
                                        .Id_Propuesta = cbosalas.SelectedValue
                                        .Id_Responsable = CboResponsable.SelectedValue
                                        .Id_Coordinador = CboResponsable.SelectedValue
                                        .H_Entrada = Format(DTPkrhoraini.Value, "HH:mm")
                                        .H_Salida = Format(DTPkrhoratem.Value, "HH:mm")
                                        .No_Personas = 0
                                        .Observacion = TxtNotas.Text
                                        .Reunion = TxtAsunto.Text
                                        .Servicio = ""
                                        .Acomodo = "Acomodo Unico"
                                        .Bandera = 1
                                        Try
                                            Accion = .Insertar
                                            solicitud = .No_Solicitud
                                        Catch ex As Exception When Accion = False Or solicitud = -1
                                            MsgBox("Error G009 - Al intentar guardar o leer el  Registro de Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                            Restaurar("agrega-borra", sesion)
                                            Return False
                                        End Try
                                    End With

                                    If CboEquipo.SelectedValue <> 0 Then
                                        With objsalas
                                            .Equipo = CboEquipo.SelectedValue
                                            .Bandera = 2
                                            Try
                                                Accion = .Insertar
                                            Catch ex As Exception When Accion = False Or solicitud = -1
                                                MsgBox("Error G010- Al intentar guardar o leer el  Registro de Equipo en Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("agrega-borra", sesion)
                                                Restaurar("agrega-borra", solicitud)
                                                Return False
                                            End Try
                                        End With
                                    End If
                                    Try
                                        .No_Sol_Sala = solicitud
                                        .Id_Sesion = sesion
                                        .Bandera = 4
                                        Accion = .Actualizar
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G011 - Al intentar guardar o leer el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("agrega-borra", sesion)
                                        Restaurar("agrega-borra-solicitud", solicitud)
                                        Return False
                                    End Try
                                    Try
                                        Accion = correo(cbosalas.SelectedValue, cbosalas.Text, solicitud)                    '''------------------- Correo  ------------------
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G0012 - Al intentar Enviar un Mail, para el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message + Chr(13) + Chr(13) + "Favor de renviar un mail de tu solicitud " + CStr(solicitud) + " al encargado, para notificar el apartado de la sala.", MsgBoxStyle.Critical)
                                    End Try
                                End If
                            End If
                            Dim sala As String
                            If solicitud > 0 Then
                                sala = "Tu solicitud de sala es " + CStr(solicitud) + "..." + Chr(13) + "Espera tu confirmaci�n del Sistema de Salas."
                            End If
                            MsgBox("NormaNET - Los datos se registraron de manera exitosa..." + Chr(13) + Chr(13) + sala, MsgBoxStyle.Information)


                        End With

                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''---------------------------------------------------------------------------------------------------------------------------------------------

                    Case "Reprograma"                    '''------------------- Reprogramar  ------------------

                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''---------------------------------------------------------------------------------------------------------------------------------------------
                        With objsesiones
                            Dim sesion2 As Integer
                            .Id_Sesion = CboSesiones.SelectedValue
                            sesion2 = .Id_Sesion
                            .Bandera = 2
                            DTRes = .Listar
                            dr = DTRes.Rows(0)
                            istasesion = dr(3)
                            .Status = 4
                            .Bandera = 5
                            .Actualizar()
                            ''''''''''''''''''''''''''''' Inserta datos en P_sesion, nuevo registro para la reprogramaci�n''''''''''''''''''''''''''''' 

                            .Id_Comite = array_texto(0)
                            .Id_CT = array_texto(1)
                            .Id_SC = array_texto(2)
                            .Id_Grupo = array_texto(3)

                            .Fecha = DTPker.Value
                            .HoraI = Format(DTPkrhoraini.Value, "HH:mm")
                            .HoraT = Format(DTPkrhoratem.Value, "HH:mm")
                            .Asunto = TxtAsunto.Text
                            .Lugar = TxtLugar.Text
                            .Responsable = CboResponsable.SelectedValue
                            .Notas = TxtNotas.Text
                            .Status = 1
                            .Bandera = 1
                            Try
                                Accion = .Insertar()
                            Catch ex As Exception When Accion = False
                                MsgBox("Error G026 - Al intentar guardar Registro..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                Restaurar("Reprograma-borra", sesion2)
                                Return False
                            End Try
                            ''''''''''''''''''''''''''''''''''''''''''''       Inserta datos en p_sesion_temas, cuando solo son agregar datos sin cambio, poner  Temas      ''''''''''''''''''''''''''''''''''''''''''''
                            sesion = .Id_Sesion
                            .Id_Sesion = sesion2
                            .Bandera = 4
                            DTResTem = .Listar()
                            DTTemas = GridTemas.DataSource()
                            If DTTemas.Rows.Count > 0 Then
                                For i = 0 To DTTemas.Rows.Count - 1
                                    Accion = validagrid("temas 1 2 3", i)
                                    If Not Accion Then
                                        MsgBox("Error G027 - Al intentar  leer los  Registro de Temas..." + Chr(13) + "Debes activar o desactivar la casilla, en la columna de Activar" + Chr(13) + Chr(13) + "En la linea " + CStr(i + 1) + ".", MsgBoxStyle.Critical)
                                        Restaurar("Reprograma-borra", sesion2)
                                        Restaurar("agrega-borra", sesion)
                                        Return False
                                    End If
                                Next

                                i = 0
                                For Each dr In DTTemas.Rows
                                    i = i + 1
                                    .Id_Sesion = sesion
                                    .Id_Plan = dr(0)
                                    .Id_tema = dr(1)
                                    .Bandera = 2
                                    Try
                                        Accion = .Insertar()
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G028 - Al intentar guardar Nuevos  Registros de Temas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("Reprograma-borra", sesion2)
                                        Restaurar("agrega-borra", sesion)
                                        Return False
                                    End Try
                                Next

                            Else
                                MsgBox("Error G029 - No asignaste ningun Tema..." + Chr(13) + Chr(13) + "Debes asignar un tema a esta sesion por lo menos.", MsgBoxStyle.Critical)
                                ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un Plan y un tema para una sesion.")
                                Restaurar("Reprograma-borra", sesion2)
                                Restaurar("agrega-borra", sesion)
                                Return False
                            End If
                            ''''''''''''''''''''''''''''''''''''''''''''       Actualiza datos en p_sesion_doctos, cuando solo son agregar datos sin cambio, poder  Temas      ''''''''''''''''''''''''''''''''''''''''''''
                            .Id_Sesion = sesion2
                            .Bandera = 5
                            DTResArch = .Listar()
                            DTArchivos = GridArchivos.DataSource()
                            If DTArchivos.Rows.Count > 0 Then
                                For i = 0 To DTArchivos.Rows.Count - 1
                                    Accion = validagrid("archivos 1 3 2", i)
                                    If Not Accion Then
                                        MsgBox("Error G030 - Debes activar o desactivar la casilla, en la columna de Activar." + Chr(13) + "En la linea " + CStr(i + 1) + ".", MsgBoxStyle.Critical)
                                        Restaurar("Reprograma-borra", sesion2)
                                        Restaurar("agrega-borra", sesion)
                                        Return False
                                    End If
                                Next
                                Try
                                    Dim DtTipos As New DataTable
                                    .Id_Sesion = sesion
                                    i = 0
                                    For Each dr In DTArchivos.Rows
                                        i = i + 1
                                        existe = False
                                        Dim archivo
                                        Dim iInactivo As Integer
                                        archivo = dr(1)
                                        iInactivo = 1
                                        For Each dr2 In DTResArch.Rows
                                            If dr(0) = dr2(0) And dr2(1) = archivo Then
                                                existe = True
                                                iInactivo = dr2(3)
                                            End If
                                        Next
                                        If existe Then
                                            .Descripcion_Docto = dr(0)
                                            .Bandera = 7
                                            DtTipos = .Listar()
                                            Dim dr3 = DtTipos.Rows(0)
                                            .Id_Tipo = dr3(0)
                                            .Id_Sesion = sesion
                                            .Docto = archivo
                                            If dr(3) Is System.DBNull.Value Then .Inactivo = 1 Else .Inactivo = IIf(dr(3), 1, 0)
                                            .Bandera = 3
                                            Try
                                                Accion = .Insertar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G031 - Al intentar insertar Registros de Archivos nuevos..." + Chr(13) + "En la linea " + CStr(i) + "." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("Reprograma-borra", sesion2)
                                                Restaurar("agrega-borra", sesion)
                                                Return False
                                            End Try
                                            ''''''''''''''''''''''''''''''''''''''''''''       Inserta datos en p_sesion_doctos, cuando solo son agregar datos sin cambio, poder agregar archivos      ''''''''''''''''''''''''''''''''''''''''''''
                                        ElseIf Not existe Then
                                            Dim comitepath

                                            If array_texto(0) <> "NA" Then comitepath = array_texto(0)
                                            If array_texto(1) <> "NA" Then comitepath = comitepath + "\" + array_texto(1)
                                            If array_texto(2) <> "NA" Then comitepath = comitepath + "\" + array_texto(2)
                                            If array_texto(3) <> "NA" Then comitepath = comitepath + "\" + array_texto(3)

                                            Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + comitepath)
                                            'Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + .Id_Plan + (objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutasSesiones")) + "\" + dr(0))
                                            Try
                                                Accion = valida("Directorio" + " _#_ " + sPath)
                                            Catch ex As Exception When Accion = False
                                                Restaurar("Reprograma-borra", sesion2)
                                                Restaurar("agrega-borra", sesion)
                                                Return False
                                            End Try
                                            If File.Exists(sPath + "\" + archivo) Then
                                                If MsgBox("El archivo (" + CStr(archivo) + ")  ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                                                    File.Copy(dr(2), sPath + "\" + archivo, True)
                                                End If
                                            Else
                                                If Not Directory.Exists(sPath) Then
                                                    Directory.CreateDirectory(sPath)
                                                End If
                                                File.Copy(dr(2), sPath + "\" + archivo)
                                            End If
                                            .Descripcion_Docto = dr(0)
                                            .Bandera = 7
                                            DtTipos = .Listar()
                                            Dim dr3 = DtTipos.Rows(0)
                                            .Id_Tipo = dr3(0)
                                            .Id_Sesion = sesion
                                            .Docto = archivo
                                            If dr(3) Is System.DBNull.Value Then .Inactivo = 1 Else .Inactivo = IIf(dr(3), 1, 0)
                                            .Bandera = 3
                                            Try
                                                Accion = .Insertar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G032 - Al intentar insertar Registros de Archivos nuevos..." + Chr(13) + "En la linea " + CStr(i) + "." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("Reprograma-borra", sesion2)
                                                Restaurar("agrega-borra", sesion)
                                                Return False
                                            End Try
                                        End If
                                    Next
                                    dt = Nothing
                                Catch ex As Exception
                                    MsgBox("Error G033 - Al intentar actualizar Registros de Archivos..." + ex.Message + ex.InnerException.ToString, MsgBoxStyle.Critical)
                                    Restaurar("Reprograma-borra", sesion2)
                                    Restaurar("agrega-borra", sesion)
                                    Return False
                                End Try
                            End If
                            ''''''''''''''''''''''''''''''''''''''''''''       Actualiza datos en p_solicitud, cuando solo son agregar Sala      ''''''''''''''''''''''''''''''''''''''''''''
                            .Id_Sesion = sesion2
                            .Bandera = 2
                            .Buscar()
                            If .No_Sol_Sala = "" And TxtLugar.Text.ToLower = "ance" And CkBxSalasANCE.CheckState = CheckState.Checked Then
                                If valida("salas") Then
                                    With objsalas
                                        .F_Solicitada = Format$(DTPker.Value, "dd/MM/yyyy")
                                        .F_Apartado = Format$(Now(), "dd/MM/yyyy")
                                        .Id_Area = CInt(objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Sistema", "id_area"))
                                        .Id_Propuesta = cbosalas.SelectedValue
                                        .Id_Responsable = CboResponsable.SelectedValue
                                        .Id_Coordinador = CboResponsable.SelectedValue
                                        .H_Entrada = Format(DTPkrhoraini.Value, "HH:mm")
                                        .H_Salida = Format(DTPkrhoratem.Value, "HH:mm")
                                        .No_Personas = 0
                                        .Observacion = TxtNotas.Text
                                        .Reunion = TxtAsunto.Text
                                        .Servicio = ""
                                        .Acomodo = "Acomodo Unico"
                                        .Bandera = 1
                                        Try
                                            Accion = .Insertar
                                            solicitud = .No_Solicitud
                                        Catch ex As Exception When Accion = False Or solicitud = -1
                                            MsgBox("Error G034 - Al intentar guardar o leer el  Registro de Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                            Restaurar("Reprograma-borra", sesion2)
                                            Restaurar("agrega-borra", sesion)
                                            Return False
                                        End Try
                                    End With
                                    Try
                                        If CboEquipo.SelectedValue <> 0 Then
                                            With objsalas
                                                .Equipo = CboEquipo.SelectedValue
                                                .Bandera = 2
                                                Try
                                                    Accion = .Insertar
                                                Catch ex As Exception When Accion = False Or solicitud = -1
                                                    MsgBox("Error G035- Al intentar guardar o leer el  Registro de Equipo en Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                    Restaurar("Reprograma-borra", sesion2)
                                                    Restaurar("agrega-borra", sesion)
                                                    Restaurar("agrega-borra-solicitud", solicitud)
                                                    Return False
                                                End Try
                                            End With

                                        End If
                                        .No_Sol_Sala = solicitud
                                        .Id_Sesion = sesion2
                                        .Bandera = 4
                                        Accion = .Actualizar
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G036 - Al intentar guardar o leer el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("Reprograma-borra", sesion2)
                                        Restaurar("agrega-borra", sesion)
                                        Restaurar("agrega-borra-solicitud", solicitud)
                                        Return False
                                    End Try
                                    Try
                                        Accion = correo(cbosalas.SelectedValue, cbosalas.Text, solicitud)                    '''------------------- Correo  ------------------
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G0037 - Al intentar Enviar un Mail, para el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message + Chr(13) + Chr(13) + "Favor de renviar un mail de tu solicitud " + CStr(solicitud) + " al encargado, para notificar el apartado de la sala.", MsgBoxStyle.Critical)
                                    End Try
                                End If

                                Dim sala As String
                                If solicitud > 0 Then
                                    sala = "Tu nueva solicitud de sala es " + CStr(solicitud) + "..." + Chr(13) + Chr(13) + "Espera tu confirmaci�n del Sistema de Salas."
                                End If
                                MsgBox("NormaNET - Los datos se han actualizado de manera exitosa..." + Chr(13) + Chr(13) + sala, MsgBoxStyle.Information)
                            ElseIf .No_Sol_Sala <> "" And TxtLugar.Text.ToLower <> "ance" And CkBxSalasANCE.Visible = False Then
                                solicitud = .No_Sol_Sala
                                With objsalas
                                    .No_Solicitud = solicitud
                                    .Buscar()
                                    istasol = .Status
                                    .Status = 2
                                    .Bandera = 20
                                    Try
                                        Accion = .Actualizar
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G038- Al intentar guardar o leer el  Registro de Equipo en Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("Reprograma-borra", sesion2)
                                        Restaurar("agrega-borra", sesion)
                                        Restaurar("editar-borra-solicitud", solicitud)
                                        Return False
                                    End Try
                                End With
                                Try
                                    .No_Sol_Sala = ""
                                    .Id_Sesion = sesion2
                                    .Bandera = 4
                                    Accion = .Actualizar
                                Catch ex As Exception When Accion = False
                                    MsgBox("Error G039 - Al intentar actualizar el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                    Restaurar("Reprograma-borra", sesion2)
                                    Restaurar("editar-borra-solicitud", solicitud)
                                    Restaurar("agrega-borra", sesion)
                                    Return False
                                End Try


                            End If





                        End With
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''---------------------------------------------------------------------------------------------------------------------------------------------

                    Case "Editar"                                   '''------------------- Editar ------------------

                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''---------------------------------------------------------------------------------------------------------------------------------------------
                        With objsesiones
                            .Id_Sesion = CboSesiones.SelectedValue
                            .Bandera = 2
                            DTRes = .Listar
                            sesion = .Id_Sesion
                            ''''''''''''''''''''''''''''''''''''''''''''       Actualiza datos en p_sesion, cuando solo son agregar datos sin cambio de lugar o asignacion de sala      ''''''''''''''''''''''''''''''''''''''''''''

                            .Id_Comite = array_texto(0)
                            .Id_CT = array_texto(1)
                            .Id_SC = array_texto(2)
                            .Id_Grupo = array_texto(3)

                            .Fecha = DTPker.Value
                            .HoraI = Format(DTPkrhoraini.Value, "HH:mm")
                            .HoraT = Format(DTPkrhoratem.Value, "HH:mm")
                            .Asunto = TxtAsunto.Text
                            .Lugar = TxtLugar.Text
                            .Responsable = CboResponsable.SelectedValue
                            .Notas = TxtNotas.Text
                            .Status = 1
                            .Bandera = 10
                            Try
                                Accion = .Actualizar
                            Catch ex As Exception When Accion = False
                                MsgBox("Error G013 - Al intentar actualizar el Registro..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                Restaurar("editar-borra", sesion)
                                Return False
                            End Try
                            ''''''''''''''''''''''''''''''''''''''''''''       Actualiza datos en p_sesion_temas, cuando solo son agregar datos sin cambio, poder  Temas      ''''''''''''''''''''''''''''''''''''''''''''
                            .Bandera = 4
                            DTResTem = .Listar()
                            DTTemas = GridTemas.DataSource()
                            If DTTemas.Rows.Count > 0 Then
                                For i = 0 To DTTemas.Rows.Count - 1
                                    Accion = validagrid("temas 1 2 3", i)
                                    If Not Accion Then
                                        MsgBox("Error G014 - Al intentar  leer los  Registro de Temas..." + Chr(13) + Chr(13) + Chr(13) + "En la linea " + CStr(i + 1) + ".", MsgBoxStyle.Critical)
                                        Restaurar("editar-borra", sesion)
                                        Return False
                                    End If
                                Next
                                Try
                                    i = 0
                                    For Each dr In DTTemas.Rows
                                        i = i + 1
                                        existe = False
                                        Dim bbool As Integer = -1
                                        For Each dr2 In DTResTem.Rows
                                            If dr(0) = dr2(0) And dr(1) = dr2(1) Then existe = True
                                            bbool = IIf(IsDBNull(dr(3)), 1, IIf(dr(3) = 0, 0, 1))
                                        Next
                                        If existe And IIf(IsDBNull(dr(3)), 1, IIf(dr(3) = 0, 0, 1)) <> bbool Then
                                            .Id_Sesion = sesion
                                            .Id_Plan = dr(0)
                                            .Id_tema = dr(1)
                                            .Inactivo = IIf(IsDBNull(dr(3)), 1, IIf(dr(3) = 0, 0, 1))
                                            .Bandera = 11
                                            Try
                                                Accion = .Actualizar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G016 - Al intentar Actualizar los  Registros de Temas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("editar-borra", sesion)
                                                Restaurar("editar-borra-tema", sesion)
                                                Return False
                                            End Try
                                        ElseIf Not existe Then
                                            .Id_Sesion = sesion
                                            .Id_Plan = dr(0)
                                            .Id_tema = dr(1)
                                            .Bandera = 2
                                            Try
                                                Accion = .Insertar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G015 - Al intentar guardar Nuevos  Registros de Temas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("editar-borra", sesion)
                                                Restaurar("editar-borra-tema", sesion)
                                                Return False
                                            End Try
                                        End If
                                    Next
                                Catch ex As Exception
                                    MsgBox("Error G017 - Al intentar guardar Registro de Temas..." + ex.Message, MsgBoxStyle.Critical)
                                    Restaurar("editar-borra", sesion)
                                    Restaurar("editar-borra-tema", sesion)
                                    Return False
                                End Try
                            Else
                                MsgBox("Error G018 - No asignaste ningun Tema..." + Chr(13) + Chr(13) + "Debes asignar un tema a esta sesion por lo menos.", MsgBoxStyle.Critical)
                                ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un Plan y un tema para una sesion.")
                                Restaurar("editar-borra", sesion)
                                Return False
                            End If
                            ''''''''''''''''''''''''''''''''''''''''''''       Actualiza datos en p_sesion_doctos, cuando solo son agregar datos sin cambio, poder agregar archivos      ''''''''''''''''''''''''''''''''''''''''''''
                            .Bandera = 5
                            DTResArch = .Listar()
                            DTArchivos = GridArchivos.DataSource()

                            If DTArchivos.Rows.Count > 0 Then
                                For i = 0 To DTArchivos.Rows.Count - 1
                                    Accion = validagrid("archivos 1 2", i)
                                    If Not Accion Then
                                        MsgBox("Error G019 - Debes activar o desactivar la casilla, en la columna de Activar." + Chr(13) + "En la linea " + CStr(i + 1) + ".", MsgBoxStyle.Critical)
                                        Restaurar("editar-borra", sesion)
                                        Restaurar("editar-borra-tema", sesion)
                                        Return False
                                    End If
                                Next
                                Try
                                    Dim DtTipos As New DataTable
                                    sesion = .Id_Sesion
                                    i = 0
                                    For Each dr In DTArchivos.Rows
                                        i = i + 1
                                        existe = False
                                        Dim archivo
                                        Dim iInactivo As Integer
                                        archivo = dr(1)
                                        iInactivo = 1
                                        For Each dr2 In DTResArch.Rows
                                            If dr(0) = dr2(0) And dr2(1) = archivo Then
                                                existe = True
                                                iInactivo = dr2(3)
                                            End If
                                        Next
                                        If existe And IIf(IsDBNull(dr(3)), 1, IIf(dr(3) = 0, 0, 1)) <> iInactivo Then
                                            .Id_Sesion = sesion
                                            .Id_Docto = IIf(IsDBNull(dr(4)), Nothing, dr(4))
                                            If dr(3) Is System.DBNull.Value Then .Inactivo = 1 Else .Inactivo = IIf(dr(3), 1, 0)
                                            .Bandera = 12 '
                                            Try
                                                Accion = .Actualizar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G020 - Al intentar actualizar el  Registro de Archivos..." + Chr(13) + "En la linea " + CStr(i) + "." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("editar-borra", sesion)
                                                Restaurar("editar-borra-tema", sesion)
                                                Restaurar("editar-borra-doctos", sesion)
                                                Return False
                                            End Try
                                            ''''''''''''''''''''''''''''''''''''''''''''       Inserta datos en p_sesion_doctos, cuando solo son agregar datos sin cambio, poder agregar archivos      ''''''''''''''''''''''''''''''''''''''''''''
                                        ElseIf Not existe Then
                                            Dim comitepath

                                            If array_texto(0) <> "NA" Then comitepath = array_texto(0)
                                            If array_texto(1) <> "NA" Then comitepath = comitepath + "\" + array_texto(1)
                                            If array_texto(2) <> "NA" Then comitepath = comitepath + "\" + array_texto(2)
                                            If array_texto(3) <> "NA" Then comitepath = comitepath + "\" + array_texto(3)

                                            Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + comitepath)
                                            ' Dim sPath = ((objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "server")) + "\" + .Id_Plan + (objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Rutas", "RutasSesiones")) + "\" + dr(0))
                                            Try
                                                Accion = valida("Directorio" + " _#_ " + sPath)
                                            Catch ex As Exception When Accion = False
                                                Restaurar("editar-borra", sesion)
                                                Restaurar("editar-borra-tema", sesion)
                                                Restaurar("editar-borra-doctos", sesion)
                                                Return False
                                            End Try
                                            If File.Exists(sPath + "\" + archivo) Then
                                                If MsgBox("El archivo (" + CStr(archivo) + ")  ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                                                    File.Copy(dr(2), sPath + "\" + archivo, True)
                                                End If
                                            Else
                                                If Not Directory.Exists(sPath) Then
                                                    Directory.CreateDirectory(sPath)
                                                End If
                                                File.Copy(dr(2), sPath + "\" + archivo)
                                            End If
                                            .Descripcion_Docto = dr(0)
                                            .Bandera = 7
                                            DtTipos = .Listar()
                                            Dim dr3 = DtTipos.Rows(0)
                                            .Id_Tipo = dr3(0)
                                            .Id_Sesion = sesion
                                            .Docto = archivo
                                            If dr(3) Is System.DBNull.Value Then .Inactivo = 1 Else .Inactivo = IIf(dr(3), 1, 0)
                                            .Bandera = 3
                                            Try
                                                Accion = .Insertar()
                                            Catch ex As Exception When Accion = False
                                                MsgBox("Error G021 - Al intentar insertar Registros de Archivos nuevos..." + Chr(13) + "En la linea " + CStr(i) + "." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                Restaurar("editar-borra", sesion)
                                                Restaurar("editar-borra-tema", sesion)
                                                Restaurar("editar-borra-doctos", sesion)
                                                Return False
                                            End Try
                                        End If
                                    Next
                                    dt = Nothing
                                Catch ex As Exception
                                    MsgBox("Error G022 - Al intentar actualizar Registros de Archivos..." + ex.Message + ex.InnerException.ToString, MsgBoxStyle.Critical)
                                    Restaurar("editar-borra", sesion)
                                    Restaurar("editar-borra-tema", sesion)
                                    Return False
                                End Try
                            Else

                            End If

                            ''''''''''''''''''''''''''''''''''''''''''''       Actualiza datos en p_solicitud, cuando solo son agregar Sala      ''''''''''''''''''''''''''''''''''''''''''''
                            If .No_Sol_Sala = "" And TxtLugar.Text.ToLower = "ance" And CkBxSalasANCE.Visible = True And CkBxSalasANCE.Checked Then
                                If valida("salas") Then
                                    With objsalas
                                        .F_Solicitada = Format$(DTPker.Value, "dd/MM/yyyy")
                                        .F_Apartado = Format$(Now(), "dd/MM/yyyy")
                                        .Id_Area = CInt(objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Sistema", "id_area"))
                                        .Id_Propuesta = cbosalas.SelectedValue
                                        .Id_Responsable = CboResponsable.SelectedValue
                                        .Id_Coordinador = CboResponsable.SelectedValue
                                        .H_Entrada = Format(DTPkrhoraini.Value, "HH:mm")
                                        .H_Salida = Format(DTPkrhoratem.Value, "HH:mm")
                                        .No_Personas = 0
                                        .Observacion = TxtNotas.Text
                                        .Reunion = TxtAsunto.Text
                                        .Servicio = ""
                                        .Acomodo = "Acomodo Unico"
                                        .Bandera = 1
                                        Try
                                            Accion = .Insertar
                                            solicitud = .No_Solicitud
                                        Catch ex As Exception When Accion = False Or solicitud = -1
                                            MsgBox("Error G023 - Al intentar guardar o leer el  Registro de Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                            Restaurar("editar-borra", sesion)
                                            Restaurar("editar-borra-tema", sesion)
                                            Restaurar("editar-borra-doctos", sesion)
                                            Return False
                                        End Try
                                    End With
                                    Try
                                        If CboEquipo.SelectedValue <> 0 Then
                                            With objsalas
                                                .Equipo = CboEquipo.SelectedValue
                                                .Bandera = 2
                                                Try
                                                    Accion = .Insertar
                                                Catch ex As Exception When Accion = False Or solicitud = -1
                                                    MsgBox("Error G024 - Al intentar guardar o leer el  Registro de Equipo en Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                                    Restaurar("editar-borra", sesion)
                                                    Restaurar("editar-borra-tema", sesion)
                                                    Restaurar("editar-borra-doctos", sesion)
                                                    Restaurar("agrega-borra-solicitud", solicitud)
                                                    Return False
                                                End Try
                                            End With

                                        End If
                                        .No_Sol_Sala = solicitud
                                        .Id_Sesion = sesion
                                        .Bandera = 4
                                        Accion = .Actualizar
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G025 - Al intentar guardar o leer el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("editar-borra", sesion)
                                        Restaurar("editar-borra-tema", sesion)
                                        Restaurar("editar-borra-doctos", sesion)
                                        Restaurar("agrega-borra-solicitud", solicitud)
                                        Return False
                                    End Try
                                    Try
                                        Accion = correo(cbosalas.SelectedValue, cbosalas.Text, solicitud)                    '''------------------- Correo  ------------------
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G0026 - Al intentar Enviar un Mail, para el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message + Chr(13) + Chr(13) + "Favor de renviar un mail de tu solicitud " + CStr(solicitud) + " al encargado, para notificar el apartado de la sala.", MsgBoxStyle.Critical)
                                    End Try
                                End If

                                Dim sala As String
                                If solicitud > 0 Then
                                    sala = "Tu solicitud de sala es " + CStr(solicitud) + "..." + Chr(13) + "Espera tu confirmaci�n del Sistema de Salas."
                                End If
                                MsgBox("NormaNET - Los datos se han actualizado de manera exitosa..." + Chr(13) + Chr(13) + sala, MsgBoxStyle.Information)
                            ElseIf .No_Sol_Sala <> "" And TxtLugar.Text.ToLower <> "ance" And CkBxSalasANCE.Visible = False Then
                                solicitud = .No_Sol_Sala
                                With objsalas
                                    .No_Solicitud = solicitud
                                    .Buscar()
                                    istasol = .Status
                                    .Status = 2
                                    .Bandera = 20
                                    Try
                                        Accion = .Actualizar
                                    Catch ex As Exception When Accion = False
                                        MsgBox("Error G024- Al intentar guardar o leer el  Registro de Equipo en Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                        Restaurar("editar-borra", sesion)
                                        Restaurar("editar-borra-tema", sesion)
                                        Restaurar("editar-borra-doctos", sesion)
                                        Restaurar("editar-borra-solicitud", solicitud)
                                        Return False
                                    End Try
                                End With
                                Try
                                    .No_Sol_Sala = ""
                                    .Id_Sesion = sesion
                                    .Bandera = 4
                                    Accion = .Actualizar
                                Catch ex As Exception When Accion = False
                                    MsgBox("Error G025 - Al intentar actualizar el  Registro de Salas - NormaNET..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                                    Restaurar("editar-borra", sesion)
                                    Restaurar("editar-borra-tema", sesion)
                                    Restaurar("editar-borra-doctos", sesion)
                                    Restaurar("editar-borra-solicitud", solicitud)
                                    Return False
                                End Try


                            End If


                        End With
                End Select

            Else
                Return False
            End If

            Return True
        Catch ex As Exception
            MsgBox("Error G000  -  Error Interno" + Chr(13) + ex.Message, MsgBoxStyle.Critical)
            If iEditar = "Agregar" Then
                Restaurar("agrega-borra", sesion)
                Restaurar("agrega-borra-solicitud", solicitud)
            ElseIf iEditar = "Editar" Then
                Restaurar("editar-borra", sesion)
                Restaurar("editar-borra-tema", sesion)
                Restaurar("editar-borra-doctos", sesion)
                Restaurar("editar-borra-solicitud", solicitud)
            End If
            Return False
        End Try

    End Function

#End Region

#Region " Envi� de Correo"

    Public Function correo(ByVal sala As Integer, ByVal salatxt As String, ByVal numsol As Integer) As Boolean
        Dim mail As New clsCorreo.ClsCorreo
        Dim sto, scc
        Select Case sala
            Case 5
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion2")
            Case 9
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Direccion2")
            Case 10
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecHum1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecHum2")
            Case 8
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Monterrey1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Monterrey2")
            Case 7
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Guadalajara1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "Guadalajara2")
            Case Else
                sto = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecMat1")
                scc = objiniarray.IniGet(Application.StartupPath + "\Principal.ini", "Salas", "RecMat2")
        End Select
        Try
            objempleados.Id_usuario = sto
            objempleados.Bandera = 3
            objempleados.Buscar()
            sto = objempleados.Email
            objempleados.Id_usuario = scc
            objempleados.Bandera = 3
            objempleados.Buscar()
            scc = objempleados.Email
            Dim Body = "<html><body background='http://intranet.ance.org.mx/salas/Imagenes/back2.jpg'><font color='#000000' face='Arial' size='3' ><font color='#660000' size='10'>Solicitud de Sala</font><br><br>Se ha generado una solicitud para el uso de  " + salatxt + ",<br>con la referencia n�mero:<br><br><font color='#006600' size='4'>" + CStr(numsol) + "<br><br> </font><font color='#660000' size='6'><a href='http://intranet.ance.org.mx/aplicaciones.asp' style='cursor:hand; color:#660000'>Aplicaciones de Intranet</a></font><br><br></font></body></html>" '
            mail.EnviarCorreo("Solicitud de Salas de NormaNET", sto, scc, "Solicitud de Salas", Body)
            Return True
        Catch ex As Exception
            MsgBox("Error G0012 - Al intentar Enviar un Mail, para el  Registro de Salas - NormaNET..." + Chr(13) + ex.Message + Chr(13) + Chr(13) + "Favor de renviar un mail de tu solicitud " + CStr(solicitud) + " al encargado, para notificar el apartado de la sala.", MsgBoxStyle.Critical)
            Return False
        End Try
    End Function

#End Region

#Region " Restaurado de Datos"

    Public Sub Restaurar(ByVal caso As String, ByVal sesion As Integer)
        With objsesiones
            Select Case caso
                Case "agrega-borra"
                    .Id_Sesion = sesion
                    .Bandera = 200
                    Try
                        Accion = .Insertar()
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 001R - Al intentar restaurar integridad de los datos..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
                Case "agrega-borra-solicitud"
                    With objsalas
                        .No_Solicitud = sesion
                        .Bandera = 200
                        Try
                            Accion = .Insertar()
                        Catch ex As Exception When Accion = False
                            MsgBox("Error 002R - Al intentar restaurar integridad de los datos..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                        End Try
                    End With
                Case "editar-borra"
                    Dim dr As DataRow
                    dr = DTRes.Rows(0)
                    .Id_Sesion = sesion
                    .Id_Comite = dr(4)
                    .Id_CT = dr(5)
                    .Id_SC = dr(6)
                    .Id_Grupo = dr(7)
                    .Fecha = dr(8)
                    .HoraI = dr(9)
                    .HoraT = dr(10)
                    .Asunto = dr(1)
                    .Lugar = dr(11)
                    .Responsable = dr(12)
                    .Notas = dr(13)
                    .Status = dr(14)
                    .Bandera = 10
                    Try
                        Accion = .Actualizar
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 003R -  Al intentar restaurar integridad de los datos....." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
                Case "editar-borra-tema"
                    Dim dr As DataRow
                    Dim ie As Integer
                    .Id_Sesion = sesion
                    .Bandera = 201
                    Try
                        Accion = .Actualizar
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 004R -  Al intentar restaurar integridad de los datos....." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
                    ie = 0
                    For Each dr In DTResTem.Rows
                        ie = ie + 1
                        .Id_Plan = dr(0)
                        .Id_tema = dr(1)
                        .Bandera = 2
                        Try
                            Accion = .Insertar
                        Catch ex As Exception When Accion = False
                            MsgBox("Error 004R" + CStr(ie) + " -  Al intentar restaurar integridad de los datos....." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                        End Try
                    Next
                Case "editar-borra-doctos"
                    Dim dr As DataRow
                    Dim ie As Integer
                    .Id_Sesion = sesion
                    .Bandera = 202
                    Try
                        Accion = .Actualizar
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 005R -  Al intentar restaurar integridad de los datos....." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
                    ie = 0
                    Dim dTtipos As DataTable
                    For Each dr In DTResArch.Rows
                        ie = ie + 1
                        .Descripcion_Docto = dr(0)
                        .Bandera = 7
                        dTtipos = .Listar()
                        Dim dr3 = dTtipos.Rows(0)
                        .Id_Tipo = dr3(0)
                        .Id_Sesion = sesion
                        .Docto = dr(1)
                        If dr(3) Is System.DBNull.Value Then .Inactivo = 1 Else .Inactivo = IIf(dr(3), 1, 0)
                        .Bandera = 3
                        Try
                            Accion = .Insertar
                        Catch ex As Exception When Accion = False
                            MsgBox("Error 005R" + CStr(ie) + " -  Al intentar restaurar integridad de los datos....." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                        End Try
                    Next
                Case "editar-borra-solicitud"
                    With objsalas
                        .Status = istasol
                        .Bandera = 20
                        ''Try
                        ''Accion = .Actualizar
                        ''Catch ex As Exception When Accion = False
                        ''    MsgBox("Error 006R - Al intentar Restaurar el  Registro de Salas..." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                        ''End Try
                    End With
                Case "Reprograma-borra"
                    .Status = istasesion
                    .Bandera = 5
                    Try
                        Accion = .Actualizar
                    Catch ex As Exception When Accion = False
                        MsgBox("Error 007R - Al intentar  restaurar integridad de los datos....." + Chr(13) + .sError + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                    End Try
            End Select
        End With
    End Sub

    Public Sub restaura_combo(ByVal dt As DateTimePicker, ByVal valor As String)
        sError = iEditar
        iEditar = "Reset"
        dt.Value = valor
        iEditar = sError
    End Sub

#End Region

#Region " Validaciones"

    Private Function valida(ByVal casos As String) As Boolean
        Dim aCasos As Array
        Dim valreturn As Boolean = True
        aCasos = Split(casos, " _#_ ")
        Select Case aCasos(0)
            Case "comites"
                If LblTreeView.Text.Length <= 0 Then
                    ErrorProvider1.SetError(Lblcomite, "Debes seleccionar un Comite")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblcomite, "")
                End If
            Case "dtpker"
                If CStr(DTPker.Value) = "" Then
                    ErrorProvider1.SetError(DTPker, "Debes escribir la fecha de tu sesi�n")
                    valreturn = False
                ElseIf Not (CInt(Format$(DTPker.Value, "dd")) <= CInt(Format$(Now(), "dd")) And CInt(Format$(DTPker.Value, "MM")) <= CInt(Format$(Now(), "MM")) And CInt(Format$(DTPker.Value, "yyyy")) <= CInt(Format$(Now(), "yyyy"))) Then
                    ErrorProvider1.SetError(DTPker, "")
                Else
                    ErrorProvider1.SetError(DTPker, "No se puede programar una  sesi�n para una fecha anterior o del  mismo d�a.")
                    valreturn = False
                End If

            Case "Asunto"
                If TxtAsunto.Text = "" Then
                    ErrorProvider1.SetError(TxtAsunto, "Debes escribir el tema principal de la sesi�n")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(TxtAsunto, "")
                End If

            Case "salas"
                If cbosalas.SelectedValue = 0 And CkBxSalasANCE.Checked Then
                    ErrorProvider1.SetError(cbosalas, "Seleccionaste apartado de sala en ANCE." + Chr(13) + " Debes elegir una sala ahora o deshactivar la casilla de Apartado de sala.")
                    ErrorProvider1.SetError(Lblchksala, "Debes seleccionar la sala en  ANCE." + Chr(13) + " para habilitar las Salas")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(cbosalas, "")
                    ErrorProvider1.SetError(CkBxSalasANCE, "")
                End If

            Case "Horario"
                Dim HoraI As DateTime = DTPkrhoraini.Value
                Dim Horat As DateTime = DTPkrhoratem.Value
                If HoraI >= Horat Then
                    ErrorProvider1.SetError(Lblhi, "Debes escribir un Horario de inicio menor al de Termino de la sesion")
                    ErrorProvider1.SetError(Lblht, "Debes escribir un Horario de Termino mayor al de Inicio de  la sesion")
                    valreturn = False
                Else
                    ErrorProvider1.SetError(Lblhi, "")
                    ErrorProvider1.SetError(Lblht, "")
                End If

            Case "Directorio"
                Dim sPath = aCasos(1)
                Try
                    If Directory.Exists(sPath) = False Then
                        'MkDir(sPath)
                        valreturn = False
                    End If
                Catch ex As Exception
                    MsgBox("Error V004 - Al intentar crear una carpeta en el servidor ..." + Chr(13) + sPath + Chr(13) + ex.Message, MsgBoxStyle.Critical) '
                    valreturn = False
                End Try
        End Select
        Return valreturn
    End Function

    Private Function validagrid(ByVal casos As String, ByVal fil As Integer) As Boolean
        Dim acasos As Array = Split(casos, " ")
        Dim i As Integer
        Dim valreturn As Boolean = True
        ErrorProvider1.SetError(lblGridTemas, "")
        ErrorProvider1.SetError(LblGridArchivos, "")
        Try
            Select Case acasos(0)
                Case "temas"
                    Dim stema = (IIf(IsDBNull(GridTemas.Item(fil, 1)), -1, GridTemas.Item(fil, 1)))
                    Dim sPlan = (IIf(IsDBNull(GridTemas.Item(fil, 0)), "", GridTemas.Item(fil, 0)))
                    For i = 1 To acasos.Length - 1
                        Select Case acasos(i)
                            Case "1"
                                If stema = -1 Then
                                    ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un tema")
                                    valreturn = False
                                End If
                            Case "2"
                                If sPlan = "" Then
                                    ErrorProvider1.SetError(lblGridTemas, "Debes seleccionar un Plan")
                                    valreturn = False
                                End If
                            Case "3"
                                Dim sverifica
                                If GridTemas.Item(fil, 3) Is System.DBNull.Value Then sverifica = (1) Else sverifica = IIf(GridTemas.Item(fil, 3), 1, 0)
                                If sverifica = 0 Then
                                    ErrorProvider1.SetError(lblGridTemas, "Debes activar o desactivar la casilla, en la columna de Activar" + Chr(13) + Chr(13) + "En la linea " + CStr(fil + 1) + ".")
                                    valreturn = False
                                End If
                        End Select
                    Next
                Case "archivos"
                    Dim stipo = (IIf(IsDBNull(GridArchivos.Item(fil, 0)), "", GridArchivos.Item(fil, 0)))
                    Dim sarchivo = (IIf(IsDBNull(GridArchivos.Item(fil, 1)), "", GridArchivos.Item(fil, 1)))
                    For i = 1 To acasos.Length - 1
                        Select Case acasos(i)
                            Case "1"
                                If stipo = "" Then
                                    ErrorProvider1.SetError(LblGridArchivos, "Debes seleccionar un tipo de archivos")
                                    valreturn = False
                                End If
                            Case "2"
                                If stipo <> "" Then
                                    If sarchivo = "" Then
                                        ErrorProvider1.SetError(LblGridArchivos, "Debes Agregar un Archivo")
                                        valreturn = False
                                    End If
                                End If
                            Case "3"
                                If sarchivo <> "" Then
                                    Dim sverifica
                                    If GridArchivos.Item(fil, 3) Is System.DBNull.Value Then sverifica = 1 Else sverifica = IIf(GridArchivos.Item(fil, 3), 1, 0)
                                    If sverifica = 0 Then
                                        ErrorProvider1.SetError(LblGridArchivos, "Debes activar o desactivar la casilla, en la columna de Activar." + Chr(13) + Chr(13) + "En la linea " + CStr(fil + 1) + ".")
                                        valreturn = False
                                    End If
                                End If

                        End Select
                    Next
            End Select
        Catch ex As Exception
            MsgBox("Intenta Nuevamente")
            Return error1 = True
        End Try
        Return valreturn
    End Function

#End Region

#Region "Limpia Sesiones"

    Private Sub limpia()
        DTPker.ResetText()
        sFechaPk = Format$(DTPker.Value, "dd/MM/yyyy")
        TxtAsunto.Text = "" : TxtLugar.Text = "" : LblcountArch.Text = 0 : Lblcounttemas.Text = 0 : TxtNotas.Text = "" : TxtNo_Sol_Sala.Text = ""
        DTPkrhoraini.ResetText()
        DTPkrhoratem.ResetText()
        cbosalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
        CkBxSalasANCE.CheckState = CheckState.Unchecked
        iarchv = 0
        itemas = 0
        Call Llena_grid(-1)
    End Sub

#End Region

#Region "Busca Sesiones"

    Private Function sesiones(ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String) As DataTable
        Cursor.Current = Cursors.WaitCursor
        Dim combotable As DataTable
        Dim regs As DataRow
        Dim iNumero As Integer
        Dim columna As DataColumn
        Try
            With objsesiones
                .Bandera = 3
                .Id_Comite = comite
                .Id_CT = CT
                .Id_SC = SC
                .Id_Grupo = grupo
                combotable = .Listar()
            End With
            If grupo.Trim <> "NA" Then
                comite = grupo.Trim
            ElseIf SC.Trim <> "NA" Then
                comite = SC.Trim
            ElseIf CT.Trim <> "NA" Then
                comite = CT.Trim
            End If
            combotable.Columns.Add("Numero")
            iNumero = 0
            For Each regs In combotable.Rows
                iNumero = iNumero + 1
                combotable.Rows(iNumero - 1).Item("Numero") = Format$(iNumero, "000") + "/" + Format$(regs("Fecha"), "yy") + " " + comite.Trim
            Next
            'LblcountArch.Text = DTArchivos.Rows.Count
            'iarchv = DTArchivos.Rows.Count
            If iNumero = 0 And (iEditar <> Nothing) Then
                MsgBox("No tiene asignada ninguna Sesion", MsgBoxStyle.Information)
            End If
            Dim cm As CurrencyManager
            cm = CType(BindingContext(combotable), CurrencyManager)
            'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyManager
            Dim Dv As DataView = CType(cm.List, DataView)
            'Asignamos el valor que deseamos para evitar o permitir nuevos registros
            If compara.Length > 0 Then Dv.RowFilter = "Numero = '" & compara & "'"
            Return combotable
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Function

#End Region

#End Region

#Region " Datagrid, Metodos y Procesos"

    Public Sub Llena_grid(ByVal num As Integer)
        With objsesiones
            .Id_Sesion = num
            .Bandera = 4
            DTTemas = .Listar()
            GridTemas.DataSource = DTTemas
            .Id_Sesion = num
            .Bandera = 5
            Lblcounttemas.Text = DTTemas.Rows.Count
            itemas = DTTemas.Rows.Count
            DTArchivos = .Listar()
            DTArchivos.Columns.Add("Boton")

            'Cambios por MMendoza 02/10/2008 - se agregaron los AllowDelete, AllowEdit, AllowNew
            DTArchivos.DefaultView.AllowDelete = False
            DTArchivos.DefaultView.AllowEdit = False
            DTArchivos.DefaultView.AllowNew = False

            DTArchivos.AcceptChanges()
            GridArchivos.DataSource = DTArchivos
            GridArchivos.Enabled = True
        End With

    End Sub

#Region " Datagrid - DGTemas, Metodos y Procesos"

#Region "  Datagrid - DGTemas, C�digo de combos dentro del  datagrid, Deshabilitado"

    'Private Sub Crea_DGTemas
    'Dim cboPlanes As New DataGridComboBoxColumn(0, GridTemas)
    ''Cambia el estilo de la combo ...
    'cboPlanes.MappingName = "Plan"
    'cboPlanes.HeaderText = "Planes"
    'cboPlanes.Width = 100
    'cboPlanes.ColumnComboBox.Name = "CboPlanes"
    'ts1.GridColumnStyles.Add(cboPlanes)
    'cboPlanes.ColumnComboBox.Items.Clear()
    'objplanes.Bandera = 1
    'Dim dtplanes As New DataTable
    'Dim regplan As DataRow
    'objplanes.ListaCombo(cboPlanes.ColumnComboBox)
    'cboPlanes.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList
    'ts1.PreferredRowHeight = (cboPlanes.ColumnComboBox.Height + 4)
    'GridTemas.TableStyles.Add(ts1)

    'Dim cboTemas As New DataGridComboBoxColumn(1, GridTemas)
    'cboTemas.MappingName = "Tema"
    'cboTemas.HeaderText = "Temas"
    'cboTemas.Width = 80
    'ts1.GridColumnStyles.Add(cboTemas)
    'cboTemas.ColumnComboBox.Items.Clear()
    'cboTemas.ColumnComboBox.Name = "CboTemas"
    'objprogtrab.Bandera = 11
    'objprogtrab.Id_Plan = ""
    'DTC_Temas = objprogtrab.Listar()
    'cboTemas.ColumnComboBox.DisplayMember = DTC_Temas.Columns(1).ColumnName
    'cboTemas.ColumnComboBox.ValueMember = DTC_Temas.Columns(0).ColumnName
    'cboTemas.ColumnComboBox.DataSource = DTC_Temas
    'cboTemas.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList
    'ts1.PreferredRowHeight = (cboTemas.ColumnComboBox.Height + 4)

    'Private Sub GridTemas_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridTemas.CurrentCellChanged

    '    If validagrid("temas 1 2", fila) = True Then
    '        objprogtrab.Id_Tema = GridTemas.Item(fila, 1)
    '        objprogtrab.Id_Plan = GridTemas.Item(fila, 0)
    '        objprogtrab.Bandera = 10
    '        objprogtrab.Buscar()
    '        GridTemas.Item(fila, 2) = objprogtrab.Clasificacion
    '    End If

#End Region

    Private Sub Crea_DGTemas()
        Dim dtcol As DataColumn = Nothing
        Try
            GridTemas.TableStyles.Clear()
            GridTemas.BorderStyle = BorderStyle.Fixed3D
            GridTemas.FlatMode = True
            GridTemas.RowHeaderWidth = 18

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            ts1.MappingName = "clsSesiones"
            ts1.AlternatingBackColor = Color.LightGray
            ts1.SelectionForeColor = Color.White
            ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
            ts1.HeaderForeColor = Color.White
            ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
            ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
            ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)

            Dim tvcolum As New DataGridColumnTreeView(GridTemas)
            tvcolum.MappingName = "Plan"
            tvcolum.HeaderText = "Planes"
            tvcolum.ColumnTreeView.ImageList = imgListTreeView
            tvcolum.ColumnTreeView.ImageIndex = 4
            tvcolum.ColumnTreeView.SelectedImageIndex = 5
            Llena_Plantreeview(tvcolum.ColumnTreeView)
            tvcolum.Width = 100
            tvcolum.ColumnTreeView.Width = 180
            tvcolum.ColumnTreeView.Height = GridTemas.Height - tvcolum.TextBox.Height
            ts1.GridColumnStyles.Add(tvcolum)
            GridTemas.TableStyles.Add(ts1)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Tema"
            TextCol1.HeaderText = "Temas"
            TextCol1.Width = 80

            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            GridTemas.TableStyles.Add(ts1)

            Dim TextCol As DataGridTextBoxColumn
            TextCol = New DataGridTextBoxColumn
            TextCol.MappingName = "Clasificacion"
            TextCol.HeaderText = "Clasificaci�n"
            TextCol.Width = 110
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)
            'GridArchivos.TableStyles.Add(ts1)

            Dim chktemas As New DataGridBoolColumn
            chktemas.MappingName = "Inactivo"
            chktemas.HeaderText = "Activar"
            chktemas.Width = 40
            chktemas.NullValue = True
            chktemas.TrueValue = 0
            chktemas.FalseValue = 1
            'chkcolum.ReadOnly = False

            ts1.GridColumnStyles.Add(chktemas)
            GridTemas.TableStyles.Add(ts1)
            ' GridTemas.RowHeaderWidth = 15

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try

    End Sub

    Private Sub Gridtemas_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridTemas.CurrentCellChanged
        ErrorProvider1.SetError(TxtLugar, "")
        ErrorProvider1.SetError(lblGridTemas, "")
    End Sub

#End Region

#Region " Datagrid - gdarchivos, Metodos y Procesos"

#Region " gdarchivos - Crea_gdarchivos, Metodos y Procesos"

    Private Sub Crea_gdarchivos()

        Try
            Cursor.Current = Cursors.WaitCursor
            GridArchivos.TableStyles.Clear()
            GridArchivos.BorderStyle = BorderStyle.Fixed3D
            GridArchivos.FlatMode = True
            GridArchivos.RowHeaderWidth = 18

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            ts1.MappingName = "clsSesiones"
            ts1.AlternatingBackColor = Color.LightGray
            ts1.SelectionForeColor = Color.White
            ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
            ts1.HeaderForeColor = Color.White
            ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
            ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
            ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)

            Dim cboTipos_doctos As New DataGridComboBoxColumn(0, GridArchivos)
            'Cambia el estilo de la combo ...
            cboTipos_doctos.MappingName = "Descripcion"
            cboTipos_doctos.HeaderText = "Tipo"
            cboTipos_doctos.Width = 75
            cboTipos_doctos.ColumnComboBox.Name = "CboTipos_doctos"

            objsesiones.Bandera = 6
            objsesiones.ListaCombo(cboTipos_doctos.ColumnComboBox)
            cboTipos_doctos.ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList
            'ts1.PreferredRowHeight = (cboTipos_doctos)
            'GridArchivos.TableStyles.Add(ts1)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "Docto"
            TextCol1.HeaderText = "Archivo"
            TextCol1.Width = 190
            TextCol1.TextBox.Enabled = False


            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "path"
            TextCol2.HeaderText = "path"
            TextCol2.Width = 1
            TextCol2.TextBox.Enabled = False
            'ts1.GridColumnStyles.Add(TextCol1)
            'GridArchivos.TableStyles.Add(ts1)

            Dim chkcolum As New DataGridBoolColumn
            chkcolum.MappingName = "Inactivo"
            chkcolum.HeaderText = "Activar"
            chkcolum.Width = 40
            chkcolum.NullValue = False
            chkcolum.TrueValue = 0
            chkcolum.FalseValue = 1


            Dim ButtonColStyle As New DataGridButtonColumn(2)
            ButtonColStyle.MappingName = "Boton"
            ButtonColStyle.HeaderText = "Examinar"
            AddHandler ButtonColStyle.CellButtonClicked, AddressOf HandleCellButtonClick

            ButtonColStyle.Width = 50
            ts1.PreferredRowHeight = cboTipos_doctos.ColumnComboBox.Height + 4
            ts1.GridColumnStyles.AddRange(New DataGridColumnStyle() {cboTipos_doctos, TextCol1, ButtonColStyle, chkcolum, TextCol2})


            GridArchivos.TableStyles.Add(ts1)

            AddHandler GridArchivos.MouseUp, AddressOf ButtonColStyle.HandleMouseUp
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MessageBox.Show(ex.ToString & " - Sesiones - " & ex.Message)
            Cursor.Current = Cursors.Default
        End Try

    End Sub

#End Region

#Region " gdarchivos - GridArchivos_CurrentCellChanged, Metodos y Procesos"

    Private Sub GridArchivos_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridArchivos.CurrentCellChanged
        ErrorProvider1.SetError(TxtLugar, "")
        ErrorProvider1.SetError(LblGridArchivos, "")
        GridArchivos.Refresh()
    End Sub

#End Region

#Region " gdarchivos - HandleCellButtonClick, Metodos y Procesos"

    Private Sub HandleCellButtonClick(ByVal sender As Object, ByVal e As DataGridCellButtonClickEventArgs)
        Dim fila = e.RowIndex.ToString()
        Dim col = e.ColIndex.ToString()
        Dim myStream As Stream
        Dim ivalor, i, rows_grid, barrido As Integer
        Dim existearch As Boolean = False
        If fila > CInt(LblcountArch.Text) - 1 Then
            Dim arch As New OpenFileDialog
            If validagrid("archivos 1", fila) Then
                If error1 = True Then
                    error1 = False
                    Exit Sub
                End If
                arch.Filter = "Bloc de Notas, Txt  files (*.txt)|*.txt|Word, Doc files (*.doc)|*.doc|Adobe, Pdf files (*.pdf)|*.pdf|All files (*.*)|*.*"
                arch.FilterIndex = 2
                arch.RestoreDirectory = True
                If arch.ShowDialog() = DialogResult.OK Then
                    rows_grid = GridArchivos.VisibleRowCount
                    For i = 0 To rows_grid - 2
                        If fila <> i Then
                            If arch.FileName.ToString = IIf(IsDBNull(GridArchivos.Item(i, 1)), "", GridArchivos.Item(i, 1)) Then existearch = True
                        End If
                    Next
                    If Not existearch Then
                        Dim namefile As Array = Split(arch.FileName, "\")
                        Dim ext As Array = Split(namefile(namefile.Length - 1), ".")
                        Dim sesion
                        objsesiones.Bandera = 19
                        objsesiones.Buscar()
                        If CboSesiones.Visible = True Then
                            sesion = CboSesiones.SelectedValue
                        Else
                            sesion = objsesiones.Id_Sesion()
                        End If
                        Dim sArchNombre As String
                        sArchNombre = Mid(ext(ext.Length - 2), 1, 14)
                        GridArchivos.Item(fila, 1) = sArchNombre + "SES" + UCase(Mid(GridArchivos.Item(fila, 0), 1, 3)) + Format(CInt(sesion), "0000") + Format(CInt(fila) + 1, "0000") + "." + ext(ext.Length - 1)
                        GridArchivos.Item(fila, 3) = True
                        GridArchivos.Item(fila, 4) = arch.FileName
                    Else
                        MsgBox("Este archivo ya ha sido seleccionado previamente en la lista")
                    End If
                End If
            End If
        End If
    End Sub

#End Region

#Region " gdarchivos - GridArchivos_Leave, Metodos y Procesos"

    Private Sub GridArchivos_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridArchivos.Leave
        Me.GridArchivos.Refresh()
    End Sub

#End Region

#End Region


#End Region

#Region " Forms - FrmSesiones, Metodos y Procesos"

    Private Sub FrmSesiones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim min As DateTime = DateTime.Now
        Dim time As TimeSpan = New TimeSpan(min.TimeOfDay.Days, 7, 0, 0, 0)
        min = DateTime.Today.Add(time)
        DTPkrhoraini.MinDate = min
        DTPkrhoraini.MaxDate = min.AddHours(16)
        DTPkrhoratem.MinDate = DTPkrhoraini.MinDate
        DTPkrhoratem.MaxDate = DTPkrhoraini.MaxDate
        Call Habilita("Nulo")
        Call Crea_DGTemas()
        Call Crea_gdarchivos()
        Call llena_ComiteTreeView()
        Inactivos(GridTemas, GridArchivos, CboSesiones, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, CboResponsable, CkBxSalasANCE, cbosalas, TxtNo_Sol_Sala, CboEquipo)  '
        Oculta(CkBxSalasANCE, Lblchksala, cbosalas, TxtNo_Sol_Sala, Lblsal, LblSol, CboEquipo)
        objempleados.Bandera = 6
        objempleados.ListaCombo(CboResponsable)
        objsalas.Bandera = 1
        objsalas.ListaCombo(cbosalas)
        objsalas.Bandera = 2
        objsalas.ListaCombo(CboEquipo)

    End Sub

    Private Sub FrmSesiones_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        DTSesiones = Nothing
    End Sub

    Private Sub FrmSesiones_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        If iEditar = Nothing Or iEditar = "" Then
            tvComites.Nodes.Clear()
            Call llena_ComiteTreeView()
        End If
    End Sub

    Private Sub FrmSesiones_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        GridArchivos.Refresh()
        Me.Focus()
    End Sub
#End Region

#Region " Tree View, Metodos y Procesos"

#Region " Tree View- tvcolum, Metodos y Procesos"

    Sub Llena_Plantreeview(ByVal TreeViewPlan As TreeView)
        Cursor.Current = Cursors.WaitCursor
        Dim Planes As TreeNode
        Dim Plan As TreeNode
        Dim Temas As TreeNode

        Dim oTablaPlan As DataTable
        Dim oTablaTemas As DataTable

        Dim RegPlan As DataRow
        Dim RegTemas As DataRow
        objplanes.Bandera = 1
        oTablaPlan = objplanes.Listar
        TreeViewPlan.BeginUpdate()
        Planes = TreeViewPlan.Nodes.Add("Selecciona un Plan")
        Planes.ImageIndex = 3
        Planes.SelectedImageIndex = 3

        If oTablaPlan.Rows Is Nothing Then
            TreeViewPlan.EndUpdate()
            TreeViewPlan.AllowDrop = True
            TreeViewPlan.Sorted = True
            Cursor.Current = Cursors.Default
            Exit Sub
        End If

        For Each RegPlan In oTablaPlan.Rows '******Planes
            Plan = Planes.Nodes.Add(Trim(RegPlan("id_plan")))
            objprogtrab.Bandera = 11
            objprogtrab.Id_Plan = Trim(RegPlan("id_plan"))
            oTablaTemas = objprogtrab.Listar
            If oTablaTemas.Rows Is Nothing Then 'Valida si no existen nodos hijos
                GoTo temas
            End If
            For Each RegTemas In oTablaTemas.Rows '******Temas de PNN
                Temas = Plan.Nodes.Add(Trim(RegTemas("id_tema")))
                Temas.ImageIndex = 6
                Temas.SelectedImageIndex = 6
            Next
temas:
        Next
        TreeViewPlan.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TreeViewPlan.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        TreeViewPlan.Sorted = True
        Cursor.Current = Cursors.Default
    End Sub

    Public Sub datostreeview(ByVal row As Integer, ByVal plan As String, ByVal tema As Integer)
        GridTemas.Item(row, 0) = plan
        GridTemas.Item(row, 1) = tema
    End Sub


#End Region

#Region "  Tree View- tvComites, Metodos y Procesos"

#Region "  tvComites - llena_ComiteTreeView , Metodos y Procesos"

    Private Sub llena_ComiteTreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim objNodos As New clsNodos.clsNodos("principal", gUsuario, gPasswordSql)

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvComites.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvComites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tvComites.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvComites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"))
                    '***OK
                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO

                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        '********Sesiones Comite
                        If GTAnt <> SCAnt And GTAnt <> CTAnt And GTAnt <> ComiteAnt Then
                            oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"), "")
                            If oTablaSs.Rows.Count > 0 Then
                                For Each RegSes In oTablaSs.Rows
                                    Ses = GT.Nodes.Add(RegSes("numero"))
                                    Ses.ImageIndex = 5
                                    Ses.SelectedImageIndex = 5
                                Next
                            End If
                        End If
                    Next 'GT
                    oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), "NA", "")
                    '********Sesiones Comite
                    If SCAnt <> CTAnt And SCAnt <> ComiteAnt Then
                        If oTablaSs.Rows.Count > 0 Then
                            For Each RegSes In oTablaSs.Rows
                                Ses = SC.Nodes.Add(RegSes("numero"))
                                Ses.ImageIndex = 5
                                Ses.SelectedImageIndex = 5
                            Next
                        End If
                    End If
sinSC:
                Next 'SC
                oTablaSs = sesiones(RegComite("ID_Comite"), RegCT("ID_CT"), "NA", "NA", "") '********Sesiones Comite
                If CTAnt <> ComiteAnt Then
                    If oTablaSs.Rows.Count > 0 Then
                        For Each RegSes In oTablaSs.Rows
                            Ses = CT.Nodes.Add(RegSes("numero"))
                            Ses.ImageIndex = 5
                            Ses.SelectedImageIndex = 5
                        Next
                    End If
                End If
sinCT:
            Next 'CT

            oTablaSs = sesiones(RegComite("ID_Comite"), "NA", "NA", "NA", "") '********Sesiones Comite
            If oTablaSs.Rows.Count > 0 Then
                For Each RegSes In oTablaSs.Rows
                    Ses = Comite.Nodes.Add(RegSes("numero"))
                    Ses.ImageIndex = 5
                    Ses.SelectedImageIndex = 5
                Next
            End If
sinComite:
        Next 'Comites
        tvComites.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvComites.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvComites.ResetText()

        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  tvComites - tvComites_AfterSelect , Metodos y Procesos"

    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvComites.AfterSelect
        Dim array_texto, lblarray As Array
        Cursor.Current = Cursors.WaitCursor
        ErrorProvider1.SetError(Lblcomite, "")
        Dim valor_nodo, valor As String
        Dim ivalor As Integer

        Dim Nodo As TreeNode
        valor_nodo = e.Node.FullPath
        ivalor = e.Node.ImageIndex
        array_texto = Split(valor_nodo, "\")
        LblTreeView.Text = ""
        For Each valor In array_texto
            If valor <> "Seleccione el comite" Then
                If LblTreeView.Text = "" Then
                    LblTreeView.Text = valor
                Else
                    LblTreeView.Text = LblTreeView.Text + " - " + valor
                End If
            End If
        Next
        lblarray = Split(LblTreeView.Text, " - ")

        If iEditar = "Espera" Or iEditar = "Agregar" Or iEditar = "" Or iEditar = Nothing Then
            Call Llenar_sesiones(CboSesiones, "NA", "NA", "NA", "NA", "")
        End If
        If CboSesiones.Visible = True Then
            Call limpia()
            Activos(tlbBotonera.Buttons(1))
            Inactivos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(4), tlbBotonera.Buttons(5))
            array_texto = Nothing
            array_texto = Split(Regresa_Path(lblarray), " \ ")

            If ivalor = 5 Then
                Inactivos(tlbBotonera.Buttons(1))
                Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(5))
                Call Llenar_sesiones(CboSesiones, array_texto(0), array_texto(1), array_texto(2), array_texto(3), e.Node.Text)
            Else
                Call Llenar_sesiones(CboSesiones, array_texto(0), array_texto(1), array_texto(2), array_texto(3), "")
            End If

            objComites.ID_Comite = array_texto(0)
            objComites.ID_CT = array_texto(1)
            objComites.ID_SC = array_texto(2)
            objComites.ID_GT = array_texto(3)

            Select Case lblarray.Length
                Case 1
                    objComites.Bandera = 1
                    objComites.Busca_uno()
                Case 2
                    If (objComites.ID_Comite <> "" Or objComites.ID_Comite <> "NA") And (objComites.ID_CT = "" Or objComites.ID_CT = "NA") And (objComites.ID_GT <> "" Or objComites.ID_GT <> "NA") Then
                        If (objComites.ID_Comite <> "" Or objComites.ID_Comite <> "NA") And (objComites.ID_CT <> "" Or objComites.ID_CT <> "NA") And (objComites.ID_SC = "" Or objComites.ID_SC = "NA") And (objComites.ID_GT = "" Or objComites.ID_GT = "NA") Then
                            objComites.Bandera = 2
                        Else
                            objComites.Bandera = 4
                        End If
                    Else
                        objComites.Bandera = 2
                    End If
                    objComites.Busca_dos()
                Case 3
                    If (objComites.ID_Comite <> "" Or objComites.ID_Comite <> "NA") And (objComites.ID_CT <> "" Or objComites.ID_CT <> "NA") And (objComites.ID_SC = "" Or objComites.ID_SC = "NA") And (objComites.ID_GT <> "" Or objComites.ID_GT <> "NA") Then
                        objComites.Bandera = 4
                    Else
                        objComites.Bandera = 3
                    End If
                    objComites.Busca_tres()
                Case 4
                    objComites.Bandera = 4
                    objComites.Busca_cuatro()
            End Select
        End If
        If objComites.Responsable <> "" Then
            CboResponsable.SelectedValue = objComites.Responsable()
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

#End Region

#Region " ComboBox , Metodos y Procesos"

#Region " ComboBox - CboSalas, Metodos y Procesos"

    Private Sub CboSalas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ErrorProvider1.SetError(Lblsal, "")
        If sReubica = "Si" Then

        End If
        'If (iEditar = "Editar") And (TxtLugar.Text.ToLower = "ance" And CkBxSalasANCE.CheckState = CheckState.Checked) Then
        '    'Activos(tlbBotonera.Buttons(4))
        'End If
    End Sub

#End Region

#Region " ComboBox - CboEquipo, Metodos y Procesos"

    Private Sub CboEquipo_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboEquipo.SelectedValueChanged
        ErrorProvider1.SetError(Lblsal, "")
        If sReubica = "Si" Then

        End If
        'If (iEditar = "Editar") And (TxtLugar.Text.ToLower = "ance" And CkBxSalasANCE.CheckState = CheckState.Checked) Then
        '    ' Activos(tlbBotonera.Buttons(4))
        'End If
    End Sub

#End Region

#Region " ComboBox - CboSesiones, Metodos y Procesos"

    Private Sub Llenar_sesiones(ByVal cbo As ComboBox, ByVal comite As String, ByVal CT As String, ByVal SC As String, ByVal grupo As String, ByVal compara As String)
        Cursor.Current = Cursors.WaitCursor
        Try
            Dim combotable As DataTable
            combotable = sesiones(comite, CT, SC, grupo, compara)
            cbo.ValueMember = combotable.Columns(0).ColumnName
            cbo.DisplayMember = combotable.Columns(2).ColumnName
            cbo.DataSource = combotable

            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - Al intentar leer datos sobre las sesiones de este comite" + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    Private Sub CboSesiones_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboSesiones.SelectedIndexChanged
        Dim ahora As Array
        Dim ihora
        ErrorProvider1.SetError(CboSesiones, "")
        Cursor.Current = Cursors.WaitCursor
        Try
            With objsesiones
                .Bandera = 2
                .Id_Sesion = CboSesiones.SelectedValue
                .Buscar()
                DTPker.Value = CDate(.Fecha)
                sFechaPk = Format$(CDate(.Fecha), "dd/MM/yyyy")
                shoraiPk = .HoraI
                DTPkrhoraini.Value = CDate(Format$(Now(), "dd/MM/yyyy ") + .HoraI)
                DTPkrhoratem.Value = CDate(Format$(Now(), "dd/MM/yyyy ") + .HoraT)
                shoratPk = .HoraT
                TxtAsunto.Text = .Asunto
                TxtLugar.Text = .Lugar
                'CboResponsable.SelectedValue = .Responsable
                TxtNo_Sol_Sala.Text = ""
                ''If .Lugar.ToLower = "ancerx" And .No_Sol_Sala <> "" Then
                ''    CkBxSalasANCE.CheckState = CheckState.Checked
                ''    objsalas.No_Solicitud = .No_Sol_Sala
                ''    objsalas.Bandera = 3
                ''    objsalas.Buscar()
                ''    TxtNo_Sol_Sala.Text = .No_Sol_Sala
                ''    If objsalas.Id_Sala <> 0 Then cbosalas.SelectedValue = objsalas.Id_Sala Else cbosalas.SelectedValue = objsalas.Id_Propuesta
                ''    Oculta(TxtNo_Sol_Sala, cbosalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                ''    Muestra(cbosalas, Lblchksala, CkBxSalasANCE, TxtNo_Sol_Sala, Lblsal, LblSol)
                ''    Inactivos(CkBxSalasANCE, cbosalas, TxtNo_Sol_Sala)
                ''ElseIf .Lugar.ToLower = "ance" And .No_Sol_Sala = "" Then
                ''    Oculta(TxtNo_Sol_Sala, cbosalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                ''    ' Muestra(CboSalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                ''    Inactivos(cbosalas, CboEquipo)
                ''    'Activos(CkBxSalasANCE)
                ''    'CkBxSalasANCE.CheckState = CheckState.Unchecked
                ''Else
                CkBxSalasANCE.CheckState = CheckState.Unchecked
                Oculta(TxtNo_Sol_Sala, cbosalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                Inactivos(cbosalas, CboEquipo, TxtNo_Sol_Sala, CkBxSalasANCE)
                ''End If
                ''''                     Llena el grid de de Temas y Archivos

                Call Llena_grid(CboSesiones.SelectedValue)
                TxtNotas.Text = .Notas
                CboResponsable.SelectedValue = .Responsable
                LblcountArch.Text = DTArchivos.Rows.Count
                iarchv = DTArchivos.Rows.Count
                GridArchivos.DataSource = DTArchivos

            End With
            Cursor.Current = Cursors.Default
        Catch ex As Exception
            MsgBox("ERROR - al intentar cargar los datos sobre esta sesion " + Chr(13) + Chr(13) + ex.Source + " " + ex.Message, MsgBoxStyle.Critical)
            Cursor.Current = Cursors.Default
        End Try

    End Sub

#End Region

#End Region

#Region " ToolBar, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        GridArchivos_Leave(sender, e)
        tlbBotonera.Focus()
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1                   '''----------   Agregar     --------
                If valida("comites") Then
                    Habilita("Agregar")
                    Inactivos(tvComites)
                    Oculta(CboSesiones, TxtNo_Sol_Sala, cbosalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                    lblSesiones.Text = lblSesiones.Text & " Nueva"
                    iEditar = "Agregar"
                    DTPker.ResetText()
                    sFechaPk = Format$(DTPker.Value, "dd/MM/yyyy")
                    TxtAsunto.Text = "" : TxtLugar.Text = "" : LblcountArch.Text = 0 : Lblcounttemas.Text = 0 : TxtNotas.Text = "" : TxtNo_Sol_Sala.Text = ""
                    DTPkrhoraini.ResetText()
                    DTPkrhoratem.ResetText()
                    cbosalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
                    CkBxSalasANCE.CheckState = CheckState.Unchecked
                    iarchv = 0
                    itemas = 0
                    Call Llena_grid(-1)
                    Activos(GridTemas, GridArchivos, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, GridTemas, GridArchivos, CboResponsable, cbosalas, CboEquipo)
                    DTPker.Focus()

                    'Cambios por MMendoza 02/10/2008 - se agregaron los AllowDelete, AllowEdit, AllowNew
                    DTArchivos.DefaultView.AllowDelete = False
                    DTArchivos.DefaultView.AllowEdit = True
                    DTArchivos.DefaultView.AllowNew = True
                Else
                    Dim Frmcomite As New frmP_Comite
                    If MsgBox("�Deseas crear un nuevo comite?", MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        ErrorProvider1.SetError(Lblcomite, "")
                        Frmcomite.Show()
                    End If
                End If
            Case 2                   '''----------   Edita     --------
                If CboSesiones.Items.Count >= 0 Then
                    If CboSesiones.SelectedValue <> 0 Then
                        sFechaPk = DTPker.Text
                        Habilita("Agregar")
                        Inactivos(tvComites, CboSesiones)
                        iEditar = "Editar"
                        ''If TxtLugar.Text.ToLower = "ance" And TxtNo_Sol_Sala.Text <> "" Then
                        ''    CkBxSalasANCE.CheckState = CheckState.Checked
                        ''    Oculta(TxtNo_Sol_Sala, CboSalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                        ''    Muestra(CboSalas, TxtNo_Sol_Sala, Lblsal, LblSol)
                        ''    Inactivos(CkBxSalasANCE, CboSalas, TxtNo_Sol_Sala)
                        ''ElseIf TxtLugar.Text.ToLower = "ance" And TxtNo_Sol_Sala.Text = "" Then
                        ''    Oculta(TxtNo_Sol_Sala, CboSalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                        ''    Muestra(CboSalas, CboEquipo, Lblsal, LblSol)
                        ''    Inactivos(CboSalas, CboEquipo)
                        ''    Activos(CkBxSalasANCE)
                        ''Else
                        giStatus = 1
                        Oculta(TxtNo_Sol_Sala, cbosalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                        Inactivos(cbosalas, CboEquipo, TxtNo_Sol_Sala, CkBxSalasANCE)
                        ''End If
                        Activos(GridTemas, GridArchivos, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, GridTemas, GridArchivos, CboResponsable)
                        DTPker.Focus()
                        ErrorProvider1.SetError(CboSesiones, "")

                        'Cambios por MMendoza 02/10/2008 - se agregaron los AllowDelete, AllowEdit, AllowNew
                        DTArchivos.DefaultView.AllowDelete = False
                        DTArchivos.DefaultView.AllowEdit = True
                        DTArchivos.DefaultView.AllowNew = True

                    Else
                        ErrorProvider1.SetError(CboSesiones, "Debes seleccionar una sesion, para poder editarla")
                    End If
                Else
                    ErrorProvider1.SetError(CboSesiones, "Debes seleccionar un Comite que contenga sesiones, para poder editarlas")
                End If
            Case 3                   '''----------   Deshacer     --------+}
                giStatus = 0
                Habilita("Nulo")
                Inactivos(GridTemas, GridArchivos, CboSesiones, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, CboResponsable, Lblchksala, CkBxSalasANCE, cbosalas, TxtNo_Sol_Sala, tlbBotonera.Buttons(4))  '
                Oculta(CkBxSalasANCE, Lblchksala, cbosalas, TxtNo_Sol_Sala, Lblsal, LblSol, CboEquipo)
                Muestra(CboSesiones)
                iEditar = ""
                lblSesiones.Text = "Clave Sesion: "
                Activos(tvComites)
                DTPker.ResetText()
                sFechaPk = DTPker.Text
                TxtAsunto.Text = "" : TxtLugar.Text = "" : LblcountArch.Text = 0 : Lblcounttemas.Text = 0 : TxtNotas.Text = ""
                DTPkrhoraini.ResetText()
                DTPkrhoratem.ResetText()
                cbosalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
                iarchv = 0
                itemas = 0
                Call Llena_grid(-1)
                tvComites.Refresh()
                tvComites.Nodes.Clear()
                Call llena_ComiteTreeView()

            Case 4                   '''----------   Guardar     --------
                Try
                    giStatus = 0
                    If valida("comites") And valida("Horario") And valida("Asunto") Then
                        Inactivos(tlbBotonera)
                        If DTPker.Value <= Now.Date Then
                            sPasada = "pasada"
                        Else
                            sPasada = ""
                        End If
                        Accion = guardar()
                        Activos(tlbBotonera)
                        If Accion Then
                            Habilita("Nulo")
                            Oculta(CkBxSalasANCE, Lblchksala, cbosalas, TxtNo_Sol_Sala, Lblsal, LblSol, CboEquipo)
                            Muestra(CboSesiones)
                            iEditar = Nothing
                            sFechaPk = ""
                            sReubica = ""
                            Activos(tvComites)
                            lblSesiones.Text = "Clave Sesion: "
                            DTPker.ResetText()
                            sFechaPk = DTPker.Text
                            TxtAsunto.Text = "" : TxtLugar.Text = "" : LblcountArch.Text = 0 : Lblcounttemas.Text = 0 : TxtNotas.Text = ""
                            DTPkrhoraini.ResetText()
                            DTPkrhoratem.ResetText()
                            cbosalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
                            iarchv = 0
                            ErrorProvider1.SetError(TxtLugar, "")
                            ErrorProvider1.SetError(Me, "")
                            itemas = 0
                            Call Llena_grid(-1)

                            tvComites.Refresh()
                            tvComites.Nodes.Clear()
                            Call llena_ComiteTreeView()
                            Inactivos(GridTemas, GridArchivos, CboSesiones, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, CboResponsable, Lblchksala, CkBxSalasANCE, cbosalas, TxtNo_Sol_Sala, tlbBotonera.Buttons(4))  '
                        End If
                    End If
                Catch ex As Exception When Accion = False
                    MsgBox("Error C000  " + Chr(13) + Chr(13) + "Faltan datos en el formulario." + Chr(13) + ex.Message, MsgBoxStyle.Critical)
                End Try
            Case 5                   '''----------   Eliminar     --------
                    If CboSesiones.Items.Count >= 0 Then
                        If CboSesiones.SelectedValue <> 0 Then
                            ErrorProvider1.SetIconAlignment(LblTreeView, ErrorIconAlignment.MiddleRight)
                            ErrorProvider1.SetError(LblTreeView, "Estas a punto de eliminar esta Sesion")
                            If MsgBox("�Estas seguro que deseas eliminar esta Sesion?", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                                Habilita("Nulo")
                                If Eliminar() Then
                                    iEditar = Nothing
                                    Activos(tvComites)
                                    Inactivos(GridTemas, GridArchivos, DTPker, DTPkrhoraini, DTPkrhoratem, TxtNotas, TxtAsunto, TxtLugar, GridTemas, GridArchivos, CboResponsable, cbosalas, CboEquipo)
                                    Oculta(CboSesiones, TxtNo_Sol_Sala, cbosalas, Lblchksala, CkBxSalasANCE, CboEquipo, Lblsal, LblSol)
                                    Muestra(CboSesiones)
                                    lblSesiones.Text = "Clave Sesion: "
                                    DTPker.ResetText()
                                    sFechaPk = Format$(DTPker.Value, "dd/MM/yyyy")
                                    TxtAsunto.Text = "" : TxtLugar.Text = "" : LblcountArch.Text = 0 : Lblcounttemas.Text = 0 : TxtNotas.Text = "" : TxtNo_Sol_Sala.Text = ""
                                    DTPkrhoraini.ResetText()
                                    DTPkrhoratem.ResetText()
                                    cbosalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
                                    CkBxSalasANCE.CheckState = CheckState.Unchecked
                                    iarchv = 0
                                    itemas = 0
                                    Call Llena_grid(-1)
                                    tvComites.Nodes.Clear()
                                    Call llena_ComiteTreeView()
                                    '   iEditar = "Espera"
                                End If
                            Else
                                ErrorProvider1.SetError(LblTreeView, "Estabas a punto de eliminar esta sesion")
                            End If
                            ErrorProvider1.SetError(LblTreeView, "")
                        Else
                            ErrorProvider1.SetError(LblTreeView, "Debes seleccionar una sesion, para poder editarla")
                        End If
                    Else
                        ErrorProvider1.SetError(LblTreeView, "Debes seleccionar un Comite que contenga sesiones, para poder editarlas")
                    End If
            Case 7                   '''----------   Salir     --------
                    iEditar = "Espera"
                    Me.Close()
        End Select

        Cursor.Current = Cursors.Default
    End Sub

    'Private Sub tlbBotonera_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tlbBotonera.MouseMove
    '    tlbBotonera.Focus()
    'End Sub


#End Region

#Region " TextBox, Metodos y Procesos"

#Region " TextBox - TxtNotas, Metodos y Procesos"

    'Private Sub TxtNotas_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNotas.TextChanged
    '    'If iEditar = "Editar" Then Activos(tlbBotonera.Buttons(4))
    'End Sub

    Private Sub TxtNotas_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtNotas.KeyPress
        If e.KeyChar = "'"c Then
            e.Handled = True
        End If
    End Sub

#End Region

#Region " TextBox - TxtAsunto, Metodos y Procesos"

    'Private Sub TxtAsunto_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtAsunto.TextChanged
    '    Activos(tlbBotonera.Buttons(4))
    'End Sub

    Private Sub TxtAsunto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtAsunto.KeyPress
        If e.KeyChar = "'"c Then
            e.Handled = True
        End If
    End Sub

#End Region

#Region " TextBox - TxtLugar, Metodos y Procesos"

    Private Sub TxtLugar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtLugar.KeyPress
        If e.KeyChar.IsLetterOrDigit(e.KeyChar) AndAlso Not e.KeyChar.IsControl(e.KeyChar) Or e.KeyChar = ControlChars.Back Then
            e.Handled = False
            Call TxtLugar_TextChanged(TxtLugar, e)
        End If
        If e.KeyChar = "'"c Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtLugar_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtLugar.Leave
        ErrorProvider1.SetError(TxtLugar, "")
        If (TxtLugar.Text) <> "" Then
            If (iEditar = "Editar" Or iEditar = "Reprograma") And CboSesiones.Visible = True Then
                With objsesiones
                    .Bandera = 2
                    .Id_Sesion = CboSesiones.SelectedValue
                    .Buscar()
                    If .Lugar.ToLower = Trim(TxtLugar.Text.ToLower) And .No_Sol_Sala <> "" Then                          '''     Cancela la Solicitud de salas " 2 "
                        Muestra(cbosalas, Lblchksala, TxtNo_Sol_Sala, Lblsal, LblSol, CkBxSalasANCE)
                        Inactivos(cbosalas, Lblchksala, TxtNo_Sol_Sala, Lblsal, LblSol, CkBxSalasANCE)
                    ElseIf .Lugar.ToLower <> Trim(TxtLugar.Text.ToLower) And .No_Sol_Sala <> "" Then
                        ErrorProvider1.SetError(TxtLugar, "Esta acci�n CANCELARA el uso de tu sala, " + Chr(13) + " que se asigno dentro Ance")
                        If MsgBox("Esta acci�n CANCELARA el uso de tu sala,  que se asigno en las instalaciones de Ance." + Chr(13) + Chr(13) + "�Estas seguro del Cambio que estas realizando en este momento?", MsgBoxStyle.Critical + MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                            sReubica = "Si"                        '''     Cancela la Solicitud de salas " 2 "
                            Oculta(CkBxSalasANCE, Lblchksala, cbosalas, TxtNo_Sol_Sala, Lblsal, LblSol, CboEquipo)
                            GridTemas.Focus()
                        Else
                            TxtLugar.Text = .Lugar
                        End If
                    End If
                End With
            End If
        ElseIf iEditar <> Nothing Or iEditar <> "" Then
            ErrorProvider1.SetError(TxtLugar, "No puede realizar esta acci�n," + Chr(13) + " ya que esta vacia la caja de lugar de sesion.")
            TxtLugar.Focus()
        End If
    End Sub

    Private Sub TxtLugar_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtLugar.TextChanged
        Dim ahora As Array
        objsesiones.Bandera = 2
        objsesiones.Id_Sesion = CboSesiones.SelectedValue
        objsesiones.Buscar()
        If iEditar = "Agregar" Or iEditar = "Espera" Then
            'If Trim(TxtLugar.Text.ToUpper) = "ANCE" Then
            If Trim(TxtLugar.Text.ToUpper) = "No Aplica_" Then
                Muestra(Lblchksala, CkBxSalasANCE)
                Activos(CkBxSalasANCE) ', CboEquipo, LblSol
            Else
                Oculta(Lblchksala, CkBxSalasANCE)
                Inactivos(CkBxSalasANCE)
            End If
        ElseIf (iEditar = "Editar") And CboEquipo.Visible = True Then
            'If Trim(TxtLugar.Text.ToUpper) = "ANCE" Then
            If Trim(TxtLugar.Text.ToUpper) = "No Aplica_" Then
                Muestra(Lblchksala, CkBxSalasANCE)
                Activos(CkBxSalasANCE) ', CboEquipo, LblSol
            Else
                Oculta(Lblchksala, CkBxSalasANCE)
                Inactivos(CkBxSalasANCE)
            End If
        ElseIf (iEditar = "Reprograma") And CboSesiones.Visible = True Then
            sReubica = "Si"
            'If Trim(TxtLugar.Text.ToUpper) = "ANCE" Then
            If Trim(TxtLugar.Text.ToUpper) = "No Aplica_" Then
                Muestra(Lblchksala, CkBxSalasANCE)
                Activos(CkBxSalasANCE, Lblchksala) ', CboEquipo, LblSol
            Else
                Oculta(Lblchksala, CkBxSalasANCE)
                Inactivos(CkBxSalasANCE)
            End If
        End If
        Call TxtLugar_Leave(TxtLugar, e)
    End Sub

#End Region

#End Region

#Region " Checkbox, Metodos y Procesos"

    Private Sub CkBxSalasANCE_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CkBxSalasANCE.CheckedChanged
        cbosalas.SelectedValue = 0 : CboEquipo.SelectedValue = 0
        If CkBxSalasANCE.CheckState = CheckState.Checked Then
            Muestra(cbosalas, Lblsal, CboEquipo, LblSol)
            Activos(cbosalas, Lblsal, CboEquipo, LblSol)
        Else
            Oculta(cbosalas, Lblsal, CboEquipo, LblSol)
            Inactivos(cbosalas, Lblsal, CboEquipo, LblSol)
        End If

    End Sub

    Private Sub CkBxSalasANCE_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CkBxSalasANCE.EnabledChanged
        CkBxSalasANCE.Checked = CheckState.Unchecked
    End Sub

#End Region

#Region " DatePacker, Metodos y Procesos"

#Region " DatePacker - DTPker , Metodos y Procesos"

    Private Sub DTPker_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPker.ValueChanged
        ErrorProvider1.SetError(DTPker, "")
        If CInt(Format$(DTPker.Value, "dd")) <= CInt(Format$(Now(), "dd")) And CInt(Format$(DTPker.Value, "MM")) <= CInt(Format$(Now(), "MM")) And CInt(Format$(DTPker.Value, "yyyy")) <= CInt(Format$(Now(), "yyyy")) And (iEditar = "Editar") Then
            If CboSesiones.Visible = True And TxtNo_Sol_Sala.Visible = True Then
                ErrorProvider1.SetError(DTPker, "Esta acci�n CANCELARA el uso de tu sala," + Chr(13) + " que se asigno dentro Ance")
                If MsgBox("�Estas seguro del Cambio que estas realizando en este momento?", MsgBoxStyle.Critical + MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    iEditar = "Reprograma"
                    'Activos(tlbBotonera.Buttons(4))
                    Muestra(cbosalas, Lblchksala, CboEquipo, Lblsal, LblSol, CkBxSalasANCE)
                    Oculta(cbosalas, Lblsal, CboEquipo, TxtNo_Sol_Sala, LblSol)
                    Inactivos(cbosalas, Lblchksala, CboEquipo, TxtNo_Sol_Sala, Lblsal, LblSol, CkBxSalasANCE)
                    DTPkrhoraini.Focus()
                ElseIf CboSesiones.Visible = True And TxtNo_Sol_Sala.Visible = False Then
                    iEditar = "Reprograma"
                    'Activos(tlbBotonera.Buttons(4))
                    Muestra(cbosalas, Lblchksala, CboEquipo, Lblsal, LblSol, CkBxSalasANCE)
                    Oculta(cbosalas, Lblsal, CboEquipo, TxtNo_Sol_Sala, LblSol)
                    Inactivos(cbosalas, Lblchksala, CboEquipo, TxtNo_Sol_Sala, Lblsal, LblSol, CkBxSalasANCE)
                    DTPkrhoraini.Focus()
                Else
                    ErrorProvider1.SetError(DTPker, "")
                    sError = iEditar
                    iEditar = "Reset"
                    DTPker.Value = sFechaPk
                    iEditar = sError
                End If
            ElseIf (iEditar = "Espera") Then
                iEditar = "Agregar" '    Alta
                'Activos(tlbBotonera.Buttons(4))
            End If
        End If
    End Sub

#End Region

#Region " DatePacker - DTPkrhoraini , Metodos y Procesos"

    Private Sub DTPkrhoraini_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPkrhoraini.ValueChanged
        ErrorProvider1.SetError(Lblhi, "")
        ErrorProvider1.SetError(Lblht, "")
        If (iEditar = "Editar") And (shoraiPk <> "07:00" And shoratPk <> "07:00") Then
            If shoraiPk <> CStr(DTPkrhoraini.Value) And CboSesiones.Visible = True Then
                If MsgBox("�Estas seguro del Cambio que estas realizando en este momento de minutos  de inicio?", MsgBoxStyle.Critical + MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    iEditar = "Reprograma"
                    Activos(tlbBotonera.Buttons(4), CkBxSalasANCE, cbosalas, TxtNo_Sol_Sala)
                    Oculta(CkBxSalasANCE, Lblchksala, cbosalas, TxtNo_Sol_Sala, Lblsal, LblSol, CboEquipo)
                    'Activos(tlbBotonera.Buttons(4))
                    TxtAsunto.Focus()
                Else
                    ErrorProvider1.SetError(Lblhi, "")
                    ErrorProvider1.SetError(Lblht, "")
                    restaura_combo(DTPkrhoraini, shoraiPk)
                End If
            ElseIf (iEditar = "Espera") Then
                iEditar = "Agregar" '    Alta
                Activos(tlbBotonera.Buttons(4))
            End If
        End If
    End Sub

#End Region

#Region " DatePacker - DTPkrhoratem, Metodos y Procesos"

    Private Sub DTPkrhoratem_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DTPkrhoratem.ValueChanged
        ErrorProvider1.SetError(Lblhi, "")
        ErrorProvider1.SetError(Lblht, "")
        If (iEditar = "Editar") And (shoraiPk <> "07:00" And shoratPk <> "07:00") Then
            If shoratPk <> CStr(DTPkrhoratem.Value) And CboSesiones.Visible = True Then
                If MsgBox("�Estas seguro del Cambio que estas realizando en este momento de minutos  de salida?", MsgBoxStyle.Critical + MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    iEditar = "Reprograma"
                    Activos(tlbBotonera.Buttons(4), CkBxSalasANCE, cbosalas, TxtNo_Sol_Sala)
                    Oculta(CkBxSalasANCE, Lblchksala, cbosalas, TxtNo_Sol_Sala, Lblsal, LblSol, CboEquipo)
                    Activos(tlbBotonera.Buttons(4))
                    TxtAsunto.Focus()
                Else
                    ErrorProvider1.SetError(Lblhi, "")
                    ErrorProvider1.SetError(Lblht, "")
                    restaura_combo(DTPkrhoratem, shoratPk)
                End If
            ElseIf (iEditar = "Espera") Then
                iEditar = "Agregar" '    Alta
                Activos(tlbBotonera.Buttons(4))
            End If
        End If
    End Sub

#End Region

#End Region

    Private Sub Referenciar(ByVal tipo As String)
        ObjPrograma.Band = False
        If tipo <> "" Then ObjPrograma.Tipo = "abandono"
        ObjPrograma.Buscar(splan, stema)
        srefp = ObjPrograma.RefA�o + ObjPrograma.RefComite + ObjPrograma.RefConsecutivo + ObjPrograma.RefRegreso + ObjPrograma.RefTraspaso
    End Sub


End Class

