
     '*****************************************************************************
     '*****************************************************************************
     '                       ESTOS SON LOS CAMPOS LLAVE QUE TIENE LA TABLA
     '              Id_Plan
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Plan Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 08/08/2006 10:38:25 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Plan

     '''''''Declaracion de Variables Privadas
     Private dsP_Plan AS New DataSet
    Private _Id_Plan As System.String
    Private _Bandera As Integer
    Private _Descripcion As System.String
    Private _F_Envio_CNN As String
    Private _Publicado_DOF As String
    Private _Enviado_CNN As String
    Private _Prim_Pub As String
    Private _Tipo As System.String
     Private _Dof as System.String
    Private _F_inicio As String
    Private _F_Fin As String
    Private _status As Integer
    Private sSql As String
    Private _encontrado As Boolean

    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property Id_Plan() As System.String
          Get
              Return _Id_Plan
          End Get
          Set(Value as System.String)
              _Id_Plan = Value
          End Set
     End Property

     Public Property Tipo() As System.String
          Get
              Return _Tipo
          End Get
          Set(Value as System.String)
              _Tipo = Value
          End Set
     End Property

     Public Property Dof() As System.String
          Get
              Return _Dof
          End Get
          Set(Value as System.String)
              _Dof = Value
          End Set
     End Property

    Public Property F_inicio() As String
        Get
            Return _F_inicio
        End Get
        Set(ByVal Value As String)
            _F_inicio = Value
        End Set
    End Property
    Public Property Descripcion() As System.String
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value As System.String)
            _Descripcion = Value
        End Set
    End Property

    Public Property F_Fin() As String
        Get
            Return _F_Fin
        End Get
        Set(ByVal Value As String)
            _F_Fin = Value
        End Set
    End Property

    Public Property status() As System.Int32
        Get
            Return _status
        End Get
        Set(ByVal Value As System.Int32)
            _status = Value
        End Set
    End Property
    Public Property F_Envio_CNN() As String
        Get
            Return _F_Envio_CNN
        End Get
        Set(ByVal Value As String)
            _F_Envio_CNN = Value
        End Set
    End Property
    Public Property Publicado_DOF() As System.String
        Get
            Return _Publicado_DOF
        End Get
        Set(ByVal Value As System.String)
            _Publicado_DOF = Value
        End Set
    End Property
    Public Property Enviado_CNN() As System.String
        Get
            Return _Enviado_CNN
        End Get
        Set(ByVal Value As System.String)
            _Enviado_CNN = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _encontrado
        End Get
        Set(ByVal Value As Boolean)
            _encontrado = Value
        End Set
    End Property
    Public Property Prim_Pub() As System.String
        Get
            Return _Prim_Pub
        End Get
        Set(ByVal Value As System.String)
            _Prim_Pub = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal cbo As Object)
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_Plan_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Planes")


        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
            cbo.DataSource = dt
        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_Plan_Buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)


        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("Planes")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Sub Inicializa(ByVal Identificador As Integer, ByVal Usuario As String, ByVal Password As String)
        If cn.State = ConnectionState.Open Then cn.Close()
        objconexion.Conexion(Identificador, Usuario, Password)
        cn.ConnectionString = "Data source = " + objconexion.SserverC + "; Initial Catalog = " + objconexion.SBaseD + "; User Id = " + Usuario + "; Pwd =  " + Password
    End Sub

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Plan WHERE id_plan='" & sClave & "'"
        Dim dr As SqlDataReader
        Dim cmd As New SqlCommand(sSql, cn)
        If cn.State = 1 Then cn.Close()

        cn.Open()
        dr = cmd.ExecuteReader
        If dr.Read Then
            _Id_Plan = dr("Id_Plan")
            _Tipo = dr("Tipo")

            _F_inicio = IIf(IsDBNull(dr("F_inicio")) = True, "", dr("F_inicio"))
            _F_Fin = IIf(IsDBNull(dr("F_Fin")) = True, "", dr("F_Fin"))
            _status = dr("status")
            _Descripcion = IIf(IsDBNull(dr("Descripcion")) = True, "", dr("Descripcion"))
            _F_Envio_CNN = IIf(IsDBNull(dr("F_Envio_CNN")) = True, "", dr("F_Envio_CNN"))
            _Publicado_DOF = IIf(IsDBNull(dr("Publicado_DOF")) = True, "", dr("Publicado_DOF"))
            _Prim_Pub = IIf(IsDBNull(dr("f_primpub")) = True, "", dr("f_primpub"))
            _encontrado = True
        Else
            _Id_Plan = ""
            _Tipo = ""

            _F_inicio = Nothing
            _F_Fin = Nothing
            _status = Nothing
            _F_Envio_CNN = Nothing
            _Publicado_DOF = Nothing
            _Prim_Pub = Nothing
            _encontrado = False
        End If

    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal bandera As String, ByVal ID_plan As String, ByVal Descripcion As String, ByVal tipo As String, ByVal Dof As String, ByVal F_Inicio As String, ByVal f_Fin As String, ByVal status As Integer, ByVal F_Cnn As String, ByVal Pub_Dof As String, ByVal F_PrimPub As String) As String
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Plan"
        cmd.Parameters.Add("@Id_PLAN", ID_plan)
        cmd.Parameters.Add("@Descripcion", Descripcion)
        cmd.Parameters.Add("@Tipo", tipo)
        cmd.Parameters.Add("@F_Inicio", F_Inicio)
        cmd.Parameters.Add("@F_fin", f_Fin)
        cmd.Parameters.Add("@Status", status)
        cmd.Parameters.Add("@F_Envio_CNN", F_Cnn)
        cmd.Parameters.Add("@Publicado_DOF", Pub_Dof)
        cmd.Parameters.Add("@F_PrimPub", F_PrimPub)
        cmd.Parameters.Add("@Bandera", bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar(ByVal bandera As String, ByVal ID_plan As String, ByVal Descripcion As String, ByVal tipo As String, ByVal Dof As String, ByVal F_Inicio As String, ByVal f_Fin As String, ByVal status As Integer, ByVal F_Cnn As String, ByVal Pub_Dof As String, ByVal F_PrimPub As String) As String
        Dim cmd As New SqlCommand
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Sp_Plan"
        cmd.Parameters.Add("@Id_PLAN", ID_plan)
        cmd.Parameters.Add("@Descripcion", Descripcion)
        cmd.Parameters.Add("@Tipo", tipo)
        cmd.Parameters.Add("@F_Inicio", F_Inicio)
        cmd.Parameters.Add("@F_fin", f_Fin)
        cmd.Parameters.Add("@Status", status)
        cmd.Parameters.Add("@F_Envio_CNN", F_Cnn)
        cmd.Parameters.Add("@Publicado_DOF", Pub_Dof)
        cmd.Parameters.Add("@F_PrimPub", F_PrimPub)
        cmd.Parameters.Add("@Bandera", bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
