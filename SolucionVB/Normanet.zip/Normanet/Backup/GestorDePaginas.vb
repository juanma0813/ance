Imports System.Configuration
Imports System.IO
Imports System.Windows.Forms
Imports System.Windows

Public Class frmGestor
    Inherits System.Windows.Forms.Form

    Private _Id_Pagina As Integer
    Private _Id_Grupo As Integer
    Private _Guarde As Boolean
    Private _DtTmpGaleria As DataTable
    Private _DtTempDoctos As DataTable
    Private _DtTempLigas As DataTable
    Private _Edicion As Boolean

    REM controles extra
    Dim objArbol As New TreeView

    Private Property Id_Pagina() As Integer
        Get
            Return _Id_Pagina
        End Get
        Set(ByVal Value As Integer)
            _Id_Pagina = Value
        End Set
    End Property

    Private Property Id_Grupo() As Integer
        Get
            Return _Id_Grupo
        End Get
        Set(ByVal Value As Integer)
            _Id_Grupo = Value
        End Set
    End Property

    Private Property Guarde() As Boolean
        Get
            Return _Guarde
        End Get
        Set(ByVal Value As Boolean)
            _Guarde = Value
        End Set
    End Property

    Private Property Edicion() As Boolean
        Get
            Return _Edicion
        End Get
        Set(ByVal Value As Boolean)
            _Edicion = Value
        End Set
    End Property

    Private Property DtTempGaleria() As DataTable
        Get
            Return _DtTmpGaleria
        End Get
        Set(ByVal Value As DataTable)
            _DtTmpGaleria = Value
        End Set
    End Property

    Private Property DtTempDoctos() As DataTable
        Get
            Return _DtTempDoctos
        End Get
        Set(ByVal Value As DataTable)
            _DtTempDoctos = Value
        End Set
    End Property

    Private Property DtTempLigas() As DataTable
        Get
            Return _DtTempLigas
        End Get
        Set(ByVal Value As DataTable)
            _DtTempLigas = Value
        End Set
    End Property

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents lstImagenes As System.Windows.Forms.ImageList
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton8 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton9 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton10 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton11 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton12 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton13 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton14 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton16 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton17 As System.Windows.Forms.ToolBarButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton18 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton19 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton20 As System.Windows.Forms.ToolBarButton
    Friend WithEvents TabGrupos As System.Windows.Forms.TabControl
    Friend WithEvents grdGrupos As System.Windows.Forms.DataGrid
    Friend WithEvents btnAdjuntar As System.Windows.Forms.Button
    Friend WithEvents txtImagenAdjunta As System.Windows.Forms.TextBox
    Friend WithEvents txtNombreImagen As System.Windows.Forms.TextBox
    Friend WithEvents tlbGalerias As System.Windows.Forms.ToolBar
    Friend WithEvents txtTextoGrupo As System.Windows.Forms.TextBox
    Friend WithEvents txtDescripcionGrupo As System.Windows.Forms.TextBox
    Friend WithEvents tlbGrupos As System.Windows.Forms.ToolBar
    Friend WithEvents txtNombreGrupo As System.Windows.Forms.TextBox
    Friend WithEvents TabLigas As System.Windows.Forms.TabControl
    Friend WithEvents grdLigas As System.Windows.Forms.DataGrid
    Friend WithEvents btnAdjuntarDoctoLiga As System.Windows.Forms.Button
    Friend WithEvents txtDocumentoAdjuntoLiga As System.Windows.Forms.TextBox
    Friend WithEvents txtDocumentoLiga As System.Windows.Forms.TextBox
    Friend WithEvents txtLigaExterna As System.Windows.Forms.TextBox
    Friend WithEvents OptPaginasContenido As System.Windows.Forms.RadioButton
    Friend WithEvents optRepositorio As System.Windows.Forms.RadioButton
    Friend WithEvents txtTextoLiga As System.Windows.Forms.TextBox
    Friend WithEvents cboTipoLiga As System.Windows.Forms.ComboBox
    Friend WithEvents txtNombreLiga As System.Windows.Forms.TextBox
    Friend WithEvents txtGrupoDeContenido As System.Windows.Forms.TextBox
    Friend WithEvents txtTituloPagina As System.Windows.Forms.TextBox
    Friend WithEvents tblGeneral As System.Windows.Forms.ToolBar
    Friend WithEvents cboTipoPagina As System.Windows.Forms.ComboBox
    Friend WithEvents txtDocumentoAdjunta As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtNombreDocto As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton21 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton22 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton23 As System.Windows.Forms.ToolBarButton
    Friend WithEvents chkDoctoRestringido As System.Windows.Forms.CheckBox
    Friend WithEvents cboNombrePagina As System.Windows.Forms.ComboBox
    Friend WithEvents grdGaleria As System.Windows.Forms.DataGrid
    Friend WithEvents btnAdjuntarListDocto As System.Windows.Forms.Button
    Friend WithEvents tblLigas As System.Windows.Forms.ToolBar
    Friend WithEvents TabGeneral As System.Windows.Forms.TabControl
    Friend WithEvents tpGrupos As System.Windows.Forms.TabPage
    Friend WithEvents tpListadoGrupos As System.Windows.Forms.TabPage
    Friend WithEvents tpGaleria As System.Windows.Forms.TabPage
    Friend WithEvents tpListadoDoctos As System.Windows.Forms.TabPage
    Friend WithEvents tpContenido As System.Windows.Forms.TabPage
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton24 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton25 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton26 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton27 As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlbListadoDoctos As System.Windows.Forms.ToolBar
    Friend WithEvents grdListadoDocumentos As System.Windows.Forms.DataGrid
    Friend WithEvents tpLigaLista As System.Windows.Forms.TabPage
    Friend WithEvents tpLigaDocto As System.Windows.Forms.TabPage
    Friend WithEvents tpLigaExterna As System.Windows.Forms.TabPage
    Friend WithEvents tpLigaDinamicas As System.Windows.Forms.TabPage
    Friend WithEvents optPreestablecidas As System.Windows.Forms.RadioButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents chkRestringirDoctoLiga As System.Windows.Forms.CheckBox
    Friend WithEvents cboPaginas As System.Windows.Forms.ComboBox
    Friend WithEvents ToolBarButton15 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdRegresarGrupos As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtPertenece As System.Windows.Forms.TextBox
    Friend WithEvents ToolBarButton28 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdCopiar As System.Windows.Forms.Button
    Friend WithEvents cmdPegar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmGestor))
        Me.lstImagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabGeneral = New System.Windows.Forms.TabControl
        Me.tpGrupos = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmdPegar = New System.Windows.Forms.Button
        Me.cmdCopiar = New System.Windows.Forms.Button
        Me.TabGrupos = New System.Windows.Forms.TabControl
        Me.tpListadoGrupos = New System.Windows.Forms.TabPage
        Me.grdGrupos = New System.Windows.Forms.DataGrid
        Me.tpGaleria = New System.Windows.Forms.TabPage
        Me.grdGaleria = New System.Windows.Forms.DataGrid
        Me.btnAdjuntar = New System.Windows.Forms.Button
        Me.txtImagenAdjunta = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtNombreImagen = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.tlbGalerias = New System.Windows.Forms.ToolBar
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton16 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton25 = New System.Windows.Forms.ToolBarButton
        Me.tpListadoDoctos = New System.Windows.Forms.TabPage
        Me.txtPertenece = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.chkDoctoRestringido = New System.Windows.Forms.CheckBox
        Me.grdListadoDocumentos = New System.Windows.Forms.DataGrid
        Me.btnAdjuntarListDocto = New System.Windows.Forms.Button
        Me.txtDocumentoAdjunta = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtNombreDocto = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.tlbListadoDoctos = New System.Windows.Forms.ToolBar
        Me.ToolBarButton21 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton22 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton23 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton26 = New System.Windows.Forms.ToolBarButton
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtTextoGrupo = New System.Windows.Forms.TextBox
        Me.txtDescripcionGrupo = New System.Windows.Forms.TextBox
        Me.tlbGrupos = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton8 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton24 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton28 = New System.Windows.Forms.ToolBarButton
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtNombreGrupo = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.tpContenido = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.tblLigas = New System.Windows.Forms.ToolBar
        Me.ToolBarButton9 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton10 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton13 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton20 = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton27 = New System.Windows.Forms.ToolBarButton
        Me.cmdRegresarGrupos = New System.Windows.Forms.ToolBarButton
        Me.TabLigas = New System.Windows.Forms.TabControl
        Me.tpLigaLista = New System.Windows.Forms.TabPage
        Me.grdLigas = New System.Windows.Forms.DataGrid
        Me.tpLigaDocto = New System.Windows.Forms.TabPage
        Me.btnAdjuntarDoctoLiga = New System.Windows.Forms.Button
        Me.chkRestringirDoctoLiga = New System.Windows.Forms.CheckBox
        Me.txtDocumentoAdjuntoLiga = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtDocumentoLiga = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.tpLigaExterna = New System.Windows.Forms.TabPage
        Me.txtLigaExterna = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.tpLigaDinamicas = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.optPreestablecidas = New System.Windows.Forms.RadioButton
        Me.cboPaginas = New System.Windows.Forms.ComboBox
        Me.OptPaginasContenido = New System.Windows.Forms.RadioButton
        Me.optRepositorio = New System.Windows.Forms.RadioButton
        Me.txtTextoLiga = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.cboTipoLiga = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtNombreLiga = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtGrupoDeContenido = New System.Windows.Forms.TextBox
        Me.txtTituloPagina = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.tblGeneral = New System.Windows.Forms.ToolBar
        Me.ToolBarButton11 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton12 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton19 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton14 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton17 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton18 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton15 = New System.Windows.Forms.ToolBarButton
        Me.Label16 = New System.Windows.Forms.Label
        Me.cboTipoPagina = New System.Windows.Forms.ComboBox
        Me.cboNombrePagina = New System.Windows.Forms.ComboBox
        Me.TabGeneral.SuspendLayout()
        Me.tpGrupos.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabGrupos.SuspendLayout()
        Me.tpListadoGrupos.SuspendLayout()
        CType(Me.grdGrupos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpGaleria.SuspendLayout()
        CType(Me.grdGaleria, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpListadoDoctos.SuspendLayout()
        CType(Me.grdListadoDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpContenido.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabLigas.SuspendLayout()
        Me.tpLigaLista.SuspendLayout()
        CType(Me.grdLigas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpLigaDocto.SuspendLayout()
        Me.tpLigaExterna.SuspendLayout()
        Me.tpLigaDinamicas.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstImagenes
        '
        Me.lstImagenes.ImageSize = New System.Drawing.Size(20, 20)
        Me.lstImagenes.ImageStream = CType(resources.GetObject("lstImagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.lstImagenes.TransparentColor = System.Drawing.Color.Transparent
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nombre de la pagina:"
        '
        'TabGeneral
        '
        Me.TabGeneral.Controls.Add(Me.tpGrupos)
        Me.TabGeneral.Controls.Add(Me.tpContenido)
        Me.TabGeneral.Location = New System.Drawing.Point(8, 96)
        Me.TabGeneral.Name = "TabGeneral"
        Me.TabGeneral.SelectedIndex = 0
        Me.TabGeneral.Size = New System.Drawing.Size(608, 416)
        Me.TabGeneral.TabIndex = 4
        '
        'tpGrupos
        '
        Me.tpGrupos.Controls.Add(Me.GroupBox1)
        Me.tpGrupos.Location = New System.Drawing.Point(4, 22)
        Me.tpGrupos.Name = "tpGrupos"
        Me.tpGrupos.Size = New System.Drawing.Size(600, 390)
        Me.tpGrupos.TabIndex = 0
        Me.tpGrupos.Text = "Grupos"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdPegar)
        Me.GroupBox1.Controls.Add(Me.cmdCopiar)
        Me.GroupBox1.Controls.Add(Me.TabGrupos)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtTextoGrupo)
        Me.GroupBox1.Controls.Add(Me.txtDescripcionGrupo)
        Me.GroupBox1.Controls.Add(Me.tlbGrupos)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtNombreGrupo)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(584, 376)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Grupos"
        '
        'cmdPegar
        '
        Me.cmdPegar.ImageIndex = 16
        Me.cmdPegar.ImageList = Me.lstImagenes
        Me.cmdPegar.Location = New System.Drawing.Point(536, 120)
        Me.cmdPegar.Name = "cmdPegar"
        Me.cmdPegar.Size = New System.Drawing.Size(28, 28)
        Me.cmdPegar.TabIndex = 11
        '
        'cmdCopiar
        '
        Me.cmdCopiar.ImageIndex = 15
        Me.cmdCopiar.ImageList = Me.lstImagenes
        Me.cmdCopiar.Location = New System.Drawing.Point(504, 120)
        Me.cmdCopiar.Name = "cmdCopiar"
        Me.cmdCopiar.Size = New System.Drawing.Size(28, 28)
        Me.cmdCopiar.TabIndex = 10
        '
        'TabGrupos
        '
        Me.TabGrupos.Controls.Add(Me.tpListadoGrupos)
        Me.TabGrupos.Controls.Add(Me.tpGaleria)
        Me.TabGrupos.Controls.Add(Me.tpListadoDoctos)
        Me.TabGrupos.Location = New System.Drawing.Point(8, 152)
        Me.TabGrupos.Name = "TabGrupos"
        Me.TabGrupos.SelectedIndex = 0
        Me.TabGrupos.Size = New System.Drawing.Size(568, 216)
        Me.TabGrupos.TabIndex = 9
        '
        'tpListadoGrupos
        '
        Me.tpListadoGrupos.Controls.Add(Me.grdGrupos)
        Me.tpListadoGrupos.Location = New System.Drawing.Point(4, 22)
        Me.tpListadoGrupos.Name = "tpListadoGrupos"
        Me.tpListadoGrupos.Size = New System.Drawing.Size(560, 190)
        Me.tpListadoGrupos.TabIndex = 0
        Me.tpListadoGrupos.Text = "Listado de Grupos"
        '
        'grdGrupos
        '
        Me.grdGrupos.DataMember = ""
        Me.grdGrupos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdGrupos.Location = New System.Drawing.Point(8, 8)
        Me.grdGrupos.Name = "grdGrupos"
        Me.grdGrupos.ReadOnly = True
        Me.grdGrupos.Size = New System.Drawing.Size(552, 144)
        Me.grdGrupos.TabIndex = 5
        '
        'tpGaleria
        '
        Me.tpGaleria.Controls.Add(Me.grdGaleria)
        Me.tpGaleria.Controls.Add(Me.btnAdjuntar)
        Me.tpGaleria.Controls.Add(Me.txtImagenAdjunta)
        Me.tpGaleria.Controls.Add(Me.Label11)
        Me.tpGaleria.Controls.Add(Me.txtNombreImagen)
        Me.tpGaleria.Controls.Add(Me.Label10)
        Me.tpGaleria.Controls.Add(Me.tlbGalerias)
        Me.tpGaleria.Location = New System.Drawing.Point(4, 22)
        Me.tpGaleria.Name = "tpGaleria"
        Me.tpGaleria.Size = New System.Drawing.Size(560, 190)
        Me.tpGaleria.TabIndex = 1
        Me.tpGaleria.Text = "Galeria por grupo"
        '
        'grdGaleria
        '
        Me.grdGaleria.DataMember = ""
        Me.grdGaleria.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdGaleria.Location = New System.Drawing.Point(8, 64)
        Me.grdGaleria.Name = "grdGaleria"
        Me.grdGaleria.ReadOnly = True
        Me.grdGaleria.Size = New System.Drawing.Size(544, 96)
        Me.grdGaleria.TabIndex = 12
        '
        'btnAdjuntar
        '
        Me.btnAdjuntar.ImageIndex = 9
        Me.btnAdjuntar.ImageList = Me.lstImagenes
        Me.btnAdjuntar.Location = New System.Drawing.Point(512, 40)
        Me.btnAdjuntar.Name = "btnAdjuntar"
        Me.btnAdjuntar.Size = New System.Drawing.Size(32, 24)
        Me.btnAdjuntar.TabIndex = 8
        '
        'txtImagenAdjunta
        '
        Me.txtImagenAdjunta.Location = New System.Drawing.Point(304, 40)
        Me.txtImagenAdjunta.Name = "txtImagenAdjunta"
        Me.txtImagenAdjunta.ReadOnly = True
        Me.txtImagenAdjunta.Size = New System.Drawing.Size(208, 20)
        Me.txtImagenAdjunta.TabIndex = 10
        Me.txtImagenAdjunta.Text = ""
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(256, 40)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(45, 16)
        Me.Label11.TabIndex = 9
        Me.Label11.Text = "Imagen:"
        '
        'txtNombreImagen
        '
        Me.txtNombreImagen.Location = New System.Drawing.Point(64, 40)
        Me.txtNombreImagen.Name = "txtNombreImagen"
        Me.txtNombreImagen.Size = New System.Drawing.Size(192, 20)
        Me.txtNombreImagen.TabIndex = 7
        Me.txtNombreImagen.Text = ""
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 40)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 16)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "Nombre:"
        '
        'tlbGalerias
        '
        Me.tlbGalerias.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton16, Me.ToolBarButton25})
        Me.tlbGalerias.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tlbGalerias.DropDownArrows = True
        Me.tlbGalerias.ImageList = Me.lstImagenes
        Me.tlbGalerias.Location = New System.Drawing.Point(0, 0)
        Me.tlbGalerias.Name = "tlbGalerias"
        Me.tlbGalerias.ShowToolTips = True
        Me.tlbGalerias.Size = New System.Drawing.Size(560, 32)
        Me.tlbGalerias.TabIndex = 6
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 6
        Me.ToolBarButton5.ToolTipText = "Nuevo"
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 3
        Me.ToolBarButton6.ToolTipText = "Guardar"
        '
        'ToolBarButton16
        '
        Me.ToolBarButton16.ImageIndex = 1
        Me.ToolBarButton16.ToolTipText = "Eliminar"
        '
        'ToolBarButton25
        '
        Me.ToolBarButton25.ImageIndex = 10
        Me.ToolBarButton25.ToolTipText = "Deshacer"
        '
        'tpListadoDoctos
        '
        Me.tpListadoDoctos.Controls.Add(Me.txtPertenece)
        Me.tpListadoDoctos.Controls.Add(Me.Label14)
        Me.tpListadoDoctos.Controls.Add(Me.chkDoctoRestringido)
        Me.tpListadoDoctos.Controls.Add(Me.grdListadoDocumentos)
        Me.tpListadoDoctos.Controls.Add(Me.btnAdjuntarListDocto)
        Me.tpListadoDoctos.Controls.Add(Me.txtDocumentoAdjunta)
        Me.tpListadoDoctos.Controls.Add(Me.Label17)
        Me.tpListadoDoctos.Controls.Add(Me.txtNombreDocto)
        Me.tpListadoDoctos.Controls.Add(Me.Label18)
        Me.tpListadoDoctos.Controls.Add(Me.tlbListadoDoctos)
        Me.tpListadoDoctos.Location = New System.Drawing.Point(4, 22)
        Me.tpListadoDoctos.Name = "tpListadoDoctos"
        Me.tpListadoDoctos.Size = New System.Drawing.Size(560, 190)
        Me.tpListadoDoctos.TabIndex = 2
        Me.tpListadoDoctos.Text = "Listado de documentos"
        '
        'txtPertenece
        '
        Me.txtPertenece.Location = New System.Drawing.Point(296, 64)
        Me.txtPertenece.Name = "txtPertenece"
        Me.txtPertenece.ReadOnly = True
        Me.txtPertenece.Size = New System.Drawing.Size(168, 20)
        Me.txtPertenece.TabIndex = 21
        Me.txtPertenece.Text = "CONANCE"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(232, 64)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(59, 16)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "Pertenece:"
        '
        'chkDoctoRestringido
        '
        Me.chkDoctoRestringido.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkDoctoRestringido.Location = New System.Drawing.Point(136, 64)
        Me.chkDoctoRestringido.Name = "chkDoctoRestringido"
        Me.chkDoctoRestringido.Size = New System.Drawing.Size(88, 16)
        Me.chkDoctoRestringido.TabIndex = 11
        Me.chkDoctoRestringido.Text = "Restringido"
        '
        'grdListadoDocumentos
        '
        Me.grdListadoDocumentos.DataMember = ""
        Me.grdListadoDocumentos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdListadoDocumentos.Location = New System.Drawing.Point(8, 88)
        Me.grdListadoDocumentos.Name = "grdListadoDocumentos"
        Me.grdListadoDocumentos.ReadOnly = True
        Me.grdListadoDocumentos.Size = New System.Drawing.Size(544, 96)
        Me.grdListadoDocumentos.TabIndex = 19
        '
        'btnAdjuntarListDocto
        '
        Me.btnAdjuntarListDocto.ImageIndex = 9
        Me.btnAdjuntarListDocto.ImageList = Me.lstImagenes
        Me.btnAdjuntarListDocto.Location = New System.Drawing.Point(440, 32)
        Me.btnAdjuntarListDocto.Name = "btnAdjuntarListDocto"
        Me.btnAdjuntarListDocto.Size = New System.Drawing.Size(24, 24)
        Me.btnAdjuntarListDocto.TabIndex = 10
        '
        'txtDocumentoAdjunta
        '
        Me.txtDocumentoAdjunta.Location = New System.Drawing.Point(296, 40)
        Me.txtDocumentoAdjunta.Name = "txtDocumentoAdjunta"
        Me.txtDocumentoAdjunta.ReadOnly = True
        Me.txtDocumentoAdjunta.Size = New System.Drawing.Size(144, 20)
        Me.txtDocumentoAdjunta.TabIndex = 17
        Me.txtDocumentoAdjunta.Text = ""
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(232, 40)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 16)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "Documento:"
        '
        'txtNombreDocto
        '
        Me.txtNombreDocto.Location = New System.Drawing.Point(64, 40)
        Me.txtNombreDocto.Name = "txtNombreDocto"
        Me.txtNombreDocto.Size = New System.Drawing.Size(160, 20)
        Me.txtNombreDocto.TabIndex = 9
        Me.txtNombreDocto.Text = ""
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(16, 40)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(48, 16)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Nombre:"
        '
        'tlbListadoDoctos
        '
        Me.tlbListadoDoctos.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton21, Me.ToolBarButton22, Me.ToolBarButton23, Me.ToolBarButton26})
        Me.tlbListadoDoctos.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tlbListadoDoctos.DropDownArrows = True
        Me.tlbListadoDoctos.ImageList = Me.lstImagenes
        Me.tlbListadoDoctos.Location = New System.Drawing.Point(0, 0)
        Me.tlbListadoDoctos.Name = "tlbListadoDoctos"
        Me.tlbListadoDoctos.ShowToolTips = True
        Me.tlbListadoDoctos.Size = New System.Drawing.Size(560, 32)
        Me.tlbListadoDoctos.TabIndex = 13
        '
        'ToolBarButton21
        '
        Me.ToolBarButton21.ImageIndex = 6
        Me.ToolBarButton21.ToolTipText = "Nuevo"
        '
        'ToolBarButton22
        '
        Me.ToolBarButton22.ImageIndex = 3
        Me.ToolBarButton22.ToolTipText = "Guardar"
        '
        'ToolBarButton23
        '
        Me.ToolBarButton23.ImageIndex = 1
        Me.ToolBarButton23.ToolTipText = "Eliminar"
        '
        'ToolBarButton26
        '
        Me.ToolBarButton26.ImageIndex = 10
        Me.ToolBarButton26.ToolTipText = "Deshacer"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(16, 120)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 16)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Texto del Grupo:"
        '
        'txtTextoGrupo
        '
        Me.txtTextoGrupo.Location = New System.Drawing.Point(104, 120)
        Me.txtTextoGrupo.Multiline = True
        Me.txtTextoGrupo.Name = "txtTextoGrupo"
        Me.txtTextoGrupo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTextoGrupo.Size = New System.Drawing.Size(400, 32)
        Me.txtTextoGrupo.TabIndex = 6
        Me.txtTextoGrupo.Text = ""
        '
        'txtDescripcionGrupo
        '
        Me.txtDescripcionGrupo.Location = New System.Drawing.Point(104, 80)
        Me.txtDescripcionGrupo.Multiline = True
        Me.txtDescripcionGrupo.Name = "txtDescripcionGrupo"
        Me.txtDescripcionGrupo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescripcionGrupo.Size = New System.Drawing.Size(472, 40)
        Me.txtDescripcionGrupo.TabIndex = 5
        Me.txtDescripcionGrupo.Text = ""
        '
        'tlbGrupos
        '
        Me.tlbGrupos.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton8, Me.ToolBarButton7, Me.ToolBarButton24, Me.ToolBarButton3, Me.ToolBarButton28})
        Me.tlbGrupos.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tlbGrupos.DropDownArrows = True
        Me.tlbGrupos.ImageList = Me.lstImagenes
        Me.tlbGrupos.Location = New System.Drawing.Point(3, 16)
        Me.tlbGrupos.Name = "tlbGrupos"
        Me.tlbGrupos.ShowToolTips = True
        Me.tlbGrupos.Size = New System.Drawing.Size(578, 32)
        Me.tlbGrupos.TabIndex = 5
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 6
        Me.ToolBarButton1.ToolTipText = "Nuevo"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 3
        Me.ToolBarButton2.ToolTipText = "Guardar"
        '
        'ToolBarButton8
        '
        Me.ToolBarButton8.ImageIndex = 0
        Me.ToolBarButton8.ToolTipText = "Editar"
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.ImageIndex = 1
        Me.ToolBarButton7.ToolTipText = "Eliminar"
        '
        'ToolBarButton24
        '
        Me.ToolBarButton24.ImageIndex = 10
        Me.ToolBarButton24.ToolTipText = "Deshacer"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 4
        Me.ToolBarButton3.ToolTipText = "Crear Ligas"
        '
        'ToolBarButton28
        '
        Me.ToolBarButton28.ImageIndex = 14
        Me.ToolBarButton28.ToolTipText = "Dise�ador Web"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 16)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Descripcion:"
        '
        'txtNombreGrupo
        '
        Me.txtNombreGrupo.Location = New System.Drawing.Point(104, 56)
        Me.txtNombreGrupo.Name = "txtNombreGrupo"
        Me.txtNombreGrupo.Size = New System.Drawing.Size(472, 20)
        Me.txtNombreGrupo.TabIndex = 4
        Me.txtNombreGrupo.Text = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Nombre del grupo:"
        '
        'tpContenido
        '
        Me.tpContenido.Controls.Add(Me.GroupBox2)
        Me.tpContenido.Controls.Add(Me.Label4)
        Me.tpContenido.Controls.Add(Me.txtGrupoDeContenido)
        Me.tpContenido.Location = New System.Drawing.Point(4, 22)
        Me.tpContenido.Name = "tpContenido"
        Me.tpContenido.Size = New System.Drawing.Size(600, 390)
        Me.tpContenido.TabIndex = 1
        Me.tpContenido.Text = "Contenido"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.tblLigas)
        Me.GroupBox2.Controls.Add(Me.TabLigas)
        Me.GroupBox2.Controls.Add(Me.txtTextoLiga)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.cboTipoLiga)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtNombreLiga)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 40)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(584, 344)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Ligas"
        '
        'tblLigas
        '
        Me.tblLigas.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton9, Me.ToolBarButton10, Me.ToolBarButton13, Me.ToolBarButton20, Me.cmdDeshacer, Me.ToolBarButton27, Me.cmdRegresarGrupos})
        Me.tblLigas.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tblLigas.DropDownArrows = True
        Me.tblLigas.ImageList = Me.lstImagenes
        Me.tblLigas.Location = New System.Drawing.Point(3, 16)
        Me.tblLigas.Name = "tblLigas"
        Me.tblLigas.ShowToolTips = True
        Me.tblLigas.Size = New System.Drawing.Size(578, 32)
        Me.tblLigas.TabIndex = 11
        '
        'ToolBarButton9
        '
        Me.ToolBarButton9.ImageIndex = 6
        Me.ToolBarButton9.ToolTipText = "Nuevo"
        '
        'ToolBarButton10
        '
        Me.ToolBarButton10.ImageIndex = 3
        Me.ToolBarButton10.ToolTipText = "Guardar"
        '
        'ToolBarButton13
        '
        Me.ToolBarButton13.ImageIndex = 0
        Me.ToolBarButton13.ToolTipText = "Editar"
        Me.ToolBarButton13.Visible = False
        '
        'ToolBarButton20
        '
        Me.ToolBarButton20.ImageIndex = 1
        Me.ToolBarButton20.ToolTipText = "Eliminar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 11
        Me.cmdDeshacer.ToolTipText = "Deshacer"
        '
        'ToolBarButton27
        '
        Me.ToolBarButton27.ImageIndex = 10
        Me.ToolBarButton27.ToolTipText = "Deshacer General"
        '
        'cmdRegresarGrupos
        '
        Me.cmdRegresarGrupos.ImageIndex = 13
        Me.cmdRegresarGrupos.Text = "Regresar a grupos"
        Me.cmdRegresarGrupos.ToolTipText = "Regresar a grupos"
        '
        'TabLigas
        '
        Me.TabLigas.Controls.Add(Me.tpLigaLista)
        Me.TabLigas.Controls.Add(Me.tpLigaDocto)
        Me.TabLigas.Controls.Add(Me.tpLigaExterna)
        Me.TabLigas.Controls.Add(Me.tpLigaDinamicas)
        Me.TabLigas.Location = New System.Drawing.Point(8, 152)
        Me.TabLigas.Name = "TabLigas"
        Me.TabLigas.SelectedIndex = 0
        Me.TabLigas.Size = New System.Drawing.Size(568, 176)
        Me.TabLigas.TabIndex = 10
        '
        'tpLigaLista
        '
        Me.tpLigaLista.Controls.Add(Me.grdLigas)
        Me.tpLigaLista.Location = New System.Drawing.Point(4, 22)
        Me.tpLigaLista.Name = "tpLigaLista"
        Me.tpLigaLista.Size = New System.Drawing.Size(560, 150)
        Me.tpLigaLista.TabIndex = 4
        Me.tpLigaLista.Text = "Listado de ligas"
        '
        'grdLigas
        '
        Me.grdLigas.DataMember = ""
        Me.grdLigas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdLigas.Location = New System.Drawing.Point(8, 8)
        Me.grdLigas.Name = "grdLigas"
        Me.grdLigas.ReadOnly = True
        Me.grdLigas.Size = New System.Drawing.Size(544, 136)
        Me.grdLigas.TabIndex = 13
        '
        'tpLigaDocto
        '
        Me.tpLigaDocto.Controls.Add(Me.btnAdjuntarDoctoLiga)
        Me.tpLigaDocto.Controls.Add(Me.chkRestringirDoctoLiga)
        Me.tpLigaDocto.Controls.Add(Me.txtDocumentoAdjuntoLiga)
        Me.tpLigaDocto.Controls.Add(Me.Label13)
        Me.tpLigaDocto.Controls.Add(Me.txtDocumentoLiga)
        Me.tpLigaDocto.Controls.Add(Me.Label12)
        Me.tpLigaDocto.Location = New System.Drawing.Point(4, 22)
        Me.tpLigaDocto.Name = "tpLigaDocto"
        Me.tpLigaDocto.Size = New System.Drawing.Size(560, 150)
        Me.tpLigaDocto.TabIndex = 0
        Me.tpLigaDocto.Text = "Archivos"
        '
        'btnAdjuntarDoctoLiga
        '
        Me.btnAdjuntarDoctoLiga.ImageIndex = 9
        Me.btnAdjuntarDoctoLiga.ImageList = Me.lstImagenes
        Me.btnAdjuntarDoctoLiga.Location = New System.Drawing.Point(512, 40)
        Me.btnAdjuntarDoctoLiga.Name = "btnAdjuntarDoctoLiga"
        Me.btnAdjuntarDoctoLiga.Size = New System.Drawing.Size(32, 24)
        Me.btnAdjuntarDoctoLiga.TabIndex = 8
        '
        'chkRestringirDoctoLiga
        '
        Me.chkRestringirDoctoLiga.Location = New System.Drawing.Point(144, 64)
        Me.chkRestringirDoctoLiga.Name = "chkRestringirDoctoLiga"
        Me.chkRestringirDoctoLiga.TabIndex = 9
        Me.chkRestringirDoctoLiga.Text = "Restringido"
        '
        'txtDocumentoAdjuntoLiga
        '
        Me.txtDocumentoAdjuntoLiga.Location = New System.Drawing.Point(144, 40)
        Me.txtDocumentoAdjuntoLiga.Name = "txtDocumentoAdjuntoLiga"
        Me.txtDocumentoAdjuntoLiga.ReadOnly = True
        Me.txtDocumentoAdjuntoLiga.Size = New System.Drawing.Size(360, 20)
        Me.txtDocumentoAdjuntoLiga.TabIndex = 3
        Me.txtDocumentoAdjuntoLiga.Text = ""
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(80, 40)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 16)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Documento:"
        '
        'txtDocumentoLiga
        '
        Me.txtDocumentoLiga.Location = New System.Drawing.Point(144, 16)
        Me.txtDocumentoLiga.Name = "txtDocumentoLiga"
        Me.txtDocumentoLiga.Size = New System.Drawing.Size(400, 20)
        Me.txtDocumentoLiga.TabIndex = 7
        Me.txtDocumentoLiga.Text = ""
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(96, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(45, 16)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Archivo:"
        '
        'tpLigaExterna
        '
        Me.tpLigaExterna.Controls.Add(Me.txtLigaExterna)
        Me.tpLigaExterna.Controls.Add(Me.Label15)
        Me.tpLigaExterna.Location = New System.Drawing.Point(4, 22)
        Me.tpLigaExterna.Name = "tpLigaExterna"
        Me.tpLigaExterna.Size = New System.Drawing.Size(560, 150)
        Me.tpLigaExterna.TabIndex = 1
        Me.tpLigaExterna.Text = "Ligas Externas"
        '
        'txtLigaExterna
        '
        Me.txtLigaExterna.Location = New System.Drawing.Point(88, 16)
        Me.txtLigaExterna.Multiline = True
        Me.txtLigaExterna.Name = "txtLigaExterna"
        Me.txtLigaExterna.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtLigaExterna.Size = New System.Drawing.Size(464, 80)
        Me.txtLigaExterna.TabIndex = 11
        Me.txtLigaExterna.Text = ""
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(16, 16)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(71, 16)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Liga Externa:"
        '
        'tpLigaDinamicas
        '
        Me.tpLigaDinamicas.Controls.Add(Me.GroupBox3)
        Me.tpLigaDinamicas.Location = New System.Drawing.Point(4, 22)
        Me.tpLigaDinamicas.Name = "tpLigaDinamicas"
        Me.tpLigaDinamicas.Size = New System.Drawing.Size(560, 150)
        Me.tpLigaDinamicas.TabIndex = 2
        Me.tpLigaDinamicas.Text = "Dinamicas"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.optPreestablecidas)
        Me.GroupBox3.Controls.Add(Me.cboPaginas)
        Me.GroupBox3.Controls.Add(Me.OptPaginasContenido)
        Me.GroupBox3.Controls.Add(Me.optRepositorio)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(544, 120)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Ligas a repositorios o a paginas de contenido"
        '
        'optPreestablecidas
        '
        Me.optPreestablecidas.Location = New System.Drawing.Point(328, 40)
        Me.optPreestablecidas.Name = "optPreestablecidas"
        Me.optPreestablecidas.Size = New System.Drawing.Size(136, 24)
        Me.optPreestablecidas.TabIndex = 16
        Me.optPreestablecidas.Text = "Preestablecidas"
        '
        'cboPaginas
        '
        Me.cboPaginas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaginas.Location = New System.Drawing.Point(64, 72)
        Me.cboPaginas.Name = "cboPaginas"
        Me.cboPaginas.Size = New System.Drawing.Size(400, 21)
        Me.cboPaginas.TabIndex = 15
        '
        'OptPaginasContenido
        '
        Me.OptPaginasContenido.Location = New System.Drawing.Point(184, 40)
        Me.OptPaginasContenido.Name = "OptPaginasContenido"
        Me.OptPaginasContenido.Size = New System.Drawing.Size(136, 24)
        Me.OptPaginasContenido.TabIndex = 13
        Me.OptPaginasContenido.Text = "Paginas de contenido"
        '
        'optRepositorio
        '
        Me.optRepositorio.Checked = True
        Me.optRepositorio.Location = New System.Drawing.Point(64, 40)
        Me.optRepositorio.Name = "optRepositorio"
        Me.optRepositorio.TabIndex = 12
        Me.optRepositorio.TabStop = True
        Me.optRepositorio.Text = "Repertorio:"
        '
        'txtTextoLiga
        '
        Me.txtTextoLiga.Location = New System.Drawing.Point(104, 104)
        Me.txtTextoLiga.Multiline = True
        Me.txtTextoLiga.Name = "txtTextoLiga"
        Me.txtTextoLiga.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTextoLiga.Size = New System.Drawing.Size(472, 40)
        Me.txtTextoLiga.TabIndex = 6
        Me.txtTextoLiga.Text = ""
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(64, 112)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 16)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Texto:"
        '
        'cboTipoLiga
        '
        Me.cboTipoLiga.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTipoLiga.Location = New System.Drawing.Point(104, 56)
        Me.cboTipoLiga.Name = "cboTipoLiga"
        Me.cboTipoLiga.Size = New System.Drawing.Size(256, 21)
        Me.cboTipoLiga.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(32, 56)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(66, 16)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Tipo de liga:"
        '
        'txtNombreLiga
        '
        Me.txtNombreLiga.Location = New System.Drawing.Point(104, 80)
        Me.txtNombreLiga.Name = "txtNombreLiga"
        Me.txtNombreLiga.Size = New System.Drawing.Size(472, 20)
        Me.txtNombreLiga.TabIndex = 4
        Me.txtNombreLiga.Text = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 16)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Nombre de la liga:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(72, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 16)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Grupo:"
        '
        'txtGrupoDeContenido
        '
        Me.txtGrupoDeContenido.Location = New System.Drawing.Point(112, 16)
        Me.txtGrupoDeContenido.Name = "txtGrupoDeContenido"
        Me.txtGrupoDeContenido.ReadOnly = True
        Me.txtGrupoDeContenido.Size = New System.Drawing.Size(472, 20)
        Me.txtGrupoDeContenido.TabIndex = 3
        Me.txtGrupoDeContenido.Text = ""
        '
        'txtTituloPagina
        '
        Me.txtTituloPagina.Location = New System.Drawing.Point(136, 64)
        Me.txtTituloPagina.Name = "txtTituloPagina"
        Me.txtTituloPagina.Size = New System.Drawing.Size(488, 20)
        Me.txtTituloPagina.TabIndex = 3
        Me.txtTituloPagina.Text = ""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(96, 64)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(35, 16)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Titulo:"
        '
        'tblGeneral
        '
        Me.tblGeneral.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton11, Me.ToolBarButton12, Me.ToolBarButton19, Me.ToolBarButton14, Me.ToolBarButton4, Me.ToolBarButton17, Me.ToolBarButton18, Me.ToolBarButton15})
        Me.tblGeneral.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tblGeneral.DropDownArrows = True
        Me.tblGeneral.ImageList = Me.lstImagenes
        Me.tblGeneral.Location = New System.Drawing.Point(0, 0)
        Me.tblGeneral.Name = "tblGeneral"
        Me.tblGeneral.ShowToolTips = True
        Me.tblGeneral.Size = New System.Drawing.Size(632, 32)
        Me.tblGeneral.TabIndex = 13
        '
        'ToolBarButton11
        '
        Me.ToolBarButton11.ImageIndex = 6
        Me.ToolBarButton11.ToolTipText = "Nuevo"
        '
        'ToolBarButton12
        '
        Me.ToolBarButton12.ImageIndex = 3
        Me.ToolBarButton12.ToolTipText = "Guardar"
        '
        'ToolBarButton19
        '
        Me.ToolBarButton19.ImageIndex = 0
        Me.ToolBarButton19.ToolTipText = "Editar"
        '
        'ToolBarButton14
        '
        Me.ToolBarButton14.ImageIndex = 1
        Me.ToolBarButton14.ToolTipText = "Eliminar"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 10
        Me.ToolBarButton4.ToolTipText = "Deshacer"
        '
        'ToolBarButton17
        '
        Me.ToolBarButton17.ImageIndex = 7
        Me.ToolBarButton17.ToolTipText = "Vista previa de la pagina (es necesario guardar)"
        '
        'ToolBarButton18
        '
        Me.ToolBarButton18.ImageIndex = 5
        Me.ToolBarButton18.ToolTipText = "Modificar menu o Index"
        '
        'ToolBarButton15
        '
        Me.ToolBarButton15.ImageIndex = 12
        Me.ToolBarButton15.ToolTipText = "Index"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(368, 40)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 16)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "Tipo de pagina:"
        '
        'cboTipoPagina
        '
        Me.cboTipoPagina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTipoPagina.Location = New System.Drawing.Point(456, 40)
        Me.cboTipoPagina.Name = "cboTipoPagina"
        Me.cboTipoPagina.Size = New System.Drawing.Size(168, 21)
        Me.cboTipoPagina.TabIndex = 2
        '
        'cboNombrePagina
        '
        Me.cboNombrePagina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboNombrePagina.Location = New System.Drawing.Point(136, 40)
        Me.cboNombrePagina.Name = "cboNombrePagina"
        Me.cboNombrePagina.Size = New System.Drawing.Size(232, 21)
        Me.cboNombrePagina.TabIndex = 1
        '
        'frmGestor
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(632, 532)
        Me.Controls.Add(Me.cboNombrePagina)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtTituloPagina)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tblGeneral)
        Me.Controls.Add(Me.TabGeneral)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboTipoPagina)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmGestor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gestor de paginas"
        Me.TabGeneral.ResumeLayout(False)
        Me.tpGrupos.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabGrupos.ResumeLayout(False)
        Me.tpListadoGrupos.ResumeLayout(False)
        CType(Me.grdGrupos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpGaleria.ResumeLayout(False)
        CType(Me.grdGaleria, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpListadoDoctos.ResumeLayout(False)
        CType(Me.grdListadoDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpContenido.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.TabLigas.ResumeLayout(False)
        Me.tpLigaLista.ResumeLayout(False)
        CType(Me.grdLigas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpLigaDocto.ResumeLayout(False)
        Me.tpLigaExterna.ResumeLayout(False)
        Me.tpLigaDinamicas.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmGestor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CargaDeInicio()
        CrearArbolPertenece()
    End Sub

    Private Sub CargaDeInicio()
        REM ----Reestablecer paneles
        tpGrupos.Parent = Nothing
        tpGrupos.Parent = TabGeneral
        tpContenido.Parent = Nothing
        tpContenido.Parent = TabGeneral

        REM ----Reestablesco propiedades----
        resetearPropiedades()
        REM ----Reestablesco propiedades----

        REM vamos por etapas
        REM ----botones de general----
        Lectura(txtTituloPagina)
        Limpiar(txtTituloPagina)

        Activar(cboTipoPagina, tblGeneral.Buttons.Item(0), tblGeneral.Buttons.Item(2), tblGeneral.Buttons.Item(3), tblGeneral.Buttons.Item(5), tblGeneral.Buttons.Item(6))
        inactivar(tblGeneral.Buttons.Item(1), tblGeneral.Buttons.Item(4))
        tpContenido.Parent = TabGeneral
        cboNombrePagina.DropDownStyle = ComboBoxStyle.DropDownList

        REM tienen que ir en ese orden
        REM cargar como cboTipoPagina
        CargarTiposPaginas()
        REM cargar combo cboNombrePagina
        cargarPaginas()
        CargarDatosGenerales()
        REM cargar grupos
        CargaDatosGrupos()
        LlenarLigas()
        REM cargar galeria
        REM LlenarImagenes()
        REM cargar documentos
        REM LlenarDocumentos()
        REM llenadatos general
        CargarDatosGenerales()

        REM ----botones de general----

        REM ----Grupos----
        inactivar(tlbGrupos)
        Limpiar(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)
        Limpiar(txtNombreImagen, txtImagenAdjunta)
        Limpiar(txtNombreDocto, txtDocumentoAdjunta)

        Lectura(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)
        inactivar(tlbGalerias, txtNombreImagen, btnAdjuntar)
        inactivar(txtNombreDocto, btnAdjuntarListDocto, chkDoctoRestringido)
        REM ----Grupos----

        REM ----Contenido ligas----
        inactivar(tblLigas)
        Limpiar(txtGrupoDeContenido, txtNombreLiga, txtTextoLiga)
        Limpiar(txtDocumentoLiga, txtDocumentoAdjuntoLiga)
        chkRestringirDoctoLiga.Checked = False

        Limpiar(txtLigaExterna)

        Lectura(txtNombreLiga, txtTextoLiga)
        inactivar(cboTipoLiga)

        Lectura(txtDocumentoLiga)
        inactivar(btnAdjuntarDoctoLiga, chkRestringirDoctoLiga)

        Lectura(txtLigaExterna)

        inactivar(optRepositorio, OptPaginasContenido, cboPaginas)
        inactivar(tlbListadoDoctos)
        REM ----Contenido ligas----

        IncioGrupos()
        inicioGaleria()
        inicioDocumentos()

        REM llenar Tipos de ligas
        LlenarTiposLigas()

        REM ----EliminarIds no terminados----
        REM EliminarPaginaNoTerminada()
        REM EliminarGruposNoTerminada()
        REM ----EliminarIds no terminados----

    End Sub

    Private Sub cargarPaginas()
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            objPaginas.Bandera = "s2"
            objPaginas.Activo = True
            objPaginas.Terminada = True
            objPaginas.Id_TipoPagina = cboTipoPagina.SelectedValue
            cboNombrePagina.DataSource = objPaginas.Listar()
            cboNombrePagina.DisplayMember = "Nombre"
            cboNombrePagina.ValueMember = "Id_Pagina"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try
    End Sub
    Private Sub tblGeneral_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tblGeneral.ButtonClick
        REM opciones del menu
        Select Case tblGeneral.Buttons.IndexOf(e.Button)
            Case 0 REM Nuevo
                BotonesDeNuevoGeneral()
                GuardarPagina(1, cboTipoPagina.SelectedValue, Nothing, Nothing, False, Nothing, "i1")
            Case 1 REM guardar
                REM el orden de guadado debe ser primero los hijos luego el padre
                REM tengo que ver si hay una operacion pendiente de grupo por guardar la forma para saberlo es si el boton de guardar esta activo
                GuardarGeneral()
            Case 2 REM editar
                BotonesDeEdicion()
            Case 3 REM eliminar
                EliminarPagina()
            Case 4 REM deshacer
                EliminarGruposSinTerminar() REM 1
                EliminarPaginaNoTerminada()
                CargaDeInicio() REM 2
                resetearPropiedades()
            Case 5 REM vista previa
                abrirPrevio()
            Case 6
                Dim Generador As New GeneradorMenu
                Generador.Show()
            Case 7 REM Menu
                ''Dim Index As New CrearIndex
                ''Index.Show()
                If MsgBox("�Estas seguro de establecer esta pagina como index?", MsgBoxStyle.Information Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    EstablecerIndex()
                End If
        End Select
    End Sub

    Private Sub abrirPrevio()
        Dim RutaRepertorio = ConfigurationSettings.AppSettings.Get("Repertorio")
        Dim proceso As New System.Diagnostics.Process
        Try

            RutaRepertorio &= cboNombrePagina.SelectedValue
            With proceso
                .StartInfo.FileName = RutaRepertorio
                .Start()
            End With

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            proceso = Nothing
        End Try
    End Sub

    Private Sub GuardarGeneral()
        If tlbGrupos.Buttons.Item(1).Enabled = True Then
            guardarNuevoGrupo()

        Else
            Guarde = True
        End If

        REM guardado final
        If Guarde = True Then
            guardarNuevaPagina()
            If Guarde = True Then
                GuardarGaleria()
                GuardarDocumentos()
                REM GuardarLigas() se quieta pusto que se guardan al momento de cambiar a la siguiente pesta�a
                terminarGruposNuevos()
                CargaDeInicio()
            End If
        End If

    End Sub

    Private Sub resetearPropiedades()
        Id_Grupo = Nothing
        Id_Pagina = Nothing
        Guarde = False
        DtTempGaleria = Nothing
        DtTempDoctos = Nothing
        DtTempLigas = Nothing
    End Sub

    Private Sub BotonesDeNuevoGeneral()
        REM --Limpio propiedades antes
        resetearPropiedades()
        REM --Limpio propiedades antes

        REM por etapas
        REM ----General----
        inactivar(cboTipoPagina, tblGeneral.Buttons.Item(0), tblGeneral.Buttons.Item(2), tblGeneral.Buttons.Item(3), tblGeneral.Buttons.Item(5), tblGeneral.Buttons.Item(6))
        Activar(tblGeneral.Buttons.Item(1), tblGeneral.Buttons.Item(4))


        cboNombrePagina.DropDownStyle = ComboBoxStyle.Simple
        Escritura(txtTituloPagina)
        Limpiar(cboNombrePagina, txtTituloPagina)

        tpContenido.Parent = Nothing
        IncioGrupos()

        TabGeneral.SelectedTab = TabGeneral.TabPages(0)
        TabGrupos.SelectedTab = TabGrupos.TabPages(0)

        tpContenido.Parent = Nothing
        eliminarFichasGrupos()

        Activar(tlbGrupos)
        REM ----General----

        REM ----Borrar Grids----
        grdGrupos.DataSource = Nothing
        grdGaleria.DataSource = Nothing
        grdListadoDocumentos.DataSource = Nothing
        REM ----Borrar Grids----
    End Sub

    Private Sub BotonesDeEdicion()

        REM --Limpio propiedades antes
        resetearPropiedades()
        REM --Limpio propiedades antes

        REM por etapas
        REM ----General----
        inactivar(cboTipoPagina, tblGeneral.Buttons.Item(0), tblGeneral.Buttons.Item(2), tblGeneral.Buttons.Item(3), tblGeneral.Buttons.Item(5), tblGeneral.Buttons.Item(6))
        Activar(tblGeneral.Buttons.Item(1), tblGeneral.Buttons.Item(4))

        cboNombrePagina.DropDownStyle = ComboBoxStyle.Simple
        Escritura(txtTituloPagina)

        tpContenido.Parent = Nothing
        IncioGrupos()

        TabGeneral.SelectedTab = TabGeneral.TabPages(0)
        TabGrupos.SelectedTab = TabGrupos.TabPages(0)

        Activar(tlbGrupos, tlbGalerias, tlbListadoDoctos)
        REM ----General----
        Id_Pagina = cboNombrePagina.SelectedValue

    End Sub

    Private Sub eliminarFichasGrupos()
        tpGaleria.Parent = Nothing
        tpListadoDoctos.Parent = Nothing
    End Sub

    Private Sub IncioGrupos()
        REM ----Limpiar propiedad----
        Id_Grupo = Nothing
        REM ----Limpiar propiedad----
        Activar(tlbGrupos.Buttons.Item(0), tlbGrupos.Buttons.Item(2), tlbGrupos.Buttons.Item(3), tlbGrupos.Buttons.Item(5))
        inactivar(tlbGrupos.Buttons.Item(1), tlbGrupos.Buttons.Item(4))
        inactivar(tlbGalerias, tlbListadoDoctos)

        TabGeneral.SelectedTab = TabGeneral.TabPages(0)
        TabGrupos.SelectedTab = TabGrupos.TabPages(0)

        tpGaleria.Parent = TabGrupos
        tpListadoDoctos.Parent = TabGrupos

        Limpiar(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)
        Lectura(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)

        Activar(grdGrupos)
    End Sub

    Private Sub tlbGrupos_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbGrupos.ButtonClick
        Select Case tlbGrupos.Buttons.IndexOf(e.Button)
            Case 0 REM Nuevo
                If ValidarMasGrupos(Id_Pagina) = True Then
                    BotonesDeNuevoGrupos()
                    guardarGrupo(1, Nothing, Id_Pagina, Nothing, False, Nothing, "i1")
                Else
                    MsgBox("Las paginas de contenido solo pueden contar con un grupo o seccion")
                End If
            Case 1 REM guardar
                guardarNuevoGrupo()
                If Guarde = True Then CargaDatosGrupos()
            Case 2 REM editar
                Edicion = True
                edicionGrupos()
                BotonesDeEdicionGrupos()
            Case 3 REM eliminar
                EliminarGrupo()
            Case 4 REM deshacer
                If Edicion <> True Then
                    EliminarGrupoPendiente()
                End If
                IncioGrupos()
                inicioGaleria()
                inicioDocumentos()
                Activar(tlbGalerias, tlbListadoDoctos)

                Edicion = False
            Case 5 REM Ligas
                LlenarLigas()
                botonesDeNuevasLigas()
            Case 6
                Dim frmControl As New frmComponenteWeb
                frmControl.ShowDialog()
        End Select
    End Sub

    Private Sub BotonesDeNuevoGrupos()
        Activar(tlbGrupos.Buttons.Item(1), tlbGrupos.Buttons.Item(4))
        inactivar(grdGrupos, tlbGrupos.Buttons.Item(0), tlbGrupos.Buttons.Item(2), tlbGrupos.Buttons.Item(3), tlbGrupos.Buttons.Item(5))

        Escritura(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)

        tpGaleria.Parent = TabGrupos
        tpListadoDoctos.Parent = TabGrupos

        REM Activar(tlbGalerias)
        REM Activar(tlbListadoDoctos)
        Limpiar(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)
    End Sub

    Private Sub BotonesDeEdicionGrupos()
        Activar(tlbGrupos.Buttons.Item(1), tlbGrupos.Buttons.Item(4))
        inactivar(grdGrupos, tlbGrupos.Buttons.Item(0), tlbGrupos.Buttons.Item(2), tlbGrupos.Buttons.Item(3), tlbGrupos.Buttons.Item(5))

        Escritura(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)

        tpGaleria.Parent = TabGrupos
        tpListadoDoctos.Parent = TabGrupos

    End Sub

    Private Sub inicioGaleria()
        Activar(tlbGalerias.Buttons.Item(0), tlbGalerias.Buttons.Item(2))

        inactivar(tlbGalerias.Buttons.Item(1), tlbGalerias.Buttons.Item(3))

        inactivar(btnAdjuntar, txtNombreImagen)
        Limpiar(txtImagenAdjunta, txtNombreImagen)
    End Sub

    Private Sub inicioDocumentos()
        Activar(tlbListadoDoctos.Buttons.Item(0), tlbListadoDoctos.Buttons.Item(2))
        inactivar(tlbListadoDoctos.Buttons.Item(1), tlbListadoDoctos.Buttons.Item(3))

        inactivar(btnAdjuntarListDocto, chkDoctoRestringido, txtNombreDocto)
        Limpiar(txtNombreDocto, txtDocumentoAdjunta)
        chkDoctoRestringido.Checked = False
    End Sub

    Private Sub tlbGalerias_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbGalerias.ButtonClick
        Select Case tlbGalerias.Buttons.IndexOf(e.Button)
            Case 0 REM nuevo
                botonesDeNuevaGaleria()
            Case 1 REM guardar
                AgregarItemGaleria()
            Case 2 REM eliminar
                eliminar(DtTempGaleria, grdGaleria, 1)
            Case 3 REM deshacer
                inicioGaleria()
        End Select
    End Sub

    Private Sub tlbListadoDoctos_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbListadoDoctos.ButtonClick
        Select Case tlbListadoDoctos.Buttons.IndexOf(e.Button)
            Case 0 REM nuevo
                botonesDeNuevoDocumento()
            Case 1 REM guardar
                AgregarItemDocumentos()
            Case 2 REM eliminar
                eliminar(DtTempDoctos, grdListadoDocumentos, 2)
            Case 3 REM deshacer
                inicioDocumentos()
        End Select
    End Sub

    Private Sub botonesDeNuevaGaleria()
        If Id_Grupo <> 0 And tlbGrupos.Buttons.Item(0).Enabled = True Then
            inactivar(tlbGalerias.Buttons.Item(0), tlbGalerias.Buttons.Item(2))
            Activar(tlbGalerias.Buttons.Item(1), tlbGalerias.Buttons.Item(3))

            Activar(btnAdjuntar, txtNombreImagen)
        Else
            MsgBox("Es necesario seleccionar un grupo de la lista de la pesta�a grupos")
        End If

    End Sub

    Private Sub botonesDeNuevoDocumento()

        If Id_Grupo <> 0 And tlbGrupos.Buttons.Item(0).Enabled = True Then
            inactivar(tlbListadoDoctos.Buttons.Item(0), tlbListadoDoctos.Buttons.Item(2))
            Activar(tlbListadoDoctos.Buttons.Item(1), tlbListadoDoctos.Buttons.Item(3))

            Activar(btnAdjuntarListDocto, chkDoctoRestringido, txtNombreDocto)
        Else
            MsgBox("Es necesario seleccionar un grupo de la lista de la pesta�a grupos")
        End If

    End Sub

    Private Sub GuardarPagina(ByVal Accion As Integer, ByVal Id_tipoPagina As Integer, ByVal ligaPreestablecida As String, ByVal Nombre As String, ByVal Terminada As Boolean, ByVal titulo As String, ByVal Bandera As String)
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            With objPaginas
                .Activo = True
                .Id_TipoPagina = Id_tipoPagina
                .LigaPreestablecida = ligaPreestablecida
                .Nombre = Nombre
                .Terminada = Terminada
                .Titulo = titulo
                .Bandera = Bandera
                .esIndex = False

                If Accion = 1 Then .Insertar()
                If Accion = 2 Then
                    .Id_Pagina = Id_Pagina
                    .Actualizar()
                End If

                REM al momento de insertar traigo el Id de la pagina
                Id_Pagina = .Id_Pagina

            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try
    End Sub

    Private Sub EliminarPaginaNoTerminada()
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            objPaginas.Bandera = "d2"
            objPaginas.Terminada = False
            objPaginas.Id_Pagina = Id_Pagina
            objPaginas.Eliminar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try
    End Sub

    Private Sub CargarTiposPaginas()
        Dim objTiposPaginas As New clsTiposPaginas.Maple.clsTipoPagina
        Try
            objTiposPaginas.Bandera = "s2"
            objTiposPaginas.Visible = True
            cboTipoPagina.DataSource = objTiposPaginas.Listar
            cboTipoPagina.ValueMember = "Id_TipoPagina"
            cboTipoPagina.DisplayMember = "Descripcion"

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objTiposPaginas = Nothing
        End Try
    End Sub

    Private Sub frmGestor_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        EliminarGruposSinTerminar() REM 1
        EliminarPaginaNoTerminada()
        CargaDeInicio() REM 2
        resetearPropiedades()
    End Sub

    Private Sub guardarNuevaPagina()
        REM validar campos
        Dim camposInvalidos As String = ""
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(cboNombrePagina, txtTituloPagina))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " ,son requeridos para guardar el registro")
                Guarde = False
            Else

                GuardarPagina(2, cboTipoPagina.SelectedValue, Nothing, cboNombrePagina.Text, True, txtTituloPagina.Text, "u1")
                MsgBox("La pagina se ha guardado")
                Guarde = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Guarde = False
        Finally
            objValidar = Nothing
        End Try
    End Sub

    Private Sub guardarNuevoGrupo()
        REM validar campos
        Dim camposInvalidos As String = ""
        Dim Terminada As Boolean = False
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Dim iIndex As Integer

        Try
            REM este proceso solo lo mando a llamar cuando hago el update del grupo
            REM es decir que no hago un insert por lo que debo de contar con id para guardar 
            REM de lo contario no guardo nada

            If Id_Grupo > -1 Then
                camposInvalidos = objValidar.ValidarCampos(validarCampos(txtNombreGrupo))
                If camposInvalidos <> "" Then
                    MsgBox("El o los campos: " & camposInvalidos & " ,son requeridos para guardar el registro")
                    Guarde = False
                    Exit Sub
                End If
                REM ver si el grupo esta guardado en la base de datos
                objGrupos.Bandera = "s1"
                objGrupos.Id_GruposPaginas = Id_Grupo
                objGrupos.LlenarDatos()
                Terminada = IIf(objGrupos.Terminada = True, True, False)

                guardarGrupo(2, txtDescripcionGrupo.Text, Id_Pagina, txtNombreGrupo.Text, Terminada, txtTextoGrupo.Text, "u1")


                Id_Grupo = Nothing
                Guarde = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objValidar = Nothing
            objGrupos = Nothing
        End Try
    End Sub

    Private Sub guardarGrupo(ByVal accion As Integer, ByVal Descripcion As String, ByVal Idpagina As Integer, ByVal Nombre As String, ByVal Terminada As Boolean, ByVal texto As String, ByVal bandera As String)
        Dim objGruposPaginas As New clsGruposPaginas.Maple.clsGruposPaginas

        Try
            With objGruposPaginas
                .Activo = True
                .Descripcion = Descripcion
                .Id_Pagina = Idpagina
                .Nombre = Nombre
                .Terminada = Terminada
                .Texto = texto
                .Bandera = bandera

                If accion = 1 Then
                    .Insertar()
                End If
                If accion = 2 Then
                    .Id_GruposPaginas = Id_Grupo
                    .Actualizar()
                    IncioGrupos()
                End If

                REM al momento de insertar traigo el Id de la pagina
                Id_Grupo = .Id_GruposPaginas

                If .respRetorno(1) = "1" Then
                    MsgBox(.respRetorno(0))
                End If
            End With

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGruposPaginas = Nothing
        End Try
    End Sub

    Private Sub EliminarGrupoPendiente()
        Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Try
            objGrupos.Bandera = "d3"
            objGrupos.Terminada = False
            REM objGrupos.Id_Pagina = Id_Pagina
            objGrupos.Id_GruposPaginas = Id_Grupo
            objGrupos.Eliminar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGrupos = Nothing
        End Try
    End Sub
    Private Sub EliminarGruposSinTerminar()
        Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Try
            objGrupos.Bandera = "d2"
            objGrupos.Terminada = False
            objGrupos.Id_Pagina = Id_Pagina
            objGrupos.Eliminar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGrupos = Nothing
        End Try
    End Sub

    Private Sub Estilos(ByVal grd As DataGrid, ByVal Datosgrid As Array, ByVal dt As DataTable)
        If dt Is Nothing Then Exit Sub

        Dim Columnas As Integer = dt.Columns.Count
        Dim aux() As String
        Dim tama�o As Integer = 0
        Dim ts1 As New DataGridTableStyle
        Dim col As Integer = 0

        tama�o = grd.Width / Columnas
        grd.TableStyles.Clear()

        ts1.MappingName = dt.TableName
        ColorStyle(ts1, grd)
        Try

            For col = 0 To Columnas - 1
                aux = Split(Datosgrid(col), "|")

                Dim Columna
                If dt.Columns(col).DataType.FullName = "System.Boolean" Then
                    Columna = New DataGridBoolColumn
                Else
                    Columna = New DataGridTextBoxColumn
                End If

                Columna.MappingName = dt.Columns(col).ColumnName
                Columna.HeaderText = aux(0)

                If CType(aux(1), Boolean) = False Then
                    Columna.Width = 0
                Else
                    Columna.Width = tama�o + CType(aux(2), Integer)
                End If

                Columna.NullText = ""
                ts1.GridColumnStyles.Add(Columna)
            Next

            grd.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("asegurate que las columnas coincidan con los nombres")
        End Try
    End Sub

    Public Sub ColorStyle(ByVal ts1 As DataGridTableStyle, ByVal grid As DataGrid)
        ts1.SelectionForeColor = Color.White
        ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderForeColor = Color.White
        ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
        ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)
        grid.BorderStyle = BorderStyle.Fixed3D
        grid.FlatMode = True
        grid.RowHeaderWidth = 18
    End Sub

    Private Sub CargaDatosGrupos()
        Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Dim dt As DataTable
        Try
            objGrupos.Bandera = "s3"
            If Id_Pagina <> 0 Then
                objGrupos.Id_Pagina = Id_Pagina
            Else
                objGrupos.Id_Pagina = cboNombrePagina.SelectedValue
            End If

            objGrupos.Activo = True
            REM objGrupos.Terminada = True
            dt = objGrupos.Listar()
            grdGrupos.DataSource = dt

            Activar(tlbGalerias, tlbListadoDoctos)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGrupos = Nothing
        End Try

        AplicarEstilos(dt, 3)

    End Sub

    Private Sub LlenarDatosGrupos(ByVal id As Integer)
        Dim objgrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Try
            objgrupos.Id_GruposPaginas = id
            objgrupos.Bandera = "s1"
            objgrupos.LlenarDatos()

            With objgrupos
                txtNombreGrupo.Text = .Nombre
                txtDescripcionGrupo.Text = .Descripcion
                txtTextoGrupo.Text = .Texto
                Id_Grupo = .Id_GruposPaginas
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objgrupos = Nothing
        End Try
    End Sub

    Private Sub cboTipoPagina_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTipoPagina.SelectionChangeCommitted
        cargarPaginas()
        CargarDatosGenerales()
        CargaDatosGrupos()
        inactivar(tlbGalerias, tlbListadoDoctos)
    End Sub

    Private Sub cboNombrePagina_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboNombrePagina.SelectionChangeCommitted
        CargarDatosGenerales()
        CargaDatosGrupos()
        inactivar(tlbGalerias, tlbListadoDoctos)

    End Sub

    Private Sub CargarDatosGenerales()
        Dim objPagina As New clsPAginas.Maple.clsPaginas
        Try
            objPagina.Bandera = "s1"
            objPagina.Id_Pagina = cboNombrePagina.SelectedValue
            objPagina.LlenarDatos()

            txtTituloPagina.Text = objPagina.Titulo

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPagina = Nothing
        End Try
    End Sub


    Private Function ValidarMasGrupos(ByVal idPagina As Integer) As Boolean
        Dim valido As Boolean = False
        If cboTipoPagina.SelectedValue = 1 Then
            Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
            Try
                objGrupos.Bandera = "s3"
                objGrupos.Id_Pagina = idPagina
                objGrupos.Terminada = True
                objGrupos.Activo = True
                If objGrupos.Listar().Rows.Count > 0 Then
                    valido = False
                Else
                    valido = True
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                objGrupos = Nothing
            End Try
        Else
            valido = True
        End If

        Return valido
    End Function

    Private Sub edicionGrupos()

        Escritura(txtNombreGrupo, txtDescripcionGrupo, txtTextoGrupo)

        Activar(tlbGrupos.Buttons.Item(1), tlbGrupos.Buttons.Item(4))
        Activar(tpGaleria, tpListadoDoctos)
        inactivar(tlbGrupos.Buttons.Item(0), tlbGrupos.Buttons.Item(2), tlbGrupos.Buttons.Item(3), tlbGrupos.Buttons.Item(5))
        inactivar(grdGrupos)
    End Sub

    Private Sub terminarGruposNuevos()
        Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Try
            REM TENGO QUE ELIMINAR LAS PAGINAS QUE TENGO EN MEMORIA
            objGrupos.Bandera = "d2"
            objGrupos.Id_GruposPaginas = Id_Grupo
            objGrupos.Terminada = False
            objGrupos.Eliminar()

            REM TENGO QUE TERMINAR LAS PAGINAS QUE YA AGREGUE
            objGrupos.Bandera = "u2"
            objGrupos.Id_Pagina = Id_Pagina
            objGrupos.Terminada = True
            objGrupos.Actualizar()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGrupos = Nothing
        End Try
    End Sub

    Private Sub EliminarGrupo()
        Dim objGrupos As New clsGruposPaginas.Maple.clsGruposPaginas
        Try
            If Id_Grupo = 0 Then
                MsgBox("Debes seleccionar un grupo")
            Else
                If MsgBox("�Estas seguro de eliminar el grupo seleccionado?", MsgBoxStyle.Exclamation Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then

                    objGrupos.Bandera = "u3"
                    objGrupos.Id_GruposPaginas = Id_Grupo
                    objGrupos.Activo = False
                    objGrupos.Actualizar()

                    If objGrupos.respRetorno(1) <> "1" Then
                        delImagenesPorGrupo(Id_Grupo)
                        MsgBox("Registro Eliminado")
                        CargaDatosGrupos()
                        IncioGrupos()
                    Else
                        MsgBox(objGrupos.respRetorno(0))
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGrupos = Nothing
        End Try
    End Sub

    Private Sub LlenarImagenes()
        Dim objGaleria As New clsPaginasGalerias.Maple.clsPaginasGalerias
        Dim dt As DataTable
        Try
            objGaleria.Bandera = "s3"
            objGaleria.Id_GruposPaginas = Id_Grupo
            objGaleria.Activo = True

            dt = objGaleria.Listar
            grdGaleria.DataSource = dt

            AplicarEstilos(dt, 2)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dt.Dispose()
            objGaleria = Nothing
        End Try
    End Sub

    Private Sub LlenarLigas()
        Dim objLigas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas
        Dim dt As DataTable
        Try
            objLigas.Bandera = "s2"
            objLigas.Id_GruposPaginas = Id_Grupo
            objLigas.Activo = True

            dt = objLigas.Listar
            grdLigas.DataSource = dt
            DtTempLigas = dt

            AplicarEstilos(dt, 4)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dt.Dispose()
            objLigas = Nothing
        End Try
    End Sub

    Private Sub LlenarDocumentos()
        Dim objDocumentos As New clsDocumentosWeb.Maple.clsDocumentosWeb
        Dim dt As DataTable
        Try
            If Id_Grupo <> 0 Then
                objDocumentos.Bandera = "s3"
                objDocumentos.Id_GruposPaginas = Id_Grupo
                objDocumentos.Activo = True

                dt = objDocumentos.Listar
                grdListadoDocumentos.DataSource = dt

                AplicarEstilos(dt, 1)

                dt.Dispose()
            Else
                grdListadoDocumentos.DataSource = Nothing
            End If


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objDocumentos = Nothing
        End Try
    End Sub

    Private Sub btnAdjuntar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdjuntar.Click
        Dim objOpenDialog As New OpenFileDialog
        Try
            objOpenDialog.Filter = "Archivo (JPG)|*.jpg|Archivo (PNG)|*.png|Archivo (GIF)|*.gif"
            objOpenDialog.ShowDialog()
            txtImagenAdjunta.Text = objOpenDialog.FileName
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objOpenDialog = Nothing
        End Try

    End Sub

    Private Sub AgregarItemGaleria()
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim camposInvalidos As String = ""
        Dim Random As New Random
        Dim ArrTemp() As String

        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(txtNombreImagen, txtImagenAdjunta))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " son requeridos")
            Else
                Dim dt As New DataTable("Galerias")
                If DtTempGaleria Is Nothing Then
                    dt = (EstructuraDtGaleria(dt))
                Else
                    dt = DtTempGaleria
                End If

                REM preparo datos para guardarlos en la fila
                Dim newRow As DataRow = dt.NewRow()
                Dim NomArchivo As String = NombreArchivo(txtImagenAdjunta.Text)
                ArrTemp = Split(NomArchivo, ".")
                Dim Extencion As String = ArrTemp(ArrTemp.Length - 1)

                REM lleno los datos que necesito de la fila
                newRow("Nombre") = txtNombreImagen.Text
                newRow("Id_GruposPaginas") = Id_Grupo
                newRow("Archivo") = "IMG-" & Format(Now, "ddMMyyyhhmmssfff") & "." & Extencion
                newRow("Ruta") = txtImagenAdjunta.Text
                dt.Rows.Add(newRow)

                REM agrego el dt al grid para verlo
                grdGaleria.DataSource = dt
                DtTempGaleria = dt

                REM agrego estilos
                AplicarEstilos(dt, 2)

                Filtrar(DtTempGaleria, grdGaleria)
                inicioGaleria()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objValidar = Nothing
            Random = Nothing
        End Try

    End Sub

    Private Sub AgregarItemDocumentos()
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim camposInvalidos As String = ""
        Dim Random As New Random
        Dim ArrTemp() As String

        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(txtNombreDocto, txtDocumentoAdjunta))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " son requeridos")
            Else
                Dim dt As New DataTable("Documentos")
                If DtTempDoctos Is Nothing Then
                    dt = (EstructuraDtDocumentos(dt))
                Else
                    dt = DtTempDoctos
                End If

                REM preparo datos para guardarlos en la fila
                Dim newRow As DataRow = dt.NewRow()
                Dim NomArchivo As String = NombreArchivo(txtDocumentoAdjunta.Text)
                ArrTemp = Split(NomArchivo, ".")
                Dim Extencion As String = ArrTemp(ArrTemp.Length - 1)

                REM lleno los datos que necesito de la fila
                newRow("Nombre") = txtNombreDocto.Text
                newRow("Id_GruposPaginas") = Id_Grupo
                newRow("Archivo") = "DOC-" & Format(Now, "ddMMyyyhhmmssfff") & "." & Extencion
                newRow("Restringido") = chkDoctoRestringido.Checked
                newRow("Ruta") = txtDocumentoAdjunta.Text
                newRow("Pertenece") = txtPertenece.Text
                dt.Rows.Add(newRow)

                REM agrego el dt al grid para verlo
                grdListadoDocumentos.DataSource = dt
                DtTempDoctos = dt

                REM agrego estilos
                AplicarEstilos(dt, 1)

                Filtrar(DtTempDoctos, grdListadoDocumentos)
                inicioDocumentos()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objValidar = Nothing
            Random = Nothing
        End Try

    End Sub

    Private Sub AplicarEstilos(ByVal dt As DataTable, ByVal iProceso As Integer)
        Dim datosgrid() As String

        Select Case iProceso
            Case 1 REM Documentos
                datosgrid = Split("Id_DocumentoWeb|False|0,Id_GruposPaginas|False|0,Nombre|True|185,Archivo|True|100,Restringido|True|50,Activo|False|0,Ruta|False|0,Pertenece|True|0", ",")
                Estilos(grdListadoDocumentos, datosgrid, dt)
            Case 2 REM Galerias
                datosgrid = Split("Id_PaginasGalerias|False|0,Id_GruposPaginas|False|0,Nombre|True|200,Archivo|True|100,Activo|False|0,Ruta|False|0", ",")
                Estilos(grdGaleria, datosgrid, dt)
            Case 3 REM grupos
                datosgrid = Split("Id_GruposPaginas|False|0,Id_Pagina|False|0,Nombre|True|100,Descripcion|True|100,Texto|True|100,Terminada|False|0,Activo|False|0", ",")
                Estilos(grdGrupos, datosgrid, dt)
            Case 4 REM Ligas
                datosgrid = Split("Id_LigasGruposPaginas|False|0,Id_GruposPaginas|False|0,Nombre|True|150,Texto|True|150," _
                                & "Id_TiposLigas|False|0,aId_DocumentoWeb|False|0,aExterna|False|0," _
                                & "aId_Pagina|False|0,Activo|False|0,Ruta|False|0,NombreArc|False|0,Restringido|False|0", ",")
                Estilos(grdLigas, datosgrid, dt)
        End Select

    End Sub

    Private Function EstructuraDtGaleria(ByVal dt As DataTable)
        dt.Columns.Add("Id_PaginasGalerias", Type.GetType("System.String"))
        dt.Columns.Add("Id_GruposPaginas", Type.GetType("System.String"))
        dt.Columns.Add("Nombre", Type.GetType("System.String"))
        dt.Columns.Add("Archivo", Type.GetType("System.String"))
        dt.Columns.Add("Activo", Type.GetType("System.String"))
        dt.Columns.Add("Ruta", Type.GetType("System.String"))

        Return dt
    End Function

    Private Function EstructuraDtDocumentos(ByVal dt As DataTable)
        dt.Columns.Add("Id_DocumentoWeb", Type.GetType("System.String"))
        dt.Columns.Add("Id_GruposPaginas", Type.GetType("System.String"))
        dt.Columns.Add("Nombre", Type.GetType("System.String"))
        dt.Columns.Add("Archivo", Type.GetType("System.String"))
        dt.Columns.Add("Restringido", Type.GetType("System.Boolean"))
        dt.Columns.Add("Activo", Type.GetType("System.String"))
        dt.Columns.Add("Ruta", Type.GetType("System.String"))
        dt.Columns.Add("Pertenece", Type.GetType("System.String"))

        Return dt
    End Function


    Private Function EstructuraDtLigas(ByVal dt As DataTable)
        dt.Columns.Add("Id_LigasGruposPaginas", Type.GetType("System.String"))
        dt.Columns.Add("Id_GruposPaginas", Type.GetType("System.String"))
        dt.Columns.Add("Nombre", Type.GetType("System.String"))
        dt.Columns.Add("Texto", Type.GetType("System.String"))
        dt.Columns.Add("Id_TiposLigas", Type.GetType("System.String"))
        dt.Columns.Add("aId_DocumentoWeb", Type.GetType("System.String"))
        dt.Columns.Add("aExterna", Type.GetType("System.String"))
        dt.Columns.Add("aId_Pagina", Type.GetType("System.String"))
        dt.Columns.Add("Activo", Type.GetType("System.String"))
        dt.Columns.Add("Ruta", Type.GetType("System.String"))
        dt.Columns.Add("NombreArc", Type.GetType("System.String")) REM descripcion de la liga
        dt.Columns.Add("Restringido", Type.GetType("System.String")) REM descripcion de la liga

        Return dt
    End Function

    Private Function NombreArchivo(ByVal sArchivoRuta As String) As String
        Dim sNombreArchivos As String
        Dim iIndice As Integer
        Dim sNombreArTem As String = ""

        'nombre archivo
        For iIndice = Len(sArchivoRuta) To 1 Step -1
            If Mid(sArchivoRuta, iIndice, 1) = "\" Then
                sNombreArTem = Mid(sArchivoRuta, iIndice + 1)
                iIndice = 1
            End If
        Next iIndice

        Return sNombreArTem
    End Function

    Private Sub TabGrupos_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabGrupos.SelectedIndexChanged
        Select Case sender.selectedindex
            Case 0
            Case 1
                LlenarImagenes()
                If Not grdGaleria.DataSource Is Nothing Then
                    Filtrar(DtTempGaleria, grdGaleria)
                    AplicarEstilos(DtTempGaleria, 2)
                End If
            Case 2
                LlenarDocumentos()
                If Not grdListadoDocumentos.DataSource Is Nothing Then
                    Filtrar(DtTempDoctos, grdListadoDocumentos)
                    AplicarEstilos(DtTempDoctos, 1)
                End If
        End Select
    End Sub

    Private Sub Filtrar(ByVal dt As DataTable, ByVal grd As DataGrid)
        Dim sort = "Nombre asc" ' ordenar por fechas
        Dim rows As DataRow()
        Dim dtNew As DataTable
        Try

            If dt Is Nothing Then
                dt = grd.DataSource
            End If

            dtNew = dt.Clone()

            'Donde strSelectgral es un where asunto = ''
            rows = dt.Select("Id_GruposPaginas='" & Id_Grupo & "'", sort)
            For Each dr As DataRow In rows
                dtNew.ImportRow(dr)
            Next
            grd.DataSource = dtNew
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dtNew.Dispose()
        End Try
    End Sub

    Private Sub eliminar(ByVal dt As DataTable, ByVal grd As DataGrid, ByVal idTipoProceso As Integer)
        Dim iIndex As Integer
        Dim iConsecutivo As String
        iIndex = grd.CurrentRowIndex

        REM 

        If iIndex < 0 Then
            MsgBox("Es necesario selecionar un elemento de la lista")
        Else
            If MsgBox("�Estas seguro de eliminar el registro?.", MsgBoxStyle.Exclamation Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                REM borrar de base si es que esta en la base
                If Not IsDBNull(grd.Item(iIndex, 0)) Then
                    REM borro de la base
                    Select Case idTipoProceso
                        Case 1 REM galerias
                            EliminaItemGaleria(grd.Item(iIndex, 0))
                            inicioGaleria()
                            LlenarImagenes()
                        Case 2
                            EliminaItemDocumentos(grd.Item(iIndex, 0))
                            inicioDocumentos()
                            LlenarDocumentos()
                        Case 3
                            EliminaItemLigas(grd.Item(iIndex, 0))
                            LlenarLigas()
                        Case 4
                    End Select
                Else
                    REM elimino solo de la tabla
                    dt.Rows(iIndex).Delete()
                    MsgBox("Registro Eliminado")
                End If
                Filtrar(dt, grd)
            End If
        End If
    End Sub

    Private Sub EliminaItemGaleria(ByVal id As Integer)
        Dim objGalerias As New clsPaginasGalerias.Maple.clsPaginasGalerias
        Try
            objGalerias.Bandera = "u2"
            objGalerias.Id_PaginasGalerias = id
            objGalerias.Activo = False
            objGalerias.Eliminar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGalerias = Nothing
        End Try
    End Sub

    Private Sub EliminaItemDocumentos(ByVal id As Integer)
        Dim objDocumentos As New clsDocumentosWeb.Maple.clsDocumentosWeb
        Try
            objDocumentos.Bandera = "u2"
            objDocumentos.Id_DocumentoWeb = id
            objDocumentos.Activo = False
            objDocumentos.Eliminar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objDocumentos = Nothing
        End Try
    End Sub

    Private Sub EliminaItemLigas(ByVal id As Integer)
        Dim objLigas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas
        Try
            objLigas.Bandera = "u2"
            objLigas.Id_LigasGruposPaginas = id
            objLigas.Activo = False
            objLigas.Eliminar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objLigas = Nothing
        End Try
    End Sub

    Private Sub delImagenesPorGrupo(ByVal IdGrupo As Integer)
        REM mismo caso tengo que ver si esta en la base de datos si no solo elimino la fila
        REM pero primero filtro el dt y elimino las filas
        Dim sort = "Nombre asc" ' ordenar por fechas
        Dim rows As DataRow()

        Try
            'Donde strSelectgral es un where asunto = ''
            If Not DtTempGaleria Is Nothing Then
                rows = DtTempGaleria.Select("Id_GruposPaginas='" & IdGrupo & "'", sort)
                For Each dr As DataRow In rows
                    If IsDBNull(dr.Item("PaginasGalerias")) Then
                        REM elimino solo de la tabla
                        DtTempGaleria.Rows.Remove(dr)
                    Else
                        REM elimino de la base
                    End If
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub GuardarGaleria()
        Dim objGalerias As New clsPaginasGalerias.Maple.clsPaginasGalerias
        Dim sDestino As String = ConfigurationSettings.AppSettings.Get("Galerias")
        REM tengo que guardar el datatable
        Try
            If DtTempGaleria Is Nothing Then Exit Sub

            For Each dr As DataRow In DtTempGaleria.Rows
                With objGalerias
                    .Bandera = "i1"
                    .Id_GruposPaginas = dr.Item("Id_GruposPaginas")
                    .Nombre = dr.Item("Nombre")
                    .Archivo = dr.Item("Archivo")
                    .Activo = True
                    If IsDBNull(dr.Item("Id_PaginasGalerias")) Then
                        .Insertar()
                        Adjuntar(dr.Item("Ruta"), dr.Item("Archivo"), sDestino)
                    End If

                End With
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGalerias = Nothing
        End Try
    End Sub

    Private Sub GuardarLigas()
        Dim objLigas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas


        REM tengo que guardar el datatable
        Try
            If DtTempLigas Is Nothing Then Exit Sub

            For Each dr As DataRow In DtTempLigas.Rows
                With objLigas
                    .Bandera = "i1"
                    If IsDBNull(dr.Item("Id_LigasGruposPaginas")) Then

                        .Id_GruposPaginas = dr.Item("Id_GruposPaginas")
                        .Nombre = IIf(IsDBNull(dr.Item("Nombre")) = True, Nothing, dr.Item("Nombre"))
                        .Texto = IIf(IsDBNull(dr.Item("Texto")) = True, Nothing, dr.Item("Texto"))
                        .Id_TiposLigas = IIf(IsDBNull(dr.Item("Id_TiposLigas")) = True, Nothing, dr.Item("Id_TiposLigas"))
                        .aExterna = IIf(IsDBNull(dr.Item("aExterna")) = True, Nothing, dr.Item("aExterna"))
                        .aId_Pagina = IIf(IsDBNull(dr.Item("aId_Pagina")) = True, Nothing, dr.Item("aId_Pagina"))
                        .Activo = True

                        If dr.Item("Id_TiposLigas") = 1 And Not IsDBNull(dr.Item("Ruta")) Then
                            .aId_DocumentoWeb = GuardarLigaDocumento(CType(dr.Item("restringido"), Boolean), dr.Item("Ruta"), dr.Item("NombreArc"))
                        End If

                        If IsDBNull(dr.Item("Id_LigasGruposPaginas")) Then
                            .Insertar()
                        End If

                    End If
                End With
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objLigas = Nothing
        End Try
    End Sub

    Private Function GuardarLigaDocumento(ByVal restringido As Boolean, ByVal sRuta As String, ByVal NombreArc As String) As Integer
        Dim sDestino As String = ConfigurationSettings.AppSettings.Get("Documentos")
        Dim ArrTemp() As String
        Dim NomArchivo As String = ""
        Dim Extencion As String = ""
        Dim objDocumentos As New clsDocumentosWeb.Maple.clsDocumentosWeb

        NomArchivo = NombreArchivo(sRuta)
        ArrTemp = Split(NomArchivo, ".")
        Extencion = ArrTemp(ArrTemp.Length - 1)
        NomArchivo = "ARC-" & Format(Now, "ddMMyyyhhmmssfff") & "." & Extencion
        GuardarLigaDocumento = Nothing

        Try
            With objDocumentos
                .Bandera = "i1"
                .Id_GruposPaginas = Nothing
                .Nombre = NombreArc
                .Archivo = NomArchivo
                .Restringido = restringido
                .Activo = True

                .Insertar()
                GuardarLigaDocumento = .Id_DocumentoWeb
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objDocumentos = Nothing
        End Try
        Adjuntar(sRuta, NomArchivo, sDestino)

        Return GuardarLigaDocumento
    End Function

    Private Sub GuardarDocumentos()
        Dim objDocumentos As New clsDocumentosWeb.Maple.clsDocumentosWeb
        Dim sDestino As String = ConfigurationSettings.AppSettings.Get("Documentos")
        REM tengo que guardar el datatable
        Try
            If DtTempDoctos Is Nothing Then Exit Sub

            For Each dr As DataRow In DtTempDoctos.Rows
                With objDocumentos
                    .Bandera = "i1"
                    .Id_GruposPaginas = dr.Item("Id_GruposPaginas")
                    .Nombre = dr.Item("Nombre")
                    .Archivo = dr.Item("Archivo")
                    .Restringido = CType(dr.Item("Restringido"), Boolean)
                    .Pertenece = dr.Item("Pertenece")
                    .Activo = True

                    If IsDBNull(dr.Item("Id_DocumentoWeb")) Then
                        .Insertar()
                        Adjuntar(dr.Item("Ruta"), dr.Item("Archivo"), sDestino)
                    End If

                End With
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objDocumentos = Nothing
        End Try
    End Sub

    Private Sub Adjuntar(ByVal sRuta As String, ByVal sNombreArchivo As String, ByVal sDestino As String)
        If File.Exists(sDestino & sNombreArchivo) Then Kill(sDestino & sNombreArchivo)
        File.Copy(sRuta, sDestino & sNombreArchivo)
    End Sub

    Private Sub btnAdjuntarListDocto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdjuntarListDocto.Click
        Dim objOpenDialog As New OpenFileDialog
        Try
            objOpenDialog.Filter = "Todos Los archivos (*.*)|*.*"
            objOpenDialog.ShowDialog()
            txtDocumentoAdjunta.Text = objOpenDialog.FileName
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objOpenDialog = Nothing
        End Try
    End Sub

    Private Sub grdListadoDocumentos_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdListadoDocumentos.DoubleClick
        Dim iIndex As Integer
        Dim iConsecutivo As Integer
        iIndex = grdListadoDocumentos.CurrentRowIndex

        If iIndex < 0 Then Exit Sub

        If grdListadoDocumentos.DataSource Is Nothing Then
            Exit Sub
        ElseIf IsDBNull(grdListadoDocumentos.Item(0, 0)) Then
            REM abro el que esta adjunto
            System.Diagnostics.Process.Start(grdListadoDocumentos.Item(iIndex, 6))
        Else
            REM abro el de la base de datos
            iConsecutivo = grdListadoDocumentos.Item(iIndex, 0)

        End If
    End Sub

    Private Sub botonesDeNuevasLigas()
        If Id_Grupo <> 0 And tlbGrupos.Buttons.Item(0).Enabled = True Then

            inactivar(tblLigas.Buttons.Item(1))
            Activar(tblLigas.Buttons.Item(0), tblLigas.Buttons.Item(2), tblLigas.Buttons.Item(3), tblLigas.Buttons.Item(5), tblLigas.Buttons.Item(6))
            inactivar(tblLigas.Buttons.Item(1), tblLigas.Buttons.Item(4))
            Activar(tblLigas, grdLigas, cboTipoLiga)

            Limpiar(txtNombreLiga, txtTextoLiga)
            txtGrupoDeContenido.Text = txtNombreGrupo.Text

            tpContenido.Parent = TabGeneral
            tpGrupos.Parent = Nothing

            REM ----Activar los campos----
            Lectura(txtNombreLiga, txtTextoLiga)
            Activar(cboTipoLiga)
            REM ---Llenar combo
            LlenarTiposLigas()
            InactivarPestLigas()
            REM ----Inactivar todas las pesta�as----
            InactivarPestLigas()

            If Not grdLigas.DataSource Is Nothing Then
                Filtrar(DtTempLigas, grdLigas)
                AplicarEstilos(DtTempLigas, 4)
            End If

        Else
            MsgBox("Es necesario seleccionar un grupo de la lista de la pesta�a grupos")
        End If
    End Sub

    Private Sub LlenarTiposLigas()
        Dim objTiposLigas As New clsTiposLigas.Maple.clsTiposLigas
        Try
            objTiposLigas.Bandera = "s2"
            cboTipoLiga.DataSource = objTiposLigas.Listar()
            cboTipoLiga.DisplayMember = "Descripcion"
            cboTipoLiga.ValueMember = "Id_TiposLigas"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objTiposLigas = Nothing
        End Try
    End Sub

    Private Sub InactivarPestLigas()
        tpLigaDocto.Parent = Nothing
        tpLigaExterna.Parent = Nothing
        tpLigaDinamicas.Parent = Nothing
    End Sub

    Private Sub AccionesLigas()

        If cboTipoLiga.Items.Count > 0 Then
            Select Case cboTipoLiga.SelectedValue
                Case 1
                    tpLigaDocto.Parent = TabLigas
                    AccionDocumentos()
                Case 2
                    tpLigaExterna.Parent = TabLigas
                    AccionLigasExternas()
                Case 3
                    tpLigaDinamicas.Parent = TabLigas
                    Activar(optRepositorio, OptPaginasContenido, cboPaginas)
                    SeleccionTipoPagina()
            End Select
        End If
    End Sub

    Private Sub AccionDocumentos()
        chkRestringirDoctoLiga.Checked = False
        Activar(txtDocumentoLiga, btnAdjuntarDoctoLiga, chkRestringirDoctoLiga)
        Escritura(txtDocumentoLiga)
        Limpiar(txtDocumentoLiga, txtDocumentoAdjuntoLiga)
    End Sub

    Private Sub AccionLigasExternas()
        Activar(txtLigaExterna)
        Escritura(txtLigaExterna)
        Limpiar(txtLigaExterna)
        chkRestringirDoctoLiga.Checked = False
    End Sub

    Private Sub AccionDinamicas(ByVal IdTipoPagina As Integer)
        REM llenar combos
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            REM atens tenia s3 pero ahora es s2
            objPaginas.Bandera = "s2"
            objPaginas.Activo = True
            objPaginas.Terminada = True

            objPaginas.Id_TipoPagina = IdTipoPagina
            cboPaginas.DataSource = objPaginas.Listar
            cboPaginas.DisplayMember = "Nombre"
            cboPaginas.ValueMember = "Id_Pagina"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try
    End Sub

    Private Sub tblLigas_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tblLigas.ButtonClick
        Select Case tblLigas.Buttons.IndexOf(e.Button)
            Case 0 REM nuevo
                botonesDeNuevaLiga()
                AccionesLigas()
            Case 1 REM guardar
                agregarItemLigas()
                If Guarde = True Then botonesDeNuevasLigas()
            Case 2 REM editar
            Case 3 REM eliminar
                eliminar(DtTempLigas, grdLigas, 3)
                Limpiar(txtNombreLiga, txtTextoLiga)
                LlenarLigas()
            Case 4 REM deshacer accion
                botonesDeNuevasLigas()
            Case 5 REM deshacer general
                tpGrupos.Parent = TabGeneral
                tpContenido.Parent = Nothing
                TabGrupos.SelectedTab = tpListadoGrupos
            Case 6 REM Regresar a grupos
                guardarCambioGrupo()
        End Select
    End Sub

    Private Sub botonesDeNuevaLiga()
        Activar(tblLigas.Buttons.Item(1), tblLigas.Buttons.Item(4))
        inactivar(cboTipoLiga, tblLigas.Buttons.Item(0), tblLigas.Buttons.Item(2), tblLigas.Buttons.Item(3), tblLigas.Buttons.Item(5), tblLigas.Buttons.Item(6))
        Escritura(txtNombreLiga, txtTextoLiga)
        Limpiar(txtNombreLiga, txtTextoLiga)
    End Sub

    Private Sub agregarItemLigas()
        Select Case cboTipoLiga.SelectedValue
            Case 1
                ItemArchivos()
            Case 2
                ItemExternas()
            Case 3
                addItemLigas()
        End Select
    End Sub

    Private Sub ItemArchivos()
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim camposInvalidos As String = ""
        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(txtDocumentoLiga, txtDocumentoAdjuntoLiga))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " son requeridos")
                Guarde = False
            Else
                addItemLigas()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objValidar = Nothing
        End Try
    End Sub

    Private Sub ItemExternas()
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim camposInvalidos As String = ""

        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(txtLigaExterna))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " son requeridos")
                Guarde = False
            Else
                addItemLigas()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objValidar = Nothing
        End Try
    End Sub

    Private Sub addItemLigas()
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim camposInvalidos As String = ""

        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(txtNombreLiga))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " son requeridos")
                Guarde = False
                Exit Sub
            End If

            Dim dt As New DataTable("Ligas")
            If DtTempLigas Is Nothing Then
                dt = (EstructuraDtLigas(dt))
            Else
                dt = DtTempLigas
            End If

            REM preparo datos para guardarlos en la fila
            Dim newRow As DataRow = dt.NewRow()

            REM lleno los datos que necesito de la fila
            newRow("Id_GruposPaginas") = Id_Grupo
            newRow("Nombre") = txtNombreLiga.Text
            newRow("Texto") = txtTextoLiga.Text
            If optPreestablecidas.Checked Then
                newRow("Id_TiposLigas") = 4
            Else
                newRow("Id_TiposLigas") = cboTipoLiga.SelectedValue
            End If

            newRow("Activo") = True

            Select Case cboTipoLiga.SelectedValue
                Case 1 REM Archivos
                    newRow("Ruta") = txtDocumentoAdjuntoLiga.Text
                    newRow("NombreArc") = txtDocumentoLiga.Text
                    newRow("Restringido") = chkRestringirDoctoLiga.Checked
                    REM newRow("aId_DocumentoWeb") =
                Case 2 REM Ligas Externas
                    newRow("aExterna") = txtLigaExterna.Text
                Case 3 REM Dinamicas
                    newRow("aId_Pagina") = cboPaginas.SelectedValue
            End Select

            dt.Rows.Add(newRow)
            Guarde = True
            REM agrego el dt al grid para verlo
            grdLigas.DataSource = dt
            DtTempLigas = dt

            REM agrego estilos
            AplicarEstilos(dt, 4)

        Catch ex As Exception
            MsgBox(ex.Message)
            Guarde = False
        Finally
            objValidar = Nothing
        End Try

    End Sub

    Private Sub btnAdjuntarDoctoLiga_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdjuntarDoctoLiga.Click
        Dim objOpenDialog As New OpenFileDialog
        Try
            objOpenDialog.Filter = "Todos Los archivos (*.*)|*.*"
            objOpenDialog.ShowDialog()
            txtDocumentoAdjuntoLiga.Text = objOpenDialog.FileName
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objOpenDialog = Nothing
        End Try
    End Sub

    Private Sub optRepositorio_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optRepositorio.CheckedChanged
        SeleccionTipoPagina()
    End Sub

    Private Sub OptPaginasContenido_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptPaginasContenido.CheckedChanged
        SeleccionTipoPagina()
    End Sub

    Private Sub optPreestablecidas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optPreestablecidas.CheckedChanged
        SeleccionTipoPagina()
    End Sub

    Private Sub SeleccionTipoPagina()
        If OptPaginasContenido.Checked Then AccionDinamicas(1)
        If optRepositorio.Checked Then AccionDinamicas(2)
        If optPreestablecidas.Checked Then AccionDinamicas(3)
    End Sub

    Private Sub DatosDeLiga()
        If grdLigas.DataSource Is Nothing Then
            Exit Sub
        Else
            Dim iIndex As Integer
            Dim iConsecutivo As Integer
            iIndex = grdLigas.CurrentRowIndex

            txtNombreLiga.Text = grdLigas.Item(iIndex, 2)
            txtTextoLiga.Text = grdLigas.Item(iIndex, 3)
            cboTipoLiga.SelectedValue = grdLigas.Item(iIndex, 4)
            If grdLigas.Item(iIndex, 4) = 4 Then cboTipoLiga.SelectedValue = 3
        End If
    End Sub

    Private Sub grdLigas_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdLigas.Click
        DatosDeLiga()
    End Sub

    Private Sub TabGeneral_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabGeneral.SelectedIndexChanged
        If Not tpContenido.Parent Is Nothing Then
            LlenarLigas()
        End If
    End Sub

    Private Sub EliminarPagina()
        Dim iIndex As Integer
        Dim iConsecutivo As String
        Dim objPaginas As New clsPAginas.Maple.clsPaginas

        Try
            If MsgBox("�Estas seguro de eliminar el registro?.", MsgBoxStyle.Exclamation Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                objPaginas.Bandera = "u2"
                objPaginas.Activo = False
                objPaginas.Id_Pagina = cboNombrePagina.SelectedValue
                objPaginas.Eliminar()
                If objPaginas.respRetorno(1) = "1" Then
                    MsgBox(objPaginas.respRetorno(0))
                Else
                    CargaDeInicio()
                    MsgBox("Pagina Eliminada")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try

    End Sub

    Private Sub grdGrupos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdGrupos.Click
        If grdGrupos.DataSource Is Nothing Then
            Exit Sub
        ElseIf CStr(grdGrupos.Item(0, 0)) <> "" Then

            Dim iIndex As Integer
            Dim iConsecutivo As Integer
            iIndex = grdGrupos.CurrentRowIndex

            iConsecutivo = grdGrupos.Item(iIndex, 0)
            LlenarDatosGrupos(iConsecutivo)
        End If
    End Sub

    Private Sub EstablecerIndex()
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            objPaginas.Bandera = "u3"
            objPaginas.Id_Pagina = cboNombrePagina.SelectedValue
            objPaginas.Actualizar()

            If objPaginas.respRetorno(1) = "1" Then
                MsgBox(objPaginas.respRetorno(0))
            Else
                MsgBox("Index establecido correcramente")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try

    End Sub

    Private Sub grdLigas_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdLigas.DoubleClick
        If grdLigas.DataSource Is Nothing Then
            Exit Sub
        Else
            Dim iIndex As Integer
            Dim iConsecutivo As Integer
            iIndex = grdLigas.CurrentRowIndex

            If grdLigas.Item(iIndex, 4) = 1 Then
                If IsDBNull(grdLigas.Item(iIndex, 0)) Then
                    REM es temporal
                    System.Diagnostics.Process.Start(grdLigas.Item(iIndex, 9))
                Else
                    REM ya esta guadada
                    Dim sRuta As String = ConfigurationSettings.AppSettings.Get("Documentos")
                    System.Diagnostics.Process.Start(sRuta & grdLigas.Item(iIndex, 9))
                End If
            End If
        End If
    End Sub

    Private Sub guardarCambioGrupo()
        If MsgBox("Deseas guardar los cambios realizados", MsgBoxStyle.Information Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
            GuardarLigas()
        End If

        tpGrupos.Parent = TabGeneral
        tpContenido.Parent = Nothing
        TabGrupos.SelectedTab = tpListadoGrupos
    End Sub

    Private Sub txtPertenece_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        objArbol.Visible = True
    End Sub

    Private Sub CrearArbolPertenece()
        objArbol.Name = "trvPertenece"
        objArbol.Width = 200
        objArbol.Height = 250
        objArbol.Enabled = True
        objArbol.Visible = False

        LlenarArbol()

        AddHandler objArbol.AfterSelect, AddressOf trvPertenece_AfterSelect
        AddHandler objArbol.DoubleClick, AddressOf trvPertenece_DoubleClick
        ''AddHandler objArbol.MouseLeave, AddressOf trvPertenece_MouseLeave

        objArbol.Location = (New Point(txtPertenece.Location.X + 30, 110))

        Me.Controls.Add(objArbol)
        objArbol.BringToFront()
    End Sub

    Private Sub LlenarArbol()
        objArbol.Nodes.Clear()
        Dim dtComites As DataTable
        Dim objArbolComites As New clsArbolComites.Maple.clsArbolComites
        Dim Raiz As New TreeNode
        Raiz.Tag = 0
        Raiz.Text = "Comites"

        objArbol.Nodes.Add(Raiz)

        dtComites = objArbolComites.getDatosMenu(1, "", "", "", "", "", "")
        objArbolComites = Nothing

        CrearMenuComites(dtComites, Nothing, Nothing, Nothing, 0, 1, False)
    End Sub

    Private Sub CrearMenuComites(ByVal dtDatos As DataTable, ByVal nodoCT As TreeNode, ByVal nodoSC As TreeNode, ByVal nodoGT As TreeNode, ByVal idx As Integer, ByVal ides As Integer, ByVal indGT As Boolean)
        Dim dvDatos As DataView
        Dim dtCT As DataTable
        Dim dtSC As DataTable
        Dim dtGT As DataTable
        dvDatos = New DataView(dtDatos)
        Try
            Dim aux As New clsArbolComites.Maple.clsArbolComites

            For Each dataRowCurrent As DataRowView In dvDatos
                Dim nuevoNodo As TreeNode
                nuevoNodo = New TreeNode
                nuevoNodo.Text = dataRowCurrent(idx).ToString()
                ''nuevoNodo.SelectAction = TreeNodeSelectAction.SelectExpand
                ''nuevoNodo.ToolTip = dataRowCurrent(ides).ToString
                If nodoCT Is Nothing Then
                    dtCT = aux.getDatosMenu(2, "@idCM", nuevoNodo.Text.ToString, "", "", "", "")
                    CrearMenuComites(dtCT, nuevoNodo, Nothing, Nothing, 1, 2, False)
                    dtGT = aux.getDatosMenu(4, "@idCM", nuevoNodo.Text.ToString, "@idCT", "NA", "@idSC", "NA")
                    CrearMenuComites(dtGT, nuevoNodo, Nothing, Nothing, 3, 4, True)
                    nuevoNodo.Tag = 1
                    REM trv.Nodes(0).ChildNodes.Add(nuevoNodo)
                    objArbol.Nodes(0).Nodes.Add(nuevoNodo)
                ElseIf indGT = True Then
                    nuevoNodo.Tag = 4
                    REM nodoCT.ChildNodes.Add(nuevoNodo)
                    nodoCT.Nodes.Add(nuevoNodo)
                Else
                    If nodoSC Is Nothing Then
                        dtSC = aux.getDatosMenu(3, "@idCM", nodoCT.Text, "@idCT", nuevoNodo.Text, "", "")
                        CrearMenuComites(dtSC, nodoCT, nuevoNodo, Nothing, 2, 3, False)
                        dtGT = aux.getDatosMenu(4, "@idCM", nodoCT.Text, "@idCT", nuevoNodo.Text, "@idSC", "NA")
                        CrearMenuComites(dtGT, nuevoNodo, Nothing, Nothing, 3, 4, True)
                        nuevoNodo.Tag = 2
                        REM nodoCT.ChildNodes.Add(nuevoNodo)
                        nodoCT.Nodes.Add(nuevoNodo)
                    Else
                        If nodoGT Is Nothing Then
                            dtGT = aux.getDatosMenu(4, "@idCM", nodoCT.Text.ToString, "@idCT", nodoSC.Text.ToString, "@idSC", nuevoNodo.Text.ToString)
                            CrearMenuComites(dtGT, nodoCT, nodoSC, nuevoNodo, 3, 4, False)
                            nuevoNodo.Tag = 3
                            REM nodoSC.ChildNodes.Add(nuevoNodo)
                            nodoSC.Nodes.Add(nuevoNodo)
                        Else
                            nuevoNodo.Tag = 4
                            REM nodoGT.ChildNodes.Add(nuevoNodo)
                            nodoGT.Nodes.Add(nuevoNodo)
                        End If
                    End If
                End If
            Next dataRowCurrent
            objArbol.CollapseAll()
            aux = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dvDatos = Nothing
            dtCT = Nothing
            dtSC = Nothing
            dtGT = Nothing
        End Try
    End Sub

    Private Sub trvPertenece_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs)
        If e.Node.Text <> "" And objArbol.Nodes(0).Text <> e.Node.Text Then
            txtPertenece.Text = e.Node.Text
        End If
    End Sub

    ''Private Sub trvPertenece_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)
    ''    objArbol.Visible = False
    ''End Sub

    Private Sub trvPertenece_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
        objArbol.Visible = False
    End Sub

    Private Sub chkDoctoRestringido_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDoctoRestringido.CheckedChanged
        If chkDoctoRestringido.Checked Then
            AddHandler txtPertenece.Click, AddressOf txtPertenece_Click
        Else
            RemoveHandler txtPertenece.Click, AddressOf txtPertenece_Click
        End If
    End Sub

    Private Sub cmdPegar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPegar.Click
        txtTextoGrupo.Text = CType(Clipboard.GetDataObject().GetData(DataFormats.Text), String)
    End Sub

    Private Sub cmdCopiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCopiar.Click
        Clipboard.SetDataObject(txtTextoGrupo.Text)
    End Sub
End Class
