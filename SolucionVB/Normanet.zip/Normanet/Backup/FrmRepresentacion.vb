Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports System.Data.DataSet

Public Class FrmRepresentacion
    Inherits System.Windows.Forms.Form
    Dim sStatus As String
    Dim ValEditar, iEditar As Integer


    ''''------ Codigo de la clase conexion amodificar--------------'''''
    Dim objrepresentacion As New ClsRepresentacion.C_Representacion("principal", gUsuario, gPasswordSql)       '''Identif, Usuario, Password

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents GpBoxAgrega As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents GpBoxLectura As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CmbRepresentacion As System.Windows.Forms.ComboBox
    Friend WithEvents ChkComTecGuar As System.Windows.Forms.CheckBox
    Friend WithEvents ChkComiteGuar As System.Windows.Forms.CheckBox
    Friend WithEvents ChkComteclect As System.Windows.Forms.CheckBox
    Friend WithEvents ChkComitelect As System.Windows.Forms.CheckBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmRepresentacion))
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.GpBoxAgrega = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.ChkComTecGuar = New System.Windows.Forms.CheckBox
        Me.ChkComiteGuar = New System.Windows.Forms.CheckBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TxtDescripcion = New System.Windows.Forms.TextBox
        Me.GpBoxLectura = New System.Windows.Forms.GroupBox
        Me.CmbRepresentacion = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.ChkComteclect = New System.Windows.Forms.CheckBox
        Me.ChkComitelect = New System.Windows.Forms.CheckBox
        Me.lblStatus = New System.Windows.Forms.Label
        Me.GpBoxAgrega.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GpBoxLectura.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.CmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 229)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(414, 62)
        Me.tlbBotonera.TabIndex = 47
        Me.tlbBotonera.TabStop = True
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "&Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "E&ditar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 3
        Me.cmdDeshacer.Text = "Des&hacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 2
        Me.cmdGuardar.Text = "&Guardar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "&Eliminar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 4
        Me.cmdSalir.Text = "&Salir"
        '
        'GpBoxAgrega
        '
        Me.GpBoxAgrega.Controls.Add(Me.GroupBox2)
        Me.GpBoxAgrega.Controls.Add(Me.Label1)
        Me.GpBoxAgrega.Controls.Add(Me.TxtDescripcion)
        Me.GpBoxAgrega.Location = New System.Drawing.Point(8, 8)
        Me.GpBoxAgrega.Name = "GpBoxAgrega"
        Me.GpBoxAgrega.Size = New System.Drawing.Size(392, 176)
        Me.GpBoxAgrega.TabIndex = 48
        Me.GpBoxAgrega.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ChkComTecGuar)
        Me.GroupBox2.Controls.Add(Me.ChkComiteGuar)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(120, 72)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(168, 96)
        Me.GroupBox2.TabIndex = 61
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Representa en:"
        '
        'ChkComTecGuar
        '
        Me.ChkComTecGuar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkComTecGuar.Location = New System.Drawing.Point(40, 56)
        Me.ChkComTecGuar.Name = "ChkComTecGuar"
        Me.ChkComTecGuar.TabIndex = 58
        Me.ChkComTecGuar.Text = "Comite Tecnico"
        '
        'ChkComiteGuar
        '
        Me.ChkComiteGuar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkComiteGuar.Location = New System.Drawing.Point(40, 24)
        Me.ChkComiteGuar.Name = "ChkComiteGuar"
        Me.ChkComiteGuar.TabIndex = 57
        Me.ChkComiteGuar.Text = "Comite"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 23)
        Me.Label1.TabIndex = 51
        Me.Label1.Text = "Descripci�n:"
        '
        'TxtDescripcion
        '
        Me.TxtDescripcion.Location = New System.Drawing.Point(104, 40)
        Me.TxtDescripcion.MaxLength = 50
        Me.TxtDescripcion.Name = "TxtDescripcion"
        Me.TxtDescripcion.Size = New System.Drawing.Size(264, 20)
        Me.TxtDescripcion.TabIndex = 52
        Me.TxtDescripcion.Text = ""
        '
        'GpBoxLectura
        '
        Me.GpBoxLectura.Controls.Add(Me.CmbRepresentacion)
        Me.GpBoxLectura.Controls.Add(Me.Label2)
        Me.GpBoxLectura.Controls.Add(Me.GroupBox3)
        Me.GpBoxLectura.Location = New System.Drawing.Point(8, 8)
        Me.GpBoxLectura.Name = "GpBoxLectura"
        Me.GpBoxLectura.Size = New System.Drawing.Size(392, 176)
        Me.GpBoxLectura.TabIndex = 61
        Me.GpBoxLectura.TabStop = False
        '
        'CmbRepresentacion
        '
        Me.CmbRepresentacion.Location = New System.Drawing.Point(104, 40)
        Me.CmbRepresentacion.Name = "CmbRepresentacion"
        Me.CmbRepresentacion.Size = New System.Drawing.Size(264, 22)
        Me.CmbRepresentacion.TabIndex = 64
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 23)
        Me.Label2.TabIndex = 63
        Me.Label2.Text = "Descripci�n:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ChkComteclect)
        Me.GroupBox3.Controls.Add(Me.ChkComitelect)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(120, 72)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(168, 96)
        Me.GroupBox3.TabIndex = 62
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Representa en:"
        '
        'ChkComteclect
        '
        Me.ChkComteclect.Enabled = False
        Me.ChkComteclect.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkComteclect.Location = New System.Drawing.Point(40, 56)
        Me.ChkComteclect.Name = "ChkComteclect"
        Me.ChkComteclect.TabIndex = 58
        Me.ChkComteclect.Text = "Comite Tecnico"
        '
        'ChkComitelect
        '
        Me.ChkComitelect.Enabled = False
        Me.ChkComitelect.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkComitelect.Location = New System.Drawing.Point(40, 24)
        Me.ChkComitelect.Name = "ChkComitelect"
        Me.ChkComitelect.TabIndex = 57
        Me.ChkComitelect.Text = "Comite"
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(16, 192)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 21)
        Me.lblStatus.TabIndex = 62
        '
        'FrmRepresentacion
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(414, 291)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.GpBoxLectura)
        Me.Controls.Add(Me.GpBoxAgrega)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmRepresentacion"
        Me.Text = "Representaci�n"
        Me.GpBoxAgrega.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GpBoxLectura.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Metodos y Procesos"

    Private Sub Habilita(ByVal Etapa As String)
        With tlbBotonera
            Select Case Etapa
                Case "Nulo"
                    Activos(.Buttons(1), .Buttons(2))
                    Inactivos(.Buttons(3), .Buttons(4), TxtDescripcion)

                Case "Agregar"
                    Inactivos(.Buttons(1), .Buttons(2), .Buttons(4))
                    Activos(.Buttons(3), TxtDescripcion)
            End Select
        End With
    End Sub

    Private Sub Guardar()
        Dim iregistros As Integer
        If ChkComiteGuar.CheckState = CheckState.Checked Then objrepresentacion.Comite = 1 Else objrepresentacion.Comite = 0
        If ChkComTecGuar.CheckState = CheckState.Checked Then objrepresentacion.CT = 1 Else objrepresentacion.CT = 0
        objrepresentacion.Descripcion = Trim(TxtDescripcion.Text)
        If iEditar = 1 Then
            If Len(ValEditar) > 0 Then
                objrepresentacion.ID_Representacion = ValEditar
                objrepresentacion.Bandera = 2
                objrepresentacion.Actualizar()
            End If
        Else
            objrepresentacion.Bandera = 1
            objrepresentacion.Insertar()
        End If
    End Sub

    Private Function valida(ByVal casos As String)
        Select Case casos
            Case "desc"
                If TxtDescripcion.Text = "" Then
                    ErrorProvider1.SetError(TxtDescripcion, "Debes escribir la Descripcion de tu representaci�n")
                    Return "Error"
                Else
                    ErrorProvider1.SetError(TxtDescripcion, "")
                    Return "Ok"
                End If
            Case "chk"
                If ChkComiteGuar.CheckState = CheckState.Unchecked And ChkComTecGuar.CheckState = CheckState.Unchecked Then
                    ErrorProvider1.SetError(ChkComiteGuar, "Debes de marcar una de las dos  opciones, por lo menos")
                    ErrorProvider1.SetError(ChkComTecGuar, "Debes de marcar una de las dos  opciones, por lo menos")
                    Return "Error"
                Else
                    ErrorProvider1.SetError(ChkComiteGuar, "")
                    ErrorProvider1.SetError(ChkComTecGuar, "")
                    Return "Ok"
                End If
        End Select
    End Function

    Private Sub Eliminar()
        Dim iregistros As Integer
        If Len(ValEditar) > 0 Then
            objrepresentacion.ID_Representacion = ValEditar
            objrepresentacion.Bandera = 3
            objrepresentacion.borra()
        End If

    End Sub
#End Region

#Region " ToolBar - tlbBotonera, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Cursor.Current = Cursors.WaitCursor
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1
                sStatus = "Carga"
                Habilita("Agregar")
                TxtDescripcion.Text = ""
                ChkComiteGuar.Checked = False
                ChkComTecGuar.Checked = False
                Muestra(GpBoxAgrega)
                Oculta(GpBoxLectura)
                iEditar = 0
                sStatus = ""
            Case 2
                sStatus = "Carga"
                If CmbRepresentacion.SelectedValue <> 0 And CmbRepresentacion.SelectedValue <> Nothing Then
                    Habilita("Agregar")
                    ValEditar = CmbRepresentacion.SelectedValue
                    TxtDescripcion.Text = CmbRepresentacion.SelectedText
                    If objrepresentacion.Comite = True Then ChkComiteGuar.Checked = True Else ChkComiteGuar.Checked = False
                    If objrepresentacion.CT = True Then ChkComTecGuar.Checked = True Else ChkComTecGuar.Checked = False
                    Muestra(GpBoxAgrega)
                    Oculta(GpBoxLectura)
                    iEditar = 1
                End If
                sStatus = ""
            Case 3
                Habilita("Nulo")
                Oculta(GpBoxAgrega)
                Muestra(GpBoxLectura)
                iEditar = 0
                CmbRepresentacion.SelectedValue = 0
                TxtDescripcion.Text = ""
            Case 4
                If valida("desc") = "Ok" And valida("chk") = "Ok" Then
                    Call Guardar()
                    Habilita("Nulo")
                    Oculta(GpBoxAgrega)
                    Muestra(GpBoxLectura)
                    iEditar = 0
                    CmbRepresentacion.SelectedValue = 0
                    TxtDescripcion.Text = ""
                    Call Carga_Combo()
                End If
            Case 5
                If iEditar = 0 Then ValEditar = CmbRepresentacion.SelectedValue
                'ErrorProvider1.SetError(Me.CmbRepresentacion, "Estas a punto de eliminar esta representaci�n")
                If MsgBox("�Estas seguro que deseas eliminar este Sector?", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
                    Habilita("Nulo")
                    Call Eliminar()
                    TxtDescripcion.Text = ""
                    Oculta(GpBoxAgrega)
                    Muestra(GpBoxLectura)
                    iEditar = 0
                    Call Carga_Combo()
                Else
                    'ErrorProvider1.SetError(Me.CmbRepresentacion, "Estabas a punto de eliminar esta representaci�n")
                End If
            Case 7
                iEditar = 0
                Me.Close()
        End Select
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "Forms - FrmRepresentacion, Metodos y Procesos"

    Private Sub FrmRepresentacion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        sStatus = "Carga"
        Call Habilita("Nulo")
        GpBoxAgrega.Visible = False
        GpBoxLectura.Visible = True

        Call Carga_Combo()
        TxtDescripcion.CausesValidation = True
        sStatus = ""

    End Sub

#End Region

#Region " ComboBox - CmbRepresentacion, Metodos y Procesos"

    Private Sub CmbRepresentacion_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbRepresentacion.SelectedIndexChanged
        Dim comite, ct As Boolean
        If sStatus <> "Carga" Then
            objrepresentacion.ID_Representacion = CmbRepresentacion.SelectedValue
            objrepresentacion.Bandera = 2
            objrepresentacion.Buscar()
            If objrepresentacion.Comite = True Then ChkComitelect.Checked = True Else ChkComitelect.Checked = False
            If objrepresentacion.CT = True Then ChkComteclect.Checked = True Else ChkComteclect.Checked = False
            If objrepresentacion.Inactivo = 1 Then
                lblStatus.Text = "Inactivo"
            Else
                lblStatus.Text = "Activo"
            End If
        End If
    End Sub

    Private Sub Carga_Combo()
        objrepresentacion.Bandera = 1
        objrepresentacion.ListaCombo(CmbRepresentacion)
    End Sub

#End Region

#Region "TextBox - TxtDescripcion, Metodos y Procesos"

    Private Sub TxtDescripcion_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtDescripcion.Validating
        If sStatus = "" Then
            If valida("desc") <> "Ok" Then
                TxtDescripcion.Focus()
                Inactivos(tlbBotonera.Buttons(4))
            Else
                Activos(tlbBotonera.Buttons(4))
            End If
        End If

    End Sub

#End Region

#Region "CheckBox, Metodos y Procesos"

#Region "CheckBox - ChkComiteGuar, Metodos y Procesos"
    Private Sub ChkComiteGuar_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ChkComiteGuar.CheckedChanged
        If valida("chk") <> "Ok" Then
            ChkComiteGuar.Focus()
        Else
            Activos(tlbBotonera.Buttons(4))
        End If
    End Sub

#End Region

#Region "CheckBox - ChkComTecGuar, Metodos y Procesos"

    Private Sub ChkComTecGuar_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ChkComTecGuar.CheckedChanged
        If valida("chk") <> "Ok" Then
            ChkComTecGuar.Focus()
        Else
            Activos(tlbBotonera.Buttons(4))
        End If
    End Sub

#End Region

#End Region


End Class
