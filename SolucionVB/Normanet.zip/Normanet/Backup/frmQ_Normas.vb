Imports System.Windows.Forms
Imports System.Data.SqlClient
Public Class frmQ_Normas
    Inherits System.Windows.Forms.Form
    Dim sTipoProceso As String
    Dim objNormas As New clsCatalogoNormas.C_Normas(0, gUsuario, gPasswordSql)
    Dim dvComite As DataView
    Dim objComites As New clsComites.clsComites(0, gUsuario, gPasswordSql)
    Dim objEmpleados As New cls_empleados.Cls_empleados("Comun", gUsuario, gPasswordSql)
    Dim ObjFechasAvance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Dim iCaso As Integer
    Dim cn As New SqlConnection
    Dim Id_Plan As String
    Dim Id_Tema As String

    Dim sqlNormas As String
    Dim sqlNormasAdoptadas As String
    Dim sqlNormaClasificacion As String
    Dim sqlProyecto As String
    Dim sqlAnteproyecto As String
    Dim sqlDT As String
    Dim objConexion As New clsConexionArchivo.clsConexionArchivo
    Dim objQ_Normas As New clsQ_Normas.clsQ_Normas(0, gUsuario, gPasswordSql)
    Dim objConexion2 As New clsConexion.cIsConexion
    Dim valreturn As Boolean = True
    Private dt_Excel As New DataTable





#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tvNormas As System.Windows.Forms.TreeView
    Friend WithEvents tclNormas As System.Windows.Forms.TabControl
    Friend WithEvents tpgNorma As System.Windows.Forms.TabPage
    Friend WithEvents gpbDeclaratoria As System.Windows.Forms.GroupBox
    Friend WithEvents chkFecDeclaracion As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelVigencia As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelVigencia As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlVigencia As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlVigencia As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDel As System.Windows.Forms.Label
    Friend WithEvents lblAl As System.Windows.Forms.Label
    Friend WithEvents gpbDGN As System.Windows.Forms.GroupBox
    Friend WithEvents chkFec_Envio_DGN As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelDGN As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelDGN As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlDGN As System.Windows.Forms.TextBox
    Friend WithEvents optNuevas As System.Windows.Forms.RadioButton
    Friend WithEvents tpgProy As System.Windows.Forms.TabPage
    Friend WithEvents tpgAnt As System.Windows.Forms.TabPage
    Friend WithEvents tpgDT As System.Windows.Forms.TabPage
    Friend WithEvents gpbNormasAnce As System.Windows.Forms.GroupBox
    Friend WithEvents chkNMXNuevas As System.Windows.Forms.CheckBox
    Friend WithEvents gpbQuinquenal As System.Windows.Forms.GroupBox
    Friend WithEvents chkQuinquenal As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelQuinquenal As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelQuinquenal As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlQuinquenal As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlQuinquenal As System.Windows.Forms.DateTimePicker
    Friend WithEvents gpbRatificacion As System.Windows.Forms.GroupBox
    Friend WithEvents chkRatificacion As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelRatificacion As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelRatificacion As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlRatificacion As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlRatificacion As System.Windows.Forms.DateTimePicker
    Friend WithEvents gpbResponsable As System.Windows.Forms.GroupBox
    Friend WithEvents chkResponsable As System.Windows.Forms.CheckBox
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents txtResponsable As System.Windows.Forms.TextBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents gpbProyenComentarios As System.Windows.Forms.GroupBox
    Friend WithEvents chkProyenComentarios As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelProyenComentarios As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelProyenComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlProyenComentarios As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlProyenComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents gpbProyFinales As System.Windows.Forms.GroupBox
    Friend WithEvents chkProyFinales As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelProyFinales As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelProyFinales As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlProyFinales As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlProyFinales As System.Windows.Forms.DateTimePicker
    Friend WithEvents gpbProyConComentarios As System.Windows.Forms.GroupBox
    Friend WithEvents chkProyConComentarios As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelProyConComentarios As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelProyConComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlProyConComentarios As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlProyConComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents gbbDOF As System.Windows.Forms.GroupBox
    Friend WithEvents chkDOF As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelDOF As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelDOF As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlDOF As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlDOF As System.Windows.Forms.DateTimePicker
    Friend WithEvents gpbProyAprobados As System.Windows.Forms.GroupBox
    Friend WithEvents chkProyAprobados As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelProyAprobados As System.Windows.Forms.TextBox
    Friend WithEvents txtAlProyAprobados As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlProyAprobados As System.Windows.Forms.DateTimePicker
    Friend WithEvents gpbResponsableProy As System.Windows.Forms.GroupBox
    Friend WithEvents txtResponsableProy As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsableProy As System.Windows.Forms.ComboBox
    Friend WithEvents chkResponsableProy As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents gpbClasificacionAnt As System.Windows.Forms.GroupBox
    Friend WithEvents txtClasificacionAnt As System.Windows.Forms.TextBox
    Friend WithEvents cboClasificacionAnt As System.Windows.Forms.ComboBox
    Friend WithEvents chkClasificacionAnt As System.Windows.Forms.CheckBox
    Friend WithEvents gpbResponsableAnt As System.Windows.Forms.GroupBox
    Friend WithEvents txtResponsableAnt As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsableAnt As System.Windows.Forms.ComboBox
    Friend WithEvents chkResponsableAnt As System.Windows.Forms.CheckBox
    Friend WithEvents gpbResponsableDT As System.Windows.Forms.GroupBox
    Friend WithEvents txtResponsableDT As System.Windows.Forms.TextBox
    Friend WithEvents cboResponsableDT As System.Windows.Forms.ComboBox
    Friend WithEvents chkResponsableDT As System.Windows.Forms.CheckBox
    Friend WithEvents gpbPeriodoDT As System.Windows.Forms.GroupBox
    Friend WithEvents chkPeriodoDT As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelPeriodoDT As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelPeriodoDT As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkAlPeriodoDT As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents optAdoptadas As System.Windows.Forms.RadioButton
    Friend WithEvents optArmonizadas As System.Windows.Forms.RadioButton
    Friend WithEvents optReferidasNom As System.Windows.Forms.RadioButton
    Friend WithEvents optReferidasNRF As System.Windows.Forms.RadioButton
    Friend WithEvents optReferidasNMX As System.Windows.Forms.RadioButton
    Friend WithEvents optConcordanciaInternacional As System.Windows.Forms.RadioButton
    Friend WithEvents txtId_Tema As System.Windows.Forms.TextBox
    Friend WithEvents txtId_Plan As System.Windows.Forms.TextBox
    Friend WithEvents txtGT As System.Windows.Forms.TextBox
    Friend WithEvents txtSC As System.Windows.Forms.TextBox
    Friend WithEvents txtCT As System.Windows.Forms.TextBox
    Friend WithEvents txtComite As System.Windows.Forms.TextBox
    Friend WithEvents lblSB As System.Windows.Forms.Label
    Friend WithEvents chkAdoptadas As System.Windows.Forms.CheckBox
    Friend WithEvents gpbAdoptadas As System.Windows.Forms.GroupBox
    Friend WithEvents optModificadas As System.Windows.Forms.RadioButton
    Friend WithEvents grdNormas As System.Windows.Forms.DataGrid
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents chkRemitidasDGN As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelRemitidasDGN As System.Windows.Forms.TextBox
    Friend WithEvents dtkDelRemitidasDGN As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAlRemitidasDGN As System.Windows.Forms.TextBox
    Friend WithEvents dtkAlRemitidasDGN As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkAlDGN As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkdelProyAprobados As System.Windows.Forms.DateTimePicker
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents txtAlPeriodoDT As System.Windows.Forms.TextBox
    Friend WithEvents cmdExportar As System.Windows.Forms.ToolBarButton
    Friend WithEvents grdNormasAdoptadas As System.Windows.Forms.DataGrid
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmQ_Normas))
        Me.tvNormas = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.tclNormas = New System.Windows.Forms.TabControl
        Me.tpgNorma = New System.Windows.Forms.TabPage
        Me.gpbDeclaratoria = New System.Windows.Forms.GroupBox
        Me.chkFecDeclaracion = New System.Windows.Forms.CheckBox
        Me.txtDelVigencia = New System.Windows.Forms.TextBox
        Me.dtkDelVigencia = New System.Windows.Forms.DateTimePicker
        Me.txtAlVigencia = New System.Windows.Forms.TextBox
        Me.dtkAlVigencia = New System.Windows.Forms.DateTimePicker
        Me.lblDel = New System.Windows.Forms.Label
        Me.lblAl = New System.Windows.Forms.Label
        Me.gpbDGN = New System.Windows.Forms.GroupBox
        Me.chkFec_Envio_DGN = New System.Windows.Forms.CheckBox
        Me.txtDelDGN = New System.Windows.Forms.TextBox
        Me.dtkDelDGN = New System.Windows.Forms.DateTimePicker
        Me.txtAlDGN = New System.Windows.Forms.TextBox
        Me.dtkAlDGN = New System.Windows.Forms.DateTimePicker
        Me.gpbNormasAnce = New System.Windows.Forms.GroupBox
        Me.optModificadas = New System.Windows.Forms.RadioButton
        Me.optNuevas = New System.Windows.Forms.RadioButton
        Me.chkNMXNuevas = New System.Windows.Forms.CheckBox
        Me.gpbAdoptadas = New System.Windows.Forms.GroupBox
        Me.optAdoptadas = New System.Windows.Forms.RadioButton
        Me.chkAdoptadas = New System.Windows.Forms.CheckBox
        Me.optArmonizadas = New System.Windows.Forms.RadioButton
        Me.optReferidasNom = New System.Windows.Forms.RadioButton
        Me.optReferidasNRF = New System.Windows.Forms.RadioButton
        Me.optReferidasNMX = New System.Windows.Forms.RadioButton
        Me.optConcordanciaInternacional = New System.Windows.Forms.RadioButton
        Me.gpbQuinquenal = New System.Windows.Forms.GroupBox
        Me.chkQuinquenal = New System.Windows.Forms.CheckBox
        Me.txtDelQuinquenal = New System.Windows.Forms.TextBox
        Me.dtkDelQuinquenal = New System.Windows.Forms.DateTimePicker
        Me.txtAlQuinquenal = New System.Windows.Forms.TextBox
        Me.dtkAlQuinquenal = New System.Windows.Forms.DateTimePicker
        Me.gpbRatificacion = New System.Windows.Forms.GroupBox
        Me.chkRatificacion = New System.Windows.Forms.CheckBox
        Me.txtDelRatificacion = New System.Windows.Forms.TextBox
        Me.dtkDelRatificacion = New System.Windows.Forms.DateTimePicker
        Me.txtAlRatificacion = New System.Windows.Forms.TextBox
        Me.dtkAlRatificacion = New System.Windows.Forms.DateTimePicker
        Me.gpbResponsable = New System.Windows.Forms.GroupBox
        Me.txtResponsable = New System.Windows.Forms.TextBox
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.chkResponsable = New System.Windows.Forms.CheckBox
        Me.tpgProy = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chkRemitidasDGN = New System.Windows.Forms.CheckBox
        Me.txtDelRemitidasDGN = New System.Windows.Forms.TextBox
        Me.dtkDelRemitidasDGN = New System.Windows.Forms.DateTimePicker
        Me.txtAlRemitidasDGN = New System.Windows.Forms.TextBox
        Me.dtkAlRemitidasDGN = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.gpbProyenComentarios = New System.Windows.Forms.GroupBox
        Me.chkProyenComentarios = New System.Windows.Forms.CheckBox
        Me.txtDelProyenComentarios = New System.Windows.Forms.TextBox
        Me.dtkDelProyenComentarios = New System.Windows.Forms.DateTimePicker
        Me.txtAlProyenComentarios = New System.Windows.Forms.TextBox
        Me.dtkAlProyenComentarios = New System.Windows.Forms.DateTimePicker
        Me.gpbProyFinales = New System.Windows.Forms.GroupBox
        Me.chkProyFinales = New System.Windows.Forms.CheckBox
        Me.txtDelProyFinales = New System.Windows.Forms.TextBox
        Me.dtkDelProyFinales = New System.Windows.Forms.DateTimePicker
        Me.txtAlProyFinales = New System.Windows.Forms.TextBox
        Me.dtkAlProyFinales = New System.Windows.Forms.DateTimePicker
        Me.gpbProyConComentarios = New System.Windows.Forms.GroupBox
        Me.chkProyConComentarios = New System.Windows.Forms.CheckBox
        Me.txtDelProyConComentarios = New System.Windows.Forms.TextBox
        Me.dtkDelProyConComentarios = New System.Windows.Forms.DateTimePicker
        Me.txtAlProyConComentarios = New System.Windows.Forms.TextBox
        Me.dtkAlProyConComentarios = New System.Windows.Forms.DateTimePicker
        Me.gbbDOF = New System.Windows.Forms.GroupBox
        Me.chkDOF = New System.Windows.Forms.CheckBox
        Me.txtDelDOF = New System.Windows.Forms.TextBox
        Me.dtkDelDOF = New System.Windows.Forms.DateTimePicker
        Me.txtAlDOF = New System.Windows.Forms.TextBox
        Me.dtkAlDOF = New System.Windows.Forms.DateTimePicker
        Me.gpbProyAprobados = New System.Windows.Forms.GroupBox
        Me.chkProyAprobados = New System.Windows.Forms.CheckBox
        Me.txtDelProyAprobados = New System.Windows.Forms.TextBox
        Me.dtkdelProyAprobados = New System.Windows.Forms.DateTimePicker
        Me.txtAlProyAprobados = New System.Windows.Forms.TextBox
        Me.dtkAlProyAprobados = New System.Windows.Forms.DateTimePicker
        Me.gpbResponsableProy = New System.Windows.Forms.GroupBox
        Me.txtResponsableProy = New System.Windows.Forms.TextBox
        Me.cboResponsableProy = New System.Windows.Forms.ComboBox
        Me.chkResponsableProy = New System.Windows.Forms.CheckBox
        Me.tpgAnt = New System.Windows.Forms.TabPage
        Me.gpbClasificacionAnt = New System.Windows.Forms.GroupBox
        Me.txtClasificacionAnt = New System.Windows.Forms.TextBox
        Me.cboClasificacionAnt = New System.Windows.Forms.ComboBox
        Me.chkClasificacionAnt = New System.Windows.Forms.CheckBox
        Me.gpbResponsableAnt = New System.Windows.Forms.GroupBox
        Me.txtResponsableAnt = New System.Windows.Forms.TextBox
        Me.cboResponsableAnt = New System.Windows.Forms.ComboBox
        Me.chkResponsableAnt = New System.Windows.Forms.CheckBox
        Me.tpgDT = New System.Windows.Forms.TabPage
        Me.gpbResponsableDT = New System.Windows.Forms.GroupBox
        Me.txtResponsableDT = New System.Windows.Forms.TextBox
        Me.cboResponsableDT = New System.Windows.Forms.ComboBox
        Me.chkResponsableDT = New System.Windows.Forms.CheckBox
        Me.gpbPeriodoDT = New System.Windows.Forms.GroupBox
        Me.chkPeriodoDT = New System.Windows.Forms.CheckBox
        Me.txtDelPeriodoDT = New System.Windows.Forms.TextBox
        Me.dtkDelPeriodoDT = New System.Windows.Forms.DateTimePicker
        Me.txtAlPeriodoDT = New System.Windows.Forms.TextBox
        Me.dtkAlPeriodoDT = New System.Windows.Forms.DateTimePicker
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.grdNormas = New System.Windows.Forms.DataGrid
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.txtId_Tema = New System.Windows.Forms.TextBox
        Me.txtId_Plan = New System.Windows.Forms.TextBox
        Me.txtGT = New System.Windows.Forms.TextBox
        Me.txtSC = New System.Windows.Forms.TextBox
        Me.txtCT = New System.Windows.Forms.TextBox
        Me.txtComite = New System.Windows.Forms.TextBox
        Me.lblSB = New System.Windows.Forms.Label
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdExportar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.grdNormasAdoptadas = New System.Windows.Forms.DataGrid
        Me.lblTotal = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.tclNormas.SuspendLayout()
        Me.tpgNorma.SuspendLayout()
        Me.gpbDeclaratoria.SuspendLayout()
        Me.gpbDGN.SuspendLayout()
        Me.gpbNormasAnce.SuspendLayout()
        Me.gpbAdoptadas.SuspendLayout()
        Me.gpbQuinquenal.SuspendLayout()
        Me.gpbRatificacion.SuspendLayout()
        Me.gpbResponsable.SuspendLayout()
        Me.tpgProy.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gpbProyenComentarios.SuspendLayout()
        Me.gpbProyFinales.SuspendLayout()
        Me.gpbProyConComentarios.SuspendLayout()
        Me.gbbDOF.SuspendLayout()
        Me.gpbProyAprobados.SuspendLayout()
        Me.gpbResponsableProy.SuspendLayout()
        Me.tpgAnt.SuspendLayout()
        Me.gpbClasificacionAnt.SuspendLayout()
        Me.gpbResponsableAnt.SuspendLayout()
        Me.tpgDT.SuspendLayout()
        Me.gpbResponsableDT.SuspendLayout()
        Me.gpbPeriodoDT.SuspendLayout()
        CType(Me.grdNormas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdNormasAdoptadas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tvNormas
        '
        Me.tvNormas.ImageList = Me.imgListTreeView
        Me.tvNormas.Location = New System.Drawing.Point(8, 4)
        Me.tvNormas.Name = "tvNormas"
        Me.tvNormas.Size = New System.Drawing.Size(240, 380)
        Me.tvNormas.TabIndex = 3
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'tclNormas
        '
        Me.tclNormas.Controls.Add(Me.tpgNorma)
        Me.tclNormas.Controls.Add(Me.tpgProy)
        Me.tclNormas.Controls.Add(Me.tpgAnt)
        Me.tclNormas.Controls.Add(Me.tpgDT)
        Me.tclNormas.Location = New System.Drawing.Point(256, 4)
        Me.tclNormas.Name = "tclNormas"
        Me.tclNormas.SelectedIndex = 0
        Me.tclNormas.Size = New System.Drawing.Size(472, 400)
        Me.tclNormas.TabIndex = 2
        '
        'tpgNorma
        '
        Me.tpgNorma.Controls.Add(Me.gpbDeclaratoria)
        Me.tpgNorma.Controls.Add(Me.lblDel)
        Me.tpgNorma.Controls.Add(Me.lblAl)
        Me.tpgNorma.Controls.Add(Me.gpbDGN)
        Me.tpgNorma.Controls.Add(Me.gpbNormasAnce)
        Me.tpgNorma.Controls.Add(Me.gpbAdoptadas)
        Me.tpgNorma.Controls.Add(Me.gpbQuinquenal)
        Me.tpgNorma.Controls.Add(Me.gpbRatificacion)
        Me.tpgNorma.Controls.Add(Me.gpbResponsable)
        Me.tpgNorma.Location = New System.Drawing.Point(4, 22)
        Me.tpgNorma.Name = "tpgNorma"
        Me.tpgNorma.Size = New System.Drawing.Size(464, 374)
        Me.tpgNorma.TabIndex = 0
        Me.tpgNorma.Text = "Normas             "
        '
        'gpbDeclaratoria
        '
        Me.gpbDeclaratoria.Controls.Add(Me.chkFecDeclaracion)
        Me.gpbDeclaratoria.Controls.Add(Me.txtDelVigencia)
        Me.gpbDeclaratoria.Controls.Add(Me.dtkDelVigencia)
        Me.gpbDeclaratoria.Controls.Add(Me.txtAlVigencia)
        Me.gpbDeclaratoria.Controls.Add(Me.dtkAlVigencia)
        Me.gpbDeclaratoria.Location = New System.Drawing.Point(13, 20)
        Me.gpbDeclaratoria.Name = "gpbDeclaratoria"
        Me.gpbDeclaratoria.Size = New System.Drawing.Size(440, 38)
        Me.gpbDeclaratoria.TabIndex = 1
        Me.gpbDeclaratoria.TabStop = False
        '
        'chkFecDeclaracion
        '
        Me.chkFecDeclaracion.Location = New System.Drawing.Point(8, 11)
        Me.chkFecDeclaracion.Name = "chkFecDeclaracion"
        Me.chkFecDeclaracion.Size = New System.Drawing.Size(127, 18)
        Me.chkFecDeclaracion.TabIndex = 31
        Me.chkFecDeclaracion.Text = "Fec_Decla_Vigencia"
        '
        'txtDelVigencia
        '
        Me.txtDelVigencia.Location = New System.Drawing.Point(224, 11)
        Me.txtDelVigencia.Name = "txtDelVigencia"
        Me.txtDelVigencia.Size = New System.Drawing.Size(80, 20)
        Me.txtDelVigencia.TabIndex = 29
        Me.txtDelVigencia.Text = ""
        '
        'dtkDelVigencia
        '
        Me.dtkDelVigencia.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelVigencia.Location = New System.Drawing.Point(224, 11)
        Me.dtkDelVigencia.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelVigencia.Name = "dtkDelVigencia"
        Me.dtkDelVigencia.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelVigencia.TabIndex = 30
        Me.dtkDelVigencia.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlVigencia
        '
        Me.txtAlVigencia.Location = New System.Drawing.Point(336, 11)
        Me.txtAlVigencia.Name = "txtAlVigencia"
        Me.txtAlVigencia.Size = New System.Drawing.Size(80, 20)
        Me.txtAlVigencia.TabIndex = 29
        Me.txtAlVigencia.Text = ""
        '
        'dtkAlVigencia
        '
        Me.dtkAlVigencia.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlVigencia.Location = New System.Drawing.Point(336, 11)
        Me.dtkAlVigencia.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlVigencia.Name = "dtkAlVigencia"
        Me.dtkAlVigencia.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlVigencia.TabIndex = 30
        Me.dtkAlVigencia.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'lblDel
        '
        Me.lblDel.AutoSize = True
        Me.lblDel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDel.Location = New System.Drawing.Point(248, 8)
        Me.lblDel.Name = "lblDel"
        Me.lblDel.Size = New System.Drawing.Size(73, 16)
        Me.lblDel.TabIndex = 31
        Me.lblDel.Text = "Periodo del: "
        '
        'lblAl
        '
        Me.lblAl.AutoSize = True
        Me.lblAl.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAl.Location = New System.Drawing.Point(368, 8)
        Me.lblAl.Name = "lblAl"
        Me.lblAl.Size = New System.Drawing.Size(66, 16)
        Me.lblAl.TabIndex = 31
        Me.lblAl.Text = "Periodo al: "
        '
        'gpbDGN
        '
        Me.gpbDGN.Controls.Add(Me.chkFec_Envio_DGN)
        Me.gpbDGN.Controls.Add(Me.txtDelDGN)
        Me.gpbDGN.Controls.Add(Me.dtkDelDGN)
        Me.gpbDGN.Controls.Add(Me.txtAlDGN)
        Me.gpbDGN.Controls.Add(Me.dtkAlDGN)
        Me.gpbDGN.Location = New System.Drawing.Point(13, 58)
        Me.gpbDGN.Name = "gpbDGN"
        Me.gpbDGN.Size = New System.Drawing.Size(440, 38)
        Me.gpbDGN.TabIndex = 1
        Me.gpbDGN.TabStop = False
        '
        'chkFec_Envio_DGN
        '
        Me.chkFec_Envio_DGN.Location = New System.Drawing.Point(8, 10)
        Me.chkFec_Envio_DGN.Name = "chkFec_Envio_DGN"
        Me.chkFec_Envio_DGN.Size = New System.Drawing.Size(109, 18)
        Me.chkFec_Envio_DGN.TabIndex = 31
        Me.chkFec_Envio_DGN.Text = "Fec_Envio_DGN"
        '
        'txtDelDGN
        '
        Me.txtDelDGN.Location = New System.Drawing.Point(223, 10)
        Me.txtDelDGN.Name = "txtDelDGN"
        Me.txtDelDGN.Size = New System.Drawing.Size(80, 20)
        Me.txtDelDGN.TabIndex = 29
        Me.txtDelDGN.Text = ""
        '
        'dtkDelDGN
        '
        Me.dtkDelDGN.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelDGN.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelDGN.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelDGN.Name = "dtkDelDGN"
        Me.dtkDelDGN.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelDGN.TabIndex = 30
        Me.dtkDelDGN.Value = New Date(2007, 1, 2, 0, 0, 0, 0)
        '
        'txtAlDGN
        '
        Me.txtAlDGN.Location = New System.Drawing.Point(336, 10)
        Me.txtAlDGN.Name = "txtAlDGN"
        Me.txtAlDGN.Size = New System.Drawing.Size(80, 20)
        Me.txtAlDGN.TabIndex = 29
        Me.txtAlDGN.Text = ""
        '
        'dtkAlDGN
        '
        Me.dtkAlDGN.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlDGN.Location = New System.Drawing.Point(337, 10)
        Me.dtkAlDGN.Name = "dtkAlDGN"
        Me.dtkAlDGN.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlDGN.TabIndex = 107
        Me.dtkAlDGN.Value = New Date(2007, 1, 2, 0, 0, 0, 0)
        '
        'gpbNormasAnce
        '
        Me.gpbNormasAnce.Controls.Add(Me.optModificadas)
        Me.gpbNormasAnce.Controls.Add(Me.optNuevas)
        Me.gpbNormasAnce.Controls.Add(Me.chkNMXNuevas)
        Me.gpbNormasAnce.Location = New System.Drawing.Point(13, 96)
        Me.gpbNormasAnce.Name = "gpbNormasAnce"
        Me.gpbNormasAnce.Size = New System.Drawing.Size(440, 40)
        Me.gpbNormasAnce.TabIndex = 1
        Me.gpbNormasAnce.TabStop = False
        '
        'optModificadas
        '
        Me.optModificadas.Location = New System.Drawing.Point(337, 12)
        Me.optModificadas.Name = "optModificadas"
        Me.optModificadas.Size = New System.Drawing.Size(83, 18)
        Me.optModificadas.TabIndex = 33
        Me.optModificadas.Text = "Modificadas"
        '
        'optNuevas
        '
        Me.optNuevas.Location = New System.Drawing.Point(224, 13)
        Me.optNuevas.Name = "optNuevas"
        Me.optNuevas.Size = New System.Drawing.Size(61, 16)
        Me.optNuevas.TabIndex = 32
        Me.optNuevas.Text = "Nuevas"
        '
        'chkNMXNuevas
        '
        Me.chkNMXNuevas.Location = New System.Drawing.Point(10, 11)
        Me.chkNMXNuevas.Name = "chkNMXNuevas"
        Me.chkNMXNuevas.Size = New System.Drawing.Size(133, 20)
        Me.chkNMXNuevas.TabIndex = 31
        Me.chkNMXNuevas.Text = "Normas NMX - ANCE"
        '
        'gpbAdoptadas
        '
        Me.gpbAdoptadas.Controls.Add(Me.optAdoptadas)
        Me.gpbAdoptadas.Controls.Add(Me.chkAdoptadas)
        Me.gpbAdoptadas.Controls.Add(Me.optArmonizadas)
        Me.gpbAdoptadas.Controls.Add(Me.optReferidasNom)
        Me.gpbAdoptadas.Controls.Add(Me.optReferidasNRF)
        Me.gpbAdoptadas.Controls.Add(Me.optReferidasNMX)
        Me.gpbAdoptadas.Controls.Add(Me.optConcordanciaInternacional)
        Me.gpbAdoptadas.Location = New System.Drawing.Point(13, 137)
        Me.gpbAdoptadas.Name = "gpbAdoptadas"
        Me.gpbAdoptadas.Size = New System.Drawing.Size(440, 111)
        Me.gpbAdoptadas.TabIndex = 1
        Me.gpbAdoptadas.TabStop = False
        '
        'optAdoptadas
        '
        Me.optAdoptadas.Location = New System.Drawing.Point(64, 40)
        Me.optAdoptadas.Name = "optAdoptadas"
        Me.optAdoptadas.Size = New System.Drawing.Size(88, 20)
        Me.optAdoptadas.TabIndex = 32
        Me.optAdoptadas.Text = "Adoptadas"
        '
        'chkAdoptadas
        '
        Me.chkAdoptadas.Location = New System.Drawing.Point(8, 13)
        Me.chkAdoptadas.Name = "chkAdoptadas"
        Me.chkAdoptadas.Size = New System.Drawing.Size(80, 18)
        Me.chkAdoptadas.TabIndex = 31
        Me.chkAdoptadas.Text = "Adoptadas"
        '
        'optArmonizadas
        '
        Me.optArmonizadas.Location = New System.Drawing.Point(64, 64)
        Me.optArmonizadas.Name = "optArmonizadas"
        Me.optArmonizadas.Size = New System.Drawing.Size(88, 20)
        Me.optArmonizadas.TabIndex = 32
        Me.optArmonizadas.Text = "Armonizadas"
        '
        'optReferidasNom
        '
        Me.optReferidasNom.Location = New System.Drawing.Point(64, 88)
        Me.optReferidasNom.Name = "optReferidasNom"
        Me.optReferidasNom.Size = New System.Drawing.Size(118, 20)
        Me.optReferidasNom.TabIndex = 32
        Me.optReferidasNom.Text = "Referidas en NOM"
        '
        'optReferidasNRF
        '
        Me.optReferidasNRF.Location = New System.Drawing.Point(224, 64)
        Me.optReferidasNRF.Name = "optReferidasNRF"
        Me.optReferidasNRF.Size = New System.Drawing.Size(120, 20)
        Me.optReferidasNRF.TabIndex = 32
        Me.optReferidasNRF.Text = "Referidas en NRF"
        '
        'optReferidasNMX
        '
        Me.optReferidasNMX.Location = New System.Drawing.Point(224, 40)
        Me.optReferidasNMX.Name = "optReferidasNMX"
        Me.optReferidasNMX.Size = New System.Drawing.Size(128, 20)
        Me.optReferidasNMX.TabIndex = 32
        Me.optReferidasNMX.Text = "Referidas en NMX"
        '
        'optConcordanciaInternacional
        '
        Me.optConcordanciaInternacional.Location = New System.Drawing.Point(224, 88)
        Me.optConcordanciaInternacional.Name = "optConcordanciaInternacional"
        Me.optConcordanciaInternacional.Size = New System.Drawing.Size(204, 20)
        Me.optConcordanciaInternacional.TabIndex = 32
        Me.optConcordanciaInternacional.Text = "Concordancia Normas Internacional"
        '
        'gpbQuinquenal
        '
        Me.gpbQuinquenal.Controls.Add(Me.chkQuinquenal)
        Me.gpbQuinquenal.Controls.Add(Me.txtDelQuinquenal)
        Me.gpbQuinquenal.Controls.Add(Me.dtkDelQuinquenal)
        Me.gpbQuinquenal.Controls.Add(Me.txtAlQuinquenal)
        Me.gpbQuinquenal.Controls.Add(Me.dtkAlQuinquenal)
        Me.gpbQuinquenal.Location = New System.Drawing.Point(14, 248)
        Me.gpbQuinquenal.Name = "gpbQuinquenal"
        Me.gpbQuinquenal.Size = New System.Drawing.Size(440, 37)
        Me.gpbQuinquenal.TabIndex = 1
        Me.gpbQuinquenal.TabStop = False
        '
        'chkQuinquenal
        '
        Me.chkQuinquenal.Location = New System.Drawing.Point(8, 10)
        Me.chkQuinquenal.Name = "chkQuinquenal"
        Me.chkQuinquenal.Size = New System.Drawing.Size(150, 18)
        Me.chkQuinquenal.TabIndex = 31
        Me.chkQuinquenal.Text = "Por Revisi�n Quinquenal"
        '
        'txtDelQuinquenal
        '
        Me.txtDelQuinquenal.Location = New System.Drawing.Point(223, 10)
        Me.txtDelQuinquenal.Name = "txtDelQuinquenal"
        Me.txtDelQuinquenal.Size = New System.Drawing.Size(80, 20)
        Me.txtDelQuinquenal.TabIndex = 29
        Me.txtDelQuinquenal.Text = ""
        '
        'dtkDelQuinquenal
        '
        Me.dtkDelQuinquenal.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelQuinquenal.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelQuinquenal.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelQuinquenal.Name = "dtkDelQuinquenal"
        Me.dtkDelQuinquenal.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelQuinquenal.TabIndex = 30
        Me.dtkDelQuinquenal.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlQuinquenal
        '
        Me.txtAlQuinquenal.Location = New System.Drawing.Point(336, 10)
        Me.txtAlQuinquenal.Name = "txtAlQuinquenal"
        Me.txtAlQuinquenal.Size = New System.Drawing.Size(80, 20)
        Me.txtAlQuinquenal.TabIndex = 29
        Me.txtAlQuinquenal.Text = ""
        '
        'dtkAlQuinquenal
        '
        Me.dtkAlQuinquenal.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlQuinquenal.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlQuinquenal.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlQuinquenal.Name = "dtkAlQuinquenal"
        Me.dtkAlQuinquenal.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlQuinquenal.TabIndex = 30
        Me.dtkAlQuinquenal.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'gpbRatificacion
        '
        Me.gpbRatificacion.Controls.Add(Me.chkRatificacion)
        Me.gpbRatificacion.Controls.Add(Me.txtDelRatificacion)
        Me.gpbRatificacion.Controls.Add(Me.dtkDelRatificacion)
        Me.gpbRatificacion.Controls.Add(Me.txtAlRatificacion)
        Me.gpbRatificacion.Controls.Add(Me.dtkAlRatificacion)
        Me.gpbRatificacion.Location = New System.Drawing.Point(14, 288)
        Me.gpbRatificacion.Name = "gpbRatificacion"
        Me.gpbRatificacion.Size = New System.Drawing.Size(440, 37)
        Me.gpbRatificacion.TabIndex = 1
        Me.gpbRatificacion.TabStop = False
        '
        'chkRatificacion
        '
        Me.chkRatificacion.Location = New System.Drawing.Point(8, 10)
        Me.chkRatificacion.Name = "chkRatificacion"
        Me.chkRatificacion.Size = New System.Drawing.Size(139, 20)
        Me.chkRatificacion.TabIndex = 31
        Me.chkRatificacion.Text = "Por Fecha Ratificaci�n"
        '
        'txtDelRatificacion
        '
        Me.txtDelRatificacion.Location = New System.Drawing.Point(223, 10)
        Me.txtDelRatificacion.Name = "txtDelRatificacion"
        Me.txtDelRatificacion.Size = New System.Drawing.Size(80, 20)
        Me.txtDelRatificacion.TabIndex = 29
        Me.txtDelRatificacion.Text = ""
        '
        'dtkDelRatificacion
        '
        Me.dtkDelRatificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelRatificacion.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelRatificacion.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelRatificacion.Name = "dtkDelRatificacion"
        Me.dtkDelRatificacion.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelRatificacion.TabIndex = 30
        Me.dtkDelRatificacion.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlRatificacion
        '
        Me.txtAlRatificacion.Location = New System.Drawing.Point(336, 10)
        Me.txtAlRatificacion.Name = "txtAlRatificacion"
        Me.txtAlRatificacion.Size = New System.Drawing.Size(80, 20)
        Me.txtAlRatificacion.TabIndex = 29
        Me.txtAlRatificacion.Text = ""
        '
        'dtkAlRatificacion
        '
        Me.dtkAlRatificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlRatificacion.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlRatificacion.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlRatificacion.Name = "dtkAlRatificacion"
        Me.dtkAlRatificacion.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlRatificacion.TabIndex = 30
        Me.dtkAlRatificacion.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'gpbResponsable
        '
        Me.gpbResponsable.Controls.Add(Me.txtResponsable)
        Me.gpbResponsable.Controls.Add(Me.cboResponsable)
        Me.gpbResponsable.Controls.Add(Me.chkResponsable)
        Me.gpbResponsable.Location = New System.Drawing.Point(14, 328)
        Me.gpbResponsable.Name = "gpbResponsable"
        Me.gpbResponsable.Size = New System.Drawing.Size(440, 43)
        Me.gpbResponsable.TabIndex = 1
        Me.gpbResponsable.TabStop = False
        '
        'txtResponsable
        '
        Me.txtResponsable.Location = New System.Drawing.Point(144, 12)
        Me.txtResponsable.Name = "txtResponsable"
        Me.txtResponsable.Size = New System.Drawing.Size(262, 20)
        Me.txtResponsable.TabIndex = 33
        Me.txtResponsable.Text = ""
        '
        'cboResponsable
        '
        Me.cboResponsable.Location = New System.Drawing.Point(144, 12)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(280, 21)
        Me.cboResponsable.TabIndex = 32
        '
        'chkResponsable
        '
        Me.chkResponsable.Location = New System.Drawing.Point(8, 14)
        Me.chkResponsable.Name = "chkResponsable"
        Me.chkResponsable.Size = New System.Drawing.Size(112, 18)
        Me.chkResponsable.TabIndex = 31
        Me.chkResponsable.Text = "Por Responsable"
        '
        'tpgProy
        '
        Me.tpgProy.Controls.Add(Me.GroupBox1)
        Me.tpgProy.Controls.Add(Me.Label1)
        Me.tpgProy.Controls.Add(Me.Label2)
        Me.tpgProy.Controls.Add(Me.gpbProyenComentarios)
        Me.tpgProy.Controls.Add(Me.gpbProyFinales)
        Me.tpgProy.Controls.Add(Me.gpbProyConComentarios)
        Me.tpgProy.Controls.Add(Me.gbbDOF)
        Me.tpgProy.Controls.Add(Me.gpbProyAprobados)
        Me.tpgProy.Controls.Add(Me.gpbResponsableProy)
        Me.tpgProy.Location = New System.Drawing.Point(4, 22)
        Me.tpgProy.Name = "tpgProy"
        Me.tpgProy.Size = New System.Drawing.Size(464, 374)
        Me.tpgProy.TabIndex = 1
        Me.tpgProy.Text = "Proyecto               "
        Me.tpgProy.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkRemitidasDGN)
        Me.GroupBox1.Controls.Add(Me.txtDelRemitidasDGN)
        Me.GroupBox1.Controls.Add(Me.dtkDelRemitidasDGN)
        Me.GroupBox1.Controls.Add(Me.txtAlRemitidasDGN)
        Me.GroupBox1.Controls.Add(Me.dtkAlRemitidasDGN)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 256)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(440, 37)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        '
        'chkRemitidasDGN
        '
        Me.chkRemitidasDGN.Location = New System.Drawing.Point(8, 10)
        Me.chkRemitidasDGN.Name = "chkRemitidasDGN"
        Me.chkRemitidasDGN.Size = New System.Drawing.Size(116, 18)
        Me.chkRemitidasDGN.TabIndex = 31
        Me.chkRemitidasDGN.Text = "Remitidas a DGN"
        '
        'txtDelRemitidasDGN
        '
        Me.txtDelRemitidasDGN.Location = New System.Drawing.Point(223, 10)
        Me.txtDelRemitidasDGN.Name = "txtDelRemitidasDGN"
        Me.txtDelRemitidasDGN.Size = New System.Drawing.Size(80, 20)
        Me.txtDelRemitidasDGN.TabIndex = 29
        Me.txtDelRemitidasDGN.Text = ""
        '
        'dtkDelRemitidasDGN
        '
        Me.dtkDelRemitidasDGN.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelRemitidasDGN.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelRemitidasDGN.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelRemitidasDGN.Name = "dtkDelRemitidasDGN"
        Me.dtkDelRemitidasDGN.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelRemitidasDGN.TabIndex = 30
        Me.dtkDelRemitidasDGN.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlRemitidasDGN
        '
        Me.txtAlRemitidasDGN.Location = New System.Drawing.Point(336, 10)
        Me.txtAlRemitidasDGN.Name = "txtAlRemitidasDGN"
        Me.txtAlRemitidasDGN.Size = New System.Drawing.Size(80, 20)
        Me.txtAlRemitidasDGN.TabIndex = 29
        Me.txtAlRemitidasDGN.Text = ""
        '
        'dtkAlRemitidasDGN
        '
        Me.dtkAlRemitidasDGN.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlRemitidasDGN.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlRemitidasDGN.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlRemitidasDGN.Name = "dtkAlRemitidasDGN"
        Me.dtkAlRemitidasDGN.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlRemitidasDGN.TabIndex = 30
        Me.dtkAlRemitidasDGN.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(248, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Periodo del: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(368, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 16)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Periodo al: "
        '
        'gpbProyenComentarios
        '
        Me.gpbProyenComentarios.Controls.Add(Me.chkProyenComentarios)
        Me.gpbProyenComentarios.Controls.Add(Me.txtDelProyenComentarios)
        Me.gpbProyenComentarios.Controls.Add(Me.dtkDelProyenComentarios)
        Me.gpbProyenComentarios.Controls.Add(Me.txtAlProyenComentarios)
        Me.gpbProyenComentarios.Controls.Add(Me.dtkAlProyenComentarios)
        Me.gpbProyenComentarios.Location = New System.Drawing.Point(8, 24)
        Me.gpbProyenComentarios.Name = "gpbProyenComentarios"
        Me.gpbProyenComentarios.Size = New System.Drawing.Size(440, 35)
        Me.gpbProyenComentarios.TabIndex = 6
        Me.gpbProyenComentarios.TabStop = False
        '
        'chkProyenComentarios
        '
        Me.chkProyenComentarios.Location = New System.Drawing.Point(8, 10)
        Me.chkProyenComentarios.Name = "chkProyenComentarios"
        Me.chkProyenComentarios.Size = New System.Drawing.Size(144, 18)
        Me.chkProyenComentarios.TabIndex = 31
        Me.chkProyenComentarios.Text = "Proy en Comentarios"
        '
        'txtDelProyenComentarios
        '
        Me.txtDelProyenComentarios.Location = New System.Drawing.Point(223, 10)
        Me.txtDelProyenComentarios.Name = "txtDelProyenComentarios"
        Me.txtDelProyenComentarios.Size = New System.Drawing.Size(80, 20)
        Me.txtDelProyenComentarios.TabIndex = 29
        Me.txtDelProyenComentarios.Text = ""
        '
        'dtkDelProyenComentarios
        '
        Me.dtkDelProyenComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelProyenComentarios.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelProyenComentarios.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelProyenComentarios.Name = "dtkDelProyenComentarios"
        Me.dtkDelProyenComentarios.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelProyenComentarios.TabIndex = 30
        Me.dtkDelProyenComentarios.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlProyenComentarios
        '
        Me.txtAlProyenComentarios.Location = New System.Drawing.Point(336, 10)
        Me.txtAlProyenComentarios.Name = "txtAlProyenComentarios"
        Me.txtAlProyenComentarios.Size = New System.Drawing.Size(80, 20)
        Me.txtAlProyenComentarios.TabIndex = 29
        Me.txtAlProyenComentarios.Text = ""
        '
        'dtkAlProyenComentarios
        '
        Me.dtkAlProyenComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlProyenComentarios.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlProyenComentarios.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlProyenComentarios.Name = "dtkAlProyenComentarios"
        Me.dtkAlProyenComentarios.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlProyenComentarios.TabIndex = 30
        Me.dtkAlProyenComentarios.Value = New Date(2007, 1, 4, 0, 0, 0, 0)
        '
        'gpbProyFinales
        '
        Me.gpbProyFinales.Controls.Add(Me.chkProyFinales)
        Me.gpbProyFinales.Controls.Add(Me.txtDelProyFinales)
        Me.gpbProyFinales.Controls.Add(Me.dtkDelProyFinales)
        Me.gpbProyFinales.Controls.Add(Me.txtAlProyFinales)
        Me.gpbProyFinales.Controls.Add(Me.dtkAlProyFinales)
        Me.gpbProyFinales.Location = New System.Drawing.Point(8, 96)
        Me.gpbProyFinales.Name = "gpbProyFinales"
        Me.gpbProyFinales.Size = New System.Drawing.Size(440, 35)
        Me.gpbProyFinales.TabIndex = 7
        Me.gpbProyFinales.TabStop = False
        '
        'chkProyFinales
        '
        Me.chkProyFinales.Location = New System.Drawing.Point(8, 10)
        Me.chkProyFinales.Name = "chkProyFinales"
        Me.chkProyFinales.Size = New System.Drawing.Size(88, 18)
        Me.chkProyFinales.TabIndex = 31
        Me.chkProyFinales.Text = "Proy Finales"
        '
        'txtDelProyFinales
        '
        Me.txtDelProyFinales.Location = New System.Drawing.Point(223, 9)
        Me.txtDelProyFinales.Name = "txtDelProyFinales"
        Me.txtDelProyFinales.Size = New System.Drawing.Size(80, 20)
        Me.txtDelProyFinales.TabIndex = 29
        Me.txtDelProyFinales.Text = ""
        '
        'dtkDelProyFinales
        '
        Me.dtkDelProyFinales.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelProyFinales.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelProyFinales.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelProyFinales.Name = "dtkDelProyFinales"
        Me.dtkDelProyFinales.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelProyFinales.TabIndex = 30
        Me.dtkDelProyFinales.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlProyFinales
        '
        Me.txtAlProyFinales.Location = New System.Drawing.Point(336, 10)
        Me.txtAlProyFinales.Name = "txtAlProyFinales"
        Me.txtAlProyFinales.Size = New System.Drawing.Size(80, 20)
        Me.txtAlProyFinales.TabIndex = 29
        Me.txtAlProyFinales.Text = ""
        '
        'dtkAlProyFinales
        '
        Me.dtkAlProyFinales.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlProyFinales.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlProyFinales.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlProyFinales.Name = "dtkAlProyFinales"
        Me.dtkAlProyFinales.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlProyFinales.TabIndex = 30
        Me.dtkAlProyFinales.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'gpbProyConComentarios
        '
        Me.gpbProyConComentarios.Controls.Add(Me.chkProyConComentarios)
        Me.gpbProyConComentarios.Controls.Add(Me.txtDelProyConComentarios)
        Me.gpbProyConComentarios.Controls.Add(Me.dtkDelProyConComentarios)
        Me.gpbProyConComentarios.Controls.Add(Me.txtAlProyConComentarios)
        Me.gpbProyConComentarios.Controls.Add(Me.dtkAlProyConComentarios)
        Me.gpbProyConComentarios.Location = New System.Drawing.Point(8, 64)
        Me.gpbProyConComentarios.Name = "gpbProyConComentarios"
        Me.gpbProyConComentarios.Size = New System.Drawing.Size(440, 35)
        Me.gpbProyConComentarios.TabIndex = 8
        Me.gpbProyConComentarios.TabStop = False
        '
        'chkProyConComentarios
        '
        Me.chkProyConComentarios.Location = New System.Drawing.Point(8, 11)
        Me.chkProyConComentarios.Name = "chkProyConComentarios"
        Me.chkProyConComentarios.Size = New System.Drawing.Size(136, 18)
        Me.chkProyConComentarios.TabIndex = 31
        Me.chkProyConComentarios.Text = "Proy con Comentarios"
        '
        'txtDelProyConComentarios
        '
        Me.txtDelProyConComentarios.Location = New System.Drawing.Point(224, 11)
        Me.txtDelProyConComentarios.Name = "txtDelProyConComentarios"
        Me.txtDelProyConComentarios.Size = New System.Drawing.Size(80, 20)
        Me.txtDelProyConComentarios.TabIndex = 29
        Me.txtDelProyConComentarios.Text = ""
        '
        'dtkDelProyConComentarios
        '
        Me.dtkDelProyConComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelProyConComentarios.Location = New System.Drawing.Point(224, 11)
        Me.dtkDelProyConComentarios.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelProyConComentarios.Name = "dtkDelProyConComentarios"
        Me.dtkDelProyConComentarios.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelProyConComentarios.TabIndex = 30
        Me.dtkDelProyConComentarios.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlProyConComentarios
        '
        Me.txtAlProyConComentarios.Location = New System.Drawing.Point(336, 11)
        Me.txtAlProyConComentarios.Name = "txtAlProyConComentarios"
        Me.txtAlProyConComentarios.Size = New System.Drawing.Size(80, 20)
        Me.txtAlProyConComentarios.TabIndex = 29
        Me.txtAlProyConComentarios.Text = ""
        '
        'dtkAlProyConComentarios
        '
        Me.dtkAlProyConComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlProyConComentarios.Location = New System.Drawing.Point(336, 11)
        Me.dtkAlProyConComentarios.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlProyConComentarios.Name = "dtkAlProyConComentarios"
        Me.dtkAlProyConComentarios.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlProyConComentarios.TabIndex = 30
        Me.dtkAlProyConComentarios.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'gbbDOF
        '
        Me.gbbDOF.Controls.Add(Me.chkDOF)
        Me.gbbDOF.Controls.Add(Me.txtDelDOF)
        Me.gbbDOF.Controls.Add(Me.dtkDelDOF)
        Me.gbbDOF.Controls.Add(Me.txtAlDOF)
        Me.gbbDOF.Controls.Add(Me.dtkAlDOF)
        Me.gbbDOF.Location = New System.Drawing.Point(8, 136)
        Me.gbbDOF.Name = "gbbDOF"
        Me.gbbDOF.Size = New System.Drawing.Size(440, 37)
        Me.gbbDOF.TabIndex = 5
        Me.gbbDOF.TabStop = False
        Me.gbbDOF.Visible = False
        '
        'chkDOF
        '
        Me.chkDOF.Location = New System.Drawing.Point(8, 10)
        Me.chkDOF.Name = "chkDOF"
        Me.chkDOF.Size = New System.Drawing.Size(150, 18)
        Me.chkDOF.TabIndex = 31
        Me.chkDOF.Text = "Fecha Publicacion DOF"
        '
        'txtDelDOF
        '
        Me.txtDelDOF.Location = New System.Drawing.Point(223, 10)
        Me.txtDelDOF.Name = "txtDelDOF"
        Me.txtDelDOF.Size = New System.Drawing.Size(80, 20)
        Me.txtDelDOF.TabIndex = 29
        Me.txtDelDOF.Text = ""
        '
        'dtkDelDOF
        '
        Me.dtkDelDOF.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelDOF.Location = New System.Drawing.Point(223, 10)
        Me.dtkDelDOF.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelDOF.Name = "dtkDelDOF"
        Me.dtkDelDOF.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelDOF.TabIndex = 30
        Me.dtkDelDOF.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlDOF
        '
        Me.txtAlDOF.Location = New System.Drawing.Point(336, 10)
        Me.txtAlDOF.Name = "txtAlDOF"
        Me.txtAlDOF.Size = New System.Drawing.Size(80, 20)
        Me.txtAlDOF.TabIndex = 29
        Me.txtAlDOF.Text = ""
        '
        'dtkAlDOF
        '
        Me.dtkAlDOF.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlDOF.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlDOF.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlDOF.Name = "dtkAlDOF"
        Me.dtkAlDOF.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlDOF.TabIndex = 30
        Me.dtkAlDOF.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'gpbProyAprobados
        '
        Me.gpbProyAprobados.Controls.Add(Me.chkProyAprobados)
        Me.gpbProyAprobados.Controls.Add(Me.txtDelProyAprobados)
        Me.gpbProyAprobados.Controls.Add(Me.dtkdelProyAprobados)
        Me.gpbProyAprobados.Controls.Add(Me.txtAlProyAprobados)
        Me.gpbProyAprobados.Controls.Add(Me.dtkAlProyAprobados)
        Me.gpbProyAprobados.Location = New System.Drawing.Point(8, 168)
        Me.gpbProyAprobados.Name = "gpbProyAprobados"
        Me.gpbProyAprobados.Size = New System.Drawing.Size(440, 37)
        Me.gpbProyAprobados.TabIndex = 2
        Me.gpbProyAprobados.TabStop = False
        '
        'chkProyAprobados
        '
        Me.chkProyAprobados.Location = New System.Drawing.Point(8, 10)
        Me.chkProyAprobados.Name = "chkProyAprobados"
        Me.chkProyAprobados.Size = New System.Drawing.Size(138, 18)
        Me.chkProyAprobados.TabIndex = 31
        Me.chkProyAprobados.Text = "Proyectos Aprobados"
        '
        'txtDelProyAprobados
        '
        Me.txtDelProyAprobados.Location = New System.Drawing.Point(224, 10)
        Me.txtDelProyAprobados.Name = "txtDelProyAprobados"
        Me.txtDelProyAprobados.Size = New System.Drawing.Size(79, 20)
        Me.txtDelProyAprobados.TabIndex = 29
        Me.txtDelProyAprobados.Text = ""
        '
        'dtkdelProyAprobados
        '
        Me.dtkdelProyAprobados.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkdelProyAprobados.Location = New System.Drawing.Point(223, 10)
        Me.dtkdelProyAprobados.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkdelProyAprobados.Name = "dtkdelProyAprobados"
        Me.dtkdelProyAprobados.Size = New System.Drawing.Size(98, 20)
        Me.dtkdelProyAprobados.TabIndex = 30
        Me.dtkdelProyAprobados.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlProyAprobados
        '
        Me.txtAlProyAprobados.Location = New System.Drawing.Point(336, 10)
        Me.txtAlProyAprobados.Name = "txtAlProyAprobados"
        Me.txtAlProyAprobados.Size = New System.Drawing.Size(80, 20)
        Me.txtAlProyAprobados.TabIndex = 29
        Me.txtAlProyAprobados.Text = ""
        '
        'dtkAlProyAprobados
        '
        Me.dtkAlProyAprobados.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlProyAprobados.Location = New System.Drawing.Point(336, 10)
        Me.dtkAlProyAprobados.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlProyAprobados.Name = "dtkAlProyAprobados"
        Me.dtkAlProyAprobados.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlProyAprobados.TabIndex = 30
        Me.dtkAlProyAprobados.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'gpbResponsableProy
        '
        Me.gpbResponsableProy.Controls.Add(Me.txtResponsableProy)
        Me.gpbResponsableProy.Controls.Add(Me.cboResponsableProy)
        Me.gpbResponsableProy.Controls.Add(Me.chkResponsableProy)
        Me.gpbResponsableProy.Location = New System.Drawing.Point(8, 208)
        Me.gpbResponsableProy.Name = "gpbResponsableProy"
        Me.gpbResponsableProy.Size = New System.Drawing.Size(440, 39)
        Me.gpbResponsableProy.TabIndex = 3
        Me.gpbResponsableProy.TabStop = False
        '
        'txtResponsableProy
        '
        Me.txtResponsableProy.Location = New System.Drawing.Point(156, 10)
        Me.txtResponsableProy.Name = "txtResponsableProy"
        Me.txtResponsableProy.Size = New System.Drawing.Size(262, 20)
        Me.txtResponsableProy.TabIndex = 33
        Me.txtResponsableProy.Text = ""
        '
        'cboResponsableProy
        '
        Me.cboResponsableProy.Location = New System.Drawing.Point(156, 10)
        Me.cboResponsableProy.Name = "cboResponsableProy"
        Me.cboResponsableProy.Size = New System.Drawing.Size(280, 21)
        Me.cboResponsableProy.TabIndex = 32
        '
        'chkResponsableProy
        '
        Me.chkResponsableProy.Location = New System.Drawing.Point(8, 12)
        Me.chkResponsableProy.Name = "chkResponsableProy"
        Me.chkResponsableProy.Size = New System.Drawing.Size(112, 18)
        Me.chkResponsableProy.TabIndex = 31
        Me.chkResponsableProy.Text = "Por Responsable"
        '
        'tpgAnt
        '
        Me.tpgAnt.Controls.Add(Me.gpbClasificacionAnt)
        Me.tpgAnt.Controls.Add(Me.gpbResponsableAnt)
        Me.tpgAnt.Location = New System.Drawing.Point(4, 22)
        Me.tpgAnt.Name = "tpgAnt"
        Me.tpgAnt.Size = New System.Drawing.Size(464, 374)
        Me.tpgAnt.TabIndex = 2
        Me.tpgAnt.Text = "Anteproyecto       "
        Me.tpgAnt.Visible = False
        '
        'gpbClasificacionAnt
        '
        Me.gpbClasificacionAnt.Controls.Add(Me.txtClasificacionAnt)
        Me.gpbClasificacionAnt.Controls.Add(Me.cboClasificacionAnt)
        Me.gpbClasificacionAnt.Controls.Add(Me.chkClasificacionAnt)
        Me.gpbClasificacionAnt.Location = New System.Drawing.Point(16, 72)
        Me.gpbClasificacionAnt.Name = "gpbClasificacionAnt"
        Me.gpbClasificacionAnt.Size = New System.Drawing.Size(440, 42)
        Me.gpbClasificacionAnt.TabIndex = 38
        Me.gpbClasificacionAnt.TabStop = False
        Me.gpbClasificacionAnt.Visible = False
        '
        'txtClasificacionAnt
        '
        Me.txtClasificacionAnt.Location = New System.Drawing.Point(144, 13)
        Me.txtClasificacionAnt.Name = "txtClasificacionAnt"
        Me.txtClasificacionAnt.Size = New System.Drawing.Size(262, 20)
        Me.txtClasificacionAnt.TabIndex = 33
        Me.txtClasificacionAnt.Text = ""
        '
        'cboClasificacionAnt
        '
        Me.cboClasificacionAnt.Location = New System.Drawing.Point(144, 13)
        Me.cboClasificacionAnt.Name = "cboClasificacionAnt"
        Me.cboClasificacionAnt.Size = New System.Drawing.Size(280, 21)
        Me.cboClasificacionAnt.TabIndex = 32
        '
        'chkClasificacionAnt
        '
        Me.chkClasificacionAnt.Location = New System.Drawing.Point(8, 14)
        Me.chkClasificacionAnt.Name = "chkClasificacionAnt"
        Me.chkClasificacionAnt.Size = New System.Drawing.Size(112, 18)
        Me.chkClasificacionAnt.TabIndex = 31
        Me.chkClasificacionAnt.Text = "Clasificacion"
        '
        'gpbResponsableAnt
        '
        Me.gpbResponsableAnt.Controls.Add(Me.txtResponsableAnt)
        Me.gpbResponsableAnt.Controls.Add(Me.cboResponsableAnt)
        Me.gpbResponsableAnt.Controls.Add(Me.chkResponsableAnt)
        Me.gpbResponsableAnt.Location = New System.Drawing.Point(16, 23)
        Me.gpbResponsableAnt.Name = "gpbResponsableAnt"
        Me.gpbResponsableAnt.Size = New System.Drawing.Size(440, 41)
        Me.gpbResponsableAnt.TabIndex = 37
        Me.gpbResponsableAnt.TabStop = False
        '
        'txtResponsableAnt
        '
        Me.txtResponsableAnt.Location = New System.Drawing.Point(144, 13)
        Me.txtResponsableAnt.Name = "txtResponsableAnt"
        Me.txtResponsableAnt.Size = New System.Drawing.Size(262, 20)
        Me.txtResponsableAnt.TabIndex = 33
        Me.txtResponsableAnt.Text = ""
        '
        'cboResponsableAnt
        '
        Me.cboResponsableAnt.Location = New System.Drawing.Point(144, 13)
        Me.cboResponsableAnt.Name = "cboResponsableAnt"
        Me.cboResponsableAnt.Size = New System.Drawing.Size(280, 21)
        Me.cboResponsableAnt.TabIndex = 32
        '
        'chkResponsableAnt
        '
        Me.chkResponsableAnt.Location = New System.Drawing.Point(8, 14)
        Me.chkResponsableAnt.Name = "chkResponsableAnt"
        Me.chkResponsableAnt.Size = New System.Drawing.Size(112, 18)
        Me.chkResponsableAnt.TabIndex = 31
        Me.chkResponsableAnt.Text = "Por Responsable"
        '
        'tpgDT
        '
        Me.tpgDT.Controls.Add(Me.gpbResponsableDT)
        Me.tpgDT.Controls.Add(Me.gpbPeriodoDT)
        Me.tpgDT.Location = New System.Drawing.Point(4, 22)
        Me.tpgDT.Name = "tpgDT"
        Me.tpgDT.Size = New System.Drawing.Size(464, 374)
        Me.tpgDT.TabIndex = 3
        Me.tpgDT.Text = "Documento de Trabajo"
        Me.tpgDT.Visible = False
        '
        'gpbResponsableDT
        '
        Me.gpbResponsableDT.Controls.Add(Me.txtResponsableDT)
        Me.gpbResponsableDT.Controls.Add(Me.cboResponsableDT)
        Me.gpbResponsableDT.Controls.Add(Me.chkResponsableDT)
        Me.gpbResponsableDT.Location = New System.Drawing.Point(14, 8)
        Me.gpbResponsableDT.Name = "gpbResponsableDT"
        Me.gpbResponsableDT.Size = New System.Drawing.Size(440, 44)
        Me.gpbResponsableDT.TabIndex = 39
        Me.gpbResponsableDT.TabStop = False
        '
        'txtResponsableDT
        '
        Me.txtResponsableDT.Location = New System.Drawing.Point(152, 13)
        Me.txtResponsableDT.Name = "txtResponsableDT"
        Me.txtResponsableDT.Size = New System.Drawing.Size(262, 20)
        Me.txtResponsableDT.TabIndex = 33
        Me.txtResponsableDT.Text = ""
        '
        'cboResponsableDT
        '
        Me.cboResponsableDT.Location = New System.Drawing.Point(152, 13)
        Me.cboResponsableDT.Name = "cboResponsableDT"
        Me.cboResponsableDT.Size = New System.Drawing.Size(280, 21)
        Me.cboResponsableDT.TabIndex = 32
        '
        'chkResponsableDT
        '
        Me.chkResponsableDT.Location = New System.Drawing.Point(8, 14)
        Me.chkResponsableDT.Name = "chkResponsableDT"
        Me.chkResponsableDT.Size = New System.Drawing.Size(112, 18)
        Me.chkResponsableDT.TabIndex = 31
        Me.chkResponsableDT.Text = "Por Responsable"
        '
        'gpbPeriodoDT
        '
        Me.gpbPeriodoDT.Controls.Add(Me.chkPeriodoDT)
        Me.gpbPeriodoDT.Controls.Add(Me.txtDelPeriodoDT)
        Me.gpbPeriodoDT.Controls.Add(Me.dtkDelPeriodoDT)
        Me.gpbPeriodoDT.Controls.Add(Me.txtAlPeriodoDT)
        Me.gpbPeriodoDT.Controls.Add(Me.dtkAlPeriodoDT)
        Me.gpbPeriodoDT.Controls.Add(Me.Label5)
        Me.gpbPeriodoDT.Controls.Add(Me.Label6)
        Me.gpbPeriodoDT.Location = New System.Drawing.Point(16, 56)
        Me.gpbPeriodoDT.Name = "gpbPeriodoDT"
        Me.gpbPeriodoDT.Size = New System.Drawing.Size(440, 56)
        Me.gpbPeriodoDT.TabIndex = 38
        Me.gpbPeriodoDT.TabStop = False
        Me.gpbPeriodoDT.Visible = False
        '
        'chkPeriodoDT
        '
        Me.chkPeriodoDT.Location = New System.Drawing.Point(8, 32)
        Me.chkPeriodoDT.Name = "chkPeriodoDT"
        Me.chkPeriodoDT.Size = New System.Drawing.Size(138, 18)
        Me.chkPeriodoDT.TabIndex = 31
        Me.chkPeriodoDT.Text = "Proyectos Aprobados"
        '
        'txtDelPeriodoDT
        '
        Me.txtDelPeriodoDT.Location = New System.Drawing.Point(223, 32)
        Me.txtDelPeriodoDT.Name = "txtDelPeriodoDT"
        Me.txtDelPeriodoDT.Size = New System.Drawing.Size(80, 20)
        Me.txtDelPeriodoDT.TabIndex = 29
        Me.txtDelPeriodoDT.Text = ""
        '
        'dtkDelPeriodoDT
        '
        Me.dtkDelPeriodoDT.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkDelPeriodoDT.Location = New System.Drawing.Point(223, 32)
        Me.dtkDelPeriodoDT.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkDelPeriodoDT.Name = "dtkDelPeriodoDT"
        Me.dtkDelPeriodoDT.Size = New System.Drawing.Size(98, 20)
        Me.dtkDelPeriodoDT.TabIndex = 30
        Me.dtkDelPeriodoDT.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'txtAlPeriodoDT
        '
        Me.txtAlPeriodoDT.Location = New System.Drawing.Point(336, 32)
        Me.txtAlPeriodoDT.Name = "txtAlPeriodoDT"
        Me.txtAlPeriodoDT.Size = New System.Drawing.Size(80, 20)
        Me.txtAlPeriodoDT.TabIndex = 29
        Me.txtAlPeriodoDT.Text = ""
        '
        'dtkAlPeriodoDT
        '
        Me.dtkAlPeriodoDT.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkAlPeriodoDT.Location = New System.Drawing.Point(336, 32)
        Me.dtkAlPeriodoDT.MinDate = New Date(1999, 1, 1, 0, 0, 0, 0)
        Me.dtkAlPeriodoDT.Name = "dtkAlPeriodoDT"
        Me.dtkAlPeriodoDT.Size = New System.Drawing.Size(98, 20)
        Me.dtkAlPeriodoDT.TabIndex = 30
        Me.dtkAlPeriodoDT.Value = New Date(2006, 10, 25, 0, 0, 0, 0)
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(232, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 16)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Periodo del: "
        Me.Label5.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(352, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(66, 16)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Periodo al: "
        Me.Label6.Visible = False
        '
        'grdNormas
        '
        Me.grdNormas.DataMember = ""
        Me.grdNormas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdNormas.Location = New System.Drawing.Point(8, 408)
        Me.grdNormas.Name = "grdNormas"
        Me.grdNormas.ReadOnly = True
        Me.grdNormas.Size = New System.Drawing.Size(537, 160)
        Me.grdNormas.TabIndex = 4
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'txtId_Tema
        '
        Me.txtId_Tema.Location = New System.Drawing.Point(66, 376)
        Me.txtId_Tema.Name = "txtId_Tema"
        Me.txtId_Tema.Size = New System.Drawing.Size(64, 20)
        Me.txtId_Tema.TabIndex = 99
        Me.txtId_Tema.Text = ""
        Me.txtId_Tema.Visible = False
        '
        'txtId_Plan
        '
        Me.txtId_Plan.Location = New System.Drawing.Point(0, 376)
        Me.txtId_Plan.Name = "txtId_Plan"
        Me.txtId_Plan.Size = New System.Drawing.Size(64, 20)
        Me.txtId_Plan.TabIndex = 98
        Me.txtId_Plan.Text = ""
        Me.txtId_Plan.Visible = False
        '
        'txtGT
        '
        Me.txtGT.Location = New System.Drawing.Point(168, 392)
        Me.txtGT.Name = "txtGT"
        Me.txtGT.Size = New System.Drawing.Size(48, 20)
        Me.txtGT.TabIndex = 97
        Me.txtGT.Text = ""
        Me.txtGT.Visible = False
        Me.txtGT.WordWrap = False
        '
        'txtSC
        '
        Me.txtSC.Location = New System.Drawing.Point(120, 392)
        Me.txtSC.Name = "txtSC"
        Me.txtSC.Size = New System.Drawing.Size(40, 20)
        Me.txtSC.TabIndex = 96
        Me.txtSC.Text = ""
        Me.txtSC.Visible = False
        Me.txtSC.WordWrap = False
        '
        'txtCT
        '
        Me.txtCT.Location = New System.Drawing.Point(69, 392)
        Me.txtCT.Name = "txtCT"
        Me.txtCT.Size = New System.Drawing.Size(48, 20)
        Me.txtCT.TabIndex = 95
        Me.txtCT.Text = ""
        Me.txtCT.Visible = False
        Me.txtCT.WordWrap = False
        '
        'txtComite
        '
        Me.txtComite.Location = New System.Drawing.Point(16, 392)
        Me.txtComite.Name = "txtComite"
        Me.txtComite.Size = New System.Drawing.Size(48, 20)
        Me.txtComite.TabIndex = 94
        Me.txtComite.Text = ""
        Me.txtComite.Visible = False
        Me.txtComite.WordWrap = False
        '
        'lblSB
        '
        Me.lblSB.Location = New System.Drawing.Point(136, 376)
        Me.lblSB.Name = "lblSB"
        Me.lblSB.Size = New System.Drawing.Size(80, 16)
        Me.lblSB.TabIndex = 100
        Me.lblSB.Visible = False
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.CmdDeshacer, Me.cmdExportar, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 598)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(920, 62)
        Me.tlbBotonera.TabIndex = 101
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 6
        Me.cmdAgregar.Text = "Buscar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'cmdExportar
        '
        Me.cmdExportar.ImageIndex = 8
        Me.cmdExportar.Text = "Exportar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'grdNormasAdoptadas
        '
        Me.grdNormasAdoptadas.DataMember = ""
        Me.grdNormasAdoptadas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdNormasAdoptadas.Location = New System.Drawing.Point(560, 408)
        Me.grdNormasAdoptadas.Name = "grdNormasAdoptadas"
        Me.grdNormasAdoptadas.ReadOnly = True
        Me.grdNormasAdoptadas.Size = New System.Drawing.Size(352, 160)
        Me.grdNormasAdoptadas.TabIndex = 102
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(392, 576)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(33, 16)
        Me.lblTotal.TabIndex = 233
        Me.lblTotal.Text = "Total:"
        '
        'txtTotal
        '
        Me.txtTotal.AutoSize = False
        Me.txtTotal.Location = New System.Drawing.Point(440, 574)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.TabIndex = 234
        Me.txtTotal.Text = ""
        '
        'frmQ_Normas
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(920, 660)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.txtId_Tema)
        Me.Controls.Add(Me.txtId_Plan)
        Me.Controls.Add(Me.txtGT)
        Me.Controls.Add(Me.txtSC)
        Me.Controls.Add(Me.txtCT)
        Me.Controls.Add(Me.txtComite)
        Me.Controls.Add(Me.grdNormasAdoptadas)
        Me.Controls.Add(Me.lblSB)
        Me.Controls.Add(Me.grdNormas)
        Me.Controls.Add(Me.tvNormas)
        Me.Controls.Add(Me.tclNormas)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Name = "frmQ_Normas"
        Me.Text = "Consulta de Normas"
        Me.tclNormas.ResumeLayout(False)
        Me.tpgNorma.ResumeLayout(False)
        Me.gpbDeclaratoria.ResumeLayout(False)
        Me.gpbDGN.ResumeLayout(False)
        Me.gpbNormasAnce.ResumeLayout(False)
        Me.gpbAdoptadas.ResumeLayout(False)
        Me.gpbQuinquenal.ResumeLayout(False)
        Me.gpbRatificacion.ResumeLayout(False)
        Me.gpbResponsable.ResumeLayout(False)
        Me.tpgProy.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.gpbProyenComentarios.ResumeLayout(False)
        Me.gpbProyFinales.ResumeLayout(False)
        Me.gpbProyConComentarios.ResumeLayout(False)
        Me.gbbDOF.ResumeLayout(False)
        Me.gpbProyAprobados.ResumeLayout(False)
        Me.gpbResponsableProy.ResumeLayout(False)
        Me.tpgAnt.ResumeLayout(False)
        Me.gpbClasificacionAnt.ResumeLayout(False)
        Me.gpbResponsableAnt.ResumeLayout(False)
        Me.tpgDT.ResumeLayout(False)
        Me.gpbResponsableDT.ResumeLayout(False)
        Me.gpbPeriodoDT.ResumeLayout(False)
        CType(Me.grdNormas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdNormasAdoptadas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmQ_Normas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dtkDelVigencia.Value = Format(Now, "dd/MM/yyyy")
        dtkAlVigencia.Value = Format(Now, "dd/MM/yyyy")
        'dtkDelVigencia.CausesValidation = True

        Call Inicializa_Inactivos()
        Call Limpia_Campos_Inactivos()

        Call llena_TreeView()

        Call Formato_Grid(grdNormas)
        Call Formato_GridAdoptadas(grdNormasAdoptadas)
        'Call Formato_GridAdoptadas(cboResponsableDT)

        Call llena_responsable(cboResponsable)
        Call llena_responsable(cboResponsableProy)
        Call llena_responsable(cboResponsableAnt)
        Call llena_responsable(cboResponsableDT)


    End Sub

#Region "  Llena TreView"
    Private Sub llena_TreeView()
        Cursor.Current = Cursors.WaitCursor
        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = tvNormas.Nodes.Add("Seleccione el comite")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        tvNormas.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = tvNormas.Nodes.Add("Seleccione el comite")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = tvNormas.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next 'Comites
        tvNormas.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        'tvNormas.AllowDrop = True
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvNormas.ResetText()

        Cursor.Current = Cursors.Default

        '''*********************fmr
        '''        Dim Comite As TreeNode
        '''        Dim CT As TreeNode
        '''        Dim SC As TreeNode
        '''        Dim GT As TreeNode
        '''        Dim SGT As TreeNode

        '''        Dim oTablaComite As DataTable
        '''        Dim oTablaCT As DataTable
        '''        Dim oTablaSC As DataTable
        '''        Dim oTablaGT As DataTable
        '''        Dim oTablaSGT As DataTable 'fmr octubre
        '''        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)

        '''        oTablaComite = objNodos.ListaComite
        '''        If objNodos.ListaComite Is Nothing Then
        '''            Comite = tvNormas.Nodes.Add("Ra�z")
        '''            Exit Sub
        '''        End If

        '''        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        '''        tvNormas.BeginUpdate()

        '''        ' defino variable del tipo DataRow
        '''        Dim RegComite As DataRow
        '''        Dim RegCT As DataRow
        '''        Dim RegSC As DataRow
        '''        Dim RegGT As DataRow
        '''        Dim RegSGT As DataRow

        '''        dvComite = oTablaComite.DefaultView
        '''        Comite = tvNormas.Nodes.Add("Seleccione un Comit�")

        '''        For Each RegComite In oTablaComite.Rows '******COMITES

        '''            If RegComite("ID_Comite") = "NA" Then 'Valida si es NA
        '''                GoTo ComiteNA
        '''            End If

        '''            Comite = tvNormas.Nodes(0).Nodes.Add(RegComite("ID_Comite"))

        '''ComiteNA:

        '''            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
        '''                GoTo sinComite
        '''            End If

        '''            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

        '''            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS

        '''                If RegComite("ID_comite") = "NA" Or RegCT("ID_CT") = "NA" Then 'Valida si no existen NA
        '''                    GoTo CTNA
        '''                End If

        '''                CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))

        '''CTNA:

        '''                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
        '''                    GoTo sinCT
        '''                End If

        '''                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

        '''                For Each RegSC In oTablaSC.Rows '******SUB COMITE

        '''                    If RegComite("ID_Comite") = "NA" Or RegCT("ID_CT") = "NA" Or RegSC("ID_SC") = "NA" Then 'Valida si no existen nodos hijos
        '''                        GoTo SCNA
        '''                    End If

        '''                    SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))

        '''SCNA:

        '''                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
        '''                        GoTo sinSC
        '''                    End If
        '''                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

        '''                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO

        '''                        If RegCT("ID_CT") = "NA" And RegSC("ID_SC") = "NA" Then 'cuando es de un comite el GT
        '''                            'Comite = Comite.Nodes.Add(Trim(RegGT("ID_Grupo")))
        '''                            Comite.Nodes.Add(Trim(RegGT("ID_Grupo")))
        '''                            'Exit For
        '''                        End If

        '''                        If Not (RegCT("ID_CT") = "NA") And (RegSC("ID_SC") = "NA") Then 'cuando es de un CT el GT
        '''                            'CT = CT.Nodes.Add(Trim(RegGT("ID_Grupo")))
        '''                            CT.Nodes.Add(Trim(RegGT("ID_Grupo")))
        '''                            'Exit For
        '''                        End If


        '''                        If Not (RegCT("ID_CT") = "NA") And Not (RegSC("ID_SC") = "NA") And Not (RegGT("ID_Grupo") = "") Then 'cuando es de un comite el GT
        '''                            'GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
        '''                            SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
        '''                        End If



        '''                        '''If objNodos.ListaSGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo")) Is Nothing Then  'Valida si no existen nodos hijos
        '''                        '''    GoTo sinGT
        '''                        '''End If
        '''                        '''oTablaSGT = objNodos.ListaSGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC"), RegGT("ID_Grupo"))  '***OK

        '''                        '''For Each RegSGT In oTablaSGT.Rows '******SUB GRUPOS DE TRABAJO
        '''                        '''    SGT = GT.Nodes.Add(Trim(RegSGT("ID_SGT")))

        '''                        '''Next 'SGT
        '''                        '''sinGT:


        '''                    Next 'GT
        '''sinSC:
        '''                Next 'SC
        '''sinCT:
        '''            Next 'CT
        '''sinComite:
        '''        Next 'Comites
        '''        tvNormas.EndUpdate()
        '''        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        '''        tvNormas.AllowDrop = True
        '''        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        '''        tvNormas.Sorted = True


    End Sub

#End Region

#Region "  AfterSelect"
    Private Sub tvNormas_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvNormas.AfterSelect
        ' recupero el Path donde est� la selecci�n y lo pongo en la barra de estado
        lblSB.Text = e.Node.FullPath
        iCaso = 0
        objConexion2.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)  'fmr 07/12/06


        Dim array_texto As Array
        Dim cmdBusca As New SqlCommand
        Dim cmdBusca2 As New SqlCommand
        Dim cmdBusca3 As New SqlCommand
        Dim cmdBusca4 As New SqlCommand

        Dim da As New SqlDataAdapter(cmdBusca)
        Dim da2 As New SqlDataAdapter(cmdBusca2)
        Dim da3 As New SqlDataAdapter(cmdBusca3)
        Dim da4 As New SqlDataAdapter(cmdBusca4)

        Dim dsP_Normalizacion As New DataSet
        Dim dsP_Normalizacion2 As New DataSet
        Dim dsP_Normalizacion3 As New DataSet
        Dim dsP_Normalizacion4 As New DataSet

        If lblSB.Text = "" Or lblSB.Text = "Seleccione un Comit�" Then
            Limpia_Campos(txtComite, txtCT, txtSC, txtGT)
            iCaso = 1
            Exit Sub
        End If
        array_texto = Split(lblSB.Text, "\")

        If array_texto.Length <= 1 Then
            Limpia_Campos(txtComite)
        Else
            objComites.Bandera = 1

            objComites.ID_Comite = array_texto(1)
            objComites.Busca_uno()
            '''aqui
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            iCaso = 2
        End If

        If array_texto.Length <= 2 Then
            txtCT.Text = ""
        Else
            objComites.Bandera = 2
            objComites.ID_Comite = array_texto(1)

            If Microsoft.VisualBasic.Left(array_texto(2), 2) = "GT" Then
                objComites.Bandera = 4
                objComites.ID_CT = "NA"
                objComites.ID_SC = "NA"
                objComites.ID_GT = array_texto(2)
                GoTo GT
            End If

            objComites.ID_CT = array_texto(2)
            objComites.Busca_dos()
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT

            iCaso = 3

        End If


        If array_texto.Length <= 3 Then
            txtSC.Text = ""
        Else
            objComites.Bandera = 3
            objComites.ID_Comite = array_texto(1)
            objComites.ID_CT = array_texto(2)

            If Microsoft.VisualBasic.Left(array_texto(3), 2) = "GT" Then
                objComites.Bandera = 4
                objComites.ID_SC = "NA"
                objComites.ID_GT = array_texto(3)
                GoTo GT
            End If

            objComites.ID_SC = array_texto(3)
            objComites.Busca_tres()
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT
            iCaso = 4
        End If


        If array_texto.Length <= 4 Then
            txtGT.Text = ""
        Else
            objComites.Bandera = 4
            objComites.ID_Comite = array_texto(1)
            objComites.ID_CT = array_texto(2)
            objComites.ID_SC = array_texto(3)
            objComites.ID_GT = array_texto(4)

GT:         'esta salto de l�nea es para cuando un Comite o CT tiene un GT directo

            objComites.Busca_cuatro()
            txtComite.Text = objComites.ID_Comite
            txtCT.Text = objComites.ID_CT
            txtSC.Text = objComites.ID_SC
            txtGT.Text = objComites.ID_GT
            iCaso = 5
            'cmdBusca4.Dispose()
        End If

        If array_texto.Length > 5 Then
            iCaso = 6
        End If




        '''        Dim array_texto As Array
        '''        Dim cmdBusca As New SqlCommand
        '''        Dim cmdBusca2 As New SqlCommand
        '''        Dim cmdBusca3 As New SqlCommand
        '''        Dim cmdBusca4 As New SqlCommand

        '''        Dim da As New SqlDataAdapter(cmdBusca)
        '''        Dim da2 As New SqlDataAdapter(cmdBusca2)
        '''        Dim da3 As New SqlDataAdapter(cmdBusca3)
        '''        Dim da4 As New SqlDataAdapter(cmdBusca4)

        '''        Dim dsP_Normalizacion As New DataSet
        '''        Dim dsP_Normalizacion2 As New DataSet
        '''        Dim dsP_Normalizacion3 As New DataSet
        '''        Dim dsP_Normalizacion4 As New DataSet

        '''        If lblSB.Text = "" Or lblSB.Text = "Seleccione un Comit�" Then
        '''            Limpia_Campos(txtComite, txtCT, txtSC, txtGT)

        '''            iCaso = 1
        '''            Exit Sub
        '''        End If
        '''        array_texto = Split(lblSB.Text, "\")

        '''        If array_texto.Length <= 1 Then
        '''            Limpia_Campos(txtComite)
        '''        Else
        '''            objComites.Bandera = 1
        '''            'objComites.Bandera = iCaso + 1
        '''            objComites.ID_Comite = array_texto(1)
        '''            objComites.Busca_uno()
        '''            txtComite.Text = objComites.ID_Comite
        '''            txtCT.Text = objComites.ID_CT
        '''            txtSC.Text = objComites.ID_SC
        '''            txtGT.Text = objComites.ID_GT
        '''            iCaso = 2
        '''        End If

        '''        If array_texto.Length <= 2 Then
        '''            txtCT.Text = ""
        '''        Else
        '''            objComites.Bandera = 2
        '''            objComites.ID_Comite = array_texto(1)

        '''            If Microsoft.VisualBasic.Left(array_texto(2), 2) = "GT" Then
        '''                objComites.Bandera = 4
        '''                objComites.ID_CT = "NA"
        '''                objComites.ID_SC = "NA"
        '''                objComites.ID_GT = array_texto(2)
        '''                GoTo GT
        '''            End If

        '''            objComites.ID_CT = array_texto(2)
        '''            objComites.Busca_dos()
        '''            txtComite.Text = objComites.ID_Comite
        '''            txtCT.Text = objComites.ID_CT
        '''            txtSC.Text = objComites.ID_SC
        '''            txtGT.Text = objComites.ID_GT

        '''            iCaso = 3

        '''        End If

        '''        If array_texto.Length <= 3 Then

        '''            txtSC.Text = ""
        '''        Else
        '''            objComites.Bandera = 3
        '''            objComites.ID_Comite = array_texto(1)
        '''            objComites.ID_CT = array_texto(2)

        '''            If Microsoft.VisualBasic.Left(array_texto(3), 2) = "GT" Then
        '''                objComites.Bandera = 4
        '''                objComites.ID_SC = "NA"
        '''                objComites.ID_GT = array_texto(3)
        '''                GoTo GT
        '''            End If

        '''            objComites.ID_SC = array_texto(3)
        '''            objComites.Busca_tres()
        '''            txtComite.Text = objComites.ID_Comite
        '''            txtCT.Text = objComites.ID_CT
        '''            txtSC.Text = objComites.ID_SC
        '''            txtGT.Text = objComites.ID_GT

        '''            iCaso = 4
        '''            'cmdBusca3.Dispose()
        '''        End If

        '''        If array_texto.Length <= 4 Then
        '''            txtGT.Text = ""
        '''        Else
        '''            objComites.Bandera = 4
        '''            objComites.ID_Comite = array_texto(1)
        '''            objComites.ID_CT = array_texto(2)
        '''            objComites.ID_SC = array_texto(3)
        '''            objComites.ID_GT = array_texto(4)

        '''GT:         'esta salto de l�nea es para cuando un Comite o CT tiene un GT directo

        '''            objComites.Busca_cuatro()
        '''            txtComite.Text = objComites.ID_Comite
        '''            txtCT.Text = objComites.ID_CT
        '''            txtSC.Text = objComites.ID_SC
        '''            txtGT.Text = objComites.ID_GT

        '''            iCaso = 5
        '''            'cmdBusca4.Dispose()
        '''        End If

        '''        If array_texto.Length > 5 Then
        '''            iCaso = 6
        '''        End If

    End Sub
#End Region

    Sub Inicializa_Inactivos()
        'Pesta�a Normas
        Checador(chkFecDeclaracion, chkFec_Envio_DGN, chkNMXNuevas, chkAdoptadas, chkQuinquenal, chkRatificacion, chkResponsable)
        Inactivos(txtDelVigencia, dtkDelVigencia, txtAlVigencia, dtkAlVigencia)
        Inactivos(txtDelDGN, dtkDelDGN, txtAlDGN, dtkAlDGN)
        optNuevas.Checked = True
        'Inactivos(txtDelNMXNuevas, dtkDelNMXNuevas, txtAlNMXNuevas, dtkAlNMXNuevas, optNuevas, optModificadas)
        Inactivos(optNuevas, optModificadas)

        optAdoptadas.Checked = True
        Inactivos(optAdoptadas, optArmonizadas, optReferidasNom, optReferidasNMX, optReferidasNRF, optConcordanciaInternacional)
        Inactivos(txtDelQuinquenal, dtkDelQuinquenal, txtAlQuinquenal, dtkAlQuinquenal)
        Inactivos(txtDelRatificacion, dtkDelRatificacion, txtAlRatificacion, dtkAlRatificacion)
        Inactivos(txtResponsable, cboResponsable)

        'Pesta�a Proyecto
        Checador(chkProyenComentarios, chkProyConComentarios, chkProyFinales, chkDOF, chkProyAprobados, chkResponsableProy, chkRemitidasDGN)
        Inactivos(txtDelProyenComentarios, dtkDelProyenComentarios, txtAlProyenComentarios, dtkAlProyenComentarios)
        Inactivos(txtDelProyConComentarios, dtkDelProyConComentarios, txtAlProyConComentarios, dtkAlProyConComentarios)
        Inactivos(txtDelProyFinales, dtkDelProyFinales, txtAlProyFinales, dtkAlProyFinales)
        Inactivos(txtDelDOF, dtkDelDOF, txtAlDOF, dtkAlDOF)
        Inactivos(txtDelProyAprobados, dtkdelProyAprobados, txtAlProyAprobados, dtkAlProyAprobados)
        Inactivos(txtResponsableProy, cboResponsableProy)
        Inactivos(txtDelRemitidasDGN, dtkDelRemitidasDGN, txtAlRemitidasDGN, dtkAlRemitidasDGN)

        'Pesta�a Anteproyecto
        Checador(chkResponsableAnt, chkClasificacionAnt)
        Inactivos(txtResponsableAnt, cboResponsableAnt)
        Inactivos(txtClasificacionAnt, cboClasificacionAnt)

        'Pesta�a Documento de Trabajo
        Checador(chkResponsableDT, chkPeriodoDT)
        Inactivos(txtResponsableDT, cboResponsableDT)
        Inactivos(txtDelPeriodoDT, dtkDelPeriodoDT, txtalPeriodoDT, dtkAlPeriodoDT)

    End Sub

    Sub Limpia_Campos_Inactivos()
        'Pesta�a Normas
        Limpia_Campos(txtDelVigencia, txtAlVigencia)
        Limpia_Campos(txtDelDGN, txtAlDGN)
        'Limpia_Campos(txtDelNMXNuevas, txtAlNMXNuevas)
        Limpia_Campos(txtDelQuinquenal, txtAlQuinquenal)
        Limpia_Campos(txtDelRatificacion, txtAlRatificacion)
        Limpia_Campos(txtResponsable)

        'Pesta�a Proyecto
        Limpia_Campos(txtDelProyenComentarios, txtAlProyenComentarios)
        Limpia_Campos(txtDelProyConComentarios, txtAlProyConComentarios)
        Limpia_Campos(txtDelProyFinales, txtAlProyFinales)
        Limpia_Campos(txtDelDOF, txtAlDOF)
        Limpia_Campos(txtDelProyAprobados, txtAlProyAprobados)
        Limpia_Campos(txtResponsableProy)
        Limpia_Campos(txtDelRemitidasDGN, txtAlRemitidasDGN)

        'Pesta�a Anteproyecto
        Limpia_Campos(txtResponsableAnt)
        Limpia_Campos(txtClasificacionAnt)

        'Pesta�a Documento de Trabajo
        Limpia_Campos(txtResponsableAnt)
        Limpia_Campos(txtDelPeriodoDT, txtalPeriodoDT)

    End Sub

    Sub Buscar()
        grdNormasAdoptadas.DataSource = Nothing

        If tclNormas.SelectedTab Is tclNormas.TabPages(0) Then
            Call Arma_where_Normas()
            objQ_Normas.Bandera = 1
            objQ_Normas.sqlNormas = sqlNormas
            grdNormas.DataSource = Nothing
            grdNormas.DataSource = objQ_Normas.Consulta_Normas
            dt_Excel = grdNormas.DataSource
            txtTotal.Text = dt_Excel.Rows.Count
        End If

        If tclNormas.SelectedTab Is tclNormas.TabPages(1) Then
            Call Arma_where_Proyecto()
            objQ_Normas.Bandera = 3
            objQ_Normas.sqlProyecto = sqlProyecto
            grdNormas.DataSource = Nothing
            grdNormas.DataSource = objQ_Normas.Consulta_Normas
            dt_Excel = grdNormas.DataSource
            txtTotal.Text = dt_Excel.Rows.Count
        End If

        If tclNormas.SelectedTab Is tclNormas.TabPages(2) Then
            Call Arma_where_Anteproyecto()
            objQ_Normas.Bandera = 5
            objQ_Normas.sqlAnteproyecto = sqlAnteproyecto
            grdNormas.DataSource = Nothing
            grdNormas.DataSource = objQ_Normas.Consulta_Normas
            dt_Excel = grdNormas.DataSource
            txtTotal.Text = dt_Excel.Rows.Count
        End If

        If tclNormas.SelectedTab Is tclNormas.TabPages(3) Then
            Call Arma_where_DT()
            objQ_Normas.Bandera = 7
            objQ_Normas.sqlDT = sqlDT
            grdNormas.DataSource = Nothing
            grdNormas.DataSource = objQ_Normas.Consulta_Normas
            dt_Excel = grdNormas.DataSource
            txtTotal.Text = dt_Excel.Rows.Count
        End If

    End Sub

    Private Sub Arma_where_Normas()
        sqlNormas = " WHERE"

        If iCaso = 2 And txtComite.Text <> "" Then 'COMITE
            sqlNormas += " C_Normas.ID_Comite = '" + txtComite.Text + "' AND"
        End If

        If iCaso = 3 And txtCT.Text <> "NA" Then 'CT
            sqlNormas += " C_Normas.ID_Comite = '" + txtComite.Text + "' AND"
            sqlNormas += " C_Normas.ID_CT = '" + txtCT.Text + "' AND"
        End If

        If iCaso = 4 And txtSC.Text <> "NA" Then 'SC
            sqlNormas += " C_Normas.ID_Comite = '" + txtComite.Text + "' AND"
            sqlNormas += " C_Normas.ID_CT = '" + txtCT.Text + "' AND"
            sqlNormas += " C_Normas.ID_SC = '" + txtSC.Text + "' AND"
        End If

        If iCaso = 5 And txtGT.Text <> "NA" Then 'GT
            sqlNormas += " C_Normas.ID_Comite = '" + txtComite.Text + "' AND"
            sqlNormas += " C_Normas.ID_CT = '" + txtCT.Text + "' AND"
            sqlNormas += " C_Normas.ID_SC = '" + txtSC.Text + "' AND"
            sqlNormas += " C_Normas.ID_Grupo = '" + txtGT.Text + "' AND"
        End If


        If chkFecDeclaracion.Checked = True Then
            sqlNormas += " C_Normas.F_Decla_Vigencia >= CONVERT(DATETIME, '" + txtDelVigencia.Text + "') AND"
            sqlNormas += " C_Normas.F_Decla_Vigencia <= CONVERT(DATETIME, '" + txtAlVigencia.Text + "') AND"
        End If

        If chkFec_Envio_DGN.Checked = True Then
            sqlNormas += " P_Avance_Temas_Fechas.F_ACUSE_DGN_PROYF >= CONVERT(DATETIME, '" + txtDelDGN.Text + "') AND"
            sqlNormas += " P_Avance_Temas_Fechas.F_ACUSE_DGN_PROYF <= CONVERT(DATETIME, '" + txtAlDGN.Text + "') AND"
        End If

        If chkNMXNuevas.Checked = True Then
            If optNuevas.Checked = True Then
                sqlNormas += " C_Normas_Canceladas.Norma_Cancelada IS NULL AND C_Normas.Observaciones IS NULL AND"
            ElseIf optModificadas.Checked = True Then
                sqlNormas += " C_Normas_Canceladas.Norma_Cancelada IS NOT NULL OR C_Normas.Observaciones IS NOT NULL AND"
            End If
        End If

        If chkAdoptadas.Checked = True Then

        End If

        If chkQuinquenal.Checked = True Then
            sqlNormas += " C_Normas.F_Revi_Quinquenal >= CONVERT(DATETIME, '" + txtDelQuinquenal.Text + "') AND"
            sqlNormas += " C_Normas.F_Revi_Quinquenal <= CONVERT(DATETIME, '" + txtAlQuinquenal.Text + "') AND"
        End If

        If chkRatificacion.Checked = True Then
            sqlNormas += " C_Normas.F_Noti_Ratificacion >= CONVERT(DATETIME, '" + txtDelRatificacion.Text + "') AND"
            sqlNormas += " C_Normas.F_Noti_Ratificacion <= CONVERT(DATETIME, '" + txtAlRatificacion.Text + "') AND"
        End If

        If chkResponsable.Checked = True Then
            sqlNormas += " C_Normas.Resp_Publicacion = '" + cboResponsable.SelectedValue + "' AND"
        End If

        If Microsoft.VisualBasic.Right(sqlNormas, 3) = "AND" Then
            sqlNormas = Microsoft.VisualBasic.Left(sqlNormas, sqlNormas.Length - 3) 'si trae AND
        Else
            sqlNormas = Microsoft.VisualBasic.Left(sqlNormas, sqlNormas.Length - 5) 'si trae WHERE
        End If

        sqlNormas += " ORDER BY C_Normas.Clasificacion ASC"
    End Sub


    Sub NormasAdoptadas()
        sqlNormasAdoptadas = " WHERE C_Normas_Detalle.Clasificacion = '" + sqlNormaClasificacion + "' AND"
        ' (dbo.C_Normas_Detalle.ID_Tipo_Norma = 1)

        'WHERE     (dbo.C_Normas_Detalle.Clasificacion = 'NMX-SFDF-SFDF-SDF-2006') AND (dbo.C_Tipo_Normas.ID_Tipo_Norma = 1)

        If optAdoptadas.Checked = True Then
            sqlNormasAdoptadas += " C_Normas_Detalle.ID_Tipo_Norma = 1 AND"
        ElseIf optArmonizadas.Checked = True Then
            sqlNormasAdoptadas += " ( C_Normas_Detalle.ID_Tipo_Norma = 2 OR"
            sqlNormasAdoptadas += " C_Normas_Detalle.ID_Tipo_Norma = 3 ) AND"
        ElseIf optReferidasNom.Checked = True Then
            sqlNormasAdoptadas += " C_Normas_Detalle.ID_Tipo_Norma = 4 AND"
        ElseIf optReferidasNMX.Checked = True Then
            sqlNormasAdoptadas += " C_Normas_Detalle.ID_Tipo_Norma = 5 AND"
        ElseIf optReferidasNRF.Checked = True Then
            sqlNormasAdoptadas += " C_Normas_Detalle.ID_Tipo_Norma = 6 AND"
        ElseIf optConcordanciaInternacional.Checked = True Then
            sqlNormasAdoptadas += " C_Normas_Detalle.ID_Tipo_Norma = 7 AND"
        End If


        If Microsoft.VisualBasic.Right(sqlNormasAdoptadas, 3) = "AND" Then
            sqlNormasAdoptadas = Microsoft.VisualBasic.Left(sqlNormasAdoptadas, sqlNormasAdoptadas.Length - 3) 'si trae AND
        Else
            sqlNormasAdoptadas = Microsoft.VisualBasic.Left(sqlNormasAdoptadas, sqlNormasAdoptadas.Length - 5) 'si trae WHERE
        End If
        sqlNormasAdoptadas += " ORDER BY C_Normas.Clasificacion ASC"

        objQ_Normas.Bandera = 2
        objQ_Normas.sqlNormasAdoptadas = sqlNormasAdoptadas
        grdNormasAdoptadas.DataSource = objQ_Normas.Consulta_Normas

    End Sub


    Private Sub Arma_where_Proyecto()
        sqlProyecto = " AND"

        If iCaso = 2 And txtComite.Text <> "" Then 'COMITE
            sqlProyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
        End If

        If iCaso = 3 And txtCT.Text <> "NA" Then 'CT
            sqlProyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlProyecto += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
        End If

        If iCaso = 4 And txtSC.Text <> "NA" Then 'SC
            sqlProyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlProyecto += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
            sqlProyecto += " P_Prog_Trab.ID_SC = '" + txtSC.Text + "' AND"
        End If

        If iCaso = 5 And txtGT.Text <> "NA" Then 'GT
            sqlProyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlProyecto += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
            sqlProyecto += " P_Prog_Trab.ID_SC = '" + txtSC.Text + "' AND"
            sqlProyecto += " P_Prog_Trab.ID_Grupo = '" + txtGT.Text + "' AND"
        End If


        If chkProyenComentarios.Checked = True Then
            sqlProyecto += " P_Avance_Temas_Fechas.F_Publicacion_ComentarioPublico >= CONVERT(DATETIME, '" + txtDelProyenComentarios.Text + "') AND"
            sqlProyecto += " P_Avance_Temas_Fechas.F_Limite_ComentarioPublico <= CONVERT(DATETIME, '" + txtAlProyenComentarios.Text + "') AND"
        End If

        '*******este se dispara en el otro grid
        If chkProyConComentarios.Checked = True Then
            sqlProyecto += " P_Avance_Temas_Fechas.F_Limite_Aprobacion_Resolucion_ComentarioPublico  >= CONVERT(DATETIME, '" + txtDelDGN.Text + "') AND"
            sqlProyecto += " P_Avance_Temas_Fechas.F_Limite_Aprobacion_Resolucion_ComentarioPublico  <= CONVERT(DATETIME, '" + txtAlDGN.Text + "') AND"
        End If

        If chkProyFinales.Checked = True Then
            sqlProyecto += " P_Avance_Temas_Fechas.F_Limite_Aprobacion_Resolucion_ComentarioPublico  >= CONVERT(DATETIME, '" + txtDelProyFinales.Text + "') AND"
            sqlProyecto += " P_Avance_Temas_Fechas.F_Limite_Aprobacion_Resolucion_ComentarioPublico  <= CONVERT(DATETIME, '" + txtAlProyFinales.Text + "') AND"
        End If

        ''''*****este ya no va
        '''If chkDOF.Checked = True Then
        '''End If

        If chkProyAprobados.Checked = True Then
            sqlProyecto += " P_Avance_Temas_Fechas.F_CARGA_PROYF >= CONVERT(DATETIME, '" + txtDelProyAprobados.Text + "') AND"
            sqlProyecto += " P_Avance_Temas_Fechas.F_CARGA_PROYF <= CONVERT(DATETIME, '" + txtAlProyAprobados.Text + "') AND"
        End If

        If chkResponsableProy.Checked = True Then
            sqlProyecto += " P_Proy.Responsable  = '" + cboResponsableProy.SelectedValue + "' AND"
        End If

        If chkRemitidasDGN.Checked = True Then
            sqlProyecto += " P_Avance_Temas_Fechas.F_ACUSE_DGN_PROYF >= CONVERT(DATETIME, '" + txtDelRemitidasDGN.Text + "') AND"
            sqlProyecto += " P_Avance_Temas_Fechas.F_ACUSE_DGN_PROYF <= CONVERT(DATETIME, '" + txtAlRemitidasDGN.Text + "') AND"
        End If


        If Microsoft.VisualBasic.Right(sqlProyecto, 3) = "AND" Then
            sqlProyecto = Microsoft.VisualBasic.Left(sqlProyecto, sqlProyecto.Length - 3) 'si trae AND
        Else
            sqlProyecto = Microsoft.VisualBasic.Left(sqlProyecto, sqlProyecto.Length - 5) 'si trae WHERE
        End If

        sqlProyecto += " ORDER BY P_Proy.Clasificacion ASC"
    End Sub

    Private Sub Arma_where_Anteproyecto()
        sqlAnteproyecto = " WHERE P_Prog_Trab.ID_etapa = 3 AND p_ant.status <> 10 and p_ant.status <> 11 AND"

        If iCaso = 2 And txtComite.Text <> "" Then 'COMITE
            sqlAnteproyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
        End If

        If iCaso = 3 And txtCT.Text <> "NA" Then 'CT
            sqlAnteproyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlAnteproyecto += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
        End If

        If iCaso = 4 And txtSC.Text <> "NA" Then 'SC
            sqlAnteproyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlAnteproyecto += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
            sqlAnteproyecto += " P_Prog_Trab.ID_SC = '" + txtSC.Text + "' AND"
        End If

        If iCaso = 5 And txtGT.Text <> "NA" Then 'GT
            sqlAnteproyecto += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlAnteproyecto += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
            sqlAnteproyecto += " P_Prog_Trab.ID_SC = '" + txtSC.Text + "' AND"
            sqlAnteproyecto += " P_Prog_Trab.ID_Grupo = '" + txtGT.Text + "' AND"
        End If


        If chkResponsableAnt.Checked = True Then
            sqlAnteproyecto += " P_Ant.Responsable  = '" + cboResponsableAnt.SelectedValue + "' AND"
        End If

        If chkClasificacionAnt.Checked = True Then
            sqlAnteproyecto += " P_Ant.Clasificacion  = '" + cboClasificacionAnt.SelectedValue + "' AND"
        End If



        If Microsoft.VisualBasic.Right(sqlAnteproyecto, 3) = "AND" Then
            sqlAnteproyecto = Microsoft.VisualBasic.Left(sqlAnteproyecto, sqlAnteproyecto.Length - 3) 'si trae AND
        Else
            sqlAnteproyecto = Microsoft.VisualBasic.Left(sqlAnteproyecto, sqlAnteproyecto.Length - 5) 'si trae WHERE
        End If

        sqlAnteproyecto += " ORDER BY P_Ant.Clasificacion ASC"
    End Sub

    Private Sub Arma_where_DT()
        sqlDT = " WHERE P_Prog_Trab.ID_etapa = 2 AND P_DT.status <> 10 and P_DT.status <> 11 AND"

        If iCaso = 2 And txtComite.Text <> "" Then 'COMITE
            sqlDT += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
        End If


        If iCaso = 3 And txtCT.Text <> "NA" Then 'CT
            sqlDT += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlDT += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
        End If

        If iCaso = 4 And txtSC.Text <> "NA" Then 'SC
            sqlDT += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlDT += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
            sqlDT += " P_Prog_Trab.ID_SC = '" + txtSC.Text + "' AND"
        End If

        If iCaso = 5 And txtGT.Text <> "NA" Then 'GT
            sqlDT += " P_Prog_Trab.ID_Comite = '" + txtComite.Text + "' AND"
            sqlDT += " P_Prog_Trab.ID_CT = '" + txtCT.Text + "' AND"
            sqlDT += " P_Prog_Trab.ID_SC = '" + txtSC.Text + "' AND"
            sqlDT += " P_Prog_Trab.ID_Grupo = '" + txtGT.Text + "' AND"
        End If

        If chkPeriodoDT.Checked = True Then
            sqlDT += " P_Avance_Temas_Fechas.F_Carga_ActaAprobacion >= CONVERT(DATETIME, '" + txtDelPeriodoDT.Text + "') AND"
            sqlDT += " P_Avance_Temas_Fechas.F_Carga_ActaAprobacion <= CONVERT(DATETIME, '" + txtalPeriodoDT.Text + "') AND"
        End If

        If chkResponsableDT.Checked = True Then
            sqlDT += "  P_DT.Responsable  = '" + cboResponsableDT.SelectedValue + "' AND"
        End If

        If Microsoft.VisualBasic.Right(sqlDT, 3) = "AND" Then
            sqlDT = Microsoft.VisualBasic.Left(sqlDT, sqlDT.Length - 3) 'si trae AND
        Else
            sqlDT = Microsoft.VisualBasic.Left(sqlDT, sqlDT.Length - 5) 'si trae WHERE
        End If

        sqlDT += " ORDER BY  P_DT.Clasificacion ASC"
    End Sub
    Sub Formato_Grid(ByVal grd As Object)
        Dim dgEstiloGrid As New DataGridTableStyle
        'Tabla_Color(dgEstiloGrid, grd)

        With dgEstiloGrid
            .AlternatingBackColor = Color.GhostWhite
            .BackColor = Color.GhostWhite
            .ForeColor = Color.MidnightBlue
            .GridLineColor = Color.RoyalBlue
            .HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .HeaderForeColor = Color.Lavender
            .SelectionBackColor = Color.Teal
            .SelectionForeColor = Color.PaleGreen
            .RowHeaderWidth = 20 'ajusta el tama�o de la columna de la izquierda que trae el grid
            .RowHeadersVisible = False
            .ColumnHeadersVisible = False '
            .MappingName = "C_Normas" 'el nombre que regresa el dataset
            '.ReadOnly = True
        End With
    End Sub

    Sub Formato_GridAdoptadas(ByVal grd As Object)
        Dim dgEstiloGrid As New DataGridTableStyle
        'Tabla_Color(dgEstiloGrid, grd)

        With dgEstiloGrid
            .AlternatingBackColor = Color.GhostWhite
            .BackColor = Color.GhostWhite
            .ForeColor = Color.MidnightBlue
            .GridLineColor = Color.RoyalBlue
            .HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            .HeaderForeColor = Color.Lavender
            .SelectionBackColor = Color.Teal
            .SelectionForeColor = Color.PaleGreen
            .RowHeaderWidth = 20 'ajusta el tama�o de la columna de la izquierda que trae el grid
            .RowHeadersVisible = False
            .ColumnHeadersVisible = False '
            .MappingName = "C_NormasAdoptadas" 'el nombre que regresa el dataset
            '.ReadOnly = True
        End With
    End Sub

    Private Sub dtkDelVigencia_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelVigencia.ValueChanged
        If chkFecDeclaracion.Checked = True Then
            txtDelVigencia.Text = Format(dtkDelVigencia.Value, "dd/MM/yyyy")
            dtkAlVigencia.Enabled = True
            dtkAlVigencia.Value = dtkDelVigencia.Value
        End If
    End Sub


    Private Sub dtkAlVigencia_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlVigencia.ValueChanged
        ''If chkFecDeclaracion.Checked = True Then
        ''    txtAlVigencia.Text = Format(dtkAlVigencia.Value, "dd/MM/yyyy")
        ''    If txtDelVigencia.Text > txtAlVigencia.Text Then
        ''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        ''        'txtDelVigencia.Text = ""
        ''        txtAlVigencia.Text = ""
        ''        Exit Sub
        ''    End If
        ''End If

        If CStr(dtkDelVigencia.Value) = "" And CStr(dtkAlVigencia.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkFecDeclaracion, "")
            valreturn = False
        ElseIf Not dtkDelVigencia.Value > dtkAlVigencia.Value Then
            ErrorProvider1.SetError(chkFecDeclaracion, "")
            txtAlVigencia.Text = Format(dtkAlVigencia.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkFecDeclaracion, "Error")
            valreturn = False
            txtAlVigencia.Text = ""
        End If

    End Sub


    Private Sub dtkDelDGN_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelDGN.ValueChanged
        If chkFec_Envio_DGN.Checked = True Then
            txtDelDGN.Text = Format(dtkDelDGN.Value, "dd/MM/yyyy")
            dtkAlDGN.Enabled = True
            dtkAlDGN.Value = dtkDelDGN.Value
        End If
    End Sub

    Private Sub dtkAlDGN_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlDGN.ValueChanged
        '''If chkFec_Envio_DGN.Checked = True Then
        '''    ''If sTipoProceso = "Agregar" Or sTipoProceso = "Editar" Then
        '''    txtAlDGN.Text = Format(dtkAlDGN.Value, "dd/MM/yyyy")
        '''    If txtDelDGN.Text > txtAlDGN.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        'txtDelDGN.Text = ""
        '''        txtAlDGN.Text = ""
        '''        Exit Sub
        '''    End If
        '''    ''End If
        '''End If

        If CStr(dtkDelDGN.Value) = "" And CStr(dtkAlDGN.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkFec_Envio_DGN, "")
            valreturn = False
        ElseIf Not dtkDelDGN.Value > dtkAlDGN.Value Then
            ErrorProvider1.SetError(chkFec_Envio_DGN, "")
            txtAlDGN.Text = Format(dtkAlDGN.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkFec_Envio_DGN, "Error")
            valreturn = False
            txtAlDGN.Text = ""
        End If
    End Sub


    '''Private Sub dtkAlDGN_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtkAlDGN.TextChanged
    '''    txtAlDGN.Text = Format(dtkAlDGN.Value, "dd/MM/yyyy")
    '''    If txtDelDGN.Text > txtAlDGN.Text Then
    '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
    '''        'txtDelDGN.Text = ""
    '''        txtAlDGN.Text = ""
    '''        Exit Sub
    '''    End If
    '''End Sub

    Private Sub dtkDelQuinquenal_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelQuinquenal.ValueChanged
        If chkQuinquenal.Checked = True Then
            txtDelQuinquenal.Text = Format(dtkDelQuinquenal.Value, "dd/MM/yyyy")
            dtkAlQuinquenal.Enabled = True
            dtkAlQuinquenal.Value = dtkDelQuinquenal.Value
        End If
    End Sub

    Private Sub dtkAlQuinquenal_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlQuinquenal.ValueChanged
        '''If chkQuinquenal.Checked = True Then
        '''    txtAlQuinquenal.Text = Format(dtkAlQuinquenal.Value, "dd/MM/yyyy")
        '''    If txtDelQuinquenal.Text > txtAlQuinquenal.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlQuinquenal.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelQuinquenal.Value) = "" And CStr(dtkAlQuinquenal.Value) = "" Then
            ErrorProvider1.SetError(chkQuinquenal, "Debes seleccionar la fecha de tu periodo de busqueda")
            valreturn = False
        ElseIf Not dtkDelVigencia.Value > dtkAlVigencia.Value Then
            ErrorProvider1.SetError(chkFecDeclaracion, "")
            txtAlQuinquenal.Text = Format(dtkAlQuinquenal.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkQuinquenal, "Error")
            valreturn = False
            txtAlQuinquenal.Text = ""
        End If
    End Sub

    Private Sub dtkDelRatificacion_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelRatificacion.ValueChanged
        If chkRatificacion.Checked = True Then
            txtDelRatificacion.Text = Format(dtkDelRatificacion.Value, "dd/MM/yyyy")
            dtkAlRatificacion.Enabled = True
            dtkAlRatificacion.Value = dtkDelRatificacion.Value
        End If
    End Sub

    Private Sub dtkAlRatificacion_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlRatificacion.ValueChanged
        '''If chkRatificacion.Checked = True Then
        '''    txtAlRatificacion.Text = Format(dtkAlRatificacion.Value, "dd/MM/yyyy")
        '''    If txtDelRatificacion.Text > txtAlRatificacion.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlRatificacion.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelRatificacion.Value) = "" And CStr(dtkAlRatificacion.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkRatificacion, "")
            valreturn = False
        ElseIf Not dtkDelRatificacion.Value > dtkAlRatificacion.Value Then
            ErrorProvider1.SetError(chkRatificacion, "")
            txtAlRatificacion.Text = Format(dtkAlRatificacion.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkRatificacion, "Error")
            valreturn = False
            txtAlRatificacion.Text = ""
        End If

    End Sub

    Private Sub cboResponsable_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsable.SelectedIndexChanged
        txtResponsable.Text = cboResponsable.SelectedValue
        If txtResponsable.Text <> "" Then
            objEmpleados.Bandera = 3
            objEmpleados.Id_usuario = txtResponsable.Text
            objEmpleados.Buscar()
            If IsDBNull(objEmpleados.NOMBRE_COMPLETO) Then
                txtResponsable.Visible = False
            Else
                txtResponsable.Text = objEmpleados.NOMBRE_COMPLETO
            End If
        End If
    End Sub

    'Sub llena_responsable(ByVal responsable As String)
    Sub llena_responsable(ByVal cbo As ComboBox)
        objEmpleados.Bandera = 6
        objEmpleados.ID_Area = "12"
        objEmpleados.ListaCombo(cbo)
        'objEmpleados.ListaCombo(cboResponsableProy)
        'objEmpleados.ListaCombo(cboResponsableAnt)
        'objEmpleados.ListaCombo(cboResponsableDT)
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        With tlbBotonera
            Select Case tlbBotonera.Buttons.IndexOf(e.Button)
                Case 0
                    Call Buscar()
                Case 1


                Case 2
                    dt_Excel = grdNormas.DataSource
                    If dt_Excel Is Nothing Or IsDBNull(dt_Excel) Then
                        Exit Sub
                    End If
                    DataTableToExcel(CType(Me.dt_Excel, DataTable))
                Case 3 'exportar
                    Me.Close()

            End Select
        End With
        Cursor.Current = Cursors.Default
    End Sub


   


    Private Sub chkFecDeclaracion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFecDeclaracion.CheckedChanged
        If chkFecDeclaracion.Checked = False Then
            dtkDelVigencia.Enabled = False
            dtkAlVigencia.Enabled = False
            txtAlVigencia.Text = ""
            txtDelVigencia.Text = ""
            ErrorProvider1.SetError(chkFecDeclaracion, "")
        ElseIf chkFecDeclaracion.Checked = True Then
            dtkDelVigencia.Enabled = True
        End If
    End Sub

    Private Sub chkFec_Envio_DGN_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFec_Envio_DGN.CheckedChanged
        If chkFec_Envio_DGN.Checked = False Then
            dtkDelDGN.Enabled = False
            dtkAlDGN.Enabled = False
            txtAlDGN.Text = ""
            txtDelDGN.Text = ""
            ErrorProvider1.SetError(chkFec_Envio_DGN, "")
        ElseIf chkFec_Envio_DGN.Checked = True Then
            dtkDelDGN.Enabled = True
        End If
    End Sub

    Private Sub chkNMXNuevas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNMXNuevas.CheckedChanged
        If chkNMXNuevas.Checked = False Then
            optNuevas.Enabled = False
            optModificadas.Enabled = False
        ElseIf chkNMXNuevas.Checked = True Then
            optNuevas.Enabled = True
            optModificadas.Enabled = True
            'dtkDelNMXNuevas.Enabled = True
        End If
    End Sub

    Private Sub chkAdoptadas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAdoptadas.CheckedChanged
        If chkAdoptadas.Checked = False Then
            Inactivos(optAdoptadas, optArmonizadas, optReferidasNom, optReferidasNMX, optReferidasNRF, optConcordanciaInternacional)
        ElseIf chkAdoptadas.Checked = True Then
            Activos(optAdoptadas, optArmonizadas, optReferidasNom, optReferidasNMX, optReferidasNRF, optConcordanciaInternacional)
            ErrorProvider1.SetError(chkAdoptadas, "")
        End If
    End Sub

    Private Sub chkQuinquenal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkQuinquenal.CheckedChanged
        If chkQuinquenal.Checked = False Then
            dtkDelQuinquenal.Enabled = False
            dtkAlQuinquenal.Enabled = False
            txtAlQuinquenal.Text = ""
            txtDelQuinquenal.Text = ""
            ErrorProvider1.SetError(chkQuinquenal, "")
        ElseIf chkQuinquenal.Checked = True Then
            dtkDelQuinquenal.Enabled = True
        End If
    End Sub

    Private Sub chkRatificacion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRatificacion.CheckedChanged
        If chkRatificacion.Checked = False Then
            dtkDelRatificacion.Enabled = False
            dtkAlRatificacion.Enabled = False
            txtAlRatificacion.Text = ""
            txtDelRatificacion.Text = ""
            ErrorProvider1.SetError(chkRatificacion, "") 'chk
        ElseIf chkRatificacion.Checked = True Then
            dtkDelRatificacion.Enabled = True
        End If
    End Sub

    Private Sub chkResponsable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkResponsable.CheckedChanged
        If chkResponsable.Checked = False Then
            cboResponsable.Enabled = False
            'txtResponsable.Text = ""
        ElseIf chkResponsable.Checked = True Then
            cboResponsable.Enabled = True
        End If
    End Sub

    Private Sub grdNormas_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdNormas.DoubleClick
        If tclNormas.SelectedTab Is tclNormas.TabPages(0) Then 'NORMAS
            If chkAdoptadas.Checked = True Then
                'If grdNormas.DataSource = Nothing Or grdNormas.DataSource Is Nothing Then
                If grdNormas.DataSource Is Nothing Or IsDBNull(grdNormas.Item(grdNormas.CurrentRowIndex, 0)) Then
                    Exit Sub
                End If
                sqlNormaClasificacion = grdNormas.Item(grdNormas.CurrentRowIndex, 0)
                Call NormasAdoptadas()
            Else
                MsgBox("Debes seleccionar un criterio de busqueda en 'ADOPTADAS'", MsgBoxStyle.Information, "Normas Adoptadas")
                ErrorProvider1.SetError(chkAdoptadas, "Selecciona una opci�n")
            End If
        End If

        If tclNormas.SelectedTab Is tclNormas.TabPages(1) Then 'PROYECTO
        End If

        If tclNormas.SelectedTab Is tclNormas.TabPages(2) Then 'ANTEPROYECTO
        End If

        If tclNormas.SelectedTab Is tclNormas.TabPages(3) Then 'DOCUMENTO DE TRABAJO
        End If

    End Sub

    Private Sub chkProyenComentarios_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkProyenComentarios.CheckedChanged
        If chkProyenComentarios.Checked = False Then
            dtkDelProyenComentarios.Enabled = False
            dtkAlProyenComentarios.Enabled = False
            txtAlProyenComentarios.Text = ""
            txtDelProyenComentarios.Text = ""
            ErrorProvider1.SetError(chkProyenComentarios, "") 'chk
        ElseIf chkProyenComentarios.Checked = True Then
            dtkDelProyenComentarios.Enabled = True
        End If
    End Sub

    Private Sub chkProyConComentarios_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkProyConComentarios.CheckedChanged
        If chkProyConComentarios.Checked = False Then
            dtkDelProyConComentarios.Enabled = False
            dtkAlProyConComentarios.Enabled = False
            txtAlProyConComentarios.Text = ""
            txtDelProyConComentarios.Text = ""
            ErrorProvider1.SetError(chkProyConComentarios, "") 'chk
        ElseIf chkProyConComentarios.Checked = True Then
            dtkDelProyConComentarios.Enabled = True
        End If
    End Sub

    Private Sub chkProyFinales_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkProyFinales.CheckedChanged
        If chkProyFinales.Checked = False Then
            dtkDelProyFinales.Enabled = False
            dtkAlProyFinales.Enabled = False
            txtAlProyFinales.Text = ""
            txtDelProyFinales.Text = ""
            ErrorProvider1.SetError(chkProyFinales, "") 'chk
        ElseIf chkProyFinales.Checked = True Then
            dtkDelProyFinales.Enabled = True
        End If
    End Sub

    Private Sub chkDOF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDOF.CheckedChanged
        If chkDOF.Checked = False Then
            dtkDelDOF.Enabled = False
            dtkAlDOF.Enabled = False
            txtAlDOF.Text = ""
            txtDelDOF.Text = ""
            ErrorProvider1.SetError(chkDOF, "") 'chk
        ElseIf chkDOF.Checked = True Then
            dtkDelDOF.Enabled = True
        End If
    End Sub

    Private Sub chkProyAprobados_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkProyAprobados.CheckedChanged
        If chkProyAprobados.Checked = False Then
            dtkdelProyAprobados.Enabled = False
            dtkAlProyAprobados.Enabled = False
            txtAlProyAprobados.Text = ""
            txtDelProyAprobados.Text = ""
            ErrorProvider1.SetError(chkProyAprobados, "") 'chk
        ElseIf chkProyAprobados.Checked = True Then
            dtkdelProyAprobados.Enabled = True
        End If
    End Sub

    Private Sub chkResponsableProy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkResponsableProy.CheckedChanged
        If chkResponsableProy.Checked = False Then
            cboResponsableProy.Enabled = False
        ElseIf chkResponsableProy.Checked = True Then
            cboResponsableProy.Enabled = True
        End If
    End Sub

    Private Sub chkRemitidasDGN_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRemitidasDGN.CheckedChanged
        If chkRemitidasDGN.Checked = False Then
            dtkDelRemitidasDGN.Enabled = False
            dtkAlRemitidasDGN.Enabled = False
            txtAlRemitidasDGN.Text = ""
            txtDelRemitidasDGN.Text = ""
            ErrorProvider1.SetError(chkRemitidasDGN, "") 'chk
        ElseIf chkRemitidasDGN.Checked = True Then
            dtkDelRemitidasDGN.Enabled = True
        End If
    End Sub

    Private Sub dtkDelProyenComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelProyenComentarios.ValueChanged
        If chkProyenComentarios.Checked = True Then
            If chkProyenComentarios.Checked = True Then
                txtDelProyenComentarios.Text = Format(dtkDelProyenComentarios.Value, "dd/MM/yyyy")
                dtkAlProyenComentarios.Enabled = True
                dtkAlProyenComentarios.Value = dtkDelProyenComentarios.Value
            End If
        End If
    End Sub

    Private Sub dtkAlProyenComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlProyenComentarios.ValueChanged
        '''If chkProyenComentarios.Checked = True Then
        '''    txtAlProyenComentarios.Text = Format(dtkAlProyenComentarios.Value, "dd/MM/yyyy")
        '''    If txtDelProyenComentarios.Text > txtAlProyenComentarios.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlProyenComentarios.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelProyenComentarios.Value) = "" And CStr(dtkAlProyenComentarios.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkProyenComentarios, "")
            valreturn = False
        ElseIf Not dtkDelProyenComentarios.Value > dtkAlProyenComentarios.Value Then
            ErrorProvider1.SetError(chkProyenComentarios, "")
            txtAlProyenComentarios.Text = Format(dtkAlProyenComentarios.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkProyenComentarios, "Error")
            valreturn = False
            txtAlProyenComentarios.Text = ""
        End If
    End Sub

    Private Sub dtkDelProyConComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelProyConComentarios.ValueChanged
        If chkProyConComentarios.Checked = True Then
            txtDelProyConComentarios.Text = Format(dtkDelProyConComentarios.Value, "dd/MM/yyyy")
            dtkAlProyConComentarios.Enabled = True
            dtkAlProyConComentarios.Value = dtkDelProyConComentarios.Value
        End If
    End Sub

    Private Sub dtkAlProyConComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlProyConComentarios.ValueChanged
        '''If chkProyConComentarios.Checked = True Then
        '''    txtAlProyConComentarios.Text = Format(dtkAlProyConComentarios.Value, "dd/MM/yyyy")
        '''    If txtDelProyConComentarios.Text > txtAlProyConComentarios.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlProyConComentarios.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelProyConComentarios.Value) = "" And CStr(dtkAlProyConComentarios.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkProyConComentarios, "")
            valreturn = False
        ElseIf Not dtkDelProyConComentarios.Value > dtkAlProyConComentarios.Value Then
            ErrorProvider1.SetError(chkProyConComentarios, "")
            txtAlProyConComentarios.Text = Format(dtkAlProyConComentarios.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkProyConComentarios, "Error")
            valreturn = False
            txtAlProyConComentarios.Text = ""
        End If
    End Sub

    Private Sub dtkDelProyFinales_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelProyFinales.ValueChanged
        If chkProyFinales.Checked = True Then
            txtDelProyFinales.Text = Format(dtkDelProyFinales.Value, "dd/MM/yyyy")
            dtkAlProyFinales.Enabled = True
            dtkAlProyFinales.Value = dtkDelProyFinales.Value
        End If
    End Sub

    Private Sub dtkAlProyFinales_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlProyFinales.ValueChanged
        '''If chkProyFinales.Checked = True Then
        '''    txtAlProyFinales.Text = Format(dtkAlProyFinales.Value, "dd/MM/yyyy")
        '''    If txtDelProyFinales.Text > txtAlProyFinales.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlProyFinales.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelProyFinales.Value) = "" And CStr(dtkAlProyFinales.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkProyFinales, "")
            valreturn = False
        ElseIf Not dtkDelProyFinales.Value > dtkAlProyFinales.Value Then
            ErrorProvider1.SetError(chkProyFinales, "")
            txtAlProyFinales.Text = Format(dtkAlProyFinales.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkProyFinales, "Error")
            valreturn = False
            txtAlProyFinales.Text = ""
        End If
    End Sub

    Private Sub dtkDelDOF_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelDOF.ValueChanged
        If chkDOF.Checked = True Then
            txtDelDOF.Text = Format(dtkDelDOF.Value, "dd/MM/yyyy")
            dtkAlDOF.Enabled = True
            dtkAlDOF.Value = dtkDelDOF.Value
        End If

    End Sub

    Private Sub dtkAlDOF_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlDOF.ValueChanged
        '''If chkDOF.Checked = True Then
        '''    txtAlDOF.Text = Format(dtkAlDOF.Value, "dd/MM/yyyy")
        '''    If txtDelDOF.Text > txtAlDOF.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlDOF.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelDOF.Value) = "" And CStr(dtkAlDOF.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkDOF, "")
            valreturn = False
        ElseIf Not dtkDelDOF.Value > dtkAlDOF.Value Then
            ErrorProvider1.SetError(chkDOF, "")
            txtAlDOF.Text = Format(dtkAlDOF.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkDOF, "Error")
            valreturn = False
            txtAlDOF.Text = ""
        End If
    End Sub

    Private Sub dtkdelProyAprobados_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkdelProyAprobados.ValueChanged
        If chkProyAprobados.Checked = True Then
            txtDelProyAprobados.Text = Format(dtkdelProyAprobados.Value, "dd/MM/yyyy")
            dtkAlProyAprobados.Enabled = True
            dtkAlProyAprobados.Value = dtkdelProyAprobados.Value
        End If
    End Sub

    Private Sub dtkAlProyAprobados_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlProyAprobados.ValueChanged
        '''If chkProyAprobados.Checked = True Then
        '''    txtAlProyAprobados.Text = Format(dtkAlProyAprobados.Value, "dd/MM/yyyy")
        '''    If txtDelProyAprobados.Text > txtAlProyAprobados.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlProyAprobados.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkdelProyAprobados.Value) = "" And CStr(dtkAlProyAprobados.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkProyAprobados, "")
            valreturn = False
        ElseIf Not dtkdelProyAprobados.Value > dtkAlProyAprobados.Value Then
            ErrorProvider1.SetError(chkProyAprobados, "")
            txtAlProyAprobados.Text = Format(dtkAlProyAprobados.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkProyAprobados, "Error")
            valreturn = False
            txtAlProyAprobados.Text = ""
        End If
    End Sub

    Private Sub cboResponsableProy_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsableProy.SelectedIndexChanged
        If chkResponsableProy.Checked = False Then
            cboResponsableProy.Enabled = False
        ElseIf chkResponsableProy.Checked = True Then
            cboResponsableProy.Enabled = True
            txtResponsableProy.Text = cboResponsableProy.Text
        End If
    End Sub

    Private Sub dtkDelRemitidasDGN_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelRemitidasDGN.ValueChanged
        If chkRemitidasDGN.Checked = True Then
            txtDelRemitidasDGN.Text = Format(dtkDelRemitidasDGN.Value, "dd/MM/yyyy")
            dtkAlRemitidasDGN.Enabled = True
            dtkAlRemitidasDGN.Value = dtkDelRemitidasDGN.Value
        End If
    End Sub

    Private Sub dtkAlRemitidasDGN_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlRemitidasDGN.ValueChanged
        '''If chkRemitidasDGN.Checked = True Then
        '''    txtAlRemitidasDGN.Text = Format(dtkAlRemitidasDGN.Value, "dd/MM/yyyy")
        '''    If txtDelRemitidasDGN.Text > txtAlRemitidasDGN.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtAlRemitidasDGN.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelRemitidasDGN.Value) = "" And CStr(dtkAlRemitidasDGN.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkRemitidasDGN, "")
            valreturn = False
        ElseIf Not dtkDelRemitidasDGN.Value > dtkAlRemitidasDGN.Value Then
            ErrorProvider1.SetError(chkRemitidasDGN, "")
            txtAlRemitidasDGN.Text = Format(dtkAlRemitidasDGN.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkRemitidasDGN, "Error")
            valreturn = False
            txtAlRemitidasDGN.Text = ""
        End If
    End Sub

    Private Sub chkResponsableAnt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkResponsableAnt.CheckedChanged
        If chkResponsableAnt.Checked = False Then
            cboResponsableAnt.Enabled = False
        ElseIf chkResponsableAnt.Checked = True Then
            cboResponsableAnt.Enabled = True
        End If
    End Sub

    Private Sub chkClasificacionAnt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkClasificacionAnt.CheckedChanged
        If chkClasificacionAnt.Checked = False Then
            cboClasificacionAnt.Enabled = False
        ElseIf chkClasificacionAnt.Checked = True Then
            cboClasificacionAnt.Enabled = True
        End If
    End Sub

    Private Sub cboResponsableAnt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsableAnt.SelectedIndexChanged
        If chkResponsableAnt.Checked = False Then
            cboResponsableAnt.Enabled = False
        ElseIf chkResponsableAnt.Checked = True Then
            cboResponsableAnt.Enabled = True
            txtResponsableAnt.Text = cboResponsableAnt.Text
        End If
    End Sub

    Private Sub cboClasificacionAnt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClasificacionAnt.SelectedIndexChanged
        If chkClasificacionAnt.Checked = False Then
            cboClasificacionAnt.Enabled = False
        ElseIf chkClasificacionAnt.Checked = True Then
            cboClasificacionAnt.Enabled = True
        End If
    End Sub

    Private Sub chkPeriodoDT_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkPeriodoDT.CheckedChanged
        If chkPeriodoDT.Checked = False Then
            dtkDelPeriodoDT.Enabled = False
            dtkAlPeriodoDT.Enabled = False
            txtAlPeriodoDT.Text = ""
            txtDelPeriodoDT.Text = ""
            ErrorProvider1.SetError(chkPeriodoDT, "") 'chk
        ElseIf chkPeriodoDT.Checked = True Then
            dtkDelPeriodoDT.Enabled = True
        End If
    End Sub

    Private Sub chkResponsableDT_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkResponsableDT.CheckedChanged
        If chkResponsableDT.Checked = False Then
            cboResponsableDT.Enabled = False
        ElseIf chkResponsableDT.Checked = True Then
            cboResponsableDT.Enabled = True
        End If
    End Sub

    Private Sub dtkDelPeriodoDT_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkDelPeriodoDT.ValueChanged
        If chkPeriodoDT.Checked = True Then
            txtDelPeriodoDT.Text = Format(dtkDelPeriodoDT.Value, "dd/MM/yyyy")
            dtkAlPeriodoDT.Enabled = True
            dtkAlPeriodoDT.Value = dtkDelPeriodoDT.Value
        End If
    End Sub

    Private Sub dtkAlPeriodoDT_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkAlPeriodoDT.ValueChanged
        '''If chkPeriodoDT.Checked = True Then
        '''    txtalPeriodoDT.Text = Format(dtkAlPeriodoDT.Value, "dd/MM/yyyy")
        '''    If txtDelPeriodoDT.Text > txtalPeriodoDT.Text Then
        '''        MsgBox("La fecha de Fin debe ser Mayor a la de inicio")
        '''        txtalPeriodoDT.Text = ""
        '''        Exit Sub
        '''    End If
        '''End If

        If CStr(dtkDelPeriodoDT.Value) = "" And CStr(dtkAlPeriodoDT.Value) = "La fecha de Fin debe ser Mayor a la de inicio" Then
            ErrorProvider1.SetError(chkPeriodoDT, "")
            valreturn = False
        ElseIf Not dtkDelPeriodoDT.Value > dtkAlPeriodoDT.Value Then
            ErrorProvider1.SetError(chkPeriodoDT, "")
            txtAlPeriodoDT.Text = Format(dtkAlPeriodoDT.Value, "dd/MM/yyyy")
        Else
            ErrorProvider1.SetError(chkPeriodoDT, "Error")
            valreturn = False
            txtAlPeriodoDT.Text = ""
        End If
    End Sub

    Private Sub cboResponsableDT_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboResponsableDT.SelectedIndexChanged
        If chkResponsableDT.Checked = False Then
            cboResponsableDT.Enabled = False
        ElseIf chkResponsableDT.Checked = True Then
            cboResponsableDT.Enabled = True
            txtResponsableDT.Text = cboResponsableDT.Text
        End If
    End Sub

    Private Sub grdNormas_Navigate(ByVal sender As System.Object, ByVal ne As System.Windows.Forms.NavigateEventArgs) Handles grdNormas.Navigate

    End Sub
End Class
