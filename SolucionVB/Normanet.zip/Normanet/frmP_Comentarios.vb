Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class frmP_Comentarios
    Inherits System.Windows.Forms.Form
    Dim objconexion As New clsConexion.cIsConexion
    Dim cn As New SqlConnection
    Dim objComentarios As New clsComentarios.C_Comentarios("Principal", gUsuario, gPasswordSql)

    Dim iCaso As Integer
    Dim dvPNN As DataView
    Dim objComites As New clsComites.clsComites("Principal", gUsuario, gPasswordSql)
    Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Dim oTablaPNN As DataTable
    Dim oTablaDPy As DataTable
    Dim oTablaSC As DataTable
    Dim oTablaGT As DataTable
    Dim sTipoProceso As String
    Private x As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Dim nodo As New TreeNode
    ' defino variable del tipo DataRow
    Dim RegPNN As DataRow
    Dim RegDPy As DataRow
    Dim RegSC As DataRow
    Dim DtCom As DataTable
    Dim Com As DataRow
    Dim RegGT As DataRow
    Dim nodo1 As New TreeNode
    Dim nodo2 As New TreeNode
    Dim array_texto As Array



#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents gpbDatosPersonales As System.Windows.Forms.GroupBox
    Friend WithEvents gbpComentarios As System.Windows.Forms.GroupBox
    Friend WithEvents txtPropuestasCambios As System.Windows.Forms.TextBox
    Friend WithEvents txtComentario As System.Windows.Forms.TextBox
    Friend WithEvents txtParrafo As System.Windows.Forms.TextBox
    Friend WithEvents txtCapituloInciso As System.Windows.Forms.TextBox
    Friend WithEvents cboTipoComentario As System.Windows.Forms.ComboBox
    Friend WithEvents lblTipoComentario As System.Windows.Forms.Label
    Friend WithEvents lblCapituloInciso As System.Windows.Forms.Label
    Friend WithEvents lblParrafo As System.Windows.Forms.Label
    Friend WithEvents lblComentario As System.Windows.Forms.Label
    Friend WithEvents lblPropuestasCambios As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtDomicilio As System.Windows.Forms.TextBox
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents lblNombre As System.Windows.Forms.Label
    Friend WithEvents lblEmpresa As System.Windows.Forms.Label
    Friend WithEvents lblDomicilio As System.Windows.Forms.Label
    Friend WithEvents lblTelefono As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cboClasificacion As System.Windows.Forms.ComboBox
    Friend WithEvents lblPNN As System.Windows.Forms.Label
    Friend WithEvents txtFecLimiteComentarios As System.Windows.Forms.TextBox
    Friend WithEvents txtFecPublicacionConsulta As System.Windows.Forms.TextBox
    Friend WithEvents cboPNN As System.Windows.Forms.ComboBox
    Friend WithEvents lblClasificacion As System.Windows.Forms.Label
    Friend WithEvents lblFecPublicacionConsulta As System.Windows.Forms.Label
    Friend WithEvents lblFecLimiteComentarios As System.Windows.Forms.Label
    Friend WithEvents lblSB As System.Windows.Forms.Label
    Friend WithEvents tvPNN As System.Windows.Forms.TreeView
    Friend WithEvents txtTema As System.Windows.Forms.TextBox
    Friend WithEvents txtPNN As System.Windows.Forms.TextBox
    Friend WithEvents dtkFecPublicacionConsulta As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtkFecLimiteComentarios As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtIdComentarios As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmP_Comentarios))
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.gpbDatosPersonales = New System.Windows.Forms.GroupBox
        Me.gbpComentarios = New System.Windows.Forms.GroupBox
        Me.txtPropuestasCambios = New System.Windows.Forms.TextBox
        Me.txtComentario = New System.Windows.Forms.TextBox
        Me.txtParrafo = New System.Windows.Forms.TextBox
        Me.txtCapituloInciso = New System.Windows.Forms.TextBox
        Me.cboTipoComentario = New System.Windows.Forms.ComboBox
        Me.lblTipoComentario = New System.Windows.Forms.Label
        Me.lblCapituloInciso = New System.Windows.Forms.Label
        Me.lblParrafo = New System.Windows.Forms.Label
        Me.lblComentario = New System.Windows.Forms.Label
        Me.lblPropuestasCambios = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtTelefono = New System.Windows.Forms.TextBox
        Me.txtDomicilio = New System.Windows.Forms.TextBox
        Me.txtEmpresa = New System.Windows.Forms.TextBox
        Me.txtNombre = New System.Windows.Forms.TextBox
        Me.lblNombre = New System.Windows.Forms.Label
        Me.lblEmpresa = New System.Windows.Forms.Label
        Me.lblDomicilio = New System.Windows.Forms.Label
        Me.lblTelefono = New System.Windows.Forms.Label
        Me.lblFax = New System.Windows.Forms.Label
        Me.lblEmail = New System.Windows.Forms.Label
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dtkFecPublicacionConsulta = New System.Windows.Forms.DateTimePicker
        Me.cboClasificacion = New System.Windows.Forms.ComboBox
        Me.lblPNN = New System.Windows.Forms.Label
        Me.txtFecLimiteComentarios = New System.Windows.Forms.TextBox
        Me.txtFecPublicacionConsulta = New System.Windows.Forms.TextBox
        Me.cboPNN = New System.Windows.Forms.ComboBox
        Me.lblClasificacion = New System.Windows.Forms.Label
        Me.lblFecPublicacionConsulta = New System.Windows.Forms.Label
        Me.lblFecLimiteComentarios = New System.Windows.Forms.Label
        Me.dtkFecLimiteComentarios = New System.Windows.Forms.DateTimePicker
        Me.tvPNN = New System.Windows.Forms.TreeView
        Me.txtIdComentarios = New System.Windows.Forms.TextBox
        Me.txtTema = New System.Windows.Forms.TextBox
        Me.txtPNN = New System.Windows.Forms.TextBox
        Me.lblSB = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gpbDatosPersonales.SuspendLayout()
        Me.gbpComentarios.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 464)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(792, 62)
        Me.tlbBotonera.TabIndex = 49
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(202, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(584, 448)
        Me.TabControl1.TabIndex = 50
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.gpbDatosPersonales)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(576, 422)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos Personales/Comentarios"
        '
        'gpbDatosPersonales
        '
        Me.gpbDatosPersonales.Controls.Add(Me.gbpComentarios)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmail)
        Me.gpbDatosPersonales.Controls.Add(Me.txtFax)
        Me.gpbDatosPersonales.Controls.Add(Me.txtTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.txtDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.txtEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.txtNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblNombre)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmpresa)
        Me.gpbDatosPersonales.Controls.Add(Me.lblDomicilio)
        Me.gpbDatosPersonales.Controls.Add(Me.lblTelefono)
        Me.gpbDatosPersonales.Controls.Add(Me.lblFax)
        Me.gpbDatosPersonales.Controls.Add(Me.lblEmail)
        Me.gpbDatosPersonales.Location = New System.Drawing.Point(5, 4)
        Me.gpbDatosPersonales.Name = "gpbDatosPersonales"
        Me.gpbDatosPersonales.Size = New System.Drawing.Size(564, 404)
        Me.gpbDatosPersonales.TabIndex = 3
        Me.gpbDatosPersonales.TabStop = False
        '
        'gbpComentarios
        '
        Me.gbpComentarios.Controls.Add(Me.txtPropuestasCambios)
        Me.gbpComentarios.Controls.Add(Me.txtComentario)
        Me.gbpComentarios.Controls.Add(Me.txtParrafo)
        Me.gbpComentarios.Controls.Add(Me.txtCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.cboTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblTipoComentario)
        Me.gbpComentarios.Controls.Add(Me.lblCapituloInciso)
        Me.gbpComentarios.Controls.Add(Me.lblParrafo)
        Me.gbpComentarios.Controls.Add(Me.lblComentario)
        Me.gbpComentarios.Controls.Add(Me.lblPropuestasCambios)
        Me.gbpComentarios.Location = New System.Drawing.Point(8, 176)
        Me.gbpComentarios.Name = "gbpComentarios"
        Me.gbpComentarios.Size = New System.Drawing.Size(440, 212)
        Me.gbpComentarios.TabIndex = 19
        Me.gbpComentarios.TabStop = False
        '
        'txtPropuestasCambios
        '
        Me.txtPropuestasCambios.Location = New System.Drawing.Point(160, 149)
        Me.txtPropuestasCambios.Multiline = True
        Me.txtPropuestasCambios.Name = "txtPropuestasCambios"
        Me.txtPropuestasCambios.Size = New System.Drawing.Size(272, 56)
        Me.txtPropuestasCambios.TabIndex = 60
        Me.txtPropuestasCambios.Text = "txtPropuestasCambios"
        '
        'txtComentario
        '
        Me.txtComentario.Location = New System.Drawing.Point(160, 94)
        Me.txtComentario.Multiline = True
        Me.txtComentario.Name = "txtComentario"
        Me.txtComentario.Size = New System.Drawing.Size(272, 48)
        Me.txtComentario.TabIndex = 59
        Me.txtComentario.Text = "txtComentario"
        '
        'txtParrafo
        '
        Me.txtParrafo.Location = New System.Drawing.Point(160, 66)
        Me.txtParrafo.Name = "txtParrafo"
        Me.txtParrafo.TabIndex = 58
        Me.txtParrafo.Text = "txtParrafo"
        '
        'txtCapituloInciso
        '
        Me.txtCapituloInciso.Location = New System.Drawing.Point(160, 42)
        Me.txtCapituloInciso.Name = "txtCapituloInciso"
        Me.txtCapituloInciso.TabIndex = 57
        Me.txtCapituloInciso.Text = "txtCapituloInciso"
        '
        'cboTipoComentario
        '
        Me.cboTipoComentario.Location = New System.Drawing.Point(160, 16)
        Me.cboTipoComentario.Name = "cboTipoComentario"
        Me.cboTipoComentario.Size = New System.Drawing.Size(260, 21)
        Me.cboTipoComentario.TabIndex = 56
        Me.cboTipoComentario.Text = "cboTipoComentario"
        '
        'lblTipoComentario
        '
        Me.lblTipoComentario.AutoSize = True
        Me.lblTipoComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTipoComentario.Location = New System.Drawing.Point(16, 16)
        Me.lblTipoComentario.Name = "lblTipoComentario"
        Me.lblTipoComentario.Size = New System.Drawing.Size(94, 16)
        Me.lblTipoComentario.TabIndex = 52
        Me.lblTipoComentario.Text = "Tipo Comentario"
        '
        'lblCapituloInciso
        '
        Me.lblCapituloInciso.AutoSize = True
        Me.lblCapituloInciso.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCapituloInciso.Location = New System.Drawing.Point(16, 42)
        Me.lblCapituloInciso.Name = "lblCapituloInciso"
        Me.lblCapituloInciso.Size = New System.Drawing.Size(85, 16)
        Me.lblCapituloInciso.TabIndex = 51
        Me.lblCapituloInciso.Text = "Cap�tulo Inciso"
        '
        'lblParrafo
        '
        Me.lblParrafo.AutoSize = True
        Me.lblParrafo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParrafo.Location = New System.Drawing.Point(16, 66)
        Me.lblParrafo.Name = "lblParrafo"
        Me.lblParrafo.Size = New System.Drawing.Size(114, 16)
        Me.lblParrafo.TabIndex = 53
        Me.lblParrafo.Text = "P�rrafo/Tabla/Figura"
        '
        'lblComentario
        '
        Me.lblComentario.AutoSize = True
        Me.lblComentario.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComentario.Location = New System.Drawing.Point(16, 94)
        Me.lblComentario.Name = "lblComentario"
        Me.lblComentario.Size = New System.Drawing.Size(67, 16)
        Me.lblComentario.TabIndex = 55
        Me.lblComentario.Text = "Comentario"
        '
        'lblPropuestasCambios
        '
        Me.lblPropuestasCambios.AutoSize = True
        Me.lblPropuestasCambios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPropuestasCambios.Location = New System.Drawing.Point(16, 149)
        Me.lblPropuestasCambios.Name = "lblPropuestasCambios"
        Me.lblPropuestasCambios.Size = New System.Drawing.Size(133, 16)
        Me.lblPropuestasCambios.TabIndex = 54
        Me.lblPropuestasCambios.Text = "Propuestas de Cambios"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(399, 73)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(160, 20)
        Me.txtEmail.TabIndex = 18
        Me.txtEmail.Text = "txtEmail"
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(399, 41)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(160, 20)
        Me.txtFax.TabIndex = 17
        Me.txtFax.Text = "txtFax"
        '
        'txtTelefono
        '
        Me.txtTelefono.Location = New System.Drawing.Point(399, 9)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(160, 20)
        Me.txtTelefono.TabIndex = 16
        Me.txtTelefono.Text = "txtTelefono"
        '
        'txtDomicilio
        '
        Me.txtDomicilio.Location = New System.Drawing.Point(71, 73)
        Me.txtDomicilio.Multiline = True
        Me.txtDomicilio.Name = "txtDomicilio"
        Me.txtDomicilio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDomicilio.Size = New System.Drawing.Size(264, 70)
        Me.txtDomicilio.TabIndex = 15
        Me.txtDomicilio.Text = "txtDomicilio"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Location = New System.Drawing.Point(71, 41)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(264, 20)
        Me.txtEmpresa.TabIndex = 14
        Me.txtEmpresa.Text = "txtEmpresa"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(71, 9)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(264, 20)
        Me.txtNombre.TabIndex = 13
        Me.txtNombre.Text = "txtNombre"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombre.Location = New System.Drawing.Point(16, 13)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(47, 16)
        Me.lblNombre.TabIndex = 12
        Me.lblNombre.Text = "Nombre"
        '
        'lblEmpresa
        '
        Me.lblEmpresa.AutoSize = True
        Me.lblEmpresa.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpresa.Location = New System.Drawing.Point(11, 42)
        Me.lblEmpresa.Name = "lblEmpresa"
        Me.lblEmpresa.Size = New System.Drawing.Size(52, 16)
        Me.lblEmpresa.TabIndex = 12
        Me.lblEmpresa.Text = "Empresa"
        '
        'lblDomicilio
        '
        Me.lblDomicilio.AutoSize = True
        Me.lblDomicilio.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDomicilio.Location = New System.Drawing.Point(11, 73)
        Me.lblDomicilio.Name = "lblDomicilio"
        Me.lblDomicilio.Size = New System.Drawing.Size(55, 16)
        Me.lblDomicilio.TabIndex = 12
        Me.lblDomicilio.Text = "Domicilio"
        '
        'lblTelefono
        '
        Me.lblTelefono.AutoSize = True
        Me.lblTelefono.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTelefono.Location = New System.Drawing.Point(343, 9)
        Me.lblTelefono.Name = "lblTelefono"
        Me.lblTelefono.Size = New System.Drawing.Size(51, 16)
        Me.lblTelefono.TabIndex = 12
        Me.lblTelefono.Text = "Tel�fono"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFax.Location = New System.Drawing.Point(367, 41)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(24, 16)
        Me.lblFax.TabIndex = 12
        Me.lblFax.Text = "Fax"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(359, 73)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(34, 16)
        Me.lblEmail.TabIndex = 12
        Me.lblEmail.Text = "Email"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(576, 422)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Proyecto            "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtkFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.cboClasificacion)
        Me.GroupBox1.Controls.Add(Me.lblPNN)
        Me.GroupBox1.Controls.Add(Me.txtFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.txtFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.cboPNN)
        Me.GroupBox1.Controls.Add(Me.lblClasificacion)
        Me.GroupBox1.Controls.Add(Me.lblFecPublicacionConsulta)
        Me.GroupBox1.Controls.Add(Me.lblFecLimiteComentarios)
        Me.GroupBox1.Controls.Add(Me.dtkFecLimiteComentarios)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 88)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(496, 136)
        Me.GroupBox1.TabIndex = 53
        Me.GroupBox1.TabStop = False
        '
        'dtkFecPublicacionConsulta
        '
        Me.dtkFecPublicacionConsulta.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecPublicacionConsulta.Location = New System.Drawing.Point(304, 56)
        Me.dtkFecPublicacionConsulta.Name = "dtkFecPublicacionConsulta"
        Me.dtkFecPublicacionConsulta.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecPublicacionConsulta.TabIndex = 31
        Me.dtkFecPublicacionConsulta.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecPublicacionConsulta.Visible = False
        '
        'cboClasificacion
        '
        Me.cboClasificacion.Location = New System.Drawing.Point(192, 16)
        Me.cboClasificacion.Name = "cboClasificacion"
        Me.cboClasificacion.Size = New System.Drawing.Size(260, 21)
        Me.cboClasificacion.TabIndex = 30
        Me.cboClasificacion.Text = "cboClasificacion"
        Me.cboClasificacion.Visible = False
        '
        'lblPNN
        '
        Me.lblPNN.AutoSize = True
        Me.lblPNN.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPNN.Location = New System.Drawing.Point(8, 16)
        Me.lblPNN.Name = "lblPNN"
        Me.lblPNN.Size = New System.Drawing.Size(28, 16)
        Me.lblPNN.TabIndex = 29
        Me.lblPNN.Text = "PNN"
        Me.lblPNN.Visible = False
        '
        'txtFecLimiteComentarios
        '
        Me.txtFecLimiteComentarios.Location = New System.Drawing.Point(192, 88)
        Me.txtFecLimiteComentarios.Name = "txtFecLimiteComentarios"
        Me.txtFecLimiteComentarios.TabIndex = 26
        Me.txtFecLimiteComentarios.Text = "txtFecLimiteComentarios"
        '
        'txtFecPublicacionConsulta
        '
        Me.txtFecPublicacionConsulta.Location = New System.Drawing.Point(192, 56)
        Me.txtFecPublicacionConsulta.Name = "txtFecPublicacionConsulta"
        Me.txtFecPublicacionConsulta.TabIndex = 25
        Me.txtFecPublicacionConsulta.Text = "FecPublicacionConsulta"
        '
        'cboPNN
        '
        Me.cboPNN.Location = New System.Drawing.Point(192, 8)
        Me.cboPNN.Name = "cboPNN"
        Me.cboPNN.Size = New System.Drawing.Size(260, 21)
        Me.cboPNN.TabIndex = 24
        Me.cboPNN.Text = "cboPNN"
        Me.cboPNN.Visible = False
        '
        'lblClasificacion
        '
        Me.lblClasificacion.AutoSize = True
        Me.lblClasificacion.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClasificacion.Location = New System.Drawing.Point(8, 24)
        Me.lblClasificacion.Name = "lblClasificacion"
        Me.lblClasificacion.Size = New System.Drawing.Size(74, 16)
        Me.lblClasificacion.TabIndex = 20
        Me.lblClasificacion.Text = "Clasificacion"
        Me.lblClasificacion.Visible = False
        '
        'lblFecPublicacionConsulta
        '
        Me.lblFecPublicacionConsulta.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecPublicacionConsulta.Location = New System.Drawing.Point(8, 56)
        Me.lblFecPublicacionConsulta.Name = "lblFecPublicacionConsulta"
        Me.lblFecPublicacionConsulta.Size = New System.Drawing.Size(174, 28)
        Me.lblFecPublicacionConsulta.TabIndex = 19
        Me.lblFecPublicacionConsulta.Text = "Fecha de Publicaci�n a periodo de Comentario P�blico"
        '
        'lblFecLimiteComentarios
        '
        Me.lblFecLimiteComentarios.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecLimiteComentarios.Location = New System.Drawing.Point(8, 96)
        Me.lblFecLimiteComentarios.Name = "lblFecLimiteComentarios"
        Me.lblFecLimiteComentarios.Size = New System.Drawing.Size(176, 19)
        Me.lblFecLimiteComentarios.TabIndex = 21
        Me.lblFecLimiteComentarios.Text = "Fecha L�mite para Comentarios"
        '
        'dtkFecLimiteComentarios
        '
        Me.dtkFecLimiteComentarios.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtkFecLimiteComentarios.Location = New System.Drawing.Point(304, 88)
        Me.dtkFecLimiteComentarios.Name = "dtkFecLimiteComentarios"
        Me.dtkFecLimiteComentarios.Size = New System.Drawing.Size(120, 20)
        Me.dtkFecLimiteComentarios.TabIndex = 31
        Me.dtkFecLimiteComentarios.Value = New Date(2006, 11, 16, 0, 0, 0, 0)
        Me.dtkFecLimiteComentarios.Visible = False
        '
        'tvPNN
        '
        Me.tvPNN.ImageList = Me.imgListTreeView
        Me.tvPNN.Location = New System.Drawing.Point(4, 11)
        Me.tvPNN.Name = "tvPNN"
        Me.tvPNN.Size = New System.Drawing.Size(193, 341)
        Me.tvPNN.TabIndex = 51
        '
        'txtIdComentarios
        '
        Me.txtIdComentarios.Location = New System.Drawing.Point(115, 357)
        Me.txtIdComentarios.Name = "txtIdComentarios"
        Me.txtIdComentarios.Size = New System.Drawing.Size(48, 20)
        Me.txtIdComentarios.TabIndex = 54
        Me.txtIdComentarios.Text = ""
        Me.txtIdComentarios.Visible = False
        '
        'txtTema
        '
        Me.txtTema.Location = New System.Drawing.Point(64, 357)
        Me.txtTema.Name = "txtTema"
        Me.txtTema.Size = New System.Drawing.Size(48, 20)
        Me.txtTema.TabIndex = 53
        Me.txtTema.Text = ""
        Me.txtTema.Visible = False
        '
        'txtPNN
        '
        Me.txtPNN.Location = New System.Drawing.Point(10, 357)
        Me.txtPNN.Name = "txtPNN"
        Me.txtPNN.Size = New System.Drawing.Size(46, 20)
        Me.txtPNN.TabIndex = 52
        Me.txtPNN.Text = ""
        Me.txtPNN.Visible = False
        '
        'lblSB
        '
        Me.lblSB.Location = New System.Drawing.Point(3, 386)
        Me.lblSB.Name = "lblSB"
        Me.lblSB.Size = New System.Drawing.Size(191, 16)
        Me.lblSB.TabIndex = 56
        Me.lblSB.Visible = False
        '
        'frmP_Comentarios
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 526)
        Me.Controls.Add(Me.lblSB)
        Me.Controls.Add(Me.txtIdComentarios)
        Me.Controls.Add(Me.txtTema)
        Me.Controls.Add(Me.txtPNN)
        Me.Controls.Add(Me.tvPNN)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Name = "frmP_Comentarios"
        Me.Text = "Captura de Comentarios"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.gpbDatosPersonales.ResumeLayout(False)
        Me.gbpComentarios.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmP_Comentarios_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sTipoProceso = "Nulo"
        Call Habilita(sTipoProceso)
        objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        cn.ConnectionString = objconexion.ConexionAnce(Application.StartupPath + "\Principal.ini", "Principal", gUsuario, gPasswordSql)
        Call inicializa()
        objComentarios.Bandera = 6 'cboComentario
        Call Carga_Combo(cboTipoComentario)
        Call llena_TreeView()


    End Sub

    Sub Carga_Combo(ByVal cbo As Object)
        'objComentarios.Bandera = 2 'para utilizar este para los dos combos, envio la mandera cuando llamo este SUB
        objComentarios.ListaCombo(cbo)  '
        
    End Sub

#Region "  Inicializa"
    Sub inicializa()
        'Datos Personales
        Limpia_Campos(txtNombre, txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        'Proyecto
        Limpia_Campos(cboPNN, cboClasificacion, txtFecPublicacionConsulta, txtFecLimiteComentarios)
        'Comentarios
        Limpia_Campos(cboTipoComentario, txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios)

        Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
        Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios)
        Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
        Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
        cboTipoComentario.Enabled = False
    End Sub
#End Region

#Region " Botonera"
    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 1 'AGREGAR
                tvPNN.Enabled = False
                sTipoProceso = "Agregar"
                Call Habilita(sTipoProceso)
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)
                'Call Agregar()

            Case 2 'EDITAR
                tvPNN.Enabled = False
                sTipoProceso = "Editar"
                Call Habilita(sTipoProceso)
                ''Activos(cmdDeshacer, cmdGuardar, grdCanceladas)
                ''Inactivos(cmdAgregar)
                'Call Editar()
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)

                If iCaso = 4 Then 'Editar Comentario
                    Activos(cmdDeshacer, cmdGuardar)
                    Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
                    Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                    Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)

                    objComentarios.Bandera = 6
                    Call Carga_Combo(cboTipoComentario)
                    cboTipoComentario.SelectedValue = objComentarios.Tipo_comentario
                    Activos(cboTipoComentario)
                End If

            Case 3 'DESHACER
                Activos(tvPNN)
                Call Deshacer()
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                ', cmdAgregar, cmdEditar, cmdBorrar)

            Case 4 'GUARDAR
                '''Inactivos(cmdDeshacer, cmdGuardar, grdCanceladas)
                '''Activos(cmdAgregar, cmdEditar, cmdBorrar, cmdSalir)
                Call Guardar()

            Case 5 'BORRAR
                Call Borrar()

            Case 7 'SALIR
                'Me.Close()
                Me.Dispose()
        End Select
    End Sub
#End Region

#Region " Llena TreeView"
    Private Sub llena_TreeView()
        oTablaPNN = x.ListaPNN("")
        tvPNN.BeginUpdate()
        nodo = tvPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = tvPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            oTablaDPy = x.ListaTemasProy(RegPNN("id_plan"))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                objComentarios.Bandera = 4
                objComentarios.Id_Plan = RegPNN("id_plan")
                objComentarios.Id_Tema = RegDPy("id_tema")
                DtCom = objComentarios.Buscar_PNN
                If DtCom.Rows.Count <> 0 Then
                    For Each Com In DtCom.Rows
                        'nodo2 = nodo1.Nodes.Add(Com("Id_Comentario"))
                        nodo2 = nodo1.Nodes.Add("COM" + Format$(Com("Id_Comentario"), "0000"))
                    Next
                End If
            Next
        Next
        tvPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        tvPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        tvPNN.Sorted = True
       
    End Sub
#End Region

#Region " AfterSelect (Despues de seleccionar un nodo)"
    Private Sub tvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvPNN.AfterSelect
        Dim svariable As String

        svariable = e.Node.FullPath
        lblSB.Text = e.Node.FullPath
        iCaso = 0

        array_texto = Split(lblSB.Text, "\")
        Select Case array_texto.Length
            Case 1 'selecciona
                Limpia_Campos(txtPNN)
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)

            Case 2 'planes
                Inactivos(cmdAgregar, cmdEditar, cmdDeshacer, cmdGuardar, cmdBorrar)
                txtPNN.Text = array_texto(1)

                Limpia_Campos(txtFecPublicacionConsulta, txtFecLimiteComentarios)
                Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                iCaso = 2
                Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)

            Case 3 'temas
                Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                Inactivos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Inactivos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(3))
                TabControl1.SelectedTab = TabControl1.TabPages.Item(1)
                'busca la informaci�n del tema en avance temas fechas
                ObjFechasavance.Buscar(array_texto(2), array_texto(1))

                txtFecPublicacionConsulta.Text = ObjFechasavance.F_Publicacion_ComentarioPublico
                txtFecLimiteComentarios.Text = ObjFechasavance.F_Limite_ComentarioPublico
                'txtFecLimiteAnalisisComentarios.Text = ObjFechasavance.F_Resolucion_ComentarioPublico


                'objComentarios.Bandera = 4
                'objComentarios.Id_Plan = array_texto(1)
                'objComentarios.Id_Tema = array_texto(2)

                'objComentarios.Llena_Campos()



                ''txtTitulo.Text = objComentarios.

                'txtTema.Text = array_texto(2)
                'iCaso = 3
            Case 4 'id_comentarios
                Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))

                Activos(cmdEditar, cmdBorrar)
                objComentarios.Bandera = 5
                objComentarios.Id_Plan = array_texto(1)
                objComentarios.Id_Tema = array_texto(2)
                objComentarios.Id_Comentario = CInt(Mid(array_texto(3), 4))
                objComentarios.Llena_Campos()

                txtFecPublicacionConsulta.Text = objComentarios.Fecha_inicio
                txtFecLimiteComentarios.Text = objComentarios.Fecha_Fin
                'txtFecLimiteAnalisisComentarios.Text = objComentarios.Fecha_Fin

                txtCapituloInciso.Text = objComentarios.Capitulo_inciso
                txtParrafo.Text = objComentarios.Parrafotablafigura
                txtComentario.Text = objComentarios.Comentarios
                txtPropuestasCambios.Text = objComentarios.Propuesta_cambios
                txtNombre.Text = objComentarios.Nombre
                txtEmpresa.Text = objComentarios.Empresa
                txtDomicilio.Text = objComentarios.Domicilio_Empresa
                txtTelefono.Text = objComentarios.Telefono
                txtFax.Text = objComentarios.Fax
                txtEmail.Text = objComentarios.Email
                'txtTitulo.Text = objComentarios.
                'txtComent.Text = objComentarios.Id_Comentario

                txtIdComentarios.Text = array_texto(3)
                objComentarios.Bandera = 8 'cboComentario
                '  objComentarios.Tipo_comentario = array_texto(3) 'cboComentario
                Call Carga_Combo(cboTipoComentario)
                cboTipoComentario.SelectedValue = objComentarios.Tipo_comentario

                iCaso = 4
                'cmdBusca3.Dispose()
                TabControl1.SelectedTab = TabControl1.TabPages.Item(0)
            Case 4
                iCaso = 5
        End Select





    End Sub
#End Region

#Region " AGREGAR"
    Private Sub Agregar()
        Inactivos(tvPNN, cmdBorrar)
        Dim sSqlAgregar As String
        '''If iCaso = 1 Then
        '''    MsgBox("No puedes agregar un Plan desde aqui", MsgBoxStyle.Information, "PNN")
        '''    '''Activos(cmdDeshacer, cmdGuardar, txtComite, txtDescripcion)
        '''    '''Activos(cboResponsable)
        '''    '''Limpia_Campos(txtComite, txtDescripcion)
        '''    '''Exit Sub
        '''End If

        '''If iCaso = 2 Then
        '''    MsgBox("No puedes agregar un Tema desde aqui", MsgBoxStyle.Information, "PNN")
        '''    '''Activos(cmdDeshacer, cmdGuardar, txtCT, txtDescripcion, txtObjetivo)
        '''    '''Activos(cboResponsable)
        '''    '''Limpia_Campos(txtCT, txtDescripcion, txtObjetivo)
        '''    '''Exit Sub
        '''End If

      
    End Sub
#End Region

#Region " EDITAR"

#End Region

#Region " DESHACER"
    Public Sub Deshacer()
        tvPNN.Nodes.Clear()
        Call inicializa()
        Call llena_TreeView()
        cboTipoComentario.Enabled = False
    End Sub

#End Region

#Region " GUARDAR"
    Dim iDetalle As Integer
    Private Sub Guardar()
        Dim sSqlAgregar As String

        If sTipoProceso = "Agregar" Then '*****************IF*************AGREGAR

            objComentarios.Bandera = 1
            objComentarios.Id_Plan = array_texto(1)
            objComentarios.Id_Tema = array_texto(2)
            objComentarios.Buscar_ID_Detalle()
            iDetalle = objComentarios.Id_Comentario

            With objComentarios
                .Bandera = 1
                .Id_Comentario = iDetalle
                .Fecha_Comentario = txtFecPublicacionConsulta.Text
                .Id_Plan = array_texto(1)
                .Id_Tema = array_texto(2)
                .Id_Etapa = 5
                .Nombre = txtNombre.Text
                .Empresa = txtEmpresa.Text
                .Domicilio_Empresa = txtDomicilio.Text
                .Telefono = txtTelefono.Text
                .Fax = txtFax.Text
                .Email = txtEmail.Text
                .Tipo_comentario = cboTipoComentario.SelectedValue
                .Capitulo_inciso = txtCapituloInciso.Text
                .Parrafotablafigura = txtParrafo.Text
                .Comentarios = txtComentario.Text
                .Propuesta_cambios = txtPropuestasCambios.Text
                '.Respuesta = ""
                '.Fecha_inicio = txtFecLimiteComentarios.Text
                '.Fecha_Fin = txtFecLimiteAnalisisComentarios.Text
                .Agregar()
            End With
            tvPNN.Nodes.Clear()
            Call inicializa()
            Call llena_TreeView()
            Limpia_Campos(txtPNN, txtTema, txtIdComentarios)
            tvPNN.Enabled = True

       


        ElseIf sTipoProceso = "Editar" Then '****************ELSE**************EDITAR
     

    
            With objComentarios
                .Bandera = 2
                .Id_Comentario = CInt(Mid(array_texto(3), 4))
                .Fecha_Comentario = txtFecPublicacionConsulta.Text
                .Id_Plan = array_texto(1)
                .Id_Tema = array_texto(2)
                .Nombre = txtNombre.Text
                .Empresa = txtEmpresa.Text
                .Domicilio_Empresa = txtDomicilio.Text
                .Telefono = txtTelefono.Text
                .Fax = txtFax.Text
                .Email = txtEmail.Text
                .Tipo_comentario = cboTipoComentario.SelectedValue
                .Capitulo_inciso = txtCapituloInciso.Text
                .Parrafotablafigura = txtParrafo.Text
                .Comentarios = txtComentario.Text
                .Propuesta_cambios = txtPropuestasCambios.Text
                .Respuesta = ""
                ' .Fecha_inicio = txtFecLimiteComentarios.Text
                ' .Fecha_Fin = txtFecLimiteAnalisisComentarios.Text
                .Actualizar()
            End With
            tvPNN.Nodes.Clear()
            Call inicializa()
            Call llena_TreeView()
            Limpia_Campos(txtPNN, txtTema, txtIdComentarios)
            tvPNN.Enabled = True



        End If
    End Sub
#End Region

#Region " BORRAR"
    Public Sub Borrar()
        If MsgBox("�Estas seguro que deseas eliminar este Comentario: " & txtPNN.Text & "/" & txtTema.Text & "/" & txtIdComentarios.Text & " ", MsgBoxStyle.OKCancel + MsgBoxStyle.Critical) = MsgBoxResult.OK Then
            objComentarios.Bandera = 5
            objComentarios.Id_Plan = txtPNN.Text
            objComentarios.Id_Tema = txtTema.Text
            objComentarios.Id_Comentario = txtIdComentarios.Text
            objComentarios.Borrar()
            tvPNN.Nodes.Clear()
            Call llena_TreeView()
            '''Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
            '''Activos(tvComites, cmdAgregar, cmdEditar)
            '''Limpia_Campos(txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo, cboResponsable)
        Else
            Exit Sub
        End If
    End Sub

#End Region

    Private Sub dtkFecPublicacionConsulta_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecPublicacionConsulta.ValueChanged
        txtFecPublicacionConsulta.Text = dtkFecPublicacionConsulta.Value
    End Sub

    Private Sub dtkFecLimiteComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtkFecLimiteComentarios.ValueChanged
        txtFecLimiteComentarios.Text = dtkFecLimiteComentarios.Value
    End Sub

    Private Sub dtkFecLimiteAnalisisComentarios_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'txtFecLimiteAnalisisComentarios.Text = dtkFecLimiteAnalisisComentarios.Value
    End Sub

    Private Sub tvPNN_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles tvPNN.BeforeExpand
        tvPNN.SelectedImageIndex = 1
    End Sub
    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"


            Case "Agregar"

                Activos(cmdDeshacer, cmdGuardar)
                Inactivos(cmdAgregar, cmdEditar, cmdBorrar)
                Inactivos(txtFecPublicacionConsulta, txtFecLimiteComentarios)

                Activos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Activos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)
                cboTipoComentario.Enabled = True
                objComentarios.Bandera = 6
                Call Carga_Combo(cboTipoComentario)
                Limpia_Campos(txtCapituloInciso, txtParrafo, txtComentario, txtPropuestasCambios, txtNombre)
                Limpia_Campos(txtEmpresa, txtDomicilio, txtTelefono, txtFax, txtEmail)



            Case "Editar"
                Activos(cmdDeshacer, cmdGuardar)
                Inactivos(cmdAgregar)



        End Select
    End Sub

    Private Sub cboTipoComentario_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTipoComentario.SelectedIndexChanged
        'If sTipoProceso = "Editar" Or sTipoProceso = "Agregar" Then
        '    txttipo.Text = cboTipoComentario.Text
        'End If
    End Sub
End Class
