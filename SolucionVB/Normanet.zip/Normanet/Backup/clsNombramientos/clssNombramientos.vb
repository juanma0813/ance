REM Clase en VB creada automaticamente by Efren David Tello Villalobos ..::zok::.. .Clase creada el: 20/10/2016 Version 3.3
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration


Namespace AnceSystem

    Public Class clssNombramientos

#Region "Propiedades de la clase"
        REM Variables de Propiedad
        Private _IdNombramiento As Integer
        Private _Folio As String
        Private _FechaIngreso As String
        Private _IdRemitente As Integer
        Private _Nombramiento As String
        Private _FechaRespuestaMaxima As String
        Private _FechaRespuestaVencimiento As String
        Private _RequiereRespuesta As Boolean
        Private _FechaRespuestaReal As String
        Private _Activo As Boolean
        Private _Bandera As String
        Private _respRetorno(1) As String
        Private _Encontrado As Boolean
        Private cn As SqlConnection


        REM Propiedades de la Entidad
        Public Property IdNombramiento() As String
            Get
                Return _IdNombramiento
            End Get
            Set(ByVal Value As String)
                _IdNombramiento = Value
            End Set
        End Property

        Public Property Folio() As String
            Get
                Return _Folio
            End Get
            Set(ByVal Value As String)
                _Folio = Value
            End Set
        End Property

        Public Property FechaIngreso() As String
            Get
                Return _FechaIngreso
            End Get
            Set(ByVal Value As String)
                _FechaIngreso = Value
            End Set
        End Property

        Public Property IdRemitente() As Integer
            Get
                Return _IdRemitente
            End Get
            Set(ByVal Value As Integer)
                _IdRemitente = Value
            End Set
        End Property

        Public Property Nombramiento() As String
            Get
                Return _Nombramiento
            End Get
            Set(ByVal Value As String)
                _Nombramiento = Value
            End Set
        End Property

        Public Property FechaRespuestaMaxima() As String
            Get
                Return _FechaRespuestaMaxima
            End Get
            Set(ByVal Value As String)
                _FechaRespuestaMaxima = Value
            End Set
        End Property

        Public Property FechaRespuestaVencimiento() As String
            Get
                Return _FechaRespuestaVencimiento
            End Get
            Set(ByVal Value As String)
                _FechaRespuestaVencimiento = Value
            End Set
        End Property

        Public Property RequiereRespuesta() As Boolean
            Get
                Return _RequiereRespuesta
            End Get
            Set(ByVal Value As Boolean)
                _RequiereRespuesta = Value
            End Set
        End Property

        Public Property FechaRespuestaReal() As String
            Get
                Return _FechaRespuestaReal
            End Get
            Set(ByVal Value As String)
                _FechaRespuestaReal = Value
            End Set
        End Property

        Public Property Activo() As Boolean
            Get
                Return _Activo
            End Get
            Set(ByVal Value As Boolean)
                _Activo = Value
            End Set
        End Property

        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Bandera() As String
            Get
                Return _Bandera
            End Get
            Set(ByVal Value As String)
                _Bandera = Value
            End Set
        End Property

        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 0 contiene el error en caso de fallar :: la posicion 1 Contiene un (1 o 0), '1' indica que el metodo fallo, y '0' indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property


        REM propiedades autoimplementadas solo para FWK 3.5
        Public Property Encontrado() As String
            Get
                Return _Encontrado
            End Get
            Set(ByVal Value As String)
                _Encontrado = Value
            End Set
        End Property

        ''|| TagPropiedades
        ''|| EndTagPropiedades

#End Region
#Region "Metodos de la Clase"
        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance").ToString)
        End Sub
        REM Funcion que Elimina datos
        ''' <summary>
        '''Metodo para eliminar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Eliminar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                Cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn

                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
                cmd.Parameters.Add("@Folio", _Folio)
                cmd.Parameters.Add("@FechaIngreso", _FechaIngreso)
                cmd.Parameters.Add("@IdRemitente", _IdRemitente)
                cmd.Parameters.Add("@Nombramiento", _Nombramiento)
                cmd.Parameters.Add("@FechaRespuestaMaxima", _FechaRespuestaMaxima)
                cmd.Parameters.Add("@FechaRespuestaVencimiento", _FechaRespuestaVencimiento)
                cmd.Parameters.Add("@RequiereRespuesta", _RequiereRespuesta)
                cmd.Parameters.Add("@FechaRespuestaReal", _FechaRespuestaReal)
                cmd.Parameters.Add("@Activo", _Activo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Actualizar datos
        ''' <summary>
        '''Metodo para Actualizar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Actualizar()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn

                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
                cmd.Parameters.Add("@Folio", _Folio)

                If _FechaIngreso Is Nothing Then
                    cmd.Parameters.Add("@FechaIngreso", Nothing)
                Else
                    cmd.Parameters.Add("@FechaIngreso", CDate(_FechaIngreso))
                End If

                cmd.Parameters.Add("@IdRemitente", _IdRemitente)
                cmd.Parameters.Add("@Nombramiento", _Nombramiento)

                If _FechaRespuestaMaxima Is Nothing Then
                    cmd.Parameters.Add("@FechaRespuestaMaxima", Nothing)
                Else
                    cmd.Parameters.Add("@FechaRespuestaMaxima", CDate(_FechaRespuestaMaxima))
                End If

                If _FechaRespuestaVencimiento Is Nothing Then
                    cmd.Parameters.Add("@FechaRespuestaVencimiento", Nothing)
                Else
                    cmd.Parameters.Add("@FechaRespuestaVencimiento", CDate(_FechaRespuestaVencimiento))
                End If
                cmd.Parameters.Add("@RequiereRespuesta", _RequiereRespuesta)

                If _FechaRespuestaReal Is Nothing Then
                    cmd.Parameters.Add("@FechaRespuestaReal", Nothing)
                Else
                    cmd.Parameters.Add("@FechaRespuestaReal", CDate(_FechaRespuestaReal))
                End If

                cmd.Parameters.Add("@Activo", _Activo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub

        Public Sub ActualizarFechas()

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn

                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
                cmd.Parameters.Add("@Folio", _Folio)
                cmd.Parameters.Add("@FechaRespuestaVencimiento", CDate(_FechaRespuestaVencimiento))
                cmd.Parameters.Add("@FechaRespuestaReal", CDate(_FechaRespuestaReal))
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Sub que Insertar datos
        ''' <summary>
        ''' Metodo para insertar, contiene todos los campos de la base de la tabla
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub Insertar()
            Dim Consecutivo As Integer = 0

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
                cmd.Parameters.Add("@Folio", _Folio)
                cmd.Parameters.Add("@FechaIngreso", CDate(_FechaIngreso))
                cmd.Parameters.Add("@IdRemitente", _IdRemitente)
                cmd.Parameters.Add("@Nombramiento", _Nombramiento)
                cmd.Parameters.Add("@FechaRespuestaMaxima", CDate(_FechaRespuestaMaxima))
                cmd.Parameters.Add("@FechaRespuestaVencimiento", CDate(_FechaRespuestaVencimiento))
                cmd.Parameters.Add("@RequiereRespuesta", _RequiereRespuesta)
                cmd.Parameters.Add("@FechaRespuestaReal", _FechaRespuestaReal)
                cmd.Parameters.Add("@Activo", _Activo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub

        Public Sub InsertarInicio()
            Dim Consecutivo As Integer = 0

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
                cmd.Parameters.Add("@Folio", _Folio)
                cmd.Parameters.Add("@FechaIngreso", CDate(_FechaIngreso))
                cmd.Parameters.Add("@IdRemitente", _IdRemitente)
                cmd.Parameters.Add("@Nombramiento", _Nombramiento)
                cmd.Parameters.Add("@FechaRespuestaMaxima", CDate(_FechaRespuestaMaxima))
                cmd.Parameters.Add("@FechaRespuestaVencimiento", _FechaRespuestaVencimiento)
                cmd.Parameters.Add("@RequiereRespuesta", _RequiereRespuesta)
                cmd.Parameters.Add("@FechaRespuestaReal", _FechaRespuestaReal)
                cmd.Parameters.Add("@Activo", _Activo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                cmd.ExecuteNonQuery()


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub

        REM Funcion que LlenarDatos datos
        ''' <summary>
        '''llena todas las propiedades en base a una consulta de sql o Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub LlenarDatos()
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Folio", _Folio)
                cmd.Parameters.Add("@FechaIngreso", _FechaIngreso)
                cmd.Parameters.Add("@IdRemitente", _IdRemitente)
                cmd.Parameters.Add("@Nombramiento", _Nombramiento)
                cmd.Parameters.Add("@FechaRespuestaMaxima", _FechaRespuestaMaxima)
                cmd.Parameters.Add("@FechaRespuestaVencimiento", _FechaRespuestaVencimiento)
                cmd.Parameters.Add("@RequiereRespuesta", _RequiereRespuesta)
                cmd.Parameters.Add("@FechaRespuestaReal", _FechaRespuestaReal)
                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)

                cmd.Parameters.Add("@Activo", _Activo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)

                If dt.Rows.Count > 0 Then
                    _Folio = IIf(IsDBNull(dt.Rows(0).Item("Folio")) = True, Nothing, dt.Rows(0).Item("Folio"))
                    _FechaIngreso = IIf(IsDBNull(dt.Rows(0).Item("FechaIngreso")) = True, Nothing, dt.Rows(0).Item("FechaIngreso"))
                    _IdRemitente = IIf(IsDBNull(dt.Rows(0).Item("IdRemitente")) = True, Nothing, dt.Rows(0).Item("IdRemitente"))
                    _Nombramiento = IIf(IsDBNull(dt.Rows(0).Item("Nombramiento")) = True, Nothing, dt.Rows(0).Item("Nombramiento"))
                    _FechaRespuestaMaxima = IIf(IsDBNull(dt.Rows(0).Item("FechaRespuestaMaxima")) = True, Nothing, dt.Rows(0).Item("FechaRespuestaMaxima"))
                    _FechaRespuestaVencimiento = IIf(IsDBNull(dt.Rows(0).Item("FechaRespuestaVencimiento")) = True, Nothing, dt.Rows(0).Item("FechaRespuestaVencimiento"))
                    _RequiereRespuesta = IIf(IsDBNull(dt.Rows(0).Item("RequiereRespuesta")) = True, Nothing, dt.Rows(0).Item("RequiereRespuesta"))
                    _FechaRespuestaReal = IIf(IsDBNull(dt.Rows(0).Item("FechaRespuestaReal")) = True, Nothing, dt.Rows(0).Item("FechaRespuestaReal"))
                    _Activo = IIf(IsDBNull(dt.Rows(0).Item("Activo")) = True, Nothing, dt.Rows(0).Item("Activo"))
                    _IdNombramiento = IIf(IsDBNull(dt.Rows(0).Item("IdNombramiento")) = True, Nothing, dt.Rows(0).Item("IdNombramiento"))
                    ''|| TagLlenado
                    ''|| EndTagLlenado
                    _Encontrado = True
                Else
                    _IdNombramiento = Nothing
                    _Folio = Nothing
                    _FechaIngreso = Nothing
                    _IdRemitente = Nothing
                    _Nombramiento = Nothing
                    _FechaRespuestaMaxima = Nothing
                    _FechaRespuestaVencimiento = Nothing
                    _RequiereRespuesta = Nothing
                    _FechaRespuestaReal = Nothing
                    _Activo = Nothing
                    ''|| TagLlenado1
                    ''|| EndTagLlemado1
                    _Encontrado = False
                End If
            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
        End Sub


        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = "0"

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspNombramientos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@IdNombramiento", _IdNombramiento)
                cmd.Parameters.Add("@Folio", _Folio)
                cmd.Parameters.Add("@FechaIngreso", _FechaIngreso)
                cmd.Parameters.Add("@IdRemitente", _IdRemitente)
                cmd.Parameters.Add("@Nombramiento", _Nombramiento)
                cmd.Parameters.Add("@FechaRespuestaMaxima", _FechaRespuestaMaxima)
                cmd.Parameters.Add("@FechaRespuestaVencimiento", _FechaRespuestaVencimiento)
                cmd.Parameters.Add("@RequiereRespuesta", _RequiereRespuesta)
                cmd.Parameters.Add("@FechaRespuestaReal", _FechaRespuestaReal)
                cmd.Parameters.Add("@Activo", _Activo)
                ''|| TagParametros
                ''|| EndTagParametros
                cmd.Parameters.Add("@Bandera", _Bandera)
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)


            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function

        Public Function RutaDocumentos() As String
            Dim sRuta As String = ConfigurationSettings.AppSettings("DocumentosWeb") & ConfigurationSettings.AppSettings("ArchivosDescarga")
            If Not System.IO.Directory.Exists(sRuta) Then System.IO.Directory.CreateDirectory(sRuta)

            Return sRuta
        End Function

#End Region


    End Class

End Namespace
