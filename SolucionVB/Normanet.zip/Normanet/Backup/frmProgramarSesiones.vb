Imports System.IO
Public Class frmProgramarSesiones
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents DTPkrhoratem As System.Windows.Forms.DateTimePicker
    Friend WithEvents DTPkrhoraini As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lblht As System.Windows.Forms.Label
    Friend WithEvents TxtNotas As System.Windows.Forms.TextBox
    Friend WithEvents lblNotas As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Lblhi As System.Windows.Forms.Label
    Friend WithEvents lblSesiones As System.Windows.Forms.Label
    Friend WithEvents TxtLugar As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtAsunto As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmdAgregarPlan As System.Windows.Forms.Button
    Friend WithEvents txtPlanes As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents grdArchivos As System.Windows.Forms.DataGrid
    Friend WithEvents cboTipo As System.Windows.Forms.ComboBox
    Friend WithEvents txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents cmdAgregarArchivos As System.Windows.Forms.Button
    Friend WithEvents cmdBuscar As System.Windows.Forms.Button
    Friend WithEvents grdTemas As System.Windows.Forms.DataGrid
    Friend WithEvents trvComites As System.Windows.Forms.TreeView
    Friend WithEvents cboResponsable As System.Windows.Forms.ComboBox
    Friend WithEvents txtClaveSesion As System.Windows.Forms.TextBox
    Friend WithEvents ilsBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotones As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmTemas As System.Windows.Forms.ContextMenu
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmDocumentos As System.Windows.Forms.ContextMenu
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtNombreDoc As System.Windows.Forms.TextBox
    Friend WithEvents cmdActivarTema As System.Windows.Forms.MenuItem
    Friend WithEvents cmdInactivarTema As System.Windows.Forms.MenuItem
    Friend WithEvents cmdActivarDoctos As System.Windows.Forms.MenuItem
    Friend WithEvents cmdInactivarDoctos As System.Windows.Forms.MenuItem
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmProgramarSesiones))
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.trvComites = New System.Windows.Forms.TreeView
        Me.DTPkrhoratem = New System.Windows.Forms.DateTimePicker
        Me.DTPkrhoraini = New System.Windows.Forms.DateTimePicker
        Me.Lblht = New System.Windows.Forms.Label
        Me.TxtNotas = New System.Windows.Forms.TextBox
        Me.lblNotas = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Lblhi = New System.Windows.Forms.Label
        Me.lblSesiones = New System.Windows.Forms.Label
        Me.TxtLugar = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.TxtAsunto = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cboResponsable = New System.Windows.Forms.ComboBox
        Me.grdArchivos = New System.Windows.Forms.DataGrid
        Me.grdTemas = New System.Windows.Forms.DataGrid
        Me.cmTemas = New System.Windows.Forms.ContextMenu
        Me.cmdActivarTema = New System.Windows.Forms.MenuItem
        Me.cmdInactivarTema = New System.Windows.Forms.MenuItem
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmdAgregarPlan = New System.Windows.Forms.Button
        Me.txtPlanes = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtNombreDoc = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmdBuscar = New System.Windows.Forms.Button
        Me.txtDocumento = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.cboTipo = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.cmdAgregarArchivos = New System.Windows.Forms.Button
        Me.txtClaveSesion = New System.Windows.Forms.TextBox
        Me.ilsBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotones = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton
        Me.cmDocumentos = New System.Windows.Forms.ContextMenu
        Me.cmdActivarDoctos = New System.Windows.Forms.MenuItem
        Me.cmdInactivarDoctos = New System.Windows.Forms.MenuItem
        CType(Me.grdArchivos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdTemas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(18, 18)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'trvComites
        '
        Me.trvComites.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.trvComites.ImageList = Me.imgListTreeView
        Me.trvComites.Location = New System.Drawing.Point(8, 17)
        Me.trvComites.Name = "trvComites"
        Me.trvComites.SelectedImageIndex = 1
        Me.trvComites.Size = New System.Drawing.Size(240, 536)
        Me.trvComites.TabIndex = 17
        '
        'DTPkrhoratem
        '
        Me.DTPkrhoratem.CustomFormat = "HH:mm "
        Me.DTPkrhoratem.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoratem.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoratem.Location = New System.Drawing.Point(608, 32)
        Me.DTPkrhoratem.Name = "DTPkrhoratem"
        Me.DTPkrhoratem.ShowUpDown = True
        Me.DTPkrhoratem.Size = New System.Drawing.Size(104, 20)
        Me.DTPkrhoratem.TabIndex = 108
        Me.DTPkrhoratem.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'DTPkrhoraini
        '
        Me.DTPkrhoraini.CustomFormat = "HH:mm"
        Me.DTPkrhoraini.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.DTPkrhoraini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPkrhoraini.Location = New System.Drawing.Point(608, 8)
        Me.DTPkrhoraini.Name = "DTPkrhoraini"
        Me.DTPkrhoraini.ShowUpDown = True
        Me.DTPkrhoraini.Size = New System.Drawing.Size(104, 20)
        Me.DTPkrhoraini.TabIndex = 107
        Me.DTPkrhoraini.Value = New Date(2006, 10, 11, 0, 0, 0, 0)
        '
        'Lblht
        '
        Me.Lblht.AutoSize = True
        Me.Lblht.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblht.Location = New System.Drawing.Point(512, 40)
        Me.Lblht.Name = "Lblht"
        Me.Lblht.Size = New System.Drawing.Size(65, 16)
        Me.Lblht.TabIndex = 106
        Me.Lblht.Text = "Termina a: "
        '
        'TxtNotas
        '
        Me.TxtNotas.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TxtNotas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNotas.Location = New System.Drawing.Point(344, 488)
        Me.TxtNotas.Multiline = True
        Me.TxtNotas.Name = "TxtNotas"
        Me.TxtNotas.Size = New System.Drawing.Size(395, 32)
        Me.TxtNotas.TabIndex = 94
        Me.TxtNotas.Text = ""
        '
        'lblNotas
        '
        Me.lblNotas.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblNotas.AutoSize = True
        Me.lblNotas.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotas.Location = New System.Drawing.Point(296, 488)
        Me.lblNotas.Name = "lblNotas"
        Me.lblNotas.Size = New System.Drawing.Size(39, 16)
        Me.lblNotas.TabIndex = 105
        Me.lblNotas.Text = "Nota:  "
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(256, 536)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 16)
        Me.Label9.TabIndex = 102
        Me.Label9.Text = "Responsable: "
        '
        'Lblhi
        '
        Me.Lblhi.AutoSize = True
        Me.Lblhi.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblhi.Location = New System.Drawing.Point(512, 8)
        Me.Lblhi.Name = "Lblhi"
        Me.Lblhi.Size = New System.Drawing.Size(74, 16)
        Me.Lblhi.TabIndex = 97
        Me.Lblhi.Text = "Comienza a: "
        '
        'lblSesiones
        '
        Me.lblSesiones.AutoSize = True
        Me.lblSesiones.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSesiones.Location = New System.Drawing.Point(256, 8)
        Me.lblSesiones.Name = "lblSesiones"
        Me.lblSesiones.Size = New System.Drawing.Size(82, 16)
        Me.lblSesiones.TabIndex = 96
        Me.lblSesiones.Text = "Clave Sesion: "
        '
        'TxtLugar
        '
        Me.TxtLugar.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLugar.Location = New System.Drawing.Point(344, 96)
        Me.TxtLugar.Name = "TxtLugar"
        Me.TxtLugar.Size = New System.Drawing.Size(392, 20)
        Me.TxtLugar.TabIndex = 91
        Me.TxtLugar.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(296, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 16)
        Me.Label4.TabIndex = 99
        Me.Label4.Text = "Lugar: "
        '
        'TxtAsunto
        '
        Me.TxtAsunto.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtAsunto.Location = New System.Drawing.Point(344, 56)
        Me.TxtAsunto.Multiline = True
        Me.TxtAsunto.Name = "TxtAsunto"
        Me.TxtAsunto.Size = New System.Drawing.Size(395, 32)
        Me.TxtAsunto.TabIndex = 90
        Me.TxtAsunto.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(288, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 16)
        Me.Label3.TabIndex = 98
        Me.Label3.Text = "Asunto: "
        '
        'cboResponsable
        '
        Me.cboResponsable.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cboResponsable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboResponsable.Location = New System.Drawing.Point(344, 528)
        Me.cboResponsable.Name = "cboResponsable"
        Me.cboResponsable.Size = New System.Drawing.Size(395, 22)
        Me.cboResponsable.TabIndex = 95
        '
        'grdArchivos
        '
        Me.grdArchivos.AllowNavigation = False
        Me.grdArchivos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdArchivos.BackgroundColor = System.Drawing.Color.White
        Me.grdArchivos.CaptionVisible = False
        Me.grdArchivos.DataMember = ""
        Me.grdArchivos.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grdArchivos.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.grdArchivos.HeaderBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grdArchivos.HeaderFont = New System.Drawing.Font("Arial", 9.290323!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grdArchivos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdArchivos.Location = New System.Drawing.Point(8, 72)
        Me.grdArchivos.Name = "grdArchivos"
        Me.grdArchivos.ReadOnly = True
        Me.grdArchivos.Size = New System.Drawing.Size(456, 96)
        Me.grdArchivos.TabIndex = 93
        '
        'grdTemas
        '
        Me.grdTemas.AllowDrop = True
        Me.grdTemas.AllowNavigation = False
        Me.grdTemas.BackgroundColor = System.Drawing.Color.White
        Me.grdTemas.CaptionVisible = False
        Me.grdTemas.DataMember = ""
        Me.grdTemas.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grdTemas.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.grdTemas.HeaderBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grdTemas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdTemas.Location = New System.Drawing.Point(8, 48)
        Me.grdTemas.Name = "grdTemas"
        Me.grdTemas.ReadOnly = True
        Me.grdTemas.Size = New System.Drawing.Size(456, 120)
        Me.grdTemas.TabIndex = 92
        '
        'cmTemas
        '
        Me.cmTemas.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.cmdActivarTema, Me.cmdInactivarTema})
        '
        'cmdActivarTema
        '
        Me.cmdActivarTema.Index = 0
        Me.cmdActivarTema.Text = "Activar"
        '
        'cmdInactivarTema
        '
        Me.cmdInactivarTema.Index = 1
        Me.cmdInactivarTema.Text = "Inactivar"
        '
        'dtpFecha
        '
        Me.dtpFecha.CustomFormat = "dd/MM/yyyy"
        Me.dtpFecha.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFecha.Location = New System.Drawing.Point(344, 32)
        Me.dtpFecha.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(163, 20)
        Me.dtpFecha.TabIndex = 89
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(296, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 16)
        Me.Label1.TabIndex = 109
        Me.Label1.Text = "Fecha: "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdAgregarPlan)
        Me.GroupBox1.Controls.Add(Me.txtPlanes)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.grdTemas)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(256, 120)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(480, 176)
        Me.GroupBox1.TabIndex = 110
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Temas"
        '
        'cmdAgregarPlan
        '
        Me.cmdAgregarPlan.Location = New System.Drawing.Point(408, 21)
        Me.cmdAgregarPlan.Name = "cmdAgregarPlan"
        Me.cmdAgregarPlan.Size = New System.Drawing.Size(56, 24)
        Me.cmdAgregarPlan.TabIndex = 95
        Me.cmdAgregarPlan.Text = "Agregar"
        '
        'txtPlanes
        '
        Me.txtPlanes.Location = New System.Drawing.Point(56, 24)
        Me.txtPlanes.Name = "txtPlanes"
        Me.txtPlanes.ReadOnly = True
        Me.txtPlanes.Size = New System.Drawing.Size(344, 20)
        Me.txtPlanes.TabIndex = 94
        Me.txtPlanes.Text = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 16)
        Me.Label2.TabIndex = 93
        Me.Label2.Text = "Planes:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtNombreDoc)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.cmdBuscar)
        Me.GroupBox2.Controls.Add(Me.txtDocumento)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.cboTipo)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.grdArchivos)
        Me.GroupBox2.Controls.Add(Me.cmdAgregarArchivos)
        Me.GroupBox2.Location = New System.Drawing.Point(256, 304)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(480, 176)
        Me.GroupBox2.TabIndex = 111
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Archivos: "
        '
        'txtNombreDoc
        '
        Me.txtNombreDoc.Location = New System.Drawing.Point(224, 16)
        Me.txtNombreDoc.Name = "txtNombreDoc"
        Me.txtNombreDoc.Size = New System.Drawing.Size(240, 20)
        Me.txtNombreDoc.TabIndex = 100
        Me.txtNombreDoc.Text = ""
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(176, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 16)
        Me.Label7.TabIndex = 99
        Me.Label7.Text = "Nombre:"
        '
        'cmdBuscar
        '
        Me.cmdBuscar.Location = New System.Drawing.Point(320, 40)
        Me.cmdBuscar.Name = "cmdBuscar"
        Me.cmdBuscar.Size = New System.Drawing.Size(32, 20)
        Me.cmdBuscar.TabIndex = 98
        Me.cmdBuscar.Text = "....."
        '
        'txtDocumento
        '
        Me.txtDocumento.Location = New System.Drawing.Point(48, 40)
        Me.txtDocumento.Name = "txtDocumento"
        Me.txtDocumento.ReadOnly = True
        Me.txtDocumento.Size = New System.Drawing.Size(272, 20)
        Me.txtDocumento.TabIndex = 97
        Me.txtDocumento.Text = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 16)
        Me.Label6.TabIndex = 96
        Me.Label6.Text = "Docto:"
        '
        'cboTipo
        '
        Me.cboTipo.Location = New System.Drawing.Point(48, 16)
        Me.cboTipo.Name = "cboTipo"
        Me.cboTipo.Size = New System.Drawing.Size(128, 21)
        Me.cboTipo.TabIndex = 95
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 16)
        Me.Label5.TabIndex = 94
        Me.Label5.Text = "Tipo:"
        '
        'cmdAgregarArchivos
        '
        Me.cmdAgregarArchivos.Location = New System.Drawing.Point(408, 40)
        Me.cmdAgregarArchivos.Name = "cmdAgregarArchivos"
        Me.cmdAgregarArchivos.Size = New System.Drawing.Size(56, 24)
        Me.cmdAgregarArchivos.TabIndex = 96
        Me.cmdAgregarArchivos.Text = "Agregar"
        '
        'txtClaveSesion
        '
        Me.txtClaveSesion.Location = New System.Drawing.Point(344, 8)
        Me.txtClaveSesion.Name = "txtClaveSesion"
        Me.txtClaveSesion.ReadOnly = True
        Me.txtClaveSesion.Size = New System.Drawing.Size(160, 20)
        Me.txtClaveSesion.TabIndex = 112
        Me.txtClaveSesion.Text = ""
        '
        'ilsBotonera
        '
        Me.ilsBotonera.ImageSize = New System.Drawing.Size(35, 35)
        Me.ilsBotonera.ImageStream = CType(resources.GetObject("ilsBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilsBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotones
        '
        Me.tlbBotones.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton5, Me.ToolBarButton4, Me.ToolBarButton6, Me.ToolBarButton7})
        Me.tlbBotones.ButtonSize = New System.Drawing.Size(60, 55)
        Me.tlbBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotones.DropDownArrows = True
        Me.tlbBotones.ImageList = Me.ilsBotonera
        Me.tlbBotones.Location = New System.Drawing.Point(0, 558)
        Me.tlbBotones.Name = "tlbBotones"
        Me.tlbBotones.ShowToolTips = True
        Me.tlbBotones.Size = New System.Drawing.Size(746, 61)
        Me.tlbBotones.TabIndex = 113
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.Text = "Agregar"
        Me.ToolBarButton1.ToolTipText = "Agregar"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 1
        Me.ToolBarButton2.Text = "Editar"
        Me.ToolBarButton2.ToolTipText = "Editar"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 2
        Me.ToolBarButton3.Text = "Deshacer"
        Me.ToolBarButton3.ToolTipText = "Deshacer"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 3
        Me.ToolBarButton5.Text = "Guardar"
        Me.ToolBarButton5.ToolTipText = "Guardar"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 4
        Me.ToolBarButton4.Text = "Borrar"
        Me.ToolBarButton4.ToolTipText = "Borrar"
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 5
        Me.ToolBarButton6.Text = "Listas"
        Me.ToolBarButton6.ToolTipText = "Listas"
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.ImageIndex = 6
        Me.ToolBarButton7.Text = "Notificaci�n"
        Me.ToolBarButton7.ToolTipText = "Notificaci�n"
        '
        'cmDocumentos
        '
        Me.cmDocumentos.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.cmdActivarDoctos, Me.cmdInactivarDoctos})
        '
        'cmdActivarDoctos
        '
        Me.cmdActivarDoctos.Index = 0
        Me.cmdActivarDoctos.Text = "Activar"
        '
        'cmdInactivarDoctos
        '
        Me.cmdInactivarDoctos.Index = 1
        Me.cmdInactivarDoctos.Text = "Inactivar"
        '
        'frmProgramarSesiones
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(746, 619)
        Me.Controls.Add(Me.tlbBotones)
        Me.Controls.Add(Me.txtClaveSesion)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Lblht)
        Me.Controls.Add(Me.TxtNotas)
        Me.Controls.Add(Me.lblNotas)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Lblhi)
        Me.Controls.Add(Me.lblSesiones)
        Me.Controls.Add(Me.TxtLugar)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtAsunto)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DTPkrhoratem)
        Me.Controls.Add(Me.DTPkrhoraini)
        Me.Controls.Add(Me.cboResponsable)
        Me.Controls.Add(Me.dtpFecha)
        Me.Controls.Add(Me.trvComites)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmProgramarSesiones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sesiones"
        CType(Me.grdArchivos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdTemas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _Estado As String
    Private objArbolTemas As New TreeView

    Private Property Estado() As String
        Get
            Return _Estado
        End Get
        Set(ByVal Value As String)
            _Estado = Value
        End Set
    End Property

    Private Sub frmProgramarSesiones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CrearArbol()
        LlenarArbol()
        LlenarTipoDoctos()
        LlenarResponsables()
    End Sub

    Private Sub BotonesInicio()
        Limpiar(txtClaveSesion, DTPkrhoraini, DTPkrhoratem, dtpFecha, TxtAsunto, TxtLugar, txtPlanes, txtDocumento, grdArchivos, TxtNotas)
        Lectura(txtClaveSesion, TxtAsunto, TxtLugar, txtPlanes, txtDocumento, TxtNotas)
        inactivar(DTPkrhoratem, DTPkrhoraini, dtpFecha, txtPlanes, txtNombreDoc)
        inactivar(grdArchivos, grdTemas, cboTipo, cboResponsable, cmdBuscar, cmdAgregarArchivos, cmdAgregarPlan)
        inactivar(tlbBotones.Buttons.Item(0), tlbBotones.Buttons.Item(1), tlbBotones.Buttons.Item(2), tlbBotones.Buttons.Item(3), tlbBotones.Buttons.Item(4), tlbBotones.Buttons.Item(5), tlbBotones.Buttons.Item(6))
        Activar(trvComites)
        grdArchivos.DataSource = Nothing
        grdTemas.DataSource = Nothing

        grdArchivos.ContextMenu = Nothing
        grdTemas.ContextMenu = Nothing

        Estado = ""
    End Sub

    Private Sub BotonesNuevo()
        Limpiar(txtClaveSesion, DTPkrhoraini, DTPkrhoratem, dtpFecha, TxtAsunto, TxtLugar, txtPlanes, txtDocumento, grdArchivos, TxtNotas)
        Escritura(TxtAsunto, TxtLugar, TxtNotas)
        Activar(DTPkrhoratem, DTPkrhoraini, dtpFecha, txtNombreDoc)
        Activar(grdArchivos, grdTemas, cboTipo, cboResponsable, txtPlanes, cmdBuscar, cmdAgregarArchivos, cmdAgregarPlan)
        Activar(tlbBotones.Buttons.Item(2), tlbBotones.Buttons.Item(3))
        inactivar(tlbBotones.Buttons.Item(0), tlbBotones.Buttons.Item(1), tlbBotones.Buttons.Item(4), trvComites, tlbBotones.Buttons.Item(5), tlbBotones.Buttons.Item(6))

        grdArchivos.DataSource = Nothing
        grdTemas.DataSource = Nothing

        grdArchivos.ContextMenu = cmDocumentos
        grdTemas.ContextMenu = cmTemas
    End Sub

    Private Sub BotonesEdicion()
        grdArchivos.ContextMenu = cmDocumentos
        grdTemas.ContextMenu = cmTemas

        Escritura(TxtAsunto, TxtLugar, TxtNotas)
        Activar(DTPkrhoratem, DTPkrhoraini, dtpFecha, txtNombreDoc)
        Activar(grdArchivos, grdTemas, cboTipo, cboResponsable, txtPlanes, cmdBuscar, cmdAgregarArchivos, cmdAgregarPlan)
        Activar(tlbBotones.Buttons.Item(2), tlbBotones.Buttons.Item(3))
        inactivar(tlbBotones.Buttons.Item(0), tlbBotones.Buttons.Item(1), tlbBotones.Buttons.Item(4), trvComites, tlbBotones.Buttons.Item(5), tlbBotones.Buttons.Item(6))

        ''grdArchivos.DataSource = Nothing
        ''grdTemas.DataSource = Nothing

        grdArchivos.ContextMenu = cmDocumentos
        grdTemas.ContextMenu = cmTemas
    End Sub

    Private Sub LlenarArbol()
        trvComites.Nodes.Clear()
        Dim dtComites As DataTable
        Dim objArbolComites As New clsArbolComites.Maple.clsArbolComites
        Dim Raiz As New TreeNode
        Raiz.Tag = 0
        Raiz.Text = "Comites"
        Raiz.ImageIndex = 0
        Raiz.SelectedImageIndex = 1

        trvComites.Nodes.Add(Raiz)

        dtComites = objArbolComites.getDatosMenu(9, "", "", "", "", "", "")
        objArbolComites = Nothing

        CrearMenuComites(dtComites, Nothing, Nothing, Nothing, 0, 1, False)
    End Sub

    Private Sub CrearMenuComites(ByVal dtDatos As DataTable, ByVal nodoCT As TreeNode, ByVal nodoSC As TreeNode, ByVal nodoGT As TreeNode, ByVal idx As Integer, ByVal ides As Integer, ByVal indGT As Boolean)
        Dim dvDatos As DataView
        Dim dtCT As DataTable
        Dim dtSC As DataTable
        Dim dtGT As DataTable
        dvDatos = New DataView(dtDatos)
        Try
            Dim aux As New clsArbolComites.Maple.clsArbolComites

            For Each dataRowCurrent As DataRowView In dvDatos
                Dim nuevoNodo As TreeNode
                nuevoNodo = New TreeNode
                nuevoNodo.Text = dataRowCurrent(idx).ToString()

                If nodoCT Is Nothing Then
                    dtCT = aux.getDatosMenu(2, "@idCM", nuevoNodo.Text.ToString, "", "", "", "")
                    CrearMenuComites(dtCT, nuevoNodo, Nothing, Nothing, 1, 2, False)
                    dtGT = aux.getDatosMenu(4, "@idCM", nuevoNodo.Text.ToString, "@idCT", "NA", "@idSC", "NA")
                    CrearMenuComites(dtGT, nuevoNodo, Nothing, Nothing, 3, 4, True)

                    REM COMITES
                    nuevoNodo.ImageIndex = 8
                    nuevoNodo.SelectedImageIndex = 7

                    AgregarSesiones(nuevoNodo)
                    trvComites.Nodes(0).Nodes.Add(nuevoNodo)
                ElseIf indGT = True Then
                    REM nodoCT.ChildNodes.Add(nuevoNodo)
                    nuevoNodo.ImageIndex = 14
                    nuevoNodo.SelectedImageIndex = 13

                    AgregarSesiones(nuevoNodo)
                    nodoCT.Nodes.Add(nuevoNodo)
                Else
                    If nodoSC Is Nothing Then
                        dtSC = aux.getDatosMenu(3, "@idCM", nodoCT.Text, "@idCT", nuevoNodo.Text, "", "")
                        CrearMenuComites(dtSC, nodoCT, nuevoNodo, Nothing, 2, 3, False)
                        dtGT = aux.getDatosMenu(4, "@idCM", nodoCT.Text, "@idCT", nuevoNodo.Text, "@idSC", "NA")
                        CrearMenuComites(dtGT, nuevoNodo, Nothing, Nothing, 3, 4, True)

                        nuevoNodo.ImageIndex = 10
                        nuevoNodo.SelectedImageIndex = 9

                        AgregarSesiones(nuevoNodo)
                        nodoCT.Nodes.Add(nuevoNodo)
                    Else
                        If nodoGT Is Nothing Then
                            dtGT = aux.getDatosMenu(4, "@idCM", nodoCT.Text.ToString, "@idCT", nodoSC.Text.ToString, "@idSC", nuevoNodo.Text.ToString)
                            CrearMenuComites(dtGT, nodoCT, nodoSC, nuevoNodo, 3, 4, False)

                            REM SC
                            nuevoNodo.ImageIndex = 12
                            nuevoNodo.SelectedImageIndex = 11

                            AgregarSesiones(nuevoNodo)
                            nodoSC.Nodes.Add(nuevoNodo)
                        Else
                            REM nodoGT.ChildNodes.Add(nuevoNodo)
                            nuevoNodo.ImageIndex = 14
                            nuevoNodo.SelectedImageIndex = 13

                            AgregarSesiones(nuevoNodo)
                            nodoGT.Nodes.Add(nuevoNodo)
                        End If
                    End If
                End If
            Next dataRowCurrent
            trvComites.CollapseAll()
            aux = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dvDatos = Nothing
            dtCT = Nothing
            dtSC = Nothing
            dtGT = Nothing
        End Try
    End Sub

    Private Sub AgregarSesiones(ByVal nodoPadre As TreeNode)
        Dim objSesiones As New clsSesiones.Maple.clsSesion
        Dim dt As DataTable
        Try
            objSesiones.Bandera = "s20"
            objSesiones.Pertenece = nodoPadre.Text
            dt = objSesiones.Listar

            For Each row As DataRow In dt.Rows
                Dim nodoSesiones As New TreeNode
                nodoSesiones.Text = row.Item("Sesion")
                nodoSesiones.ImageIndex = 15
                nodoSesiones.SelectedImageIndex = 15
                nodoSesiones.Tag = row.Item("Id_Sesion")

                nodoPadre.Nodes.Add(nodoSesiones)
                nodoSesiones = Nothing
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesiones = Nothing
            dt.Dispose()
        End Try
    End Sub

    Private Sub trvComites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles trvComites.AfterSelect
        Dim IdSesion As String = ""
        IdSesion = e.Node.Tag

        If IdSesion <> "" And IdSesion <> 0 Then
            Activar(grdArchivos, grdTemas)
            Activar(tlbBotones.Buttons.Item(1), tlbBotones.Buttons.Item(4), tlbBotones.Buttons.Item(5), tlbBotones.Buttons.Item(6))
            inactivar(tlbBotones.Buttons.Item(0), tlbBotones.Buttons.Item(2), tlbBotones.Buttons.Item(3))

            LlenarDatosSesiones(IdSesion)
        Else
            BotonesInicio()
            If e.Node.Text <> "Comites" Then Activar(tlbBotones.Buttons.Item(0))
        End If
    End Sub

    Private Sub LlenarDatosSesiones(ByVal IdSesion As Integer)
        Dim objSesiones As New clsSesiones.Maple.clsSesion
        Try
            objSesiones.Bandera = "s21"
            objSesiones.Id_Sesion = IdSesion
            objSesiones.LlenarDatos()

            txtClaveSesion.Text = trvComites.SelectedNode.Text

            DTPkrhoraini.Value = CDate(Format(Now, "dd/MM/yyyy") & " " & objSesiones.HoraI)
            DTPkrhoratem.Value = CDate(Format(Now, "dd/MM/yyyy") & " " & objSesiones.HoraT)
            dtpFecha.Value = objSesiones.Fecha
            TxtAsunto.Text = objSesiones.Asunto
            TxtLugar.Text = objSesiones.Lugar
            TxtNotas.Text = objSesiones.Notas
            cboResponsable.Text = objSesiones.Responsable

            REM llenar los temas de las sesiones
            LlenarTemasSesiones(IdSesion)

            REM llenar documentos de las sesiones
            LlenarDocumentosSesiones(IdSesion)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesiones = Nothing
        End Try
    End Sub

    Private Sub LlenarTemasSesiones(ByVal IdSesion As Integer)
        Dim objSesionesTemas As New clsSesionesTema.Maple.clsSesionesTema
        Dim dt As DataTable
        Dim datosGrid() As String
        Try
            objSesionesTemas.Bandera = "s2"
            objSesionesTemas.Id_Sesion = IdSesion
            dt = objSesionesTemas.Listar()
            datosGrid = Split("Referencia|False|0,Plan|True|60,Tema|True|-30,DeBase|False|0,Clasificacion|True|80,Inactivo|True|-13", ",")
            Estilos(grdTemas, datosGrid, dt)
            grdTemas.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesTemas = Nothing
            dt.Dispose()
        End Try
    End Sub

    Private Sub LlenarDocumentosSesiones(ByVal IdSesion)
        Dim objSesionesDocumentos As New clsSesionesDoctos.Maple.clsPSesionDoctos
        Dim dt As DataTable
        Dim datosGrid() As String

        Try
            objSesionesDocumentos.Bandera = "s3"
            objSesionesDocumentos.Id_Sesion = IdSesion
            dt = objSesionesDocumentos.Listar()
            datosGrid = Split("Id_Docto|False|0,TipoDocumento|True|48,Nombre|True|60,Documento|True|10,DeBase|False|0,Inactivo|True|-13,id_tipo_doc|False|0", ",")
            Estilos(grdArchivos, datosGrid, dt)
            grdArchivos.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesDocumentos = Nothing
            dt.Dispose()
        End Try
    End Sub

    Private Sub Estilos(ByVal grd As DataGrid, ByVal Datosgrid As Array, ByVal dt As DataTable)
        If dt Is Nothing Then Exit Sub

        Dim Columnas As Integer = dt.Columns.Count
        Dim aux() As String
        Dim tama�o As Integer = 0
        Dim ts1 As New DataGridTableStyle
        Dim col As Integer = 0

        tama�o = grd.Width / Columnas
        grd.TableStyles.Clear()

        ts1.MappingName = dt.TableName
        ColorStyle(ts1, grd)
        Try

            For col = 0 To Columnas - 1
                aux = Split(Datosgrid(col), "|")

                Dim Columna
                If dt.Columns(col).DataType.FullName = "System.Boolean" Then
                    Columna = New DataGridBoolColumn
                Else
                    Columna = New DataGridTextBoxColumn
                End If

                Columna.MappingName = dt.Columns(col).ColumnName
                Columna.HeaderText = aux(0)

                If CType(aux(1), Boolean) = False Then
                    Columna.Width = 0
                Else
                    Columna.Width = tama�o + CType(aux(2), Integer)
                End If

                Columna.NullText = ""
                ts1.GridColumnStyles.Add(Columna)
            Next

            grd.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("asegurate que las columnas coincidan con los nombres")
        End Try
    End Sub

    Public Sub ColorStyle(ByVal ts1 As DataGridTableStyle, ByVal grid As DataGrid)
        ts1.SelectionForeColor = Color.White
        ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderForeColor = Color.White
        ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
        ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)
        grid.BorderStyle = BorderStyle.Fixed3D
        grid.FlatMode = True
        grid.RowHeaderWidth = 18
    End Sub

    Private Sub LlenarTipoDoctos()
        Dim objTiposDocumentos As New clsTipoDoctos.Maple.clsTipoDoctos
        Try
            objTiposDocumentos.Bandera = "s2"
            cboTipo.DataSource = objTiposDocumentos.Listar
            cboTipo.DisplayMember = "Descripcion"
            cboTipo.ValueMember = "id_tipo_doc"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objTiposDocumentos = Nothing
        End Try
    End Sub

    Private Sub LlenarResponsables()
        Dim objempleados As New cls_empleados.Cls_empleados("COMUN", gUsuario, gPasswordSql)
        Try
            objempleados.Bandera = 6
            objempleados.ListaCombo(cboResponsable)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objempleados = Nothing
        End Try

    End Sub

    Private Sub cmdBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBuscar.Click
        SeleccionarArchivo()
    End Sub

    Private Sub SeleccionarArchivo()
        Dim ofdDocumento As New OpenFileDialog
        ofdDocumento.ShowDialog()
        txtDocumento.Text = ofdDocumento.FileName
    End Sub

    Private Sub tlbBotones_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotones.ButtonClick
        Select Case tlbBotones.Buttons.IndexOf(e.Button)
            Case 0 REM nuevo
                Estado = "Nuevo"
                BotonesNuevo()
            Case 1 REM editar
                Estado = "Edicion"
                BotonesEdicion()
            Case 2 REM deshacer
                BotonesInicio()
            Case 3 REM guardar
                If ValidarGuardado() = False Then
                    Select Case Estado
                        Case "Nuevo"
                            GuardarNuevo()
                            MsgBox("Datos Guardados correctamente")
                            BotonesInicio()
                            LlenarArbol()
                        Case "Edicion"
                            GuardarEdicion()
                            MsgBox("Datos Guardados correctamente")
                            BotonesInicio()
                            LlenarArbol()
                    End Select
                End If
            Case 4
                EliminarSesion()
            Case 5
                    GenerarListaAsistencia()
            Case 6
                    Dim SesionNotificacion As New FrmSesionNotificacion
                    SesionNotificacion.MdiParent = Me.MdiParent
                    SesionNotificacion.IdSesion = trvComites.SelectedNode.Tag
                    SesionNotificacion.Sesion = trvComites.SelectedNode.Text
                    SesionNotificacion.Show()
        End Select
    End Sub

    Private Sub GenerarListaAsistencia()
        Dim ListaAsistencia As New FrmListaAsistencia
        ListaAsistencia.MdiParent = Me.MdiParent
        ListaAsistencia.IdSesion = trvComites.SelectedNode.Tag
        ListaAsistencia.Sesion = trvComites.SelectedNode.Text
        ListaAsistencia.Comite = trvComites.SelectedNode.Parent.Text
        ListaAsistencia.SesionFecha = dtpFecha.Value

        ListaAsistencia.Show()
        ListaAsistencia.GenerarReporte()
    End Sub

    Private Sub EliminarSesion()
        If MsgBox("�Estas seguro de eliminar la sesion seleccionada?", MsgBoxStyle.Information Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
            Dim objSesiones As New clsSesiones.Maple.clsSesion
            Try
                objSesiones.Bandera = "u2"
                objSesiones.Status = 3
                objSesiones.Id_Sesion = trvComites.SelectedNode.Tag
                objSesiones.Eliminar()

                If objSesiones.respRetorno(1) = "1" Then
                    MsgBox(objSesiones.respRetorno(0))
                Else
                    MsgBox("Registro eliminado correctamente")
                    BotonesInicio()
                    LlenarArbol()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                objSesiones = Nothing
            End Try
        End If
    End Sub

    Private Function ValidarGuardado() As Boolean
        Dim band As Boolean = False
        Dim dt As DataTable = grdTemas.DataSource
        If (DTPkrhoraini.Value > DTPkrhoratem.Value) Or (DTPkrhoraini.Value = DTPkrhoratem.Value) Then
            MsgBox("la hora de inicio no puede ser mayor o igual a la hora de fin")
            band = True
        End If

        If band = False And dt Is Nothing Then
            MsgBox("No se ha seleccionado ningun tema")
            band = True
        End If

        If band = False And Not dt Is Nothing Then
            If dt.Rows.Count <= 0 Then
                MsgBox("No se ha seleccionado ningun tema")
                band = True
            End If
        End If
        dt = Nothing
        Return band
    End Function

    Private Sub GuardarNuevo()
        REM guardar datos
        Dim objSesiones As New clsSesiones.Maple.clsSesion
        Dim Comite, Ct, Sc, Gt As String
        Try
            OptenerComites(Comite, Ct, Sc, Gt, False)
            objSesiones.Bandera = "i1"
            objSesiones.Id_Comite = Comite
            objSesiones.Id_CT = Ct
            objSesiones.Id_SC = Sc
            objSesiones.Id_Grupo = Gt
            objSesiones.Fecha = Format(dtpFecha.Value, "dd/MM/yyyy")
            objSesiones.HoraI = Format(DTPkrhoraini.Value, "HH:mm:ss")
            objSesiones.HoraT = Format(DTPkrhoratem.Value, "HH:mm:ss")
            objSesiones.Asunto = TxtAsunto.Text
            objSesiones.Lugar = TxtLugar.Text
            objSesiones.Responsable = cboResponsable.SelectedValue
            objSesiones.Notas = TxtNotas.Text
            objSesiones.Status = 2
            objSesiones.No_Sol_Sala = Nothing
            objSesiones.Insertar()
            If objSesiones.respRetorno(1) = "1" Then
                MsgBox(objSesiones.respRetorno(0))
            Else
                REM inserto temas
                ProcesarTemas(objSesiones.Id_Sesion)

                REM Iserto Documentos
                ProcesarDocumentos(objSesiones.Id_Sesion, True)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesiones = Nothing
        End Try
    End Sub

    Private Sub GuardarEdicion()
        REM guardar datos
        Dim objSesiones As New clsSesiones.Maple.clsSesion
        Dim Comite, Ct, Sc, Gt As String
        Try
            OptenerComites(Comite, Ct, Sc, Gt, True)
            objSesiones.Bandera = "u1"
            objSesiones.Id_Comite = Comite
            objSesiones.Id_CT = Ct
            objSesiones.Id_SC = Sc
            objSesiones.Id_Grupo = Gt
            objSesiones.Fecha = Format(dtpFecha.Value, "dd/MM/yyyy")
            objSesiones.HoraI = Format(DTPkrhoraini.Value, "HH:mm:ss")
            objSesiones.HoraT = Format(DTPkrhoratem.Value, "HH:mm:ss")
            objSesiones.Asunto = TxtAsunto.Text
            objSesiones.Lugar = TxtLugar.Text
            objSesiones.Responsable = cboResponsable.SelectedValue
            objSesiones.Notas = TxtNotas.Text
            objSesiones.Status = 2
            objSesiones.No_Sol_Sala = Nothing
            objSesiones.Id_Sesion = trvComites.SelectedNode.Tag
            objSesiones.Actualizar()
            If objSesiones.respRetorno(1) = "1" Then
                MsgBox(objSesiones.respRetorno(0))
            Else
                REM inserto temas
                ProcesarTemas(objSesiones.Id_Sesion)

                REM Iserto Documentos
                ProcesarDocumentos(objSesiones.Id_Sesion, False)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesiones = Nothing
        End Try
    End Sub

    Private Sub ProcesarTemas(ByVal Id_Sesion As Integer)
        Dim dt As DataTable
        Dim Id_Plan As String
        Dim Id_Tema As String
        Dim Inactivo As Boolean
        Dim Referencia As String

        REM sacar el contenido del grid en un dt
        Try
            dt = grdTemas.DataSource
            For Each rows As DataRow In dt.Rows
                REM validar si viene de la base de datos o no (en caso de ser de la base se actualiza
                REM de lo contrario se guarda
                Id_Plan = rows("Id_Plan")
                Id_Tema = rows("Id_Tema")
                Inactivo = rows("Inactivo")
                If rows("DeBase") = False Then
                    REM guardo
                    GuardarSesionTema(Id_Sesion, Id_Plan, Id_Tema, Inactivo)
                Else
                    REM actualizo
                    Referencia = rows("Referencia")
                    GuardarEdicionTemas(Id_Sesion, Inactivo, Referencia)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dt = Nothing
        End Try
    End Sub

    Private Sub ProcesarDocumentos(ByVal Id_Sesion As Integer, ByVal EsNuevaSesion As Boolean)
        Dim dt As DataTable
        Dim sRutaDocto As String
        Dim id_tipo As Integer
        Dim Inactivo As Boolean
        Dim NombreDocto As String
        Dim Id_docto As Integer
        Try
            dt = grdArchivos.DataSource
            If Not dt Is Nothing Then
                For Each rows As DataRow In dt.Rows
                    REM validar si viene de la base de datos o no (en caso de ser de la base se actualiza
                    REM de lo contrario se guarda
                    sRutaDocto = rows("Docto")
                    id_tipo = rows("id_tipo_doc")
                    NombreDocto = rows("NombreDelDocumento")
                    Inactivo = rows("Inactivo")
                    If rows("DeBase") = False Then
                        REM guardo
                        GuardarDoctosTema(Id_Sesion, sRutaDocto, id_tipo, NombreDocto, Inactivo, EsNuevaSesion)
                    Else
                        Id_docto = rows("Id_docto")
                        GuardarEdicionDoctos(Id_docto, Inactivo)
                    End If
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dt = Nothing
        End Try
    End Sub

    Private Sub GuardarDoctosTema(ByVal Id_Sesion As Integer, ByVal sRutaDocto As String, ByVal id_tipo As Integer, ByVal NombreDocto As String, ByVal Inactivo As Boolean, ByVal esNuevaSesion As Boolean)
        Dim objSesionesDoctos As New clsSesionesDoctos.Maple.clsPSesionDoctos
        Dim NombreArchivo As String
        Try
            REM adjunto el documento
            NombreArchivo = AdjuntarArchivos(sRutaDocto, esNuevaSesion)
            If NombreArchivo <> "" Then
                objSesionesDoctos.Bandera = "i1"
                objSesionesDoctos.Id_Sesion = Id_Sesion
                objSesionesDoctos.Docto = NombreArchivo
                objSesionesDoctos.Id_Tipo = id_tipo
                objSesionesDoctos.Inactivo = Inactivo
                objSesionesDoctos.NombreDelDocumento = NombreDocto
                objSesionesDoctos.Insertar()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesDoctos = Nothing
        End Try
    End Sub

    Private Sub GuardarEdicionTemas(ByVal Id_Sesion As Integer, ByVal Inactivo As Boolean, ByVal Referencia As String)
        Dim objSesionesTemas As New clsSesionesTema.Maple.clsSesionesTema
        Dim dt As DataTable
        Try

            objSesionesTemas.Bandera = "u2"
            objSesionesTemas.Id_Sesion = Id_Sesion
            objSesionesTemas.Inactivo = Inactivo
            objSesionesTemas.Referencia = Referencia
            objSesionesTemas.Actualizar()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesTemas = Nothing
            dt = Nothing
        End Try
    End Sub

    Private Sub GuardarEdicionDoctos(ByVal Id_docto As Integer, ByVal inactivo As Boolean)
        Dim objSesionesDoctos As New clsSesionesDoctos.Maple.clsPSesionDoctos
        Try
            objSesionesDoctos.Bandera = "u2"
            objSesionesDoctos.Id_Docto = Id_docto
            objSesionesDoctos.Inactivo = inactivo
            objSesionesDoctos.Actualizar()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesDoctos = Nothing
        End Try
    End Sub

    Private Function AdjuntarArchivos(ByVal sRutaDocto As String, ByVal esNuevaSesion As Boolean) As String
        Dim sRutaFinal As String
        Dim Comite, Ct, Sc, Gt As String
        Dim NombreArchivo As String
        Dim Extencion As String
        Dim ArchivoArr() As String
        Dim porSesion As Boolean = IIf(esNuevaSesion = True, False, True)

        OptenerComites(Comite, Ct, Sc, Gt, porSesion)

        Try

            Dim sRutaDoctos = Configuration.ConfigurationSettings.AppSettings("DocumentosProceso").ToString
            Dim Ruta = Comite & "\" _
                    & IIf(Ct = "NA", "", Ct & "\") _
                    & IIf(Sc = "NA", "", Sc & "\") _
                    & IIf(Gt = "NA", "", Gt & "\")

            If Not Directory.Exists(sRutaDoctos & Ruta) Then Directory.CreateDirectory(sRutaDoctos & Ruta)
            System.Threading.Thread.Sleep(200)
            NombreArchivo = "DocSes_" & Format(Now, "dMyy_hhmmss") & Now.Millisecond.ToString
            ArchivoArr = Split(sRutaDocto, ".")
            NombreArchivo &= "." & ArchivoArr(ArchivoArr.Length - 1)

            File.Copy(sRutaDocto, sRutaDoctos & Ruta & NombreArchivo)

        Catch ex As Exception
            MsgBox(ex.Message)
            NombreArchivo = ""
        End Try

        Return NombreArchivo
    End Function

    Private Sub GuardarSesionTema(ByVal Id_Sesion As Integer, ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal Inactivo As Boolean)
        Dim objSesionesTemas As New clsSesionesTema.Maple.clsSesionesTema
        Dim objSesionesTemasTrab As New clsSesionesTema.Maple.clsSesionesTema
        Dim dt As DataTable
        Try
            objSesionesTemasTrab.Bandera = "s4"
            objSesionesTemasTrab.Id_Plan = Id_Plan
            objSesionesTemasTrab.Id_Tema = Id_Tema
            dt = objSesionesTemasTrab.Listar()

            objSesionesTemas.Bandera = "i1"
            objSesionesTemas.Id_Sesion = Id_Sesion
            objSesionesTemas.Id_Plan = Id_Plan
            objSesionesTemas.Id_Tema = Id_Tema
            objSesionesTemas.Inactivo = Inactivo
            objSesionesTemas.ref_a�o = IIf(IsDBNull(dt.Rows(0).Item("ref_a�o")), "", dt.Rows(0).Item("ref_a�o"))
            objSesionesTemas.ref_comite = IIf(IsDBNull(dt.Rows(0).Item("ref_comite")), "", dt.Rows(0).Item("ref_comite"))
            objSesionesTemas.ref_consecutivo = IIf(IsDBNull(dt.Rows(0).Item("ref_consecutivo")), "", dt.Rows(0).Item("ref_consecutivo"))
            objSesionesTemas.ref_regreso = IIf(IsDBNull(dt.Rows(0).Item("ref_regreso")), "", dt.Rows(0).Item("ref_regreso"))
            objSesionesTemas.ref_traspaso = IIf(IsDBNull(dt.Rows(0).Item("ref_traspaso")), "", dt.Rows(0).Item("ref_traspaso"))
            objSesionesTemas.Insertar()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesTemas = Nothing
            objSesionesTemasTrab = Nothing
            dt = Nothing
        End Try

    End Sub

    Private Sub OptenerComites(ByRef Comite As String, ByRef Ct As String, ByRef Sc As String, ByRef Gt As String, ByVal porSesion As Boolean)
        Dim dt As DataTable
        Dim objSesion As New clsSesiones.Maple.clsSesion
        Dim fullPhat() As String = Split(trvComites.SelectedNode.FullPath, "\")
        Try
            objSesion.Bandera = "s22"
            If porSesion = True Then
                objSesion.Id_Comite = fullPhat(fullPhat.Length - 2)
            Else
                objSesion.Id_Comite = trvComites.SelectedNode.Text
            End If

            dt = objSesion.Listar()
            If Not dt Is Nothing Then
                Comite = IIf(IsDBNull(dt.Rows(0).Item("ID_Comite")), "", dt.Rows(0).Item("ID_Comite"))
                Ct = IIf(IsDBNull(dt.Rows(0).Item("ID_CT")), "", dt.Rows(0).Item("ID_CT"))
                Sc = IIf(IsDBNull(dt.Rows(0).Item("Id_SC")), "", dt.Rows(0).Item("Id_SC"))
                Gt = IIf(IsDBNull(dt.Rows(0).Item("ID_Grupo")), "", dt.Rows(0).Item("ID_Grupo"))
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesion = Nothing
            dt = Nothing
        End Try
    End Sub

    Private Sub txtPlanes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPlanes.Click
        CrearArbolTemas()
    End Sub

    Private Sub CrearArbolTemas()

        Dim objTemas As New clsViewTree.cls(0, gUsuario, gPasswordSql)
        Dim dt As DataTable
        Dim dtDPy As DataTable
        Dim nodo As New TreeNode
        Dim nodoAux As New TreeNode


        Try
            objArbolTemas.Nodes.Clear()
            objArbolTemas.Visible = True
            dt = objTemas.ListaPNN("")

            nodo.Text = "Planes"
            nodo.ImageIndex = 2
            nodo.SelectedImageIndex = 2
            objArbolTemas.Nodes.Add(nodo)

            For Each RegPNN As DataRow In dt.Rows '******Planes
                nodo = objArbolTemas.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
                nodo.ImageIndex = 3
                nodo.SelectedImageIndex = 4
                dtDPy = objTemas.ListaDprog(Trim(RegPNN("id_plan")))
                For Each RegDPy As DataRow In dtDPy.Rows
                    nodoAux = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                    nodoAux.SelectedImageIndex = 5
                    nodoAux.ImageIndex = 5
                Next
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objTemas = Nothing
            dt = Nothing
            nodo = Nothing
            dtDPy = Nothing
            nodoAux = Nothing
        End Try

    End Sub

    Private Sub CrearArbol()
        objArbolTemas.Name = "trvPlanes"
        objArbolTemas.Width = 250
        objArbolTemas.Height = 250
        objArbolTemas.Enabled = True
        objArbolTemas.Visible = False
        objArbolTemas.ImageList = imgListTreeView

        LlenarArbol()

        AddHandler objArbolTemas.AfterSelect, AddressOf objArbolTemas_AfterSelect
        AddHandler objArbolTemas.DoubleClick, AddressOf objArbolTemas_DoubleClick
        ''AddHandler objArbol.MouseLeave, AddressOf trvPertenece_MouseLeave

        objArbolTemas.Location = (New Point(txtPlanes.Location.X + 260, 140))

        Me.Controls.Add(objArbolTemas)
        objArbolTemas.BringToFront()
    End Sub

    Private Sub objArbolTemas_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs)
        If e.Node.Text <> "" And objArbolTemas.Nodes(0).Text <> e.Node.Text Then
            If IsNumeric(e.Node.Text) Then
                ObtenerDatosTemas(e.Node.Parent.Text, e.Node.Text)
            End If
        End If
    End Sub

    ''Private Sub trvPertenece_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)
    ''    objArbol.Visible = False
    ''End Sub

    Private Sub objArbolTemas_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
        objArbolTemas.Visible = False
    End Sub

    Private Sub ObtenerDatosTemas(ByVal Plan As String, ByVal Tema As Integer)
        Dim objSesionesTemas As New clsSesionesTema.Maple.clsSesionesTema
        Dim dt As DataTable
        Try
            objSesionesTemas.Bandera = "s3"
            objSesionesTemas.Id_Tema = Tema
            objSesionesTemas.Id_Plan = Plan
            dt = objSesionesTemas.Listar

            txtPlanes.Text = IIf(IsDBNull(dt.Rows(0).Item("Id_Plan")), "", dt.Rows(0).Item("Id_Plan"))
            txtPlanes.Text &= " | " & IIf(IsDBNull(dt.Rows(0).Item("Id_Tema")), "", dt.Rows(0).Item("Id_Tema"))
            txtPlanes.Text &= " | " & IIf(IsDBNull(dt.Rows(0).Item("Clasificacion")), "", dt.Rows(0).Item("Clasificacion"))

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objSesionesTemas = Nothing
        End Try
    End Sub

    Private Sub cmdAgregarPlan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAgregarPlan.Click
        If txtPlanes.Text.Trim = "" Then
            MsgBox("No se ha seleccionado ningun tema")
        Else
            AgregarNuevoTema()
        End If

    End Sub

    Private Sub AgregarNuevoTema()
        Dim dt As DataTable
        Dim row As DataRow
        Dim datosGrid() As String
        Try
            If grdTemas.DataSource Is Nothing Then
                CrearDtTemas(dt)
            Else
                dt = grdTemas.DataSource
            End If

            row = dt.NewRow
            row("Referencia") = ""
            row("Id_Plan") = Split(txtPlanes.Text, " | ")(0)
            row("Id_Tema") = Split(txtPlanes.Text, " | ")(1)
            row("DeBase") = 0
            row("Clasificacion") = Split(txtPlanes.Text, " | ")(2)
            row("Inactivo") = 0
            dt.Rows.Add(row)

            grdTemas.DataSource = dt
            Limpiar(txtPlanes)

            datosGrid = Split("Referencia|False|0,Plan|True|60,Tema|True|-30,DeBase|False|0,Clasificacion|True|80,Inactivo|True|-13", ",")
            Estilos(grdTemas, datosGrid, dt)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dt = Nothing
            row = Nothing
        End Try

    End Sub

    Private Sub CrearDtTemas(ByRef dt As DataTable)
        dt = New DataTable("Datos")
        dt.Columns.Add("Referencia", Type.GetType("System.String"))
        dt.Columns.Add("Id_Plan", Type.GetType("System.String"))
        dt.Columns.Add("Id_Tema", GetType(Integer))
        dt.Columns.Add("DeBase", GetType(Boolean))
        dt.Columns.Add("Clasificacion", Type.GetType("System.String"))
        dt.Columns.Add("Inactivo", GetType(Boolean))
    End Sub

    Private Sub cmdAgregarArchivos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAgregarArchivos.Click
        If txtDocumento.Text.Trim = "" Or txtNombreDoc.Text.Trim = "" Then
            MsgBox("No se ha seleccionado ningun documento o falta el nombre del documento")
        Else
            AgregarNuevoDocumento()
        End If
    End Sub

    Private Sub AgregarNuevoDocumento()
        Dim dt As DataTable
        Dim row As DataRow
        Dim datosGrid() As String
        Try
            If grdArchivos.DataSource Is Nothing Then
                CrearDtDocumentos(dt)
            Else
                dt = grdArchivos.DataSource
            End If

            row = dt.NewRow
            row("Id_Docto") = ""
            row("TipoDocumento") = cboTipo.Text
            row("NombreDelDocumento") = txtNombreDoc.Text
            row("Docto") = txtDocumento.Text
            row("DeBase") = 0
            row("Inactivo") = 0
            row("id_tipo_doc") = cboTipo.SelectedValue
            dt.Rows.Add(row)

            grdArchivos.DataSource = dt
            Limpiar(txtDocumento, txtNombreDoc)

            datosGrid = Split("Id_Docto|False|0,TipoDocumento|True|48,Nombre|True|60,Documento|True|10,DeBase|False|0,Inactivo|True|-13,id_tipo_doc|False|0", ",")
            Estilos(grdArchivos, datosGrid, dt)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dt = Nothing
            row = Nothing
        End Try

    End Sub

    Private Sub CrearDtDocumentos(ByRef dt As DataTable)
        dt = New DataTable("Datos")
        dt.Columns.Add("Id_Docto", Type.GetType("System.String"))
        dt.Columns.Add("TipoDocumento", Type.GetType("System.String"))
        dt.Columns.Add("NombreDelDocumento", Type.GetType("System.String"))
        dt.Columns.Add("Docto", Type.GetType("System.String"))
        dt.Columns.Add("DeBase", GetType(Boolean))
        dt.Columns.Add("Inactivo", GetType(Boolean))
        dt.Columns.Add("id_tipo_doc", GetType(Integer))
    End Sub

    Private Sub cmdInactivarTema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInactivarTema.Click
        ActivarInactivar(5, grdTemas, True)
    End Sub

    Private Sub cmdActivarTema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdActivarTema.Click
        ActivarInactivar(5, grdTemas, False)
    End Sub

    Private Sub cmdInactivarDoctos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInactivarDoctos.Click
        ActivarInactivar(5, grdArchivos, True)
    End Sub

    Private Sub cmdActivarDoctos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdActivarDoctos.Click
        ActivarInactivar(5, grdArchivos, False)
    End Sub

    Private Sub ActivarInactivar(ByVal IndexColumna As Integer, ByVal grd As DataGrid, ByVal inActivo As Boolean)
        Dim Index As Integer

        REM saber el indice de la tabla
        If Not grd Is Nothing Then
            Index = grd.CurrentRowIndex

            grd.Item(Index, IndexColumna) = inActivo
        End If
    End Sub

    Private Sub AbrirArchivo()
        Dim Index As Integer
        Dim Comite, Ct, Sc, Gt As String
        Dim Documento As String

        REM saber el indice de la tabla
        If Not grdArchivos.DataSource Is Nothing Then
            Index = grdArchivos.CurrentRowIndex
            If Index < 0 Then Exit Sub

            OptenerComites(Comite, Ct, Sc, Gt, True)
            Documento = grdArchivos.Item(Index, 3)
            If Documento <> "" Then
                Dim sRutaDoctos = Configuration.ConfigurationSettings.AppSettings("DocumentosProceso").ToString
                Dim Ruta = Comite & "\" _
                        & IIf(Ct = "NA", "", Ct & "\") _
                        & IIf(Sc = "NA", "", Sc & "\") _
                        & IIf(Gt = "NA", "", Gt & "\")

                If grdArchivos.Item(Index, 4) = True Then
                    If File.Exists(sRutaDoctos & Ruta & Documento) Then
                        System.Diagnostics.Process.Start(sRutaDoctos & Ruta & Documento)
                    End If
                Else
                    If File.Exists(Documento) Then
                        System.Diagnostics.Process.Start(Documento)
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub grdArchivos_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdArchivos.DoubleClick
        AbrirArchivo()
    End Sub
End Class
