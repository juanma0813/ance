
Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms


Public Class C_Representacion

    '''''''Declaracion de Variables Privadas
    Private dsC_Representacion As New DataSet
    Private cn As New SQLConnection
    Private _ID_Representacion As Int32
    Private _Bandera As Int32
    Private _Descripcion As String
    Private _Comite As Boolean
    Private _CT As Boolean
    Private _Inactivo As Int32
    Private sSql As String
    Dim objconexion1 As New clsConexion.cIsConexion

    Public Sub New(ByVal Identificador As String, ByVal Usuario As String, ByVal Password As String)
        objconexion1.ConexionAnce(Application.StartupPath + "\principal.ini", Identificador, Usuario, Password)
        cn.ConnectionString = "Data source = " + objconexion1.Server + "; Initial Catalog = " + objconexion1.Base + "; User Id = " + Usuario + "; Pwd =  " + Password

    End Sub

    '''''''Declaracion de Propiedades publicas
    Public Property Bandera()
        Get
            Return _Bandera
        End Get
        Set(ByVal Value)
            _Bandera = Value
        End Set
    End Property

    Public Property ID_Representacion()
        Get
            Return _ID_Representacion
        End Get
        Set(ByVal Value)
            _ID_Representacion = Value
        End Set
    End Property

    Public Property Descripcion()
        Get
            Return _Descripcion
        End Get
        Set(ByVal Value)
            _Descripcion = Value
        End Set
    End Property

    Public Property Comite()
        Get
            Return _Comite
        End Get
        Set(ByVal Value)
            _Comite = Value
        End Set
    End Property

    Public Property CT()
        Get
            Return _CT
        End Get
        Set(ByVal Value)
            _CT = Value
        End Set
    End Property

    Public Property Inactivo()
        Get
            Return _Inactivo
        End Get
        Set(ByVal Value)
            Inactivo = Value
        End Set
    End Property


   
    '''''''''''''''''Genera una la lista de campos
    Public Sub ListaCombo(ByVal cbo As Object)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Representacion_Buscar" 'Cargo
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Representacion")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            cbo.DataSource = dt
            cbo.DisplayMember = dt.Columns(1).ColumnName
            cbo.ValueMember = dt.Columns(0).ColumnName
        Catch ex As Exception
        End Try
    End Sub

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Sub Buscar()
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        ' sSql = "SELECT * FROM C_Representacion WHERE Campo_Llave = sClave"
        Dim cmd As New SqlCommand

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_C_Representacion_Buscar "
        cmd.Connection = cn
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Descripcion", _Descripcion)
        cmd.Parameters.Add("@Comite", _Comite)
        cmd.Parameters.Add("@CT", _CT)
        cmd.Parameters.Add("@ID_Representacion", _ID_Representacion)
        Try
            cn.Open()
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            If dr.Read Then
                _ID_Representacion = dr("ID_Representacion")
                _Descripcion = dr("Descripcion")
                _Comite = dr("Comite")
                _CT = dr("CT")
                _Inactivo = dr("Inactivo")
            Else
                _ID_Representacion = ""
                _Descripcion = ""
                _Comite = ""
                _CT = ""
                _Inactivo = ""
            End If
            cn.Close()
        Catch ex As Exception
        End Try
    End Sub



    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_representacion"
            .Parameters.Add("@ID_Representacion", _ID_Representacion)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Comite", _Comite)
            .Parameters.Add("@CT", _CT)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function Insertar() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_representacion"
            '      .Parameters.Add("@ID_Representacion", _ID_Representacion)
            .Parameters.Add("@Descripcion", _Descripcion)
            .Parameters.Add("@Comite", _Comite)
            .Parameters.Add("@CT", _CT)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function borra() As String
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
        Dim cmd As New SqlCommand
        With cmd
            .CommandType = CommandType.StoredProcedure
            .Connection = cn
            .CommandText = "sp_c_representacion"
            .Parameters.Add("@ID_Representacion", _ID_Representacion)
            .Parameters.Add("@Bandera", _Bandera)
        End With
        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            'Return True
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
        '
    End Function
End Class
