'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
'   NOMBRE DE LA CLASE: CLASE DE CONEXION ARCHIVO DE CONTABILIDAD
'   DESARROLLADA POR : EXTI, S.C. PARA ANCE, A.C.
'                      EMMANUEL ESPINOSA JUAREZ 
'   FECHA: 30 SEPTIEMBRE 2005
'
'   BASES RELACIONADAS: DEPENDIENDO DEL ARCHIVO .INI
'
'   TIPO: SOLO LECTURA
'
'   DESCRIPCION: REQUIERO OBLIGATORIAMENTE:
'                Identif = 0 PARA IDNETIFICAR QUE SE CONCECTA A LA BASE PRINCIPAL (NORMALIZACION)
'                Identif = 1 PARA IDENTIFICAR QUE SE CONECTA A LA BASE COMUN (dbANCE)
'                Usuario = id_Usuario QUE CREA LA CONEXION
'                Password = CLAVE DE ACCESO

'
'   FECHA MODIFICACION: 
'   MODIFICACION REALIZADA:
'
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Imports System.IO

Public Class ClsCopiaArchivos
    Private _er As Boolean

    Public Property er() As Boolean
        Get
            Return _er
        End Get
        Set(ByVal Value As Boolean)
            _er = Value
        End Set
    End Property




    Public Function CopiaArchivos(ByVal RutaOrigen As String, ByVal RutaDestino As String, ByVal rutaOriginal As String)

        'Dim fs As FileStream = File.Create(RutaOrigen)
        Dim Path2 As String
        Dim iindice As Integer
        Dim Archivo As String

        _er = False

        For iindice = Len(RutaOrigen) To 1 Step -1
            If Mid(RutaOrigen, iindice, 1) = "\" Then
                Archivo = Mid(RutaOrigen, iindice)
                iindice = 1
            End If
        Next iindice
        Path2 = RutaDestino
        If File.Exists(Path2) Then
            If MsgBox("El archivo ya existe en el Servidor, desea sobrescribir el archivo...", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.Yes Then
                File.Delete(Path2)
                File.Copy(RutaOrigen, Path2, True)
            End If
        Else
            Try
                If Not Directory.Exists(rutaOriginal) Then
                    MsgBox("El directorio: " + rutaOriginal + "No existe se creara el directorio")
                    'si la ruta no existe se crea 
                    Directory.CreateDirectory(rutaOriginal)
                End If
                File.Copy(RutaOrigen, Path2, False)
            Catch ex As Exception
                MsgBox("Error al adjuntar el archivo compruebe que existan las carpetas pertinentes dentro de NormaNet: " + ex.Message)
                _er = True
            End Try
        End If
    End Function
End Class
