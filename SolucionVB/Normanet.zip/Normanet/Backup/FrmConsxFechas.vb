Public Class FrmConsxFechas
    Inherits System.Windows.Forms.Form

#Region " Referencias instanciadas"

    Private objtreeview As New clsViewTree.cls(0, gUsuario, gPasswordSql)
    Private ObjFechasavance As New ClsAvanceFechas.P_Avance_Temas_Fechas(0, gUsuario, gPasswordSql)
    Dim Matriz As Array
    Dim svariable As String
    Dim sraiz As String
    Dim bandera As Integer
    Dim sPlan As String
    Dim stema As String
    Dim ultimo_obj As CheckBox

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TxtTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DGridResultados As System.Windows.Forms.DataGrid
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents F_Car_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Car_Act_Apr_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Acu_DGN_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Imp_Act_Apr_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Edi_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Ter_Rev_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Ini_Rev_PROYF As System.Windows.Forms.CheckBox
    Friend WithEvents F_Vo_Bo_Com As System.Windows.Forms.CheckBox
    Friend WithEvents f_Apr_Res_Come_Pub As System.Windows.Forms.CheckBox
    Friend WithEvents TVPNN As System.Windows.Forms.TreeView
    Friend WithEvents F_Act_Apro As System.Windows.Forms.CheckBox
    Friend WithEvents F_Imp_Act_Apro As System.Windows.Forms.CheckBox
    Friend WithEvents F_Car_DT_Fin As System.Windows.Forms.CheckBox
    Friend WithEvents F_Apro_Rev_Edit As System.Windows.Forms.CheckBox
    Friend WithEvents f_ini_des_nmx As System.Windows.Forms.CheckBox
    Friend WithEvents F_Lim_Res_Come_Pub As System.Windows.Forms.CheckBox
    Friend WithEvents F_Car_Min_Fin_Pro_Alt As System.Windows.Forms.CheckBox
    Friend WithEvents F_Ini_Pro_Alt As System.Windows.Forms.CheckBox
    Friend WithEvents F_Res_Come_Pub As System.Windows.Forms.CheckBox
    Friend WithEvents F_Lim_Come_Pub As System.Windows.Forms.CheckBox
    Friend WithEvents F_Pub_Come_Pub As System.Windows.Forms.CheckBox
    Friend WithEvents F_Apr_Com_Proy As System.Windows.Forms.CheckBox
    Friend WithEvents F_Car_Ant_Fin As System.Windows.Forms.CheckBox
    Friend WithEvents F_Apr_Ant_CT_GT As System.Windows.Forms.CheckBox
    Friend WithEvents Todo As System.Windows.Forms.CheckBox
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdBuscar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdImprimir As System.Windows.Forms.ToolBarButton
    Friend WithEvents separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdQuitar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmConsxFechas))
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.TxtTotal = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.DGridResultados = New System.Windows.Forms.DataGrid
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmdQuitar = New System.Windows.Forms.Button
        Me.Todo = New System.Windows.Forms.CheckBox
        Me.F_Car_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Car_Act_Apr_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Acu_DGN_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Imp_Act_Apr_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Edi_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Ter_Rev_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Ini_Rev_PROYF = New System.Windows.Forms.CheckBox
        Me.F_Vo_Bo_Com = New System.Windows.Forms.CheckBox
        Me.f_Apr_Res_Come_Pub = New System.Windows.Forms.CheckBox
        Me.F_Lim_Res_Come_Pub = New System.Windows.Forms.CheckBox
        Me.F_Car_Min_Fin_Pro_Alt = New System.Windows.Forms.CheckBox
        Me.F_Ini_Pro_Alt = New System.Windows.Forms.CheckBox
        Me.F_Res_Come_Pub = New System.Windows.Forms.CheckBox
        Me.F_Lim_Come_Pub = New System.Windows.Forms.CheckBox
        Me.F_Pub_Come_Pub = New System.Windows.Forms.CheckBox
        Me.F_Apr_Com_Proy = New System.Windows.Forms.CheckBox
        Me.F_Car_Ant_Fin = New System.Windows.Forms.CheckBox
        Me.F_Apr_Ant_CT_GT = New System.Windows.Forms.CheckBox
        Me.F_Act_Apro = New System.Windows.Forms.CheckBox
        Me.F_Imp_Act_Apro = New System.Windows.Forms.CheckBox
        Me.F_Car_DT_Fin = New System.Windows.Forms.CheckBox
        Me.F_Apro_Rev_Edit = New System.Windows.Forms.CheckBox
        Me.f_ini_des_nmx = New System.Windows.Forms.CheckBox
        Me.TVPNN = New System.Windows.Forms.TreeView
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdBuscar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdImprimir = New System.Windows.Forms.ToolBarButton
        Me.separador1 = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        CType(Me.DGridResultados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'TxtTotal
        '
        Me.TxtTotal.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TxtTotal.Location = New System.Drawing.Point(872, 454)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(120, 20)
        Me.TxtTotal.TabIndex = 119
        Me.TxtTotal.Text = ""
        Me.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Label1.Location = New System.Drawing.Point(816, 456)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 16)
        Me.Label1.TabIndex = 118
        Me.Label1.Text = "Total:"
        '
        'DGridResultados
        '
        Me.DGridResultados.CaptionBackColor = System.Drawing.Color.Blue
        Me.DGridResultados.CaptionVisible = False
        Me.DGridResultados.DataMember = ""
        Me.DGridResultados.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.DGridResultados.HeaderBackColor = System.Drawing.Color.Blue
        Me.DGridResultados.HeaderForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.DGridResultados.Location = New System.Drawing.Point(472, 16)
        Me.DGridResultados.Name = "DGridResultados"
        Me.DGridResultados.Size = New System.Drawing.Size(520, 432)
        Me.DGridResultados.TabIndex = 116
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdQuitar)
        Me.GroupBox1.Controls.Add(Me.Todo)
        Me.GroupBox1.Controls.Add(Me.F_Car_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Car_Act_Apr_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Acu_DGN_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Imp_Act_Apr_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Edi_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Ter_Rev_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Ini_Rev_PROYF)
        Me.GroupBox1.Controls.Add(Me.F_Vo_Bo_Com)
        Me.GroupBox1.Controls.Add(Me.f_Apr_Res_Come_Pub)
        Me.GroupBox1.Controls.Add(Me.F_Lim_Res_Come_Pub)
        Me.GroupBox1.Controls.Add(Me.F_Car_Min_Fin_Pro_Alt)
        Me.GroupBox1.Controls.Add(Me.F_Ini_Pro_Alt)
        Me.GroupBox1.Controls.Add(Me.F_Res_Come_Pub)
        Me.GroupBox1.Controls.Add(Me.F_Lim_Come_Pub)
        Me.GroupBox1.Controls.Add(Me.F_Pub_Come_Pub)
        Me.GroupBox1.Controls.Add(Me.F_Apr_Com_Proy)
        Me.GroupBox1.Controls.Add(Me.F_Car_Ant_Fin)
        Me.GroupBox1.Controls.Add(Me.F_Apr_Ant_CT_GT)
        Me.GroupBox1.Controls.Add(Me.F_Act_Apro)
        Me.GroupBox1.Controls.Add(Me.F_Imp_Act_Apro)
        Me.GroupBox1.Controls.Add(Me.F_Car_DT_Fin)
        Me.GroupBox1.Controls.Add(Me.F_Apro_Rev_Edit)
        Me.GroupBox1.Controls.Add(Me.f_ini_des_nmx)
        Me.GroupBox1.Location = New System.Drawing.Point(184, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 464)
        Me.GroupBox1.TabIndex = 189
        Me.GroupBox1.TabStop = False
        '
        'cmdQuitar
        '
        Me.cmdQuitar.Location = New System.Drawing.Point(168, 432)
        Me.cmdQuitar.Name = "cmdQuitar"
        Me.cmdQuitar.TabIndex = 214
        Me.cmdQuitar.Text = "Quitar Todas"
        '
        'Todo
        '
        Me.Todo.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Todo.Location = New System.Drawing.Point(32, 432)
        Me.Todo.Name = "Todo"
        Me.Todo.TabIndex = 212
        Me.Todo.Text = "Todas"
        '
        'F_Car_PROYF
        '
        Me.F_Car_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Car_PROYF.Location = New System.Drawing.Point(16, 400)
        Me.F_Car_PROYF.Name = "F_Car_PROYF"
        Me.F_Car_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Car_PROYF.TabIndex = 211
        Me.F_Car_PROYF.Text = "Fecha de Carga PROYF"
        '
        'F_Car_Act_Apr_PROYF
        '
        Me.F_Car_Act_Apr_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Car_Act_Apr_PROYF.Location = New System.Drawing.Point(16, 368)
        Me.F_Car_Act_Apr_PROYF.Name = "F_Car_Act_Apr_PROYF"
        Me.F_Car_Act_Apr_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Car_Act_Apr_PROYF.TabIndex = 210
        Me.F_Car_Act_Apr_PROYF.Text = "Fecha de Carga acta de Aprobaci�n PROYF"
        '
        'F_Acu_DGN_PROYF
        '
        Me.F_Acu_DGN_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Acu_DGN_PROYF.Location = New System.Drawing.Point(16, 384)
        Me.F_Acu_DGN_PROYF.Name = "F_Acu_DGN_PROYF"
        Me.F_Acu_DGN_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Acu_DGN_PROYF.TabIndex = 209
        Me.F_Acu_DGN_PROYF.Text = "Fecha de acuse DGN PROYF"
        '
        'F_Imp_Act_Apr_PROYF
        '
        Me.F_Imp_Act_Apr_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Imp_Act_Apr_PROYF.Location = New System.Drawing.Point(16, 352)
        Me.F_Imp_Act_Apr_PROYF.Name = "F_Imp_Act_Apr_PROYF"
        Me.F_Imp_Act_Apr_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Imp_Act_Apr_PROYF.TabIndex = 208
        Me.F_Imp_Act_Apr_PROYF.Text = "Fecha de Impresi�n acta aprobaci�n PROYF"
        '
        'F_Edi_PROYF
        '
        Me.F_Edi_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Edi_PROYF.Location = New System.Drawing.Point(16, 336)
        Me.F_Edi_PROYF.Name = "F_Edi_PROYF"
        Me.F_Edi_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Edi_PROYF.TabIndex = 207
        Me.F_Edi_PROYF.Text = "Fecha de edici�n PROYF"
        '
        'F_Ter_Rev_PROYF
        '
        Me.F_Ter_Rev_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Ter_Rev_PROYF.Location = New System.Drawing.Point(16, 320)
        Me.F_Ter_Rev_PROYF.Name = "F_Ter_Rev_PROYF"
        Me.F_Ter_Rev_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Ter_Rev_PROYF.TabIndex = 206
        Me.F_Ter_Rev_PROYF.Text = "Fecha T�rmino Revisi�n PROYF"
        '
        'F_Ini_Rev_PROYF
        '
        Me.F_Ini_Rev_PROYF.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Ini_Rev_PROYF.Location = New System.Drawing.Point(16, 304)
        Me.F_Ini_Rev_PROYF.Name = "F_Ini_Rev_PROYF"
        Me.F_Ini_Rev_PROYF.Size = New System.Drawing.Size(256, 16)
        Me.F_Ini_Rev_PROYF.TabIndex = 205
        Me.F_Ini_Rev_PROYF.Text = "Fecha de Inicio Revisi�n PROYF"
        '
        'F_Vo_Bo_Com
        '
        Me.F_Vo_Bo_Com.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Vo_Bo_Com.Location = New System.Drawing.Point(16, 288)
        Me.F_Vo_Bo_Com.Name = "F_Vo_Bo_Com"
        Me.F_Vo_Bo_Com.Size = New System.Drawing.Size(256, 16)
        Me.F_Vo_Bo_Com.TabIndex = 204
        Me.F_Vo_Bo_Com.Text = "Fecha Vo Bo Comit�"
        '
        'f_Apr_Res_Come_Pub
        '
        Me.f_Apr_Res_Come_Pub.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.f_Apr_Res_Come_Pub.Location = New System.Drawing.Point(16, 264)
        Me.f_Apr_Res_Come_Pub.Name = "f_Apr_Res_Come_Pub"
        Me.f_Apr_Res_Come_Pub.Size = New System.Drawing.Size(256, 24)
        Me.f_Apr_Res_Come_Pub.TabIndex = 203
        Me.f_Apr_Res_Come_Pub.Text = "Fecha de Aprobaci�n de Resoluci�n a comentario P�blico"
        '
        'F_Lim_Res_Come_Pub
        '
        Me.F_Lim_Res_Come_Pub.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Lim_Res_Come_Pub.Location = New System.Drawing.Point(16, 240)
        Me.F_Lim_Res_Come_Pub.Name = "F_Lim_Res_Come_Pub"
        Me.F_Lim_Res_Come_Pub.Size = New System.Drawing.Size(256, 24)
        Me.F_Lim_Res_Come_Pub.TabIndex = 202
        Me.F_Lim_Res_Come_Pub.Text = "Fecha L�mite de Resoluci�n a Comentario P�blico"
        '
        'F_Car_Min_Fin_Pro_Alt
        '
        Me.F_Car_Min_Fin_Pro_Alt.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Car_Min_Fin_Pro_Alt.Location = New System.Drawing.Point(16, 216)
        Me.F_Car_Min_Fin_Pro_Alt.Name = "F_Car_Min_Fin_Pro_Alt"
        Me.F_Car_Min_Fin_Pro_Alt.Size = New System.Drawing.Size(256, 24)
        Me.F_Car_Min_Fin_Pro_Alt.TabIndex = 201
        Me.F_Car_Min_Fin_Pro_Alt.Text = "Fecha de Carga Minuta de Fin de Procedimiento Alternativo"
        '
        'F_Ini_Pro_Alt
        '
        Me.F_Ini_Pro_Alt.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Ini_Pro_Alt.Location = New System.Drawing.Point(16, 200)
        Me.F_Ini_Pro_Alt.Name = "F_Ini_Pro_Alt"
        Me.F_Ini_Pro_Alt.Size = New System.Drawing.Size(256, 16)
        Me.F_Ini_Pro_Alt.TabIndex = 200
        Me.F_Ini_Pro_Alt.Text = "Fecha de Inicio Procedimiento Alternativo"
        '
        'F_Res_Come_Pub
        '
        Me.F_Res_Come_Pub.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Res_Come_Pub.Location = New System.Drawing.Point(16, 184)
        Me.F_Res_Come_Pub.Name = "F_Res_Come_Pub"
        Me.F_Res_Come_Pub.Size = New System.Drawing.Size(256, 16)
        Me.F_Res_Come_Pub.TabIndex = 199
        Me.F_Res_Come_Pub.Text = "Fecha de Resoluci�n Comentario P�blico"
        '
        'F_Lim_Come_Pub
        '
        Me.F_Lim_Come_Pub.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Lim_Come_Pub.Location = New System.Drawing.Point(16, 168)
        Me.F_Lim_Come_Pub.Name = "F_Lim_Come_Pub"
        Me.F_Lim_Come_Pub.Size = New System.Drawing.Size(256, 16)
        Me.F_Lim_Come_Pub.TabIndex = 198
        Me.F_Lim_Come_Pub.Text = "Fecha L�mite Comentario P�blico"
        '
        'F_Pub_Come_Pub
        '
        Me.F_Pub_Come_Pub.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Pub_Come_Pub.Location = New System.Drawing.Point(16, 152)
        Me.F_Pub_Come_Pub.Name = "F_Pub_Come_Pub"
        Me.F_Pub_Come_Pub.Size = New System.Drawing.Size(256, 16)
        Me.F_Pub_Come_Pub.TabIndex = 197
        Me.F_Pub_Come_Pub.Text = "Fecha de Publicaci�n Comentario P�blico"
        '
        'F_Apr_Com_Proy
        '
        Me.F_Apr_Com_Proy.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Apr_Com_Proy.Location = New System.Drawing.Point(16, 136)
        Me.F_Apr_Com_Proy.Name = "F_Apr_Com_Proy"
        Me.F_Apr_Com_Proy.Size = New System.Drawing.Size(256, 16)
        Me.F_Apr_Com_Proy.TabIndex = 196
        Me.F_Apr_Com_Proy.Text = "Fecha de Aprobaci�n Comit� Proy"
        '
        'F_Car_Ant_Fin
        '
        Me.F_Car_Ant_Fin.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Car_Ant_Fin.Location = New System.Drawing.Point(16, 120)
        Me.F_Car_Ant_Fin.Name = "F_Car_Ant_Fin"
        Me.F_Car_Ant_Fin.Size = New System.Drawing.Size(256, 16)
        Me.F_Car_Ant_Fin.TabIndex = 195
        Me.F_Car_Ant_Fin.Text = "Fecha de Carga Ant Final"
        '
        'F_Apr_Ant_CT_GT
        '
        Me.F_Apr_Ant_CT_GT.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Apr_Ant_CT_GT.Location = New System.Drawing.Point(16, 104)
        Me.F_Apr_Ant_CT_GT.Name = "F_Apr_Ant_CT_GT"
        Me.F_Apr_Ant_CT_GT.Size = New System.Drawing.Size(256, 16)
        Me.F_Apr_Ant_CT_GT.TabIndex = 194
        Me.F_Apr_Ant_CT_GT.Text = "Fecha de Aprobaci�n Ant CT GT"
        '
        'F_Act_Apro
        '
        Me.F_Act_Apro.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Act_Apro.Location = New System.Drawing.Point(16, 88)
        Me.F_Act_Apro.Name = "F_Act_Apro"
        Me.F_Act_Apro.Size = New System.Drawing.Size(256, 16)
        Me.F_Act_Apro.TabIndex = 193
        Me.F_Act_Apro.Text = "Fecha de Carga Acta Aprobaci�n"
        '
        'F_Imp_Act_Apro
        '
        Me.F_Imp_Act_Apro.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Imp_Act_Apro.Location = New System.Drawing.Point(16, 72)
        Me.F_Imp_Act_Apro.Name = "F_Imp_Act_Apro"
        Me.F_Imp_Act_Apro.Size = New System.Drawing.Size(256, 16)
        Me.F_Imp_Act_Apro.TabIndex = 192
        Me.F_Imp_Act_Apro.Text = "Fecha de Impresi�n Acta Aprobaci�n"
        '
        'F_Car_DT_Fin
        '
        Me.F_Car_DT_Fin.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Car_DT_Fin.Location = New System.Drawing.Point(16, 56)
        Me.F_Car_DT_Fin.Name = "F_Car_DT_Fin"
        Me.F_Car_DT_Fin.Size = New System.Drawing.Size(256, 16)
        Me.F_Car_DT_Fin.TabIndex = 191
        Me.F_Car_DT_Fin.Text = "Fecha de carga DT Final"
        '
        'F_Apro_Rev_Edit
        '
        Me.F_Apro_Rev_Edit.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.F_Apro_Rev_Edit.Location = New System.Drawing.Point(16, 40)
        Me.F_Apro_Rev_Edit.Name = "F_Apro_Rev_Edit"
        Me.F_Apro_Rev_Edit.Size = New System.Drawing.Size(256, 16)
        Me.F_Apro_Rev_Edit.TabIndex = 190
        Me.F_Apro_Rev_Edit.Text = "Fecha de Aprobaci�n Revisi�n Editorial"
        '
        'f_ini_des_nmx
        '
        Me.f_ini_des_nmx.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.f_ini_des_nmx.Location = New System.Drawing.Point(16, 24)
        Me.f_ini_des_nmx.Name = "f_ini_des_nmx"
        Me.f_ini_des_nmx.Size = New System.Drawing.Size(256, 16)
        Me.f_ini_des_nmx.TabIndex = 189
        Me.f_ini_des_nmx.Text = "Fecha de Inicio de Desarrollo de NMX"
        '
        'TVPNN
        '
        Me.TVPNN.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TVPNN.ImageIndex = 2
        Me.TVPNN.ImageList = Me.imgListTreeView
        Me.TVPNN.Location = New System.Drawing.Point(8, 8)
        Me.TVPNN.Name = "TVPNN"
        Me.TVPNN.SelectedImageIndex = 2
        Me.TVPNN.Size = New System.Drawing.Size(168, 464)
        Me.TVPNN.TabIndex = 190
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdBuscar, Me.CmdDeshacer, Me.CmdImprimir, Me.separador1, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 489)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(1000, 62)
        Me.tlbBotonera.TabIndex = 191
        '
        'cmdBuscar
        '
        Me.cmdBuscar.ImageIndex = 6
        Me.cmdBuscar.Text = "Actualizar"
        Me.cmdBuscar.ToolTipText = "Actualizar Busqueda"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 2
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.ImageIndex = 7
        Me.CmdImprimir.Text = "Imprimir"
        Me.CmdImprimir.ToolTipText = "Imprimir Consulta"
        '
        'separador1
        '
        Me.separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 5
        Me.CmdSalir.Text = "Salir"
        '
        'FrmConsxFechas
        '
        Me.AutoScale = False
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1000, 551)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.TVPNN)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TxtTotal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DGridResultados)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmConsxFechas"
        Me.Text = "Consultas de Fechas"
        CType(Me.DGridResultados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "  Metodos y procesos"

#Region " Sub Revisa_checks(), Metodos y procesos"

    Sub Revisa_checks(ByVal ParamArray Objetos() As System.Windows.Forms.CheckBox)

        Inactivos(Objetos)
        Inactivos(Todo)
        ultimo_obj = Nothing
        Dim objeto As CheckBox
        Dim dt As DataTable
        Dim dr As DataRow
        Dim i, cols, cont As Integer
        Dim namechk As String

        ObjFechasavance.BANDERA = 3
        ObjFechasavance.Id_Plan = sPlan
        ObjFechasavance.Id_Tema = stema
        dt = ObjFechasavance.Listar
        cols = dt.Columns.Count
        For Each dr In dt.Rows
            For i = 0 To cols - 1
                If Not IsDBNull(dr(i)) Then
                    For Each objeto In Objetos
                        namechk = Replace(objeto.Text, "Fecha de ", "")
                        If namechk.ToLower = Campo(dt.Columns(i).ColumnName).ToLower Then
                            cont = 1
                            objeto.Enabled = True
                            objeto.Checked = True
                            ultimo_obj = objeto
                        End If
                    Next
                End If
            Next
        Next
        If cont <> 1 Then Todo.Enabled = True
    End Sub

#End Region

#Region " Sub Campo(name), Metodos y procesos"

    Function Campo(ByVal name As String) As String
        Select Case name
            Case "f_ini_des_nmx"
                Return "F_Inic_Desarrollo_Nmx"
            Case "F_Apro_Rev_Edit"
                Return "F_Aprob_Revisi�n_Editorial"
            Case "F_Car_DT_Fin"
                Return "F_Carga_DtFinal"
            Case "F_Imp_Act_Apro"
                Return "F_Impresion_ActaAprobacion"
            Case "F_Act_Apro"
                Return "F_Carga_ActaAprobacion"
            Case "F_Apr_Ant_CT_GT"
                Return "F_Aprobacion_CTGT_ANT"
            Case "F_Car_Ant_Fin"
                Return "F_Carga_ANTF"
            Case "F_Apr_Com_Proy"
                Return "F_Aprobacion_Comite_PROY"
            Case "F_Pub_Come_Pub"
                Return "F_Publicacion_ComentarioPublico"
            Case "F_Lim_Come_Pub"
                Return "F_Limite_ComentarioPublico"
            Case "F_Res_Come_Pub"
                Return "F_Resolucion_ComentarioPublico"
            Case "F_Ini_Pro_Alt"
                Return "F_Inicio_Comentarios"
            Case "F_Car_Min_Fin_Pro_Alt"
                Return "F_Fin_Comentarios"
            Case "F_Lim_Res_Come_Pub"
                Return "F_Limite_Aprobacion_Resolucion_ComentarioPublico"
            Case "f_Apr_Res_Come_Pub"
                Return "F_Aprobacion_Resolucion_ComentarioPublico"
            Case "F_Vo_Bo_Com"
                Return "F_VoBo_CONANCE"
            Case "F_Ini_Rev_PROYF"
                Return "F_Inicio_Revision_PROYF"
            Case "F_Ter_Rev_PROYF"
                Return "F_Termino_Revision_PROYF"
            Case "F_Edi_PROYF"
                Return "F_Edicion_PROYF"
            Case "F_Imp_Act_Apr_PROYF"
                Return "F_Impresion_ActaAprobacion_PROYF"
            Case "F_Car_Act_Apr_PROYF"
                Return "F_Carga_ActaAprobacion_PROYF"
            Case "F_Acu_DGN_PROYF"
                Return "F_ACUSE_DGN_PROYF"
            Case "F_Car_PROYF"
                Return "F_CARGA_PROYF"
                '-------------------- Retorna Label ---------------------------'
            Case "F_Inic_Desarrollo_Nmx"
                Return "Inicio de Desarrollo de NMX"
            Case "F_Aprob_Revisi�n_Editorial"
                Return "Aprobaci�n Revisi�n Editorial"
            Case "F_Carga_DtFinal"
                Return "Carga DT Final"
            Case "F_Impresion_ActaAprobacion"
                Return "Impresi�n Acta Aprobaci�n"
            Case "F_Carga_ActaAprobacion"
                Return "Carga Acta Aprobaci�n"
            Case "F_Aprobacion_CTGT_ANT"
                Return "Aprobaci�n Ant CT GT"
            Case "F_Carga_ANTF"
                Return "Carga Ant Final"
            Case "F_Aprobacion_Comite_PROY"
                Return "Aprobaci�n Comit� Proy"
            Case "F_Publicacion_ComentarioPublico"
                Return "Publicaci�n Comentario P�blico"
            Case "F_Limite_ComentarioPublico"
                Return "Fecha L�mite Comentario P�blico"
            Case "F_Resolucion_ComentarioPublico"
                Return "Resoluci�n Comentario P�blico"
            Case "F_Inicio_Comentarios"
                Return "Inicio Procedimiento Alternativo"
            Case "F_Fin_Comentarios"
                Return "Carga Minuta de Fin de Procedimiento Alternativo"
            Case "F_Limite_Aprobacion_Resolucion_ComentarioPublico"
                Return "Fecha L�mite de Resoluci�n a Comentario P�blico"
            Case "F_Aprobacion_Resolucion_ComentarioPublico"
                Return "Aprobaci�n de Resoluci�n a comentario P�blico"
            Case "F_VoBo_CONANCE"
                Return "Fecha Vo Bo Comit�"
            Case "F_Inicio_Revision_PROYF"
                Return "Inicio Revisi�n PROYF"
            Case "F_Termino_Revision_PROYF"
                Return "Fecha T�rmino Revisi�n PROYF"
            Case "F_Edicion_PROYF"
                Return "edici�n PROYF"
            Case "F_Impresion_ActaAprobacion_PROYF"
                Return "Impresi�n acta aprobaci�n PROYF"
            Case "F_ACUSE_DGN_PROYF"
                Return "Acuse DGN PROYF"
            Case "F_Carga_ActaAprobacion_PROYF"
                Return "Carga acta de Aprobaci�n PROYF"
            Case "F_CARGA_PROYF"
                Return "Carga PROYF"
        End Select
    End Function

#End Region

#Region " Sub combinaciones, Metodos y procesos"

    Function combinaciones(ByVal ParamArray Objetos() As System.Windows.Forms.CheckBox) As String
        Dim objeto As CheckBox
        Dim objeto2 As CheckBox
        Dim vistaso As Array
        Dim scadena, inicio, fin As String
        Dim iobj, i As Integer
        iobj = 0
        For Each objeto In Objetos
            If objeto.Checked = True And ((Objetos.Length - 1) <> (iobj + 1)) Then
                If inicio = "" Or inicio = Nothing Then inicio = Campo(objeto.Name)
                For i = iobj To Objetos.Length - 1
                    objeto2 = Objetos(i)
                    If objeto2.Checked = True And objeto2.Name <> objeto.Name Then
                        scadena = scadena + Campo(objeto.Name) + "-" + Campo(objeto2.Name) + "\"
                        Exit For
                    End If
                Next
                fin = Campo(objeto.Name)
            End If
            iobj = iobj + 1
        Next objeto
        vistaso = Split(scadena, "\")
        If (inicio + "-" + fin) <> vistaso(0) Then scadena = scadena + inicio + "-" + fin
        Return scadena
    End Function

#End Region

#Region " Sub Buscar, Metodos y procesos"

    Sub buscar()

        Dim scriterios, sdate As Array
        Dim Parcial As String
        Dim dtresultados As DataTable = DGridResultados.DataSource
        Dim i As Integer
        Call dgstyle()
        dtresultados.Rows.Clear()
        If Not Todo.Checked Then
            scriterios = Split(combinaciones(f_ini_des_nmx, F_Apro_Rev_Edit, F_Car_DT_Fin, F_Imp_Act_Apro, F_Act_Apro, F_Apr_Ant_CT_GT, F_Car_Ant_Fin, F_Apr_Com_Proy, F_Pub_Come_Pub, F_Lim_Come_Pub, F_Res_Come_Pub, F_Ini_Pro_Alt, F_Car_Min_Fin_Pro_Alt, F_Lim_Res_Come_Pub, f_Apr_Res_Come_Pub, F_Vo_Bo_Com, F_Ini_Rev_PROYF, F_Ter_Rev_PROYF, F_Edi_PROYF, F_Imp_Act_Apr_PROYF, F_Car_Act_Apr_PROYF, F_Acu_DGN_PROYF, F_Car_PROYF), "\")
        Else
                scriterios = Split("f_ini_des_nmx-" + Campo(ultimo_obj.Name), "\")
        End If
        If scriterios.Length <> 0 And stema <> Nothing Then
            ObjFechasavance.BANDERA = 1
            ObjFechasavance.Id_Plan = sPlan
            ObjFechasavance.Id_Tema = stema
            For Each Parcial In scriterios
                Dim dttemp As DataTable
                Dim drtemp, drresultados As DataRow
                sdate = Split(Parcial, "-") '+ " "
                If sdate.Length > 1 Then
                    ObjFechasavance.date1 = sdate(0)
                    ObjFechasavance.date2 = sdate(1)
                    dttemp = ObjFechasavance.Listar
                    If dttemp.Rows.Count > 0 Then
                        For Each drtemp In dttemp.Rows
                            drresultados = dtresultados.NewRow
                            drresultados(0) = Campo(sdate(0)) + vbCrLf + " - " + Campo(sdate(1))
                            For i = 1 To dtresultados.Columns.Count - 1
                                drresultados(i) = IIf(IsDBNull(drtemp(i - 1)), "", drtemp(i - 1))
                            Next
                            dtresultados.Rows.Add(drresultados)
                        Next
                    End If
                End If
            Next
        End If
        Dim cm As CurrencyManager
        cm = CType(BindingContext(dtresultados), CurrencyManager)
        'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyMaNAger
        Dim Dv As DataView = CType(cm.List, DataView)
        'AsigNAmos el valor que deseamos para evitar o permitir nuevos registros
        Dv.AllowNew = False
        Dv.AllowEdit = False
        Dv.AllowDelete = False
        TxtTotal.Text = Dv.Count()
        DGridResultados.DataSource = dtresultados
    End Sub

#End Region

#End Region

#Region " Form - frmPNN_temas, Metodos y Procesos"

    Private Sub FrmConsxFechas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Llena_Plan()
        ObjFechasavance.BANDERA = 2
        ObjFechasavance.Id_Plan = ""
        Call dgstyle()
        DGridResultados.DataSource = ObjFechasavance.Listar
    End Sub

#End Region

#Region " CheckBox, Metodos y Procesos"

#Region " CheckBox - f_ini_des_nmx, Metodos y Procesos"

#Region " f_ini_des_nmx - f_ini_des_nmx_CheckedChanged, Metodos y Procesos"

    Private Sub f_ini_des_nmx_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles f_ini_des_nmx.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If f_ini_des_nmx.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " f_ini_des_nmx - f_ini_des_nmx_EnabledChanged, Metodos y Procesos"

    Private Sub f_ini_des_nmx_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles f_ini_des_nmx.EnabledChanged
        f_ini_des_nmx.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Apro_Rev_Edit, Metodos y Procesos"

#Region " F_Apro_Rev_Edit - F_Apro_Rev_Edit_CheckedChanged, Metodos y Procesos"

    Private Sub F_Apro_Rev_Edit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Apro_Rev_Edit.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Apro_Rev_Edit.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Apro_Rev_Edit - F_Apro_Rev_Edit_EnabledChanged, Metodos y Procesos"

    Private Sub F_Apro_Rev_Edit_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Apro_Rev_Edit.EnabledChanged
        F_Apro_Rev_Edit.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Car_DT_Fin, Metodos y Procesos"

#Region " F_Car_DT_Fin - F_Car_DT_Fin_CheckedChanged, Metodos y Procesos"

    Private Sub F_Car_DT_Fin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Car_DT_Fin.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Car_DT_Fin.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Car_DT_Fin - F_Car_DT_Fin_EnabledChanged, Metodos y Procesos"

    Private Sub F_Car_DT_Fin_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Car_DT_Fin.EnabledChanged
        F_Car_DT_Fin.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Imp_Act_Apro, Metodos y Procesos"

#Region " F_Imp_Act_Apro - F_Imp_Act_Apro_CheckedChanged, Metodos y Procesos"

    Private Sub F_Imp_Act_Apro_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Imp_Act_Apro.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Imp_Act_Apro.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Imp_Act_Apro - F_Imp_Act_Apro_EnabledChanged, Metodos y Procesos"

    Private Sub F_Imp_Act_Apro_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Imp_Act_Apro.EnabledChanged
        F_Imp_Act_Apro.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Act_Apro, Metodos y Procesos"

#Region " F_Act_Apro - F_Act_Apro_CheckedChanged, Metodos y Procesos"

    Private Sub F_Act_Apro_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Act_Apro.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Act_Apro.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Act_Apro - F_Act_Apro_EnabledChanged, Metodos y Procesos"

    Private Sub F_Act_Apro_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Act_Apro.EnabledChanged
        F_Act_Apro.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Apr_Ant_CT_GT, Metodos y Procesos"

#Region " F_Apr_Ant_CT_GT - F_Apr_Ant_CT_GT_CheckedChanged, Metodos y Procesos"

    Private Sub F_Apr_Ant_CT_GT_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Apr_Ant_CT_GT.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Apr_Ant_CT_GT.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Apr_Ant_CT_GT - F_Apr_Ant_CT_GT_EnabledChanged, Metodos y Procesos"

    Private Sub F_Apr_Ant_CT_GT_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Apr_Ant_CT_GT.EnabledChanged
        F_Apr_Ant_CT_GT.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Car_Ant_Fin, Metodos y Procesos"

#Region " F_Car_Ant_Fin - F_Car_Ant_Fin_CheckedChanged, Metodos y Procesos"

    Private Sub F_Car_Ant_Fin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Car_Ant_Fin.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Car_Ant_Fin.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Car_Ant_Fin - F_Car_Ant_Fin_EnabledChanged, Metodos y Procesos"

    Private Sub F_Car_Ant_Fin_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Car_Ant_Fin.EnabledChanged
        F_Car_Ant_Fin.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Apr_Com_Proy, Metodos y Procesos"

#Region " F_Apr_Com_Proy - F_Apr_Com_Proy_CheckedChanged, Metodos y Procesos"

    Private Sub F_Apr_Com_Proy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Apr_Com_Proy.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Apr_Com_Proy.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Apr_Com_Proy - F_Apr_Com_Proy_EnabledChanged, Metodos y Procesos"

    Private Sub F_Apr_Com_Proy_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Apr_Com_Proy.EnabledChanged
        F_Apr_Com_Proy.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Pub_Come_Pub, Metodos y Procesos"

#Region " F_Pub_Come_Pub - F_Pub_Come_Pub_CheckedChanged, Metodos y Procesos"

    Private Sub F_Pub_Come_Pub_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Pub_Come_Pub.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Pub_Come_Pub.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Pub_Come_Pub - F_Pub_Come_Pub_EnabledChanged, Metodos y Procesos"

    Private Sub F_Pub_Come_Pub_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Pub_Come_Pub.EnabledChanged
        F_Pub_Come_Pub.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Lim_Come_Pub, Metodos y Procesos"

#Region " F_Lim_Come_Pub - F_Lim_Come_Pub_CheckedChanged, Metodos y Procesos"

    Private Sub F_Lim_Come_Pub_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Lim_Come_Pub.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Lim_Come_Pub.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Lim_Come_Pub - F_Lim_Come_Pub_EnabledChanged, Metodos y Procesos"

    Private Sub F_Lim_Come_Pub_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Lim_Come_Pub.EnabledChanged
        F_Lim_Come_Pub.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Res_Come_Pub, Metodos y Procesos"

#Region " F_Res_Come_Pub - F_Res_Come_Pub_CheckedChanged, Metodos y Procesos"

    Private Sub F_Res_Come_Pub_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Res_Come_Pub.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Res_Come_Pub.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Res_Come_Pub - F_Res_Come_Pub_EnabledChanged, Metodos y Procesos"

    Private Sub F_Res_Come_Pub_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Res_Come_Pub.EnabledChanged
        F_Res_Come_Pub.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Ini_Pro_Alt, Metodos y Procesos"

#Region " F_Ini_Pro_Alt - F_Ini_Pro_Alt_CheckedChanged, Metodos y Procesos"

    Private Sub F_Ini_Pro_Alt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Ini_Pro_Alt.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Ini_Pro_Alt.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Ini_Pro_Alt - F_Ini_Pro_Alt_EnabledChanged, Metodos y Procesos"

    Private Sub F_Ini_Pro_Alt_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Ini_Pro_Alt.EnabledChanged
        F_Ini_Pro_Alt.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Car_Min_Fin_Pro_Alt, Metodos y Procesos"

#Region " F_Car_Min_Fin_Pro_Alt - F_Car_Min_Fin_Pro_Alt_CheckedChanged, Metodos y Procesos"

    Private Sub F_Car_Min_Fin_Pro_Alt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Car_Min_Fin_Pro_Alt.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Car_Min_Fin_Pro_Alt.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Car_Min_Fin_Pro_Alt - F_Car_Min_Fin_Pro_Alt_EnabledChanged, Metodos y Procesos"

    Private Sub F_Car_Min_Fin_Pro_Alt_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Car_Min_Fin_Pro_Alt.EnabledChanged
        F_Car_Min_Fin_Pro_Alt.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Lim_Res_Come_Pub, Metodos y Procesos"

#Region " F_Lim_Res_Come_Pub - F_Lim_Res_Come_Pub, Metodos y Procesos"

    Private Sub F_Lim_Res_Come_Pub_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Lim_Res_Come_Pub.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Lim_Res_Come_Pub.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Lim_Res_Come_Pub - F_Lim_Res_Come_Pub_EnabledChanged, Metodos y Procesos"

    Private Sub F_Lim_Res_Come_Pub_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Lim_Res_Come_Pub.EnabledChanged
        F_Lim_Res_Come_Pub.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - f_Apr_Res_Come_Pub, Metodos y Procesos"

#Region " f_Apr_Res_Come_Pub - f_Apr_Res_Come_Pub_CheckedChanged, Metodos y Procesos"

    Private Sub f_Apr_Res_Come_Pub_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles f_Apr_Res_Come_Pub.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If f_Apr_Res_Come_Pub.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " f_Apr_Res_Come_Pub - f_Apr_Res_Come_Pub_EnabledChanged, Metodos y Procesos"

    Private Sub f_Apr_Res_Come_Pub_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles f_Apr_Res_Come_Pub.EnabledChanged
        f_Apr_Res_Come_Pub.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Vo_Bo_Com, Metodos y Procesos"

#Region " F_Vo_Bo_Com - F_Vo_Bo_Com_CheckedChanged, Metodos y Procesos"

    Private Sub F_Vo_Bo_Com_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Vo_Bo_Com.CheckedChanged

        Cursor.Current = Cursors.WaitCursor
        If F_Vo_Bo_Com.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Vo_Bo_Com - F_Vo_Bo_Com_EnabledChanged, Metodos y Procesos"

    Private Sub F_Vo_Bo_Com_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Vo_Bo_Com.EnabledChanged
        F_Vo_Bo_Com.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Ini_Rev_PROYF, Metodos y Procesos"

#Region " F_Ini_Rev_PROYF - F_Ini_Rev_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Ini_Rev_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Ini_Rev_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Ini_Rev_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Ini_Rev_PROYF - F_Ini_Rev_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Ini_Rev_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Ini_Rev_PROYF.EnabledChanged
        F_Ini_Rev_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Ter_Rev_PROYF, Metodos y Procesos"

#Region " F_Ter_Rev_PROYF - F_Ter_Rev_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Ter_Rev_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Ter_Rev_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Ter_Rev_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Ter_Rev_PROYF - F_Ter_Rev_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Ter_Rev_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Ter_Rev_PROYF.EnabledChanged
        F_Ter_Rev_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Edi_PROYF, Metodos y Procesos"

#Region " F_Edi_PROYF - F_Edi_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Edi_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Edi_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Edi_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Edi_PROYF - F_Edi_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Edi_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Edi_PROYF.EnabledChanged
        F_Edi_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Imp_Act_Apr_PROYF, Metodos y Procesos"

#Region " F_Imp_Act_Apr_PROYF - F_Imp_Act_Apr_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Imp_Act_Apr_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Imp_Act_Apr_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Imp_Act_Apr_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Imp_Act_Apr_PROYF - F_Imp_Act_Apr_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Imp_Act_Apr_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Imp_Act_Apr_PROYF.EnabledChanged
        F_Imp_Act_Apr_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Car_Act_Apr_PROYF, Metodos y Procesos"

#Region " F_Car_Act_Apr_PROYF - F_Car_Act_Apr_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Car_Act_Apr_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Car_Act_Apr_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Car_Act_Apr_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Car_Act_Apr_PROYF - F_Car_Act_Apr_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Car_Act_Apr_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Car_Act_Apr_PROYF.EnabledChanged
        F_Car_Act_Apr_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Acu_DGN_PROYF, Metodos y Procesos"

#Region " F_Acu_DGN_PROYF - F_Acu_DGN_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Acu_DGN_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Acu_DGN_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Acu_DGN_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Acu_DGN_PROYF - F_Acu_DGN_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Acu_DGN_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Acu_DGN_PROYF.EnabledChanged
        F_Acu_DGN_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - F_Car_PROYF, Metodos y Procesos"

#Region " F_Car_PROYF - F_Car_PROYF_CheckedChanged, Metodos y Procesos"

    Private Sub F_Car_PROYF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F_Car_PROYF.CheckedChanged
        Cursor.Current = Cursors.WaitCursor
        If F_Car_PROYF.Checked Then
            Call buscar()
            Activos(tlbBotonera.Buttons(2), tlbBotonera.Buttons(3))
        End If
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " F_Car_PROYF - F_Car_PROYF_EnabledChanged, Metodos y Procesos"

    Private Sub F_Car_PROYF_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles F_Car_PROYF.EnabledChanged
        F_Car_PROYF.Checked = False
    End Sub

#End Region

#End Region

#Region " CheckBox - Todo, Metodos y Procesos"

#Region " Todo - Todo_CheckedChanged, Metodos y Procesos"

    Private Sub Todo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Todo.CheckedChanged
        If sPlan = "" And stema = "" Then
            If Todo.Checked Then
                MsgBox("Favor de seleccionar un plan y un tema")
            End If
            Todo.Checked = False
            Exit Sub
        End If
            Cursor.Current = Cursors.WaitCursor
            If Todo.Checked Then
                Call Revisa_checks()
                Inactivos(F_Car_PROYF, F_Car_Act_Apr_PROYF, F_Acu_DGN_PROYF, F_Imp_Act_Apr_PROYF, F_Edi_PROYF, F_Ter_Rev_PROYF, F_Ini_Rev_PROYF, F_Vo_Bo_Com, f_Apr_Res_Come_Pub, F_Act_Apro, F_Imp_Act_Apro, F_Car_DT_Fin, F_Apro_Rev_Edit, f_ini_des_nmx, F_Lim_Res_Come_Pub, F_Car_Min_Fin_Pro_Alt, F_Ini_Pro_Alt, F_Res_Come_Pub, F_Lim_Come_Pub, F_Pub_Come_Pub, F_Apr_Com_Proy, F_Car_Ant_Fin, F_Apr_Ant_CT_GT)
            Else
                Call Revisa_checks()
            End If
            Cursor.Current = Cursors.Default

    End Sub

#End Region

#Region " Todo - Todo_EnabledChanged, Metodos y Procesos"

    Private Sub Todo_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Todo.EnabledChanged
        Todo.Checked = False
    End Sub

#End Region

#End Region

#End Region

#Region " DGridResultados - DGStyle, Metodos y Procesos"

    Private Sub dgstyle()
        Dim dtcol As DataColumn = Nothing
        Try
            DGridResultados.TableStyles.Clear()


            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, DGridResultados)

            ts1.MappingName = "ClsFechasAvance"
            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Etapas"
            TextCol.HeaderText = "Rangos de Etapas"
            TextCol.Width = 180
            TextCol.Alignment = HorizontalAlignment.Center
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol0 As New DataGridTextBoxColumn
            TextCol0.MappingName = "F_Inic"
            TextCol0.HeaderText = "Fecha Inicio"
            TextCol0.Width = 85
            TextCol0.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol0)

            Dim TextCol1 As New DataGridTextBoxColumn
            TextCol1.MappingName = "F_Final"
            TextCol1.HeaderText = "Fecha Final"
            TextCol1.Width = 85
            TextCol1.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol1)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "diferencia"
            TextCol2.HeaderText = "D�as Estimados"
            TextCol2.Width = 100
            TextCol2.Alignment = HorizontalAlignment.Center
            TextCol2.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol2)

            ts1.PreferredRowHeight = TextCol2.TextBox.Height * 1.5
            DGridResultados.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

#End Region

#Region " ToolBar - tlbBotonera, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick

        Cursor.Current = Cursors.WaitCursor
        With tlbBotonera
            Select Case tlbBotonera.Buttons.IndexOf(e.Button)
                Case 0
                    Call buscar()
                    Activos(.Buttons(2), .Buttons(3))
                Case 1

                Case 2

                Case 4                   '''----------   Salir     --------
                    Me.Dispose()
            End Select
        End With
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " TreeView - TVPNN, Metodos y Procesos"

#Region " TVPNN - TVPNN_AfterSelect, Metodos y Procesos"

    Private Sub TVPNN_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVPNN.AfterSelect
        Cursor.Current = Cursors.WaitCursor
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                stema = ""
                sPlan = ""
            Case 2
                sPlan = Matriz(1)
            Case 3
                sPlan = Matriz(1)
                stema = Matriz(2)
                Call Revisa_checks(f_ini_des_nmx, F_Apro_Rev_Edit, F_Car_DT_Fin, F_Imp_Act_Apro, F_Act_Apro, F_Apr_Ant_CT_GT, F_Car_Ant_Fin, F_Apr_Com_Proy, F_Pub_Come_Pub, F_Lim_Come_Pub, F_Res_Come_Pub, F_Ini_Pro_Alt, F_Car_Min_Fin_Pro_Alt, F_Lim_Res_Come_Pub, f_Apr_Res_Come_Pub, F_Vo_Bo_Com, F_Ini_Rev_PROYF, F_Ter_Rev_PROYF, F_Edi_PROYF, F_Imp_Act_Apr_PROYF, F_Car_Act_Apr_PROYF, F_Acu_DGN_PROYF, F_Car_PROYF)
        End Select
        Dim dat As DataTable = DGridResultados.DataSource
        dat.Rows.Clear()
        DGridResultados.DataSource = dat
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region " TVPNN - Llena_Plan, Metodos y Procesos"

    Sub Llena_Plan()
        Cursor.Current = Cursors.WaitCursor
        Dim nodo As New TreeNode
        Dim nodo1 As New TreeNode
        Dim oTablaPNN As DataTable
        Dim oTablaDPy As DataTable
        Dim RegPNN As DataRow
        Dim RegDPy As DataRow

        oTablaPNN = objtreeview.ListaPNN("")
        TVPNN.BeginUpdate()
        nodo = TVPNN.Nodes.Add("Selecciona un Plan")
        For Each RegPNN In oTablaPNN.Rows '******Planes
            nodo = TVPNN.Nodes(0).Nodes.Add(Trim(RegPNN("id_plan")))
            nodo.ImageIndex = 3
            nodo.SelectedImageIndex = 4
            oTablaDPy = objtreeview.ListaDprog(Trim(RegPNN("id_plan")))
            For Each RegDPy In oTablaDPy.Rows '******Temas de PNN
                nodo1 = nodo.Nodes.Add(Trim(RegDPy("id_tema")))
                nodo1.SelectedImageIndex = 5
                nodo1.ImageIndex = 5
            Next
        Next
        TVPNN.EndUpdate()
        ' modifico la propiedad AllowDrop a True para poder realizar Drag and Drop
        TVPNN.AllowDrop = False
        ' modifico la propiedad Sorted a True para que los nodos est�n ordenados
        ' TVPNN.Sorted = True
        Cursor.Current = Cursors.Default
    End Sub

#End Region

#End Region

    Private Sub deseleccionarTodas(ByVal ParamArray Objetos() As Object)
        Dim objeto As Object
        For Each objeto In Objetos
            objeto.Checked = False
        Next objeto
    End Sub

    Private Sub cmdQuitar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdQuitar.Click
        deseleccionarTodas(f_ini_des_nmx, F_Apro_Rev_Edit, F_Car_DT_Fin, F_Imp_Act_Apro, F_Act_Apro, F_Apr_Ant_CT_GT, F_Car_Ant_Fin, F_Apr_Com_Proy, F_Pub_Come_Pub, F_Lim_Come_Pub, F_Res_Come_Pub, F_Ini_Pro_Alt, F_Car_Min_Fin_Pro_Alt, F_Lim_Res_Come_Pub, f_Apr_Res_Come_Pub, F_Vo_Bo_Com, F_Ini_Rev_PROYF, F_Ter_Rev_PROYF, F_Edi_PROYF, F_Imp_Act_Apr_PROYF, F_Car_Act_Apr_PROYF, F_Acu_DGN_PROYF, F_Car_PROYF)
    End Sub
End Class
