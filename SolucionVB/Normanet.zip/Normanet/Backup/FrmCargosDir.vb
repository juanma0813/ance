Public Class FrmCargosDir
    Inherits System.Windows.Forms.Form
    Dim ObjCargos As New ClsDirectorio_Cargos.C_Directorio_Cargos(0, gUsuario, gPasswordSql)
    Dim objCatCargos As New clsCargos.C_Cargos("PRINCIPAL", gUsuario, gPasswordSql)
    Dim objsector As New ClsSector.ClsSector("PRINCIPAL", gUsuario, gPasswordSql)
    Dim objrepresentacion As New ClsRepresentacion.C_Representacion("PRINCIPAL", gUsuario, gPasswordSql)       '''Identif, Usuario, Password
    Dim DtCargos As DataTable
    Dim dvComite As DataView
    Dim Setapa As String
    Dim Tipo_Cargo As Integer
  

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents txtclave As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtcomite As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents TVcomites As System.Windows.Forms.TreeView
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtsector As System.Windows.Forms.TextBox
    Friend WithEvents cbosector As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtrepresentacion As System.Windows.Forms.TextBox
    Friend WithEvents cborepresentacion As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtcargo As System.Windows.Forms.TextBox
    Friend WithEvents cbocargos As System.Windows.Forms.ComboBox
    Friend WithEvents imgListTreeView As System.Windows.Forms.ImageList
    Friend WithEvents txtcomitez As System.Windows.Forms.TextBox
    Friend WithEvents txtctz As System.Windows.Forms.TextBox
    Friend WithEvents txtscz As System.Windows.Forms.TextBox
    Friend WithEvents txtgtz As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboFolios As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmCargosDir))
        Me.txtclave = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtcomite = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.TVcomites = New System.Windows.Forms.TreeView
        Me.imgListTreeView = New System.Windows.Forms.ImageList(Me.components)
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtsector = New System.Windows.Forms.TextBox
        Me.cbosector = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtrepresentacion = New System.Windows.Forms.TextBox
        Me.cborepresentacion = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtcargo = New System.Windows.Forms.TextBox
        Me.cbocargos = New System.Windows.Forms.ComboBox
        Me.txtcomitez = New System.Windows.Forms.TextBox
        Me.txtctz = New System.Windows.Forms.TextBox
        Me.txtscz = New System.Windows.Forms.TextBox
        Me.txtgtz = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.cboFolios = New System.Windows.Forms.ComboBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtclave
        '
        Me.txtclave.Location = New System.Drawing.Point(72, 32)
        Me.txtclave.Name = "txtclave"
        Me.txtclave.Size = New System.Drawing.Size(128, 20)
        Me.txtclave.TabIndex = 2
        Me.txtclave.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Clave"
        '
        'txtcomite
        '
        Me.txtcomite.Location = New System.Drawing.Point(72, 64)
        Me.txtcomite.Name = "txtcomite"
        Me.txtcomite.Size = New System.Drawing.Size(128, 20)
        Me.txtcomite.TabIndex = 34
        Me.txtcomite.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(16, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 23)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Pertenece:"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdBorrar, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 380)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(456, 62)
        Me.tlbBotonera.TabIndex = 35
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'CmdBorrar
        '
        Me.CmdBorrar.ImageIndex = 5
        Me.CmdBorrar.Text = "Borrar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'TVcomites
        '
        Me.TVcomites.ImageList = Me.imgListTreeView
        Me.TVcomites.Location = New System.Drawing.Point(16, 88)
        Me.TVcomites.Name = "TVcomites"
        Me.TVcomites.Size = New System.Drawing.Size(424, 128)
        Me.TVcomites.TabIndex = 36
        '
        'imgListTreeView
        '
        Me.imgListTreeView.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgListTreeView.ImageSize = New System.Drawing.Size(17, 17)
        Me.imgListTreeView.ImageStream = CType(resources.GetObject("imgListTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListTreeView.TransparentColor = System.Drawing.Color.Transparent
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 24)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Sector:"
        '
        'txtsector
        '
        Me.txtsector.Enabled = False
        Me.txtsector.Location = New System.Drawing.Point(104, 224)
        Me.txtsector.Name = "txtsector"
        Me.txtsector.Size = New System.Drawing.Size(328, 20)
        Me.txtsector.TabIndex = 46
        Me.txtsector.Text = ""
        '
        'cbosector
        '
        Me.cbosector.ItemHeight = 13
        Me.cbosector.Location = New System.Drawing.Point(104, 224)
        Me.cbosector.Name = "cbosector"
        Me.cbosector.Size = New System.Drawing.Size(344, 21)
        Me.cbosector.TabIndex = 44
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 264)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 24)
        Me.Label2.TabIndex = 48
        Me.Label2.Text = "Representaci�n"
        '
        'txtrepresentacion
        '
        Me.txtrepresentacion.Enabled = False
        Me.txtrepresentacion.Location = New System.Drawing.Point(104, 264)
        Me.txtrepresentacion.Name = "txtrepresentacion"
        Me.txtrepresentacion.Size = New System.Drawing.Size(328, 20)
        Me.txtrepresentacion.TabIndex = 49
        Me.txtrepresentacion.Text = ""
        '
        'cborepresentacion
        '
        Me.cborepresentacion.ItemHeight = 13
        Me.cborepresentacion.Location = New System.Drawing.Point(104, 264)
        Me.cborepresentacion.Name = "cborepresentacion"
        Me.cborepresentacion.Size = New System.Drawing.Size(344, 21)
        Me.cborepresentacion.TabIndex = 47
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 296)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 24)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "Cargo"
        '
        'txtcargo
        '
        Me.txtcargo.Enabled = False
        Me.txtcargo.Location = New System.Drawing.Point(104, 296)
        Me.txtcargo.Name = "txtcargo"
        Me.txtcargo.Size = New System.Drawing.Size(328, 20)
        Me.txtcargo.TabIndex = 52
        Me.txtcargo.Text = ""
        '
        'cbocargos
        '
        Me.cbocargos.ItemHeight = 13
        Me.cbocargos.Location = New System.Drawing.Point(104, 296)
        Me.cbocargos.Name = "cbocargos"
        Me.cbocargos.Size = New System.Drawing.Size(344, 21)
        Me.cbocargos.TabIndex = 50
        '
        'txtcomitez
        '
        Me.txtcomitez.Location = New System.Drawing.Point(440, 24)
        Me.txtcomitez.Name = "txtcomitez"
        Me.txtcomitez.TabIndex = 53
        Me.txtcomitez.Text = ""
        Me.txtcomitez.Visible = False
        '
        'txtctz
        '
        Me.txtctz.Location = New System.Drawing.Point(440, 48)
        Me.txtctz.Name = "txtctz"
        Me.txtctz.TabIndex = 54
        Me.txtctz.Text = ""
        Me.txtctz.Visible = False
        '
        'txtscz
        '
        Me.txtscz.Location = New System.Drawing.Point(440, 72)
        Me.txtscz.Name = "txtscz"
        Me.txtscz.TabIndex = 55
        Me.txtscz.Text = ""
        Me.txtscz.Visible = False
        '
        'txtgtz
        '
        Me.txtgtz.Location = New System.Drawing.Point(440, 96)
        Me.txtgtz.Name = "txtgtz"
        Me.txtgtz.TabIndex = 56
        Me.txtgtz.Text = ""
        Me.txtgtz.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpFinal)
        Me.GroupBox1.Controls.Add(Me.dtpInicio)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 328)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(432, 48)
        Me.GroupBox1.TabIndex = 57
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Fechas"
        '
        'dtpFinal
        '
        Me.dtpFinal.Enabled = False
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpFinal.Location = New System.Drawing.Point(192, 16)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(88, 20)
        Me.dtpFinal.TabIndex = 3
        '
        'dtpInicio
        '
        Me.dtpInicio.Enabled = False
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpInicio.Location = New System.Drawing.Point(56, 16)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(88, 20)
        Me.dtpInicio.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(152, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 16)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Final:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 16)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Inicio:"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(200, 32)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 23)
        Me.Label7.TabIndex = 58
        Me.Label7.Text = "Folio Nombramiento:"
        '
        'cboFolios
        '
        Me.cboFolios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFolios.Location = New System.Drawing.Point(304, 32)
        Me.cboFolios.Name = "cboFolios"
        Me.cboFolios.Size = New System.Drawing.Size(136, 21)
        Me.cboFolios.TabIndex = 59
        '
        'FrmCargosDir
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 442)
        Me.Controls.Add(Me.cboFolios)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtgtz)
        Me.Controls.Add(Me.txtscz)
        Me.Controls.Add(Me.txtctz)
        Me.Controls.Add(Me.txtcomitez)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtcargo)
        Me.Controls.Add(Me.txtrepresentacion)
        Me.Controls.Add(Me.txtsector)
        Me.Controls.Add(Me.txtcomite)
        Me.Controls.Add(Me.txtclave)
        Me.Controls.Add(Me.cbocargos)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cborepresentacion)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbosector)
        Me.Controls.Add(Me.TVcomites)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmCargosDir"
        Me.Text = "Cargos"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Forms - FrmCargosDir, Metodos y Procesos"

    Private Sub FrmCargosDir_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Busca las representaciones
        objrepresentacion.Bandera = 1
        objrepresentacion.ListaCombo(cborepresentacion)
        FillFoliosNombramientos(cboFolios)
        'busca los sectores
        Dim oTablaST As DataTable
        Dim RegST As DataRow
        objsector.Bandera = 1
        objsector.ListaCombo(cbosector)
        llena_TreeView()

        If bandgrd = False Then ' esto es por si no se selecciono nada del otro lado
            Setapa = "Agregar"
            Call Habilita(Setapa)
            FillFoliosNombramientos(cboFolios)
            Exit Sub
        End If

        If SGralCargos <> "" Then
            'Setapa = "Editar"
            Setapa = "Inactivo"
            Call Habilita(Setapa)
            'vALIDACI�N PARA SABER EXACTAMENTE A QUE COMIT� PERTENECE.
            'SI ES GRUPO DE TRABAJO
            If sGT <> "NA" Then
                txtcomite.Text = sGT
            End If
            'SI ES SUBCOMITE
            If SSc <> "NA" And sGT = "NA" Then
                txtcomite.Text = SSc
            End If
            'SI ES COMITE TECNICO
            If SCt <> "NA" And SSc = "NA" And sGT = "NA" Then
                txtcomite.Text = SCt
            End If
            'SI ES DIRECTO DE COMITE
            If sComite <> "NA" And SCt = "NA" And SSc = "NA" And sGT = "NA" Then
                txtcomite.Text = sComite
            End If
            txtsector.Text = sSector
            txtrepresentacion.Text = sRepresentacion
            txtcargo.Text = SGralCargos
            cbocargos.Text = SGralCargos
        Else
            Setapa = "Inactivo"
            Call Habilita(Setapa)
            'Busca las representaciones
            objrepresentacion.Bandera = 1
            objrepresentacion.ListaCombo(cborepresentacion)

        End If

        REM buscar las fechas
        Try
            Dim objDirectorio As New ClsDirectorio_Cargos.C_Directorio_Cargos(0, gUsuario, gPasswordSql)
            objDirectorio.Bandera = 5
            objDirectorio.Consecutivo = SConsecutivo
            objDirectorio.LlenarDatos()

            cboFolios.SelectedValue = objDirectorio.IdNombramiento

            If objDirectorio.F_VigenciaInicio = Nothing Then
                dtpInicio.Value = Now.Date
            Else
                dtpInicio.Value = objDirectorio.F_VigenciaInicio
            End If

            If objDirectorio.F_VigenciaFinal = Nothing Then
                dtpFinal.Value = Now.Date
            Else
                dtpFinal.Value = objDirectorio.F_VigenciaFinal
            End If

            'dtpInicio.Value = IIf(IsDBNull(objDirectorio.F_VigenciaInicio), Now.Date, CDate(objDirectorio.F_VigenciaInicio))
            'dtpFinal.Value = IIf(IsDBNull(objDirectorio.F_VigenciaFinal), Now.Date, CDate(objDirectorio.F_VigenciaFinal))

            objDirectorio = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

#End Region

#Region " TreeView - TVcomites, Metodos y Procesos"

#Region "  TVcomites - llena_TreeView, Metodos y Procesos"

    Private Sub llena_TreeView()

        Cursor.Current = Cursors.WaitCursor
        Dim objNodos As New clsNodos.clsNodos("Principal", gUsuario, gPasswordSql)
        Dim Comite As TreeNode
        Dim CT As TreeNode
        Dim SC As TreeNode
        Dim GT As TreeNode
        Dim Ses As TreeNode

        Dim oTablaComite As DataTable
        Dim oTablaCT As DataTable
        Dim oTablaSC As DataTable
        Dim oTablaGT As DataTable
        Dim oTablaSs As DataTable

        Dim ComiteAnt As String
        Dim CTAnt As String
        Dim SCAnt As String
        Dim GTAnt As String

        oTablaComite = objNodos.ListaComite
        If objNodos.ListaComite Is Nothing Then
            Comite = TVcomites.Nodes.Add("Seleccione un Comit�")
            Exit Sub
        End If

        ' deshabilita la actualizaci�n en pantalla del control TreeView 
        TVcomites.BeginUpdate()

        ' defino variable del tipo DataRow
        Dim RegComite As DataRow
        Dim RegCT As DataRow
        Dim RegSC As DataRow
        Dim RegGT As DataRow
        Dim RegSes As DataRow

        dvComite = oTablaComite.DefaultView
        Comite = TVcomites.Nodes.Add("Seleccione un Comit�")

        For Each RegComite In oTablaComite.Rows '******COMITES
            Comite = TVcomites.Nodes(0).Nodes.Add(RegComite("ID_Comite"))
            ComiteAnt = RegComite("ID_Comite") + ",NA,NA,NA"
            Comite.ImageIndex = 8
            Comite.SelectedImageIndex = 7
            If objNodos.ListaCT(RegComite("ID_Comite")) Is Nothing Then 'Valida si no existen nodos hijos
                GoTo sinComite
            End If
            oTablaCT = objNodos.ListaCT(RegComite("ID_Comite"))

            For Each RegCT In oTablaCT.Rows '******COMITES T�CNICOS
                If Trim(RegCT("ID_CT")) = "NA" Then
                    CT = Comite
                Else
                    CT = Comite.Nodes.Add(Trim(RegCT("ID_CT")))
                    CT.ImageIndex = 10
                    CT.SelectedImageIndex = 9
                End If
                CTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + ",NA,NA"
                If objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT")) Is Nothing Then 'Valida si no existen nodos hijos
                    'Exit For
                    GoTo sinCT
                End If
                oTablaSC = objNodos.ListaSC(RegComite("ID_comite"), RegCT("ID_CT"))

                For Each RegSC In oTablaSC.Rows '******SUB COMITE
                    If Trim(RegSC("ID_SC")) = "NA" Then
                        SC = CT
                    Else
                        SC = CT.Nodes.Add(Trim(RegSC("ID_SC")))
                        SC.ImageIndex = 12
                        SC.SelectedImageIndex = 11
                    End If
                    SCAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + ",NA"
                    If objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) Is Nothing Then 'Valida si no existen nodos hijos
                        GoTo sinSC
                    End If
                    oTablaGT = objNodos.ListaGT(RegComite("ID_Comite"), RegCT("ID_CT"), RegSC("ID_SC")) '***OK

                    For Each RegGT In oTablaGT.Rows '******GRUPOS DE TRABAJO
                        GT = SC.Nodes.Add(Trim(RegGT("ID_Grupo")))
                        GTAnt = RegComite("ID_Comite") + "," + RegCT("ID_CT") + "," + RegSC("ID_SC") + "," + RegGT("ID_Grupo")
                        GT.ImageIndex = 14
                        GT.SelectedImageIndex = 13
                    Next 'GT
sinSC:
                Next 'SC
sinCT:
            Next 'CT
sinComite:
        Next
        TVcomites.EndUpdate()
        TVcomites.ResetText()

        Cursor.Current = Cursors.Default
    End Sub

#End Region

#Region "  TVcomites - TVcomites_AfterSelect, Metodos y Procesos"


    Private Sub TVcomites_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TVcomites.AfterSelect
        Dim Matriz As Array
        Dim svariable As String

        Dim sraiz As String
        Dim bandera As Integer
        svariable = e.Node.FullPath
        Matriz = Split(svariable, "\")

        Select Case Matriz.Length
            Case 1
                sraiz = Matriz(0)
                txtcomitez.Text = "NA"
                txtctz.Text = "NA"
                zSc = "NA"
                zGT = "NA"

                sComite = "NA"
                SCt = "NA"
                SSc = "NA"
                sGT = "NA"
                objCatCargos.Bandera = 2
                txtcargo.Text = ""
            Case 2
                sComite = Matriz(1)
                SCt = "NA"
                SSc = "NA"
                sGT = "NA"

                txtcomitez.Text = Matriz(1)
                txtctz.Text = "NA"
                txtscz.Text = "NA"
                txtgtz.Text = "NA"

                txtcomite.Text = ""
                txtcomite.Text = Matriz(1)
                objCatCargos.Bandera = 3
                txtcargo.Text = ""
            Case 3
                If Microsoft.VisualBasic.Left(Matriz(2), 2) = "GT" Then
                    sComite = Matriz(1)
                    SCt = "NA"
                    SSc = "NA"
                    sGT = Matriz(2)

                    txtcomitez.Text = Matriz(1)
                    txtctz.Text = "NA"
                    txtscz.Text = "NA"
                    txtgtz.Text = Matriz(2)

                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(2)
                Else
                    sComite = Matriz(1)
                    SCt = Matriz(2)
                    SSc = "NA"
                    sGT = "NA"

                    txtcomitez.Text = Matriz(1)
                    txtctz.Text = Matriz(2)
                    txtscz.Text = "NA"
                    txtgtz.Text = "NA"

                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(2)
                End If

                '''sComite = Matriz(1)
                '''SCt = Matriz(2)
                '''SSc = "NA"
                '''txtcomite.Text = ""
                '''txtcomite.Text = Matriz(2)
                '''objCatCargos.Bandera = 4
                '''txtcargo.Text = ""
            Case 4
                If Microsoft.VisualBasic.Left(Matriz(3), 2) = "GT" Then
                    sComite = Matriz(1)
                    SCt = Matriz(2)
                    SSc = "NA"
                    sGT = Matriz(3)

                    txtcomitez.Text = Matriz(1)
                    txtctz.Text = Matriz(2)
                    txtscz.Text = "NA"
                    txtgtz.Text = Matriz(3)

                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(3)
                Else
                    sComite = Matriz(1)
                    SCt = Matriz(2)
                    SSc = Matriz(3)
                    sGT = "NA"

                    txtcomitez.Text = Matriz(1)
                    txtctz.Text = Matriz(2)
                    txtscz.Text = Matriz(3)
                    txtgtz.Text = "NA"

                    txtcomite.Text = ""
                    txtcomite.Text = Matriz(3)
                End If

                '''sComite = Matriz(1)
                '''SCt = Matriz(2)
                '''SSc = Matriz(3)
                '''sGT = "NA"
                '''txtcomite.Text = ""
                '''txtcomite.Text = Matriz(3)
                '''objCatCargos.Bandera = 5
                '''txtcargo.Text = ""
            Case 5
                sComite = Matriz(1)
                SCt = Matriz(2)
                SSc = Matriz(3)
                sGT = Matriz(4)

                txtcomitez.Text = Matriz(1)
                txtctz.Text = Matriz(2)
                txtscz.Text = Matriz(3)
                txtgtz.Text = Matriz(4)

                txtcomite.Text = ""
                txtcomite.Text = Matriz(4)
                objCatCargos.Bandera = 6
                txtcargo.Text = ""
        End Select

        'carga los cargos del catalog

        objCatCargos.ListaCombo(cbocargos) 'funfiona

    End Sub

#End Region

#End Region

#Region " Habilita"

    Sub Habilita(ByVal setapa As String)

        Select Case setapa
            Case "Inactivo"
                Inactivos(txtclave, txtcomite, txtsector, txtrepresentacion)
                Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
                Inactivos(cbosector, cborepresentacion, cbocargos, dtpFinal, dtpInicio)
            Case "Agregar"
                Inactivos(txtclave, txtcomite, txtsector, txtrepresentacion)
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
                Limpia_Campos(txtcomite, txtsector, txtrepresentacion, txtcargo)
                Muestra(TVcomites)
                Activos(cbosector, cborepresentacion, cbocargos)
                zComite = Nothing
                zCt = Nothing
                zSc = Nothing
                zGT = Nothing
                zComite = Nothing
                zCt = Nothing
                zSc = Nothing
                zGT = Nothing
                Activos(dtpFinal, dtpInicio)
            Case "Editar"
                Muestra(TVcomites)
                Activos(cbosector, cborepresentacion, cbocargos)
                Inactivos(txtclave, txtcomite, txtsector, txtrepresentacion)
                Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4))
                Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(0))
                Activos(dtpFinal, dtpInicio)
                '''Busca las representaciones
                ''objrepresentacion.Bandera = 1
                ''objrepresentacion.ListaCombo(cborepresentacion)
                '''busca los sectores
                ''Dim oTablaST As DataTable
                ''Dim RegST As DataRow
                ''objsector.Bandera = 1
                ''objsector.ListaCombo(cbosector)
                ''llena_TreeView()




        End Select

    End Sub

    Private Sub cbosector_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbosector.SelectedIndexChanged
        If Setapa <> "" Then
            txtsector.Text = cbosector.Text
        End If
    End Sub

#End Region

    Private Sub cborepresentacion_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cborepresentacion.SelectedIndexChanged
        If Setapa <> "" Then
            txtrepresentacion.Text = cborepresentacion.Text
        End If
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                TVcomites.Enabled = True
                Setapa = "Agregar"
                Call Habilita(Setapa)
            Case 1 'editar
                TVcomites.Enabled = True
                Setapa = "Editar"
                Call Habilita(Setapa)
            Case 2 'Deshacer
                TVcomites.Enabled = False
                Setapa = "Inactivo"
                Call Habilita(Setapa)
            Case 3 'Salvar
                reasignar()
                If (sComite = "NA" Or sComite = "") And (SCt = "NA" Or SCt = "") And (SSc = "NA" Or SSc = "") And (sGT = "NA" Or sGT = "") Then
                    MsgBox("Imposible agragar o actualizar datos. El campo pertenece esta vacio")
                    Exit Sub
                End If
                If Setapa = "Editar" Then
                    Call Actualiza()
                Else
                    Call Inserta()
                    Setapa = "Inactivo"
                    'Call Habilita(Setapa)
                End If
                TVcomites.Enabled = False
            Case 4 'Borrar
                Call Borra()
                TVcomites.Enabled = False
            Case 5 'Salir
                Me.Dispose()
        End Select
    End Sub
    Private Sub reasignar()
        If (txtcomitez.Text = "NA" Or txtcomitez.Text = "") And (txtctz.Text = "NA" Or txtctz.Text = "") And (txtscz.Text = "NA" Or txtscz.Text = "") And (txtgtz.Text = "NA" Or txtgtz.Text = "") Then
            Exit Sub
        End If
        sComite = txtcomitez.Text
        SCt = txtctz.Text
        SSc = txtscz.Text
        sGT = txtgtz.Text
    End Sub
    Private Sub cbocargos_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbocargos.SelectedIndexChanged
        If Setapa <> "" Then
            txtcargo.Text = cbocargos.Text
        End If

    End Sub
    Sub Actualiza()
        ObjCargos.Bandera = 2
        ObjCargos.Consecutivo = SConsecutivo
        ObjCargos.Cve_Cargo = cbocargos.SelectedValue
        ObjCargos.Cve_Comite = sComite
        ObjCargos.Cve_ComiteTec = SCt
        ObjCargos.Cve_Subcomite = SSc
        ObjCargos.Cve_Grupo = sGT
        ObjCargos.Cve_Directorio = txtclave.Text
        ObjCargos.sector = cbosector.SelectedValue
        ObjCargos.representacion = cborepresentacion.SelectedValue
        ObjCargos.IdNombramiento = cboFolios.SelectedValue
        ObjCargos.F_VigenciaInicio = dtpInicio.Text
        ObjCargos.F_VigenciaFinal = dtpFinal.Text

        ObjCargos.Actualiza()
        Activo = 1
        SCveDirectorio = txtclave.Text
        Me.Dispose()
    End Sub

    Sub Inserta()
        Dim consec As Integer
        ObjCargos.Bandera = 1
        ObjCargos.Lista()
        consec = ObjCargos.Consecutivo + 1
        ObjCargos.Consecutivo = consec
        ObjCargos.Cve_Cargo = cbocargos.SelectedValue
        ObjCargos.Cve_Comite = sComite
        ObjCargos.Cve_ComiteTec = SCt
        ObjCargos.Cve_Subcomite = SSc
        ObjCargos.Cve_Grupo = sGT
        ObjCargos.Cve_Directorio = txtclave.Text
        ObjCargos.sector = cbosector.SelectedValue
        ObjCargos.representacion = cborepresentacion.SelectedValue
        ObjCargos.IdNombramiento = cboFolios.SelectedValue
        ObjCargos.F_VigenciaInicio = dtpInicio.Text
        ObjCargos.F_VigenciaFinal = dtpFinal.Text

        ObjCargos.Actualiza()
        Activo = 1
        SCveDirectorio = txtclave.Text
        Me.Dispose()

    End Sub

    Sub Borra()
        ObjCargos.Bandera = 3
        ObjCargos.Consecutivo = SConsecutivo
        ObjCargos.Actualiza()
        Activo = 1
        SCveDirectorio = txtclave.Text
        Me.Dispose()

    End Sub

    Sub Validaciones()
        If txtcomite.Text = "" Then
            MsgBox("Es necesario escoger el Comit�,Comit� T�cnico, Subcomit� o Grupo de Trabajo para el cargo")
            Exit Sub
        End If
        If txtsector.Text = "" Then
            MsgBox("El Sector no puede quedar vaci�n")
            Exit Sub
        End If
        If txtrepresentacion.Text = "" Then
            MsgBox("La representaci�n no pude quedar vac�o")
            Exit Sub
        End If
        If txtcargo.Text = "" Then
            MsgBox("El cargo no puede quedar vac�o")
            Exit Sub
        End If
        If sComite = "" And SCt = "" And SSc = "" And sGT = "" Then
            MsgBox("Es necesario escoger el Comit�,Comit� T�cnico, Subcomit� o Grupo de Trabajo para el cargo")
            Exit Sub
        End If

    End Sub

    Private Sub txtsector_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsector.TextChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpInicio.ValueChanged

    End Sub

    Private Sub FillFoliosNombramientos(ByVal cbo As ComboBox)
        Dim dt As DataTable
        Dim objNombramientos As New clsNombramientos.AnceSystem.clssNombramientos
        objNombramientos.Bandera = "s2"
        dt = objNombramientos.Listar

        cbo.DisplayMember = "Folio"
        cbo.ValueMember = "IdNombramiento"
        cbo.DataSource = dt
    End Sub
End Class
