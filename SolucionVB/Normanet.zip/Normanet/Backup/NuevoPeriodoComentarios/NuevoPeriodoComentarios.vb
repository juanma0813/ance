Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class NuevoPeriodoComentarios

    '''''''Declaracion de Variables Privadas
    Private dsNuevoPeriodoComentarios As New DataSet
    Private _Id_Plan As String
    Private _Id_Tema As Integer
    Private _Consecutivo As Integer
    Private _F_Cambio As System.DateTime
    Private _F_Inicial As System.DateTime
    Private _F_Final As System.DateTime
    Private _Status As Boolean
    Private sSql As String
    Private _Tipo As String
    Private _Encontrado As Boolean
    Private _Bandera As Integer
    Private _Opcion As String
    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _sReferencia As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

    '''''''Declaracion de Propiedades publicas
    Public Property Id_Plan() As String
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value As String)
            _Id_Plan = Value
        End Set
    End Property

    Public Property Id_Tema() As Integer
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value As Integer)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Consecutivo() As Integer
        Get
            Return _Consecutivo
        End Get
        Set(ByVal Value As Integer)
            _Consecutivo = Value
        End Set
    End Property

    Public Property F_Cambio() As System.DateTime
        Get
            Return _F_Cambio
        End Get
        Set(ByVal Value As System.DateTime)
            _F_Cambio = Value
        End Set
    End Property

    Public Property F_Inicial() As System.DateTime
        Get
            Return _F_Inicial
        End Get
        Set(ByVal Value As System.DateTime)
            _F_Inicial = Value
        End Set
    End Property

    Public Property F_Final() As System.DateTime
        Get
            Return _F_Final
        End Get
        Set(ByVal Value As System.DateTime)
            _F_Final = Value
        End Set
    End Property

    Public Property Status() As Boolean
        Get
            Return _Status
        End Get
        Set(ByVal Value As Boolean)
            _Status = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property
    Public Property Opcion() As String
        Get
            Return _Opcion
        End Get
        Set(ByVal Value As String)
            _Opcion = Value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property sReferencia() As String
        Get
            Return _Sreferencia
        End Get
        Set(ByVal Value As String)
            _Sreferencia = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("NuevoPeriodoComentarios")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function
    Public Property Tipo() As String
        Get
            Return _Tipo
        End Get
        Set(ByVal Value As String)
            _Tipo = Value
        End Set
    End Property

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sTema As Integer, ByVal splan As String) As NuevoPeriodoComentarios
        sSql = "SELECT * FROM  P_Nuevo_Periodo_Comentarios WHERE id_tema='" & sTema & "' and id_plan='" & splan & "' and status = 1"
        sSql = sSql + "and ref_a�o + ref_comite + ref_Consecutivo + ref_regreso + ref_traspaso = '" & _sReferencia & "'"
        If _Tipo = "abandono" Then sSql = sSql + " order by dbo.P_Avance_Temas_Fechas.ref_regreso desc"
        If _Tipo = "traspaso" Then sSql = sSql + " order by dbo.P_Avance_Temas_Fechas.traspaso desc "

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            da.Fill(dsNuevoPeriodoComentarios, "C_Encontrado")
            cn.Close()
            If dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows.Count > 0 Then
                _Ref_A�o = IIf(IsDBNull(dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")) = True, "", dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_A�o"))
                _Ref_Comite = IIf(IsDBNull(dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, "", dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
                _Ref_Consecutivo = IIf(IsDBNull(dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, "", dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
                _Ref_Regreso = IIf(IsDBNull(dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, "", dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
                _Ref_Traspaso = IIf(IsDBNull(dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, "", dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))
                _Id_Plan = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Id_Plan")
                _Id_Tema = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Id_Tema")
                _Consecutivo = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Consecutivo")
                _F_Cambio = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("F_Cambio")
                _F_Inicial = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("F_Inicial")
                _F_Final = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("F_Final")
                _Status = dsNuevoPeriodoComentarios.Tables("C_Encontrado").Rows(0).Item("Status")
                _Encontrado = True
            Else
                _Id_Plan = ""
                _Id_Tema = 0
                _Consecutivo = -1
                _F_Cambio = Nothing
                _F_Inicial = Nothing
                _F_Final = Nothing
                _Status = ""
            End If
            dsNuevoPeriodoComentarios.Tables("C_Encontrado").Clear()
        Catch ex As Exception
            Dim ms
            ms = ex.Message
        End Try
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar() As String
        Dim cmd As New SqlCommand
        cmd.CommandText = "SP_NuevoPeriodoComentarios"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Consecutivo", _Consecutivo)
        cmd.Parameters.Add("@F_Cambio", _F_Cambio)
        cmd.Parameters.Add("@F_Inicial", _F_Inicial)
        cmd.Parameters.Add("@F_Final", _F_Final)
        cmd.Parameters.Add("@Status", _Status)
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "SP_NuevoPeriodoComentarios"

        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Consecutivo", _Consecutivo)
        cmd.Parameters.Add("@F_Inicial", _F_Inicial)
        cmd.Parameters.Add("@F_Final", _F_Final)
        cmd.Parameters.Add("@Status", _Status)
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        If cn.State = 1 Then cn.Close()
        cn.Open()

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class

