Imports System.Configuration


Public Class FrmCatalogoDirectorio
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtdomicilio As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtempresa As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtclave As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbonombre As System.Windows.Forms.ComboBox
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdCargos As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents tlbVencidos As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents grdMiembros As System.Windows.Forms.DataGrid
    Friend WithEvents optVencidos As System.Windows.Forms.RadioButton
    Friend WithEvents optProximos As System.Windows.Forms.RadioButton
    Friend WithEvents cboComite As System.Windows.Forms.ComboBox
    Friend WithEvents chkPorComite As System.Windows.Forms.CheckBox
    Friend WithEvents chkFiltros As System.Windows.Forms.CheckBox
    Friend WithEvents cmdEliminar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdActivar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGenerarPassword As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdResumne As System.Windows.Forms.ToolBarButton
    Friend WithEvents grdCargos As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmCatalogoDirectorio))
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.cmdCargos = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.cmdEliminar = New System.Windows.Forms.ToolBarButton
        Me.cmdActivar = New System.Windows.Forms.ToolBarButton
        Me.cmdGenerarPassword = New System.Windows.Forms.ToolBarButton
        Me.cmdResumne = New System.Windows.Forms.ToolBarButton
        Me.grdCargos = New System.Windows.Forms.DataGrid
        Me.txtpassword = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txttelefono = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtdomicilio = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtempresa = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtnombre = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtclave = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.cbonombre = New System.Windows.Forms.ComboBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.tlbVencidos = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chkFiltros = New System.Windows.Forms.CheckBox
        Me.chkPorComite = New System.Windows.Forms.CheckBox
        Me.optProximos = New System.Windows.Forms.RadioButton
        Me.optVencidos = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.grdMiembros = New System.Windows.Forms.DataGrid
        Me.cboComite = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.grdCargos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdMiembros, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(8, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(680, 480)
        Me.TabControl1.TabIndex = 17
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.tlbBotonera)
        Me.TabPage1.Controls.Add(Me.grdCargos)
        Me.TabPage1.Controls.Add(Me.txtpassword)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.txtemail)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.txttelefono)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.txtdomicilio)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.txtempresa)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.txtnombre)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.txtclave)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.cbonombre)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(672, 454)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Directorio"
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.cmdCargos, Me.CmdSalir, Me.cmdEliminar, Me.cmdActivar, Me.cmdGenerarPassword, Me.cmdResumne})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 392)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(672, 62)
        Me.tlbBotonera.TabIndex = 36
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'cmdCargos
        '
        Me.cmdCargos.ImageIndex = 8
        Me.cmdCargos.Text = "Cargos"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'cmdEliminar
        '
        Me.cmdEliminar.ImageIndex = 11
        Me.cmdEliminar.Text = "Eliminar"
        Me.cmdEliminar.ToolTipText = "Eliminar Participante"
        '
        'cmdActivar
        '
        Me.cmdActivar.ImageIndex = 12
        Me.cmdActivar.Text = "Activar"
        Me.cmdActivar.ToolTipText = "Activar Miembro"
        '
        'cmdGenerarPassword
        '
        Me.cmdGenerarPassword.ImageIndex = 13
        Me.cmdGenerarPassword.Text = "Password"
        Me.cmdGenerarPassword.ToolTipText = "Generar Password"
        '
        'cmdResumne
        '
        Me.cmdResumne.ImageIndex = 14
        Me.cmdResumne.Text = "Resumen"
        Me.cmdResumne.ToolTipText = "Resumen de cargos"
        '
        'grdCargos
        '
        Me.grdCargos.AlternatingBackColor = System.Drawing.Color.Silver
        Me.grdCargos.BackColor = System.Drawing.Color.White
        Me.grdCargos.CaptionBackColor = System.Drawing.Color.YellowGreen
        Me.grdCargos.CaptionFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdCargos.CaptionForeColor = System.Drawing.Color.White
        Me.grdCargos.CaptionText = "Cargos Asignados"
        Me.grdCargos.DataMember = ""
        Me.grdCargos.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdCargos.ForeColor = System.Drawing.Color.Black
        Me.grdCargos.GridLineColor = System.Drawing.Color.Silver
        Me.grdCargos.HeaderBackColor = System.Drawing.Color.Silver
        Me.grdCargos.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.grdCargos.HeaderForeColor = System.Drawing.Color.Black
        Me.grdCargos.LinkColor = System.Drawing.Color.Maroon
        Me.grdCargos.Location = New System.Drawing.Point(8, 168)
        Me.grdCargos.Name = "grdCargos"
        Me.grdCargos.ParentRowsBackColor = System.Drawing.Color.Silver
        Me.grdCargos.ParentRowsForeColor = System.Drawing.Color.Black
        Me.grdCargos.SelectionBackColor = System.Drawing.Color.Maroon
        Me.grdCargos.SelectionForeColor = System.Drawing.Color.White
        Me.grdCargos.Size = New System.Drawing.Size(656, 216)
        Me.grdCargos.TabIndex = 35
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(272, 136)
        Me.txtpassword.MaxLength = 10
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(88, 20)
        Me.txtpassword.TabIndex = 29
        Me.txtpassword.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(208, 136)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 23)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Password"
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(72, 8)
        Me.txtemail.MaxLength = 60
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(376, 20)
        Me.txtemail.TabIndex = 28
        Me.txtemail.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(16, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 23)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "Email"
        '
        'txttelefono
        '
        Me.txttelefono.Location = New System.Drawing.Point(72, 136)
        Me.txttelefono.MaxLength = 45
        Me.txttelefono.Name = "txttelefono"
        Me.txttelefono.Size = New System.Drawing.Size(124, 20)
        Me.txttelefono.TabIndex = 25
        Me.txttelefono.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(16, 136)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 23)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Tel�fono"
        '
        'txtdomicilio
        '
        Me.txtdomicilio.Location = New System.Drawing.Point(72, 104)
        Me.txtdomicilio.MaxLength = 150
        Me.txtdomicilio.Name = "txtdomicilio"
        Me.txtdomicilio.Size = New System.Drawing.Size(376, 20)
        Me.txtdomicilio.TabIndex = 23
        Me.txtdomicilio.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 23)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Domicilio"
        '
        'txtempresa
        '
        Me.txtempresa.Location = New System.Drawing.Point(72, 72)
        Me.txtempresa.MaxLength = 100
        Me.txtempresa.Name = "txtempresa"
        Me.txtempresa.Size = New System.Drawing.Size(376, 20)
        Me.txtempresa.TabIndex = 21
        Me.txtempresa.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 23)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Empresa"
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(72, 40)
        Me.txtnombre.MaxLength = 50
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(368, 20)
        Me.txtnombre.TabIndex = 20
        Me.txtnombre.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 23)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Nombre"
        '
        'txtclave
        '
        Me.txtclave.Location = New System.Drawing.Point(456, 104)
        Me.txtclave.Name = "txtclave"
        Me.txtclave.Size = New System.Drawing.Size(88, 20)
        Me.txtclave.TabIndex = 19
        Me.txtclave.Text = ""
        Me.txtclave.Visible = False
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(456, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 23)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Clave"
        Me.Label1.Visible = False
        '
        'cbonombre
        '
        Me.cbonombre.Location = New System.Drawing.Point(72, 40)
        Me.cbonombre.Name = "cbonombre"
        Me.cbonombre.Size = New System.Drawing.Size(384, 21)
        Me.cbonombre.TabIndex = 24
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.tlbVencidos)
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(672, 454)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Registros Directorio, Proximos y vencidos"
        '
        'tlbVencidos
        '
        Me.tlbVencidos.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2})
        Me.tlbVencidos.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbVencidos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbVencidos.DropDownArrows = True
        Me.tlbVencidos.ImageList = Me.ImgListBotonera
        Me.tlbVencidos.Location = New System.Drawing.Point(0, 392)
        Me.tlbVencidos.Name = "tlbVencidos"
        Me.tlbVencidos.ShowToolTips = True
        Me.tlbVencidos.Size = New System.Drawing.Size(672, 62)
        Me.tlbVencidos.TabIndex = 1
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 9
        Me.ToolBarButton1.Text = "Buscar"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 10
        Me.ToolBarButton2.Text = "Exportar"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkFiltros)
        Me.GroupBox1.Controls.Add(Me.chkPorComite)
        Me.GroupBox1.Controls.Add(Me.optProximos)
        Me.GroupBox1.Controls.Add(Me.optVencidos)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.cboComite)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(560, 376)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'chkFiltros
        '
        Me.chkFiltros.Location = New System.Drawing.Point(24, 40)
        Me.chkFiltros.Name = "chkFiltros"
        Me.chkFiltros.Size = New System.Drawing.Size(128, 24)
        Me.chkFiltros.TabIndex = 6
        Me.chkFiltros.Text = "Proximos y vencidos"
        '
        'chkPorComite
        '
        Me.chkPorComite.Location = New System.Drawing.Point(24, 16)
        Me.chkPorComite.Name = "chkPorComite"
        Me.chkPorComite.Size = New System.Drawing.Size(80, 16)
        Me.chkPorComite.TabIndex = 5
        Me.chkPorComite.Text = "Por Comite"
        '
        'optProximos
        '
        Me.optProximos.Enabled = False
        Me.optProximos.Location = New System.Drawing.Point(232, 48)
        Me.optProximos.Name = "optProximos"
        Me.optProximos.Size = New System.Drawing.Size(72, 16)
        Me.optProximos.TabIndex = 4
        Me.optProximos.Text = "Proximos"
        '
        'optVencidos
        '
        Me.optVencidos.Checked = True
        Me.optVencidos.Enabled = False
        Me.optVencidos.Location = New System.Drawing.Point(160, 48)
        Me.optVencidos.Name = "optVencidos"
        Me.optVencidos.Size = New System.Drawing.Size(72, 16)
        Me.optVencidos.TabIndex = 3
        Me.optVencidos.TabStop = True
        Me.optVencidos.Text = "Vencidos"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.grdMiembros)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 72)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(544, 296)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Miembros y asociados"
        '
        'grdMiembros
        '
        Me.grdMiembros.AllowSorting = False
        Me.grdMiembros.DataMember = ""
        Me.grdMiembros.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdMiembros.Location = New System.Drawing.Point(8, 24)
        Me.grdMiembros.Name = "grdMiembros"
        Me.grdMiembros.ReadOnly = True
        Me.grdMiembros.Size = New System.Drawing.Size(528, 264)
        Me.grdMiembros.TabIndex = 0
        '
        'cboComite
        '
        Me.cboComite.Enabled = False
        Me.cboComite.Location = New System.Drawing.Point(160, 16)
        Me.cboComite.Name = "cboComite"
        Me.cboComite.Size = New System.Drawing.Size(240, 21)
        Me.cboComite.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(112, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 16)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Comite:"
        '
        'FrmCatalogoDirectorio
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(696, 498)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "FrmCatalogoDirectorio"
        Me.Text = "Directorio"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.grdCargos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdMiembros, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Inicializa Variables"
    Dim Setapa As String
    Dim ObjDirectorio As New ClsDirectorio.C_Directorio(0, gUsuario, gPasswordSql)
    Dim ObjCargos As New ClsDirectorio_Cargos.C_Directorio_Cargos(0, gUsuario, gPasswordSql)
    Public dsConsulta As New DataSet
    Private dtDirectorio As DataTable
    Private dtCargos As DataTable
    Dim Tabla As String = "C_Encontrado"
    Dim Ibandera As Integer
    Dim dgEstiloColumna As New DataGridTableStyle
    Dim ColEStilo1 As New DataGridTextBoxColumn
    Dim ColEStilo2 As New DataGridTextBoxColumn
    Dim ColEStilo3 As New DataGridTextBoxColumn
    Dim ColEStilo4 As New DataGridTextBoxColumn
    Dim ColEStilo5 As New DataGridTextBoxColumn
    Dim ColEStilo6 As New DataGridTextBoxColumn
    Dim ColEStilo7 As New DataGridTextBoxColumn
    Dim ColEStilo8 As New DataGridTextBoxColumn
    Dim zcomite As String
    Dim zct As String
    Dim zsc As String
    Dim zgt As String
    Dim frm_entrada As Resolucion
    Public bandError As Boolean
    Public bandhabilita As Boolean

#End Region

#Region " Forms - FrmCatalogoDirectorio, Metodos y Procesos"

#Region " FrmCatalogoDirectorio - FrmCatalogoDirectorio_Load, Metodos y Procesos"

    Private Sub FrmCatalogoDirectorio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bandgrd = False
        Setapa = "Inactivo"
        Call Habilita(Setapa)
        Ibandera = 0
        dtDirectorio = ObjDirectorio.ListaCombo(cbonombre)
        Ibandera = 1
        FormaGrid()

        LlenarComites()
    End Sub

#End Region

    Private Sub LlenarComites()
        Dim objBusquedasWeb As New clsConsultasWeb.Maple.clsProyectosWeb
        objBusquedasWeb.Bandera = "s19"
        cboComite.DataSource = objBusquedasWeb.Listar
        cboComite.DisplayMember = "Id_Comite"
        cboComite.ValueMember = "Id_Comite"

        objBusquedasWeb = Nothing
    End Sub

#Region " FrmCatalogoDirectorio - FrmCatalogoDirectorio_Activated, Metodos y Procesos"

    Private Sub FrmCatalogoDirectorio_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        If Activo <> 0 Then
            'ObjDirectorio.ID_Directorio = SCveDirectorio
            Call Llena_Campos()
            Activo = 0
        End If
    End Sub

#End Region

#End Region


    Sub Habilita(ByVal Etapa As String)
        Select Case Etapa
            Case "Inactivo"
                Inactivos(txtnombre, txtempresa, txtdomicilio, txttelefono, txtemail, txtpassword, txtclave)
                Inactivos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5), tlbBotonera.Buttons.Item(7), tlbBotonera.Buttons.Item(9))

                Activar(tlbBotonera.Buttons.Item(6), tlbBotonera.Buttons.Item(8))
                Activos(tlbBotonera.Buttons.Item(0), cbonombre)
            Case "Existe" ' al seleccionar combo
                Activos(tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(5), tlbBotonera.Buttons.Item(9))
                inactivar(tlbBotonera.Buttons.Item(7))
            Case "Agregar"
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5), tlbBotonera.Buttons.Item(6), tlbBotonera.Buttons.Item(9))
                Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(7))
                Limpia_Campos(txtnombre, txtempresa, txtdomicilio, txttelefono, txtemail, txtpassword, txtclave)
                Activos(txtnombre, txtempresa, txtdomicilio, txttelefono, txtemail, txtpassword, txtclave)
                Inactivos(cbonombre)
                GrdCargos.DataSource = Nothing
                inactivar(tlbBotonera.Buttons.Item(8))
            Case "Editar"
                Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4), tlbBotonera.Buttons.Item(5))
                Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3), tlbBotonera.Buttons.Item(7))
                Inactivos(txtclave, cbonombre)
                Activos(txtnombre, txtempresa, txtdomicilio, txttelefono, txtemail, txtpassword)
                inactivar(tlbBotonera.Buttons.Item(6), tlbBotonera.Buttons.Item(7), tlbBotonera.Buttons.Item(8), tlbBotonera.Buttons.Item(9))
        End Select
    End Sub


    Private Sub cbonombre_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbonombre.SelectedIndexChanged
        If Ibandera = 1 Then
            txtnombre.Text = cbonombre.Text
            Call Llena_Campos()
        End If

    End Sub

    Sub Llena_Campos()

        ObjDirectorio.ID_Directorio = cbonombre.SelectedValue
        ObjDirectorio.Buscar()
        If ObjDirectorio.Encontrado = True Then
            Setapa = "Existe"
            Call Habilita(Setapa)
            txtclave.Text = IIf(IsDBNull(ObjDirectorio.ID_Directorio) = True, "", ObjDirectorio.ID_Directorio)
            txtnombre.Text = IIf(IsDBNull(ObjDirectorio.Nombre) = True, "", ObjDirectorio.Nombre)
            txtempresa.Text = IIf(IsDBNull(ObjDirectorio.Empresa) = True, "", ObjDirectorio.Empresa)
            txtdomicilio.Text = IIf(IsDBNull(ObjDirectorio.Domicilio) = True, "", ObjDirectorio.Domicilio)
            txttelefono.Text = IIf(IsDBNull(ObjDirectorio.Telefono) = True, "", ObjDirectorio.Telefono)
            REM txtfax.Text = IIf(IsDBNull(ObjDirectorio.Fax) = True, "", ObjDirectorio.Fax)
            txtemail.Text = IIf(IsDBNull(ObjDirectorio.Mail) = True, "", ObjDirectorio.Mail)
            txtpassword.Text = IIf(IsDBNull(ObjDirectorio.Password) = True, "", ObjDirectorio.Password)
            ObjCargos.Cve_Directorio = txtclave.Text

            dtCargos = ObjCargos.Buscar()
            If ObjCargos.Encontrado = True Then
                Dim cm As CurrencyManager
                cm = CType(BindingContext(dtCargos), CurrencyManager)
                'Instanciamos y creamos un DataView asosiado a nuestro manejador CurrencyManager
                Dim Dv As DataView = CType(cm.List, DataView)
                'Asignamos el valor que deseamos para evitar o permitir nuevos registros
                Dv.AllowNew = False
                ' Dv.Item(0).Delete()

                GrdCargos.Visible = True
                GrdCargos.DataSource = dtCargos
                Setapa = "Existe"
                Call Habilita(Setapa)
            Else
                GrdCargos.DataSource = Nothing
            End If
        End If

    End Sub

    Sub FormaGrid()
        With grdCargos()
            .CaptionText = "CARGOS ASIGNADOS AL DIRECTORIO"
            .CaptionBackColor = Color.RoyalBlue
            .CaptionFont = New Font("Tahoma", 10.0!, FontStyle.Bold)
            '.CaptionForeColor = Color.Bisque
            '.BackColor = Color.GhostWhite
            '.BackgroundColor = Color.Lavender
            .BorderStyle = BorderStyle.None
            .Font = New Font("Tahoma", 8.0!)
            '.ParentRowsBackColor = Color.Green
            '.ParentRowsForeColor = Color.MidnightBlue
            .AllowSorting = False
        End With
        Call Tabla_Color(dgEstiloColumna, grdCargos)

        With dgEstiloColumna
            '.AlternatingBackColor = Color.GhostWhite
            '.BackColor = Color.GhostWhite
            '.GridLineColor = Color.RoyalBlue
            '.HeaderBackColor = Color.MidnightBlue
            .HeaderFont = New Font("Tahoma", 8.0!, FontStyle.Bold)
            '.HeaderForeColor = Color.Lavender
            '.SelectionBackColor = Color.GreenYellow
            '.SelectionForeColor = Color.Blue
            .MappingName = Tabla
            .PreferredColumnWidth = 125
            .PreferredRowHeight = 15
            .AllowSorting = False
        End With

        With ColEStilo1
            .HeaderText = "Cargo"
            .MappingName = "Descripcion"
            .Width = 80
            .ReadOnly = True
        End With

        With ColEStilo2
            .HeaderText = "Comit�"
            .MappingName = "Cve_comite"
            .Width = 60
            .ReadOnly = True
        End With

        With ColEStilo3
            .HeaderText = "CT"
            .MappingName = "Cve_comitetec"
            .Width = 60
            .ReadOnly = True
        End With

        With ColEStilo4
            .HeaderText = "SC"
            .MappingName = "Cve_subcomite"
            .Width = 60
            .ReadOnly = True
        End With

        With ColEStilo5
            .HeaderText = "GT"
            .MappingName = "Cve_grupo"
            .Width = 60
            .ReadOnly = True
        End With

        With ColEStilo6
            .HeaderText = "Sector"
            .MappingName = "Sector"
            .Width = 100
            .ReadOnly = True
        End With

        With ColEStilo7
            .HeaderText = "Representacion"
            .MappingName = "Representacion"
            .Width = 100
            .ReadOnly = True
        End With
        With ColEStilo8
            .HeaderText = "Consecutivo"
            .MappingName = "Consecutivo"
            .Width = 0
            .ReadOnly = True
        End With
        dgEstiloColumna.GridColumnStyles.AddRange(New DataGridColumnStyle() {ColEStilo1, ColEStilo2, ColEStilo3, ColEStilo4, ColEStilo5, ColEStilo6, ColEStilo7, ColEStilo8})
        grdCargos.TableStyles.Add(dgEstiloColumna)




        'Dim cm As CurrencyManager = CType(Me.BindingContext(Me.GrdCargos.DataSource, Me.GrdCargos.DataMember), CurrencyManager)
        'CType(cm.List, DataView).AllowNew = False

    End Sub

    Private Sub cbonombre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbonombre.Click
        If Setapa = "" Then
            Ibandera = 0
        Else
            Ibandera = 1
        End If
    End Sub

    Private Sub DesHacer()
        Setapa = "Inactivo"
        Call Habilita(Setapa)
        Limpia_Campos(txtnombre, txtempresa, txtdomicilio, txttelefono, txtemail, txtpassword, txtclave)
        If ObjCargos.Encontrado = True Then
            dtCargos.Clear()
            grdCargos.DataSource = dtCargos
        End If
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar
                Setapa = "Agregar"
                Call Habilita(Setapa)
                txtpassword.Text = CalcularClave()
            Case 1 'editar
                Setapa = "Editar"
                Call Habilita(Setapa)
            Case 2 'Deshacer
                DesHacer()

            Case 3 'salvar
                If Setapa = "Editar" Then
                    Validaciones()
                    Actualiza()
                Else
                    Call Validaciones()
                    If bandError = True Then
                        bandError = False
                        Exit Sub
                    Else
                        Inserta()
                    End If
                End If
                If bandError <> True Then
                    ObjDirectorio.ListaCombo(cbonombre)
                End If
                bandError = False
            Case 4 'Cargos

                Dim dt As New DataTable("Temporal")
                dt = grdCargos.DataSource
                ''If dt Is Nothing Then
                ''    MsgBox("No se ha seleccionado ningun cargo")
                ''    dt = Nothing
                ''    Exit Sub
                ''ElseIf dt.Rows.Count <= 0 Then
                ''    MsgBox("No se ha seleccionado ningun cargo")
                ''    dt.Dispose()
                ''    Exit Sub
                ''End If
                ''dt.Dispose()

                Dim Cargos As New FrmCargosDir
                Cargos.MdiParent = Me.MdiParent

                Dim Seleccionado As Boolean
                Dim iSeleccion As Integer
                For iSeleccion = 0 To ObjCargos.Contador - 1 Step 1
                    Seleccionado = grdCargos.IsSelected(iSeleccion)
                    If Seleccionado Then
                        SCveDirectorio = ""
                        SGralCargos = ""
                        SConsecutivo = ""
                        sSector = ""
                        sRepresentacion = ""
                        sComite = ""
                        SCt = ""
                        SSc = ""
                        sGT = ""
                        'Asigana alas variables Globales los valores del grid
                        SCveDirectorio = txtclave.Text
                        SGralCargos = CStr(grdCargos.Item(iSeleccion, 0))
                        sComite = CStr(grdCargos.Item(iSeleccion, 1))
                        SCt = CStr(grdCargos.Item(iSeleccion, 2))
                        SSc = CStr(grdCargos.Item(iSeleccion, 3))
                        sGT = CStr(grdCargos.Item(iSeleccion, 4))
                        sSector = CStr(grdCargos.Item(iSeleccion, 5))
                        sRepresentacion = CStr(grdCargos.Item(iSeleccion, 6))
                        SConsecutivo = CStr(grdCargos.Item(iSeleccion, 7))

                    End If
                Next

                Cargos.Show()

                Cargos.txtcomitez.Text = zcomite
                Cargos.txtctz.Text = zct
                Cargos.txtscz.Text = zsc
                Cargos.txtgtz.Text = zgt
                Cargos.txtclave.Text = Me.txtclave.Text

                If bandgrd <> False Then
                    Cargos.txtcargo.Text = SGralCargos
                    Cargos.cbocargos.Text = SGralCargos
                    Cargos.cbosector.Text = sSector
                    Cargos.cborepresentacion.Text = sRepresentacion
                Else
                    Cargos.txtcargo.Text = ""
                    Cargos.cbocargos.Text = ""
                End If

                ''Maple
                If txtnombre.Text = "" Then
                    Cargos.Dispose()
                    MsgBox("No se ha seleccionado a ningun integrante del directorio")
                    Exit Sub
                End If

                If dt Is Nothing Then
                    REM tener la posibilidad de agregar uno nuevo
                    Activar(Cargos.tlbBotonera.Buttons(0), Cargos.tlbBotonera.Buttons(2), Cargos.tlbBotonera.Buttons(3), Cargos.tlbBotonera.Buttons(5))
                    inactivar(Cargos.tlbBotonera.Buttons(1), Cargos.tlbBotonera.Buttons(4))
                    'Else
                    '    REM tener la posibilidad de agregar nuevos y editar
                    '    Activar(Cargos.tlbBotonera.Buttons(1), Cargos.tlbBotonera.Buttons(2), Cargos.tlbBotonera.Buttons(3), Cargos.tlbBotonera.Buttons(4), Cargos.tlbBotonera.Buttons(5))
                End If
                ''Maple
            Case 5 'Salir
                Me.Dispose()
            Case 6 'Eliminar
                If txtclave.Text <> "" Then
                    If MsgBox("�Estas seguro de eliminar el registro?", MsgBoxStyle.Information Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                        EliminarRegistro()
                    End If
                Else
                    MsgBox("Es necesario seleccionar a miembro del combo para eliminarlo", MsgBoxStyle.Critical)
                End If
            Case 7 'Activar
                If txtemail.Text <> "" Then
                    ActivarRegistro(txtemail.Text)
                Else
                    MsgBox("Es necesario escribir un correo para intentar activarlo", MsgBoxStyle.Critical)
                End If
            Case 8 'Regenerar Contrase�a
                If txtclave.Text <> "" Then
                    ReGenearContrase�a(txtclave.Text, txtemail.Text)
                Else
                    MsgBox("Es necesario seleccionar a miembro del combo para eliminarlo", MsgBoxStyle.Critical)
                End If
            Case 9 'Listado de cargos
                If Trim(txtemail.Text) = "" Then
                    MsgBox("Es necesario seleccionar a un miembro")
                Else
                    EnviarResumenCargos(txtemail.Text, txtnombre.Text)
                End If
        End Select
    End Sub

    Private Sub ReGenearContrase�a(ByVal IdDirectorio As String, ByVal mail As String)
        Dim password As String = CalcularClave()
        txtpassword.Text = password
        ObjDirectorio.Bandera = 10
        ObjDirectorio.Password = password
        ObjDirectorio.Actualiza()

        EnviarCorreoAcceso(password, mail)
        MsgBox("Contrase�a generada y enviada correctamente", MsgBoxStyle.Information)
    End Sub

    Private Sub EnviarResumenCargos(ByVal mail As String, ByVal Nombre As String)
        Dim dt As DataTable

        REM verificar si tiene cargos
        ObjCargos.Cve_Directorio = txtclave.Text
        dt = ObjCargos.Buscar()
        If dt.Rows.Count <= 0 Then
            MsgBox("No se encontraron cargos para enviar.", MsgBoxStyle.Critical)
        Else
            Dim objCorreo As New clsCorreo.ClsCorreo
            Dim Param01 As New Maple.entXml
            Dim Param02 As New Maple.entXml
            Dim Parametros As New ArrayList

            Param01.Key = "IdDirectorio"
            Param01.Value = txtclave.Text

            Param02.Key = "NombreRemitente"
            Param02.Value = Nombre

            Parametros.Add(Param01)
            Parametros.Add(Param02)

            objCorreo.Bandera = "s3"
            objCorreo.sTo = mail
            objCorreo.Subject = "Resumen de cargos"

            objCorreo.scc = ConfigurationSettings.AppSettings("ccCargosPorMiembro").ToString
            objCorreo.XML = Maple.clssufnSQL.CrearXmlParamSql(Parametros)

            objCorreo.CorreoPersonalizado()
            MsgBox("Correo con resumen de cargos enviado.", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub EnviarCorreoAcceso(ByVal password As String, ByVal email As String)
        Dim Parametros As New ArrayList
        Dim Param01 As New Maple.entXml
        Dim Param02 As New Maple.entXml

        Param01.Key = "Usuario"
        Param01.Value = email

        Param02.Key = "Password"
        Param02.Value = password

        Parametros.Add(Param01)
        Parametros.Add(Param02)

        Dim objCorreo As New clsCorreo.ClsCorreo
        objCorreo.Bandera = "s2"
        objCorreo.sTo = email
        objCorreo.scc = ConfigurationSettings.AppSettings("ccContrasenia").ToString
        objCorreo.XML = Maple.clssufnSQL.CrearXmlParamSql(Parametros)
        objCorreo.Subject = "Datos de inicio de sesi�n Normalizaci�n"
        objCorreo.CorreoPersonalizado()

    End Sub


    Private Sub ActivarRegistro(ByVal mail)
        Dim idDirectorio As String = ""
        Dim dt As DataTable
        ObjDirectorio.Bandera = 7
        ObjDirectorio.Mail = mail
        dt = ObjDirectorio.Listar()

        If dt.Rows.Count > 2 Then
            MsgBox("Se encontro mas de un registro con el mismo correo. No es posible activar el registro", MsgBoxStyle.Critical)
        ElseIf dt.Rows.Count = 1 Then
            ObjDirectorio.Bandera = 9
            ObjDirectorio.ID_Directorio = dt.Rows(0).Item("ID_Directorio")
            ObjDirectorio.Actualiza()
            MsgBox("Se activo el registro del correo ingresado", MsgBoxStyle.Information)
            ObjDirectorio.ListaCombo(cbonombre)
            DesHacer()
        Else
            MsgBox("No se encontr� el registro del correo ingresado", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub EliminarRegistro()
        Dim dt As DataTable
        REM verificar si tiene cargos
        ObjCargos.Cve_Directorio = txtclave.Text
        dt = ObjCargos.Buscar()
        If dt.Rows.Count > 0 Then
            MsgBox("No es posible eliminar a un miembro con cargos activos.", MsgBoxStyle.Critical)
        Else
            ObjDirectorio.Bandera = "5"
            ObjDirectorio.ID_Directorio = txtclave.Text
            ObjDirectorio.Mail = txtemail.Text
            ObjDirectorio.Actualiza()
            MsgBox("Registro eliminado correctamente", MsgBoxStyle.Information)
            ObjDirectorio.ListaCombo(cbonombre)
        End If
    End Sub

    Sub Validaciones()
        ''If txtclave.Text = "" Then
        ''    MsgBox("La clave no puede quedar vac�a")
        ''    bandError = True
        ''    Exit Sub
        ''End If
        If txtnombre.Text = "" Then
            MsgBox("El nombre no puede quedar vac�o")
            bandError = True
            Exit Sub
        End If
        If txtempresa.Text = "" Then
            MsgBox("El campo empresa no puede quedar vac�o")
            bandError = True
            Exit Sub
        End If
        If txtdomicilio.Text = "" Then
            MsgBox("El campo domicilio no puede quedar vac�o")
            bandError = True
            Exit Sub
        End If
        If txttelefono.Text = "" Then
            MsgBox("El campo tel�fono no puede quedar vac�o")
            bandError = True
            Exit Sub
        End If
        If txtemail.Text = "" Then
            MsgBox("El campo email no puede quedar vac�o")
            bandError = True
            Exit Sub
        End If
        If txtpassword.Text = "" Then
            MsgBox("El campo password no puede quedar vac�o")
            bandError = True
            Exit Sub
        End If


    End Sub

    Function CalcularClave() As String
        Dim IdClave As String = ""
        Dim dt As DataTable
        ObjDirectorio.Bandera = "6"
        dt = ObjDirectorio.Listar()

        If dt.Rows.Count > 0 Then
            IdClave = dt.Rows(0).Item("IdClave")
        End If

        Return IdClave
    End Function

    Private Function ValidarExistencia(ByVal Email) As Boolean
        Dim bExiste As Boolean = False

        ObjDirectorio.Bandera = 7
        ObjDirectorio.Mail = Email
        If ObjDirectorio.Listar().Rows.Count > 0 Then
            bExiste = True
        Else
            bExiste = False
        End If

        Return bExiste
    End Function

    Sub Inserta()
        Dim IdClave As String = ""
        Dim bExiste As Boolean = False
        bandError = False

        bExiste = ValidarExistencia(txtemail.Text)
        If bExiste = False Then
            IdClave = CalcularClave()

            If IdClave = "" Then
                MsgBox("No se pudo insertar el registro. Intentalo mas tarde", MsgBoxStyle.Critical)
            Else
                ObjDirectorio.ID_Directorio = IdClave
                ObjDirectorio.Buscar()

                If ObjDirectorio.Encontrado = True Then
                    bandError = True
                    Inserta()
                Else
                    ObjDirectorio.ID_Directorio = IdClave
                    ObjDirectorio.Nombre = txtnombre.Text
                    ObjDirectorio.Bandera = 1
                    ObjDirectorio.Domicilio = txtdomicilio.Text
                    ObjDirectorio.Empresa = txtempresa.Text
                    ObjDirectorio.Telefono = txttelefono.Text
                    ObjDirectorio.Fax = txttelefono.Text
                    ObjDirectorio.Password = txtpassword.Text
                    ObjDirectorio.Mail = Trim(txtemail.Text)
                    ObjDirectorio.Actualiza()
                    If ObjDirectorio.banderaError = False Then
                        EnviarCorreoAcceso(txtpassword.Text, Trim(txtemail.Text))
                    End If

                    Setapa = "Inactivo"
                    Habilita(Setapa)
                End If
            End If
        Else
            bandError = True
            MsgBox("El correo del miembro que intenta registrar ya existe. Por favor registra un correo diferente", MsgBoxStyle.Critical)
        End If
    End Sub

    Sub Actualiza()
        Dim bExiste As Boolean = False
        bandError = False

        ObjDirectorio.ID_Directorio = cbonombre.SelectedValue
        ObjDirectorio.Buscar()

        If ObjDirectorio.Mail <> txtemail.Text Then
            bExiste = ValidarExistencia(txtemail.Text)
        End If

        If bExiste = False Then
            ObjDirectorio.ID_Directorio = txtclave.Text
            ObjDirectorio.Nombre = txtnombre.Text
            ObjDirectorio.Bandera = 2
            ObjDirectorio.Domicilio = txtdomicilio.Text
            ObjDirectorio.Empresa = txtempresa.Text
            ObjDirectorio.Telefono = txttelefono.Text
            ObjDirectorio.Fax = txttelefono.Text
            ObjDirectorio.Password = txtpassword.Text
            ObjDirectorio.Mail = txtemail.Text
            ObjDirectorio.Actualiza()

            Setapa = "Inactivo"
            Habilita(Setapa)
        Else
            bandError = True
            MsgBox("el correo que intenta registrar ya existe.", MsgBoxStyle.Critical)
        End If
    End Sub

    Sub Borra()
        ObjDirectorio.ID_Directorio = txtclave.Text
    End Sub
    Private Sub GrdCargos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdCargos.Click
        If Not grdCargos.DataSource Is Nothing Then
            bandgrd = True
            Dim index As Integer
            index = grdCargos.CurrentRowIndex

            zcomite = grdCargos.Item(index, 1)
            zct = grdCargos.Item(index, 2)
            zsc = grdCargos.Item(index, 3)
            zgt = grdCargos.Item(index, 4)
        End If
        Activos(tlbBotonera.Buttons.Item(4))
    End Sub


    Private Sub chkPorComite_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkPorComite.CheckedChanged
        If chkPorComite.Checked Then
            cboComite.Enabled = True
        Else
            cboComite.Enabled = False
        End If
    End Sub

    Private Sub tlbVencidos_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbVencidos.ButtonClick
        Select Case tlbVencidos.Buttons.IndexOf(e.Button)
            Case 0 REM buscar
                buscarRegistros()
            Case 1 REM exportar
                ExportarExcel()
        End Select
    End Sub

    Private Sub ExportarExcel()
        Dim objExcel As New ClsExcel.ClsExcel
        objExcel.DataTableToExcel(buscarRegistros)
        objExcel = Nothing
    End Sub
    Private Function buscarRegistros() As DataTable
        Dim dt As DataTable
        Dim objDirectorio As New ClsDirectorio_Cargos.C_Directorio_Cargos(0, gUsuario, gPasswordSql)
        Try
            objDirectorio.Bandera = 6
            objDirectorio.Vencidos = optVencidos.Checked
            objDirectorio.Pertenece = IIf(chkPorComite.Checked = True, cboComite.Text, "")
            objDirectorio.Filtrar = chkFiltros.Checked

            dt = objDirectorio.ListarDatos()
            grdMiembros.DataSource = dt
            DGReStyleSesiones()

            objDirectorio = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return dt
    End Function

    Private Sub DGReStyleSesiones()
        Dim dtcol As DataColumn = Nothing
        Try
            grdMiembros.TableStyles.Clear()
            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, grdMiembros)
            'nombre del datatable
            ts1.MappingName = "Encontrados"

            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Nombre"
            TextCol.HeaderText = "Nombre"
            TextCol.Width = 170
            TextCol.TextBox.Enabled = False
            TextCol.NullText = ""
            ts1.GridColumnStyles.Add(TextCol)

            Dim TextCol2 As New DataGridTextBoxColumn
            TextCol2.MappingName = "Empresa"
            TextCol2.HeaderText = "Empresa"
            TextCol2.Width = 170
            TextCol2.TextBox.Enabled = False
            TextCol2.NullText = "" 'por si viene en null el dato
            ts1.GridColumnStyles.Add(TextCol2)

            Dim TextCol3 As New DataGridTextBoxColumn
            TextCol3.MappingName = "Cargo"
            TextCol3.HeaderText = "Cargo"
            TextCol3.Width = 75
            TextCol3.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol3)

            Dim TextCol4 As New DataGridTextBoxColumn
            TextCol4.MappingName = "Clave"
            TextCol4.HeaderText = "Clave"
            TextCol4.Width = 50
            TextCol4.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol4)

            Dim TextCol5 As New DataGridTextBoxColumn
            TextCol5.MappingName = "password"
            TextCol5.HeaderText = "Password"
            TextCol5.Width = 75
            TextCol5.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol5)

            Dim TextCol6 As New DataGridTextBoxColumn
            TextCol6.MappingName = "Pertenece"
            TextCol6.HeaderText = "Pertenece"
            TextCol6.Width = 75
            TextCol6.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol6)

            Dim TextCol7 As New DataGridTextBoxColumn
            TextCol7.MappingName = "F_VigenciaInicio"
            TextCol7.HeaderText = "Vigencia Inicio"
            TextCol7.Width = 125
            TextCol7.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol7)

            Dim TextCol8 As New DataGridTextBoxColumn
            TextCol8.MappingName = "F_VigenciaFinal"
            TextCol8.HeaderText = "Vigencia Final"
            TextCol8.Width = 125
            TextCol8.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol8)


            ' para dar el alto a la fila
            ts1.PreferredRowHeight = TextCol2.TextBox.Height
            grdMiembros.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

    Public Sub Tabla_Color(ByVal ts1 As DataGridTableStyle, ByVal grid As DataGrid)
        ts1.SelectionForeColor = Color.White
        ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderForeColor = Color.White
        ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
        ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)
        grid.BorderStyle = BorderStyle.Fixed3D
        grid.FlatMode = True
        grid.RowHeaderWidth = 18
    End Sub

    Private Sub chkFiltros_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFiltros.CheckedChanged
        If chkFiltros.Checked Then
            optProximos.Enabled = True
            optVencidos.Enabled = True
        Else
            optProximos.Enabled = False
            optVencidos.Enabled = False
        End If
    End Sub

    Private Sub grdCargos_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdCargos.DoubleClick
        If MsgBox("�Deseas Relacionar un nombramiento con el cargo?", MsgBoxStyle.Question Or MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then

        End If

    End Sub
End Class
