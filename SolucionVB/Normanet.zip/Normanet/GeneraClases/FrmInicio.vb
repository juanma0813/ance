Imports System
Imports System.Drawing
Imports System.IO

Public Class FrmInicio
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents BtnGenera As System.Windows.Forms.Button
    Friend WithEvents BtnSalir As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.BtnGenera = New System.Windows.Forms.Button()
        Me.BtnSalir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BtnGenera
        '
        Me.BtnGenera.Location = New System.Drawing.Point(312, 32)
        Me.BtnGenera.Name = "BtnGenera"
        Me.BtnGenera.Size = New System.Drawing.Size(88, 48)
        Me.BtnGenera.TabIndex = 0
        Me.BtnGenera.Text = "Generracion de Clases"
        '
        'BtnSalir
        '
        Me.BtnSalir.Location = New System.Drawing.Point(320, 152)
        Me.BtnSalir.Name = "BtnSalir"
        Me.BtnSalir.Size = New System.Drawing.Size(80, 40)
        Me.BtnSalir.TabIndex = 1
        Me.BtnSalir.Text = "Salir"
        '
        'FrmInicio
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 230)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.BtnSalir, Me.BtnGenera})
        Me.Name = "FrmInicio"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Generador de Clases"
        Me.ResumeLayout(False)

    End Sub

#End Region
    '********************************************************************************
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnGenera_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGenera.Click
        Dim FormaClases As New FrmClases()
        FormaClases.ShowDialog()
    End Sub

    Private Sub BtnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSalir.Click
        End
    End Sub
End Class
