
'*****************************************************************************
'*****************************************************************************
'           Actualizada por Efren David Tello ver 1.1 BETA
'                       NO TIENE CAMPO LLAVE CUIDADO
'              Puede Afectar el correcto funcionamiento de las funciones
'          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
'*****************************************************************************
'*****************************************************************************

Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient
'agrega la referencia de windows form a la clase
'Imports System.Windows.Forms

Public Class ClsJusti_regresos

    '''''''Declaracion de Variables Privadas
    Private dsClsJusti_regresos As New DataSet
    Private _ref_a�o As System.String
    Private _ref_comite As System.String
    Private _ref_consecutivo As System.String
    Private _ref_regreso As System.String
    Private _ref_traspaso As System.String
    Private _F_Regreso As System.DateTime
    Private _Justificacion As System.String
    Private _Status As System.Int32
    Private _Encontrado As Boolean
    Private _Bandera As Integer
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo
    'Si utilisas la clase de coneccion qeu todos sabemos descomenta la linea siguiente
    'Private objconexion As New clsConexion.cIsConexion

    '''''''Declaracion de Propiedades publicas
    Public Property ref_a�o() As System.String
        Get
            Return _ref_a�o
        End Get
        Set(ByVal Value As System.String)
            _ref_a�o = Value
        End Set
    End Property

    Public Property ref_comite() As System.String
        Get
            Return _ref_comite
        End Get
        Set(ByVal Value As System.String)
            _ref_comite = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property

    Public Property ref_consecutivo() As System.String
        Get
            Return _ref_consecutivo
        End Get
        Set(ByVal Value As System.String)
            _ref_consecutivo = Value
        End Set
    End Property

    Public Property ref_regreso() As System.String
        Get
            Return _ref_regreso
        End Get
        Set(ByVal Value As System.String)
            _ref_regreso = Value
        End Set
    End Property

    Public Property ref_traspaso() As System.String
        Get
            Return _ref_traspaso
        End Get
        Set(ByVal Value As System.String)
            _ref_traspaso = Value
        End Set
    End Property

    Public Property F_Regreso() As System.DateTime
        Get
            Return _F_Regreso
        End Get
        Set(ByVal Value As System.DateTime)
            _F_Regreso = Value
        End Set
    End Property

    Public Property Justificacion() As System.String
        Get
            Return _Justificacion
        End Get
        Set(ByVal Value As System.String)
            _Justificacion = Value
        End Set
    End Property

    Public Property Status() As System.Int32
        Get
            Return _Status
        End Get
        Set(ByVal Value As System.Int32)
            _Status = Value
        End Set
    End Property

    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsJusti_regresos")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As String) As ClsJusti_regresos
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM ClsJusti_regresos WHERE Campo_Llave = sClave"
        Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da.Fill(dsClsJusti_regresos, "C_Encontrado")
        cn.Close()
        If dsClsJusti_regresos.Tables("C_Encontrado").Rows.Count > 0 Then
            _ref_a�o = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("ref_a�o")
            _ref_comite = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("ref_comite")
            _ref_consecutivo = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("ref_consecutivo")
            _ref_regreso = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("ref_regreso")
            _ref_traspaso = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("ref_traspaso")
            _F_Regreso = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("F_Regreso")
            _Justificacion = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("Justificacion")
            _Status = dsClsJusti_regresos.Tables("C_Encontrado").Rows(0).Item("Status")
            _Encontrado = True
        Else
            _ref_a�o = Nothing
            _ref_comite = Nothing
            _ref_consecutivo = Nothing
            _ref_regreso = Nothing
            _ref_traspaso = Nothing
            _F_Regreso = Nothing
            _Justificacion = Nothing
            _Status = Nothing
            _Encontrado = False
        End If
        dsClsJusti_regresos.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE ClsJusti_regresos SET ref_a�o = @ref_a�o, ref_comite = @ref_comite, ref_consecutivo = @ref_consecutivo, ref_regreso = @ref_regreso, ref_traspaso = @ref_traspaso, F_Regreso = @F_Regreso, Justificacion = @Justificacion, Status = @Status, Where ( = @)"
        cmd.Parameters.Add("@ref_a�o", "_ref_a�o")
        cmd.Parameters.Add("@ref_comite", "_ref_comite")
        cmd.Parameters.Add("@ref_consecutivo", "_ref_consecutivo")
        cmd.Parameters.Add("@ref_regreso", "_ref_regreso")
        cmd.Parameters.Add("@ref_traspaso", "_ref_traspaso")
        cmd.Parameters.Add("@F_Regreso", "_F_Regreso")
        cmd.Parameters.Add("@Justificacion", "_Justificacion")
        cmd.Parameters.Add("@Status", "_Status")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand '("Sp_Justi_Regreso", cn)
        cmd.CommandText = "Sp_Justi_Regreso"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        If cn.State = 1 Then cn.Close()
        cn.Open()
        cmd.Parameters.Add("@ref_a�o", _ref_a�o)
        cmd.Parameters.Add("@ref_comite", _ref_comite)
        cmd.Parameters.Add("@ref_consecutivo", _ref_consecutivo)
        cmd.Parameters.Add("@ref_regreso", _ref_regreso)
        cmd.Parameters.Add("@ref_traspaso", _ref_traspaso)
        cmd.Parameters.Add("@F_Regreso", _F_Regreso)
        cmd.Parameters.Add("@Justificacion", _Justificacion)
        cmd.Parameters.Add("@Status", _Status)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    '''''''''''''''''Funcion que nos permite llenar un combo
    'Public Function LlenaCombo(ByVal cbo As Object)
    '    Dim cmd As New SqlCommand
    '    cmd.CommandType = CommandType.StoredProcedure
    '    cmd.CommandText = "nombre del store"
    '    cmd.Connection = cn
    '    cmd.Parameters.Add("@parametro", _parametro)
    '    Dim da As SqlDataAdapter
    '    Dim dt As New DataTable("clsempleados")
    '    Try
    '        da = New Data.SqlClient.SqlDataAdapter(cmd)
    '        da.Fill(dt)
    '        cbo.DisplayMember = dt.Columns(1).ColumnName
    '        cbo.ValueMember = dt.Columns(0).ColumnName
    '        cbo.DataSource = dt
    '    Catch ex As Exception
    '        Return ex
    '    End Try
    'End Function
End Class

