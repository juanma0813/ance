Imports System.Text.RegularExpressions

Module modGeneral

    Public Sub inactivar(ByVal ParamArray obj() As Object)
        For Each objetos As Object In obj
            objetos.enabled = False
        Next

    End Sub

    Public Sub Activar(ByVal ParamArray obj() As Object)
        For Each objetos As Object In obj
            objetos.enabled = True
        Next
    End Sub

    Public Sub Limpiar(ByVal ParamArray obj() As Object)
        For Each objetos As Object In obj
            objetos.Text = ""
        Next
    End Sub

    Public Sub Lectura(ByVal ParamArray obj() As Object)
        For Each objetos As Object In obj
            objetos.ReadOnly = True
        Next
    End Sub

    Public Sub Escritura(ByVal ParamArray obj() As Object)
        For Each objetos As Object In obj
            objetos.ReadOnly = False
        Next
    End Sub

    ''' <summary>
    ''' Funcion que valida campos en blanco, deben de contener por lo menos una letra
    ''' </summary>
    ''' <param name="obj">Campos de texto que se desean validar </param>
    ''' <returns>Regresa un arreglo de los objetos que no pasaron la prueba</returns>
    ''' <remarks></remarks>
    Public Function validarCampos(ByVal ParamArray obj() As Object) As Array
        Dim exReg As String = "[a-zA-Z]"
        Dim arrObj() As String
        Dim sObj As String

        For Each objetos As Object In obj
            If Not Regex.IsMatch(objetos.text, exReg) Then
                sObj = sObj + objetos.name + "|"
            End If
        Next

        If sObj <> "" Then
            sObj = sObj.Substring(0, sObj.Length - 1)
            arrObj = Split(sObj, "|")
        End If

        Return arrObj
    End Function

    ''' <summary>
    ''' Permite encontrar el nombre de un archivo en un path :. c:\documentos\docto.xls. 
    ''' </summary>
    ''' <param name="sArchivoRuta">Ruta donde se encuentra el archivo</param>
    ''' <returns>Regresa un arreglo de longitud 2 donde contiene el nombre del archivo (0) y su extencion (1)</returns>
    ''' <remarks></remarks>
    Public Function RutaArchCadena(ByVal sArchivoRuta As String) As Array
        Dim iIndice As Integer
        Dim sNombreArTem As String = ""
        Dim aText() As String
        Dim sExt As String

        'nombre archivo
        For iIndice = Len(sArchivoRuta) To 1 Step -1
            If Mid(sArchivoRuta, iIndice, 1) = "\" Then
                sNombreArTem = Mid(sArchivoRuta, iIndice + 1)
                iIndice = 1
            End If
        Next iIndice
        'para sacar la extencion del archivo

        aText = Split(sNombreArTem, ".")
        sExt = aText(UBound(aText))

        ReDim aText(1)
        aText(0) = sNombreArTem.Replace("." & sExt, "")
        aText(1) = "." & sExt

        Return aText
    End Function

End Module
