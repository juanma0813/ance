Imports System.Configuration

Public Class FrmSesionNotificacion
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTitulo As System.Windows.Forms.TextBox
    Friend WithEvents tlbBotones As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ilsBotonera As System.Windows.Forms.ImageList
    Friend WithEvents txtCuerpo As System.Windows.Forms.TextBox
    Friend WithEvents lstImagenes As System.Windows.Forms.ImageList
    Friend WithEvents cmdPegar As System.Windows.Forms.Button
    Friend WithEvents cmdCopiar As System.Windows.Forms.Button
    Friend WithEvents cmdHTML As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtNoSesion As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmSesionNotificacion))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtTitulo = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtCuerpo = New System.Windows.Forms.TextBox
        Me.tlbBotones = New System.Windows.Forms.ToolBar
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ilsBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.lstImagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.cmdPegar = New System.Windows.Forms.Button
        Me.cmdCopiar = New System.Windows.Forms.Button
        Me.cmdHTML = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txtNoSesion = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.txtTitulo)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(344, 56)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Titulo de Notificaci�n:"
        '
        'txtTitulo
        '
        Me.txtTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTitulo.Location = New System.Drawing.Point(8, 24)
        Me.txtTitulo.Name = "txtTitulo"
        Me.txtTitulo.Size = New System.Drawing.Size(328, 20)
        Me.txtTitulo.TabIndex = 1
        Me.txtTitulo.Text = ""
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.txtCuerpo)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 72)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(584, 312)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Contenido"
        '
        'txtCuerpo
        '
        Me.txtCuerpo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCuerpo.Location = New System.Drawing.Point(8, 16)
        Me.txtCuerpo.Multiline = True
        Me.txtCuerpo.Name = "txtCuerpo"
        Me.txtCuerpo.Size = New System.Drawing.Size(568, 288)
        Me.txtCuerpo.TabIndex = 0
        Me.txtCuerpo.Text = ""
        '
        'tlbBotones
        '
        Me.tlbBotones.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton5, Me.ToolBarButton4})
        Me.tlbBotones.ButtonSize = New System.Drawing.Size(60, 55)
        Me.tlbBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotones.DropDownArrows = True
        Me.tlbBotones.ImageList = Me.ilsBotonera
        Me.tlbBotones.Location = New System.Drawing.Point(0, 396)
        Me.tlbBotones.Name = "tlbBotones"
        Me.tlbBotones.ShowToolTips = True
        Me.tlbBotones.Size = New System.Drawing.Size(600, 61)
        Me.tlbBotones.TabIndex = 114
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 3
        Me.ToolBarButton5.Text = "Guardar"
        Me.ToolBarButton5.ToolTipText = "Guardar"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 7
        Me.ToolBarButton4.Text = "Enviar"
        Me.ToolBarButton4.ToolTipText = "Enviar"
        '
        'ilsBotonera
        '
        Me.ilsBotonera.ImageSize = New System.Drawing.Size(35, 35)
        Me.ilsBotonera.ImageStream = CType(resources.GetObject("ilsBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilsBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'lstImagenes
        '
        Me.lstImagenes.ImageSize = New System.Drawing.Size(20, 20)
        Me.lstImagenes.ImageStream = CType(resources.GetObject("lstImagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.lstImagenes.TransparentColor = System.Drawing.Color.Transparent
        '
        'cmdPegar
        '
        Me.cmdPegar.ImageIndex = 16
        Me.cmdPegar.ImageList = Me.lstImagenes
        Me.cmdPegar.Location = New System.Drawing.Point(560, 8)
        Me.cmdPegar.Name = "cmdPegar"
        Me.cmdPegar.Size = New System.Drawing.Size(28, 28)
        Me.cmdPegar.TabIndex = 116
        '
        'cmdCopiar
        '
        Me.cmdCopiar.ImageIndex = 15
        Me.cmdCopiar.ImageList = Me.lstImagenes
        Me.cmdCopiar.Location = New System.Drawing.Point(560, 40)
        Me.cmdCopiar.Name = "cmdCopiar"
        Me.cmdCopiar.Size = New System.Drawing.Size(28, 28)
        Me.cmdCopiar.TabIndex = 115
        '
        'cmdHTML
        '
        Me.cmdHTML.ImageIndex = 14
        Me.cmdHTML.ImageList = Me.lstImagenes
        Me.cmdHTML.Location = New System.Drawing.Point(528, 8)
        Me.cmdHTML.Name = "cmdHTML"
        Me.cmdHTML.Size = New System.Drawing.Size(28, 28)
        Me.cmdHTML.TabIndex = 117
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.txtNoSesion)
        Me.GroupBox3.Location = New System.Drawing.Point(360, 8)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(160, 56)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "No. Sesion:"
        '
        'txtNoSesion
        '
        Me.txtNoSesion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNoSesion.Location = New System.Drawing.Point(8, 24)
        Me.txtNoSesion.Name = "txtNoSesion"
        Me.txtNoSesion.Size = New System.Drawing.Size(144, 20)
        Me.txtNoSesion.TabIndex = 1
        Me.txtNoSesion.Text = ""
        '
        'FrmSesionNotificacion
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 457)
        Me.Controls.Add(Me.cmdHTML)
        Me.Controls.Add(Me.cmdPegar)
        Me.Controls.Add(Me.cmdCopiar)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tlbBotones)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "FrmSesionNotificacion"
        Me.Text = "..:: Notificaciones de sesiones ::.."
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _IdSesion As Integer
    Private _Sesion As String

    Private Enum eAccion As Integer
        Editar = 1
        Nuevo = 2
    End Enum

    Private IdAccion As eAccion

    Public Property IdSesion() As Integer
        Get
            Return _IdSesion
        End Get
        Set(ByVal Value As Integer)
            _IdSesion = Value
        End Set
    End Property

    Public Property Sesion() As String
        Get
            Return _Sesion
        End Get
        Set(ByVal Value As String)
            _Sesion = Value
        End Set
    End Property


    Private Sub FrmSesionNotificacion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sPagina As String
        sPagina = ConfigurationSettings.AppSettings.Get("ControlWeb")
        FillDatos()
    End Sub

    Private Sub tlbBotones_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotones.ButtonClick
        Select Case tlbBotones.Buttons.IndexOf(e.Button)
            Case 0 REM Guardar
                If IdAccion = eAccion.Nuevo Then GuardarContenido()
                If IdAccion = eAccion.Editar Then EditarContenido()
            Case 1
                EnviarCorreo()
        End Select

    End Sub

    Private Sub GuardarContenido()
        Dim objSesionesNotificaciones As New clsSesionesNotificaciones.AnceSystem.clssSesionesNotificaciones
        objSesionesNotificaciones.Bandera = "i1"
        objSesionesNotificaciones.Cuerpo = txtCuerpo.Text
        objSesionesNotificaciones.IdSesion = IdSesion
        objSesionesNotificaciones.Titulo = txtTitulo.Text
        objSesionesNotificaciones.Insertar()
        MsgBox("Contenido Agregado correctamente", MsgBoxStyle.Information)

        Activar(tlbBotones.Buttons(1))
    End Sub

    Private Sub EditarContenido()
        Dim objSesionesNotificaciones As New clsSesionesNotificaciones.AnceSystem.clssSesionesNotificaciones
        objSesionesNotificaciones.Bandera = "u2"
        objSesionesNotificaciones.Cuerpo = txtCuerpo.Text
        objSesionesNotificaciones.IdSesion = IdSesion
        objSesionesNotificaciones.Titulo = txtTitulo.Text
        objSesionesNotificaciones.Actualizar()
        MsgBox("Contenido Agregado correctamente", MsgBoxStyle.Information)
    End Sub

    Private Sub FillDatos()
        Dim objSesionesNotificaciones As New clsSesionesNotificaciones.AnceSystem.clssSesionesNotificaciones
        objSesionesNotificaciones.Bandera = "s2"
        objSesionesNotificaciones.IdSesion = IdSesion
        objSesionesNotificaciones.LlenarDatos()

        If objSesionesNotificaciones.Encontrado = True Then
            IdAccion = eAccion.Editar
            txtTitulo.Text = objSesionesNotificaciones.Titulo
            txtCuerpo.Text = objSesionesNotificaciones.Cuerpo
            Activar(tlbBotones.Buttons(1))
        Else
            IdAccion = eAccion.Nuevo
            inactivar(tlbBotones.Buttons(1))
        End If
    End Sub

    Private Sub EnviarCorreo()
        Dim lstParametros As New ArrayList
        Dim paramIdSesion As New Maple.entXml
        Dim paramSesion As New Maple.entXml

        paramIdSesion.Key = "IdSesion"
        paramIdSesion.Value = IdSesion

        paramSesion.Key = "Sesion"
        paramSesion.Value = txtNoSesion.Text

        lstParametros.Add(paramIdSesion)
        lstParametros.Add(paramSesion)

        Dim objCorreo As New clsCorreo.ClsCorreo
        objCorreo.XML = Maple.clssufnSQL.CrearXmlParamSql(lstParametros)
        objCorreo.Bandera = "s4"
        objCorreo.Subject = "NOTIFICACI�N A SESI�N " & txtNoSesion.Text
        objCorreo.sTo = "efren.tello@maplesistemas.com.mx"
        objCorreo.CorreoPersonalizado()

        MsgBox("Correo Enviado Correctamente", MsgBoxStyle.Information)
    End Sub

    Private Sub cmdPegar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPegar.Click
        txtCuerpo.Text = CType(Clipboard.GetDataObject().GetData(DataFormats.Text), String)
    End Sub

    Private Sub cmdCopiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCopiar.Click
        Clipboard.SetDataObject(txtCuerpo.Text)
    End Sub

    Private Sub cmdHTML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHTML.Click
        Dim frmControl As New frmComponenteWeb
        frmControl.ShowDialog()
    End Sub

End Class
