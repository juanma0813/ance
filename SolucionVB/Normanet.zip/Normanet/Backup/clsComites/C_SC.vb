
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_SC Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 07/08/2006 11:59:29 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class C_SC

     '''''''Declaracion de Variables Privadas
     Private dsC_SC AS New DataSet
     Private cn  AS New SQLConnection
     Private _ID_Comite as String
     Private _ID_CT as String
     Private _ID_SC as String
     Private _Descripcion as String
     Private _Objetivo as String
     Private _Responsable as String
     Private sSql as String

     '''''''Declaracion de Propiedades publicas
     Public Property ID_Comite()
          Get
              Return _ID_Comite
          End Get
          Set(ByVal Value)
              _ID_Comite = Value
          End Set
     End Property

     Public Property ID_CT()
          Get
              Return _ID_CT
          End Get
          Set(ByVal Value)
              _ID_CT = Value
          End Set
     End Property

     Public Property ID_SC()
          Get
              Return _ID_SC
          End Get
          Set(ByVal Value)
              _ID_SC = Value
          End Set
     End Property

     Public Property Descripcion()
          Get
              Return _Descripcion
          End Get
          Set(ByVal Value)
              _Descripcion = Value
          End Set
     End Property

     Public Property Objetivo()
          Get
              Return _Objetivo
          End Get
          Set(ByVal Value)
              _Objetivo = Value
          End Set
     End Property

     Public Property Responsable()
          Get
              Return _Responsable
          End Get
          Set(ByVal Value)
              _Responsable = Value
          End Set
     End Property


     Public Sub New () 
     End Sub

    ''''''''''''''''''Genera una la lista de campos
    'Public   Function ListaCombo() as DataTable
    '     Dim da as SqldataAdapter
    '     Dim dt as New DataTable("C_SC")
    '     Try
    '         da = New SqlDataAdapter(Sel, CadenaConexion)
    '         Da.Fill(dt)
    '     Catch
    '         Return Nothing
    '     End Try
    '     Return dt
    'End Function

     '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
     Public   Sub Buscar()
'***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
          sSql = "SELECT * FROM C_SC WHERE Campo_Llave = sClave
          Dim cmd As New SqlCommand(sSql, cn)
          Dim dr As SqlDatareader
          cn.Open()
          dr = cmd.ExecuteReader
          If dr.Read Then
              _ID_Comite = dr("ID_Comite")
              _ID_CT = dr("ID_CT")
              _ID_SC = dr("ID_SC")
              _Descripcion = dr("Descripcion")
              _Objetivo = dr("Objetivo")
              _Responsable = dr("Responsable")
          Else
              _ID_Comite = ""
              _ID_CT = ""
              _ID_SC = ""
              _Descripcion = ""
              _Objetivo = ""
              _Responsable = ""
          End If
          cn.Close()
     End Sub

     '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
     Public Function Actualizar() as String
          Dim cmd As New Sqlcommand("NOMBRE_STORE", cn)
          sSql ="UPDATE C_SC SET ID_Comite = @ID_Comite, ID_CT = @ID_CT, ID_SC = @ID_SC, Descripcion = @Descripcion, Objetivo = @Objetivo, Responsable = @Responsable, Where ( = @)"
          cmd.Parameters.Add("@ID_Comite", SqlDbType.NvarChar, 15, "_ID_Comite")
          cmd.Parameters.Add("@ID_CT", SqlDbType.NvarChar, 15, "_ID_CT")
          cmd.Parameters.Add("@ID_SC", SqlDbType.NvarChar, 15, "_ID_SC")
          cmd.Parameters.Add("@Descripcion", SqlDbType.NvarChar, 75, "_Descripcion")
          cmd.Parameters.Add("@Objetivo", SqlDbType.NvarChar, 90, "_Objetivo")
          cmd.Parameters.Add("@Responsable", SqlDbType.NvarChar, 15, "_Responsable")
          Try
              cmd.ExecuteNonQuery()
          Catch ex As Exception
              Return "ERROR: " & ex.Message
          End Try
     End Function
     
     
     Public Function Insertar() as String
          Dim cmd As New Sqlcommand("NOMBRE_STORE", cn)
          sSql ="INSERT INTO C_SC (ID_Comite, ID_CT, ID_SC, Descripcion, Objetivo)Responsable,  VALUES (@ID_Comite, @ID_CT, @ID_SC, @Descripcion, @Objetivo)@Responsable, "
          cmd.Parameters.Add("@ID_Comite", SqlDbType.NvarChar, 15, "_ID_Comite")
          cmd.Parameters.Add("@ID_CT", SqlDbType.NvarChar, 15, "_ID_CT")
          cmd.Parameters.Add("@ID_SC", SqlDbType.NvarChar, 15, "_ID_SC")
          cmd.Parameters.Add("@Descripcion", SqlDbType.NvarChar, 75, "_Descripcion")
          cmd.Parameters.Add("@Objetivo", SqlDbType.NvarChar, 90, "_Objetivo")
          cmd.Parameters.Add("@Responsable", SqlDbType.NvarChar, 15, "_Responsable")
          Try
              cmd.ExecuteNonQuery()
          Catch ex As Exception
              Return "ERROR: " & ex.Message
          End Try
     End Function
End Class
