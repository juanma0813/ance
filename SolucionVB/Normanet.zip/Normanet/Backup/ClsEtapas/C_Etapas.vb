
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase C_Etapas Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 10/01/2007 05:34:52 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class C_Etapas

     '''''''Declaracion de Variables Privadas
     Private dsC_Etapas AS New DataSet
     Private _ID_etapa as System.Int32
     Private _Etapa as System.String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property ID_etapa() As System.Int32
          Get
              Return _ID_etapa
          End Get
          Set(Value as System.Int32)
              _ID_etapa = Value
          End Set
     End Property

     Public Property Etapa() As System.String
          Get
              Return _Etapa
          End Get
          Set(Value as System.String)
              _Etapa = Value
          End Set
     End Property


     '''''''Define la cadena de Conexion a la Base de Datos
     Private  CadenaConexion as String = ""

   

     '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo() As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("C_Etapas")
        Try
            If cn.State = 1 Then cn.Close()
            cn.Open()
            da = New SqlDataAdapter("SELECT * FROM C_Etapas", cn)
            da.Fill(dt)
            cn.Close()
        Catch
            Return Nothing
        End Try
        Return dt
    End Function
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub
    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As String) As C_Etapas
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM C_Etapas WHERE Campo_Llave = sClave"
        Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da.Fill(dsC_Etapas, "C_Encontrado")
        cn.Close()
        If dsC_Etapas.Tables("C_Encontrado").Rows.Count > 0 Then
            _ID_etapa = dsC_Etapas.Tables("C_Encontrado").Rows(0).Item("ID_etapa")
            _Etapa = dsC_Etapas.Tables("C_Encontrado").Rows(0).Item("Etapa")
        Else
            _ID_etapa = ""
            _Etapa = ""
        End If
        dsC_Etapas.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal Sel As String) As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "UPDATE C_Etapas SET ID_etapa = @ID_etapa, Etapa = @Etapa, Where ( = @)"
        cmd.Parameters.Add("@ID_etapa", SqlDbType.Int, 0, "_ID_etapa")
        cmd.Parameters.Add("@Etapa", SqlDbType.NVarChar, 50, "_Etapa")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "INSERT INTO C_Etapas (ID_etapa)Etapa,  VALUES (@ID_etapa)@Etapa, "
        cmd.Parameters.Add("@ID_etapa", SqlDbType.Int, 0, "_ID_etapa")
        cmd.Parameters.Add("@Etapa", SqlDbType.NVarChar, 50, "_Etapa")
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class
