Public Class FrmReporteAsistencia
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdEliminar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cboLista As System.Windows.Forms.ComboBox
    Friend WithEvents cboGrupos As System.Windows.Forms.ComboBox
    Friend WithEvents optSinDato As System.Windows.Forms.RadioButton
    Friend WithEvents optComite As System.Windows.Forms.RadioButton
    Friend WithEvents optInstitucion As System.Windows.Forms.RadioButton
    Friend WithEvents lstDisponibles As System.Windows.Forms.ListView
    Friend WithEvents lstAgregados As System.Windows.Forms.ListView
    Friend WithEvents btnAgregar As System.Windows.Forms.Button
    Friend WithEvents btnQuitar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmReporteAsistencia))
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboLista = New System.Windows.Forms.ComboBox
        Me.cboGrupos = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.optSinDato = New System.Windows.Forms.RadioButton
        Me.optComite = New System.Windows.Forms.RadioButton
        Me.optInstitucion = New System.Windows.Forms.RadioButton
        Me.btnAgregar = New System.Windows.Forms.Button
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.btnQuitar = New System.Windows.Forms.Button
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdEliminar = New System.Windows.Forms.ToolBarButton
        Me.lstDisponibles = New System.Windows.Forms.ListView
        Me.lstAgregados = New System.Windows.Forms.ListView
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Lista:"
        '
        'cboLista
        '
        Me.cboLista.Location = New System.Drawing.Point(64, 16)
        Me.cboLista.Name = "cboLista"
        Me.cboLista.Size = New System.Drawing.Size(480, 21)
        Me.cboLista.TabIndex = 2
        '
        'cboGrupos
        '
        Me.cboGrupos.Location = New System.Drawing.Point(64, 40)
        Me.cboGrupos.Name = "cboGrupos"
        Me.cboGrupos.Size = New System.Drawing.Size(480, 21)
        Me.cboGrupos.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Grupos:"
        '
        'optSinDato
        '
        Me.optSinDato.Checked = True
        Me.optSinDato.Location = New System.Drawing.Point(24, 64)
        Me.optSinDato.Name = "optSinDato"
        Me.optSinDato.Size = New System.Drawing.Size(80, 24)
        Me.optSinDato.TabIndex = 5
        Me.optSinDato.TabStop = True
        Me.optSinDato.Text = "Sin Dato"
        '
        'optComite
        '
        Me.optComite.Location = New System.Drawing.Point(248, 64)
        Me.optComite.Name = "optComite"
        Me.optComite.Size = New System.Drawing.Size(72, 24)
        Me.optComite.TabIndex = 6
        Me.optComite.Text = "Comit�"
        '
        'optInstitucion
        '
        Me.optInstitucion.Location = New System.Drawing.Point(456, 64)
        Me.optInstitucion.Name = "optInstitucion"
        Me.optInstitucion.Size = New System.Drawing.Size(80, 24)
        Me.optInstitucion.TabIndex = 7
        Me.optInstitucion.Text = "Instituci�n"
        '
        'btnAgregar
        '
        Me.btnAgregar.ImageIndex = 17
        Me.btnAgregar.ImageList = Me.ImgListBotonera
        Me.btnAgregar.Location = New System.Drawing.Point(264, 184)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(24, 24)
        Me.btnAgregar.TabIndex = 9
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'btnQuitar
        '
        Me.btnQuitar.ImageIndex = 16
        Me.btnQuitar.ImageList = Me.ImgListBotonera
        Me.btnQuitar.Location = New System.Drawing.Point(264, 216)
        Me.btnQuitar.Name = "btnQuitar"
        Me.btnQuitar.Size = New System.Drawing.Size(24, 24)
        Me.btnQuitar.TabIndex = 10
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdEliminar})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 403)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(552, 62)
        Me.tlbBotonera.TabIndex = 38
        '
        'cmdEliminar
        '
        Me.cmdEliminar.ImageIndex = 15
        Me.cmdEliminar.Text = "Niveles"
        Me.cmdEliminar.ToolTipText = "Niveles"
        '
        'lstDisponibles
        '
        Me.lstDisponibles.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstDisponibles.FullRowSelect = True
        Me.lstDisponibles.GridLines = True
        Me.lstDisponibles.HideSelection = False
        Me.lstDisponibles.Location = New System.Drawing.Point(16, 96)
        Me.lstDisponibles.Name = "lstDisponibles"
        Me.lstDisponibles.Size = New System.Drawing.Size(240, 296)
        Me.lstDisponibles.TabIndex = 39
        '
        'lstAgregados
        '
        Me.lstAgregados.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstAgregados.FullRowSelect = True
        Me.lstAgregados.GridLines = True
        Me.lstAgregados.HideSelection = False
        Me.lstAgregados.Location = New System.Drawing.Point(304, 96)
        Me.lstAgregados.Name = "lstAgregados"
        Me.lstAgregados.Size = New System.Drawing.Size(240, 296)
        Me.lstAgregados.TabIndex = 40
        '
        'FrmReporteAsistencia
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(552, 465)
        Me.Controls.Add(Me.lstAgregados)
        Me.Controls.Add(Me.lstDisponibles)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.btnQuitar)
        Me.Controls.Add(Me.btnAgregar)
        Me.Controls.Add(Me.optInstitucion)
        Me.Controls.Add(Me.optComite)
        Me.Controls.Add(Me.optSinDato)
        Me.Controls.Add(Me.cboGrupos)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cboLista)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmReporteAsistencia"
        Me.Text = "..:: Configurar Reporte Asistencia ::.."
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FrmReporteAsistencia_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FillListas(cboLista)
        FillGrupos(cboGrupos, cboLista.SelectedValue)
        FillCargosDisponibles()
        FillCargosAgregados()
    End Sub

    Private Sub FillListas(ByVal cbo As ComboBox)
        Dim objListas As New clsListasAsistencia.AnceSystem.clssListasAsistencia
        Dim dt As DataTable
        objListas.Bandera = "s2"
        dt = objListas.Listar()

        cbo.DataSource = dt

        cbo.DisplayMember = "Descripcion"
        cbo.ValueMember = "IdListaAsistencia"
    End Sub

    Private Sub FillGrupos(ByVal cbo As ComboBox, ByVal IdGrupoListaAsistencia As Integer)
        Dim dt As DataTable
        Dim objGruposListas As New clsGruposListasAsistencia.AnceSystem.clssGruposListasAsistencia

        objGruposListas.IdGrupoListaAsistencia = IdGrupoListaAsistencia
        objGruposListas.Bandera = "s2"
        dt = objGruposListas.Listar

        cbo.DataSource = dt

        cbo.DisplayMember = "GrupoListaAsistencia"
        cbo.ValueMember = "IdGrupoListaAsistencia"
    End Sub

    Private Sub cboLista_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboLista.SelectionChangeCommitted
        FillGrupos(cboGrupos, sender.selectedValue)
        FillCargosDisponibles()
        FillCargosAgregados()
    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Dim GruposNivelesListas As New frmGruposNivelesListas
        GruposNivelesListas.MdiParent = Me.MdiParent
        GruposNivelesListas.Show()
    End Sub


    Private Sub FillCargosDisponibles()
        Dim objCargos As New clsCargos.C_Cargos("Principal", gUsuario, gPasswordSql)
        Dim dt As DataTable
        Dim Item As DataRow
        Dim ItemGrupo As New ItemGrupo
        Dim lstParam As New ArrayList

        Dim ParamIdListaAsistencia As New Maple.entXml
        Dim ParamGrupoListaAsistencia As New Maple.entXml

        ParamIdListaAsistencia.Key = "IdListaAsistencia"
        ParamIdListaAsistencia.Value = cboLista.SelectedValue

        ParamGrupoListaAsistencia.Key = "IdGrupoListaAsistencia"
        ParamGrupoListaAsistencia.Value = cboGrupos.SelectedValue

        lstParam.Add(ParamIdListaAsistencia)
        lstParam.Add(ParamGrupoListaAsistencia)

        objCargos.Bandera = 13
        objCargos.sXml = Maple.clssufnSQL.CrearXmlParamSql(lstParam)
        dt = objCargos.Listar()

        lstDisponibles.Items.Clear()
        lstDisponibles.Columns.Clear()

        lstDisponibles.View = View.Details
        lstDisponibles.GridLines = True
        lstDisponibles.Columns.Add("ID_Cargo", 0, HorizontalAlignment.Center)
        lstDisponibles.Columns.Add("Descripcion", 190, HorizontalAlignment.Left)

        For Each Item In dt.Rows
            lstDisponibles.Items.Add(New ListViewItem(New String() {Item("ID_Cargo"), Item("Descripcion")}))
        Next
    End Sub

    Private Sub FillCargosAgregados()
        Dim objCargos As New clsCargos.C_Cargos("Principal", gUsuario, gPasswordSql)
        Dim dt As DataTable
        Dim Item As DataRow
        Dim ItemGrupo As New ItemGrupo
        Dim lstParam As New ArrayList

        Dim ParamIdListaAsistencia As New Maple.entXml
        Dim ParamGrupoListaAsistencia As New Maple.entXml

        ParamIdListaAsistencia.Key = "IdListaAsistencia"
        ParamIdListaAsistencia.Value = cboLista.SelectedValue

        ParamGrupoListaAsistencia.Key = "IdGrupoListaAsistencia"
        ParamGrupoListaAsistencia.Value = cboGrupos.SelectedValue

        lstParam.Add(ParamIdListaAsistencia)
        lstParam.Add(ParamGrupoListaAsistencia)

        objCargos.Bandera = 14
        objCargos.sXml = Maple.clssufnSQL.CrearXmlParamSql(lstParam)
        dt = objCargos.Listar()

        lstAgregados.Items.Clear()
        lstAgregados.Columns.Clear()

        lstAgregados.View = View.Details
        lstAgregados.GridLines = True
        lstAgregados.Columns.Add("IdGrupoListaAsistenciaRelacion", 0, HorizontalAlignment.Center)
        lstAgregados.Columns.Add("Descripcion", 160, HorizontalAlignment.Left)
        lstAgregados.Columns.Add("Tipo", 70, HorizontalAlignment.Left)


        For Each Item In dt.Rows
            lstAgregados.Items.Add(New ListViewItem(New String() {Item("IdGrupoListaAsistenciaRelacion"), Item("Descripcion"), Item("ListaTipoInformacion")}))
        Next
    End Sub

    Private Sub cboGrupos_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGrupos.SelectionChangeCommitted
        FillCargosDisponibles()
        FillCargosAgregados()
    End Sub

    Private Sub btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregar.Click
        If lstDisponibles.SelectedItems.Count > 0 Then AgregarCargoGrupo(lstDisponibles.SelectedItems(0).Text)
    End Sub

    Private Sub AgregarCargoGrupo(ByVal IdCargo)
        Dim objGruposListasAsistenciaRelacion As New clsGruposListasAsistenciaRelacion.AnceSystem.clssGruposListasAsistenciaRelacion
        With objGruposListasAsistenciaRelacion
            .Bandera = "i1"
            .IdCargo = IdCargo
            .IdListaAsistencia = cboLista.SelectedValue
            .IdGrupoListaAsistencia = cboGrupos.SelectedValue
            If optSinDato.Checked Then .IdListaTipoInformacion = 1
            If optComite.Checked Then .IdListaTipoInformacion = 2
            If optInstitucion.Checked Then .IdListaTipoInformacion = 3
            .Insertar()

            FillCargosDisponibles()
            FillCargosAgregados()
        End With
    End Sub

    Private Sub btnQuitar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitar.Click
        If lstAgregados.SelectedItems.Count > 0 Then QuitarCargosGrupo(lstAgregados.SelectedItems(0).Text)
    End Sub

    Private Sub QuitarCargosGrupo(ByVal IdGrupoListaAsistenciaRelacion)
        Dim objGruposListasAsistenciaRelacion As New clsGruposListasAsistenciaRelacion.AnceSystem.clssGruposListasAsistenciaRelacion
        With objGruposListasAsistenciaRelacion
            .Bandera = "d1"
            .IdGrupoListaAsistenciaRelacion = IdGrupoListaAsistenciaRelacion
            .Eliminar()

            FillCargosDisponibles()
            FillCargosAgregados()
        End With
    End Sub

End Class
