Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Namespace Maple
    Public Class clsProyectosWeb

        Private _Bandera As String
        Private _respRetorno(1) As String
        Private _Referencia As String
        Private _ID_Tipo_Norma As String
        Private _Busqueda As String
        Private _idPlan As String
        Private _id_comite As String
        Private _pertenece As String
        Private _parametroBusqueda As String
        Private _Id_Etapa As Integer

        Private cn As SqlConnection


        ''' <summary>
        '''Se utiliza para pasarle la bandera a un store procedure
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Bandera() As String
            Get
                Return _Bandera
            End Get
            Set(ByVal Value As String)
                _Bandera = Value
            End Set
        End Property

        Public Property Referencia() As String
            Get
                Return _Referencia
            End Get
            Set(ByVal Value As String)
                _Referencia = Value
            End Set
        End Property

        Public Property ID_Tipo_Norma() As String
            Get
                Return _ID_Tipo_Norma
            End Get
            Set(ByVal Value As String)
                _ID_Tipo_Norma = Value
            End Set
        End Property

        Public Property Busqueda() As String
            Get
                Return _Busqueda
            End Get
            Set(ByVal Value As String)
                _Busqueda = Value
            End Set
        End Property

        Public Property idPlan() As String
            Get
                Return _idPlan
            End Get
            Set(ByVal Value As String)
                _idPlan = Value
            End Set
        End Property

        Public Property id_comite() As String
            Get
                Return _id_comite
            End Get
            Set(ByVal Value As String)
                _id_comite = Value
            End Set
        End Property

        Public Property pertenece() As String
            Get
                Return _pertenece
            End Get
            Set(ByVal Value As String)
                _pertenece = Value
            End Set
        End Property

        Public Property parametroBusqueda() As String
            Get
                Return _parametroBusqueda
            End Get
            Set(ByVal Value As String)
                _parametroBusqueda = Value
            End Set
        End Property

        Public Property Id_Etapa() As Integer
            Get
                Return _Id_Etapa
            End Get
            Set(ByVal Value As Integer)
                _Id_Etapa = Value
            End Set
        End Property


        ''' <summary>
        '''propiedad de tipo arreglo de longitud 2. la posicion 1 contiene el error en caso de fallar :: la posicion 0 Contiene un (1 o 0), 1 indica que el metodo fallo, y 0 indica que funciono
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Property respRetorno() As Array
            Get
                Return _respRetorno
            End Get
        End Property

        ''' <summary>
        '''Contructor de la clase
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            cn = New SqlConnection(ConfigurationSettings.AppSettings("Ance"))
        End Sub

        REM Funcion que Lista datos
        ''' <summary>
        '''Metodo que regresa un datatable o un query de Linq
        ''' </summary>
        ''' <remarks></remarks>
        Public Function Listar() As DataTable
            Dim dt As New DataTable("Encontrados")

            Try
                _respRetorno(0) = ""
                _respRetorno(1) = CStr(0)

                cn.Open()
                Dim cmd As New SqlCommand
                cmd.CommandText = "uspConsultasWeb"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Connection = cn
                cmd.Parameters.Add("@Bandera", _Bandera)
                cmd.Parameters.Add("@Referencia", _Referencia)
                cmd.Parameters.Add("@ID_Tipo_Norma", _ID_Tipo_Norma)
                cmd.Parameters.Add("@Busqueda", _Busqueda)
                cmd.Parameters.Add("@idPlan", _idPlan)
                cmd.Parameters.Add("@id_comite", _id_comite)
                cmd.Parameters.Add("@pertenece", pertenece)
                cmd.Parameters.Add("@parametroBusqueda", parametroBusqueda)
                cmd.Parameters.Add("@Id_Etapa", _Id_Etapa)

                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                '_idPlan = cmd.Parameters.Add("@Plan", SqlDbType.VarChar, 100).Value
                da.Dispose()
                cmd.Dispose()

            Catch ex As Exception
                _respRetorno(0) = ex.Message
                _respRetorno(1) = CStr(1)
            Finally
                cn.Close()
            End Try
            Return dt
        End Function

    End Class
End Namespace

