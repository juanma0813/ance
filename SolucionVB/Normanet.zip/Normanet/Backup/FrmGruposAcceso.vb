Public Class FrmGruposAcceso
    Inherits System.Windows.Forms.Form


    Private objConexion As New clsConexion.cIsConexion
    Private clsAdmonGrupos As New clsAdmonGrupos.ClsadmonGrupos(Application.StartupPath + "\Principal.ini", "COMUN", gUsuario, gPasswordSql)
    Private dtgrupos As DataTable
    Private Menus As DataTable
    Dim ibandera As Boolean
    Dim setapa As String

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbogrupo As System.Windows.Forms.ComboBox
    Friend WithEvents txtgrupo As System.Windows.Forms.TextBox
    Friend WithEvents GrdMenus As System.Windows.Forms.DataGrid
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Cmdeditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalvar As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImgListBotonera As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FrmGruposAcceso))
        Me.Label1 = New System.Windows.Forms.Label
        Me.cbogrupo = New System.Windows.Forms.ComboBox
        Me.txtgrupo = New System.Windows.Forms.TextBox
        Me.GrdMenus = New System.Windows.Forms.DataGrid
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.Cmdeditar = New System.Windows.Forms.ToolBarButton
        Me.CmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.CmdSalvar = New System.Windows.Forms.ToolBarButton
        Me.CmdSalir = New System.Windows.Forms.ToolBarButton
        Me.ImgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.GrdMenus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Grupo"
        '
        'cbogrupo
        '
        Me.cbogrupo.Location = New System.Drawing.Point(112, 16)
        Me.cbogrupo.Name = "cbogrupo"
        Me.cbogrupo.Size = New System.Drawing.Size(256, 21)
        Me.cbogrupo.TabIndex = 1
        '
        'txtgrupo
        '
        Me.txtgrupo.Location = New System.Drawing.Point(112, 16)
        Me.txtgrupo.Name = "txtgrupo"
        Me.txtgrupo.Size = New System.Drawing.Size(240, 20)
        Me.txtgrupo.TabIndex = 2
        Me.txtgrupo.Text = ""
        '
        'GrdMenus
        '
        Me.GrdMenus.CaptionText = "Accesos para el grupo"
        Me.GrdMenus.DataMember = ""
        Me.GrdMenus.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.GrdMenus.Location = New System.Drawing.Point(32, 56)
        Me.GrdMenus.Name = "GrdMenus"
        Me.GrdMenus.Size = New System.Drawing.Size(416, 480)
        Me.GrdMenus.TabIndex = 3
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdAgregar, Me.Cmdeditar, Me.CmdDeshacer, Me.CmdSalvar, Me.CmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.ImageList = Me.ImgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 552)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(472, 62)
        Me.tlbBotonera.TabIndex = 10
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Text = "Agregar"
        Me.cmdAgregar.ToolTipText = "Se agregan las noticias"
        '
        'Cmdeditar
        '
        Me.Cmdeditar.ImageIndex = 1
        Me.Cmdeditar.Text = "Editar"
        '
        'CmdDeshacer
        '
        Me.CmdDeshacer.ImageIndex = 3
        Me.CmdDeshacer.Text = "Deshacer"
        '
        'CmdSalvar
        '
        Me.CmdSalvar.ImageIndex = 2
        Me.CmdSalvar.Text = "Salvar"
        '
        'CmdSalir
        '
        Me.CmdSalir.ImageIndex = 4
        Me.CmdSalir.Text = "Salir"
        '
        'ImgListBotonera
        '
        Me.ImgListBotonera.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.ImgListBotonera.ImageStream = CType(resources.GetObject("ImgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgListBotonera.TransparentColor = System.Drawing.Color.White
        '
        'FrmGruposAcceso
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(472, 614)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.GrdMenus)
        Me.Controls.Add(Me.cbogrupo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtgrupo)
        Me.Name = "FrmGruposAcceso"
        Me.Text = "FrmGruposAcceso"
        CType(Me.GrdMenus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FrmGruposAcceso_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ibandera = False
        clsAdmonGrupos.Id_usuario = gUsuario
        dtgrupos = clsAdmonGrupos.ListaCombo()
        cbogrupo.DataSource = dtgrupos
        cbogrupo.DisplayMember = dtgrupos.Columns(2).ColumnName
        cbogrupo.ValueMember = dtgrupos.Columns(1).ColumnName
        ibandera = 1
        setapa = "Nulo"
        Call Habilita(setapa)

    End Sub


    Private Sub cbogrupo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbogrupo.SelectedIndexChanged
        Dim Grupo As Integer
        If ibandera = True Then
            Grupo = 0
            Grupo = cbogrupo.SelectedValue
            clsAdmonGrupos.Id_grupo = Grupo
            clsAdmonGrupos.Id_usuario = gUsuario
            clsAdmonGrupos.Bandera = 3
            dtgrupos = clsAdmonGrupos.Buscar()
            GrdMenus.DataSource = dtgrupos
            'DGStyTemasPT()
        End If

    End Sub

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 0 'Agregar

                setapa = "Agregar"
                Call Habilita(setapa)
                clsAdmonGrupos.Bandera = 4
                dtgrupos = clsAdmonGrupos.Buscar()
                Dim column As DataColumn = New DataColumn("Acceso")
                column.DataType = System.Type.GetType("boolean")
                Dim chkcolum As New DataGridBoolColumn

                dtgrupos.Columns.Add(column)


                'dtgrupos.Columns.Add("Acceso")
                GrdMenus.DataSource = dtgrupos



                'DGStyTemasPT()
                'Dim cm As CurrencyManager = CType(Me.BindingContext(Me.GrdMenus.DataSource, Me.GrdMenus.DataMember), CurrencyManager)
                'CType(cm.List, DataView).AllowNew = False


            Case 1 'Editar
                setapa = "Editar"
                Call Habilita(setapa)

            Case 2 'Deshacer
                setapa = "Nulo"
                Call Habilita(setapa)

            Case 3 'Salvar

                If setapa = "Editar" Then
                    'Call Actualizar()
                    setapa = "Nulo"
                    Call Habilita(setapa)
                    ibandera = True
                Else
                    'Call Insertar()
                    setapa = "Nulo"
                    Call Habilita(setapa)
                    ibandera = True
                End If
            Case 4
                MsgBox("Esta seguro de Borrar esta Grupo?", MsgBoxStyle.OKCancel, "Atenci�n")
                If MsgBoxResult.OK Then
                    'Call Borrar()
                End If
            Case 5
                Me.Dispose()
        End Select
    End Sub
    Private Sub Habilita(ByVal sEtapa As String)
        Select Case sEtapa
            Case "Nulo"
                Call Activos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))


                Call Inactivos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
            Case "Agregar"
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Oculta(cbogrupo)
                Muestra(txtgrupo)
            Case "Editar"
                Call Inactivos(tlbBotonera.Buttons.Item(0), tlbBotonera.Buttons.Item(1), tlbBotonera.Buttons.Item(4))
                Call Activos(tlbBotonera.Buttons.Item(2), tlbBotonera.Buttons.Item(3))

        End Select
    End Sub
    Private Sub DGStyTemasPT()
        Dim dtcol As DataColumn = Nothing
        Try
            GrdMenus.TableStyles.Clear()

            Dim ts1 As DataGridTableStyle
            ts1 = New DataGridTableStyle
            Call Tabla_Color(ts1, GrdMenus)


            ts1.MappingName = "clsMenus"
            Dim TextCol As New DataGridTextBoxColumn
            TextCol.MappingName = "Id_Menu"
            TextCol.HeaderText = "Men�"
            TextCol.Width = 150
            TextCol.TextBox.Enabled = False
            ts1.GridColumnStyles.Add(TextCol)

            Dim chkcolum As New DataGridBoolColumn
            chkcolum.MappingName = "Acceso"
            chkcolum.HeaderText = "Acceso"
            chkcolum.Width = 60
            chkcolum.NullValue = False
            chkcolum.TrueValue = 1
            chkcolum.FalseValue = 0


            ts1.GridColumnStyles.Add(chkcolum)


            GrdMenus.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("ERROR - " + ex.Source + " " + ex.Message)
        End Try
    End Sub

    Private Sub GrdMenus_Navigate(ByVal sender As System.Object, ByVal ne As System.Windows.Forms.NavigateEventArgs) Handles GrdMenus.Navigate

    End Sub
End Class
