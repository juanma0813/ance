
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Traspasos_TemasPNN Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 23/11/2006 10:53:16 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Traspasos_TemasPNN

     '''''''Declaracion de Variables Privadas
     Private dsP_Traspasos_TemasPNN AS New DataSet
     Private _id_Plan as System.String
     Private _Id_tema as System.Int32
     Private _Fecha_Traspaso as System.DateTime
     Private _Id_Usuario_Traspaso as System.String
     Private _Id_plan_destino as System.String
     Private _Id_Tema_destino as System.Int32
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo

     '''''''Declaracion de Propiedades publicas
     Public Property id_Plan() As System.String
          Get
              Return _id_Plan
          End Get
          Set(Value as System.String)
              _id_Plan = Value
          End Set
     End Property

     Public Property Id_tema() As System.Int32
          Get
              Return _Id_tema
          End Get
          Set(Value as System.Int32)
              _Id_tema = Value
          End Set
     End Property

     Public Property Fecha_Traspaso() As System.DateTime
          Get
              Return _Fecha_Traspaso
          End Get
          Set(Value as System.DateTime)
              _Fecha_Traspaso = Value
          End Set
     End Property

     Public Property Id_Usuario_Traspaso() As System.String
          Get
              Return _Id_Usuario_Traspaso
          End Get
          Set(Value as System.String)
              _Id_Usuario_Traspaso = Value
          End Set
     End Property

     Public Property Id_plan_destino() As System.String
          Get
              Return _Id_plan_destino
          End Get
          Set(Value as System.String)
              _Id_plan_destino = Value
          End Set
     End Property

     Public Property Id_Tema_destino() As System.Int32
          Get
              Return _Id_Tema_destino
          End Get
          Set(Value as System.Int32)
              _Id_Tema_destino = Value
          End Set
     End Property


     '''''''Define la cadena de Conexion a la Base de Datos
     Private  CadenaConexion as String = ""
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub
    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Traspasos_TemasPNN")
        Try
            da = New SqlDataAdapter(Sel, cn)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sClave As String) As P_Traspasos_TemasPNN
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Traspasos_TemasPNN WHERE Campo_Llave = sClave"
        Dim da As New SqlDataAdapter(sSql, cn)
        cn.Open()
        da.Fill(dsP_Traspasos_TemasPNN, "C_Encontrado")
        cn.Close()
        If dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows.Count > 0 Then
            _id_Plan = dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows(0).Item("id_Plan")
            _Id_tema = dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows(0).Item("Id_tema")
            _Fecha_Traspaso = dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows(0).Item("Fecha_Traspaso")
            _Id_Usuario_Traspaso = dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows(0).Item("Id_Usuario_Traspaso")
            _Id_plan_destino = dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows(0).Item("Id_plan_destino")
            _Id_Tema_destino = dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Rows(0).Item("Id_Tema_destino")
        Else
            _id_Plan = ""
            _Id_tema = ""
            _Fecha_Traspaso = ""
            _Id_Usuario_Traspaso = ""
            _Id_plan_destino = ""
            _Id_Tema_destino = ""
        End If
        dsP_Traspasos_TemasPNN.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza(ByVal Splan As String, ByVal id_tema As Integer, ByVal id_usuario As String, ByVal id_plan_destino As String, ByVal id_temadestino As String) As String

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Traspaso_TemasPNN"
        cmd.Parameters.Add("@id_Plan", Splan)
        cmd.Parameters.Add("@Id_tema", id_tema)
        cmd.Parameters.Add("@Fecha_Traspaso", Format(Now.Date, "dd/MM/yyyy"))
        cmd.Parameters.Add("@Id_Usuario_Traspaso", id_usuario)
        cmd.Parameters.Add("@Id_plan_destino", id_plan_destino)
        cmd.Parameters.Add("@Id_Tema_destino", id_temadestino)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Insertar() As String
        Dim cmd As New SqlCommand("NOMBRE_STORE", cn)
        sSql = "INSERT INTO P_Traspasos_TemasPNN (id_Plan, Id_tema, Fecha_Traspaso, Id_Usuario_Traspaso, Id_plan_destino)Id_Tema_destino,  VALUES (@id_Plan, @Id_tema, @Fecha_Traspaso, @Id_Usuario_Traspaso, @Id_plan_destino)@Id_Tema_destino, "
        cmd.Parameters.Add("@id_Plan", SqlDbType.NVarChar, 20, "_id_Plan")
        cmd.Parameters.Add("@Id_tema", SqlDbType.Int, 0, "_Id_tema")
        cmd.Parameters.Add("@Fecha_Traspaso", SqlDbType.DateTime, 0, "_Fecha_Traspaso")
        cmd.Parameters.Add("@Id_Usuario_Traspaso", SqlDbType.NVarChar, 50, "_Id_Usuario_Traspaso")
        cmd.Parameters.Add("@Id_plan_destino", SqlDbType.NVarChar, 20, "_Id_plan_destino")
        cmd.Parameters.Add("@Id_Tema_destino", SqlDbType.Int, 0, "_Id_Tema_destino")
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    'HDLCASIO TRASPASO COMPLETO DE TEMA DESDE SQL
    Public Function TraspasoTema(ByVal sRefOrigen As String, ByVal dFechaIni As Date, ByVal dFechaFin As Date, ByVal iTipoTema As Integer) As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        cmd.CommandText = "paTraspasoTema"
        cmd.Parameters.Add("@sBandera", "i1")
        cmd.Parameters.Add("@sRefOrigen", sRefOrigen)
        cmd.Parameters.Add("@sIdPlanOrigen", _id_Plan)
        cmd.Parameters.Add("@iIdTemaOrigen", _Id_tema)
        cmd.Parameters.Add("@sIdPlanDestino", _Id_plan_destino)
        cmd.Parameters.Add("@iIdTemaDestino", _Id_Tema_destino)
        cmd.Parameters.Add("@dFechaIni", dFechaIni)
        cmd.Parameters.Add("@dFechaFin", dFechaFin)
        cmd.Parameters.Add("@iIdTipoTema", iTipoTema)
        cmd.Parameters.Add("@MsgError", SqlDbType.VarChar, 8000).Direction = ParameterDirection.Output

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
            Return cmd.Parameters("@MsgError").Value
        Catch ex As Exception
            Return ex.Message
        End Try
    End Function

End Class
