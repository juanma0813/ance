Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class Frmc_cargosnivel
    Inherits System.Windows.Forms.Form

#Region " Inicializaci�n de Dll's, Metodos y Procesos "

    Dim objCargos As New clsCargos.C_Cargos("Principal", gUsuario, gPasswordSql)


#End Region

#Region " Inicializaci�n de Variabes, Metodos y Procesos "

    Dim dtcarniv As New DataTable
    Dim sTipoProceso As String
    Dim Svaloritem As String

#End Region

#Region " Metodos y Procesos "

#Region " Funci�n - Guardar(), Metodos y Procesos "

    Private Function Guardar() As Boolean
        Dim dr As DataRow
        Dim iconta As Integer
        objCargos.Bandera = 4
        iconta = 0
        For Each dr In dtcarniv.Rows
            iconta = iconta + 1
            objCargos.Dependencia = iconta
            objCargos.Descripcion = dr(1)
            objCargos.Actualizar()
        Next
    End Function

#End Region

#Region " Funci�n - Ordenarb(lugar), Metodos y Procesos "

    Private Function Ordenarb(ByVal lugar As Integer) As DataTable
        Dim dr1, dr2 As DataRow
        Dim pos1, id2, iant As Integer
        Dim valor As String
        For Each dr1 In dtcarniv.Rows
            If iant = Nothing Then iant = dr1(0)
            If dr1(1) = Svaloritem Then
                pos1 = dr1(0)
                iant = id2
                Exit For
            End If
            id2 = dr1(0)
        Next
        id2 = 0
        For Each dr1 In dtcarniv.Rows
            If dr1(0) = iant Then
                valor = dr1(1)
                dr1(1) = Svaloritem
                id2 = 1
            End If
            If dr1(0) = pos1 And id2 <> 1 Then dr1(1) = valor
            id2 = 0
        Next
        Dim cm As CurrencyManager
        Dim Dv As DataView = (dtcarniv.DefaultView)
        Dv.Sort = Dv.Table.Columns(2).ColumnName + " ASC"
        Dv.RowStateFilter = DataViewRowState.ModifiedCurrent

    End Function

#End Region

#Region " Funci�n - Ordenaba(lugar), Metodos y Procesos "

    Private Function Ordenaba(ByVal lugar As Integer) As DataTable
        Dim dr1, dr2 As DataRow
        Dim pos1, id2, iant As Integer
        Dim valor As String
        Dim band1 As Boolean = False
        Dim band2 As Boolean = False
        id2 = 0
        'si entra a la primera entonces es el primer elemento 
        For Each dr1 In dtcarniv.Rows
            If dr1.Item(1) = Svaloritem Then
                iant = dr1.Item(0)
                id2 = 1
                valor = dr1.Item(1)
            End If
            If dr1.Item(0) > iant And id2 = 1 Then
                valor = dr1.Item(1)
                dr1.Item(1) = Svaloritem
                id2 = 0
                Exit For
            End If
        Next
        For Each dr1 In dtcarniv.Rows
            If dr1.Item(0) = iant Then
                dr1.Item(1) = valor
                Exit For
            End If
        Next
        Dim cm As CurrencyManager
        Dim Dv As DataView = (dtcarniv.DefaultView)
        Dv.Sort = Dv.Table.Columns(2).ColumnName + " ASC"
        Dv.RowStateFilter = DataViewRowState.ModifiedCurrent

    End Function

#End Region

#End Region

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents imgListBotonera As System.Windows.Forms.ImageList
    Friend WithEvents tlbBotonera As System.Windows.Forms.ToolBar
    Friend WithEvents Separador1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdAgregar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdEditar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdDeshacer As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdGuardar As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdBorrar As System.Windows.Forms.ToolBarButton
    Friend WithEvents Separador2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSalir As System.Windows.Forms.ToolBarButton
    Friend WithEvents CmdAbajo As System.Windows.Forms.Button
    Friend WithEvents CmdArriba As System.Windows.Forms.Button
    Friend WithEvents LtBxCargos As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Frmc_cargosnivel))
        Me.imgListBotonera = New System.Windows.Forms.ImageList(Me.components)
        Me.CmdArriba = New System.Windows.Forms.Button
        Me.CmdAbajo = New System.Windows.Forms.Button
        Me.tlbBotonera = New System.Windows.Forms.ToolBar
        Me.Separador1 = New System.Windows.Forms.ToolBarButton
        Me.cmdAgregar = New System.Windows.Forms.ToolBarButton
        Me.cmdEditar = New System.Windows.Forms.ToolBarButton
        Me.cmdDeshacer = New System.Windows.Forms.ToolBarButton
        Me.cmdGuardar = New System.Windows.Forms.ToolBarButton
        Me.cmdBorrar = New System.Windows.Forms.ToolBarButton
        Me.Separador2 = New System.Windows.Forms.ToolBarButton
        Me.cmdSalir = New System.Windows.Forms.ToolBarButton
        Me.LtBxCargos = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'imgListBotonera
        '
        Me.imgListBotonera.ImageSize = New System.Drawing.Size(37, 36)
        Me.imgListBotonera.ImageStream = CType(resources.GetObject("imgListBotonera.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListBotonera.TransparentColor = System.Drawing.Color.Transparent
        '
        'CmdArriba
        '
        Me.CmdArriba.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CmdArriba.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdArriba.ImageIndex = 7
        Me.CmdArriba.ImageList = Me.imgListBotonera
        Me.CmdArriba.Location = New System.Drawing.Point(216, 140)
        Me.CmdArriba.Name = "CmdArriba"
        Me.CmdArriba.Size = New System.Drawing.Size(64, 56)
        Me.CmdArriba.TabIndex = 1
        Me.CmdArriba.Text = "Arriba"
        Me.CmdArriba.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CmdAbajo
        '
        Me.CmdAbajo.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.CmdAbajo.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdAbajo.ImageIndex = 6
        Me.CmdAbajo.ImageList = Me.imgListBotonera
        Me.CmdAbajo.Location = New System.Drawing.Point(216, 236)
        Me.CmdAbajo.Name = "CmdAbajo"
        Me.CmdAbajo.Size = New System.Drawing.Size(64, 56)
        Me.CmdAbajo.TabIndex = 2
        Me.CmdAbajo.Text = "Abajo"
        Me.CmdAbajo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'tlbBotonera
        '
        Me.tlbBotonera.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Separador1, Me.cmdAgregar, Me.cmdEditar, Me.cmdDeshacer, Me.cmdGuardar, Me.cmdBorrar, Me.Separador2, Me.cmdSalir})
        Me.tlbBotonera.ButtonSize = New System.Drawing.Size(64, 56)
        Me.tlbBotonera.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tlbBotonera.DropDownArrows = True
        Me.tlbBotonera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlbBotonera.ImageList = Me.imgListBotonera
        Me.tlbBotonera.Location = New System.Drawing.Point(0, 370)
        Me.tlbBotonera.Name = "tlbBotonera"
        Me.tlbBotonera.ShowToolTips = True
        Me.tlbBotonera.Size = New System.Drawing.Size(312, 62)
        Me.tlbBotonera.TabIndex = 57
        '
        'Separador1
        '
        Me.Separador1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdAgregar
        '
        Me.cmdAgregar.ImageIndex = 0
        Me.cmdAgregar.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        Me.cmdAgregar.Text = "Agregar"
        '
        'cmdEditar
        '
        Me.cmdEditar.ImageIndex = 1
        Me.cmdEditar.Text = "Editar"
        '
        'cmdDeshacer
        '
        Me.cmdDeshacer.ImageIndex = 2
        Me.cmdDeshacer.Text = "Deshacer"
        '
        'cmdGuardar
        '
        Me.cmdGuardar.ImageIndex = 3
        Me.cmdGuardar.Text = "Guardar"
        '
        'cmdBorrar
        '
        Me.cmdBorrar.ImageIndex = 4
        Me.cmdBorrar.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        Me.cmdBorrar.Text = "Borrar"
        '
        'Separador2
        '
        Me.Separador2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdSalir
        '
        Me.cmdSalir.ImageIndex = 5
        Me.cmdSalir.Text = "Salir"
        '
        'LtBxCargos
        '
        Me.LtBxCargos.Location = New System.Drawing.Point(8, 16)
        Me.LtBxCargos.Name = "LtBxCargos"
        Me.LtBxCargos.Size = New System.Drawing.Size(200, 342)
        Me.LtBxCargos.TabIndex = 58
        '
        'Frmc_cargosnivel
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(312, 432)
        Me.Controls.Add(Me.LtBxCargos)
        Me.Controls.Add(Me.tlbBotonera)
        Me.Controls.Add(Me.CmdAbajo)
        Me.Controls.Add(Me.CmdArriba)
        Me.Name = "Frmc_cargosnivel"
        Me.Text = "Nivel de los Cargos"
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " CommandButtons - CmdArriba,  Metodos y Procesos "

#Region " CmdArriba - CmdArriba_Click, Metodos y Procesos "

    Private Sub CmdArriba_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdArriba.Click
        Inactivos(CmdArriba, CmdAbajo, tlbBotonera)
        If LtBxCargos.SelectedIndex <> 0 Then
            If Not Svaloritem Is Nothing Then Ordenarb(1)
            Llena_LtBxCargos(dtcarniv)
            Activos(CmdArriba, CmdAbajo, tlbBotonera)
        End If
    End Sub

#End Region

#Region " CmdAbajo - CmdAbajo_Click, Metodos y Procesos "

    Private Sub CmdAbajo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdAbajo.Click
        Inactivos(CmdArriba, CmdAbajo, tlbBotonera)
        If LtBxCargos.SelectedIndex <> LtBxCargos.Items.Count - 1 Then
            If Not Svaloritem Is Nothing Then Ordenaba(1)
            Llena_LtBxCargos(dtcarniv)
            Activos(CmdArriba, CmdAbajo, tlbBotonera)
        End If
    End Sub

#End Region

#End Region

#Region " Forms - Frmc_cargosnivel_Load, Metodos y Procesos "

    Private Sub Frmc_cargosnivel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        objCargos.Bandera = 7
        dtcarniv = objCargos.Listar()
        Call Llena_LtBxCargos(dtcarniv)
        Inactivos(cmdDeshacer, cmdGuardar, cmdBorrar, CmdArriba, CmdAbajo, LtBxCargos)
        sTipoProceso = ""
    End Sub

#End Region

#Region " ListBox - LtBxCargos, Metodos y Procesos"

#Region " LtBxCargos - Llena_LtBxCargos, Metodos y Procesos"

    Private Sub Llena_LtBxCargos(ByVal dt As DataTable)
        Dim dr As DataRow
        LtBxCargos.Items.Clear()
        For Each dr In dt.Rows
            LtBxCargos.Items.Add(dr("Descripcion"))
        Next
        LtBxCargos.SelectedItem = Svaloritem
    End Sub

#End Region

#Region " LtBxCargos - LtBxCargos_SelectedIndexChanged, Metodos y Procesos"

    Private Sub LtBxCargos_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LtBxCargos.SelectedIndexChanged
        Try
        Svaloritem = LtBxCargos.SelectedItem
            Activos(CmdArriba, CmdAbajo, tlbBotonera)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

#End Region

#End Region

#Region " ToolBar - tlbBotonera, Metodos y Procesos"

    Private Sub tlbBotonera_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbBotonera.ButtonClick
        Select Case tlbBotonera.Buttons.IndexOf(e.Button)
            Case 2 'EDITAR
                sTipoProceso = "Editar"
                Activos(LtBxCargos, CmdArriba, CmdAbajo, cmdDeshacer, cmdGuardar)
            Case 3 'DESHACER
                'Inactivos(cmdDeshacer, cmdGuardar, txtComite, txtCT, txtSC, txtGT, txtDescripcion, txtObjetivo)
                Frmc_cargosnivel_Load(Me, e)
            Case 4 'GUARDAR
                Call Guardar()
                Me.Dispose()
            Case 7
                Me.Dispose()
        End Select
    End Sub

#End Region


End Class
