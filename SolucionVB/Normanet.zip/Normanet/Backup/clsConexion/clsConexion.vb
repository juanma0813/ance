'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'   NOMBRE DE LA CLASE: CLASE DE CONEXION
'   DESARROLLADA POR : EXTI, S.C. PARA ANCE, A.C.
'   FECHA: 15 MAYO 2006
'
'   TIPO: LECTURA Y/O ESCRITURA
'
'   DESCRIPCION: Con base en esta clase definimos a que servidor y Base de Datos nos conectamos 
'                mediante el archivo Ini el cual tiene el nombre BotonInicial.JPEG, para leer este archivo es necesario cargar la Clase  clsIniArray
'
'   PARAMETROS : La clase debera requerir dos parametros (1) es la ruta del servidor, (2) La seccion a la cual se debe conectar [Principal] o [Comun]
'
'   FECHA MODIFICACION: 
'   MODIFICACION REALIZADA:
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Option Strict On
Option Explicit On 

Public Class cIsConexion

    Private sBuffer As String ' Para usarla en las funciones GetSection(s)
    '--- Declaraciones para leer ficheros INI ---
    ' Leer todas las secciones de un fichero INI, esto seguramente no funciona en Win95
    ' Esta funci�n no estaba en las declaraciones del API que se incluye con el VB
    Private Declare Function GetPrivateProfileSectionNames Lib "kernel32" Alias "GetPrivateProfileSectionNamesA" (ByVal lpszReturnBuffer As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer

    ' Leer una secci�n completa
    Private Declare Function GetPrivateProfileSection Lib "kernel32" Alias "GetPrivateProfileSectionA" (ByVal lpAppName As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer

    ' Leer una clave de un fichero INI
    Private Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer
    Private Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Integer, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer

    ' Escribir una clave de un fichero INI (tambi�n para borrar claves y secciones)
    Private Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpString As String, ByVal lpFileName As String) As Integer
    Private Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpString As Integer, ByVal lpFileName As String) As Integer
    Private Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Integer, ByVal lpString As Integer, ByVal lpFileName As String) As Integer

    Private _Base As String
    Private _Server As String

    Public Property Base() As System.String
        Get
            Return _Base
        End Get
        Set(ByVal Value As System.String)
            _Base = Value
        End Set
    End Property

    Public Property Server() As System.String
        Get
            Return _Server
        End Get
        Set(ByVal Value As System.String)
            _Server = Value
        End Set
    End Property
    Private Sub IniDeleteKey(ByVal sIniFile As String, ByVal sSection As String, Optional ByVal sKey As String = "")
        ' Para borrar una secci�n se deber�a usar IniDeleteSection
        If Len(sKey) = 0 Then
            ' Borrar una secci�n
            Call WritePrivateProfileString(sSection, 0, 0, sIniFile)
        Else
            ' Borrar una entrada
            Call WritePrivateProfileString(sSection, sKey, 0, sIniFile)
        End If
    End Sub

    Private Sub IniDeleteSection(ByVal sIniFile As String, ByVal sSection As String)
        ' Borrar una secci�n de un fichero INI                          (04/Abr/01)
        Call WritePrivateProfileString(sSection, 0, 0, sIniFile)
    End Sub

    Public Function IniGet(ByVal sFileName As String, ByVal sSection As String, ByVal sKeyName As String, Optional ByVal sDefault As String = "") As String
        '--------------------------------------------------------------------------
        ' Devuelve el valor de una clave de un fichero INI
        ' Los par�metros son:
        '   sFileName   El fichero INI
        '   sSection    La secci�n de la que se quiere leer
        '   sKeyName    Clave
        '   sDefault    Valor opcional que devolver� si no se encuentra la clave
        '--------------------------------------------------------------------------
        Dim ret As Integer
        Dim sRetVal As String
        '
        sRetVal = New String(Chr(0), 255)
        '
        ret = GetPrivateProfileString(sSection, sKeyName, sDefault, sRetVal, Len(sRetVal), sFileName)
        If ret = 0 Then
            Return sDefault
        Else
            Return Left(sRetVal, ret)
        End If
    End Function

    Private Sub IniWrite(ByVal sFileName As String, ByVal sSection As String, ByVal sKeyName As String, ByVal sValue As String)
        '--------------------------------------------------------------------------
        ' Guarda los datos de configuraci�n
        Call WritePrivateProfileString(sSection, sKeyName, sValue, sFileName)
    End Sub

    Private Function IniGetSection(ByVal sFileName As String, ByVal sSection As String) As String()
        '--------------------------------------------------------------------------
        ' Lee una secci�n entera de un fichero INI                      (27/Feb/99)
        ' Adaptada para devolver un array de string                     (04/Abr/01)

        Dim aSeccion() As String
        Dim n As Integer

        ReDim aSeccion(0)

        ' El tama�o m�ximo para Windows 95
        sBuffer = New String(ChrW(0), 32767)

        n = GetPrivateProfileSection(sSection, sBuffer, sBuffer.Length, sFileName)

        If n > 0 Then

            ' Cortar la cadena al n�mero de caracteres devueltos
            ' menos los dos �ltimos que indican el final de la cadena
            sBuffer = sBuffer.Substring(0, n - 2).TrimEnd()
            ' Cada elemento estar� separado por un Chr(0)
            ' y cada valor estar� en la forma: clave = valor
            aSeccion = sBuffer.Split(New Char() {ChrW(0), "="c})
        End If
        ' Devolver el array
        Return aSeccion
    End Function

    Private Function IniGetSections(ByVal sFileName As String) As String()
        '--------------------------------------------------------------------------
        ' Devuelve todas las secciones de un fichero INI                (27/Feb/99)
        ' Adaptada para devolver un array de string                     (04/Abr/01)

        Dim n As Integer
        Dim aSections() As String
        '
        ReDim aSections(0)
        '
        ' El tama�o m�ximo para Windows 95
        sBuffer = New String(ChrW(0), 32767)
        ' Esta funci�n del API no est� definida en el fichero TXT
        n = GetPrivateProfileSectionNames(sBuffer, sBuffer.Length, sFileName)
        '
        If n > 0 Then
            sBuffer = sBuffer.Substring(0, n - 2).TrimEnd()
            aSections = sBuffer.Split(ChrW(0))
        End If
        ' Devolver el array
        Return aSections
    End Function
    '
    Private Shared Function AppPath( _
            Optional ByVal backSlash As Boolean = False _
            ) As String
        Dim s As String = _
            IO.Path.GetDirectoryName( _
            System.Reflection.Assembly.GetExecutingAssembly.GetCallingAssembly.Location)
        If backSlash Then
            s &= "\"
        End If
        Return s
    End Function

    Public Function Conexionweb(ByVal sPathIni As String, ByVal sSeccion As String) As String
        '  Dim sServer, sBase As String
        _Server = Me.IniGet(sPathIni, sSeccion, "Servidor")
        _Base = Me.IniGet(sPathIni, sSeccion, "Base")
        Conexionweb = "Data source =" & _Server & "; Initial Catalog = " & _Base & "; User Id=admsis; pwd=admynsys;"
        Return Conexionweb

    End Function
    Public Function ConexionAnce(ByVal sPathIni As String, ByVal sSeccion As String, ByVal usuario As String, ByVal clave As String) As String
        '  Dim sServer, sBase As String
        _Server = Me.IniGet(sPathIni, sSeccion, "Servidor")
        _Base = Me.IniGet(sPathIni, sSeccion, "Base")
        ConexionAnce = "Data source =" & _Server & "; Initial Catalog = " & _Base & "; User Id=" & usuario & "; pwd=" & clave & ""
        Return ConexionAnce

    End Function

    Public Sub New()

    End Sub
End Class
