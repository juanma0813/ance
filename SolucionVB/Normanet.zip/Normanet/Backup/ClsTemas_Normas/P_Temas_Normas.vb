
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Temas_Normas Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 21/11/2006 12:11:12 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Temas_Normas

     '''''''Declaracion de Variables Privadas
    Private dsP_Temas_Normas As New DataSet
    Private _Id_plan As System.String
    Private _Id_tema As System.Int32
    Private _Clasificacion As System.String
    Private _Encontrado As Boolean
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo
    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _status As Integer
    Private _Tipo As String
    Private _sReferencia As String

     '''''''Declaracion de Propiedades publicas
     Public Property Id_plan() As System.String
          Get
              Return _Id_plan
          End Get
          Set(Value as System.String)
              _Id_plan = Value
          End Set
     End Property

     Public Property Id_tema() As System.Int32
          Get
              Return _Id_tema
          End Get
          Set(Value as System.Int32)
              _Id_tema = Value
          End Set
     End Property

     Public Property Clasificacion() As System.String
          Get
              Return _Clasificacion
          End Get
          Set(Value as System.String)
              _Clasificacion = Value
          End Set
     End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Status() As Integer
        Get
            Return _status
        End Get
        Set(ByVal Value As Integer)
            _status = Value
        End Set
    End Property

    Public Property Tipo() As String
        Get
            Return _Tipo
        End Get
        Set(ByVal Value As String)
            _Tipo = Value
        End Set
    End Property
    Public Property sReferencia() As System.String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As System.String)
            _sReferencia = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Lista(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Temas_Normas")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal stema As String, ByVal splan As String, ByVal sClasificacion As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Temas_Normas WHERE clasificacion='" & sClasificacion & "' and id_tema='" & stema & "' and id_plan='" & splan & "'"
        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            da.Fill(dsP_Temas_Normas, "C_Encontrado")
            cn.Close()
            If dsP_Temas_Normas.Tables("C_Encontrado").Rows.Count > 0 Then

                _Ref_A�o = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_A�o"))
                _Ref_Comite = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
                _Ref_Consecutivo = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
                _Ref_Regreso = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
                _Ref_Traspaso = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))
                '_status = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Status")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Status"))

                _Id_plan = dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Id_plan")
                _Id_tema = dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Id_tema")
                _Clasificacion = dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Clasificacion")
                _Encontrado = True
            Else
                _Ref_A�o = Nothing
                _Ref_Comite = Nothing
                _Ref_Consecutivo = Nothing
                _Ref_Regreso = Nothing
                _Ref_Traspaso = Nothing
                _status = Nothing

                _Id_plan = ""
                _Id_tema = 0
                _Clasificacion = ""
                _Encontrado = False
            End If
            dsP_Temas_Normas.Tables("C_Encontrado").Clear()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try


    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza(ByVal Stema As String, ByVal sPlan As String, ByVal sClasificacion As String, ByVal Bandera As Integer)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_TemasNormas"


        cmd.Parameters.Add("@Id_plan", sPlan)
        cmd.Parameters.Add("@Id_tema", Stema)
        cmd.Parameters.Add("@Clasificacion", sClasificacion)
        cmd.Parameters.Add("@Bandera", Bandera)

        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@sReferencia", _sReferencia)
        'cmd.Parameters.Add("", _status)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Function BuscarXreferencia(ByVal stema As String, ByVal splan As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Temas_Normas WHERE id_tema='" & stema & "' and id_plan='" & splan & "'"
        sSql = sSql + " and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & _sReferencia & "'"
        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            da.Fill(dsP_Temas_Normas, "C_Encontrado")
            cn.Close()
            If dsP_Temas_Normas.Tables("C_Encontrado").Rows.Count > 0 Then

                _Ref_A�o = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_A�o"))
                _Ref_Comite = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
                _Ref_Consecutivo = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
                _Ref_Regreso = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
                _Ref_Traspaso = IIf(IsDBNull(dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, "", dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))

                _Id_plan = dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Id_plan")
                _Id_tema = dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Id_tema")
                _Clasificacion = dsP_Temas_Normas.Tables("C_Encontrado").Rows(0).Item("Clasificacion")
                _Encontrado = True
            Else
                _Ref_A�o = Nothing
                _Ref_Comite = Nothing
                _Ref_Consecutivo = Nothing
                _Ref_Regreso = Nothing
                _Ref_Traspaso = Nothing
                _status = Nothing

                _Id_plan = ""
                _Id_tema = 0
                _Clasificacion = ""
                _Encontrado = False
            End If
            dsP_Temas_Normas.Tables("C_Encontrado").Clear()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try


    End Function
    Public Sub traspasaTemasNormas(ByVal plan As String, ByVal tema As Integer)
        _Ref_Traspaso = _Ref_Traspaso + 1
        Actualiza(tema, plan, _Clasificacion, 2)
    End Sub

End Class
