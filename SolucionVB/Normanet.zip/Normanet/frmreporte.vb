Imports System.Data.SqlClient
Imports System.Data.DataSet
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Web
Imports CrystalDecisions.Windows.Forms
Imports System.IO
Imports System.IO.File
Imports System.Windows.Forms

Public Class frmreporte
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents crvReporte As CrystalDecisions.Windows.Forms.CrystalReportViewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.crvReporte = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.SuspendLayout()
        '
        'crvReporte
        '
        Me.crvReporte.ActiveViewIndex = -1
        Me.crvReporte.Dock = System.Windows.Forms.DockStyle.Fill
        Me.crvReporte.Location = New System.Drawing.Point(0, 0)
        Me.crvReporte.Name = "crvReporte"
        Me.crvReporte.ReportSource = Nothing
        Me.crvReporte.Size = New System.Drawing.Size(736, 646)
        Me.crvReporte.TabIndex = 0
        '
        'frmreporte
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(736, 646)
        Me.Controls.Add(Me.crvReporte)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmreporte"
        Me.Text = "Reportes"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim cr As New ReportDocument
    Dim sReporte As String
    Dim log As New CrystalDecisions.Shared.TableLogOnInfo
    Dim Sruta As String
    Dim sRuta2 As String
    Private ObjReporte As New clsConexion.cIsConexion
    'Private ObjReporte As New clsConexionArchivo.clsConexionArchivo
    Private ObjPrograma As New ClsProgramaTrabajo.P_Prog_Trab(0, gUsuario, gPasswordSql)

    Private Sub frmreporte_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        crvReporte.ShowCloseButton = False
        Select Case gReporte
            Case "Acta_Aprob_Dt"
                Sruta = Application.StartupPath + "\Reportes\Acta_Aprobacion_DT.rpt"
                sRuta2 = Application.StartupPath + "\Principal.ini"
                ObjReporte.ConexionAnce(sRuta2, "PRINCIPAL", gUsuario, gPasswordSql)
                log.ConnectionInfo.ServerName = ObjReporte.Server
                log.ConnectionInfo.DatabaseName = ObjReporte.Base
                log.ConnectionInfo.UserID = gUsuario
                log.ConnectionInfo.Password = gPasswordSql
                cr.Load(Sruta)
                cr.DataDefinition.FormulaFields("Plan").Text = Chr(34) + SGralPlan + Chr(34)
                cr.DataDefinition.FormulaFields("Id_tema").Text = Chr(34) + SGralTema + Chr(34)
                cr.DataDefinition.FormulaFields("Titulo").Text = Chr(34) + UCase(sGralTitulo) + Chr(34)
                cr.DataDefinition.FormulaFields("Comit�").Text = Chr(34) + sGralComite + Chr(34)
                cr.DataDefinition.FormulaFields("Clasificacion").Text = Chr(34) + UCase(sGralClasificacion) + Chr(34)
                cr.DataDefinition.FormulaFields("Fecha").Text = Chr(34) + sGralFecha + Chr(34)

                'cr.Database.Tables.Item("P_Prog_Trab").ApplyLogOnInfo(log)
                crvReporte.ReportSource = cr
            Case "Acta_Aprob_PROY"
                Sruta = Application.StartupPath + "\Reportes\Acta_Aprobacion_Proy.rpt"
                sRuta2 = Application.StartupPath + "\Principal.ini"
                ObjReporte.ConexionAnce(sRuta2, "PRINCIPAL", gUsuario, gPasswordSql)
                log.ConnectionInfo.ServerName = ObjReporte.Server
                log.ConnectionInfo.DatabaseName = ObjReporte.Base
                log.ConnectionInfo.UserID = gUsuario
                log.ConnectionInfo.Password = gPasswordSql
                cr.Load(Sruta)
                cr.DataDefinition.FormulaFields("Plan").Text = Chr(34) + SGralPlan + Chr(34)
                cr.DataDefinition.FormulaFields("Id_tema").Text = Chr(34) + SGralTema + Chr(34)
                cr.DataDefinition.FormulaFields("Titulo").Text = Chr(34) + sGralTitulo + Chr(34)
                cr.DataDefinition.FormulaFields("Comit�").Text = Chr(34) + sGralComite + Chr(34)
                cr.DataDefinition.FormulaFields("Clasificacion").Text = Chr(34) + sGralClasificacion.Replace("PROY-", "") + Chr(34)
                cr.DataDefinition.FormulaFields("Fecha").Text = Chr(34) + sGralFecha + Chr(34)

                cr.DataDefinition.FormulaFields("Paginas").Text = Chr(34) + sPaginas + Chr(34)
                cr.DataDefinition.FormulaFields("Norma").Text = Chr(34) + sNorma + Chr(34)
                cr.DataDefinition.FormulaFields("Sesion").Text = Chr(34) + sSesion + Chr(34)
                cr.DataDefinition.FormulaFields("Fecha").Text = Chr(34) + sGralFecha + Chr(34)
                cr.DataDefinition.FormulaFields("Comit�").Text = Chr(34) + sComiteT + Chr(34)
                sCancela = IIf(sCancela = "", "Primera Edici�n", "Esta norma cancela a la: " & sCancela)
                cr.DataDefinition.FormulaFields("Cancela").Text = Chr(34) + sCancela + Chr(34)

                REM cr.DataDefinition.FormulaFields("PreAnce").Text = Chr(34) + sPreAnce + Chr(34)
                REM cr.DataDefinition.FormulaFields("PreConance").Text = Chr(34) + sPreConance + Chr(34)

                'cr.Database.Tables.Item("P_Prog_Trab").ApplyLogOnInfo(log)
                crvReporte.ReportSource = cr

        End Select
        gReporte = ""

    End Sub

    Private Sub crvReporte_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles crvReporte.Load

    End Sub
End Class
