
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Ant Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 21/09/2006 05:53:33 p.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Ant

     '''''''Declaracion de Variables Privadas
     Private dsP_Ant AS New DataSet
     Private _Id_Plan as System.String
     Private _Id_Tema as System.Int32
     Private _Titulo as System.String
     Private _Num_Paginas as System.Int32
     Private _Fecha_Aprob_ct_gt as System.DateTime
     Private _Clasificacion as System.String
    Private _Responsable As System.String
    Private _Encontrado As Boolean
    Private _Act_aprob As String
    Private _Bandera As Boolean
    Private _f_correcciones As String
    Private _correcciones As Boolean

    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _status As Integer
    Private _bandera2 As Integer
    Private _Tipo As String
    Private _sReferencia As String

    Private sSql As String

    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo


    '''''''Declaracion de Propiedades publicas
    Public Property Id_Plan() As System.String
        Get
            Return _Id_Plan
        End Get
        Set(ByVal Value As System.String)
            _Id_Plan = Value
        End Set
    End Property

    Public Property Id_Tema() As System.Int32
        Get
            Return _Id_Tema
        End Get
        Set(ByVal Value As System.Int32)
            _Id_Tema = Value
        End Set
    End Property

    Public Property Titulo() As System.String
        Get
            Return _Titulo
        End Get
        Set(ByVal Value As System.String)
            _Titulo = Value
        End Set
    End Property

    Public Property Tipo() As String
        Get
            Return _Tipo
        End Get
        Set(ByVal Value As String)
            _Tipo = Value
        End Set
    End Property

    Public Property Num_Paginas() As System.Int32
        Get
            Return _Num_Paginas
        End Get
        Set(ByVal Value As System.Int32)
            _Num_Paginas = Value
        End Set
    End Property

    Public Property Bandera2() As System.Int32
        Get
            Return _bandera2
        End Get
        Set(ByVal Value As System.Int32)
            _bandera2 = Value
        End Set
    End Property

    Public Property Fecha_Aprob_ct_gt() As System.DateTime
        Get
            Return _Fecha_Aprob_ct_gt
        End Get
        Set(ByVal Value As System.DateTime)
            _Fecha_Aprob_ct_gt = Value
        End Set
    End Property

    Public Property Clasificacion() As System.String
        Get
            Return _Clasificacion
        End Get
        Set(ByVal Value As System.String)
            _Clasificacion = Value
        End Set
    End Property

    Public Property Responsable() As System.String
        Get
            Return _Responsable
        End Get
        Set(ByVal Value As System.String)
            _Responsable = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Bandera() As Boolean
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Boolean)
            _Bandera = Value
        End Set
    End Property
    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Status() As Integer
        Get
            Return _status
        End Get
        Set(ByVal Value As Integer)
            _status = Value
        End Set
    End Property
    Public Property Act_aprob() As Integer
        Get
            Return _Act_aprob
        End Get
        Set(ByVal Value As Integer)
            _Act_aprob = Value
        End Set
    End Property

    Public Property Correcciones() As Boolean
        Get
            Return _correcciones
        End Get
        Set(ByVal Value As Boolean)
            _correcciones = Value
        End Set
    End Property

    Public Property F_Correcciones() As String
        Get
            Return _f_correcciones
        End Get
        Set(ByVal Value As String)
            _f_correcciones = Value
        End Set
    End Property

    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property


    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""
    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function ListaCombo(ByVal Sel As String) As DataTable
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("P_Ant")
        Try
            da = New SqlDataAdapter(Sel, CadenaConexion)
            da.Fill(dt)
        Catch
            Return Nothing
        End Try
        Return dt
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal sTema As String, ByVal Splan As String, ByVal sref As String)
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Ant WHERE id_tema='" & sTema & "' and id_plan='" & Splan & "' and status <> 10 and status <> 11"
        sSql = sSql + " and ref_a�o + ref_comite + ref_Consecutivo + ref_regreso + ref_traspaso ='" & sref & "'"

        If _Tipo = "abandono" Then sSql = sSql + "Order by ref_regreso desc"
        If _Tipo = "traspaso" Then sSql = sSql + "Order by ref_regreso desc"

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da.Fill(dsP_Ant, "C_Encontrado")
        cn.Close()
        If dsP_Ant.Tables("C_Encontrado").Rows.Count > 0 Then

            _Ref_A�o = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_A�o"))
            _Ref_Comite = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Comite"))
            _Ref_Consecutivo = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo"))
            _Ref_Regreso = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso"))
            _Ref_Traspaso = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso"))
            _status = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Status")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Status"))

            _Id_Plan = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Id_Plan")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Id_Plan"))
            _Act_aprob = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Act_aprob")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Act_aprob"))
            _Id_Tema = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Id_Tema")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Id_Tema"))
            _Titulo = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Titulo")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Titulo"))
            _Num_Paginas = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Num_Paginas")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Num_Paginas"))
            '_Fecha_Aprob_ct_gt = dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Fecha_Aprob_ct_gt")
            _Clasificacion = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Clasificacion")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Clasificacion"))
            _Responsable = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Responsable")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("Responsable"))
            _f_correcciones = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("f_correcciones")) = True, "", dsP_Ant.Tables("C_Encontrado").Rows(0).Item("f_correcciones"))
            _correcciones = IIf(IsDBNull(dsP_Ant.Tables("C_Encontrado").Rows(0).Item("correcciones")) = True, False, dsP_Ant.Tables("C_Encontrado").Rows(0).Item("correcciones"))
            _Encontrado = True
        Else
            _Id_Plan = ""
            _Id_Tema = 0
            _Titulo = ""
            _Num_Paginas = 0
            _Clasificacion = ""
            _Responsable = ""
            _Encontrado = False
        End If
        dsP_Ant.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualizar(ByVal splan As String, ByVal stema As String, ByVal stitulo As String, ByVal snumpaginas As String, ByVal sclasificacion As String, ByVal sresponsable As String) As String

        Dim cmd As New SqlCommand("Sp_ANT", cn)
        sSql = "UPDATE P_Ant SET Id_Plan = @Id_Plan, Id_Tema = @Id_Tema, Titulo = @Titulo, Num_Paginas = @Num_Paginas, Fecha_Aprob_ct_gt = @Fecha_Aprob_ct_gt, Clasificacion = @Clasificacion, Responsable = @Responsable, Where ( = @)"
        cmd.Parameters.Add("@Id_Plan", SqlDbType.NVarChar, 20, "_Id_Plan")
        cmd.Parameters.Add("@Id_Tema", SqlDbType.Int, 0, "_Id_Tema")
        cmd.Parameters.Add("@Titulo", SqlDbType.NVarChar, 2147483647, "_Titulo")
        cmd.Parameters.Add("@Num_Paginas", SqlDbType.Int, 0, "_Num_Paginas")
        cmd.Parameters.Add("@Clasificacion", SqlDbType.NVarChar, 20, "_Clasificacion")
        cmd.Parameters.Add("@Responsable", SqlDbType.NVarChar, 15, "_Responsable")
        cmd.Parameters.Add("@correccion", _correcciones)
        cmd.Parameters.Add("@f_Correccion", _f_correcciones)
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function


    Public Function Actualiza(ByVal Bandera As Integer, ByVal splan As String, ByVal stema As String, ByVal stitulo As String, ByVal snumpaginas As String, ByVal sclasificacion As String, ByVal sresponsable As String, ByVal status As Integer, ByVal sref As String) As String
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "Sp_Ant"

        cmd.Parameters.Add("@Bandera", Bandera)
        cmd.Parameters.Add("@Id_Plan", splan)
        cmd.Parameters.Add("@Id_Tema", stema)
        cmd.Parameters.Add("@Titulo", stitulo)
        cmd.Parameters.Add("@Num_Paginas", snumpaginas)
        cmd.Parameters.Add("@Clasificacion", sclasificacion)
        cmd.Parameters.Add("@Responsable", sresponsable)
        cmd.Parameters.Add("@sReferencia", sref)

        cmd.Parameters.Add("@correcciones", _correcciones)
        cmd.Parameters.Add("@f_Correcciones", IIf(_f_correcciones = "", Nothing, _f_correcciones))

        cmd.Parameters.Add("@Ref_A�o", _Ref_A�o)
        cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
        cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Status", 1)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function Insertar()

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_Ant"
        If cn.State = 1 Then cn.Close()
        cn.Open()

        cmd.Connection = cn

        cmd.Parameters.Add("@ref_a�o", _Ref_A�o)
        cmd.Parameters.Add("@ref_comite", _Ref_Comite)
        cmd.Parameters.Add("@ref_consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@ref_regreso", _Ref_Regreso)
        cmd.Parameters.Add("@ref_traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_Tema", _Id_Tema)
        cmd.Parameters.Add("@Clasificacion", _Clasificacion)
        cmd.Parameters.Add("@Titulo", _Titulo)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@Num_Paginas", _Num_Paginas)
        cmd.Parameters.Add("@Bandera", _bandera2)
        cmd.Parameters.Add("@Status", _status)
        cmd.Parameters.Add("@Act_aprob", _Act_aprob)
        cmd.Parameters.Add("@f_Correcciones", IIf(_f_correcciones = "", Nothing, _f_correcciones))
        cmd.Parameters.Add("@Correcciones", _correcciones)
        cmd.Parameters.Add("@sReferencia", _sReferencia)

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Sub ActualizaRefAnterior(ByVal band As Integer)
        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "sp_Ant"
            .CommandType = CommandType.StoredProcedure

            .Parameters.Add("@bandera", band)
            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@sReferencia", _sReferencia)
            If cn.State = 1 Then cn.Close()
            cn.Open()
            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Dim ms
                ms = ex.Message
            End Try
        End With
    End Sub
    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_Ant"
        cmd.Parameters.Add("@Bandera", 5)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Sub traspasaAnt(ByVal plan As String, ByVal tema As Integer)
        _status = 1
        _Id_Plan = plan
        _Id_Tema = tema
        _bandera2 = 6
        _Ref_Traspaso = _Ref_Traspaso + 1
        Insertar()
    End Sub
End Class
