Public Class CrearIndex
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents tlbMenus As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton16 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton25 As System.Windows.Forms.ToolBarButton
    Friend WithEvents lstImagenes As System.Windows.Forms.ImageList
    Friend WithEvents grpLigas As System.Windows.Forms.GroupBox
    Friend WithEvents optTipoExternas As System.Windows.Forms.RadioButton
    Friend WithEvents optTipoCreadas As System.Windows.Forms.RadioButton
    Friend WithEvents cboLiga As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTextoLigaIndex As System.Windows.Forms.TextBox
    Friend WithEvents txtNombreLiga As System.Windows.Forms.TextBox
    Friend WithEvents grdLigas As System.Windows.Forms.DataGrid
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cboGrupos As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(CrearIndex))
        Me.tlbMenus = New System.Windows.Forms.ToolBar
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton16 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton25 = New System.Windows.Forms.ToolBarButton
        Me.lstImagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.grpLigas = New System.Windows.Forms.GroupBox
        Me.optTipoExternas = New System.Windows.Forms.RadioButton
        Me.optTipoCreadas = New System.Windows.Forms.RadioButton
        Me.cboLiga = New System.Windows.Forms.ComboBox
        Me.txtNombreLiga = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtTextoLigaIndex = New System.Windows.Forms.TextBox
        Me.grdLigas = New System.Windows.Forms.DataGrid
        Me.Label4 = New System.Windows.Forms.Label
        Me.cboGrupos = New System.Windows.Forms.ComboBox
        Me.grpLigas.SuspendLayout()
        CType(Me.grdLigas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tlbMenus
        '
        Me.tlbMenus.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton16, Me.ToolBarButton25})
        Me.tlbMenus.ButtonSize = New System.Drawing.Size(27, 26)
        Me.tlbMenus.DropDownArrows = True
        Me.tlbMenus.ImageList = Me.lstImagenes
        Me.tlbMenus.Location = New System.Drawing.Point(0, 0)
        Me.tlbMenus.Name = "tlbMenus"
        Me.tlbMenus.ShowToolTips = True
        Me.tlbMenus.Size = New System.Drawing.Size(632, 32)
        Me.tlbMenus.TabIndex = 8
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 6
        Me.ToolBarButton5.ToolTipText = "Nuevo"
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 3
        Me.ToolBarButton6.ToolTipText = "Guardar"
        '
        'ToolBarButton16
        '
        Me.ToolBarButton16.ImageIndex = 1
        Me.ToolBarButton16.ToolTipText = "Eliminar"
        '
        'ToolBarButton25
        '
        Me.ToolBarButton25.ImageIndex = 10
        Me.ToolBarButton25.ToolTipText = "Deshacer"
        '
        'lstImagenes
        '
        Me.lstImagenes.ImageSize = New System.Drawing.Size(20, 20)
        Me.lstImagenes.ImageStream = CType(resources.GetObject("lstImagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.lstImagenes.TransparentColor = System.Drawing.Color.Transparent
        '
        'grpLigas
        '
        Me.grpLigas.Controls.Add(Me.optTipoExternas)
        Me.grpLigas.Controls.Add(Me.optTipoCreadas)
        Me.grpLigas.Location = New System.Drawing.Point(104, 136)
        Me.grpLigas.Name = "grpLigas"
        Me.grpLigas.Size = New System.Drawing.Size(256, 48)
        Me.grpLigas.TabIndex = 15
        Me.grpLigas.TabStop = False
        Me.grpLigas.Text = "Tipo de Liga"
        '
        'optTipoExternas
        '
        Me.optTipoExternas.Checked = True
        Me.optTipoExternas.Location = New System.Drawing.Point(136, 16)
        Me.optTipoExternas.Name = "optTipoExternas"
        Me.optTipoExternas.Size = New System.Drawing.Size(112, 24)
        Me.optTipoExternas.TabIndex = 6
        Me.optTipoExternas.TabStop = True
        Me.optTipoExternas.Text = "Paginas Externas"
        '
        'optTipoCreadas
        '
        Me.optTipoCreadas.Location = New System.Drawing.Point(8, 16)
        Me.optTipoCreadas.Name = "optTipoCreadas"
        Me.optTipoCreadas.Size = New System.Drawing.Size(112, 24)
        Me.optTipoCreadas.TabIndex = 5
        Me.optTipoCreadas.Text = "Paginas creadas"
        '
        'cboLiga
        '
        Me.cboLiga.Location = New System.Drawing.Point(104, 112)
        Me.cboLiga.Name = "cboLiga"
        Me.cboLiga.Size = New System.Drawing.Size(512, 21)
        Me.cboLiga.TabIndex = 4
        '
        'txtNombreLiga
        '
        Me.txtNombreLiga.Location = New System.Drawing.Point(104, 64)
        Me.txtNombreLiga.Name = "txtNombreLiga"
        Me.txtNombreLiga.Size = New System.Drawing.Size(512, 20)
        Me.txtNombreLiga.TabIndex = 2
        Me.txtNombreLiga.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(72, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 23)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Liga:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(32, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 23)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Nombre Liga:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(64, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 23)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Texto:"
        '
        'txtTextoLigaIndex
        '
        Me.txtTextoLigaIndex.Location = New System.Drawing.Point(104, 88)
        Me.txtTextoLigaIndex.Name = "txtTextoLigaIndex"
        Me.txtTextoLigaIndex.Size = New System.Drawing.Size(512, 20)
        Me.txtTextoLigaIndex.TabIndex = 3
        Me.txtTextoLigaIndex.Text = ""
        '
        'grdLigas
        '
        Me.grdLigas.DataMember = ""
        Me.grdLigas.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdLigas.Location = New System.Drawing.Point(16, 192)
        Me.grdLigas.Name = "grdLigas"
        Me.grdLigas.ReadOnly = True
        Me.grdLigas.Size = New System.Drawing.Size(600, 176)
        Me.grdLigas.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(64, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 23)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Grupo:"
        '
        'cboGrupos
        '
        Me.cboGrupos.Location = New System.Drawing.Point(104, 40)
        Me.cboGrupos.Name = "cboGrupos"
        Me.cboGrupos.Size = New System.Drawing.Size(264, 21)
        Me.cboGrupos.TabIndex = 1
        '
        'CrearIndex
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(632, 378)
        Me.Controls.Add(Me.cboGrupos)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.grdLigas)
        Me.Controls.Add(Me.txtTextoLigaIndex)
        Me.Controls.Add(Me.txtNombreLiga)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.grpLigas)
        Me.Controls.Add(Me.cboLiga)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tlbMenus)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CrearIndex"
        Me.Text = "Creador de Index"
        Me.grpLigas.ResumeLayout(False)
        CType(Me.grdLigas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub CrearIndex_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        botonesDeInicio()
        LlenarGrupos()
        llenarLigas()
    End Sub

    Private Sub LlenarGrupos()
        Dim objGruposPaginas As New clsGruposPaginas.Maple.clsGruposPaginas

        objGruposPaginas.Bandera = "s5"
        objGruposPaginas.Activo = True
        objGruposPaginas.Terminada = True
        Try
            cboGrupos.DataSource = objGruposPaginas.Listar
            cboGrupos.DisplayMember = "Nombre"
            cboGrupos.ValueMember = "Id_GruposPaginas"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGruposPaginas = Nothing
        End Try
    End Sub

    Private Sub llenarLigas()
        Dim objGruposPaginas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas
        Dim dt As DataTable
        Dim datosgrid() As String

        Try
            objGruposPaginas.Bandera = "s4"
            objGruposPaginas.Activo = True
            objGruposPaginas.Id_GruposPaginas = cboGrupos.SelectedValue

            dt = objGruposPaginas.Listar
            grdLigas.DataSource = dt

            datosgrid = Split("Id_LigasGruposPaginas|False|0,Id_GruposPaginas|False|0,Nombre|True|150,Texto|True|150," _
                                            & "Id_TiposLigas|False|0,aId_DocumentoWeb|False|0,aExterna|True|150," _
                                            & "aId_Pagina|False|0,Activo|False|0", ",")


            Estilos(grdLigas, datosgrid, dt)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGruposPaginas = Nothing
            dt = Nothing
        End Try
    End Sub


    Private Sub botonesDeInicio()
        cboLiga.DropDownStyle = ComboBoxStyle.Simple
        Lectura(txtNombreLiga, txtTextoLigaIndex)
        Limpiar(txtNombreLiga, txtTextoLigaIndex, cboLiga)

        Activar(tlbMenus.Buttons.Item(0), tlbMenus.Buttons.Item(2), cboGrupos)
        inactivar(tlbMenus.Buttons.Item(1), tlbMenus.Buttons.Item(3), grpLigas)

        inactivar(cboLiga)
        optTipoExternas.Checked = True        
    End Sub

    Private Sub botonesDeNuevo()
        inactivar(tlbMenus.Buttons.Item(0), tlbMenus.Buttons.Item(2), cboGrupos)
        Activar(tlbMenus.Buttons.Item(1), tlbMenus.Buttons.Item(3), grpLigas)
        Escritura(txtNombreLiga, txtTextoLigaIndex)
        Limpiar(txtNombreLiga, txtTextoLigaIndex, cboLiga)
        Activar(cboLiga)
    End Sub

    Private Sub optTipoExternas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTipoExternas.CheckedChanged
        Limpiar(cboLiga)
        cboLiga.DataSource = Nothing
        If optTipoExternas.Checked Then
            cboLiga.DropDownStyle = ComboBoxStyle.Simple
        Else
            cboLiga.DropDownStyle = ComboBoxStyle.DropDownList
        End If
    End Sub

    Private Sub optTipoCreadas_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTipoCreadas.CheckedChanged
        Limpiar(cboLiga)
        If optTipoCreadas.Checked Then
            LlenarPaginas()
        End If
    End Sub

    Private Sub LlenarPaginas()
        Dim objPaginas As New clsPAginas.Maple.clsPaginas
        Try
            objPaginas.Bandera = "s4"
            objPaginas.Terminada = True
            objPaginas.Activo = True

            cboLiga.DataSource = objPaginas.Listar
            cboLiga.ValueMember = "Id_Pagina"
            cboLiga.DisplayMember = "Nombre"
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPaginas = Nothing
        End Try
    End Sub

    Private Sub tlbMenus_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbMenus.ButtonClick
        Select Case tlbMenus.Buttons.IndexOf(e.Button)
            Case 0 REM Nuevo
                botonesDeNuevo()
            Case 1 REM guardar
                GuardarLiga()
                LlenarGrupos()
                llenarLigas()
            Case 2 REM eliminar
                If MsgBox("�Estas seguro de eliminar la liga?", MsgBoxStyle.OKCancel) = MsgBoxResult.OK Then
                    eliminarLiga()
                    LlenarGrupos()
                    llenarLigas()
                End If

            Case 3 REM deshacer
                botonesDeInicio()
                LlenarGrupos()
                llenarLigas()
        End Select
    End Sub

    Private Sub GuardarLiga()
        Dim objValidar As New clsValidarCampos.Maple.clsValidarCampos
        Dim objGruposPaginas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas
        Dim camposInvalidos As String = ""
        Dim TipoLiga As Integer
        Try
            camposInvalidos = objValidar.ValidarCampos(validarCampos(txtNombreLiga, cboLiga))
            If camposInvalidos <> "" Then
                MsgBox("El o los campos: " & camposInvalidos & " ,son requeridos para guardar el registro")
                Exit Sub
            End If
            objGruposPaginas.Bandera = "i1"
            objGruposPaginas.Id_GruposPaginas = cboGrupos.SelectedValue
            objGruposPaginas.Nombre = txtNombreLiga.Text
            objGruposPaginas.Texto = txtTextoLigaIndex.Text
            REM existen tres tipos de ligas  (2) liga externa, (3) liga dinamica, (4) preestablecida

            If optTipoExternas.Checked Then
                TipoLiga = 2
            Else
                REM consultar el id de la pagina para sacar el tipo de liga
                Dim objPaginas As New clsPAginas.Maple.clsPaginas
                objPaginas.Bandera = "s1"
                objPaginas.Id_Pagina = cboLiga.SelectedValue
                objPaginas.LlenarDatos()
                Select Case objPaginas.Id_TipoPagina
                    Case 1, 2
                        TipoLiga = 3
                    Case 3
                        TipoLiga = 4
                End Select

                objPaginas = Nothing
            End If

            objGruposPaginas.Id_TiposLigas = TipoLiga
            objGruposPaginas.aId_DocumentoWeb = 0
            objGruposPaginas.aExterna = IIf(optTipoExternas.Checked = True, cboLiga.Text, Nothing)
            objGruposPaginas.aId_Pagina = IIf(optTipoCreadas.Checked = True, cboLiga.SelectedValue, 0)
            objGruposPaginas.Activo = True
            objGruposPaginas.Insertar()
            If objGruposPaginas.respRetorno(1) = "1" Then
                MsgBox(objGruposPaginas.respRetorno(0))
            Else
                MsgBox("Registro Insertado")
                botonesDeInicio()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objValidar = Nothing
            objGruposPaginas = Nothing
        End Try
    End Sub

    Private Sub Estilos(ByVal grd As DataGrid, ByVal Datosgrid As Array, ByVal dt As DataTable)
        If dt Is Nothing Then Exit Sub

        Dim Columnas As Integer = dt.Columns.Count
        Dim aux() As String
        Dim tama�o As Integer = 0
        Dim ts1 As New DataGridTableStyle
        Dim col As Integer = 0

        tama�o = grd.Width / Columnas
        grd.TableStyles.Clear()

        ts1.MappingName = dt.TableName
        ColorStyle(ts1, grd)
        Try

            For col = 0 To Columnas - 1
                aux = Split(Datosgrid(col), "|")

                Dim Columna
                If dt.Columns(col).DataType.FullName = "System.Boolean" Then
                    Columna = New DataGridBoolColumn
                Else
                    Columna = New DataGridTextBoxColumn
                End If

                Columna.MappingName = dt.Columns(col).ColumnName
                Columna.HeaderText = aux(0)

                If CType(aux(1), Boolean) = False Then
                    Columna.Width = 0
                Else
                    Columna.Width = tama�o + CType(aux(2), Integer)
                End If

                Columna.NullText = ""
                ts1.GridColumnStyles.Add(Columna)
            Next

            grd.TableStyles.Add(ts1)

        Catch ex As Exception
            MsgBox("asegurate que las columnas coincidan con los nombres")
        End Try
    End Sub

    Public Sub ColorStyle(ByVal ts1 As DataGridTableStyle, ByVal grid As DataGrid)
        ts1.SelectionForeColor = Color.White
        ts1.SelectionBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderForeColor = Color.White
        ts1.HeaderBackColor = Color.FromArgb(0, 95, 250)
        ts1.HeaderFont = New Font("Arial", 10.0!, FontStyle.Bold)
        ts1.AlternatingBackColor = Color.FromArgb(170, 230, 93)
        grid.BorderStyle = BorderStyle.Fixed3D
        grid.FlatMode = True
        grid.RowHeaderWidth = 18
    End Sub

    Private Sub grdLigas_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdLigas.Click
        If grdLigas.DataSource Is Nothing Then
            Exit Sub
        ElseIf CStr(grdLigas.Item(0, 0)) <> "" Then

            Dim iIndex As Integer
            Dim iConsecutivo As Integer
            iIndex = grdLigas.CurrentRowIndex

            iConsecutivo = grdLigas.Item(iIndex, 0)
            llenarDatos(iConsecutivo)
        End If
    End Sub

    Private Sub llenarDatos(ByVal id)
        Dim objGruposPaginas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas
        Try
            objGruposPaginas.Bandera = "s5"
            objGruposPaginas.Id_LigasGruposPaginas = id
            objGruposPaginas.LlenarDatos()

            txtNombreLiga.Text = objGruposPaginas.Nombre
            txtTextoLigaIndex.Text = objGruposPaginas.Texto

            If objGruposPaginas.Id_TiposLigas = 2 Then
                cboLiga.Text = objGruposPaginas.aExterna
            Else
                cboLiga.Text = buscarPagina(objGruposPaginas.aId_Pagina)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objGruposPaginas = Nothing
        End Try
    End Sub

    Private Function buscarPagina(ByVal idPagina As Integer) As String
        Dim objPagina As New clsPAginas.Maple.clsPaginas
        Try
            objPagina.Bandera = "s3"
            objPagina.Activo = True
            objPagina.Terminada = True
            objPagina.Id_Pagina = idPagina
            objPagina.LlenarDatos()
            buscarPagina = objPagina.Nombre
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            objPagina = Nothing
        End Try
        Return buscarPagina
    End Function

    Private Sub eliminarLiga()
        Dim objGruposPaginas As New clsLigasGruposPaginas.Maple.clsLigasGruposPaginas

        If grdLigas.DataSource Is Nothing Then
            MsgBox("Debes seleccionar un elemento de la lista")
            Exit Sub
        ElseIf CStr(grdLigas.Item(0, 0)) <> "" Then
            Try
                Dim iIndex As Integer
                Dim iConsecutivo As Integer
                iIndex = grdLigas.CurrentRowIndex

                iConsecutivo = grdLigas.Item(iIndex, 0)

                objGruposPaginas.Bandera = "u2"
                objGruposPaginas.Activo = False
                objGruposPaginas.Id_LigasGruposPaginas = iConsecutivo
                objGruposPaginas.Actualizar()

                If objGruposPaginas.respRetorno(1) = "1" Then
                    MsgBox(objGruposPaginas.respRetorno(0))
                Else
                    MsgBox("Registro eliminado correctamente")
                    botonesDeInicio()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                objGruposPaginas = Nothing
            End Try
        End If
    End Sub
End Class
