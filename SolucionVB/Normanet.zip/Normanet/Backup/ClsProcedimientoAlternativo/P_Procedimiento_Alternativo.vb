
     '*****************************************************************************
     '*****************************************************************************
     '                       NO TIENE CAMPO LLAVE CUIDADO
     '              Puede Afectar el correcto funcionamiento de las funciones
     '          De Actualizacion y de Borrado ya que se hacen sobre un campo llave
     '*****************************************************************************
     '*****************************************************************************

'*************************************************************************************
'Clase P_Procedimiento_Alternativo Generada automaticamente
'Desarrollada por EXTI, S.C. para ANCE, A.C.
'Fecha : 08/12/2006 10:18:41 a.m.
'*************************************************************************************


Option Explicit
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class P_Procedimiento_Alternativo

     '''''''Declaracion de Variables Privadas
     Private dsP_Procedimiento_Alternativo AS New DataSet
     Private _Id_Plan as System.String
     Private _Id_tema as System.Int32
     Private _Responsable as System.String
    Private _F_Inicio_Responsable As String
    Private _F_Fin_Responsable As String
    Private _F_Inicio_Comentarios As String
    Private _F_Fin_Comentarios As String
    Private _Bandera As Integer
    Private _error As String
    Private _Encontrado As Boolean
    Private _F_Carga_Minuta_Terminacion As String
    Private _Ref_A�o As String
    Private _Ref_Comite As String
    Private _Ref_Consecutivo As String
    Private _Ref_Regreso As String
    Private _Ref_Traspaso As String
    Private _status As Integer
    Private _Tipo As String
    Private _sReferencia As String
    Private sSql As String
    Private cn As New SqlClient.SqlConnection
    Private objconexion As New clsConexionArchivo.clsConexionArchivo


     '''''''Declaracion de Propiedades publicas
     Public Property Id_Plan() As System.String
          Get
              Return _Id_Plan
          End Get
          Set(Value as System.String)
              _Id_Plan = Value
          End Set
     End Property

     Public Property Id_tema() As System.Int32
          Get
              Return _Id_tema
          End Get
          Set(Value as System.Int32)
              _Id_tema = Value
          End Set
     End Property

     Public Property Responsable() As System.String
          Get
              Return _Responsable
          End Get
          Set(Value as System.String)
              _Responsable = Value
          End Set
     End Property

    Public Property F_Inicio_Responsable() As String
        Get
            If _F_Inicio_Responsable Is Nothing Then
                Return ""
            Else
                Return _F_Inicio_Responsable
            End If

        End Get
        Set(ByVal Value As String)
            If _F_Inicio_Responsable Is "" Then
                _F_Inicio_Responsable = Nothing
            Else
                _F_Inicio_Responsable = Value
            End If

        End Set
    End Property

    Public Property F_Fin_Responsable() As String
        Get
            If _F_Fin_Responsable Is Nothing Then
                Return ""
            Else
                Return _F_Fin_Responsable
            End If

        End Get
        Set(ByVal Value As String)
            _F_Fin_Responsable = Value
        End Set
    End Property

    Public Property F_Inicio_Comentarios() As String
        Get
            If _F_Inicio_Comentarios Is Nothing Then
                Return ""
            Else
                Return _F_Inicio_Comentarios
            End If

        End Get
        Set(ByVal Value As String)
            _F_Inicio_Comentarios = Value
        End Set
    End Property

    Public Property F_Fin_Comentarios() As String
        Get
            If _F_Fin_Comentarios Is Nothing Then
                Return ""
            Else
                Return _F_Fin_Comentarios
            End If
        End Get
        Set(ByVal Value As String)
            _F_Fin_Comentarios = Value
        End Set
    End Property
    Public Property Encontrado() As Boolean
        Get
            Return _Encontrado
        End Get
        Set(ByVal Value As Boolean)
            _Encontrado = Value
        End Set
    End Property
    Public Property Bandera() As Integer
        Get
            Return _Bandera
        End Get
        Set(ByVal Value As Integer)
            _Bandera = Value
        End Set
    End Property
    Public Property sError() As String
        Get
            Return _Error
        End Get
        Set(ByVal Value As String)
            _Error = Value
        End Set
    End Property

    Public Property RefA�o() As String
        Get
            Return _Ref_A�o
        End Get
        Set(ByVal Value As String)
            _Ref_A�o = Value
        End Set
    End Property
    Public Property RefComite() As String
        Get
            Return _Ref_Comite
        End Get
        Set(ByVal Value As String)
            _Ref_Comite = Value
        End Set
    End Property
    Public Property RefConsecutivo() As String
        Get
            Return _Ref_Consecutivo
        End Get
        Set(ByVal Value As String)
            _Ref_Consecutivo = Value
        End Set
    End Property
    Public Property RefRegreso() As String
        Get
            Return _Ref_Regreso
        End Get
        Set(ByVal Value As String)
            _Ref_Regreso = Value
        End Set
    End Property
    Public Property RefTraspaso() As String
        Get
            Return _Ref_Traspaso
        End Get
        Set(ByVal Value As String)
            _Ref_Traspaso = Value
        End Set
    End Property
    Public Property Status() As Integer
        Get
            Return _status
        End Get
        Set(ByVal Value As Integer)
            _status = Value
        End Set
    End Property
    Public Property F_Carga_Minuta_Terminacion() As String
        Get
            Return _F_Carga_Minuta_Terminacion
        End Get
        Set(ByVal Value As String)
            _F_Carga_Minuta_Terminacion = Value
        End Set
    End Property
    Public Property Tipo() As String
        Get
            Return _Tipo
        End Get
        Set(ByVal Value As String)
            _Tipo = Value
        End Set
    End Property
    Public Property sReferencia() As String
        Get
            Return _sReferencia
        End Get
        Set(ByVal Value As String)
            _sReferencia = Value
        End Set
    End Property

    '''''''Define la cadena de Conexion a la Base de Datos
    Private CadenaConexion As String = ""

    Public Sub New(ByVal Identif As Integer, ByVal Usuario As String, ByVal Password As String)
        Dim Servidor As String
        Dim Base As String

        sSql = objconexion.Conexion(Identif, Usuario, Password)
        cn.ConnectionString = sSql

        Servidor = objconexion.SserverC
        Base = objconexion.SBaseD
    End Sub

    '''''''''''''''''Genera una la lista de campos
    Public Function Listar() As DataTable
        If cn.State = ConnectionState.Open Then cn.Close()
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sp_ProcedimientoAlternativo_buscar"
        cmd.Connection = cn
        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_tema", _Id_tema)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@F_Inicio_Responsable", _F_Inicio_Responsable)
        cmd.Parameters.Add("@F_Fin_Responsable", _F_Fin_Responsable)
        cmd.Parameters.Add("@F_Inicio_Comentarios", _F_Inicio_Comentarios)
        cmd.Parameters.Add("@F_Fin_Comentarios", _F_Fin_Comentarios)
        cmd.Parameters.Add("@Bandera", _Bandera)
        Dim da As SqlDataAdapter
        Dim dt As New DataTable("ClsSesiones")
        Try
            da = New Data.SqlClient.SqlDataAdapter(cmd)
            da.Fill(dt)
            Return dt
        Catch ex As Exception
            _error = "ERROR - " + ex.Source + " " + ex.Message
            Return Nothing
        End Try
    End Function

    '''''''''''''''''Funcion para buscar datos en la tabla segun parametro
    Public Function Buscar(ByVal Id_plan As String, ByVal id_tema As String, ByVal sref As String) As P_Procedimiento_Alternativo
        '***** ASEGURATE CAMBIAR LA SENTENCIA SELECT DE ACUERDO A TUS CAMPOS DE BUSQUEDA Y BORRA ESTA LINEA*****
        sSql = "SELECT * FROM P_Procedimiento_Alternativo WHERE Id_Plan='" & Id_plan & "' and id_tema='" & id_tema & "' and status <> 0"
        sSql = sSql + " and Status <> 10 and Status <> 11 and ref_a�o + ref_comite + ref_consecutivo + ref_regreso + ref_traspaso = '" & sref & "'"
        'If _Tipo = "abandono" Then sSql = sSql + " order by dbo.P_Avance_Temas_Fechas.ref_regreso desc"
        'If _Tipo = "traspaso" Then sSql = sSql + " order by dbo.P_Avance_Temas_Fechas.traspaso desc "

        Dim da As New SqlDataAdapter(sSql, cn)
        If cn.State = 1 Then cn.Close()
        cn.Open()
        da.Fill(dsP_Procedimiento_Alternativo, "C_Encontrado")
        cn.Close()
        If dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows.Count > 0 Then
            _Ref_Traspaso = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Ref_Traspaso")
            _Ref_A�o = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Ref_A�o")
            _Ref_Comite = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Ref_Comite")
            _Ref_Regreso = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Ref_Regreso")
            _Ref_Consecutivo = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Ref_Consecutivo")

            _Id_Plan = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Id_Plan")
            _Id_tema = dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Id_tema")
            _Responsable = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Responsable")) = True, "", dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("Responsable"))
            _F_Inicio_Responsable = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Responsable")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Responsable"))
            _F_Fin_Responsable = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Fin_Responsable")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Fin_Responsable"))
            _F_Inicio_Comentarios = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Comentarios")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Comentarios"))
            _F_Fin_Comentarios = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Fin_Comentarios")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Fin_Comentarios"))
            _F_Carga_Minuta_Terminacion = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Carga_Minuta_Terminacion")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Carga_Minuta_Terminacion"))
            _F_Inicio_Responsable = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Responsable")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Inicio_Responsable"))
            _F_Fin_Responsable = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Fin_Responsable")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("F_Fin_Responsable"))
            _status = IIf(IsDBNull(dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("status")) = True, Nothing, dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Rows(0).Item("status"))
            _Encontrado = True
        Else
            _Id_Plan = ""
            _Id_tema = 0
            _Responsable = ""
            _F_Inicio_Responsable = Nothing
            _F_Fin_Responsable = Nothing
            _F_Inicio_Comentarios = Nothing
            _F_Fin_Comentarios = Nothing
            _Encontrado = False
        End If
        dsP_Procedimiento_Alternativo.Tables("C_Encontrado").Clear()
    End Function

    '''''''''''''''''Funcion que nos permite actualizar datos en nuestra base de datos
    Public Function Actualiza() As String

        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_ProcedimientoAlternativo"

        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_tema", _Id_tema)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@F_Inicio_Responsable", _F_Inicio_Responsable)
        cmd.Parameters.Add("@F_Fin_Responsable", _F_Fin_Responsable)
        cmd.Parameters.Add("@F_Inicio_Comentarios", _F_Inicio_Comentarios)
        cmd.Parameters.Add("@F_Fin_Comentarios", _F_Fin_Comentarios)
        cmd.Parameters.Add("@Bandera", _Bandera)
        cmd.Parameters.Add("@Status", _status)

        cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Ref_A�o", _Ref_A�o)
        cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
        cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)
        cmd.Parameters.Add("@F_carga_minuta", _F_Carga_Minuta_Terminacion)
        cmd.Parameters.Add("@sReferencia", _sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Function Insertar() As String
        Dim cmd As New SqlCommand
        cmd.CommandText = "sp_ProcedimientoAlternativo"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn

        cmd.Parameters.Add("@Ref_Traspaso", _Ref_Traspaso)
        cmd.Parameters.Add("@Ref_A�o", _Ref_A�o)
        cmd.Parameters.Add("@Ref_Comite", _Ref_Comite)
        cmd.Parameters.Add("@Ref_Regreso", _Ref_Regreso)
        cmd.Parameters.Add("@Ref_Consecutivo", _Ref_Consecutivo)

        cmd.Parameters.Add("@Id_Plan", _Id_Plan)
        cmd.Parameters.Add("@Id_tema", _Id_tema)
        cmd.Parameters.Add("@Responsable", _Responsable)
        cmd.Parameters.Add("@F_Inicio_Responsable", _F_Inicio_Responsable)
        cmd.Parameters.Add("@F_Fin_Responsable", _F_Fin_Responsable)
        cmd.Parameters.Add("@F_Inicio_Comentarios", _F_Inicio_Comentarios)
        cmd.Parameters.Add("@F_Fin_Comentarios", _F_Fin_Comentarios)
        cmd.Parameters.Add("@bandera", _Bandera)
        cmd.Parameters.Add("@F_Carga_Minuta_Terminacion", _F_Carga_Minuta_Terminacion)
        cmd.Parameters.Add("@Status", _status)
        cmd.Parameters.Add("@sReferencia", _sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
    Public Sub ActualizaProgAnterior()
        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "sp_ProcedimientoAlternativo"
            .CommandType = CommandType.StoredProcedure

            .Parameters.Add("@bandera", _Bandera)
            .Parameters.Add("@ref_a�o", _Ref_A�o)
            .Parameters.Add("@ref_comite", _Ref_Comite)
            .Parameters.Add("@ref_Consecutivo", _Ref_Consecutivo)
            .Parameters.Add("@ref_regreso", _Ref_Regreso)
            .Parameters.Add("@Status", _status)
            .Parameters.Add("@Id_Tema", _Id_tema)
            .Parameters.Add("@Id_plan", _Id_Plan)
            .Parameters.Add("@sReferencia", _sReferencia)

            If cn.State = 1 Then cn.Close()
            cn.Open()
            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Dim ms
                ms = ex.Message
            End Try
        End With
    End Sub
    Public Function Borrar(ByVal Id_Plan As String, ByVal Id_Tema As Integer, ByVal sReferencia As String)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        cmd.CommandText = "sp_ProcedimientoAlternativo"
        cmd.Parameters.Add("@Bandera", 6)
        cmd.Parameters.Add("@Id_Plan", Id_Plan)
        cmd.Parameters.Add("@Id_Tema", Id_Tema)
        cmd.Parameters.Add("@sReferencia", sReferencia)

        If cn.State = 1 Then cn.Close()
        cn.Open()
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function

    Public Sub traspasaAlter(ByVal plan As String, ByVal tema As Integer)
        _status = 1
        _Id_Plan = plan
        _Id_tema = tema
        _Bandera = 7
        _Ref_Traspaso = _Ref_Traspaso + 1
        Insertar()
    End Sub
End Class
